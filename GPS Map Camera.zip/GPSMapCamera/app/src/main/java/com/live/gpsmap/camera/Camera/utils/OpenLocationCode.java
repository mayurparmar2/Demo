package com.live.gpsmap.camera.Camera.utils;

import java.util.Objects;

/* loaded from: classes.dex */
public final class OpenLocationCode {
    public static final String CODE_ALPHABET = "23456789CFGHJMPQRVWX";
    public static final int CODE_PRECISION_NORMAL = 10;
    private static final int ENCODING_BASE = 20;
    private static final int GRID_CODE_LENGTH = 5;
    private static final int GRID_COLUMNS = 4;
    private static final int GRID_ROWS = 5;
    private static final long LATITUDE_MAX = 90;
    private static final long LAT_INTEGER_MULTIPLIER = 25000000;
    private static final long LAT_MSP_VALUE = (20 * LAT_INTEGER_MULTIPLIER) * 20;
    private static final long LNG_INTEGER_MULTIPLIER = 8192000;
    private static final long LNG_MSP_VALUE = (20 * LNG_INTEGER_MULTIPLIER) * 20;
    private static final long LONGITUDE_MAX = 180;
    public static final int MAX_DIGIT_COUNT = 15;
    public static final char PADDING_CHARACTER = '0';
    private static final int PAIR_CODE_LENGTH = 10;
    public static final char SEPARATOR = '+';
    private static final int SEPARATOR_POSITION = 8;
    private final String code;

    private static double normalizeLongitude(double d) {
        return (d < -180.0d || d >= 180.0d) ? ((((d % 360.0d) + 360.0d) + 180.0d) % 360.0d) - 180.0d : d;
    }

    /* loaded from: classes3.dex */
    public static class CodeArea {
        private final double eastLongitude;
        private final int length;
        private final double northLatitude;
        private final double southLatitude;
        private final double westLongitude;

        public CodeArea(double d, double d2, double d3, double d4, int i) {
            this.southLatitude = d;
            this.westLongitude = d2;
            this.northLatitude = d3;
            this.eastLongitude = d4;
            this.length = i;
        }

        public double getSouthLatitude() {
            return this.southLatitude;
        }

        public double getWestLongitude() {
            return this.westLongitude;
        }

        public double getLatitudeHeight() {
            return this.northLatitude - this.southLatitude;
        }

        public double getLongitudeWidth() {
            return this.eastLongitude - this.westLongitude;
        }

        public double getCenterLatitude() {
            return (this.southLatitude + this.northLatitude) / 2.0d;
        }

        public double getCenterLongitude() {
            return (this.westLongitude + this.eastLongitude) / 2.0d;
        }

        public double getNorthLatitude() {
            return this.northLatitude;
        }

        public double getEastLongitude() {
            return this.eastLongitude;
        }

        public int getLength() {
            return this.length;
        }
    }

    public OpenLocationCode(String str) {
        if (!isValidCode(str.toUpperCase())) {
            throw new IllegalArgumentException("The provided code '" + str + "' is not a valid Open Location Code.");
        }
        this.code = str.toUpperCase();
    }

    public OpenLocationCode(double d, double d2, int i) {
        int min = Math.min(i, 15);
        if ((min < 10 && min % 2 == 1) || min < 4) {
            throw new IllegalArgumentException("" + min);
        }
        double clipLatitude = clipLatitude(d);
        double normalizeLongitude = normalizeLongitude(d2);
        clipLatitude = clipLatitude == 90.0d ? clipLatitude - (computeLatitudePrecision(min) * 0.9d) : clipLatitude;
        StringBuilder sb = new StringBuilder();
        long round = (long) (Math.round(((clipLatitude + 90.0d) * 2.5E7d) * 1000000.0d) / 1000000.0d);
        long round2 = (long) (Math.round(((normalizeLongitude + 180.0d) * 8192000.0d) * 1000000.0d) / 1000000.0d);
        if (min > 10) {
            for (int i2 = 0; i2 < 5; i2++) {
                sb.append(CODE_ALPHABET.charAt((int) (((round % 5) * 4) + (round2 % 4))));
                round /= 5;
                round2 /= 4;
            }
        } else {
            round = (long) (round / Math.pow(5.0d, 5.0d));
            round2 = (long) (round2 / Math.pow(4.0d, 5.0d));
        }
        for (int i3 = 0; i3 < 5; i3++) {
            int i4 = ENCODING_BASE;
            sb.append(CODE_ALPHABET.charAt((int) (round2 % i4)));
            sb.append(CODE_ALPHABET.charAt((int) (round % i4)));
            round /= i4;
            round2 /= i4;
            if (i3 == 0) {
                sb.append(SEPARATOR);
            }
        }
        StringBuilder reverse = sb.reverse();
        if (min < 8) {
            for (int i5 = min; i5 < 8; i5++) {
                reverse.setCharAt(i5, PADDING_CHARACTER);
            }
        }
        this.code = reverse.subSequence(0, Math.max(9, min + 1)).toString();
    }

    public OpenLocationCode(double d, double d2) {
        this(d, d2, 10);
    }

    public String getCode() {
        return this.code;
    }

    public static String encode(double d, double d2) {
        return new OpenLocationCode(d, d2).getCode();
    }

    public static String encode(double d, double d2, int i) {
        return new OpenLocationCode(d, d2, i).getCode();
    }

    public CodeArea decode() {
        int i;
        if (!isFullCode(this.code)) {
            throw new IllegalStateException("Method decode() could only be called on valid full codes, code was " + this.code + ".");
        }
        String replace = this.code.replace(String.valueOf((char) SEPARATOR), "").replace(String.valueOf((char) PADDING_CHARACTER), "");
        long j = -2250000000L;
        long j2 = -1474560000;
        long j3 = LAT_MSP_VALUE;
        long j4 = LNG_MSP_VALUE;
        int i2 = 0;
        while (true) {
            if (i2 >= Math.min(replace.length(), 10)) {
                break;
            }
            int i3 = ENCODING_BASE;
            j3 /= i3;
            j4 /= i3;
            j += CODE_ALPHABET.indexOf(replace.charAt(i2)) * j3;
            j2 += CODE_ALPHABET.indexOf(replace.charAt(i2 + 1)) * j4;
            i2 += 2;
        }
        for (i = 10; i < Math.min(replace.length(), 15); i++) {
            j3 /= 5;
            j4 /= 4;
            int indexOf = CODE_ALPHABET.indexOf(replace.charAt(i));
            j += (indexOf / 4) * j3;
            j2 += (indexOf % 4) * j4;
        }
        return new CodeArea(j / 2.5E7d, j2 / 8192000.0d, (j + j3) / 2.5E7d, (j2 + j4) / 8192000.0d, Math.min(replace.length(), 15));
    }

    public static CodeArea decode(String str) throws IllegalArgumentException {
        return new OpenLocationCode(str).decode();
    }

    public boolean isFull() {
        return this.code.indexOf(43) == 8;
    }

    public static boolean isFull(String str) throws IllegalArgumentException {
        return new OpenLocationCode(str).isFull();
    }

    public boolean isShort() {
        return this.code.indexOf(43) >= 0 && this.code.indexOf(43) < 8;
    }

    public static boolean isShort(String str) throws IllegalArgumentException {
        return new OpenLocationCode(str).isShort();
    }

    private boolean isPadded() {
        return this.code.indexOf(48) >= 0;
    }

    public static boolean isPadded(String str) throws IllegalArgumentException {
        return new OpenLocationCode(str).isPadded();
    }

    public OpenLocationCode shorten(double d, double d2) {
        if (!isFull()) {
            throw new IllegalStateException("shorten() method could only be called on a full code.");
        }
        if (isPadded()) {
            throw new IllegalStateException("shorten() method can not be called on a padded code.");
        }
        CodeArea decode = decode();
        double max = Math.max(Math.abs(d - decode.getCenterLatitude()), Math.abs(d2 - decode.getCenterLongitude()));
        for (int i = 4; i >= 1; i--) {
            int i2 = i * 2;
            if (max < computeLatitudePrecision(i2) * 0.3d) {
                return new OpenLocationCode(this.code.substring(i2));
            }
        }
        throw new IllegalArgumentException("Reference location is too far from the Open Location Code center.");
    }

//Complete
    public OpenLocationCode recover(double f, double f1) {
        double f11;
        double f10;
        if(this.isFull()) {
            return this;
        }

        double f2 = OpenLocationCode.clipLatitude(f);
        double f3 = OpenLocationCode.normalizeLongitude(f1);
        int v = 8 - this.code.indexOf(43);
        double f4 = Math.pow(1.000000E-322, 2 - v / 2);
        OpenLocationCode openLocationCode0 = new OpenLocationCode(new OpenLocationCode(f2, f3).getCode().substring(0, v) + this.code);
        CodeArea openLocationCode$CodeArea0 = openLocationCode0.decode();
        double f5 = openLocationCode$CodeArea0.getCenterLatitude();
        double f6 = openLocationCode$CodeArea0.getCenterLongitude();
        double f7 = f5 - f2;
        double f8 = f4 / 2.0;
        if(f7 > f8) {
            double f9 = f5 - f4;
            if(f9 <= -90.0) {
                f10 = f6;
            }
            f10 = f6;
            f11 = f9;
        }
        else {
//            label_55:
            f10 = f6;
            if(f7 < -f4 / 2.0) {
                double f12 = f5 + f4;
                f11 = f12 < 90.0 ? f12 : f5;
            }
            else {
                f11 = f5;
            }
        }

        double f13 = openLocationCode$CodeArea0.getCenterLongitude() - f3;
        if(f13 > f8) {
            return new OpenLocationCode(f11, f10 - f4, openLocationCode0.getCode().length() - 1);
        }

        return f13 >= -f4 / 2.0 ? new OpenLocationCode(f11, f10, openLocationCode0.getCode().length() - 1) : new OpenLocationCode(f11, f10 + f4, openLocationCode0.getCode().length() - 1);
    }

    public boolean contains(double d, double d2) {
        CodeArea decode = decode();
        return decode.getSouthLatitude() <= d && d < decode.getNorthLatitude() && decode.getWestLongitude() <= d2 && d2 < decode.getEastLongitude();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.code, ((OpenLocationCode) obj).code);
    }

    public int hashCode() {
        String str = this.code;
        if (str != null) {
            return str.hashCode();
        }
        return 0;
    }

    public String toString() {
        return getCode();
    }

    public static boolean isValidCode(String str) {
        String upperCase;
        int indexOf;
        if (str == null || str.length() < 2 || (indexOf = (upperCase = str.toUpperCase()).indexOf(43)) == -1 || indexOf != upperCase.lastIndexOf(43) || indexOf % 2 != 0 || indexOf > 8) {
            return false;
        }
        if (indexOf != 8 || (CODE_ALPHABET.indexOf(upperCase.charAt(0)) <= 8 && CODE_ALPHABET.indexOf(upperCase.charAt(1)) <= 17)) {
            boolean z = false;
            for (int i = 0; i < indexOf; i++) {
                if (CODE_ALPHABET.indexOf(upperCase.charAt(i)) == -1 && upperCase.charAt(i) != '0') {
                    return false;
                }
                if (z) {
                    if (upperCase.charAt(i) != '0') {
                        return false;
                    }
                } else if (upperCase.charAt(i) != '0') {
                    continue;
                } else if (indexOf < 8) {
                    return false;
                } else {
                    if (i != 2 && i != 4 && i != 6) {
                        return false;
                    }
                    z = true;
                }
            }
            int i2 = indexOf + 1;
            if (upperCase.length() > i2) {
                if (z || upperCase.length() == indexOf + 2) {
                    return false;
                }
                while (i2 < upperCase.length()) {
                    if (CODE_ALPHABET.indexOf(upperCase.charAt(i2)) == -1) {
                        return false;
                    }
                    i2++;
                }
            }
            return true;
        }
        return false;
    }

    public static boolean isFullCode(String str) {
        try {
            return new OpenLocationCode(str).isFull();
        } catch (IllegalArgumentException unused) {
            return false;
        }
    }

    public static boolean isShortCode(String str) {
        try {
            return new OpenLocationCode(str).isShort();
        } catch (IllegalArgumentException unused) {
            return false;
        }
    }

    private static double clipLatitude(double d) {
        return Math.min(Math.max(d, -90.0d), 90.0d);
    }

    private static double computeLatitudePrecision(int i) {
        if (i <= 10) {
            return Math.pow(ENCODING_BASE, (i / (-2)) + 2);
        }
        return Math.pow(ENCODING_BASE, -3.0d) / Math.pow(5.0d, i - 10);
    }
}
