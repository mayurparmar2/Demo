package com.live.gpsmap.camera.Camera;

import android.content.Context;
import android.location.Location;


public class LocationSupplier {
    private static final String TAG = "LocationSupplier";
    private final Context context;
    private Location mLocation;

    public LocationSupplier(Context context) {
        this.context = context;
    }

    public void setLocation(Location location) {
        this.mLocation = location;
    }

    public Location getLocation() {
        return this.mLocation;
    }

    public static String locationToDMS(double d) {
        String str = d < 0.0d ? "-" : "";
        double abs = Math.abs(d);
        int i = (int) abs;
        boolean z = true;
        boolean z2 = i == 0;
        String valueOf = String.valueOf(i);
        double d2 = (abs - i) * 60.0d;
        int i2 = (int) d2;
        boolean z3 = z2 && i2 == 0;
        String valueOf2 = String.valueOf(i2);
        int i3 = (int) ((d2 - i2) * 60.0d);
        z = (z3 && i3 == 0) ? false : false;
        String valueOf3 = String.valueOf(i3);
        String str2 = z ? "" : str;
        return str2 + valueOf + "°" + valueOf2 + "'" + valueOf3 + "\"";
    }
}
