package com.live.gpsmap.camera.os_notifications;

/* loaded from: classes.dex */
public interface RateDialogBtnClickListener {
    void onRateBtnClicked();
}
