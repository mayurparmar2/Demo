package com.live.gpsmap.camera.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.live.gpsmap.camera.Interface.OnRecyclerItemClickListener;
import com.live.gpsmap.camera.Model.NotesModal;
import com.live.gpsmap.camera.R;

import java.util.ArrayList;

/* loaded from: classes.dex */
public class Notes_adapter extends RecyclerView.Adapter<Notes_adapter.NotesViewHolder> {
    ArrayList<NotesModal> Tag_list;
    Context context;
    OnRecyclerItemClickListener mOnRecyclerItemClickListener;
    int selectedposition;

    public Notes_adapter(Context context, ArrayList<NotesModal> arrayList, OnRecyclerItemClickListener onRecyclerItemClickListener) {
        new ArrayList();
        this.context = context;
        this.Tag_list = arrayList;
        this.mOnRecyclerItemClickListener = onRecyclerItemClickListener;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public NotesViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new NotesViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.notes_list, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(NotesViewHolder notesViewHolder, @SuppressLint("RecyclerView") int i) {
        NotesModal notesModal = this.Tag_list.get(i);
        TextView textView = notesViewHolder.txt_title;
        textView.setText(notesModal.getTiitle() + " " + notesModal.getNotes());
        if (notesModal.getSelected() == 1) {
            this.selectedposition = i;
            notesViewHolder.img_select.setVisibility(View.VISIBLE);
            return;
        }
        notesViewHolder.img_select.setVisibility(View.INVISIBLE);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.Tag_list.size();
    }

    public void refreceadapter(ArrayList<NotesModal> arrayList) {
        this.Tag_list = arrayList;
        notifyDataSetChanged();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes2.dex */
    public class NotesViewHolder extends RecyclerView.ViewHolder {
        ImageView img_select;
        LinearLayout main_lin;
        TextView txt_title;

        public NotesViewHolder(View view) {
            super(view);
            this.txt_title = (TextView) view.findViewById(R.id.txt_title);
            this.img_select = (ImageView) view.findViewById(R.id.img_select);
            LinearLayout linearLayout = (LinearLayout) view.findViewById(R.id.main_lin);
            this.main_lin = linearLayout;
            linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.adapter.Notes_adapter.NotesViewHolder.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    if (NotesViewHolder.this.getAdapterPosition() < 0 || Notes_adapter.this.mOnRecyclerItemClickListener == null) {
                        return;
                    }
                    Notes_adapter.this.mOnRecyclerItemClickListener.OnClick_(NotesViewHolder.this.getAdapterPosition(), view2);
                }
            });
            this.main_lin.setOnLongClickListener(new View.OnLongClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.adapter.Notes_adapter.NotesViewHolder.2
                @Override // android.view.View.OnLongClickListener
                public boolean onLongClick(View view2) {
                    if (NotesViewHolder.this.getAdapterPosition() <= 0 || NotesViewHolder.this.getAdapterPosition() == Notes_adapter.this.selectedposition || Notes_adapter.this.mOnRecyclerItemClickListener == null) {
                        return false;
                    }
                    Notes_adapter.this.mOnRecyclerItemClickListener.OnLongClick_(NotesViewHolder.this.getAdapterPosition(), view2);
                    return false;
                }
            });
        }
    }
}