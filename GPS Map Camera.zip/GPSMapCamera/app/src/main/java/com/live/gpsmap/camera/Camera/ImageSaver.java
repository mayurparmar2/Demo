package com.live.gpsmap.camera.Camera;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.Log;
import android.util.Xml;

import androidx.exifinterface.media.ExifInterface;

import com.live.gpsmap.camera.Camera.cameracontroller.CameraController;
import com.live.gpsmap.camera.Camera.cameracontroller.RawImage;
import com.live.gpsmap.camera.Camera.utils.GPS;
import com.live.gpsmap.camera.Camera.utils.NetworkState;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.SP;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlSerializer;

@SuppressWarnings("All")
public class ImageSaver extends Thread {
    private static final String TAG = "ImageSaver";
    private static final String gyro_info_camera_view_angle_x_tag = "camera_view_angle_x";
    private static final String gyro_info_camera_view_angle_y_tag = "camera_view_angle_y";
    private static final String gyro_info_doc_tag = "open_camera_gyro_info";
    private static final String gyro_info_image_tag = "image";
    private static final String gyro_info_panorama_pics_per_screen_tag = "panorama_pics_per_screen";
    private static final String gyro_info_vector_right_type = "X";
    private static final String gyro_info_vector_screen_type = "Z";
    private static final String gyro_info_vector_tag = "vector";
    private static final String gyro_info_vector_up_type = "Y";
    private static final int queue_cost_dng_c = 6;
    private static final int queue_cost_jpeg_c = 1;
    public static volatile boolean test_small_queue_size;
    private boolean app_is_paused;
    private final HDRProcessor hdrProcessor;
    private final CameraMainActivity main_activity;
    private int n_images_to_save;
    private int n_real_images_to_save;
    private final Paint p;
    private final PanoramaProcessor panoramaProcessor;
    private Request pending_image_average_request;
    private final BlockingQueue<Request> queue;
    private final int queue_capacity;
    public volatile boolean test_queue_blocked;
    public volatile boolean test_slow_saving;

    /* loaded from: classes3.dex */
    public static class GyroDebugInfo {
        public final List<GyroImageDebugInfo> image_info = new ArrayList();


        public static class GyroImageDebugInfo {
            public float[] vectorRight;
            public float[] vectorScreen;
            public float[] vectorUp;
        }
    }

    private boolean needGPSTimestampHack(boolean z, boolean z2, boolean z3) {
        if (z && z2) {
            return z3;
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes3.dex */
    public static class Request {
        float camera_view_angle_x;
        float camera_view_angle_y;
        final int color;
        final Date current_date;
        final String custom_tag_artist;
        final String custom_tag_copyright;
        boolean do_auto_stabilise;

        final long exposure_time;
        final int font_size;
        final boolean force_suffix;
        final double geo_direction;
        final List<float[]> gyro_rotation_matrix;
        final boolean image_capture_intent;
        final Uri image_capture_intent_uri;
        ImageFormat image_format;
        int image_quality;
        final boolean is_front_facing;
        final int iso;
        final List<byte[]> jpeg_images;
        final double level_angle;
        final Location location;
        boolean mirror;
        final boolean panorama_crop;
        boolean panorama_dir_left_to_right;
        final double pitch_angle;
        final String pref_style;
        final String preference_hdr_contrast_enhancement;
        String preference_stamp;
        final String preference_stamp_dateformat;
//        final String preference_stamp_geo_address;
        final String preference_stamp_gpsformat;
        final String preference_stamp_timeformat;
        String preference_textstamp;
        final String preference_units_distance;
        final ProcessType process_type;
        final RawImage raw_image;
        final int sample_factor;
        final SaveBase save_base;
        final boolean store_geo_direction;
        final boolean store_location;
        final boolean store_ypr;
        final int suffix_offset;
        final Type type;
        final boolean using_camera2;
        final float zoom_factor;
        final HDRProcessor.TonemappingAlgorithm preference_hdr_tonemapping_algorithm;

        /* JADX INFO: Access modifiers changed from: package-private */
        /* loaded from: classes3.dex */
        enum RemoveDeviceExif {
            OFF, // don't remove any device exif tags
            ON, // remove all device exif tags
            KEEP_DATETIME // remove all device exif tags except datetime tags
        }
        public enum ImageFormat {
            STD,
            WEBP,
            PNG
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        /* loaded from: classes.dex */
        public enum ProcessType {
            NORMAL,
            HDR,
            AVERAGE,
            PANORAMA,
            X_NIGHT
        }


        public enum SaveBase {
            SAVEBASE_NONE,
            SAVEBASE_FIRST,
            SAVEBASE_ALL,
            SAVEBASE_ALL_PLUS_DEBUG
        }

        public enum Type {
            JPEG,
            RAW,
            DUMMY,
            ON_DESTROY
        }
        boolean using_camera_extensions;
        final RemoveDeviceExif remove_device_exif;
        Request(Type type,
                ProcessType process_type,
                boolean force_suffix,
                int suffix_offset,
                SaveBase save_base,
                List<byte []> jpeg_images,
                RawImage raw_image,
                boolean image_capture_intent, Uri image_capture_intent_uri,
                boolean using_camera2, boolean using_camera_extensions,
                ImageFormat image_format, int image_quality,
                boolean do_auto_stabilise, double level_angle, List<float []> gyro_rotation_matrix,
                boolean is_front_facing,
                boolean mirror,
                Date current_date,
                HDRProcessor.TonemappingAlgorithm preference_hdr_tonemapping_algorithm,
                String preference_hdr_contrast_enhancement,
                int iso,
                long exposure_time,
                float zoom_factor,
                String preference_stamp, String preference_textstamp, int font_size, int color, String pref_style, String preference_stamp_dateformat, String preference_stamp_timeformat, String preference_stamp_gpsformat,
                //String preference_stamp_geo_address,
                String preference_units_distance,
                boolean panorama_crop,
                RemoveDeviceExif remove_device_exif,
                boolean store_location, Location location, boolean store_geo_direction, double geo_direction,
                double pitch_angle, boolean store_ypr,
                String custom_tag_artist,
                String custom_tag_copyright,
                int sample_factor) {
            this.type = type;
            this.process_type = process_type;
            this.force_suffix = force_suffix;
            this.suffix_offset = suffix_offset;
            this.save_base = save_base;
            this.jpeg_images = jpeg_images;
            this.raw_image = raw_image;
            this.image_capture_intent = image_capture_intent;
            this.image_capture_intent_uri = image_capture_intent_uri;
            this.using_camera2 = using_camera2;
            this.using_camera_extensions = using_camera_extensions;
            this.image_format = image_format;
            this.image_quality = image_quality;
            this.do_auto_stabilise = do_auto_stabilise;
            this.level_angle = level_angle;
            this.gyro_rotation_matrix = gyro_rotation_matrix;
            this.is_front_facing = is_front_facing;
            this.mirror = mirror;
            this.current_date = current_date;
            this.preference_hdr_tonemapping_algorithm = preference_hdr_tonemapping_algorithm;
            this.preference_hdr_contrast_enhancement = preference_hdr_contrast_enhancement;
            this.iso = iso;
            this.exposure_time = exposure_time;
            this.zoom_factor = zoom_factor;
            this.preference_stamp = preference_stamp;
            this.preference_textstamp = preference_textstamp;
            this.font_size = font_size;
            this.color = color;
            this.pref_style = pref_style;
            this.preference_stamp_dateformat = preference_stamp_dateformat;
            this.preference_stamp_timeformat = preference_stamp_timeformat;
            this.preference_stamp_gpsformat = preference_stamp_gpsformat;
            //this.preference_stamp_geo_address = preference_stamp_geo_address;
            this.preference_units_distance = preference_units_distance;
            this.panorama_crop = panorama_crop;
            this.remove_device_exif = remove_device_exif;
            this.store_location = store_location;
            this.location = location;
            this.store_geo_direction = store_geo_direction;
            this.geo_direction = geo_direction;
            this.pitch_angle = pitch_angle;
            this.store_ypr = store_ypr;
            this.custom_tag_artist = custom_tag_artist;
            this.custom_tag_copyright = custom_tag_copyright;
            this.sample_factor = sample_factor;
        }

        Request copy() {
            return new Request(this.type,
                    this.process_type,
                    this.force_suffix,
                    this.suffix_offset,
                    this.save_base,
                    this.jpeg_images,
                    this.raw_image,
                    this.image_capture_intent, this.image_capture_intent_uri,
                    this.using_camera2, this.using_camera_extensions,
                    this.image_format, this.image_quality,
                    this.do_auto_stabilise, this.level_angle, this.gyro_rotation_matrix,
                    this.is_front_facing,
                    this.mirror,
                    this.current_date,
                    this.preference_hdr_tonemapping_algorithm,
                    this.preference_hdr_contrast_enhancement,
                    this.iso,
                    this.exposure_time,
                    this.zoom_factor,
                    this.preference_stamp, this.preference_textstamp, this.font_size, this.color, this.pref_style, this.preference_stamp_dateformat, this.preference_stamp_timeformat, this.preference_stamp_gpsformat,
                    //this.preference_stamp_geo_address,
                    this.preference_units_distance,
                    this.panorama_crop, this.remove_device_exif, this.store_location, this.location, this.store_geo_direction, this.geo_direction,
                    this.pitch_angle, this.store_ypr,
                    this.custom_tag_artist,
                    this.custom_tag_copyright,
                    this.sample_factor);
        }
    }

    public ImageSaver(CameraMainActivity mainActivity) {
        Paint paint = new Paint();
        this.p = paint;
        this.n_images_to_save = 0;
        this.n_real_images_to_save = 0;
        this.app_is_paused = true;
        this.pending_image_average_request = null;
        Log.d(TAG, TAG);
        this.main_activity = mainActivity;
        int computeQueueSize = computeQueueSize(((ActivityManager) mainActivity.getSystemService("activity")).getLargeMemoryClass());
        this.queue_capacity = computeQueueSize;
        this.queue = new ArrayBlockingQueue(computeQueueSize);
        HDRProcessor hDRProcessor = new HDRProcessor(mainActivity, mainActivity.is_test);
        this.hdrProcessor = hDRProcessor;
        this.panoramaProcessor = new PanoramaProcessor(mainActivity, hDRProcessor);
        paint.setAntiAlias(true);
    }

    public int getQueueSize() {
        return this.queue_capacity;
    }

    public static int computeQueueSize(int i) {
        Log.d(TAG, "large max memory = " + i + "MB");
        StringBuilder sb = new StringBuilder();
        sb.append("test_small_queue_size?: ");
        sb.append(test_small_queue_size);
        Log.d(TAG, sb.toString());
        if (test_small_queue_size) {
            i = 0;
        }
        int i2 = i>=512 ? 34 : i>=256 ? 12 : i>=128 ? 8 : 6;
        Log.d(TAG, "max_queue_size = " + i2);
        return i2;
    }

    public static int computeRequestCost(boolean z, int i) {
        Log.d(TAG, "computeRequestCost");
        Log.d(TAG, "is_raw: " + z);
        Log.d(TAG, "n_images: " + i);
        return z ? i * 6 : i * 1;
    }

    public int computePhotoCost(int i, int i2) {
        Log.d(TAG, "computePhotoCost");
        Log.d(TAG, "n_raw: " + i);
        Log.d(TAG, "n_jpegs: " + i2);
        int computeRequestCost = i>0 ? computeRequestCost(true, i) + 0 : 0;
        if (i2>0) {
            computeRequestCost += computeRequestCost(false, i2);
        }
        Log.d(TAG, "cost: " + computeRequestCost);
        return computeRequestCost;
    }


    public boolean queueWouldBlock(int i, int i2) {
        return queueWouldBlock(computePhotoCost(i, i2));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public synchronized boolean queueWouldBlock(int i) {
        Log.d(TAG, "queueWouldBlock");
        Log.d(TAG, "photo_cost: " + i);
        Log.d(TAG, "n_images_to_save: " + this.n_images_to_save);
        Log.d(TAG, "queue_capacity: " + this.queue_capacity);
        int i2 = this.n_images_to_save;
        if (i2 == 0) {
            Log.d(TAG, "queue is empty");
            return false;
        } else if (i2 + i>this.queue_capacity + 1) {
            Log.d(TAG, "queue would block");
            return true;
        } else {
            Log.d(TAG, "queue would not block");
            return false;
        }
    }


    public int getMaxDNG() {
        int i = ((this.queue_capacity + 1) / 6) + 1;
        Log.d(TAG, "max_dng = " + i);
        return i;
    }

    public synchronized int getNImagesToSave() {
        return this.n_images_to_save;
    }

    public synchronized int getNRealImagesToSave() {
        return this.n_real_images_to_save;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void onPause() {
        synchronized (this) {
            this.app_is_paused = true;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void onResume() {
        synchronized (this) {
            this.app_is_paused = false;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        PanoramaProcessor panoramaProcessor = this.panoramaProcessor;
        if (panoramaProcessor != null) {
            panoramaProcessor.onDestroy();
        }
        HDRProcessor hDRProcessor = this.hdrProcessor;
        if (hDRProcessor != null) {
            hDRProcessor.onDestroy();
        }
    }

    @Override
    public void run() {
        if (MyDebug.LOG)
            Log.d(TAG, "starting ImageSaver thread...");
        while (true) {
            try {
                if (MyDebug.LOG)
                    Log.d(TAG, "ImageSaver thread reading from queue, size: " + queue.size());
                Request request = queue.take(); // if empty, take() blocks until non-empty
                // Only decrement n_images_to_save after we've actually saved the image! Otherwise waitUntilDone() will return
                // even though we still have a last image to be saved.
                if (MyDebug.LOG)
                    Log.d(TAG, "ImageSaver thread found new request from queue, size is now: " + queue.size());
                boolean success;
                boolean on_destroy = false;
                switch (request.type) {
                    case RAW:
                        if (MyDebug.LOG)
                            Log.d(TAG, "request is raw");
                        success = saveImageNowRaw(request);
                        break;
                    case JPEG:
                        if (MyDebug.LOG)
                            Log.d(TAG, "request is jpeg");
                        success = saveImageNow(request);
                        break;
                    case DUMMY:
                        if (MyDebug.LOG)
                            Log.d(TAG, "request is dummy");
                        success = true;
                        break;
                    case ON_DESTROY:
                        if (MyDebug.LOG)
                            Log.d(TAG, "request is on_destroy");
                        success = true;
                        on_destroy = true;
                        break;
                    default:
                        if (MyDebug.LOG)
                            Log.e(TAG, "request is unknown type!");
                        success = false;
                        break;
                }
                if (test_slow_saving) {
                    // ignore warning about "Call to Thread.sleep in a loop", this is only activated in test code
                    //noinspection BusyWait
                    Thread.sleep(2000);
                }
                if (MyDebug.LOG) {
                    if (success)
                        Log.d(TAG, "ImageSaver thread successfully saved image");
                    else
                        Log.e(TAG, "ImageSaver thread failed to save image");
                }
                synchronized (this) {
                    n_images_to_save--;
                    if (request.type != Request.Type.DUMMY && request.type != Request.Type.ON_DESTROY)
                        n_real_images_to_save--;
                    if (MyDebug.LOG)
                        Log.d(TAG, "ImageSaver thread processed new request from queue, images to save is now: " + n_images_to_save);
                    if (MyDebug.LOG && n_images_to_save<0) {
                        Log.e(TAG, "images to save has become negative");
                        throw new RuntimeException();
                    } else if (MyDebug.LOG && n_real_images_to_save<0) {
                        Log.e(TAG, "real images to save has become negative");
                        throw new RuntimeException();
                    }
                    notifyAll();

                    main_activity.runOnUiThread(new Runnable() {
                        public void run() {
                            main_activity.imageQueueChanged();
                        }
                    });
                }
                if (on_destroy) {
                    break;
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
                if (MyDebug.LOG)
                    Log.e(TAG, "interrupted while trying to read from ImageSaver queue");
            }
        }
        if (MyDebug.LOG)
            Log.d(TAG, "stopping ImageSaver thread...");
    }


//    public boolean saveImageJpeg(boolean z, boolean z2, boolean z3, int i, boolean z4, List<byte[]> list, boolean z5, Uri uri, boolean z6, Request.ImageFormat imageFormat, int i2, boolean z7, double d, boolean z8, boolean z9, Date date, String str, int i3, long j, float f, String str2, String str3, int i4, int i5, String str4, String str5, String str6, String str7, String str8, String str9, boolean z10, boolean z11, Location location, boolean z12, double d2, double d3, boolean z13, String str10, String str11, int i6) {
//        Log.d(TAG, "saveImageJpeg");
//        Log.d(TAG, "do_in_background? " + z);
//        Log.d(TAG, "number of images: " + list.size());
//        return saveImage(z, false, z2, z3, i, z4, list, null, z5, uri, z6, imageFormat, i2, z7, d, z8, z9, date, str, i3, j, f, str2, str3, i4, i5, str4, str5, str6, str7, str8, str9, z10, z11, location, z12, d2, d3, z13, str10, str11, i6);
//    }

    boolean saveImageJpeg(boolean do_in_background,
                          Request.ProcessType processType,
                          boolean force_suffix,
                          int suffix_offset,
                          boolean save_expo,
                          List<byte []> images,
                          boolean image_capture_intent, Uri image_capture_intent_uri,
                          boolean using_camera2, boolean using_camera_extensions,
                          Request.ImageFormat image_format, int image_quality,
                          boolean do_auto_stabilise, double level_angle,
                          boolean is_front_facing,
                          boolean mirror,
                          Date current_date,
                          HDRProcessor.TonemappingAlgorithm preference_hdr_tonemapping_algorithm,
                          String preference_hdr_contrast_enhancement,
                          int iso,
                          long exposure_time,
                          float zoom_factor,
                          String preference_stamp, String preference_textstamp, int font_size, int color, String pref_style, String preference_stamp_dateformat, String preference_stamp_timeformat, String preference_stamp_gpsformat,
                          //String preference_stamp_geo_address,
                          String preference_units_distance,
                          boolean panorama_crop,
                          Request.RemoveDeviceExif remove_device_exif,
                          boolean store_location, Location location, boolean store_geo_direction, double geo_direction,
                          double pitch_angle, boolean store_ypr,
                          String custom_tag_artist,
                          String custom_tag_copyright,
                          int sample_factor) {
        if( MyDebug.LOG ) {
            Log.d(TAG, "saveImageJpeg");
            Log.d(TAG, "do_in_background? " + do_in_background);
            Log.d(TAG, "number of images: " + images.size());
        }
        return saveImage(do_in_background,
                false,
                processType,
                force_suffix,
                suffix_offset,
                save_expo,
                images,
                null,
                image_capture_intent, image_capture_intent_uri,
                using_camera2, using_camera_extensions,
                image_format, image_quality,
                do_auto_stabilise, level_angle,
                is_front_facing,
                mirror,
                current_date,
                preference_hdr_tonemapping_algorithm,
                preference_hdr_contrast_enhancement,
                iso,
                exposure_time,
                zoom_factor,
                preference_stamp, preference_textstamp, font_size, color, pref_style, preference_stamp_dateformat, preference_stamp_timeformat, preference_stamp_gpsformat,
                //preference_stamp_geo_address,
                preference_units_distance,
                panorama_crop, remove_device_exif, store_location, location, store_geo_direction, geo_direction,
                pitch_angle, store_ypr,
                custom_tag_artist,
                custom_tag_copyright,
                sample_factor);
    }


    /* JADX INFO: Access modifiers changed from: package-private */
//    public boolean saveImageRaw(boolean z, boolean z2, int i, RawImage rawImage, Date date) {
//        Log.d(TAG, "saveImageRaw");
//        Log.d(TAG, "do_in_background? " + z);
//        return saveImage(z, true, false, z2, i, false, null, rawImage, false, null, false, Request.ImageFormat.STD, 0, false, 0.0d, false, false, date, null, 0, 0L, 1.0f, null, null, 0, 0, null, null, null, null, null, null, false, false, null, false, 0.0d, 0.0d, false, null, null, 1);
//    }

    boolean saveImageRaw(boolean do_in_background,
                         boolean force_suffix,
                         int suffix_offset,
                         RawImage raw_image,
                         Date current_date) {
        if( MyDebug.LOG ) {
            Log.d(TAG, "saveImageRaw");
            Log.d(TAG, "do_in_background? " + do_in_background);
        }
        return saveImage(do_in_background,
                true,
                Request.ProcessType.NORMAL,
                force_suffix,
                suffix_offset,
                false,
                null,
                raw_image,
                false, null,
                false, false,
                Request.ImageFormat.STD, 0,
                false, 0.0,
                false,
                false,
                current_date,
                HDRProcessor.default_tonemapping_algorithm_c,
                null,
                0,
                0,
                1.0f,
                null, null, 0, 0, null, null, null, null,
                //null,
                null,
                false, Request.RemoveDeviceExif.OFF, false, null, false, 0.0,
                0.0, false,
                null, null,
                1);
    }

//    public void startImageBatch(boolean z, Request.ProcessType processType, Request.SaveBase saveBase, boolean z2, Uri uri, boolean z3, Request.ImageFormat imageFormat, int i, boolean z4, double d, boolean z5, boolean z6, boolean z7, Date date, int i2, long j, float f, String str, String str2, int i3, int i4, String str3, String str4, String str5, String str6, String str7, String str8, boolean z8, boolean z9, Location location, boolean z10, double d2, double d3, boolean z11, String str9, String str10, int i5) {
//        Log.d(TAG, "startImageBatch");
//        Log.d(TAG, "do_in_background? " + z);
//        this.pending_image_average_request = new Request(Request.Type.JPEG, processType, false, 0, saveBase, new ArrayList(), null, z2, uri, z3, imageFormat, i, z4, d, z5 ? new ArrayList() : null, z6, z7, date, null, i2, j, f, str, str2, i3, i4, str3, str4, str5, str6, str7, str8, z8, z9, location, z10, d2, d3, z11, str9, str10, i5);
//    }
void startImageBatch(boolean do_in_background,
                     Request.ProcessType processType,
                     Request.SaveBase save_base,
                     boolean image_capture_intent, Uri image_capture_intent_uri,
                     boolean using_camera2, boolean using_camera_extensions,
                     Request.ImageFormat image_format, int image_quality,
                     boolean do_auto_stabilise, double level_angle, boolean want_gyro_matrices,
                     boolean is_front_facing,
                     boolean mirror,
                     Date current_date,
                     int iso,
                     long exposure_time,
                     float zoom_factor,
                     String preference_stamp, String preference_textstamp, int font_size, int color, String pref_style, String preference_stamp_dateformat, String preference_stamp_timeformat, String preference_stamp_gpsformat,
                     //String preference_stamp_geo_address,
                     String preference_units_distance,
                     boolean panorama_crop,
                     Request.RemoveDeviceExif remove_device_exif,
                     boolean store_location, Location location, boolean store_geo_direction, double geo_direction,
                     double pitch_angle, boolean store_ypr,
                     String custom_tag_artist,
                     String custom_tag_copyright,
                     int sample_factor) {
    if( MyDebug.LOG ) {
        Log.d(TAG, "startImageBatch");
        Log.d(TAG, "do_in_background? " + do_in_background);
    }
    pending_image_average_request = new Request(Request.Type.JPEG,
            processType,
            false,
            0,
            save_base,
            new ArrayList<>(),
            null,
            image_capture_intent, image_capture_intent_uri,
            using_camera2, using_camera_extensions,
            image_format, image_quality,
            do_auto_stabilise, level_angle, want_gyro_matrices ? new ArrayList<>() : null,
            is_front_facing,
            mirror,
            current_date,
            HDRProcessor.default_tonemapping_algorithm_c,
            null,
            iso,
            exposure_time,
            zoom_factor,
            preference_stamp, preference_textstamp, font_size, color, pref_style, preference_stamp_dateformat, preference_stamp_timeformat, preference_stamp_gpsformat,
            //preference_stamp_geo_address,
            preference_units_distance,
            panorama_crop, remove_device_exif, store_location, location, store_geo_direction, geo_direction,
            pitch_angle, store_ypr,
            custom_tag_artist,
            custom_tag_copyright,
            sample_factor);
}

    /* JADX INFO: Access modifiers changed from: package-private */
    public void addImageBatch(byte[] bArr, float[] fArr) {
        Log.d(TAG, "addImageBatch");
        Request request = this.pending_image_average_request;
        if (request == null) {
            Log.e(TAG, "addImageBatch called but no pending_image_average_request");
            return;
        }
        request.jpeg_images.add(bArr);
        if (fArr != null) {
            float[] fArr2 = new float[fArr.length];
            System.arraycopy(fArr, 0, fArr2, 0, fArr.length);
            this.pending_image_average_request.gyro_rotation_matrix.add(fArr2);
        }
        Log.d(TAG, "image average request images: " + this.pending_image_average_request.jpeg_images.size());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Request getImageBatchRequest() {
        return this.pending_image_average_request;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void finishImageBatch(boolean z) {
        Log.d(TAG, "finishImageBatch");
        if (this.pending_image_average_request == null) {
            Log.d(TAG, "finishImageBatch called but no pending_image_average_request");
            return;
        }
        if (z) {
            Log.d(TAG, "add background request");
            addRequest(this.pending_image_average_request, computeRequestCost(false, this.pending_image_average_request.jpeg_images.size()));
        } else {
            waitUntilDone();
            saveImageNow(this.pending_image_average_request);
        }
        this.pending_image_average_request = null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void flushImageBatch() {
        Log.d(TAG, "flushImageBatch");
        this.pending_image_average_request = null;
    }

//    private boolean saveImage(boolean z, boolean z2, boolean z3, boolean z4, int i, boolean z5, List<byte[]> list, RawImage rawImage, boolean z6, Uri uri, boolean z7, Request.ImageFormat imageFormat, int i2, boolean z8, double d, boolean z9, boolean z10, Date date, String str, int i3, long j, float f, String str2, String str3, int i4, int i5, String str4, String str5, String str6, String str7, String str8, String str9, boolean z11, boolean z12, Location location, boolean z13, double d2, double d3, boolean z14, String str10, String str11, int i6) {
//        Log.d(TAG, "saveImage");
//        Log.d(TAG, "do_in_background? " + z);
//        Request request = new Request(z2 ? Request.Type.RAW : Request.Type.JPEG, z3 ? Request.ProcessType.HDR : Request.ProcessType.NORMAL, z4, i, z5 ? Request.SaveBase.SAVEBASE_ALL : Request.SaveBase.SAVEBASE_NONE, list, rawImage, z6, uri, z7, imageFormat, i2, z8, d, null, z9, z10, date, str, i3, j, f, str2, str3, i4, i5, str4, str5, str6, str7, str8, str9, z11, z12, location, z13, d2, d3, z14, str10, str11, i6);
//        boolean z15 = true;
//        if (z) {
//            Log.d(TAG, "add background request");
//            addRequest(request, computeRequestCost(z2, z2 ? 1 : request.jpeg_images.size()));
//        } else {
//            waitUntilDone();
//            if (z2) {
//                z15 = saveImageNowRaw(request);
//            } else {
//                z15 = saveImageNow(request);
//            }
//        }
//        Log.d(TAG, "success: " + z15);
//        return z15;
//    }

    private boolean saveImage(boolean do_in_background,
                              boolean is_raw,
                              Request.ProcessType processType,
                              boolean force_suffix,
                              int suffix_offset,
                              boolean save_expo,
                              List<byte []> jpeg_images,
                              RawImage raw_image,
                              boolean image_capture_intent, Uri image_capture_intent_uri,
                              boolean using_camera2, boolean using_camera_extensions,
                              Request.ImageFormat image_format, int image_quality,
                              boolean do_auto_stabilise, double level_angle,
                              boolean is_front_facing,
                              boolean mirror,
                              Date current_date,
                              HDRProcessor.TonemappingAlgorithm preference_hdr_tonemapping_algorithm,
                              String preference_hdr_contrast_enhancement,
                              int iso,
                              long exposure_time,
                              float zoom_factor,
                              String preference_stamp, String preference_textstamp, int font_size, int color, String pref_style, String preference_stamp_dateformat, String preference_stamp_timeformat, String preference_stamp_gpsformat,
                              //String preference_stamp_geo_address,
                              String preference_units_distance,
                              boolean panorama_crop,
                              Request.RemoveDeviceExif remove_device_exif,
                              boolean store_location, Location location, boolean store_geo_direction, double geo_direction,
                              double pitch_angle, boolean store_ypr,
                              String custom_tag_artist,
                              String custom_tag_copyright,
                              int sample_factor) {
        if( MyDebug.LOG ) {
            Log.d(TAG, "saveImage");
            Log.d(TAG, "do_in_background? " + do_in_background);
        }
        boolean success;

        //do_in_background = false;

        Request request = new Request(is_raw ? Request.Type.RAW : Request.Type.JPEG,
                processType,
                force_suffix,
                suffix_offset,
                save_expo ? Request.SaveBase.SAVEBASE_ALL : Request.SaveBase.SAVEBASE_NONE,
                jpeg_images,
                raw_image,
                image_capture_intent, image_capture_intent_uri,
                using_camera2, using_camera_extensions,
                image_format, image_quality,
                do_auto_stabilise, level_angle, null,
                is_front_facing,
                mirror,
                current_date,
                preference_hdr_tonemapping_algorithm,
                preference_hdr_contrast_enhancement,
                iso,
                exposure_time,
                zoom_factor,
                preference_stamp, preference_textstamp, font_size, color, pref_style, preference_stamp_dateformat, preference_stamp_timeformat, preference_stamp_gpsformat,
                //preference_stamp_geo_address,
                preference_units_distance,
                panorama_crop, remove_device_exif, store_location, location, store_geo_direction, geo_direction,
                pitch_angle, store_ypr,
                custom_tag_artist,
                custom_tag_copyright,
                sample_factor);

        if( do_in_background ) {
            if( MyDebug.LOG )
                Log.d(TAG, "add background request");
            int cost = computeRequestCost(is_raw, is_raw ? 1 : request.jpeg_images.size());
            addRequest(request, cost);
            success = true; // always return true when done in background
        }
        else {
            // wait for queue to be empty
            waitUntilDone();
            if( is_raw ) {
                success = saveImageNowRaw(request);
            }
            else {
                success = saveImageNow(request);
            }
        }

        if( MyDebug.LOG )
            Log.d(TAG, "success: " + success);
        return success;
    }


    private void addRequest(Request request, int i) {
        Log.d(TAG, "addRequest, cost: " + i);
        if (Build.VERSION.SDK_INT>=17 && this.main_activity.isDestroyed()) {
            Log.e(TAG, "application is destroyed, image lost!");
            return;
        }
        boolean z = false;
        while (!z) {
            try {
                Log.d(TAG, "ImageSaver thread adding to queue, size: " + this.queue.size());
                synchronized (this) {
                    this.n_images_to_save++;
                    if (request.type != Request.Type.DUMMY) {
                        this.n_real_images_to_save++;
                    }
                    this.main_activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            ImageSaver.this.main_activity.imageQueueChanged();
                        }
                    });
                }
                if (this.queue.size() + 1>this.queue_capacity) {
                    Log.e(TAG, "ImageSaver thread is going to block, queue already full: " + this.queue.size());
                    this.test_queue_blocked = true;
                }
                this.queue.put(request);
                synchronized (this) {
                    Log.d(TAG, "ImageSaver thread added to queue, size is now: " + this.queue.size());
                    Log.d(TAG, "images still to save is now: " + this.n_images_to_save);
                    Log.d(TAG, "real images still to save is now: " + this.n_real_images_to_save);
                }
                z = true;
            } catch (InterruptedException e) {
                e.printStackTrace();
                Log.e(TAG, "interrupted while trying to add to ImageSaver queue");
            }
        }
        if (i>0) {
            for (int i2 = 0; i2<i - 1; i2++) {
                addDummyRequest();
            }
        }
    }

    private void addDummyRequest() {
//        Request request = new Request(Request.Type.DUMMY, Request.ProcessType.NORMAL, false, 0, Request.SaveBase.SAVEBASE_NONE, null, null, false, null, false, Request.ImageFormat.STD, 0, false, 0.0d, null, false, false, null, null, 0, 0L, 1.0f, null, null, 0, 0, null, null, null, null, null, null, false, false, null, false, 0.0d, 0.0d, false, null, null, 1);
//        Log.d(TAG, "add dummy request");
//        addRequest(request, 1);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void waitUntilDone() {
        Log.d(TAG, "waitUntilDone");
        synchronized (this) {
            Log.d(TAG, "waitUntilDone: queue is size " + this.queue.size());
            Log.d(TAG, "waitUntilDone: images still to save " + this.n_images_to_save);
            while (this.n_images_to_save>0) {
                Log.d(TAG, "wait until done...");
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    Log.e(TAG, "interrupted while waiting for ImageSaver queue to be empty");
                }
                Log.d(TAG, "waitUntilDone: queue is size " + this.queue.size());
                Log.d(TAG, "waitUntilDone: images still to save " + this.n_images_to_save);
            }
        }
        Log.d(TAG, "waitUntilDone: images all saved");
    }

    private void setBitmapOptionsSampleSize(BitmapFactory.Options options, int i) {
        Log.d(TAG, "setBitmapOptionsSampleSize: " + i);
        if (i>1) {
            options.inDensity = i;
            options.inTargetDensity = 1;
        }
    }

    private Bitmap loadBitmap(byte[] bArr, boolean z, int i) {
        Log.d(TAG, "loadBitmap");
        Log.d(TAG, "mutable?: " + z);
        BitmapFactory.Options options = new BitmapFactory.Options();
        Log.d(TAG, "options.inMutable is: " + options.inMutable);
        options.inMutable = z;
        setBitmapOptionsSampleSize(options, i);
        if (Build.VERSION.SDK_INT<=19) {
            options.inPurgeable = true;
        }
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(bArr, 0, bArr.length, options);
        if (decodeByteArray == null) {
            Log.e(TAG, "failed to decode bitmap");
        }
        return decodeByteArray;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes3.dex */
    public static class LoadBitmapThread extends Thread {
        Bitmap bitmap;
        final byte[] jpeg;
        final BitmapFactory.Options options;

        LoadBitmapThread(BitmapFactory.Options options, byte[] bArr) {
            this.options = options;
            this.jpeg = bArr;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            byte[] bArr = this.jpeg;
            this.bitmap = BitmapFactory.decodeByteArray(bArr, 0, bArr.length, this.options);
        }
    }

    private List<Bitmap> loadBitmaps(List<byte[]> list, int i, int i2) {
        Log.d(TAG, "mutable_id: " + i);
        BitmapFactory.Options options = new BitmapFactory.Options();
        boolean z = true;
        options.inMutable = true;
        setBitmapOptionsSampleSize(options, i2);
        BitmapFactory.Options options2 = new BitmapFactory.Options();
        options2.inMutable = false;
        setBitmapOptionsSampleSize(options2, i2);
        if (Build.VERSION.SDK_INT<=19) {
            options.inPurgeable = true;
            options2.inPurgeable = true;
        }
        LoadBitmapThread[] loadBitmapThreadArr = new LoadBitmapThread[list.size()];
        int i3 = 0;
        while (i3<list.size()) {
            loadBitmapThreadArr[i3] = new LoadBitmapThread(i3 == i ? options : options2, list.get(i3));
            i3++;
        }
        Log.d(TAG, "start threads");
        for (int i4 = 0; i4<list.size(); i4++) {
            loadBitmapThreadArr[i4].start();
        }
        Log.d(TAG, "wait for threads to complete");
        for (int i5 = 0; i5<list.size(); i5++) {
            try {
                loadBitmapThreadArr[i5].join();
            } catch (InterruptedException e) {
                Log.e(TAG, "threads interrupted");
                e.printStackTrace();
                z = false;
            }
        }
        Log.d(TAG, "threads completed");
        ArrayList arrayList = new ArrayList();
        for (int i6 = 0; i6<list.size() && z; i6++) {
            Bitmap bitmap = loadBitmapThreadArr[i6].bitmap;
            if (bitmap == null) {
                Log.e(TAG, "failed to decode bitmap in thread: " + i6);
                z = false;
            } else {
                Log.d(TAG, "bitmap " + i6 + ": " + bitmap + " is mutable? " + bitmap.isMutable());
            }
            arrayList.add(bitmap);
        }
        if (z) {
            return arrayList;
        }
        Log.d(TAG, "cleanup from failure");
        for (int i7 = 0; i7<list.size(); i7++) {
            if (loadBitmapThreadArr[i7].bitmap != null) {
                loadBitmapThreadArr[i7].bitmap.recycle();
                loadBitmapThreadArr[i7].bitmap = null;
            }
        }
        arrayList.clear();
        System.gc();
        return null;
    }

    public static float getHDRAlpha(String preference_hdr_contrast_enhancement, long exposure_time, int n_bitmaps) {
        boolean use_hdr_alpha;
        if( n_bitmaps == 1 ) {
            // DRO always applies hdr_alpha
            use_hdr_alpha = true;
        }
        else {
            // else HDR
            switch( preference_hdr_contrast_enhancement ) {
                case "preference_hdr_contrast_enhancement_off":
                    use_hdr_alpha = false;
                    break;
                case "preference_hdr_contrast_enhancement_smart":
                default:
                    // Using local contrast enhancement helps scenes where the dynamic range is very large, which tends to be when we choose
                    // a short exposure time, due to fixing problems where some regions are too dark.
                    // This helps: testHDR11, testHDR19, testHDR34, testHDR53, testHDR61.
                    // Using local contrast enhancement in all cases can increase noise in darker scenes. This problem would occur
                    // (if we used local contrast enhancement) is: testHDR2, testHDR12, testHDR17, testHDR43, testHDR50, testHDR51,
                    // testHDR54, testHDR55, testHDR56.
                    use_hdr_alpha = (exposure_time < 1000000000L/59);
                    break;
                case "preference_hdr_contrast_enhancement_always":
                    use_hdr_alpha = true;
                    break;
            }
        }
        //use_hdr_alpha = true; // test
        float hdr_alpha = use_hdr_alpha ? 0.5f : 0.0f;
        if( MyDebug.LOG ) {
            Log.d(TAG, "preference_hdr_contrast_enhancement: " + preference_hdr_contrast_enhancement);
            Log.d(TAG, "exposure_time: " + exposure_time);
            Log.d(TAG, "hdr_alpha: " + hdr_alpha);
        }
        return hdr_alpha;
    }

    private void writeGyroDebugXml(Writer writer, Request request) throws IOException {
        XmlSerializer newSerializer = Xml.newSerializer();
        newSerializer.setOutput(writer);
        char c = 1;
        newSerializer.startDocument("UTF-8", true);
        String str = null;
        newSerializer.startTag(null, gyro_info_doc_tag);
        newSerializer.attribute(null, gyro_info_panorama_pics_per_screen_tag, "" + MyApplicationInterface.getPanoramaPicsPerScreen());
        newSerializer.attribute(null, gyro_info_camera_view_angle_x_tag, "" + request.camera_view_angle_x);
        newSerializer.attribute(null, gyro_info_camera_view_angle_y_tag, "" + request.camera_view_angle_y);
        float[] fArr = new float[3];
        float[] fArr2 = new float[3];
        char c2 = 0;
        int i = 0;
        while (i<request.gyro_rotation_matrix.size()) {
            newSerializer.startTag(str, "image");
            newSerializer.attribute(str, "index", "" + i);
            GyroSensor.setVector(fArr, 1.0f, 0.0f, 0.0f);
            GyroSensor.transformVector(fArr2, request.gyro_rotation_matrix.get(i), fArr);
            newSerializer.startTag(str, gyro_info_vector_tag);
            newSerializer.attribute(str, "type", gyro_info_vector_right_type);
            newSerializer.attribute(str, "x", "" + fArr2[c2]);
            newSerializer.attribute(str, "y", "" + fArr2[c]);
            newSerializer.attribute(str, "z", "" + fArr2[2]);
            newSerializer.endTag(str, gyro_info_vector_tag);
            GyroSensor.setVector(fArr, 0.0f, 1.0f, 0.0f);
            GyroSensor.transformVector(fArr2, request.gyro_rotation_matrix.get(i), fArr);
            newSerializer.startTag(str, gyro_info_vector_tag);
            newSerializer.attribute(str, "type", gyro_info_vector_up_type);
            newSerializer.attribute(str, "x", "" + fArr2[0]);
            str = null;
            newSerializer.attribute(null, "y", "" + fArr2[1]);
            newSerializer.attribute(null, "z", "" + fArr2[2]);
            newSerializer.endTag(null, gyro_info_vector_tag);
            GyroSensor.setVector(fArr, 0.0f, 0.0f, -1.0f);
            GyroSensor.transformVector(fArr2, request.gyro_rotation_matrix.get(i), fArr);
            newSerializer.startTag(null, gyro_info_vector_tag);
            newSerializer.attribute(null, "type", gyro_info_vector_screen_type);
            newSerializer.attribute(null, "x", "" + fArr2[0]);
            newSerializer.attribute(null, "y", "" + fArr2[1]);
            newSerializer.attribute(null, "z", "" + fArr2[2]);
            newSerializer.endTag(null, gyro_info_vector_tag);
            newSerializer.endTag(null, "image");
            i++;
            c = 1;
            c2 = 0;
        }
        newSerializer.endTag(str, gyro_info_doc_tag);
        newSerializer.endDocument();
        newSerializer.flush();
    }

    public static boolean readGyroDebugXml(InputStream inputStream, GyroDebugInfo info) {
        try {
            XmlPullParser parser = Xml.newPullParser();
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(inputStream, null);
            parser.nextTag();

            parser.require(XmlPullParser.START_TAG, null, gyro_info_doc_tag);
            GyroDebugInfo.GyroImageDebugInfo image_info = null;

            while( parser.next() != XmlPullParser.END_DOCUMENT ) {
                switch( parser.getEventType() ) {
                    case XmlPullParser.START_TAG: {
                        String name = parser.getName();
                        if( MyDebug.LOG ) {
                            Log.d(TAG, "start tag, name: " + name);
                        }

                        switch( name ) {
                            case gyro_info_image_tag:
                                info.image_info.add( image_info = new GyroDebugInfo.GyroImageDebugInfo() );
                                break;
                            case gyro_info_vector_tag:
                                if( image_info == null ) {
                                    Log.e(TAG, "vector tag outside of image tag");
                                    return false;
                                }
                                String type = parser.getAttributeValue(null, "type");
                                String x_s = parser.getAttributeValue(null, "x");
                                String y_s = parser.getAttributeValue(null, "y");
                                String z_s = parser.getAttributeValue(null, "z");
                                float [] vector = new float[3];
                                vector[0] = Float.parseFloat(x_s);
                                vector[1] = Float.parseFloat(y_s);
                                vector[2] = Float.parseFloat(z_s);
                                switch( type ) {
                                    case gyro_info_vector_right_type:
                                        image_info.vectorRight = vector;
                                        break;
                                    case gyro_info_vector_up_type:
                                        image_info.vectorUp = vector;
                                        break;
                                    case gyro_info_vector_screen_type:
                                        image_info.vectorScreen = vector;
                                        break;
                                    default:
                                        Log.e(TAG, "unknown type in vector tag: " + type);
                                        return false;
                                }
                                break;
                        }
                        break;
                    }
                    case XmlPullParser.END_TAG: {
                        String name = parser.getName();
                        if( MyDebug.LOG ) {
                            Log.d(TAG, "end tag, name: " + name);
                        }

                        //noinspection SwitchStatementWithTooFewBranches
                        switch( name ) {
                            case gyro_info_image_tag:
                                image_info = null;
                                break;
                        }
                        break;
                    }
                }
            }
        }
        catch(Exception e) {
            e.printStackTrace();
            return false;
        }
        finally {
            try {
                inputStream.close();
            }
            catch(IOException e) {
                e.printStackTrace();
            }
        }
        return true;
    }


    private boolean saveImageNow(final Request request) {
        if( MyDebug.LOG )
            Log.d(TAG, "saveImageNow");

        if( request.type != Request.Type.JPEG ) {
            if( MyDebug.LOG )
                Log.d(TAG, "saveImageNow called with non-jpeg request");
            // throw runtime exception, as this is a programming error
            throw new RuntimeException();
        }
        else if( request.jpeg_images.size() == 0 ) {
            if( MyDebug.LOG )
                Log.d(TAG, "saveImageNow called with zero images");
            // throw runtime exception, as this is a programming error
            throw new RuntimeException();
        }

        boolean success;
        if( request.process_type == Request.ProcessType.AVERAGE ) {
            if( MyDebug.LOG )
                Log.d(TAG, "average");

            saveBaseImages(request, "_");
            main_activity.savingImage(true);

            /*List<Bitmap> bitmaps = loadBitmaps(request.jpeg_images, 0);
            if (bitmaps == null) {
                if (MyDebug.LOG)
                    Log.e(TAG, "failed to load bitmaps");
                main_activity.savingImage(false);
                return false;
            }*/
            /*Bitmap nr_bitmap = loadBitmap(request.jpeg_images.get(0), true);

            if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
                try {
                    for(int i = 1; i < request.jpeg_images.size(); i++) {
                        Log.d(TAG, "processAvg for image: " + i);
                        Bitmap new_bitmap = loadBitmap(request.jpeg_images.get(i), false);
                        float avg_factor = (float) i;
                        hdrProcessor.processAvg(nr_bitmap, new_bitmap, avg_factor, true);
                        // processAvg recycles new_bitmap
                    }
                    //hdrProcessor.processAvgMulti(bitmaps, hdr_strength, 4);
                    //hdrProcessor.avgBrighten(nr_bitmap);
                }
                catch(HDRProcessorException e) {
                    e.printStackTrace();
                    throw new RuntimeException();
                }
            }
            else {
                Log.e(TAG, "shouldn't have offered NoiseReduction as an option if not on Android 5");
                throw new RuntimeException();
            }*/
            Bitmap nr_bitmap;
            if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
                try {
                    long time_s = System.currentTimeMillis();
                    // initialise allocation from first two bitmaps
                    //int inSampleSize = hdrProcessor.getAvgSampleSize(request.jpeg_images.size());
                    int inSampleSize = hdrProcessor.getAvgSampleSize(request.iso, request.exposure_time);
                    //final boolean use_smp = false;
                    final boolean use_smp = true;
                    // n_smp_images is how many bitmaps to decompress at once if use_smp==true. Beware of setting too high -
                    // e.g., storing 4 16MP bitmaps takes 256MB of heap (NR requires at least 512MB large heap); also need to make
                    // sure there isn't a knock on effect on performance
                    //final int n_smp_images = 2;
                    final int n_smp_images = 4;
                    long this_time_s = System.currentTimeMillis();
                    List<Bitmap> bitmaps = null;
                    Bitmap bitmap0, bitmap1;
                    if( use_smp ) {
                        /*List<byte []> sub_jpeg_list = new ArrayList<>();
                        sub_jpeg_list.add(request.jpeg_images.get(0));
                        sub_jpeg_list.add(request.jpeg_images.get(1));
                        bitmaps = loadBitmaps(sub_jpeg_list, -1, inSampleSize);
                        bitmap0 = bitmaps.get(0);
                        bitmap1 = bitmaps.get(1);*/
                        int n_remaining = request.jpeg_images.size();
                        int n_load = Math.min(n_smp_images, n_remaining);
                        if( MyDebug.LOG ) {
                            Log.d(TAG, "n_remaining: " + n_remaining);
                            Log.d(TAG, "n_load: " + n_load);
                        }
                        List<byte []> sub_jpeg_list = new ArrayList<>();
                        for(int j=0;j<n_load;j++) {
                            sub_jpeg_list.add(request.jpeg_images.get(j));
                        }
                        bitmaps = loadBitmaps(sub_jpeg_list, -1, inSampleSize);
                        if( MyDebug.LOG )
                            Log.d(TAG, "length of bitmaps list is now: " + bitmaps.size());
                        bitmap0 = bitmaps.get(0);
                        bitmap1 = bitmaps.get(1);
                    }
                    else {
                        bitmap0 = loadBitmap(request.jpeg_images.get(0), false, inSampleSize);
                        bitmap1 = loadBitmap(request.jpeg_images.get(1), false, inSampleSize);
                    }
                    if( MyDebug.LOG ) {
                        Log.d(TAG, "*** time for loading first bitmaps: " + (System.currentTimeMillis() - this_time_s));
                    }
                    int width = bitmap0.getWidth();
                    int height = bitmap0.getHeight();
                    float avg_factor = 1.0f;
                    this_time_s = System.currentTimeMillis();
                    HDRProcessor.AvgData avg_data = hdrProcessor.processAvg(bitmap0, bitmap1, avg_factor, request.iso, request.exposure_time, request.zoom_factor);
                    if( bitmaps != null ) {
                        bitmaps.set(0, null);
                        bitmaps.set(1, null);
                    }
                    if( MyDebug.LOG ) {
                        Log.d(TAG, "*** time for processing first two bitmaps: " + (System.currentTimeMillis() - this_time_s));
                    }

                    for(int i=2;i<request.jpeg_images.size();i++) {
                        if( MyDebug.LOG )
                            Log.d(TAG, "processAvg for image: " + i);

                        this_time_s = System.currentTimeMillis();
                        Bitmap new_bitmap;
                        if( use_smp ) {
                            // check if we already loaded the bitmap
                            if( MyDebug.LOG )
                                Log.d(TAG, "length of bitmaps list: " + bitmaps.size());
                            if( i < bitmaps.size() ) {
                                if( MyDebug.LOG ) {
                                    Log.d(TAG, "already loaded bitmap from previous iteration with SMP");
                                }
                                new_bitmap = bitmaps.get(i);
                            }
                            else {
                                int n_remaining = request.jpeg_images.size() - i;
                                int n_load = Math.min(n_smp_images, n_remaining);
                                if( MyDebug.LOG ) {
                                    Log.d(TAG, "n_remaining: " + n_remaining);
                                    Log.d(TAG, "n_load: " + n_load);
                                }
                                List<byte []> sub_jpeg_list = new ArrayList<>();
                                for(int j=i;j<i+n_load;j++) {
                                    sub_jpeg_list.add(request.jpeg_images.get(j));
                                }
                                List<Bitmap> new_bitmaps = loadBitmaps(sub_jpeg_list, -1, inSampleSize);
                                bitmaps.addAll(new_bitmaps);
                                if( MyDebug.LOG )
                                    Log.d(TAG, "length of bitmaps list is now: " + bitmaps.size());
                                new_bitmap = bitmaps.get(i);
                            }
                        }
                        else {
                            new_bitmap = loadBitmap(request.jpeg_images.get(i), false, inSampleSize);
                        }
                        if( MyDebug.LOG ) {
                            Log.d(TAG, "*** time for loading extra bitmap: " + (System.currentTimeMillis() - this_time_s));
                        }
                        avg_factor = (float)i;
                        this_time_s = System.currentTimeMillis();
                        hdrProcessor.updateAvg(avg_data, width, height, new_bitmap, avg_factor, request.iso, request.exposure_time, request.zoom_factor);
                        // updateAvg recycles new_bitmap
                        if( bitmaps != null ) {
                            bitmaps.set(i, null);
                        }
                        if( MyDebug.LOG ) {
                            Log.d(TAG, "*** time for updating extra bitmap: " + (System.currentTimeMillis() - this_time_s));
                        }
                    }

                    this_time_s = System.currentTimeMillis();
                    nr_bitmap = hdrProcessor.avgBrighten(avg_data, width, height, request.iso, request.exposure_time);
                    if( MyDebug.LOG ) {
                        Log.d(TAG, "*** time for brighten: " + (System.currentTimeMillis() - this_time_s));
                    }
                    avg_data.destroy();
                    //noinspection UnusedAssignment
                    avg_data = null;
                    if( MyDebug.LOG ) {
                        Log.d(TAG, "*** total time for saving NR image: " + (System.currentTimeMillis() - time_s));
                    }
                }
                catch(HDRProcessorException e) {
                    e.printStackTrace();
                    throw new RuntimeException();
                }
            }
            else {
                Log.e(TAG, "shouldn't have offered NoiseReduction as an option if not on Android 5");
                throw new RuntimeException();
            }

            if( MyDebug.LOG )
                Log.d(TAG, "nr_bitmap: " + nr_bitmap + " is mutable? " + nr_bitmap.isMutable());
            System.gc();
            main_activity.savingImage(false);

            if( MyDebug.LOG )
                Log.d(TAG, "save NR image");
            success = saveSingleImageNow(request, request.jpeg_images.get(0), nr_bitmap, "_NR", true, true, true, false);
            if( MyDebug.LOG && !success )
                Log.e(TAG, "saveSingleImageNow failed for nr image");
            nr_bitmap.recycle();
            System.gc();
        }
        else if( request.process_type == Request.ProcessType.HDR ) {
            if( MyDebug.LOG )
                Log.d(TAG, "hdr");
            if( request.jpeg_images.size() != 1 && request.jpeg_images.size() != 3 ) {
                if( MyDebug.LOG )
                    Log.d(TAG, "saveImageNow expected either 1 or 3 images for hdr, not " + request.jpeg_images.size());
                // throw runtime exception, as this is a programming error
                throw new RuntimeException();
            }

            long time_s = System.currentTimeMillis();
            if( request.jpeg_images.size() > 1 ) {
                // if there's only 1 image, we're in DRO mode, and shouldn't save the base image
                // note that in earlier Open Camera versions, we used "_EXP" as the suffix. We now use just "_" from 1.42 onwards, so Google
                // Photos will group them together. (Unfortunately using "_EXP_" doesn't work, the images aren't grouped!)
                saveBaseImages(request, "_");
                if( MyDebug.LOG ) {
                    Log.d(TAG, "HDR performance: time after saving base exposures: " + (System.currentTimeMillis() - time_s));
                }
            }

            // note, even if we failed saving some of the expo images, still try to save the HDR image
            if( MyDebug.LOG )
                Log.d(TAG, "create HDR image");
            main_activity.savingImage(true);

            // see documentation for HDRProcessor.processHDR() - because we're using release_bitmaps==true, we need to make sure that
            // the bitmap that will hold the output HDR image is mutable (in case of options like photo stamp)
            // see test testTakePhotoHDRPhotoStamp.
            int base_bitmap = (request.jpeg_images.size()-1)/2;
            if( MyDebug.LOG )
                Log.d(TAG, "base_bitmap: " + base_bitmap);
            List<Bitmap> bitmaps = loadBitmaps(request.jpeg_images, base_bitmap, 1);
            if( bitmaps == null ) {
                if( MyDebug.LOG )
                    Log.e(TAG, "failed to load bitmaps");
                main_activity.savingImage(false);
                return false;
            }
            if( MyDebug.LOG ) {
                Log.d(TAG, "HDR performance: time after decompressing base exposures: " + (System.currentTimeMillis() - time_s));
            }
            float hdr_alpha = getHDRAlpha(request.preference_hdr_contrast_enhancement, request.exposure_time, bitmaps.size());
            if( MyDebug.LOG )
                Log.d(TAG, "before HDR first bitmap: " + bitmaps.get(0) + " is mutable? " + bitmaps.get(0).isMutable());
            try {
                if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
                    hdrProcessor.processHDR(bitmaps, true, null, true, null, hdr_alpha, 4, true, request.preference_hdr_tonemapping_algorithm, HDRProcessor.DROTonemappingAlgorithm.DROALGORITHM_GAINGAMMA); // this will recycle all the bitmaps except bitmaps.get(0), which will contain the hdr image
                }
                else {
                    Log.e(TAG, "shouldn't have offered HDR as an option if not on Android 5");
                    throw new RuntimeException();
                }
            }
            catch(HDRProcessorException e) {
                Log.e(TAG, "HDRProcessorException from processHDR: " + e.getCode());
                e.printStackTrace();
                if( e.getCode() == HDRProcessorException.UNEQUAL_SIZES ) {
                    // this can happen on OnePlus 3T with old camera API with front camera, seems to be a bug that resolution changes when exposure compensation is set!
                    main_activity.getPreview().showToast(null, R.string.failed_to_process_hdr);
                    Log.e(TAG, "UNEQUAL_SIZES");
                    bitmaps.clear();
                    System.gc();
                    main_activity.savingImage(false);
                    return false;
                }
                else {
                    // throw RuntimeException, as we shouldn't ever get the error INVALID_N_IMAGES, if we do it's a programming error
                    throw new RuntimeException();
                }
            }
            if( MyDebug.LOG ) {
                Log.d(TAG, "HDR performance: time after creating HDR image: " + (System.currentTimeMillis() - time_s));
            }
            if( MyDebug.LOG )
                Log.d(TAG, "after HDR first bitmap: " + bitmaps.get(0) + " is mutable? " + bitmaps.get(0).isMutable());
            Bitmap hdr_bitmap = bitmaps.get(0);
            if( MyDebug.LOG )
                Log.d(TAG, "hdr_bitmap: " + hdr_bitmap + " is mutable? " + hdr_bitmap.isMutable());
            bitmaps.clear();
            System.gc();
            main_activity.savingImage(false);

            if( MyDebug.LOG )
                Log.d(TAG, "save HDR image");
            int base_image_id = ((request.jpeg_images.size()-1)/2);
            if( MyDebug.LOG )
                Log.d(TAG, "base_image_id: " + base_image_id);
            String suffix = request.jpeg_images.size() == 1 ? "_DRO" : "_HDR";
            success = saveSingleImageNow(request, request.jpeg_images.get(base_image_id), hdr_bitmap, suffix, true, true, true, false);
            if( MyDebug.LOG && !success )
                Log.e(TAG, "saveSingleImageNow failed for hdr image");
            if( MyDebug.LOG ) {
                Log.d(TAG, "HDR performance: time after saving HDR image: " + (System.currentTimeMillis() - time_s));
            }
            hdr_bitmap.recycle();
            System.gc();
        }
        else if( request.process_type == Request.ProcessType.PANORAMA ) {
            if( MyDebug.LOG )
                Log.d(TAG, "panorama");

            // save text file with gyro info
            if( !request.image_capture_intent && request.save_base == Request.SaveBase.SAVEBASE_ALL_PLUS_DEBUG ) {
                /*final StringBuilder gyro_text = new StringBuilder();
                gyro_text.append("Panorama gyro debug info\n");
                gyro_text.append("n images: " + request.gyro_rotation_matrix.size() + ":\n");

                float [] inVector = new float[3];
                float [] outVector = new float[3];
                for(int i=0;i<request.gyro_rotation_matrix.size();i++) {
                    gyro_text.append("Image " + i + ":\n");

                    GyroSensor.setVector(inVector, 1.0f, 0.0f, 0.0f); // vector pointing in "right" direction
                    GyroSensor.transformVector(outVector, request.gyro_rotation_matrix.get(i), inVector);
                    gyro_text.append("    X: " + outVector[0] + " , " + outVector[1] + " , " + outVector[2] + "\n");

                    GyroSensor.setVector(inVector, 0.0f, 1.0f, 0.0f); // vector pointing in "up" direction
                    GyroSensor.transformVector(outVector, request.gyro_rotation_matrix.get(i), inVector);
                    gyro_text.append("    Y: " + outVector[0] + " , " + outVector[1] + " , " + outVector[2] + "\n");

                    GyroSensor.setVector(inVector, 0.0f, 0.0f, -1.0f); // vector pointing behind the device's screen
                    GyroSensor.transformVector(outVector, request.gyro_rotation_matrix.get(i), inVector);
                    gyro_text.append("    -Z: " + outVector[0] + " , " + outVector[1] + " , " + outVector[2] + "\n");

                }*/

                try {
                    StringWriter writer = new StringWriter();

                    writeGyroDebugXml(writer, request);

                    StorageUtils storageUtils = main_activity.getStorageUtils();
                    /*File saveFile = null;
                    Uri saveUri = null;
                    if( storageUtils.isUsingSAF() ) {
                        saveUri = storageUtils.createOutputMediaFileSAF(StorageUtils.MEDIA_TYPE_GYRO_INFO, "", "xml", request.current_date);
                    }
                    else {
                        saveFile = storageUtils.createOutputMediaFile(StorageUtils.MEDIA_TYPE_GYRO_INFO, "", "xml", request.current_date);
                        if( MyDebug.LOG )
                            Log.d(TAG, "save to: " + saveFile.getAbsolutePath());
                    }*/
                    // We save to the application specific folder so this works on Android 10 with scoped storage, without having to
                    // rewrite the non-SAF codepath to use MediaStore API (which would also have problems that the gyro debug files would
                    // show up in the MediaStore, hence gallery applications!)
                    // We use this for older Android versions for consistency, plus not a bad idea of to have debug files in the application
                    // folder anyway.
                    File saveFile = storageUtils.createOutputMediaFile(main_activity.getExternalFilesDir(null), StorageUtils.MEDIA_TYPE_GYRO_INFO, "", "xml", request.current_date);
                    Uri saveUri = null;
                    if( MyDebug.LOG )
                        Log.d(TAG, "save to: " + saveFile.getAbsolutePath());

                    OutputStream outputStream;
                    if( saveFile != null )
                        outputStream = new FileOutputStream(saveFile);
                    else
                        outputStream = main_activity.getContentResolver().openOutputStream(saveUri);
                    try {
                        //outputStream.write(gyro_text.toString().getBytes());
                        //noinspection CharsetObjectCanBeUsed
                        outputStream.write(writer.toString().getBytes(Charset.forName("UTF-8")));
                    }
                    finally {
                        outputStream.close();
                    }

                    if( saveFile != null ) {
                        storageUtils.broadcastFile(saveFile, false, false, false, false, null);
                    }
                    else {
                        broadcastSAFFile(saveUri, false, false, false);
                    }
                }
                catch(IOException e) {
                    Log.e(TAG, "failed to write gyro text file");
                    e.printStackTrace();
                }
            }

            // for now, just save all the images:
            //String suffix = "_";
            //success = saveImages(request, suffix, false, true, true);

            saveBaseImages(request, "_");

            main_activity.savingImage(true);

            long time_s = System.currentTimeMillis();

            if( MyDebug.LOG )
                Log.d(TAG, "panorama_dir_left_to_right: " + request.panorama_dir_left_to_right);
            if( !request.panorama_dir_left_to_right ) {
                Collections.reverse(request.jpeg_images);
                // shouldn't use gyro_rotation_matrix from this point, but keep in sync with jpeg_images just in case
                Collections.reverse(request.gyro_rotation_matrix);
            }

            List<Bitmap> bitmaps = loadBitmaps(request.jpeg_images, -1, 1);
            if( bitmaps == null ) {
                if( MyDebug.LOG )
                    Log.e(TAG, "failed to load bitmaps");
                main_activity.savingImage(false);
                return false;
            }
            if( MyDebug.LOG ) {
                Log.d(TAG, "panorama performance: time after decompressing base exposures: " + (System.currentTimeMillis() - time_s));
            }

            // rotate the bitmaps if necessary for exif tags
            for(int i=0;i<bitmaps.size();i++) {
                Bitmap bitmap = bitmaps.get(i);
                bitmap = rotateForExif(bitmap, request.jpeg_images.get(0));
                bitmaps.set(i, bitmap);
            }
            if( MyDebug.LOG ) {
                Log.d(TAG, "panorama performance: time after rotating for exif: " + (System.currentTimeMillis() - time_s));
            }

            Bitmap panorama;
            try {
                if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
                    panorama = panoramaProcessor.panorama(bitmaps, MyApplicationInterface.getPanoramaPicsPerScreen(), request.camera_view_angle_y, request.panorama_crop);
                }
                else {
                    Log.e(TAG, "shouldn't have offered panorama as an option if not on Android 5");
                    throw new RuntimeException();
                }
            }
            catch(PanoramaProcessorException e) {
                Log.e(TAG, "PanoramaProcessorException from panorama: " + e.getCode());
                e.printStackTrace();
                if( e.getCode() == PanoramaProcessorException.UNEQUAL_SIZES || e.getCode() == PanoramaProcessorException.FAILED_TO_CROP ) {
                    main_activity.getPreview().showToast(null, R.string.failed_to_process_panorama);
                    Log.e(TAG, "panorama failed: " + e.getCode());
                    bitmaps.clear();
                    System.gc();
                    main_activity.savingImage(false);
                    return false;
                }
                else {
                    // throw RuntimeException, as we shouldn't ever get the error INVALID_N_IMAGES, if we do it's a programming error
                    throw new RuntimeException();
                }
            }
            if( MyDebug.LOG ) {
                Log.d(TAG, "panorama performance: time after creating panorama image: " + (System.currentTimeMillis() - time_s));
            }
            if( MyDebug.LOG )
                Log.d(TAG, "panorama: " + panorama);
            bitmaps.clear();
            System.gc();

            main_activity.savingImage(false);

            if( MyDebug.LOG )
                Log.d(TAG, "save panorama image");
            success = saveSingleImageNow(request, request.jpeg_images.get(0), panorama, "_PANO", true, true, true, true);
            if( MyDebug.LOG && !success )
                Log.e(TAG, "saveSingleImageNow failed for panorama image");
            panorama.recycle();
            System.gc();
        }
        else {
            // see note above how we used to use "_EXP" for the suffix for multiple images
            //String suffix = "_EXP";
            String suffix = "_";
            success = saveImages(request, suffix, false, true, true);
        }

        return success;
    }
    private void broadcastSAFFile(Uri saveUri, boolean set_last_scanned, boolean hasnoexifdatetime, boolean image_capture_intent) {
        if( MyDebug.LOG )
            Log.d(TAG, "broadcastSAFFile");
        StorageUtils storageUtils = main_activity.getStorageUtils();
        storageUtils.broadcastUri(saveUri, true, false, set_last_scanned, hasnoexifdatetime, image_capture_intent);
    }

    private boolean saveImages(Request request, String str, boolean z, boolean z2, boolean z3) {
        String str2;
        int size = request.jpeg_images.size() / 2;
        int i = 0;
        boolean z4 = true;
        while (i<request.jpeg_images.size()) {
            byte[] bArr = request.jpeg_images.get(i);
            if ((request.jpeg_images.size()>1 && !z) || request.force_suffix) {
                str2 = str + (request.suffix_offset + i);
            } else {
                str2 = "";
            }
            if (!saveSingleImageNow(request, bArr, null, str2, z2, z3 && i == size, false, false)) {
                Log.e(TAG, "saveSingleImageNow failed for image: " + i);
                z4 = false;
            }
            if (z) {
                break;
            }
            i++;
        }
        return z4;
    }

    private void saveBaseImages(Request request, String str) {
        Log.d(TAG, "saveBaseImages");
        if (request.image_capture_intent || request.save_base == Request.SaveBase.SAVEBASE_NONE) {
            return;
        }
        Log.d(TAG, "save base images");
        if (request.process_type == Request.ProcessType.PANORAMA) {
            request = request.copy();
            request.image_format = Request.ImageFormat.PNG;
            request.preference_stamp = "preference_stamp_no";
            request.preference_textstamp = "";
            request.do_auto_stabilise = false;
            request.mirror = false;
        } else if (request.process_type == Request.ProcessType.AVERAGE) {
            request = request.copy();
            request.image_quality = 100;
        }
        Request request2 = request;
        saveImages(request2, str, request2.save_base == Request.SaveBase.SAVEBASE_FIRST, false, false);
    }

    public static boolean autoStabiliseCrop(int[] iArr, double d, double d2, double d3, int i, int i2, int i3, int i4) {
        iArr[0] = 0;
        iArr[1] = 0;
        double tan = Math.tan(d);
        double sin = Math.sin(d);
        double d4 = (d3 / d2) + tan;
        double d5 = (d2 / d3) + tan;
        if (d4 == 0.0d || d4<1.0E-14d) {
            Log.d(TAG, "zero denominator?!");
            return false;
        } else if (d5 == 0.0d || d5<1.0E-14d) {
            Log.d(TAG, "zero alt denominator?!");
            return false;
        } else {
            int i5 = (int) (((d3 + (((i2 * 2.0d) * sin) * tan)) - (d2 * tan)) / d4);
            int i6 = (int) ((i5 * d3) / d2);
            int i7 = (int) (((d2 + (((i * 2.0d) * sin) * tan)) - (tan * d3)) / d5);
            int i8 = (int) ((i7 * d2) / d3);
            Log.d(TAG, "w2 = " + i5 + " , h2 = " + i6);
            Log.d(TAG, "alt_w2 = " + i8 + " , alt_h2 = " + i7);
            if (i8<i5) {
                Log.d(TAG, "chose alt!");
                i6 = i7;
                i5 = i8;
            }
            if (i5<=0) {
                i5 = 1;
            } else if (i5>i3) {
                i5 = i3;
            }
            if (i6<=0) {
                i6 = 1;
            } else if (i6>i4) {
                i6 = i4;
            }
            iArr[0] = i5;
            iArr[1] = i6;
            return true;
        }
    }

    private Bitmap autoStabilise(byte [] data, Bitmap bitmap, double level_angle, boolean is_front_facing) {
        if( MyDebug.LOG ) {
            Log.d(TAG, "autoStabilise");
            Log.d(TAG, "level_angle: " + level_angle);
            Log.d(TAG, "is_front_facing: " + is_front_facing);
        }
        while( level_angle < -90 )
            level_angle += 180;
        while( level_angle > 90 )
            level_angle -= 180;
        if( MyDebug.LOG )
            Log.d(TAG, "auto stabilising... angle: " + level_angle);
        if( bitmap == null ) {
            if( MyDebug.LOG )
                Log.d(TAG, "need to decode bitmap to auto-stabilise");
            // bitmap doesn't need to be mutable here, as this won't be the final bitmap returned from the auto-stabilise code
            bitmap = loadBitmapWithRotation(data, false);
            if( bitmap == null ) {
                main_activity.getPreview().showToast(null, R.string.failed_to_auto_stabilise);
                System.gc();
            }
        }
        if( bitmap != null ) {
            int width = bitmap.getWidth();
            int height = bitmap.getHeight();
            if( MyDebug.LOG ) {
                Log.d(TAG, "level_angle: " + level_angle);
                Log.d(TAG, "decoded bitmap size " + width + ", " + height);
                Log.d(TAG, "bitmap size: " + width*height*4);
            }
                /*for(int y=0;y<height;y++) {
                    for(int x=0;x<width;x++) {
                        int col = bitmap.getPixel(x, y);
                        col = col & 0xffff0000; // mask out red component
                        bitmap.setPixel(x, y, col);
                    }
                }*/
            Matrix matrix = new Matrix();
            double level_angle_rad_abs = Math.abs( Math.toRadians(level_angle) );
            int w1 = width, h1 = height;
            double w0 = (w1 * Math.cos(level_angle_rad_abs) + h1 * Math.sin(level_angle_rad_abs));
            double h0 = (w1 * Math.sin(level_angle_rad_abs) + h1 * Math.cos(level_angle_rad_abs));
            // apply a scale so that the overall image size isn't increased
            float orig_size = w1*h1;
            float rotated_size = (float)(w0*h0);
            float scale = (float)Math.sqrt(orig_size/rotated_size);
            if( main_activity.test_low_memory ) {
                if( MyDebug.LOG ) {
                    Log.d(TAG, "TESTING LOW MEMORY");
                    Log.d(TAG, "scale was: " + scale);
                }
                // test 20MP on Galaxy Nexus or Nexus 7; 29MP on Nexus 6 and 36MP OnePlus 3T
                if( width*height >= 7500 )
                    scale *= 1.5f;
                else
                    scale *= 2.0f;
            }
            if( MyDebug.LOG ) {
                Log.d(TAG, "w0 = " + w0 + " , h0 = " + h0);
                Log.d(TAG, "w1 = " + w1 + " , h1 = " + h1);
                Log.d(TAG, "scale = sqrt " + orig_size + " / " + rotated_size + " = " + scale);
            }
            matrix.postScale(scale, scale);
            w0 *= scale;
            h0 *= scale;
            w1 *= scale;
            h1 *= scale;
            if( MyDebug.LOG ) {
                Log.d(TAG, "after scaling: w0 = " + w0 + " , h0 = " + h0);
                Log.d(TAG, "after scaling: w1 = " + w1 + " , h1 = " + h1);
            }
            if( is_front_facing ) {
                matrix.postRotate((float)-level_angle);
            }
            else {
                matrix.postRotate((float)level_angle);
            }
            Bitmap new_bitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
            // careful, as new_bitmap is sometimes not a copy!
            if( new_bitmap != bitmap ) {
                bitmap.recycle();
                bitmap = new_bitmap;
            }
            System.gc();
            if( MyDebug.LOG ) {
                Log.d(TAG, "rotated and scaled bitmap size " + bitmap.getWidth() + ", " + bitmap.getHeight());
                Log.d(TAG, "rotated and scaled bitmap size: " + bitmap.getWidth()*bitmap.getHeight()*4);
            }

            int [] crop = new int [2];
            if( autoStabiliseCrop(crop, level_angle_rad_abs, w0, h0, w1, h1, bitmap.getWidth(), bitmap.getHeight()) ) {
                int w2 = crop[0];
                int h2 = crop[1];
                int x0 = (bitmap.getWidth()-w2)/2;
                int y0 = (bitmap.getHeight()-h2)/2;
                if( MyDebug.LOG ) {
                    Log.d(TAG, "x0 = " + x0 + " , y0 = " + y0);
                }
                new_bitmap = Bitmap.createBitmap(bitmap, x0, y0, w2, h2);
                if( new_bitmap != bitmap ) {
                    bitmap.recycle();
                    bitmap = new_bitmap;
                }
                System.gc();
            }

            if( MyDebug.LOG )
                Log.d(TAG, "bitmap is mutable?: " + bitmap.isMutable());
            // Usually createBitmap will return a mutable bitmap, but not if the source bitmap (which we set as immutable)
            // is returned (if the level angle is (tolerantly) 0.
            // see testPhotoStamp() for testing this.
            if( !bitmap.isMutable() ) {
                new_bitmap = bitmap.copy(bitmap.getConfig(), true);
                bitmap.recycle();
                bitmap = new_bitmap;
            }
        }
        return bitmap;
    }

    private Bitmap mirrorImage(byte[] bArr, Bitmap bitmap) {
        Log.d(TAG, "mirrorImage");
        if (bitmap == null) {
            Log.d(TAG, "need to decode bitmap to mirror");
            bitmap = loadBitmapWithRotation(bArr, false);
            if (bitmap == null) {
                System.gc();
            }
        }
        if (bitmap != null) {
            Matrix matrix = new Matrix();
            matrix.preScale(-1.0f, 1.0f);
            Bitmap createBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
            if (createBitmap != bitmap) {
                bitmap.recycle();
                bitmap = createBitmap;
            }
            Log.d(TAG, "bitmap is mutable?: " + bitmap.isMutable());
        }
        return bitmap;
    }

    private Bitmap stampImage(Request request, byte[] bArr, Bitmap bitmap) {
        Log.d(TAG, "stampImage");
        MyApplicationInterface applicationInterface = this.main_activity.getApplicationInterface();
        if (bitmap == null) {
            Log.d(TAG, "decode bitmap in order to stamp info");
            bitmap = loadBitmapWithRotation(bArr, true);
            if (bitmap == null) {
                this.main_activity.getPreview().showToast((ToastBoxer) null, R.string.failed_to_stamp);
                System.gc();
            }
        }
        if (bitmap != null) {
            applicationInterface.capturedStampBitmap(request, new Canvas(bitmap), new Paint(1), bitmap);
        }
        applicationInterface.orginalImage = null;
        return bitmap;
    }


    public static class PostProcessBitmapResult {
        final Bitmap bitmap;

        PostProcessBitmapResult(Bitmap bitmap) {
            this.bitmap = bitmap;
        }
    }

    private PostProcessBitmapResult postProcessBitmap(Request request, byte[] bArr, Bitmap bitmap, boolean z) throws IOException {
        Bitmap bitmap2 = bitmap;
        Log.d(TAG, "postProcessBitmap");
        long currentTimeMillis = System.currentTimeMillis();
        boolean equals = request.preference_stamp.equals("preference_stamp_yes");
        boolean z2 = request.preference_textstamp.length()>0;
        if ((bitmap2 != null || request.image_format != Request.ImageFormat.STD || request.do_auto_stabilise || request.mirror || equals || z2) && !z && bitmap2 != null) {
            Log.d(TAG, "rotate pre-existing bitmap for exif tags?");
            bitmap2 = rotateForExif(bitmap2, bArr);
        }
        Bitmap bitmap3 = bitmap2;
        if (request.do_auto_stabilise) {
            bitmap3 = autoStabilise(bArr, bitmap3, request.level_angle, request.is_front_facing);
        }
        Log.d(TAG, "Save single image performance: time after auto-stabilise: " + (System.currentTimeMillis() - currentTimeMillis));
        if (request.mirror) {
            bitmap3 = mirrorImage(bArr, bitmap3);
        }
        if (request.image_format != Request.ImageFormat.STD && bitmap3 == null) {
            Log.d(TAG, "need to decode bitmap to convert file format");
            bitmap3 = loadBitmapWithRotation(bArr, true);
            if (bitmap3 == null) {
                System.gc();
                throw new IOException();
            }
        }
        Bitmap stampImage = stampImage(request, bArr, bitmap3);
        Log.d(TAG, "Save single image performance: time after photostamp: " + (System.currentTimeMillis() - currentTimeMillis));
        return new PostProcessBitmapResult(stampImage);
    }


    @SuppressLint("SimpleDateFormat")
    private boolean saveSingleImageNow(final Request request, byte [] data, Bitmap bitmap, String filename_suffix, boolean update_thumbnail, boolean share_image, boolean ignore_raw_only, boolean ignore_exif_orientation) {
        if( MyDebug.LOG )
            Log.d(TAG, "saveSingleImageNow");

        if( request.type != Request.Type.JPEG ) {
            if( MyDebug.LOG )
                Log.d(TAG, "saveImageNow called with non-jpeg request");
            // throw runtime exception, as this is a programming error
            throw new RuntimeException();
        }
        else if( data == null ) {
            if( MyDebug.LOG )
                Log.d(TAG, "saveSingleImageNow called with no data");
            // throw runtime exception, as this is a programming error
            throw new RuntimeException();
        }
        long time_s = System.currentTimeMillis();

        boolean success = false;
        final MyApplicationInterface applicationInterface = main_activity.getApplicationInterface();
        boolean raw_only = !ignore_raw_only && applicationInterface.isRawOnly();
        if( MyDebug.LOG )
            Log.d(TAG, "raw_only: " + raw_only);
        StorageUtils storageUtils = main_activity.getStorageUtils();

        String extension;
        switch( request.image_format ) {
            case WEBP:
                extension = "webp";
                break;
            case PNG:
                extension = "png";
                break;
            default:
                extension = "jpg";
                break;
        }
        if( MyDebug.LOG )
            Log.d(TAG, "extension: " + extension);

        main_activity.savingImage(true);

        // If using SAF or image_capture_intent is true, or using scoped storage, only saveUri is non-null
        // Otherwise, only picFile is non-null
        File picFile = null;
        Uri saveUri = null;
        boolean use_media_store = false;
        ContentValues contentValues = null; // used if using scoped storage
        try {
            if( !raw_only ) {
                PostProcessBitmapResult postProcessBitmapResult = postProcessBitmap(request, data, bitmap, ignore_exif_orientation);
                bitmap = postProcessBitmapResult.bitmap;
            }

            if( raw_only ) {
                // don't save the JPEG
                success = true;
            }
            else if( request.image_capture_intent ) {
                if( MyDebug.LOG )
                    Log.d(TAG, "image_capture_intent");
                if( request.image_capture_intent_uri != null )
                {
                    // Save the bitmap to the specified URI (use a try/catch block)
                    if( MyDebug.LOG )
                        Log.d(TAG, "save to: " + request.image_capture_intent_uri);
                    saveUri = request.image_capture_intent_uri;
                }
                else
                {
                    // If the intent doesn't contain an URI, send the bitmap as a parcel
                    // (it is a good idea to reduce its size to ~50k pixels before)
                    if( MyDebug.LOG )
                        Log.d(TAG, "sent to intent via parcel");
                    if( bitmap == null ) {
                        if( MyDebug.LOG )
                            Log.d(TAG, "create bitmap");
                        // bitmap we return doesn't need to be mutable
                        bitmap = loadBitmapWithRotation(data, false);
                    }
                    if( bitmap != null ) {
                        int width = bitmap.getWidth();
                        int height = bitmap.getHeight();
                        if( MyDebug.LOG ) {
                            Log.d(TAG, "decoded bitmap size " + width + ", " + height);
                            Log.d(TAG, "bitmap size: " + width*height*4);
                        }
                        final int small_size_c = 128;
                        if( width > small_size_c ) {
                            float scale = ((float)small_size_c)/(float)width;
                            if( MyDebug.LOG )
                                Log.d(TAG, "scale to " + scale);
                            Matrix matrix = new Matrix();
                            matrix.postScale(scale, scale);
                            Bitmap new_bitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
                            // careful, as new_bitmap is sometimes not a copy!
                            if( new_bitmap != bitmap ) {
                                bitmap.recycle();
                                bitmap = new_bitmap;
                            }
                        }
                    }
                    if( MyDebug.LOG ) {
                        if( bitmap != null ) {
                            Log.d(TAG, "returned bitmap size " + bitmap.getWidth() + ", " + bitmap.getHeight());
                            Log.d(TAG, "returned bitmap size: " + bitmap.getWidth()*bitmap.getHeight()*4);
                        }
                        else {
                            Log.e(TAG, "no bitmap created");
                        }
                    }
                    if( bitmap != null )
                        main_activity.setResult(Activity.RESULT_OK, new Intent("inline-data").putExtra("data", bitmap));
                    main_activity.finish();
                }
            }
            else if( storageUtils.isUsingSAF() ) {
                saveUri = storageUtils.createOutputMediaFileSAF(StorageUtils.MEDIA_TYPE_IMAGE, filename_suffix, extension, request.current_date);
            }
            else if( CameraMainActivity.useScopedStorage() ) {
                if( MyDebug.LOG )
                    Log.d(TAG, "use media store");
                use_media_store = true;
                Uri folder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ?
                        MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) :
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                contentValues = new ContentValues();
                String picName = storageUtils.createMediaFilename(StorageUtils.MEDIA_TYPE_IMAGE, filename_suffix, 0, "." + extension, request.current_date);
                if( MyDebug.LOG )
                    Log.d(TAG, "picName: " + picName);
                contentValues.put(MediaStore.Images.Media.DISPLAY_NAME, picName);
                String mime_type = storageUtils.getImageMimeType(extension);
                if( MyDebug.LOG )
                    Log.d(TAG, "mime_type: " + mime_type);
                contentValues.put(MediaStore.Images.Media.MIME_TYPE, mime_type);
                if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ) {
                    String relative_path = storageUtils.getSaveRelativeFolder();
                    if( MyDebug.LOG )
                        Log.d(TAG, "relative_path: " + relative_path);
                    contentValues.put(MediaStore.Images.Media.RELATIVE_PATH, relative_path);
                    contentValues.put(MediaStore.Images.Media.IS_PENDING, 1);
                }

                // Note, we catch exceptions specific to insert() here and rethrow as IOException,
                // rather than catching below, to avoid catching things too broadly - e.g.,
                // IllegalStateException can also be thrown via "new Canvas" (from
                // postProcessBitmap()) but this is a programming error that we shouldn't catch.
                // Catching too broadly could mean we miss genuine problems that should be fixed.
                try {
                    saveUri = main_activity.getContentResolver().insert(folder, contentValues);
                }
                catch(IllegalArgumentException e) {
                    // can happen for mediastore method if invalid ContentResolver.insert() call
                    if( MyDebug.LOG )
                        Log.e(TAG, "IllegalArgumentException inserting to mediastore: " + e.getMessage());
                    e.printStackTrace();
                    throw new IOException();
                }
                catch(IllegalStateException e) {
                    // have received Google Play crashes from ContentResolver.insert() call for mediastore method
                    if( MyDebug.LOG )
                        Log.e(TAG, "IllegalStateException inserting to mediastore: " + e.getMessage());
                    e.printStackTrace();
                    throw new IOException();
                }
                if( MyDebug.LOG )
                    Log.d(TAG, "saveUri: " + saveUri);
                if( saveUri == null ) {
                    throw new IOException();
                }
            }
            else {
                picFile = storageUtils.createOutputMediaFile(StorageUtils.MEDIA_TYPE_IMAGE, filename_suffix, extension, request.current_date);
                if( MyDebug.LOG )
                    Log.d(TAG, "save to: " + picFile.getAbsolutePath());
            }

            if( MyDebug.LOG )
                Log.d(TAG, "saveUri: " + saveUri);

            if( picFile != null || saveUri != null ) {
                OutputStream outputStream;
                if( picFile != null )
                    outputStream = new FileOutputStream(picFile);
                else
                    outputStream = main_activity.getContentResolver().openOutputStream(saveUri);
                try {
                    if( bitmap != null ) {
                        if( MyDebug.LOG )
                            Log.d(TAG, "compress bitmap, quality " + request.image_quality);
                        Bitmap.CompressFormat compress_format;
                        switch( request.image_format ) {
                            case WEBP:
                                compress_format = Bitmap.CompressFormat.WEBP;
                                break;
                            case PNG:
                                compress_format = Bitmap.CompressFormat.PNG;
                                break;
                            default:
                                compress_format = Bitmap.CompressFormat.JPEG;
                                break;
                        }
                        bitmap.compress(compress_format, request.image_quality, outputStream);
                    }
                    else {
                        outputStream.write(data);
                    }
                }
                finally {
                    outputStream.close();
                }
                if( MyDebug.LOG )
                    Log.d(TAG, "saveImageNow saved photo");
                if( MyDebug.LOG ) {
                    Log.d(TAG, "Save single image performance: time after saving photo: " + (System.currentTimeMillis() - time_s));
                }

                if( saveUri == null ) { // if saveUri is non-null, then we haven't succeeded until we've copied to the saveUri
                    success = true;
                }

                if( request.image_format == Request.ImageFormat.STD ) {
                    // handle transferring/setting Exif tags (JPEG format only)
                    if( bitmap != null ) {
                        // need to update EXIF data! (only supported for JPEG image formats)
                        if( MyDebug.LOG )
                            Log.d(TAG, "set Exif tags from data");
                        if( picFile != null ) {
                            setExifFromData(request, data, picFile);
                        }
                        else {
                            ParcelFileDescriptor parcelFileDescriptor = main_activity.getContentResolver().openFileDescriptor(saveUri, "rw");
                            try {
                                if( parcelFileDescriptor != null ) {
                                    FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
                                    setExifFromData(request, data, fileDescriptor);
                                }
                                else {
                                    Log.e(TAG, "failed to create ParcelFileDescriptor for saveUri: " + saveUri);
                                }
                            }
                            finally {
                                if( parcelFileDescriptor != null ) {
                                    try {
                                        parcelFileDescriptor.close();
                                    }
                                    catch(IOException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        }
                    }
                    else {
                        updateExif(request, picFile, saveUri);
                        if( MyDebug.LOG ) {
                            Log.d(TAG, "Save single image performance: time after updateExif: " + (System.currentTimeMillis() - time_s));
                        }
                    }
                }

                if( update_thumbnail ) {
                    // clear just in case we're unable to update this - don't want an out of date cached uri
                    storageUtils.clearLastMediaScanned();
                }

                boolean hasnoexifdatetime = request.remove_device_exif != Request.RemoveDeviceExif.OFF && request.remove_device_exif != Request.RemoveDeviceExif.KEEP_DATETIME;

                if( picFile != null && saveUri == null ) {
                    // broadcast for SAF is done later, when we've actually written out the file
                    storageUtils.broadcastFile(picFile, true, false, update_thumbnail, hasnoexifdatetime, null);
                    main_activity.test_last_saved_image = picFile.getAbsolutePath();
                }

                if( request.image_capture_intent ) {
                    if( MyDebug.LOG )
                        Log.d(TAG, "finish activity due to being called from intent");
                    main_activity.setResult(Activity.RESULT_OK);
                    main_activity.finish();
                }

                if( saveUri != null ) {
                    success = true;

                    if( use_media_store ) {
                        if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ) {
                            contentValues.clear();
                            contentValues.put(MediaStore.Images.Media.IS_PENDING, 0);
                            main_activity.getContentResolver().update(saveUri, contentValues, null, null);
                        }

                        // no need to broadcast when using mediastore method
                        if( !request.image_capture_intent ) {
                            if( MyDebug.LOG )
                                Log.d(TAG, "announce mediastore uri");
                            // in theory this is pointless, as announceUri no longer does anything on Android 7+,
                            // and mediastore method is only used on Android 10+, but keep this just in case
                            // announceUri does something in future
                            storageUtils.announceUri(saveUri, true, false);
                            if( update_thumbnail ) {
                                // we also want to save the uri - we can use the media uri directly, rather than having to scan it
                                storageUtils.setLastMediaScanned(saveUri, false, hasnoexifdatetime, saveUri);
                            }
                        }
                    }
                    else {
                        broadcastSAFFile(saveUri, update_thumbnail, hasnoexifdatetime, request.image_capture_intent);
                    }

                    main_activity.test_last_saved_imageuri = saveUri;
                }
            }
        }
        catch(FileNotFoundException e) {
            if( MyDebug.LOG )
                Log.e(TAG, "File not found: " + e.getMessage());
            e.printStackTrace();
            main_activity.getPreview().showToast(null, R.string.failed_to_save_photo);
        }
        catch(IOException e) {
            if( MyDebug.LOG )
                Log.e(TAG, "I/O error writing file: " + e.getMessage());
            e.printStackTrace();
            main_activity.getPreview().showToast(null, R.string.failed_to_save_photo);
        }
        catch(SecurityException e) {
            // received security exception from copyFileToUri()->openOutputStream() from Google Play
            // update: no longer have copyFileToUri() (as no longer use temporary files for SAF), but might as well keep this
            if( MyDebug.LOG )
                Log.e(TAG, "security exception writing file: " + e.getMessage());
            e.printStackTrace();
            main_activity.getPreview().showToast(null, R.string.failed_to_save_photo);
        }

        if( raw_only ) {
            // no saved image to record
        }
        else if( success && saveUri == null ) {
            applicationInterface.addLastImage(picFile, share_image);
        }
        else if( success && storageUtils.isUsingSAF() ){
            applicationInterface.addLastImageSAF(saveUri, share_image);
        }
        else if( success && use_media_store ){
            applicationInterface.addLastImageMediaStore(saveUri, share_image);
        }

        // I have received crashes where camera_controller was null - could perhaps happen if this thread was running just as the camera is closing?
        if( success && main_activity.getPreview().getCameraController() != null && update_thumbnail ) {
            // update thumbnail - this should be done after restarting preview, so that the preview is started asap
            CameraController.Size size = main_activity.getPreview().getCameraController().getPictureSize();
            int ratio = (int) Math.ceil((double) size.width / main_activity.getPreview().getView().getWidth());
            int sample_size = Integer.highestOneBit(ratio);
            sample_size *= request.sample_factor;
            if( MyDebug.LOG ) {
                Log.d(TAG, "    picture width: " + size.width);
                Log.d(TAG, "    preview width: " + main_activity.getPreview().getView().getWidth());
                Log.d(TAG, "    ratio        : " + ratio);
                Log.d(TAG, "    sample_size  : " + sample_size);
            }
            Bitmap thumbnail;
            if( bitmap == null ) {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inMutable = false;
                if( Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT ) {
                    // setting is ignored in Android 5 onwards
                    options.inPurgeable = true;
                }
                options.inSampleSize = sample_size;
                thumbnail = BitmapFactory.decodeByteArray(data, 0, data.length, options);
                if( MyDebug.LOG ) {
                    Log.d(TAG, "thumbnail width: " + thumbnail.getWidth());
                    Log.d(TAG, "thumbnail height: " + thumbnail.getHeight());
                }
                // now get the rotation from the Exif data
                if( MyDebug.LOG )
                    Log.d(TAG, "rotate thumbnail for exif tags?");
                thumbnail = rotateForExif(thumbnail, data);
            }
            else {
                int width = bitmap.getWidth();
                int height = bitmap.getHeight();
                Matrix matrix = new Matrix();
                float scale = 1.0f / (float)sample_size;
                matrix.postScale(scale, scale);
                if( MyDebug.LOG )
                    Log.d(TAG, "    scale: " + scale);
                try {
                    thumbnail = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
                    if( MyDebug.LOG ) {
                        Log.d(TAG, "thumbnail width: " + thumbnail.getWidth());
                        Log.d(TAG, "thumbnail height: " + thumbnail.getHeight());
                    }
                    // don't need to rotate for exif, as we already did that when creating the bitmap
                }
                catch(IllegalArgumentException e) {
                    // received IllegalArgumentException on Google Play from Bitmap.createBitmap; documentation suggests this
                    // means width or height are 0 - but trapping that didn't fix the problem
                    // or "the x, y, width, height values are outside of the dimensions of the source bitmap", but that can't be
                    // true here
                    // crashes seem to all be Android 7.1 or earlier, so maybe this is a bug that's been fixed - but catch it anyway
                    // as it's grown popular
                    Log.e(TAG, "can't create thumbnail bitmap due to IllegalArgumentException?!");
                    e.printStackTrace();
                    thumbnail = null;
                }
            }
            if( thumbnail == null ) {
                // received crashes on Google Play suggesting that thumbnail could not be created
                if( MyDebug.LOG )
                    Log.e(TAG, "failed to create thumbnail bitmap");
            }
            else {
                final Bitmap thumbnail_f = thumbnail;
                main_activity.runOnUiThread(new Runnable() {
                    public void run() {
                        applicationInterface.updateThumbnail(thumbnail_f, false);
                    }
                });
                if( MyDebug.LOG ) {
                    Log.d(TAG, "Save single image performance: time after creating thumbnail: " + (System.currentTimeMillis() - time_s));
                }
            }
        }

        if( bitmap != null ) {
            bitmap.recycle();
        }

        System.gc();

        main_activity.savingImage(false);

        if( MyDebug.LOG ) {
            Log.d(TAG, "Save single image performance: total time: " + (System.currentTimeMillis() - time_s));
        }
        return success;
    }



    public static class AnonymousClass4 {
        static final int[] $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$ImageSaver$Request$ImageFormat;
        static final int[] $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$ImageSaver$Request$Type;

        static {
            int[] iArr = new int[Request.ImageFormat.values().length];
            $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$ImageSaver$Request$ImageFormat = iArr;
            try {
                iArr[Request.ImageFormat.WEBP.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$ImageSaver$Request$ImageFormat[Request.ImageFormat.PNG.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            int[] iArr2 = new int[Request.Type.values().length];
            $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$ImageSaver$Request$Type = iArr2;
            try {
                iArr2[Request.Type.RAW.ordinal()] = 1;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$ImageSaver$Request$Type[Request.Type.JPEG.ordinal()] = 2;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$ImageSaver$Request$Type[Request.Type.DUMMY.ordinal()] = 3;
            } catch (NoSuchFieldError unused5) {
            }
        }
    }

    private void setExifFromData(Request request, byte[] bArr, File file) throws IOException {
        ByteArrayInputStream byteArrayInputStream;
        Log.d(TAG, "setExifFromData");
        Log.d(TAG, "to_file: " + file);
        ByteArrayInputStream byteArrayInputStream2 = null;
        byteArrayInputStream = new ByteArrayInputStream(bArr);

        try {
            setExif(request, new ExifInterface(byteArrayInputStream), new ExifInterface(file.getAbsolutePath()));
            byteArrayInputStream.close();
        } catch (Throwable th2) {
            byteArrayInputStream2 = byteArrayInputStream;
            if (byteArrayInputStream2 != null) {
                byteArrayInputStream2.close();
            }
            th2.printStackTrace();
        }
    }

    private void broadcastSAFFile(Uri uri, boolean z) {
        Log.d(TAG, "broadcastSAFFile");
        this.main_activity.getStorageUtils().broadcastUri(uri, true, false, true, z);
    }

    private void setExifFromData(Request request, byte[] bArr, FileDescriptor fileDescriptor) throws IOException {
        ByteArrayInputStream byteArrayInputStream;
        Log.d(TAG, "setExifFromData");
        Log.d(TAG, "to_file_descriptor: " + fileDescriptor);
        ByteArrayInputStream byteArrayInputStream2 = null;
        byteArrayInputStream = new ByteArrayInputStream(bArr);
        try {
            setExif(request, new ExifInterface(byteArrayInputStream), new ExifInterface(fileDescriptor));
            byteArrayInputStream.close();
        } catch (Throwable th2) {
            byteArrayInputStream2 = byteArrayInputStream;
            if (byteArrayInputStream2 != null) {
                byteArrayInputStream2.close();
            }
            throw th2;
        }
    }

    private void setExif(Request imageSaver$Request0, ExifInterface exifInterface0, ExifInterface exifInterface1) throws IOException {
        ExifInterface exifInterface2 = exifInterface1;
        SP sP0 = new SP(this.main_activity);
        String s = sP0.getString(this.main_activity, "latitude_1", "");
        String s1 = sP0.getString(this.main_activity, "longitude_1", "");
        Log.d("ImageSaver", "setExif");
        Log.d("ImageSaver", "read back EXIF data");
        String s2 = exifInterface0.getAttribute("FNumber");
        String s3 = exifInterface0.getAttribute("DateTime");
        String s4 = exifInterface0.getAttribute("ExposureTime");
        String s5 = exifInterface0.getAttribute("Flash");
        String s6 = exifInterface0.getAttribute("FocalLength");
        String s7 = s1;
        String s8 = exifInterface0.getAttribute("GPSAltitude");
        String s9 = s;
        String s10 = exifInterface0.getAttribute("GPSAltitudeRef");
        String s11 = exifInterface0.getAttribute("GPSDateStamp");
        String s12 = exifInterface0.getAttribute("GPSLatitude");
        String s13 = exifInterface0.getAttribute("GPSLatitudeRef");
        String s14 = exifInterface0.getAttribute("GPSLongitude");
        String s15 = exifInterface0.getAttribute("GPSLongitudeRef");
        String s16 = exifInterface0.getAttribute("GPSProcessingMethod");
        String s17 = exifInterface0.getAttribute("GPSTimeStamp");
        String s18 = exifInterface0.getAttribute("ISOSpeedRatings");
        String s19 = exifInterface0.getAttribute("Make");
        String s20 = exifInterface0.getAttribute("Model");
        String s21 = exifInterface0.getAttribute("WhiteBalance");
        String s22 = exifInterface0.getAttribute("DateTimeDigitized");
        String s23 = exifInterface0.getAttribute("SubSecTime");
        String s24 = exifInterface0.getAttribute("SubSecTimeDigitized");
        String s25 = exifInterface0.getAttribute("SubSecTimeOriginal");
        String s26 = exifInterface0.getAttribute("ApertureValue");
        String s27 = exifInterface0.getAttribute("BrightnessValue");
        String s28 = exifInterface0.getAttribute("CFAPattern");
        String s29 = exifInterface0.getAttribute("ColorSpace");
        String s30 = exifInterface0.getAttribute("ComponentsConfiguration");
        String s31 = exifInterface0.getAttribute("CompressedBitsPerPixel");
        String s32 = exifInterface0.getAttribute("Compression");
        String s33 = exifInterface0.getAttribute("Contrast");
        String s34 = exifInterface0.getAttribute("DateTimeOriginal");
        String s35 = exifInterface0.getAttribute("DeviceSettingDescription");
        String s36 = exifInterface0.getAttribute("DigitalZoomRatio");
        String s37 = exifInterface0.getAttribute("ExposureBiasValue");
        String s38 = exifInterface0.getAttribute("ExposureIndex");
        String s39 = exifInterface0.getAttribute("ExposureMode");
        String s40 = exifInterface0.getAttribute("ExposureProgram");
        String s41 = exifInterface0.getAttribute("FlashEnergy");
        String s42 = exifInterface0.getAttribute("FocalLengthIn35mmFilm");
        String s43 = exifInterface0.getAttribute("FocalPlaneResolutionUnit");
        String s44 = exifInterface0.getAttribute("FocalPlaneXResolution");
        String s45 = exifInterface0.getAttribute("FocalPlaneYResolution");
        String s46 = exifInterface0.getAttribute("GainControl");
        String s47 = exifInterface0.getAttribute("GPSAreaInformation");
        String s48 = exifInterface0.getAttribute("GPSDifferential");
        String s49 = exifInterface0.getAttribute("GPSDOP");
        String s50 = exifInterface0.getAttribute("GPSMeasureMode");
        String s51 = exifInterface0.getAttribute("ImageDescription");
        String s52 = exifInterface0.getAttribute("LightSource");
        String s53 = exifInterface0.getAttribute("MakerNote");
        String s54 = exifInterface0.getAttribute("MaxApertureValue");
        String s55 = exifInterface0.getAttribute("MeteringMode");
        String s56 = exifInterface0.getAttribute("OECF");
        String s57 = exifInterface0.getAttribute("PhotometricInterpretation");
        String s58 = exifInterface0.getAttribute("Saturation");
        String s59 = exifInterface0.getAttribute("SceneCaptureType");
        String s60 = exifInterface0.getAttribute("SceneType");
        String s61 = exifInterface0.getAttribute("SensingMethod");
        String s62 = exifInterface0.getAttribute("Sharpness");
        String s63 = exifInterface0.getAttribute("ShutterSpeedValue");
        String s64 = exifInterface0.getAttribute("Software");
        String s65 = exifInterface0.getAttribute("UserComment");
        Log.d("ImageSaver", "now write new EXIF data");
        if (s2 != null) {
            exifInterface2.setAttribute("FNumber", s2);
        }

        if (s3 != null) {
            exifInterface2.setAttribute("DateTime", s3);
        }

        if (s4 != null) {
            exifInterface2.setAttribute("ExposureTime", s4);
        }

        if (s5 != null) {
            exifInterface2.setAttribute("Flash", s5);
        }

        if (s6 != null) {
            exifInterface2.setAttribute("FocalLength", s6);
        }

        if (s8 != null) {
            exifInterface2.setAttribute("GPSAltitude", s8);
        }

        if (s10 != null) {
            exifInterface2.setAttribute("GPSAltitudeRef", s10);
        }

        if (s11 != null) {
            exifInterface2.setAttribute("GPSDateStamp", s11);
        }

        if (s16 != null) {
            exifInterface2.setAttribute("GPSProcessingMethod", s16);
        }

        if (s17 != null) {
            exifInterface2.setAttribute("GPSTimeStamp", s17);
        }

        if (s18 != null) {
            exifInterface2.setAttribute("ISOSpeedRatings", s18);
        }

        if (s19 != null) {
            exifInterface2.setAttribute("Make", s19);
        }

        if (s20 != null) {
            exifInterface2.setAttribute("Model", s20 + " :: Captured by - GPS Map Camera");
        }

        if (s21 != null) {
            exifInterface2.setAttribute("WhiteBalance", s21);
        }

        if (s9 != null && !s9.isEmpty() && s7 != null && !s7.isEmpty() && (NetworkState.Companion.isOnline(this.main_activity))) {
            exifInterface2.setAttribute("GPSLatitude", GPS.convert(Double.parseDouble(s9)));
            exifInterface2.setAttribute("GPSLongitude", GPS.convert(Double.parseDouble(s7)));
            exifInterface2.setAttribute("GPSLatitudeRef", GPS.latitudeRef(Double.parseDouble(s9)));
            exifInterface2.setAttribute("GPSLongitudeRef", GPS.longitudeRef(Double.parseDouble(s7)));
        } else {
            if (s12 != null) {
                exifInterface2.setAttribute("GPSLatitude", s12);
            }

            if (s13 != null) {
                exifInterface2.setAttribute("GPSLatitudeRef", s13);
            }

            if (s14 != null) {
                exifInterface2.setAttribute("GPSLongitude", s14);
            }

            if (s15 != null) {
                exifInterface2.setAttribute("GPSLongitudeRef", s15);
            }
        }

        if (s22 != null) {
            exifInterface2.setAttribute("DateTimeDigitized", s22);
        }

        if (s23 != null) {
            exifInterface2.setAttribute("SubSecTime", s23);
        }

        if (s24 != null) {
            exifInterface2.setAttribute("SubSecTimeDigitized", s24);
        }

        if (s25 != null) {
            exifInterface2.setAttribute("SubSecTimeOriginal", s25);
        }

        if (s26 != null) {
            exifInterface2.setAttribute("ApertureValue", s26);
        }

        if (s27 != null) {
            exifInterface2.setAttribute("BrightnessValue", s27);
        }

        if (s28 != null) {
            exifInterface2.setAttribute("CFAPattern", s28);
        }

        if (s29 != null) {
            exifInterface2.setAttribute("ColorSpace", s29);
        }

        if (s30 != null) {
            exifInterface2.setAttribute("ComponentsConfiguration", s30);
        }

        if (s31 != null) {
            exifInterface2.setAttribute("CompressedBitsPerPixel", s31);
        }

        if (s32 != null) {
            exifInterface2.setAttribute("Compression", s32);
        }

        if (s33 != null) {
            exifInterface2.setAttribute("Contrast", s33);
        }

        if (s34 != null) {
            exifInterface2.setAttribute("DateTimeOriginal", s34);
        }

        if (s35 != null) {
            exifInterface2.setAttribute("DeviceSettingDescription", s35);
        }

        if (s36 != null) {
            exifInterface2.setAttribute("DigitalZoomRatio", s36);
        }

        if (s37 != null) {
            exifInterface2.setAttribute("ExposureBiasValue", s37);
        }

        if (s38 != null) {
            exifInterface2.setAttribute("ExposureIndex", s38);
        }

        if (s39 != null) {
            exifInterface2.setAttribute("ExposureMode", s39);
        }

        if (s40 != null) {
            exifInterface2.setAttribute("ExposureProgram", s40);
        }

        if (s41 != null) {
            exifInterface2.setAttribute("FlashEnergy", s41);
        }

        if (s42 != null) {
            exifInterface2.setAttribute("FocalLengthIn35mmFilm", s42);
        }

        if (s43 != null) {
            exifInterface2.setAttribute("FocalPlaneResolutionUnit", s43);
        }

        if (s44 != null) {
            exifInterface2.setAttribute("FocalPlaneXResolution", s44);
        }

        if (s45 != null) {
            exifInterface2.setAttribute("FocalPlaneYResolution", s45);
        }

        if (s46 != null) {
            exifInterface2.setAttribute("GainControl", s46);
        }

        if (s47 != null) {
            exifInterface2.setAttribute("GPSAreaInformation", s47);
        }

        if (s48 != null) {
            exifInterface2.setAttribute("GPSDifferential", s48);
        }

        if (s49 != null) {
            exifInterface2.setAttribute("GPSDOP", s49);
        }

        if (s50 != null) {
            exifInterface2.setAttribute("GPSMeasureMode", s50);
        }

        if (s51 != null) {
            exifInterface2.setAttribute("ImageDescription", s51);
        }

        if (s52 != null) {
            exifInterface2.setAttribute("LightSource", s52);
        }

        if (s53 != null) {
            exifInterface2.setAttribute("MakerNote", s53);
        }

        if (s54 != null) {
            exifInterface2.setAttribute("MaxApertureValue", s54);
        }

        if (s55 != null) {
            exifInterface2.setAttribute("MeteringMode", s55);
        }

        if (s56 != null) {
            exifInterface2.setAttribute("OECF", s56);
        }

        if (s57 != null) {
            exifInterface2.setAttribute("PhotometricInterpretation", s57);
        }

        if (s58 != null) {
            exifInterface2.setAttribute("Saturation", s58);
        }

        if (s59 != null) {
            exifInterface2.setAttribute("SceneCaptureType", s59);
        }

        if (s60 != null) {
            exifInterface2.setAttribute("SceneType", s60);
        }

        if (s61 != null) {
            exifInterface2.setAttribute("SensingMethod", s61);
        }

        if (s62 != null) {
            exifInterface2.setAttribute("Sharpness", s62);
        }

        if (s63 != null) {
            exifInterface2.setAttribute("ShutterSpeedValue", s63);
        }

        if (s64 != null) {
            exifInterface2.setAttribute("Software", s64);
        }

        if (s65 != null) {
            exifInterface2.setAttribute("UserComment", s65);
        }
        int vvv = imageSaver$Request0.type == Request.Type.JPEG ? 1 : 0;
        boolean vvb = true;
        if (vvv == 0) {
            vvb = false;
        }

        this.modifyExif(exifInterface1,         // exifInterface0:androidx.exifinterface.media.ExifInterface
                vvb, // z:boolean
                imageSaver$Request0.using_camera2, // z1:boolean
                imageSaver$Request0.current_date, // date0:java.util.Date
                imageSaver$Request0.store_location, // z2:boolean
                imageSaver$Request0.store_geo_direction, // z3:boolean
                imageSaver$Request0.geo_direction, // f:double
                imageSaver$Request0.custom_tag_artist, // s:java.lang.String
                imageSaver$Request0.custom_tag_copyright, // s1:java.lang.String
                imageSaver$Request0.level_angle, // f1:double
                imageSaver$Request0.pitch_angle, // f2:double
                imageSaver$Request0.store_ypr // z4:boolean
        );
        this.setDateTimeExif(exifInterface1);
        exifInterface1.saveAttributes();
    }


    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
//    private boolean saveImageNowRaw(Request imageSaver$Request0) {
//        Throwable throwable3;
//        FileOutputStream fileOutputStream1;
//        File file0 = null;
//        ContentValues contentValues0 = null;
//        int v = 0;
//        String s3 = null;
//        Uri uri1 = null;
//        FileOutputStream fileOutputStream0 = null;
//        ImageSaver imageSaver0 = this;
//        Request imageSaver$Request1 = imageSaver$Request0;
//        Log.d("ImageSaver", "saveImageNowRaw");
//        if (Build.VERSION.SDK_INT<21) {
//            Log.e("ImageSaver", "RAW requires LOLLIPOP or higher");
//            return false;
//        }
//
//        StorageUtils storageUtils0 = imageSaver0.main_activity.getStorageUtils();
//        boolean z = true;
//        imageSaver0.main_activity.savingImage(true);
//        RawImage rawImage0 = imageSaver$Request1.raw_image;
//        try {
//            String s = imageSaver$Request1.force_suffix ? "_" + imageSaver$Request1.suffix_offset : "";
//            String s1 = s;
//            System.out.println("FileName          " + s1);
//            boolean z1 = storageUtils0.isUsingSAF();
//            String s2 = "";
//            if (z1) {
//                Uri uri0 = storageUtils0.createOutputMediaFileSAF(1, s1, "dng", imageSaver$Request1.current_date);
//                Log.d("ImageSaver", "saveUri: " + uri0);
//                uri1 = uri0;
//                s3 = s2;
//                v = 0;
//                contentValues0 = null;
//                file0 = null;
//            } else {
//                if (MainActivity.useScopedStorage()) {
//                    Uri uri2 = Build.VERSION.SDK_INT<29 ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.getContentUri("external_primary");
//                    contentValues0 = new ContentValues();
//                    Uri uri3 = uri2;
//                    String s4 = s2;
//                    contentValues0.put("_display_name", storageUtils0.createMediaFilename(1, s1, 0, ".dng", imageSaver$Request1.current_date));
//                    contentValues0.put("mime_type", "image/dng");
//                    if (Build.VERSION.SDK_INT>=29) {
//                        contentValues0.put("relative_path", storageUtils0.getSaveRelativeFolder());
//                        s3 = s4;
//                        contentValues0.put(s3, Integer.valueOf(1));
//                    } else {
//                        s3 = s4;
//                    }
//
//                    Uri uri4 = imageSaver0.main_activity.getContentResolver().insert(uri3, contentValues0);
//                    Log.d("ImageSaver", "saveUri: " + uri4);
//                    if (uri4 != null) {
//                        uri1 = uri4;
//                        v = 1;
//                        file0 = null;
////                        label_159:
//                        fileOutputStream0 = file0 == null ? (FileOutputStream) imageSaver0.main_activity.getContentResolver().openOutputStream(uri1) : new FileOutputStream(file0);
//                    }
//
//                    throw new IOException();
//                }
//                s3 = s2;
//                File file1 = storageUtils0.createOutputMediaFile(1, s1, "dng", imageSaver$Request1.current_date);
//                Log.d("ImageSaver", "save to: " + file1.getAbsolutePath());
//                file0 = file1;
//                v = 0;
//                uri1 = null;
//                contentValues0 = null;
//
//            }
//        } catch (FileNotFoundException fileNotFoundException0) {
//            z = false;
//            Log.e("ImageSaver", "File not found: " + fileNotFoundException0.getMessage());
//            fileNotFoundException0.printStackTrace();
//            imageSaver0.main_activity.getPreview().showToast(null, R.string.failed_to_save_photo_raw);
//            return false;// string:failed_to_save_photo_raw "Failed to save RAW photo"
//        } catch (IOException iOException0) {
//            Log.e("ImageSaver", "ioexception writing raw image file");
//            iOException0.printStackTrace();
//            imageSaver0.main_activity.getPreview().showToast(null, R.string.failed_to_save_photo_raw);
//            return false;
//        } catch (Throwable throwable0) {
//            throwable3 = throwable0;
//            fileOutputStream1 = null;
//            label_320:
//            if (fileOutputStream1 != null) {
//                try {
//                    fileOutputStream1.close();
//                    if (rawImage0 != null) {
//                        rawImage0.close();
//                    }
//                } catch (IOException iOException3) {
//                    Log.e("ImageSaver", "ioexception closing raw output");
//                    iOException3.printStackTrace();
//                }
//            }
//
//        }
//
//        try {
//            rawImage0.writeImage(fileOutputStream0);
//            rawImage0.close();
//            fileOutputStream0.close();
//            MyApplicationInterface myApplicationInterface0 = imageSaver0.main_activity.getApplicationInterface();
//            boolean z2 = myApplicationInterface0.isRawOnly();
//            Log.d("ImageSaver", "raw_only: " + z2);
//            if (uri1 == null) {
//                myApplicationInterface0.addLastImage(file0, z2);
//            } else if (storageUtils0.isUsingSAF()) {
//                myApplicationInterface0.addLastImageSAF(uri1, z2);
//            } else if (v != 0) {
//                myApplicationInterface0.addLastImageMediaStore(uri1, z2);
//            }
//
//            if (uri1 == null) {
//                storageUtils0.broadcastFile(file0, true, false, false);
//            } else if (v == 0) {
//                storageUtils0.broadcastUri(uri1, true, false, false, false);
//            } else {
//                if (Build.VERSION.SDK_INT>=29) {
//                    contentValues0.clear();
//                    contentValues0.put(s3, Integer.valueOf(0));
//                    imageSaver0.main_activity.getContentResolver().update(uri1, contentValues0, null, null);
//                }
//
//                storageUtils0.announceUri(uri1, true, false);
//            }
//        } catch (FileNotFoundException fileNotFoundException0) {
//            z = false;
//            Log.e("ImageSaver", "File not found: " + fileNotFoundException0.getMessage());
//            fileNotFoundException0.printStackTrace();
//            imageSaver0.main_activity.getPreview().showToast(null, R.string.failed_to_save_photo_raw);
//            return false;// string:failed_to_save_photo_raw "Failed to save RAW photo"
//        } catch (IOException iOException0) {
//            Log.e("ImageSaver", "ioexception writing raw image file");
//            iOException0.printStackTrace();
//            imageSaver0.main_activity.getPreview().showToast(null, R.string.failed_to_save_photo_raw);
//            return false;
//        }
//        return true;
//    }


    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private boolean saveImageNowRaw(Request request) {
        if (MyDebug.LOG)
            Log.d(TAG, "saveImageNowRaw");

        if (Build.VERSION.SDK_INT<Build.VERSION_CODES.LOLLIPOP) {
            if (MyDebug.LOG)
                Log.e(TAG, "RAW requires LOLLIPOP or higher");
            return false;
        }
        StorageUtils storageUtils = main_activity.getStorageUtils();
        boolean success = false;

        main_activity.savingImage(true);

        OutputStream output = null;
        RawImage raw_image = request.raw_image;
        try {
            File picFile = null;
            Uri saveUri = null;

            if (storageUtils.isUsingSAF()) {
                saveUri = storageUtils.createOutputMediaFileSAF(StorageUtils.MEDIA_TYPE_IMAGE, "_" + request.suffix_offset
                        , "dng", request.current_date);
                if (MyDebug.LOG)
                    Log.d(TAG, "saveUri: " + saveUri);
                // When using SAF, we don't save to a temp file first (unlike for JPEGs). Firstly we don't need to modify Exif, so don't
                // need a real file; secondly copying to a temp file is much slower for RAW.
            } else {
                picFile = storageUtils.createOutputMediaFile(StorageUtils.MEDIA_TYPE_IMAGE, "_" + request.suffix_offset
                        , "dng", request.current_date);
                if (MyDebug.LOG)
                    Log.d(TAG, "save to: " + picFile.getAbsolutePath());
            }

            if (picFile != null) {
                output = new FileOutputStream(picFile);
            } else {
                output = main_activity.getContentResolver().openOutputStream(saveUri);
            }
            raw_image.writeImage(output);
            raw_image.close();
            raw_image = null;
            output.close();
            output = null;
            success = true;

    		/*Location location = null;
    		if( main_activity.getApplicationInterface().getGeotaggingPref() ) {
    			location = main_activity.getApplicationInterface().getLocation();
	    		if( MyDebug.LOG )
	    			Log.d(TAG, "location: " + location);
    		}*/

            // set last image for share/trash options for pause preview
            // Must be done before broadcastFile() (because on Android 7+ with non-SAF, we update
            // the LastImage's uri from the MediaScannerConnection.scanFile() callback from
            // StorageUtils.broadcastFile(), which assumes the last image has already been set.
            MyApplicationInterface applicationInterface = main_activity.getApplicationInterface();
            boolean raw_only = applicationInterface.isRawOnly();
            if (MyDebug.LOG)
                Log.d(TAG, "raw_only: " + raw_only);
            if (saveUri == null) {
                applicationInterface.addLastImage(picFile, raw_only);
            } else if (storageUtils.isUsingSAF()) {
                applicationInterface.addLastImageSAF(saveUri, raw_only);
            }

            if (saveUri == null) {
                //Uri media_uri = storageUtils.broadcastFileRaw(picFile, current_date, location);
                //storageUtils.announceUri(media_uri, true, false);
                storageUtils.broadcastFile(picFile, true, false, false);
            } else {
                File real_file = storageUtils.getFileFromDocumentUriSAF(saveUri, false);
                if (MyDebug.LOG)
                    Log.d(TAG, "real_file: " + real_file);
                if (real_file != null) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "broadcast file");
                    //Uri media_uri = storageUtils.broadcastFileRaw(real_file, current_date, location);
                    //storageUtils.announceUri(media_uri, true, false);
                    storageUtils.broadcastFile(real_file, true, false, false);
                } else {
                    if (MyDebug.LOG)
                        Log.d(TAG, "announce SAF uri");
                    storageUtils.announceUri(saveUri, true, false);
                }
            }
        } catch (FileNotFoundException e) {
            if (MyDebug.LOG)
                Log.e(TAG, "File not found: " + e.getMessage());
            e.printStackTrace();
            main_activity.getPreview().showToast(null, R.string.failed_to_save_photo_raw);
        } catch (IOException e) {
            if (MyDebug.LOG)
                Log.e(TAG, "ioexception writing raw image file");
            e.printStackTrace();
            main_activity.getPreview().showToast(null, R.string.failed_to_save_photo_raw);
        } finally {
            if (output != null) {
                try {
                    output.close();
                } catch (IOException e) {
                    if (MyDebug.LOG)
                        Log.e(TAG, "ioexception closing raw output");
                    e.printStackTrace();
                }
            }
            if (raw_image != null) {
                raw_image.close();
            }
        }

        System.gc();

        main_activity.savingImage(false);

        return success;
    }

    private Bitmap rotateForExif(Bitmap bitmap, byte [] data) {
        if( MyDebug.LOG )
            Log.d(TAG, "rotateForExif");
        InputStream inputStream = null;
        try {
            ExifInterface exif;

            if( MyDebug.LOG )
                Log.d(TAG, "use data stream to read exif tags");
            inputStream = new ByteArrayInputStream(data);
            exif = new ExifInterface(inputStream);

            int exif_orientation_s = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);
            if( MyDebug.LOG )
                Log.d(TAG, "    exif orientation string: " + exif_orientation_s);
            boolean needs_tf = false;
            int exif_orientation = 0;
            // see http://jpegclub.org/exif_orientation.html
            // and http://stackoverflow.com/questions/20478765/how-to-get-the-correct-orientation-of-the-image-selected-from-the-default-image
            switch (exif_orientation_s) {
                case ExifInterface.ORIENTATION_UNDEFINED:
                case ExifInterface.ORIENTATION_NORMAL:
                    // leave unchanged
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    needs_tf = true;
                    exif_orientation = 180;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_90:
                    needs_tf = true;
                    exif_orientation = 90;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    needs_tf = true;
                    exif_orientation = 270;
                    break;
                default:
                    // just leave unchanged for now
                    if (MyDebug.LOG)
                        Log.e(TAG, "    unsupported exif orientation: " + exif_orientation_s);
                    break;
            }
            if( MyDebug.LOG )
                Log.d(TAG, "    exif orientation: " + exif_orientation);

            if( needs_tf ) {
                if( MyDebug.LOG )
                    Log.d(TAG, "    need to rotate bitmap due to exif orientation tag");
                Matrix m = new Matrix();
                m.setRotate(exif_orientation, bitmap.getWidth() * 0.5f, bitmap.getHeight() * 0.5f);
                Bitmap rotated_bitmap = Bitmap.createBitmap(bitmap, 0, 0,bitmap.getWidth(), bitmap.getHeight(), m, true);
                if( rotated_bitmap != bitmap ) {
                    bitmap.recycle();
                    bitmap = rotated_bitmap;
                }
            }
        }
        catch(IOException exception) {
            if( MyDebug.LOG )
                Log.e(TAG, "exif orientation ioexception");
            exception.printStackTrace();
        }
        catch(NoClassDefFoundError exception) {
            // have had Google Play crashes from new ExifInterface() for Galaxy Ace4 (vivalto3g), Galaxy S Duos3 (vivalto3gvn)
            if( MyDebug.LOG )
                Log.e(TAG, "exif orientation NoClassDefFoundError");
            exception.printStackTrace();
        }
        finally {
            if( inputStream != null ) {
                try {
                    inputStream.close();
                }
                catch(IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return bitmap;
    }

    private Bitmap loadBitmapWithRotation(byte[] bArr, boolean z) {
        Bitmap loadBitmap = loadBitmap(bArr, z, 1);
        if (loadBitmap != null) {
            Log.d(TAG, "rotate bitmap for exif tags?");
            return rotateForExif(loadBitmap, bArr);
        }
        return loadBitmap;
    }


    public static class ExifInterfaceHolder {
        private final ExifInterface exif;
        private final ParcelFileDescriptor pfd;

        ExifInterfaceHolder(ParcelFileDescriptor parcelFileDescriptor, ExifInterface exifInterface) {
            this.pfd = parcelFileDescriptor;
            this.exif = exifInterface;
        }

        ExifInterface getExif() {
            return this.exif;
        }

        void close() {
            ParcelFileDescriptor parcelFileDescriptor = this.pfd;
            if (parcelFileDescriptor != null) {
                try {
                    parcelFileDescriptor.close();
                } catch (IOException e) {
                    Log.e(ImageSaver.TAG, "failed to close parcelfiledescriptor");
                    e.printStackTrace();
                }
            }
        }
    }

    private ExifInterfaceHolder createExifInterface(File file, Uri uri) throws IOException {
        ExifInterface exifInterface;
        ExifInterface exifInterface2 = null;
        ParcelFileDescriptor parcelFileDescriptor = null;
        if (file != null) {
            Log.d(TAG, "write to picFile: " + file);
            exifInterface = new ExifInterface(file.getAbsolutePath());
        } else {
            Log.d(TAG, "write direct to saveUri: " + uri);
            ParcelFileDescriptor openFileDescriptor = this.main_activity.getContentResolver().openFileDescriptor(uri, "rw");
            if (openFileDescriptor != null) {
                exifInterface2 = new ExifInterface(openFileDescriptor.getFileDescriptor());
            } else {
                Log.e(TAG, "failed to create ParcelFileDescriptor for saveUri: " + uri);
            }
            exifInterface = exifInterface2;
            parcelFileDescriptor = openFileDescriptor;
        }
        return new ExifInterfaceHolder(parcelFileDescriptor, exifInterface);
    }

    /* JADX WARN: Not initialized variable reg: 23, insn: 0x00e3: MOVE  (r1 I:??[OBJECT, ARRAY]) = (r23 I:??[OBJECT, ARRAY]), block:B:48:0x00e3 */
    /* JADX WARN: Not initialized variable reg: 24, insn: 0x00e5: MOVE  (r2 I:??[OBJECT, ARRAY]) = (r24 I:??[OBJECT, ARRAY]), block:B:48:0x00e3 */
    private void updateExif(Request imageSaver$Request0, File file0, Uri uri0) throws IOException {
        ExifInterface exifInterface1;
        ExifInterfaceHolder imageSaver$ExifInterfaceHolder1;
        ExifInterfaceHolder imageSaver$ExifInterfaceHolder0;
        Log.d("ImageSaver", "updateExif: " + file0);
        boolean v = true;
        if (!imageSaver$Request0.store_geo_direction && !imageSaver$Request0.store_ypr && !this.hasCustomExif(imageSaver$Request0.custom_tag_artist, imageSaver$Request0.custom_tag_copyright)) {
            if (imageSaver$Request0.type != Request.Type.JPEG) {
                v = false;
            }

            if (this.needGPSTimestampHack(v, imageSaver$Request0.using_camera2, imageSaver$Request0.store_location)) {
                Log.d("ImageSaver", "remove GPS timestamp hack");
                try {
                    imageSaver$ExifInterfaceHolder0 = this.createExifInterface(file0, uri0);
                } catch (NoClassDefFoundError noClassDefFoundError0) {
                    Log.e("ImageSaver", "exif orientation NoClassDefFoundError");
                    noClassDefFoundError0.printStackTrace();
                    return;
                }

                try {
                    ExifInterface exifInterface0 = imageSaver$ExifInterfaceHolder0.getExif();
                    if (exifInterface0 != null) {
                        this.fixGPSTimestamp(exifInterface0, imageSaver$Request0.current_date);
                        exifInterface0.saveAttributes();
                    }

                    imageSaver$ExifInterfaceHolder0.close();
                } catch (Throwable throwable0) {
                    try {
                        imageSaver$ExifInterfaceHolder0.close();
                        throw throwable0;
                    } catch (NoClassDefFoundError noClassDefFoundError0) {
                        Log.e("ImageSaver", "exif orientation NoClassDefFoundError");
                        noClassDefFoundError0.printStackTrace();
                    }
                }


                return;
            }

            Log.d("ImageSaver", "no exif data to update for: " + file0);
            return;
        }

        long v1 = System.currentTimeMillis();
        Log.d("ImageSaver", "add additional exif info");
        try {
            imageSaver$ExifInterfaceHolder1 = this.createExifInterface(file0, uri0);
            exifInterface1 = imageSaver$ExifInterfaceHolder1.getExif();
            if (exifInterface1 != null) {
                int vvv = imageSaver$Request0.type == Request.Type.JPEG ? 1 : 0;
                boolean vvb = true;
                if (vvv == 0) {
                    vvb = false;
                }
                label_84:
                this.modifyExif(exifInterface1,         // exifInterface0:androidx.exifinterface.media.ExifInterface
                        ((boolean) (vvb)), // z:boolean
                        imageSaver$Request0.using_camera2, // z1:boolean
                        imageSaver$Request0.current_date, // date0:java.util.Date
                        imageSaver$Request0.store_location, // z2:boolean
                        imageSaver$Request0.store_geo_direction, // z3:boolean
                        imageSaver$Request0.geo_direction, // f:double
                        imageSaver$Request0.custom_tag_artist, // s:java.lang.String
                        imageSaver$Request0.custom_tag_copyright, // s1:java.lang.String
                        imageSaver$Request0.level_angle, // f1:double
                        imageSaver$Request0.pitch_angle, // f2:double
                        imageSaver$Request0.store_ypr // z4:boolean
                );
                exifInterface1.saveAttributes();
                imageSaver$ExifInterfaceHolder1.close();
                Log.d("ImageSaver", "*** time to add additional exif info: " + (System.currentTimeMillis() - v1));
            }
        } catch (NoClassDefFoundError noClassDefFoundError1) {
            Log.e("ImageSaver", "exif orientation NoClassDefFoundError");
            noClassDefFoundError1.printStackTrace();
        }

    }


    private void modifyExif(ExifInterface exifInterface, boolean z, boolean z2, Date date, boolean z3, boolean z4, double d, String str, String str2, double d2, double d3, boolean z5) {
        Log.d(TAG, "modifyExif");
        setGPSDirectionExif(exifInterface, z4, d);
        if (z5) {
            float degrees = (float) Math.toDegrees(d);
            if (degrees<0.0f) {
                degrees += 360.0f;
            }
            exifInterface.setAttribute(ExifInterface.TAG_USER_COMMENT, "ASCII\u0000\u0000\u0000Yaw:" + degrees + ",Pitch:" + d3 + ",Roll:" + d2);
            StringBuilder sb = new StringBuilder();
            sb.append("UserComment: ");
            sb.append(exifInterface.getAttribute(ExifInterface.TAG_USER_COMMENT));
            Log.d(TAG, sb.toString());
        }
        setCustomExif(exifInterface, str, str2);
        if (needGPSTimestampHack(z, z2, z3)) {
            fixGPSTimestamp(exifInterface, date);
        }
    }

    private void setGPSDirectionExif(ExifInterface exifInterface, boolean z, double d) {
        Log.d(TAG, "setGPSDirectionExif");
        if (z) {
            float degrees = (float) Math.toDegrees(d);
            if (degrees<0.0f) {
                degrees += 360.0f;
            }
            Log.d(TAG, "save geo_angle: " + degrees);
            String str = Math.round(degrees * 100.0f) + "/100";
            Log.d(TAG, "GPSImgDirection_string: " + str);
            exifInterface.setAttribute(ExifInterface.TAG_GPS_IMG_DIRECTION, str);
            exifInterface.setAttribute(ExifInterface.TAG_GPS_IMG_DIRECTION_REF, "M");
        }
    }

    private boolean hasCustomExif(String str, String str2) {
        if (str == null || str.length()<=0) {
            return str2 != null && str2.length()>0;
        }
        return true;
    }

    private void setCustomExif(ExifInterface exifInterface, String str, String str2) {
        Log.d(TAG, "setCustomExif");
        if (str != null && str.length()>0) {
            Log.d(TAG, "apply TAG_ARTIST: " + str);
            exifInterface.setAttribute(ExifInterface.TAG_ARTIST, str);
        }
        if (str2 == null || str2.length()<=0) {
            return;
        }
        exifInterface.setAttribute(ExifInterface.TAG_COPYRIGHT, str2);
        Log.d(TAG, "apply TAG_COPYRIGHT: " + str2);
    }

    private void setDateTimeExif(ExifInterface exifInterface) {
        Log.d(TAG, "setDateTimeExif");
        String attribute = exifInterface.getAttribute(ExifInterface.TAG_DATETIME);
        if (attribute != null) {
            Log.d(TAG, "write datetime tags: " + attribute);
            exifInterface.setAttribute(ExifInterface.TAG_DATETIME_ORIGINAL, attribute);
            exifInterface.setAttribute(ExifInterface.TAG_DATETIME_DIGITIZED, attribute);
        }
    }

    private void fixGPSTimestamp(ExifInterface exifInterface, Date date) {
        Log.d(TAG, "fixGPSTimestamp");
        Log.d(TAG, "current datestamp: " + exifInterface.getAttribute(ExifInterface.TAG_GPS_DATESTAMP));
        Log.d(TAG, "current timestamp: " + exifInterface.getAttribute(ExifInterface.TAG_GPS_TIMESTAMP));
        Log.d(TAG, "current datetime: " + exifInterface.getAttribute(ExifInterface.TAG_DATETIME));
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy:MM:dd", Locale.US);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        String format = simpleDateFormat.format(date);
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("HH:mm:ss", Locale.US);
        simpleDateFormat2.setTimeZone(TimeZone.getTimeZone("UTC"));
        String format2 = simpleDateFormat2.format(date);
        Log.d(TAG, "datestamp: " + format);
        Log.d(TAG, "timestamp: " + format2);
        exifInterface.setAttribute(ExifInterface.TAG_GPS_DATESTAMP, format);
        exifInterface.setAttribute(ExifInterface.TAG_GPS_TIMESTAMP, format2);
        Log.d(TAG, "fixGPSTimestamp exit");
    }

    public HDRProcessor getHDRProcessor() {
        return this.hdrProcessor;
    }

    public PanoramaProcessor getPanoramaProcessor() {
        return this.panoramaProcessor;
    }
}
