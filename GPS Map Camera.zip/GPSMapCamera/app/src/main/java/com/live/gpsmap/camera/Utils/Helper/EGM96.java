package com.live.gpsmap.camera.Utils.Helper;

import android.content.Context;
import android.location.Location;

import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Default;
import com.live.gpsmap.camera.Utils.SP;
import com.onesignal.OneSignalRemoteParams;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Array;

/* loaded from: classes.dex */
public class EGM96 {
    public static final double EGM96_VALUE_INVALID = -10000.0d;
    private static final EGM96 instance = new EGM96();
    Context mConntext;

    public static EGM96 getInstance() {
        return instance;
    }

    public void loadGrid(Location location, Context context) {
        this.mConntext = context;
        new Thread(new LoadEGM96Grid(location)).start();
    }

    public double getEGMCorrection(double d, double d2) {
        if (Default.isEGMGridLoaded) {
            double d3 = 90.0d - d;
            if (d2 < 0.0d) {
                d2 += 360.0d;
            }
            int i = ((int) (d2 / 0.5d)) + 3;
            int i2 = ((int) (d3 / 0.5d)) + 3;
            try {
                short s = Default.EGMGrid[i][i2];
                int i3 = i2 + 1;
                short s2 = Default.EGMGrid[i][i3];
                int i4 = i + 1;
                short s3 = Default.EGMGrid[i4][i2];
                double d4 = d3 % 0.25d;
                double d5 = s + (((s2 - s) * d4) / 0.25d);
                return (d5 + ((((s3 + (((Default.EGMGrid[i4][i3] - s3) * d4) / 0.25d)) - d5) * (d2 % 0.25d)) / 0.25d)) / 100.0d;
            } catch (ArrayIndexOutOfBoundsException unused) {
                return -10000.0d;
            }
        }
        return -10000.0d;
    }

    /* loaded from: classes2.dex */
    private class LoadEGM96Grid implements Runnable {
        Location mLocation;
        SP mSP;

        public LoadEGM96Grid(Location location) {
            this.mSP = new SP(EGM96.this.mConntext);
            this.mLocation = location;
        }

        @Override // java.lang.Runnable
        public void run() {
            InputStream openRawResource = EGM96.this.mConntext.getResources().openRawResource(R.raw.ww15mgh);
            File file = new File(EGM96.this.mConntext.getFilesDir() + File.separator + "DefaultProperties.xml");
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                byte[] bArr = new byte[1024];
                while (true) {
                    int read = openRawResource.read(bArr);
                    if (read <= 0) {
                        break;
                    }
                    fileOutputStream.write(bArr, 0, read);
                }
                fileOutputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            DataInputStream dataInputStream = new DataInputStream(new BufferedInputStream(EGM96.this.mConntext.getResources().openRawResource(R.raw.ww15mgh)));
            if (Default.EGMGrid == null) {
                Default.EGMGrid = (short[][]) Array.newInstance(Short.TYPE, 1446, 727);
                if (Default.COUNT == 0) {
                    Default.COUNT = (int) (file.length() / 2);
                }
                int i = 3;
                int i2 = 3;
                for (int i3 = 0; i3 < Default.COUNT; i3++) {
                    try {
                        Default.EGMGrid[i][i2] = dataInputStream.readShort();
                        i++;
                        if (i >= 1443) {
                            i2++;
                            i = 3;
                        }
                    } catch (IOException e2) {
                        Default.isEGMGridLoaded = false;
                        e2.printStackTrace();
                        return;
                    }
                }
                for (int i4 = 0; i4 < 3; i4++) {
                    for (int i5 = 3; i5 < 724; i5++) {
                        Default.EGMGrid[i4][i5] = Default.EGMGrid[i4 + OneSignalRemoteParams.DEFAULT_INDIRECT_ATTRIBUTION_WINDOW][i5];
                        int i6 = i4 + 3;
                        Default.EGMGrid[i6 + OneSignalRemoteParams.DEFAULT_INDIRECT_ATTRIBUTION_WINDOW][i5] = Default.EGMGrid[i6][i5];
                    }
                }
                for (int i7 = 0; i7 < 3; i7++) {
                    for (int i8 = 0; i8 < 1446; i8++) {
                        if (i8 > 720) {
                            int i9 = i8 - 720;
                            Default.EGMGrid[i8][i7] = Default.EGMGrid[i9][6 - i7];
                            Default.EGMGrid[i8][i7 + 3 + 721] = Default.EGMGrid[i9][722 - i7];
                        } else {
                            int i10 = i8 + 720;
                            Default.EGMGrid[i8][i7] = Default.EGMGrid[i10][6 - i7];
                            Default.EGMGrid[i8][i7 + 3 + 721] = Default.EGMGrid[i10][722 - i7];
                        }
                    }
                }
            }
            Default.isEGMGridLoaded = true;
            this.mSP.setFloat(EGM96.this.mConntext, SP.ALTITUDE_VALUE, Float.parseFloat(String.valueOf(EGM96.this.getEGMCorrection(this.mLocation.getLatitude(), this.mLocation.getLongitude()))));
        }
    }
}