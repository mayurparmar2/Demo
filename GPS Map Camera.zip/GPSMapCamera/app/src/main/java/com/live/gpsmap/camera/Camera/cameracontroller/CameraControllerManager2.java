package com.live.gpsmap.camera.Camera.cameracontroller;

import android.content.Context;
import android.graphics.Rect;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.util.Log;
import android.util.Size;
import android.util.SizeF;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraController;
import com.live.gpsmap.camera.R;


public class CameraControllerManager2 extends CameraControllerManager {
    private static final String TAG = "CControllerManager2";
    private final Context context;

    public CameraControllerManager2(Context context) {
        this.context = context;
    }

    @Override
    public int getNumberOfCameras() {
        try {
            return ((CameraManager) this.context.getSystemService(Context.CAMERA_SERVICE)).getCameraIdList().length;
        } catch (Throwable th) {
            Log.e(TAG, "exception trying to get camera ids");
            th.printStackTrace();
            return 0;
        }
    }

    @Override
    public CameraController.Facing getFacing(int i) {
        CameraCharacteristics cameraCharacteristics = null;
        int intValue = 0;
        CameraManager cameraManager = (CameraManager) this.context.getSystemService(Context.CAMERA_SERVICE);
        try {
            cameraCharacteristics = cameraManager.getCameraCharacteristics(cameraManager.getCameraIdList()[i]);
            intValue = ((Integer) cameraCharacteristics.get(CameraCharacteristics.LENS_FACING)).intValue();
        } catch (Throwable th) {
            Log.e(TAG, "exception trying to get camera characteristics");
            th.printStackTrace();
        }
        if (intValue != 0) {
            if (intValue != 1) {
                if (intValue == 2) {
                    return CameraController.Facing.FACING_EXTERNAL;
                }
                Log.e(TAG, "unknown camera_facing: " + cameraCharacteristics.get(CameraCharacteristics.LENS_FACING));
                return CameraController.Facing.FACING_UNKNOWN;
            }
            return CameraController.Facing.FACING_BACK;
        }
        return CameraController.Facing.FACING_FRONT;
    }

    @Override
    public String getDescription(Context context, int i) {
        String string;
        CameraManager cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        try {
            CameraCharacteristics cameraCharacteristics = cameraManager.getCameraCharacteristics(cameraManager.getCameraIdList()[i]);
            int intValue = ((Integer) cameraCharacteristics.get(CameraCharacteristics.LENS_FACING)).intValue();
            if (intValue == 0) {
                string = context.getResources().getString(R.string.front_camera);
            } else if (intValue == 1) {
                string = context.getResources().getString(R.string.back_camera);
            } else if (intValue == 2) {
                string = context.getResources().getString(R.string.external_camera);
            } else {
                Log.e(TAG, "unknown camera type");
                return null;
            }
            String str = string;
            if (computeViewAngles(cameraCharacteristics).getWidth() > 90.5f) {
                return str + ", " + context.getResources().getString(R.string.ultrawide);
            }
            return str;
        } catch (Throwable th) {
            Log.e(TAG, "exception trying to get camera characteristics");
            th.printStackTrace();
            return null;
        }
    }

    public static SizeF computeViewAngles(CameraCharacteristics cameraCharacteristics) {
        Rect rect = (Rect) cameraCharacteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
        SizeF sizeF = (SizeF) cameraCharacteristics.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
        Size size = (Size) cameraCharacteristics.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE);
        float[] fArr = (float[]) cameraCharacteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
        if (rect == null || sizeF == null || size == null || fArr == null || fArr.length == 0) {
            Log.e(TAG, "can't get camera view angles");
            return new SizeF(55.0f, 43.0f);
        }
        float width = rect.width() / size.getWidth();
        float height = rect.height() / size.getHeight();
        float degrees = (float) Math.toDegrees(Math.atan2(sizeF.getWidth() * width, fArr[0] * 2.0d) * 2.0d);
        float degrees2 = (float) Math.toDegrees(Math.atan2(sizeF.getHeight() * height, fArr[0] * 2.0d) * 2.0d);
        Log.d(TAG, "frac_x: " + width);
        Log.d(TAG, "frac_y: " + height);
        Log.d(TAG, "view_angle_x: " + degrees);
        Log.d(TAG, "view_angle_y: " + degrees2);
        return new SizeF(degrees, degrees2);
    }

    public static boolean isHardwareLevelSupported(CameraCharacteristics cameraCharacteristics, int i) {
        int intValue = ((Integer) cameraCharacteristics.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)).intValue();
        if (intValue == 0) {
            Log.d(TAG, "Camera has LIMITED Camera2 support");
        } else if (intValue == 1) {
            Log.d(TAG, "Camera has FULL Camera2 support");
        } else if (intValue == 2) {
            Log.d(TAG, "Camera has LEGACY Camera2 support");
        } else if (intValue == 3) {
            Log.d(TAG, "Camera has Level 3 Camera2 support");
        } else if (intValue == 4) {
            Log.d(TAG, "Camera has EXTERNAL Camera2 support");
        } else {
            Log.d(TAG, "Camera has unknown Camera2 support: " + intValue);
        }
        if (intValue == 2) {
            return i == intValue;
        }
        if (intValue == 4) {
            intValue = 0;
        }
        if (i == 4) {
            i = 0;
        }
        return i <= intValue;
    }

    public boolean allowCamera2Support(int i) {
        CameraManager cameraManager = (CameraManager) this.context.getSystemService(Context.CAMERA_SERVICE);
        try {
            return isHardwareLevelSupported(cameraManager.getCameraCharacteristics(cameraManager.getCameraIdList()[i]), 0);
        } catch (Throwable th) {
            Log.e(TAG, "exception trying to get camera characteristics");
            th.printStackTrace();
            return false;
        }
    }
}
