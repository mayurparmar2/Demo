package com.live.gpsmap.camera.Camera;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Build;
import android.util.Log;
import android.util.SparseIntArray;

@SuppressWarnings("All")
public class SoundPoolManager {
    private static final String TAG = "SoundPoolManager";
    private final Context context;
    private SparseIntArray sound_ids;
    private SoundPool sound_pool;

    public SoundPoolManager(Context context) {
        this.context = context;
    }

    public void initSound() {
        if (this.sound_pool == null) {
            Log.d(TAG, "create new sound_pool");
            if (Build.VERSION.SDK_INT >= 21) {
                this.sound_pool = new SoundPool.Builder().setMaxStreams(1).setAudioAttributes(new AudioAttributes.Builder().setLegacyStreamType(1).setContentType(4).build()).build();
            } else {
                this.sound_pool = new SoundPool(1, 1, 0);
            }
            this.sound_ids = new SparseIntArray();
        }
    }

    public void releaseSound() {
        if (this.sound_pool != null) {
            Log.d(TAG, "release sound_pool");
            this.sound_pool.release();
            this.sound_pool = null;
            this.sound_ids = null;
        }
    }

    public void loadSound(int i) {
        if (this.sound_pool != null) {
            Log.d(TAG, "loading sound resource: " + i);
            int load = this.sound_pool.load(this.context, i, 1);
            Log.d(TAG, "    loaded sound: " + load);
            this.sound_ids.put(i, load);
        }
    }


    public void playSound(int i) {
        if (this.sound_pool != null) {
            if (this.sound_ids.indexOfKey(i) < 0) {
                Log.d(TAG, "resource not loaded: " + i);
                return;
            }
            int i2 = this.sound_ids.get(i);
            Log.d(TAG, "play sound: " + i2);
            this.sound_pool.play(i2, 1.0f, 1.0f, 0, 0, 1.0f);
        }
    }
}
