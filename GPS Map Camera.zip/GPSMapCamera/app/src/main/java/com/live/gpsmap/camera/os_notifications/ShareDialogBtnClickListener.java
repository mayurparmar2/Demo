package com.live.gpsmap.camera.os_notifications;

/* loaded from: classes3.dex */
public interface ShareDialogBtnClickListener {
    void onShareBtnClicked();
}
