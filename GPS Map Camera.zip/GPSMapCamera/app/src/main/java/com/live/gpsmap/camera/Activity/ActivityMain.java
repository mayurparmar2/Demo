package com.live.gpsmap.camera.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.material.navigation.NavigationView;
import com.live.gpsmap.camera.Camera.MyApplicationInterface;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.Utils.Util;
import com.live.gpsmap.camera.databinding.ActivityMainCameraBinding;
import com.google.android.gms.maps.OnMapReadyCallback;
@SuppressWarnings("All")
public class ActivityMain extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, OnMapReadyCallback{
    ActivityMainCameraBinding binding;
    public static Window window;
    Intent intent;
    public boolean is_test;
    private static final String TAG = "com.gpsvideocamera.videotimestamp.CameraActivity";
    SharedPreferences sharedPreferences;
    private boolean supports_auto_stabilise;
    private boolean supports_force_video_4k;
    public MyApplicationInterface applicationInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainCameraBinding.inflate(getLayoutInflater());
        Util.SetLanguage(this);
        setContentView(binding.getRoot());
        window = getWindow();
        this.intent = getIntent();
        if (!new SP(this).getBoolean(this, "enableAutostart", false)) {
            enableAutoStart();
        }
        if (Build.VERSION.SDK_INT >= 18) {
            WindowManager.LayoutParams attributes = getWindow().getAttributes();
            attributes.rotationAnimation = 1;
            getWindow().setAttributes(attributes);
        }
        if (getIntent() != null && getIntent().getExtras() != null) {
            this.is_test = getIntent().getExtras().getBoolean("test_project");
        }
        if (getIntent() != null) {
            getIntent().getExtras();
        }
        if (getIntent() != null && getIntent().getAction() != null) {
            Log.d(TAG, "shortcut: " + getIntent().getAction());
        }
        if (Build.VERSION.SDK_INT > 32 && !checkNotiPermission()) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.POST_NOTIFICATIONS"}, 100);
        }
        this.sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        Log.d(TAG, "standard max memory = " + activityManager.getMemoryClass() + "MB");
        Log.d(TAG, "large max memory = " + activityManager.getLargeMemoryClass() + "MB");
        int largeMemoryClass = activityManager.getLargeMemoryClass();
        if (largeMemoryClass >= 128) {
            this.supports_auto_stabilise = true;
        }
        Log.d(TAG, "supports_auto_stabilise? " + this.supports_auto_stabilise);
        if (activityManager.getMemoryClass() >= 128 || activityManager.getLargeMemoryClass() >= 512) {
            this.supports_force_video_4k = true;
        }
        Log.d(TAG, "supports_force_video_4k? " + this.supports_force_video_4k);
//        this.applicationInterface = new MyApplicationInterface(ActivityMain.this, savedInstanceState);




    }


    @Override
    public void onMapReady(GoogleMap googleMap) {

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return false;
    }
    private boolean checkNotiPermission() {
        return ContextCompat.checkSelfPermission(this, "android.permission.POST_NOTIFICATIONS") == 0;
    }

    private void enableAutoStart() {
        if (Build.BRAND.equalsIgnoreCase("xiaomi") || Build.BRAND.equalsIgnoreCase("redmi")) {
            final SP sp = new SP(this);
            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(false);
            builder.setTitle("Enable AutoStart");
            builder.setMessage("Please allow us to run in the background, else our services can’t be accessed.");
            builder.setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    try {
                        Intent intent = new Intent();
                        intent.setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"));
                        startActivity(intent);
                        sp.setBoolean(ActivityMain.this, "enableAutostart", true);
                    } catch (Exception e) {
                        e.printStackTrace();
                        builder.setCancelable(true);
                        sp.setBoolean(ActivityMain.this, "enableAutostart", true);
                    }
                    builder.setCancelable(true);
                }
            });
            androidx.appcompat.app.AlertDialog create = builder.create();
            create.show();
            create.getButton(-1).setTextColor(getResources().getColor(R.color.black));
        }
    }

}