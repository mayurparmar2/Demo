package com.live.gpsmap.camera.os_notifications.models;

import com.google.gson.annotations.SerializedName;
public class NotificationModel {
    @SerializedName("message")
    public String message;
    @SerializedName("title")
    public String title;
    @SerializedName("type")
    public String type;
    @SerializedName("url")
    public String url;

    public String getType() {
        return this.type;
    }

    public String getTitle() {
        return this.title;
    }

    public String getMessage() {
        return this.message;
    }

    public String getUrl() {
        return this.url;
    }
}
