package com.live.gpsmap.camera.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;

import com.live.gpsmap.camera.Adapter.LanguageAdapter;
import com.live.gpsmap.camera.Camera.CameraMainActivity;
import com.live.gpsmap.camera.Interface.OnRecyclerItemClickListener;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Helper.SingleClickListener;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.databinding.ActivityLanguageSelectionBinding;

public class ActivityLanguageSelection extends AppCompatActivity {
    ActivityLanguageSelectionBinding binding;
    SP mSP;
    int count;
    private String[] mLanArray;
    TypedArray langIcon;
    String mSelectedLanguage;
    int selected_pos;
    Intent intent;
    LanguageAdapter mAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLanguageSelectionBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SP sp = new SP(this);
        this.mSP = sp;
        this.count = sp.getInteger(this, SP.LANGUAGE_COUNT, 0);
        this.mLanArray = getResources().getStringArray(R.array.lan_array);
        this.langIcon = getResources().obtainTypedArray(R.array.lang_img);

        binding.toolbar.tvToolbarTitle.setText(R.string.select_language);
        if (count == 0){
            binding.toolbar.toolbar.setVisibility(View.GONE);
            binding.btnSave.setVisibility(View.VISIBLE);
        }else {
            binding.tvHomeSubTitle.setVisibility(View.GONE);
            binding.tvHomeTitle.setVisibility(View.GONE);
            binding.btnSave.setVisibility(View.GONE);
            binding.toolbar.toolbar.setVisibility(View.VISIBLE);
        }
        this.mSelectedLanguage = this.mSP.getString(this, SP.SELECTED_LANGUAGE, "English");
        this.selected_pos = this.mSP.getInteger(this, SP.LANGUAGE_POS, 0);

        binding.btnSave.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View view) {
                mSP.setInteger(ActivityLanguageSelection.this, SP.LANGUAGE_COUNT, 1);
                if (mSP.getBoolean(ActivityLanguageSelection.this, SP.ALL_PERMISSION_ACCESS, false)) {
                    intent = new Intent(ActivityLanguageSelection.this, ActivityMain.class);
                } else {
                    intent = new Intent(ActivityLanguageSelection.this, ActivityPermission.class);
                }
                saveData();
            }
        });
        binding.toolbar.toolbarBack.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View view) {
                onBackPressed();
            }
        });
        binding.toolbar.toolbarDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mSP.getBoolean(ActivityLanguageSelection.this, SP.ALL_PERMISSION_ACCESS, false)) {
                    intent = new Intent(ActivityLanguageSelection.this, CameraMainActivity.class);
                } else {
                    intent = new Intent(ActivityLanguageSelection.this, ActivityPermission.class);
                }
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                saveData();

            }
        });

        setAdapter();
        binding.btnSave.setBackgroundColor(getResources().getColor(R.color._ffcc00));

    }
    @Override
    public void onBackPressed() {
        if (this.count != 0) {
            if (isChanges()) {
                this.intent = new Intent(this, CameraMainActivity.class);
                saveData();
                return;
            }
            setResult(0, this.intent);
            finish();
        }
    }
    private boolean isChanges() {
        return this.selected_pos != this.mSP.getInteger(this, SP.LANGUAGE_POS, -1);
    }





    private void setAdapter() {
        binding.selectLanRecyclerview.setLayoutManager(new LinearLayoutManager(this));
        LanguageAdapter languageAdapter = new LanguageAdapter(this, this.mLanArray, this.langIcon, new OnRecyclerItemClickListener() {
            @Override
            public void OnLongClick_(int i, View view) {
            }

            @Override
            public void OnClick_(int i, View view) {
                selected_pos = i;
                if (selected_pos >= 0) {
                    mSelectedLanguage = mLanArray[i];
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (mAdapter != null) {
                                mAdapter.refAdapter(selected_pos);
                            }
                            binding.toolbar.toolbarDone.setVisibility(View.VISIBLE);
                        }
                    }, 120L);
                }
            }
        });
        this.mAdapter = languageAdapter;
        binding.selectLanRecyclerview.setAdapter(languageAdapter);
    }


    public void saveData() {
        this.mSP.setString(this, SP.SELECTED_LANGUAGE, this.mSelectedLanguage);
        this.mSP.setInteger(this, SP.LANGUAGE_POS, this.selected_pos);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        setResult(-1, this.intent);
        startActivity(this.intent);
        finish();
    }

}