package com.live.gpsmap.camera.Camera.Script.Say;

/* loaded from: classes3.dex */
public class TccIv {
    public static String CWcYOLH;
    public static String DDNgFwu;
    public static String DZgQPJNrndrAOqS;
    public static String HTlkDxEZyTeDw;
    public static String KTFJ;
    public static String LSDKuPZGkEvNenJ;
    public static String MrSTHvImG;
    public static String QKXErhYV;
    public static String TMrYp;
    public static String UOYMSSGuf;
    public static String VHCASybnK;
    public static String VRjBTYoIr;
    public static String VxjSNBIjjZi;
    public static String XBxDbXlSTg;
    public static String XRsGR;
    public static String bvVyvpRzJ;
    public static String fwkHHpZSxj;
    public static String iBdXUkjZOZetDgN;
    public static String jtc;
    public static String oboAwQwJFoGUk;
    public static String pYG;
    public static String rUXfpmYxaFPCGY;
    public static String rlPJoV;
    public static String thCbwIm;
    public static String ttTXzfbxskD;
    public static String ugjObmrSehLhyXA;
    public static String xYOUckNYUhtLQHr;
    public static String xkkwbc;
    public static String yJciOoaeJhaFc;
    public static String zAzGiEz;
    public static String zqrnmtoQBcbdo;
}
