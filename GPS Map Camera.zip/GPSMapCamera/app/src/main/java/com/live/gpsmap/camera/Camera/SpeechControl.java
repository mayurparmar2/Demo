package com.live.gpsmap.camera.Camera;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;
import android.util.Log;
import java.util.ArrayList;
import java.util.Locale;

@SuppressWarnings("All")
public class SpeechControl {
    private static final String TAG = "SpeechControl";
    private final CameraMainActivity main_activity;
    private SpeechRecognizer speechRecognizer;
    private boolean speechRecognizerIsStarted;

    private void speechRecognizerStopped() {
    }

    void speechRecognizerStarted() {
    }

    public SpeechControl(CameraMainActivity mainActivity) {
        this.main_activity = mainActivity;
    }

    void startSpeechRecognizerIntent() {
        Log.d(TAG, "startSpeechRecognizerIntent");
        if (this.speechRecognizer != null) {
            Intent intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
            intent.putExtra("android.speech.extra.LANGUAGE", "en_US");
            this.speechRecognizer.startListening(intent);
        }
    }

    public void initSpeechRecognizer() {
        Log.d(TAG, "initSpeechRecognizer");
        boolean equals = PreferenceManager.getDefaultSharedPreferences(this.main_activity).getString(PreferenceKeys.AudioControlPreferenceKey, "none").equals("voice");
        SpeechRecognizer speechRecognizer = this.speechRecognizer;
        if (speechRecognizer != null || !equals) {
            if (speechRecognizer == null || equals) {
                return;
            }
            Log.d(TAG, "stop existing SpeechRecognizer");
            stopSpeechRecognizer();
            return;
        }
        Log.d(TAG, "create new speechRecognizer");
        SpeechRecognizer createSpeechRecognizer = SpeechRecognizer.createSpeechRecognizer(this.main_activity);
        this.speechRecognizer = createSpeechRecognizer;
        if (createSpeechRecognizer != null) {
            this.speechRecognizerIsStarted = false;
            createSpeechRecognizer.setRecognitionListener(new RecognitionListener() { // from class: com.live.gpsmap.camera.Camera.SpeechControl.1
                @Override // android.speech.RecognitionListener
                public void onRmsChanged(float f) {
                }

                private void restart() {
                    Log.d(SpeechControl.TAG, "RecognitionListener: restart");
                    new Handler().postDelayed(new Runnable() { // from class: com.live.gpsmap.camera.Camera.SpeechControl.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            SpeechControl.this.startSpeechRecognizerIntent();
                        }
                    }, 250L);
                }

                @Override // android.speech.RecognitionListener
                public void onBeginningOfSpeech() {
                    Log.d(SpeechControl.TAG, "RecognitionListener: onBeginningOfSpeech");
                    if (SpeechControl.this.speechRecognizerIsStarted) {
                        return;
                    }
                    Log.d(SpeechControl.TAG, "...but speech recognition already stopped");
                }

                @Override // android.speech.RecognitionListener
                public void onBufferReceived(byte[] bArr) {
                    Log.d(SpeechControl.TAG, "RecognitionListener: onBufferReceived");
                    if (SpeechControl.this.speechRecognizerIsStarted) {
                        return;
                    }
                    Log.d(SpeechControl.TAG, "...but speech recognition already stopped");
                }

                @Override // android.speech.RecognitionListener
                public void onEndOfSpeech() {
                    Log.d(SpeechControl.TAG, "RecognitionListener: onEndOfSpeech");
                    if (!SpeechControl.this.speechRecognizerIsStarted) {
                        Log.d(SpeechControl.TAG, "...but speech recognition already stopped");
                    } else {
                        restart();
                    }
                }

                @Override // android.speech.RecognitionListener
                public void onError(int i) {
                    Log.d(SpeechControl.TAG, "RecognitionListener: onError: " + i);
                    if (!SpeechControl.this.speechRecognizerIsStarted) {
                        Log.d(SpeechControl.TAG, "...but speech recognition already stopped");
                    } else if (i != 7) {
                        restart();
                    }
                }

                @Override // android.speech.RecognitionListener
                public void onEvent(int i, Bundle bundle) {
                    Log.d(SpeechControl.TAG, "RecognitionListener: onEvent");
                    if (SpeechControl.this.speechRecognizerIsStarted) {
                        return;
                    }
                    Log.d(SpeechControl.TAG, "...but speech recognition already stopped");
                }

                @Override // android.speech.RecognitionListener
                public void onPartialResults(Bundle bundle) {
                    Log.d(SpeechControl.TAG, "RecognitionListener: onPartialResults");
                    if (SpeechControl.this.speechRecognizerIsStarted) {
                        return;
                    }
                    Log.d(SpeechControl.TAG, "...but speech recognition already stopped");
                }

                @Override // android.speech.RecognitionListener
                public void onReadyForSpeech(Bundle bundle) {
                    Log.d(SpeechControl.TAG, "RecognitionListener: onReadyForSpeech");
                    if (SpeechControl.this.speechRecognizerIsStarted) {
                        return;
                    }
                    Log.d(SpeechControl.TAG, "...but speech recognition already stopped");
                }

                @Override // android.speech.RecognitionListener
                public void onResults(Bundle bundle) {
                    float[] floatArray;
                    Log.d(SpeechControl.TAG, "RecognitionListener: onResults");
                    if (!SpeechControl.this.speechRecognizerIsStarted) {
                        Log.d(SpeechControl.TAG, "...but speech recognition already stopped");
                        return;
                    }
                    ArrayList<String> stringArrayList = bundle.getStringArrayList("results_recognition");
                    boolean z = false;
                    for (int i = 0; stringArrayList != null && i < stringArrayList.size(); i++) {
                        String str = stringArrayList.get(i);
                        if (bundle.getFloatArray("confidence_scores") != null) {
//                            Log.d(SpeechControl.TAG, "text: " + str + " score: " + floatArray[i]);
                        }
                        if (str.toLowerCase(Locale.US).contains("cheese")) {
                            z = true;
                        }
                    }
                    if (z) {
                        Log.d(SpeechControl.TAG, "audio trigger from speech recognition");
                        SpeechControl.this.main_activity.audioTrigger();
                    } else if (stringArrayList != null && stringArrayList.size() > 0) {
                        String str2 = stringArrayList.get(0) + "?";
                        Log.d(SpeechControl.TAG, "unrecognised: " + str2);
                        SpeechControl.this.main_activity.getPreview().showToast(SpeechControl.this.main_activity.getAudioControlToast(), str2);
                    }
                }
            });
            this.main_activity.getMainUI().inImmersiveMode();
        }
    }

    private void freeSpeechRecognizer() {
        Log.d(TAG, "freeSpeechRecognizer");
        this.speechRecognizer.cancel();
        try {
            this.speechRecognizer.destroy();
        } catch (IllegalArgumentException e) {
            Log.e(TAG, "exception destroying speechRecognizer");
            e.printStackTrace();
        }
        this.speechRecognizer = null;
    }

    public void stopSpeechRecognizer() {
        Log.d(TAG, "stopSpeechRecognizer");
        if (this.speechRecognizer != null) {
            speechRecognizerStopped();
            freeSpeechRecognizer();
        }
    }

    boolean isStarted() {
        return this.speechRecognizerIsStarted;
    }

    public void stopListening() {
        this.speechRecognizer.stopListening();
        speechRecognizerStopped();
    }

    public boolean hasSpeechRecognition() {
        return this.speechRecognizer != null;
    }
}
