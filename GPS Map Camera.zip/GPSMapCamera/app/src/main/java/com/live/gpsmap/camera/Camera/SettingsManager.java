package com.live.gpsmap.camera.Camera;

import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.util.Log;
import android.util.Xml;

import com.live.gpsmap.camera.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.util.Map;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

@SuppressWarnings("All")
public class SettingsManager {
    private static final String TAG = "SettingsManager";
    private static final String boolean_tag = "boolean";
    private static final String doc_tag = "open_camera_prefs";
    private static final String float_tag = "float";
    private static final String int_tag = "int";
    private static final String long_tag = "long";
    private static final String string_tag = "string";
    private final CameraMainActivity main_activity;

    public SettingsManager(CameraMainActivity mainActivity) {
        this.main_activity = mainActivity;
    }

    public boolean loadSettings(String str) {
        Log.d(TAG, "loadSettings: " + str);
        try {
            return loadSettings(new FileInputStream(str));
        } catch (FileNotFoundException e) {
            Log.e(TAG, "failed to load: " + str);
            e.printStackTrace();
            this.main_activity.getPreview().showToast((ToastBoxer) null, R.string.restore_settings_failed);
            return false;
        }
    }

    public boolean loadSettings(Uri uri) {
        Log.d(TAG, "loadSettings: " + uri);
        try {
            return loadSettings(this.main_activity.getContentResolver().openInputStream(uri));
        } catch (FileNotFoundException e) {
            Log.e(TAG, "failed to load: " + uri);
            e.printStackTrace();
            this.main_activity.getPreview().showToast((ToastBoxer) null, R.string.restore_settings_failed);
            return false;
        }
    }

    private boolean loadSettings(InputStream inputStream) {
        Log.d(TAG, "loadSettings: " + inputStream);
        try {
            try {
                XmlPullParser newPullParser = Xml.newPullParser();
                newPullParser.setFeature("http://xmlpull.org/v1/doc/features.html#process-namespaces", false);
                newPullParser.setInput(inputStream, null);
                newPullParser.nextTag();
                newPullParser.require(2, null, doc_tag);
                SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(this.main_activity).edit();
                edit.clear();
                while (newPullParser.next() != 3) {
                    if (newPullParser.getEventType() == 2) {
                        String name = newPullParser.getName();
                        String attributeValue = newPullParser.getAttributeValue(null, "key");
                        Log.d(TAG, "name: " + name);
                        Log.d(TAG, "    key: " + attributeValue);
                        Log.d(TAG, "    value: " + newPullParser.getAttributeValue(null, "value"));
                        char c = 65535;
                        switch (name.hashCode()) {
                            case -891985903:
                                if (name.equals("string")) {
                                    c = 4;
                                    break;
                                }
                                break;
                            case 104431:
                                if (name.equals(int_tag)) {
                                    c = 2;
                                    break;
                                }
                                break;
                            case 3327612:
                                if (name.equals(long_tag)) {
                                    c = 3;
                                    break;
                                }
                                break;
                            case 64711720:
                                if (name.equals("boolean")) {
                                    c = 0;
                                    break;
                                }
                                break;
                            case 97526364:
                                if (name.equals("float")) {
                                    c = 1;
                                    break;
                                }
                                break;
                        }
                        if (c == 0) {
                            edit.putBoolean(attributeValue, Boolean.parseBoolean(newPullParser.getAttributeValue(null, "value")));
                        } else if (c == 1) {
                            edit.putFloat(attributeValue, Float.parseFloat(newPullParser.getAttributeValue(null, "value")));
                        } else if (c == 2) {
                            edit.putInt(attributeValue, Integer.parseInt(newPullParser.getAttributeValue(null, "value")));
                        } else if (c == 3) {
                            edit.putLong(attributeValue, Long.parseLong(newPullParser.getAttributeValue(null, "value")));
                        } else if (c == 4) {
                            edit.putString(attributeValue, newPullParser.getAttributeValue(null, "value"));
                        }
                        skipXml(newPullParser);
                    }
                }
                edit.putBoolean(PreferenceKeys.FirstTimePreferenceKey, true);
                try {
                    edit.putInt(PreferenceKeys.LatestVersionPreferenceKey, this.main_activity.getPackageManager().getPackageInfo(this.main_activity.getPackageName(), 0).versionCode);
                } catch (PackageManager.NameNotFoundException e) {
                    Log.d(TAG, "NameNotFoundException exception trying to get version number");
                    e.printStackTrace();
                }
                edit.apply();
                if (!this.main_activity.is_test) {
                    this.main_activity.restartOpenCamera();
                }
                try {
                    inputStream.close();
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
                return true;
            } catch (Exception e3) {
                e3.printStackTrace();
                this.main_activity.getPreview().showToast((ToastBoxer) null, R.string.restore_settings_failed);
                try {
                    inputStream.close();
                } catch (IOException e4) {
                    e4.printStackTrace();
                }
                return false;
            }
        } catch (Throwable th) {
            try {
                inputStream.close();
            } catch (IOException e5) {
                e5.printStackTrace();
            }
            throw th;
        }
    }

    private static void skipXml(XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
        if (xmlPullParser.getEventType() != 2) {
            throw new IllegalStateException();
        }
        int i = 1;
        while (i != 0) {
            int next = xmlPullParser.next();
            if (next == 2) {
                i++;
            } else if (next == 3) {
                i--;
            }
        }
    }

    public void saveSettings(String s) {
        String s2;
        FileOutputStream fileOutputStream0 = null;
        Log.d("SettingsManager", "saveSettings: " + s);
        try {
            StorageUtils storageUtils0 = this.main_activity.getStorageUtils();
            File file0 = storageUtils0.getSettingsFolder();
            storageUtils0.createFolderIfRequired(file0);
            File file1 = new File(file0.getPath() + File.separator + s);
            this.main_activity.test_save_settings_file = file1.getAbsolutePath();
            fileOutputStream0 = new FileOutputStream(file1);
            XmlSerializer xmlSerializer0 = Xml.newSerializer();
            StringWriter stringWriter0 = new StringWriter();
            xmlSerializer0.setOutput(stringWriter0);
            xmlSerializer0.startDocument("UTF-8", Boolean.valueOf(true));
            xmlSerializer0.startTag(null, "open_camera_prefs");
            for (Object object0 : PreferenceManager.getDefaultSharedPreferences(this.main_activity).getAll().entrySet()) {
                Map.Entry map$Entry0 = (Map.Entry) object0;
                String s1 = (String) map$Entry0.getKey();
                Object object1 = map$Entry0.getValue();
                if (s1 == null) {
                    continue;
                }

                if ((object1 instanceof Boolean)) {
                    s2 = "boolean";
                } else if ((object1 instanceof Float)) {
                    s2 = "float";
                } else if ((object1 instanceof Integer)) {
                    s2 = "int";
                } else if ((object1 instanceof Long)) {
                    s2 = "long";
                } else if ((object1 instanceof String)) {
                    s2 = "string";
                } else {
//                    Log.e("SettingsManager", AnLZaZYK.avh + object1);
                    s2 = null;
                }

                if (s2 == null) {
                    continue;
                }

                xmlSerializer0.startTag(null, s2);
                xmlSerializer0.attribute(null, "key", s1);
                if (object1 != null) {
                    xmlSerializer0.attribute(null, "value", object1.toString());
                }

                xmlSerializer0.endTag(null, s2);
            }

            xmlSerializer0.endTag(null, "open_camera_prefs");
            xmlSerializer0.endDocument();
            xmlSerializer0.flush();
            Charset charset0 = Charset.forName("UTF-8");
            fileOutputStream0.write(stringWriter0.toString().getBytes(charset0));
            this.main_activity.getPreview().showToast(null, R.string.saved_settings);  // string:saved_settings "Saved settings"
            storageUtils0.broadcastFile(file1, false, false, false);
            fileOutputStream0.close();
        } catch (IOException iOException0) {
            iOException0.printStackTrace();
            this.main_activity.getPreview().showToast(null, R.string.save_settings_failed);  // string:save_settings_failed "Failed to save settings"
            if (fileOutputStream0 != null) {
                try {
                    fileOutputStream0.close();
                    return;
                } catch (IOException iOException1) {
                    iOException1.printStackTrace();
                }
            }
        }
    }
}
