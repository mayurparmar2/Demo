package com.live.gpsmap.camera.Utils;

import android.os.Environment;

/* loaded from: classes2.dex */
public class Default {


    public static final String CAMERA_FOLDER = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).toString() + "/Camera";


    public static final String ADDRESS = "address";
    public static final String AUTOMATIC = "Automatic";
    public static final int BOUNDARY = 3;
    public static final String CUSTOM1 = "name1";
    public static final String CUSTOM2 = "name2";
    public static final String CUSTOM3 = "name3";
    public static final String CUSTUM_NAME_1_VALUE = "ByGPSMapCamera";
    public static final String DATETIME = "datetime";
    public static final String DEFAULT_DATE_FORMAT = "dd/MM/yy hh:mm a";
    public static final String DEFAULT_FOLDER_NAME = "Default";
    public static final String DEFAULT_FONT_NAME = "Sf ui Text";
    public static final String DEFAULT_FONT_STYLE = "sfuitext_regular.otf";
    public static final String HYBRID_4 = "hybrid";
    public static final boolean IS_ACCURACY = false;
    public static final boolean IS_ADDRESS = true;
    public static final boolean IS_ALTITUDE = false;
    public static final boolean IS_COMPASS = false;
    public static final boolean IS_CUS_1 = true;
    public static final boolean IS_CUS_2 = false;
    public static final boolean IS_CUS_3 = false;
    public static final boolean IS_DATE_TIME = true;
    public static final boolean IS_ELEVATION = false;
    public static final boolean IS_HUMIDITY = false;
    public static final boolean IS_INCREMENT = true;
    public static final boolean IS_LAT_LNG_TEMPLATE = true;
    public static final boolean IS_LAT_LONG_FILE_NAME = false;
    public static final boolean IS_LOGO = false;
    public static final boolean IS_MAGNETIC_FIELD = false;
    public static final boolean IS_MAIN_ADDRESS_FILE_NAME = false;
    public static final boolean IS_MAIN_DT_FILE = true;
    public static final boolean IS_MAP = true;
    public static final boolean IS_NOTES = false;
    public static final boolean IS_NUMBERING = false;
    public static final boolean IS_PLUS_CODE = false;
    public static final boolean IS_PRESSURE = false;
    public static final boolean IS_SEQUENCE_FILE = false;
    public static final boolean IS_TIMEZONE = true;
    public static final boolean IS_WEATHER = false;
    public static final boolean IS_WIND = false;
    public static final String LANGUAGE = "English";
    public static final String LATLONG = "latlong";
    public static final int LAT_LNG_TYPE = 1;
    public static final String LOGO_uri = "no_logo";
    public static final String MANUAL = "Manual";
    public static final String NORMAL_1 = "roadmap";
    public static final String PLUSCODE_TYPE = "accurate";
    public static final String SEQUENCE = "sequence";
    public static final String SETELLITE_2 = "satellite";
    public static final String SITE_1 = "Site 1";
    public static final String SITE_2 = "Site 2";
    public static final String TEMPLATE_SIZE = "Medium";
    public static final String TERRAIN_3 = "terrain";
    public static final String notes = "Note : Captured by GPS Map Camera";
    public static final String notes_desc = "Captured by GPS Map Camera";
    public static final String notes_title = "Note :";
    public static final String DIR_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString() + "/";
    public static final String PARENT_FOLDER_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString() + "/GPS Map Camera/";
    public static final String DEFAULT_FOLDER_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString() + "/Camera";
    public static int ISEXITNATIVE = 1;
    public static boolean isEGMGridLoaded = false;
    public static int COUNT = 0;
    public static short[][] EGMGrid = null;
    public static int WHITEBALANCE = 0;
    public static int SCENEMODE = 0;
    public static int IN_APP_REVIEW = 0;
}