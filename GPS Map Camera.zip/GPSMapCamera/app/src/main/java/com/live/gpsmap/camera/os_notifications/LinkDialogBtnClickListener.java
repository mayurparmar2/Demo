package com.live.gpsmap.camera.os_notifications;

/* loaded from: classes3.dex */
public interface LinkDialogBtnClickListener {
    void onLinkBtnClicked(String str);
}
