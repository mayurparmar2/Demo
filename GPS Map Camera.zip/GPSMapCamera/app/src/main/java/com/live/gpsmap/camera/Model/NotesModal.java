package com.live.gpsmap.camera.Model;

public class NotesModal {
    int ID;
    String Notes;
    int Selected;
    String Tiitle;

    public int getID() {
        return this.ID;
    }

    public void setID(int i) {
        this.ID = i;
    }

    public String getTiitle() {
        return this.Tiitle;
    }

    public void setTiitle(String str) {
        this.Tiitle = str;
    }

    public String getNotes() {
        return this.Notes;
    }

    public void setNotes(String str) {
        this.Notes = str;
    }

    public int getSelected() {
        return this.Selected;
    }

    public void setSelected(int i) {
        this.Selected = i;
    }
}