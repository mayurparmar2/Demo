package com.live.gpsmap.camera.Utils.Helper;

import android.os.SystemClock;
import android.view.View;

public abstract class SingleClickListener implements View.OnClickListener {
    protected int defaultInterval;
    private long lastTimeClicked;

    public abstract void performClick(View view);

    public SingleClickListener() {
        this(1000);
    }

    public SingleClickListener(int i) {
        this.lastTimeClicked = 0L;
        this.defaultInterval = i;
    }

    @Override
    public void onClick(View view) {
        if (SystemClock.elapsedRealtime() - this.lastTimeClicked < this.defaultInterval) {
            return;
        }
        this.lastTimeClicked = SystemClock.elapsedRealtime();
        performClick(view);
    }
}