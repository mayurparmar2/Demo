package com.live.gpsmap.camera.Activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchaseHistoryRecord;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.live.gpsmap.camera.Camera.CameraMainActivity;
import com.live.gpsmap.camera.Camera.utils.NetworkState;
import com.live.gpsmap.camera.Model.PurchaseModel;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Receiver.AlarmReceiver;
import com.live.gpsmap.camera.Utils.Helper.PurchaseHelper;
import com.live.gpsmap.camera.Utils.Helper.SearchHelper;
import com.live.gpsmap.camera.Utils.Helper.SingleClickListener;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.Utils.Util;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

@SuppressWarnings("All")
public class InAppPurchaseActivity extends AppCompatActivity implements View.OnClickListener, PurchasesUpdatedListener {
    LinearLayout btn_premium;
    LinearLayout btn_standard;
    ImageView imag_remove_ads;
    boolean isPurchaseQueryPending;
    LinearLayout lin_remove_ads;
    LinearLayout lin_stand_prem;
    LinearLayout lin_tablayout;
    private Button mBtn_purchase;
    private Util mHelperClass;
    private SP mSP;
    private RelativeLayout mToolbar_back;
    LinearLayout main_layout;
    SP msp;
    private TextView mtvPrice;
    List<PurchaseHistoryRecord> purchaseHistory;
    PurchaseHelper purchaseInAppHelper;
    PurchaseModel purchaseModel;
    private TextView txt_mesg;
    private TextView txt_premium;
    private TextView txt_standard;
    private TextView txt_title_inapp;
    LinearLayout view_premium;
    LinearLayout view_standard;
    ArrayList<PurchaseModel> purchase_list = new ArrayList<>();
    int pro_flag = 0;
    List<String> tempList = new ArrayList();

    @Override // com.android.billingclient.api.PurchasesUpdatedListener
    public void onPurchasesUpdated(BillingResult billingResult, List<Purchase> list) {
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.mHelperClass = new Util();
        this.mSP = new SP(this);
        this.mHelperClass.SetLanguage(this);
        setContentView(R.layout.activity_in_app_purchase);
        this.tempList.add(getResources().getString(R.string.PRODUCT_ID_ALL));
        this.tempList.add(getResources().getString(R.string.PRODUCT_ID_WITH_AD));
        this.tempList.add(getResources().getString(R.string.PRODUCT_ID_AD));
        init();
    }

    private void init() {
        this.msp = new SP(this);
        this.mToolbar_back = (RelativeLayout) findViewById(R.id.toolbar_back);
        this.mtvPrice = (TextView) findViewById(R.id.tv_inapp_price);
        this.txt_standard = (TextView) findViewById(R.id.txt_standard);
        this.txt_premium = (TextView) findViewById(R.id.txt_premium);
        this.mBtn_purchase = (Button) findViewById(R.id.btn_purchase);
        this.txt_title_inapp = (TextView) findViewById(R.id.txt_title_inapp);
        this.view_standard = (LinearLayout) findViewById(R.id.view_standard);
        this.view_premium = (LinearLayout) findViewById(R.id.view_premium);
        this.main_layout = (LinearLayout) findViewById(R.id.main_layout);
        this.imag_remove_ads = (ImageView) findViewById(R.id.imag_remove_ads);
        this.btn_standard = (LinearLayout) findViewById(R.id.btn_standard);
        this.btn_premium = (LinearLayout) findViewById(R.id.btn_premium);
        this.lin_tablayout = (LinearLayout) findViewById(R.id.lin_tablayout);
        this.lin_stand_prem = (LinearLayout) findViewById(R.id.lin_stand_prem);
        this.lin_remove_ads = (LinearLayout) findViewById(R.id.lin_remove_ads);
        this.txt_mesg = (TextView) findViewById(R.id.txt_mesg);
        checkInApp();
        this.mToolbar_back.setOnClickListener(this);
        if (this.msp.getBoolean(this, "is_use_all_function", false) && !this.msp.getBoolean(this, "isPurcheshOrNot", false)) {
            this.pro_flag = 1;
            ads_remove_view();
        } else {
            premium_view();
        }
        this.btn_premium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InAppPurchaseActivity.this.premium_view();
                if (InAppPurchaseActivity.this.purchase_list.size() > 0) {
                    for (int i = 0; i < InAppPurchaseActivity.this.purchase_list.size(); i++) {
                        if (InAppPurchaseActivity.this.purchase_list.get(i).getPakageid().equals(InAppPurchaseActivity.this.getResources().getString(R.string.PRODUCT_ID_ALL))) {
                            InAppPurchaseActivity inAppPurchaseActivity = InAppPurchaseActivity.this;
                            inAppPurchaseActivity.purchaseModel = inAppPurchaseActivity.purchase_list.get(i);
                            InAppPurchaseActivity.this.mtvPrice.setText(InAppPurchaseActivity.this.purchase_list.get(i).getPrice());
                        }
                    }
                }
            }
        });
        this.btn_standard.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.InAppPurchaseActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                InAppPurchaseActivity.this.stander_view();
                if (InAppPurchaseActivity.this.purchase_list.size() > 0) {
                    for (int i = 0; i < InAppPurchaseActivity.this.purchase_list.size(); i++) {
                        if (InAppPurchaseActivity.this.purchase_list.get(i).getPakageid().equals(InAppPurchaseActivity.this.getResources().getString(R.string.PRODUCT_ID_WITH_AD))) {
                            InAppPurchaseActivity inAppPurchaseActivity = InAppPurchaseActivity.this;
                            inAppPurchaseActivity.purchaseModel = inAppPurchaseActivity.purchase_list.get(i);
                            InAppPurchaseActivity.this.mtvPrice.setText(InAppPurchaseActivity.this.purchase_list.get(i).getPrice());
                        }
                    }
                }
            }
        });
        this.mBtn_purchase.setOnClickListener(new SingleClickListener() {
            @Override // com.gpsmapcamera.geotagginglocationonphoto.helper.SingleClickListener
            public void performClick(View view) {
                if (InAppPurchaseActivity.this.purchaseInAppHelper == null || InAppPurchaseActivity.this.purchaseModel == null) {
                    return;
                }
                if (InAppPurchaseActivity.this.purchaseModel.getPakageid().equals(InAppPurchaseActivity.this.getResources().getString(R.string.PRODUCT_ID_AD))) {
                    InAppPurchaseActivity.this.dialog();
                    InAppPurchaseActivity inAppPurchaseActivity = InAppPurchaseActivity.this;
//                    FBAnalyticsEventUtils.registerEvent(inAppPurchaseActivity, inAppPurchaseActivity.getString(R.string.standard_buy_now_btn_click), InAppPurchaseActivity.this.getString(R.string.standard_buy_now_btn_click), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
                    if (InAppPurchaseActivity.this.mSP.getBoolean(InAppPurchaseActivity.this, "PURCHASE_3_TIME_SHOWN_STAN", false)) {
                        return;
                    }
                    int integer = InAppPurchaseActivity.this.mSP.getInteger(InAppPurchaseActivity.this, "PURCHASE_3_TIME_CLICK_STAN", 0) + 1;
                    if (integer == 3) {
                        AlarmReceiver alarmReceiver = new AlarmReceiver();
                        Calendar calendar = Calendar.getInstance();
                        calendar.set(11, 21);
                        calendar.set(12, 0);
                        calendar.set(13, 0);
                        calendar.set(14, 0);
                        alarmReceiver.setAlarm(InAppPurchaseActivity.this, calendar.getTimeInMillis(), 66);
                        InAppPurchaseActivity.this.mSP.setBoolean(InAppPurchaseActivity.this, "PURCHASE_3_TIME_SHOWN_STAN", true);
                        return;
                    }
                    InAppPurchaseActivity.this.mSP.setInteger(InAppPurchaseActivity.this, "PURCHASE_3_TIME_CLICK_STAN", integer);
                    return;
                }
                InAppPurchaseActivity.this.purchaseInAppHelper.launchBillingFLow(InAppPurchaseActivity.this.purchaseModel.getProductDetails());
                InAppPurchaseActivity inAppPurchaseActivity2 = InAppPurchaseActivity.this;
//                FBAnalyticsEventUtils.registerEvent(inAppPurchaseActivity2, inAppPurchaseActivity2.getString(R.string.premium_buy_now_btn_click), InAppPurchaseActivity.this.getString(R.string.premium_buy_now_btn_click), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
                if (InAppPurchaseActivity.this.mSP.getBoolean(InAppPurchaseActivity.this, "PURCHASE_3_TIME_SHOWN", false)) {
                    return;
                }
                int integer2 = InAppPurchaseActivity.this.mSP.getInteger(InAppPurchaseActivity.this, "PURCHASE_3_TIME_CLICK", 0) + 1;
                if (integer2 == 3) {
                    AlarmReceiver alarmReceiver2 = new AlarmReceiver();
                    Calendar calendar2 = Calendar.getInstance();
                    calendar2.set(11, 21);
                    calendar2.set(12, 0);
                    calendar2.set(13, 0);
                    calendar2.set(14, 0);
                    alarmReceiver2.setAlarm(InAppPurchaseActivity.this, calendar2.getTimeInMillis(), 65);
                    InAppPurchaseActivity.this.mSP.setBoolean(InAppPurchaseActivity.this, "PURCHASE_3_TIME_SHOWN", true);
                    return;
                }
                InAppPurchaseActivity.this.mSP.setInteger(InAppPurchaseActivity.this, "PURCHASE_3_TIME_CLICK", integer2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void dialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("With Standard Purchase, Ads will be there!  You are purchasing for New Folders, Add file name, Colors & No Watermark.");
        builder.setPositiveButton("Buy Now", new DialogInterface.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.InAppPurchaseActivity.4
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                InAppPurchaseActivity.this.purchaseInAppHelper.launchBillingFLow(InAppPurchaseActivity.this.purchaseModel.getProductDetails());
            }
        });
        builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.InAppPurchaseActivity.5
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.create().show();
    }

    private void ads_remove_view() {
        this.txt_mesg.setText(getResources().getString(R.string.pro_mes));
        this.lin_tablayout.setVisibility(View.GONE);
        this.txt_title_inapp.setText(getResources().getString(R.string.upgrade_gps_map_camera));
        this.txt_title_inapp.setTextColor(getResources().getColor(R.color._2bdb21));
        this.lin_stand_prem.setVisibility(View.GONE);
        this.lin_remove_ads.setVisibility(View.VISIBLE);
        this.txt_title_inapp.setTextColor(getResources().getColor(R.color._2bdb21));
        this.mBtn_purchase.setBackground(getResources().getDrawable(R.drawable.rect_inapp_green));
        this.main_layout.setBackground(getResources().getDrawable(R.drawable.green_grad_inapp));
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.addFlags(Integer.MIN_VALUE);
            window.setStatusBarColor(getResources().getColor(R.color._DCE5DC));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void premium_view() {
        this.txt_standard.setTextColor(getResources().getColor(R.color._030303));
        this.txt_premium.setTextColor(getResources().getColor(R.color._ffcc00));
        this.view_premium.setVisibility(View.VISIBLE);
        this.view_standard.setVisibility(View.GONE);
        this.lin_remove_ads.setVisibility(View.GONE);
        this.lin_stand_prem.setVisibility(View.VISIBLE);
        this.imag_remove_ads.setImageResource(R.drawable.ic_tick);
        this.txt_title_inapp.setText(getResources().getString(R.string.gps_camera_premium));
        this.txt_title_inapp.setTextColor(getResources().getColor(R.color._ffcc00));
        this.mBtn_purchase.setBackground(getResources().getDrawable(R.drawable.rect_inapp));
        this.main_layout.setBackground(getResources().getDrawable(R.drawable.yellow_grad_inapp));
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.addFlags(Integer.MIN_VALUE);
            window.setStatusBarColor(getResources().getColor(R.color._E5E0CC));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stander_view() {
        this.txt_standard.setTextColor(getResources().getColor(R.color._0086ff));
        this.txt_premium.setTextColor(getResources().getColor(R.color._030303));
        this.view_premium.setVisibility(View.GONE);
        this.view_standard.setVisibility(View.VISIBLE);
        this.lin_remove_ads.setVisibility(View.GONE);
        this.lin_stand_prem.setVisibility(View.VISIBLE);
        this.imag_remove_ads.setImageResource(R.drawable.ic_cancel);
        this.txt_title_inapp.setText(getResources().getString(R.string.gps_camera_standard));
        this.txt_title_inapp.setTextColor(getResources().getColor(R.color._0086ff));
        this.mBtn_purchase.setBackground(getResources().getDrawable(R.drawable.rect_inapp_skycolor));
        this.main_layout.setBackground(getResources().getDrawable(R.drawable.skyblue_grad_inapp));
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.addFlags(Integer.MIN_VALUE);
            window.setStatusBarColor(getResources().getColor(R.color._CAD8E4));
        }
    }

    private void checkInApp() {
        if (NetworkState.Companion.isOnline(this)) {
            this.purchaseInAppHelper = new PurchaseHelper(this, getInAppHelperListener());
            loadData();
        }
    }

    public PurchaseHelper.PurchaseHelperListener getInAppHelperListener() {
        return new PurchaseHelper.PurchaseHelperListener() {
            @Override
            public void onServiceConnected(int i) {
                if (InAppPurchaseActivity.this.isPurchaseQueryPending) {
                    InAppPurchaseActivity.this.purchaseInAppHelper.getPurchasedItems("inapp");
                    InAppPurchaseActivity.this.isPurchaseQueryPending = false;
                }
            }

            @Override // com.gpsmapcamera.geotagginglocationonphoto.helper.PurchaseHelper.PurchaseHelperListener
            public void onProductQueryResponse(List<ProductDetails> list) {
                if (list == null || list.isEmpty()) {
                    return;
                }
                InAppPurchaseActivity.this.purchase_list.clear();
                int i = 0;
                for (ProductDetails productDetails : list) {
                    if (productDetails.getProductId().equals(InAppPurchaseActivity.this.getResources().getString(R.string.PRODUCT_ID_ALL))) {
                        PurchaseModel purchaseModel = new PurchaseModel(1, 1);
                        purchaseModel.setPrice(productDetails.getOneTimePurchaseOfferDetails().getFormattedPrice());
                        purchaseModel.setProductDetails(productDetails);
                        purchaseModel.setPakageid(InAppPurchaseActivity.this.getResources().getString(R.string.PRODUCT_ID_ALL));
                        InAppPurchaseActivity.this.purchase_list.add(purchaseModel);
                    }
                    if (productDetails.getProductId().equals(InAppPurchaseActivity.this.getResources().getString(R.string.PRODUCT_ID_AD))) {
                        PurchaseModel purchaseModel2 = new PurchaseModel(3, 0);
                        purchaseModel2.setPrice(productDetails.getOneTimePurchaseOfferDetails().getFormattedPrice());
                        purchaseModel2.setProductDetails(productDetails);
                        purchaseModel2.setPakageid(InAppPurchaseActivity.this.getResources().getString(R.string.PRODUCT_ID_AD));
                        InAppPurchaseActivity.this.purchase_list.add(purchaseModel2);
                    }
                    if (productDetails.getProductId().equals(InAppPurchaseActivity.this.getResources().getString(R.string.PRODUCT_ID_WITH_AD))) {
                        PurchaseModel purchaseModel3 = new PurchaseModel(2, 0);
                        purchaseModel3.setPrice(productDetails.getOneTimePurchaseOfferDetails().getFormattedPrice());
                        purchaseModel3.setProductDetails(productDetails);
                        purchaseModel3.setPakageid(InAppPurchaseActivity.this.getResources().getString(R.string.PRODUCT_ID_WITH_AD));
                        InAppPurchaseActivity.this.purchase_list.add(purchaseModel3);
                    }
                    i++;
                    if (i == list.size()) {
                        for (int i2 = 0; i2 < InAppPurchaseActivity.this.purchase_list.size(); i2++) {
                            if (InAppPurchaseActivity.this.pro_flag == 1) {
                                if (InAppPurchaseActivity.this.purchase_list.get(i2).getPakageid().equals(InAppPurchaseActivity.this.getResources().getString(R.string.PRODUCT_ID_AD))) {
                                    InAppPurchaseActivity inAppPurchaseActivity = InAppPurchaseActivity.this;
                                    inAppPurchaseActivity.purchaseModel = inAppPurchaseActivity.purchase_list.get(i2);
                                    InAppPurchaseActivity.this.mtvPrice.setText(InAppPurchaseActivity.this.purchase_list.get(i2).getPrice());
                                }
                            } else if (InAppPurchaseActivity.this.purchase_list.get(i2).getPakageid().equals(InAppPurchaseActivity.this.getResources().getString(R.string.PRODUCT_ID_ALL))) {
                                InAppPurchaseActivity inAppPurchaseActivity2 = InAppPurchaseActivity.this;
                                inAppPurchaseActivity2.purchaseModel = inAppPurchaseActivity2.purchase_list.get(i2);
                                InAppPurchaseActivity.this.mtvPrice.setText(InAppPurchaseActivity.this.purchase_list.get(i2).getPrice());
                            }
                        }
                    }
                }
            }

            @Override // com.gpsmapcamera.geotagginglocationonphoto.helper.PurchaseHelper.PurchaseHelperListener
            public void onPurchasehistoryResponse(List<PurchaseHistoryRecord> list) {
                InAppPurchaseActivity.this.purchaseHistory = list;
                if (InAppPurchaseActivity.this.purchaseHistory != null) {
                    List<String> arrayList = new ArrayList<>();
                    arrayList.add(InAppPurchaseActivity.this.getResources().getString(R.string.PRODUCT_ID_ALL));
                    arrayList.add(InAppPurchaseActivity.this.getResources().getString(R.string.PRODUCT_ID_WITH_AD));
                    arrayList.add(InAppPurchaseActivity.this.getResources().getString(R.string.PRODUCT_ID_AD));
                    ArrayList<String> arrayList2 = new ArrayList(arrayList);
                    Log.e("::MG::DDD1", "tempSkuList:" + arrayList2);
                    List<String> purchasedProductIdListing = SearchHelper.getPurchasedProductIdListing(InAppPurchaseActivity.this.purchaseHistory);
                    if (purchasedProductIdListing.size() > 0) {
                        Log.e("DDD1", "::::::" + purchasedProductIdListing);
                        arrayList2.retainAll(purchasedProductIdListing);
                        for (String str : arrayList2) {
                            Log.e("A_SUBCHECK", "Already Purchased:" + str);
                            for (int i = 0; i < InAppPurchaseActivity.this.tempList.size(); i++) {
                                if (str.equals(InAppPurchaseActivity.this.tempList.get(i))) {
                                    InAppPurchaseActivity.this.setSharedpr(i, true);
                                }
                            }
                        }
                        arrayList.removeAll(purchasedProductIdListing);
                    }
                    for (String str2 : arrayList) {
                        Log.e("A_SUBCHECK", "Yet to purchase:" + str2);
                        for (int i2 = 0; i2 < InAppPurchaseActivity.this.tempList.size(); i2++) {
                            if (str2.equals(InAppPurchaseActivity.this.tempList.get(i2))) {
                                InAppPurchaseActivity.this.setSharedpr(i2, false);
                            }
                        }
                    }
                    if (arrayList.size() > 0) {
                        InAppPurchaseActivity.this.purchaseInAppHelper.getSkuDetails(arrayList, "inapp");
                    }
                }
            }

            @Override // com.gpsmapcamera.geotagginglocationonphoto.helper.PurchaseHelper.PurchaseHelperListener
            public void onPurchasesUpdated(BillingResult billingResult, List<Purchase> list) {
                if (billingResult.getResponseCode() != 0 || list == null) {
                    return;
                }
                for (Purchase purchase : list) {
                    InAppPurchaseActivity.this.purchaseInAppHelper.handlePurchase(purchase);
                    for (int i = 0; i < InAppPurchaseActivity.this.tempList.size(); i++) {
                        if (purchase.getProducts().get(0).equals(InAppPurchaseActivity.this.tempList.get(i))) {
                            InAppPurchaseActivity.this.setSharedpr(i, true);
                            InAppPurchaseActivity.this.createRestartDialog();
                        }
                    }
                }
            }
        };
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setSharedpr(int i, boolean z) {
        if (i == 0) {
            if (this.msp.getBoolean(this, "isPurcheshOrNot", false)) {
                return;
            }
            this.msp.setBoolean(this, "isPurcheshOrNot", z);
        } else if (i == 1) {
            this.msp.setBoolean(this, "is_use_all_function", z);
        } else if (i == 2 && !this.msp.getBoolean(this, "isPurcheshOrNot", false)) {
            this.msp.setBoolean(this, "isPurcheshOrNot", z);
        }
    }

    private void loadData() {
        PurchaseHelper purchaseHelper = this.purchaseInAppHelper;
        if (purchaseHelper != null && purchaseHelper.isServiceConnected()) {
            this.purchaseInAppHelper.getPurchasedItems("inapp");
        } else {
            this.isPurchaseQueryPending = true;
        }
    }

    public void createRestartDialog() {
        try {
            if (isFinishing()) {
                return;
            }
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getResources().getString(R.string.congratulations));
            builder.setMessage(getResources().getString(R.string.restart_msg));
            builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Intent intent = new Intent(InAppPurchaseActivity.this, CameraMainActivity.class);
                    intent.setFlags(268468224);
                    InAppPurchaseActivity.this.startActivity(intent);
                }
            });
            builder.setCancelable(false);
            builder.create().show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View view) {
        if (view.getId() != R.id.toolbar_back) {
            return;
        }
        finish();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        PurchaseHelper purchaseHelper = this.purchaseInAppHelper;
        if (purchaseHelper != null) {
            purchaseHelper.endConnection();
        }
    }
}