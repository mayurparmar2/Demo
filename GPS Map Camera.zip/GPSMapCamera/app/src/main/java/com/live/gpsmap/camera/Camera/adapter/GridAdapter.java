package com.live.gpsmap.camera.Camera.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.live.gpsmap.camera.Camera.PreferenceKeys;
import com.live.gpsmap.camera.Camera.onRecyclerClickListener;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.SP;


public class GridAdapter extends RecyclerView.Adapter<GridAdapter.MyViewHolder> {
    Context mContext;
    String[] mGrid_entries;
    onRecyclerClickListener mOnRecyclerClickListener;
    SP mSP;
    int selctedPos;

    public GridAdapter(Context context, String[] strArr, onRecyclerClickListener onrecyclerclicklistener) {
        this.mContext = context;
        this.mGrid_entries = strArr;
        SP sp = new SP(context);
        this.mSP = sp;
        this.mOnRecyclerClickListener = onrecyclerclicklistener;
        this.selctedPos = sp.getInteger(context, PreferenceKeys.GRID_POS, 0);
    }

    public void refreshAdapter(int i) {
        this.selctedPos = i;
        notifyDataSetChanged();
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.gride_list, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(MyViewHolder myViewHolder, @SuppressLint("RecyclerView") final int i) {
        if (myViewHolder instanceof MyViewHolder) {
            myViewHolder.tv_grid.setText(this.mGrid_entries[i]);
            if (this.selctedPos == i) {
                myViewHolder.tv_grid.setBackground(this.mContext.getResources().getDrawable(R.drawable.selected_back));
            } else {
                myViewHolder.tv_grid.setBackground(this.mContext.getResources().getDrawable(R.drawable.unselect_back));
            }
            myViewHolder.tv_grid.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (GridAdapter.this.mOnRecyclerClickListener != null) {
                        GridAdapter.this.mOnRecyclerClickListener.setOnItemClickListener(i, view);
                    }
                    GridAdapter.this.selctedPos = i;
                    GridAdapter.this.notifyDataSetChanged();
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return this.mGrid_entries.length;
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tv_grid;

        public MyViewHolder(View view) {
            super(view);
            this.tv_grid = (TextView) view.findViewById(R.id.tv_gride);
        }
    }
}
