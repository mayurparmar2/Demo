package com.live.gpsmap.camera.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.snackbar.Snackbar;
import com.live.gpsmap.camera.Adapter.AddFolderAdapter;
import com.live.gpsmap.camera.Camera.CameraMainActivity;
import com.live.gpsmap.camera.Camera.utils.NetworkState;
import com.live.gpsmap.camera.Fragment.FolderaddBottomsheetfragment;
import com.live.gpsmap.camera.Interface.OnRecyclerItemClickListener;
import com.live.gpsmap.camera.Model.FileGetSet;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Default;
import com.live.gpsmap.camera.Utils.Helper.SingleClickListener;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.Utils.Util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


@SuppressWarnings("All")
public class FolderActivity extends AppCompatActivity {
    private boolean IS_ADS;
    String ads_status;
    FolderaddBottomsheetfragment folderaddBottomsheetfragment;
    boolean is_original_image;
    boolean is_pro;
    public AddFolderAdapter mAdapter;
    private RecyclerView mAdd_Folder_Recyclerview;
    Util mHelperClass;
    private ImageView mImgPro;
    public String mSelectedVale;
    private SP mSp;
    private SwitchCompat mSwitch_on_off;
    private ImageView mToolbar_add;
    private RelativeLayout mToolbar_back;
    CameraMainActivity mainActivity;
    private TextView mtv_toolbar_title;
    public List<FileGetSet> mFolderList = new ArrayList();


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Util Util = new Util();
        this.mHelperClass = Util;
        Util.SetLanguage(this);
        setContentView(R.layout.activity_add_folder);
        init();
    }

    private void init() {
        SP sp = new SP(this);
        this.mSp = sp;
        boolean z = true;
        this.mSp.setInteger(this, "FOLDER_OPEN_TIME", sp.getInteger(this, "FOLDER_OPEN_TIME", 0) + 1);
        this.mainActivity = new CameraMainActivity();
        this.ads_status = new SP(this).getString(this, SP.ADS_STATUS, "1");
        this.IS_ADS = new SP(this).getBoolean(this, "isPurcheshOrNot", false);
        this.is_original_image = new SP(this).getBoolean(this, SP.IS_ORIGINAL_IMAGE, false);
        this.mToolbar_back = (RelativeLayout) findViewById(R.id.toolbar_back);
        this.mToolbar_add = (ImageView) findViewById(R.id.toolbar_add_img);
        this.mtv_toolbar_title = (TextView) findViewById(R.id.tv_toolbar_title);
        this.mImgPro = (ImageView) findViewById(R.id.imgPro_img);
        this.mSwitch_on_off = (SwitchCompat) findViewById(R.id.switch_on_off);
        this.mtv_toolbar_title.setText(getString(R.string.select_folder));
        this.mToolbar_add.setVisibility(View.VISIBLE);
        this.mAdd_Folder_Recyclerview = (RecyclerView) findViewById(R.id.add_folder_recyclerview);
        if (!this.mSp.getBoolean(this, "isPurcheshOrNot", false) && !this.mSp.getBoolean(this, "is_use_all_function", false)) {
            z = false;
        }
        this.is_pro = z;
        if (z) {
            this.mImgPro.setVisibility(View.GONE);
        } else {
            this.mImgPro.setVisibility(View.VISIBLE);
        }
        this.mSwitch_on_off.setChecked(this.is_original_image);
        this.mSelectedVale = this.mSp.getString(this, SP.FOLDER_PATH, Default.DEFAULT_FOLDER_PATH);
        FolderaddBottomsheetfragment folderaddBottomsheetfragment = new FolderaddBottomsheetfragment();
        this.folderaddBottomsheetfragment = folderaddBottomsheetfragment;
        folderaddBottomsheetfragment.setOnAddFolder(new FolderaddBottomsheetfragment.OnAddFolder() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FolderActivity.1
            @Override // com.gpsmapcamera.geotagginglocationonphoto.fragment.FolderaddBottomsheetfragment.OnAddFolder
            public void OnAdd(File file) {
                file.mkdir();
                FileGetSet fileGetSet = new FileGetSet();
                fileGetSet.setFilePath(file.getAbsolutePath());
                fileGetSet.setFileName(file.getName());
                FolderActivity.this.mFolderList.add(fileGetSet);
                FolderActivity.this.mSelectedVale = file.getAbsolutePath();
                if (FolderActivity.this.mAdapter != null) {
                    FolderActivity.this.mAdapter.refAdapter(FolderActivity.this.mFolderList, FolderActivity.this.mSelectedVale);
                }
            }
        });
        setAdapter();
        onClicks();
        loadAds();
    }

    private void loadAds() {
//        new Admob().loadAdaptive_banner(this, (RelativeLayout) findViewById(R.id.rel_adaptive_banner), getString(R.string.GMC_Banner_Details));
    }

    private void setAdapter() {
        fillData();
        this.mAdd_Folder_Recyclerview.setLayoutManager(new LinearLayoutManager(this, 1, false));
        AddFolderAdapter addFolderAdapter = new AddFolderAdapter(this, this.mFolderList, new OnRecyclerItemClickListener() {
            @Override
            public void OnClick_(int i, View view) {
                FolderActivity folderActivity = FolderActivity.this;
                folderActivity.mSelectedVale = folderActivity.mFolderList.get(i).getFilePath();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        FolderActivity.this.mAdapter.refAdapter(FolderActivity.this.mSelectedVale);
                    }
                }, 150L);
            }

            @Override
            public void OnLongClick_(int i, View view) {
                if (FolderActivity.this.mFolderList.get(i).getFileName().equals(Default.SITE_1) || FolderActivity.this.mFolderList.get(i).getFileName().equals(Default.SITE_2) || FolderActivity.this.mFolderList.get(i).getFileName().equals(Default.DEFAULT_FOLDER_NAME)) {
                    return;
                }
                FolderActivity.this.openDeleteDialog(i);
            }
        });
        this.mAdapter = addFolderAdapter;
        this.mAdd_Folder_Recyclerview.setAdapter(addFolderAdapter);
    }


    public void openDeleteDialog(final int i) {
        if (isFinishing()) {
            return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.delete_dialog_title));
        builder.setMessage(getString(R.string.delete_dialog_message));
        builder.setPositiveButton(getString(R.string.delete), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i2) {
                File file = new File(FolderActivity.this.mFolderList.get(i).getFilePath());
                if (file.exists()) {
                    FolderActivity.this.mFolderList.remove(i);
                    if (file.getAbsolutePath().equals(FolderActivity.this.mSelectedVale)) {
                        FolderActivity.this.mSelectedVale = Default.DEFAULT_FOLDER_PATH;
                        FolderActivity.this.mAdapter.refAdapter(FolderActivity.this.mFolderList, FolderActivity.this.mSelectedVale);
                        SP sp = FolderActivity.this.mSp;
                        FolderActivity folderActivity = FolderActivity.this;
                        sp.setString(folderActivity, SP.FOLDER_PATH, folderActivity.mSelectedVale);
                    } else {
                        FolderActivity.this.mAdapter.refAdapter(FolderActivity.this.mFolderList, FolderActivity.this.mSelectedVale);
                    }
                    FolderActivity.this.deleteFile(file);
                }
                dialogInterface.dismiss();
            }
        });
        builder.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i2) {
                dialogInterface.dismiss();
            }
        });
        builder.create().show();
    }


    public void deleteFile(File file) {
        File[] listFiles;
        if (file.isDirectory()) {
            for (File file2 : file.listFiles()) {
                file2.delete();
                deleteFile(file2);
            }
        }
        file.delete();
    }

    private void fillData() {
        this.mFolderList.clear();
        FileGetSet fileGetSet = new FileGetSet();
        fileGetSet.setFileName(Default.DEFAULT_FOLDER_NAME);
        fileGetSet.setFilePath(Default.DEFAULT_FOLDER_PATH);
        this.mFolderList.add(fileGetSet);
        int i = 0;
        if (!this.is_pro) {
            File[] listFiles = new File(Default.PARENT_FOLDER_PATH).listFiles();
            if (listFiles == null || listFiles.length <= 0) {
                return;
            }
            while (i < listFiles.length) {
                if (listFiles[i].getName().equals(Default.SITE_1) || listFiles[i].getName().equals(Default.SITE_2)) {
                    FileGetSet fileGetSet2 = new FileGetSet();
                    fileGetSet2.setFileName(listFiles[i].getName());
                    fileGetSet2.setFilePath(listFiles[i].getAbsolutePath());
                    this.mFolderList.add(fileGetSet2);
                }
                i++;
            }
            return;
        }
        File[] listFiles2 = new File(Default.PARENT_FOLDER_PATH).listFiles();
        if (listFiles2 == null || listFiles2.length <= 0) {
            return;
        }
        while (i < listFiles2.length) {
            FileGetSet fileGetSet3 = new FileGetSet();
            fileGetSet3.setFileName(listFiles2[i].getName());
            fileGetSet3.setFilePath(listFiles2[i].getAbsolutePath());
            this.mFolderList.add(fileGetSet3);
            i++;
        }
    }

    private void onClicks() {
        this.mToolbar_back.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View view) {
                FolderActivity.this.onBackPressed();
            }
        });
        this.mSwitch_on_off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (FolderActivity.this.is_original_image) {
                    FolderActivity.this.is_original_image = false;
                } else {
                    FolderActivity.this.is_original_image = true;
                }
                FolderActivity.this.mSwitch_on_off.setChecked(FolderActivity.this.is_original_image);
            }
        });
        this.mToolbar_add.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View view) {
                FolderActivity.this.addFolderDialog();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void addFolderDialog() {
        FolderaddBottomsheetfragment folderaddBottomsheetfragment;
        if (isFinishing() || this.folderaddBottomsheetfragment.isAdded() || (folderaddBottomsheetfragment = this.folderaddBottomsheetfragment) == null) {
            return;
        }
        folderaddBottomsheetfragment.show(getSupportFragmentManager(), FolderaddBottomsheetfragment.TAG);
    }

    private void confirmDialog() {
        if (isFinishing()) {
            return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getString(R.string.discard_message));
        builder.setPositiveButton(getString(R.string.save), new DialogInterface.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FolderActivity.8
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                FolderActivity.this.checkInApp();
                dialogInterface.dismiss();
            }
        });
        builder.setNegativeButton(getString(R.string.discard), new DialogInterface.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FolderActivity.9
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                FolderActivity.this.getexitads();
            }
        });
        builder.create().show();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (!this.mSelectedVale.equals(this.mSp.getString(this, SP.FOLDER_PATH, Default.DEFAULT_FOLDER_PATH)) || this.mSp.getBoolean(this, SP.IS_ORIGINAL_IMAGE, false) != this.mSwitch_on_off.isChecked()) {
            checkInApp();
        } else {
            getexitads();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void getexitads() {
//        int integer = this.mSp.getInteger(this, Util.COUNTADS, 0);
//        if (!this.ads_status.equals("1") || this.IS_ADS) {
//            finish();
//        } else if (integer == 2) {
//            if (NetworkState.Companion.isOnline(this)) {
//                Util.showProgressDialog(this, "Loading...");
//                new Handler().postDelayed(new Runnable() {
//                    @Override // java.lang.Runnable
//                    public void run() {
//                        FolderActivity.this.mSp.setInteger(FolderActivity.this, Util.COUNTADS, 0);
//                        FolderActivity folderActivity = FolderActivity.this;
//                        folderActivity.inrequestadd(folderActivity);
//                    }
//                }, 200L);
//                new Handler().postDelayed(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FolderActivity.11
//                    @Override // java.lang.Runnable
//                    public void run() {
//                        Util.dismissProgressDialog();
//                        if (FolderActivity.this.mInterstitialAd != null) {
//                            FolderActivity.this.mInterstitialAd.show(FolderActivity.this);
//                        } else {
//                            FolderActivity.this.finish();
//                        }
//                    }
//                }, 7000L);
//                return;
//            }
//            finish();
//        } else {
//            this.mSp.setInteger(this, Util.COUNTADS, integer + 1);
//            finish();
//        }

        FolderActivity.this.finish();
    }

    /* JADX INFO: Access modifiers changed from: private */
//    public void inrequestadd(Context context) {
//        try {
//            InterstitialAd.load(this, getResources().getString(R.string.TC_3_click_FS), new AdRequest.Builder().build(), new InterstitialAdLoadCallback() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FolderActivity.12
//                @Override // com.google.android.gms.ads.AdLoadCallback
//                public void onAdLoaded(InterstitialAd interstitialAd) {
//                    FolderActivity.this.mInterstitialAd = interstitialAd;
//                    setFullScreenContentCallback();
//                    if (FolderActivity.this.mInterstitialAd != null) {
//                        FolderActivity.this.mInterstitialAd.show(FolderActivity.this);
//                    }
//                }
//
//                private void setFullScreenContentCallback() {
//                    FolderActivity.this.mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FolderActivity.12.1
//                        @Override // com.google.android.gms.ads.FullScreenContentCallback
//                        public void onAdDismissedFullScreenContent() {
//                            Log.d("TAG", "The ad was dismissed.");
//                            Util.dismissProgressDialog();
//                            FolderActivity.this.finish();
//                        }
//
//                        @Override // com.google.android.gms.ads.FullScreenContentCallback
//                        public void onAdFailedToShowFullScreenContent(AdError adError) {
//                            Log.d("TAG", "The ad failed to show.");
//                            FolderActivity.this.finish();
//                        }
//
//                        @Override // com.google.android.gms.ads.FullScreenContentCallback
//                        public void onAdShowedFullScreenContent() {
//                            FolderActivity.this.mInterstitialAd = null;
//                            Log.d("TAG", "The ad was shown.");
//                        }
//                    });
//                }
//
//                @Override // com.google.android.gms.ads.AdLoadCallback
//                public void onAdFailedToLoad(LoadAdError loadAdError) {
//                    FolderActivity.this.mInterstitialAd = null;
//                }
//            });
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    private void saveData() {
        String string = this.mSp.getString(this, SP.FOLDER_PATH, Default.DEFAULT_FOLDER_PATH);
        this.mSp.setString(this, SP.FOLDER_PATH, this.mSelectedVale);
        this.mSp.setBoolean(this, SP.IS_ORIGINAL_IMAGE, this.is_original_image);
        if (!this.mSelectedVale.equals(string)) {
            pathDialog();
        } else {
            getexitads();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void checkInApp() {
        if (this.is_pro) {
            saveData();
            return;
        }
        if (!this.mSelectedVale.equals(Default.DEFAULT_FOLDER_PATH)) {
            String str = this.mSelectedVale;
            if (!str.equals("" + Default.PARENT_FOLDER_PATH + Default.SITE_1)) {
                String str2 = this.mSelectedVale;
                if (!str2.equals("" + Default.PARENT_FOLDER_PATH + Default.SITE_2)) {
                    createInAppDialog();
                    return;
                }
            }
        }
        saveData();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void createInAppDialog() {
        if (isFinishing()) {
            return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getString(R.string.add_folder_inapp_msg));
        builder.setPositiveButton(getString(R.string.pro), new DialogInterface.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FolderActivity.13
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                if (NetworkState.Companion.isOnline(FolderActivity.this)) {
                    FolderActivity.this.startActivity(new Intent(FolderActivity.this, InAppPurchaseActivity.class));
                } else {
                    RelativeLayout relativeLayout = FolderActivity.this.mToolbar_back;
                    Snackbar.make(relativeLayout, "" + FolderActivity.this.getString(R.string.no_internet_msg), -1).show();
                }
                dialogInterface.dismiss();
            }
        });
        builder.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FolderActivity.14
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.create().show();
    }

    void pathDialog() {
        if (isFinishing()) {
            return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.folder_path));
        builder.setMessage(this.mSelectedVale);
        builder.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                FolderActivity.this.finish();
            }
        });
        final AlertDialog create = builder.create();
        create.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                create.getButton(-1).setTextColor(FolderActivity.this.getResources().getColor(R.color._3D3D3D));
            }
        });
        create.show();
    }
}