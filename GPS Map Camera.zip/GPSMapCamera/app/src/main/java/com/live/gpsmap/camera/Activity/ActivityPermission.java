package com.live.gpsmap.camera.Activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.karumi.dexter.BuildConfig;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.live.gpsmap.camera.Camera.CameraMainActivity;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.Utils.Util;
import com.live.gpsmap.camera.databinding.ActivityPermissionBinding;

import java.util.List;

public class ActivityPermission extends AppCompatActivity {
    ActivityPermissionBinding binding;
    SP mSP;
    AlertDialog alertSimpleDialog;
    int isactivityopen = 0;
    public int isStoragePermission = 0;
    boolean doubleBackToExitPressedOnce = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPermissionBinding.inflate(getLayoutInflater());
        Util.SetLanguage(this);
        setContentView(binding.getRoot());

        binding.btnSave.setVisibility(View.GONE);
        this.mSP = new SP(this);

        binding.cardViewCameraPermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestCameraPermission();
            }
        });
        binding.switchOnOffCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestCameraPermission();
            }
        });

        binding.cardViewStoragePermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestStoragePermission();
            }
        });
        binding.switchOnOffStorage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestStoragePermission();
            }
        });

        binding.cardViewLocationPermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestLocationPermission();
            }
        });
        binding.switchOnOffLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestLocationPermission();
            }
        });

        binding.btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mSP.getBoolean(ActivityPermission.this, SP.INAPP_FEATURES, false)) {
                    startActivity(new Intent(ActivityPermission.this, CameraMainActivity.class));
                    finish();
                    return;
                }
                startActivity(new Intent(ActivityPermission.this, ActivityAppFeatures.class));
                finish();
            }
        });

    }

    void requestLocationPermission() {
        Dexter.withContext(this).withPermissions("android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION").withListener(new MultiplePermissionsListener() {
            @Override
            public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                multiplePermissionsReport.areAllPermissionsGranted();
                if (!multiplePermissionsReport.areAllPermissionsGranted()) {
                    showSimpleDialog();
                }
                if (multiplePermissionsReport.isAnyPermissionPermanentlyDenied()) {
                    showSimpleDialog();
                }
            }

            @Override
            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }
        }).check();
    }
    void requestStoragePermission() {
        if (Build.VERSION.SDK_INT > 32) {
            Dexter.withContext(this).withPermissions("android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VIDEO").withListener(new MultiplePermissionsListener() {
                @Override
                public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                    multiplePermissionsReport.areAllPermissionsGranted();
                    if (!multiplePermissionsReport.areAllPermissionsGranted()) {
                        showSimpleDialog();
                    }
                    if (multiplePermissionsReport.isAnyPermissionPermanentlyDenied()) {
                        showSimpleDialog();
                    }
                }

                @Override
                public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                    permissionToken.continuePermissionRequest();
                }
            }).check();
        } else {
            Dexter.withContext(this).withPermissions("android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE").withListener(new MultiplePermissionsListener() {
                @Override
                public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                    multiplePermissionsReport.areAllPermissionsGranted();
                    if (!multiplePermissionsReport.areAllPermissionsGranted()) {
                        showSimpleDialog();
                    }
                    if (multiplePermissionsReport.isAnyPermissionPermanentlyDenied()) {
                        showSimpleDialog();
                    }
                }

                @Override
                public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                    permissionToken.continuePermissionRequest();
                }
            }).check();
        }
    }
    void requestCameraPermission() {
        Dexter.withContext(this).withPermissions("android.permission.CAMERA").withListener(new MultiplePermissionsListener() {
            @Override
            public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                multiplePermissionsReport.areAllPermissionsGranted();
                if (!multiplePermissionsReport.areAllPermissionsGranted()) {
                    showSimpleDialog();
                }
                if (multiplePermissionsReport.isAnyPermissionPermanentlyDenied()) {
                    showSimpleDialog();
                }
            }

            @Override
            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }
        }).check();
    }
    public void showSimpleDialog() {
        try {
            AlertDialog alertDialog = this.alertSimpleDialog;
            if (alertDialog != null) {
                if (!alertDialog.isShowing()) {
                    this.alertSimpleDialog.show();
                }
            } else {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(getResources().getString(R.string.permission_denied_title));
                builder.setMessage(getResources().getString(R.string.allow_for_smooth));
                builder.setCancelable(false);
                builder.setPositiveButton(getResources().getString(R.string.action_settings), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent();
                        intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                        intent.setData(Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                        isactivityopen = 1;
                        startActivity(intent);
                    }
                });
                AlertDialog create = builder.create();
                this.alertSimpleDialog = create;
                create.show();
                this.alertSimpleDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialogInterface) {
                        isStoragePermission = 0;
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onBackPressed() {
        if (this.doubleBackToExitPressedOnce) {
            System.gc();
            finishAffinity();
            return;
        }
        this.doubleBackToExitPressedOnce = true;
        Snackbar.make(findViewById(R.id.cardView_camera_permission), "Press once again to exit", BaseTransientBottomBar.LENGTH_INDEFINITE).show();
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;
            }
        }, 2000L);
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        if (checkCameraPermission()) {
            binding.switchOnOffCamera.setChecked(true);
            binding.switchOnOffCamera.setClickable(false);
        } else {
            binding.switchOnOffCamera.setChecked(false);
        }
        if (checkStoragePermission()) {
            binding.switchOnOffStorage.setChecked(true);
            binding.switchOnOffStorage.setClickable(false);
        } else {
            binding.switchOnOffStorage.setChecked(false);
        }
        if (checkLocationPermission()) {
            binding.switchOnOffLocation.setChecked(true);
            binding.switchOnOffLocation.setClickable(false);
        } else {
            binding.switchOnOffLocation.setChecked(false);
        }
        if (checkCameraPermission() && checkLocationPermission() && checkStoragePermission()) {
            binding.btnSave.setVisibility(View.VISIBLE);
            this.mSP.setBoolean(this, SP.ALL_PERMISSION_ACCESS, true);
            binding.btnSave.setEnabled(true);
            binding.btnSave.setBackgroundColor(getResources().getColor(R.color._ffcc00));
            return;
        }
        binding.btnSave.setVisibility(View.GONE);
        this.mSP.setBoolean(this, SP.ALL_PERMISSION_ACCESS, false);
        binding.btnSave.setEnabled(false);
    }

    private boolean checkStoragePermission() {
        boolean z;
        if (Build.VERSION.SDK_INT > 32) {
            z = ContextCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_IMAGES") == 0;
            if (ContextCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_VIDEO") != 0) {
                return false;
            }
            return z;
        }
        z = ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0;
        if (ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            return false;
        }
        return z;
    }

    private boolean checkCameraPermission() {
        return ContextCompat.checkSelfPermission(this, "android.permission.CAMERA") == 0;
    }



    private boolean checkLocationPermission() {
        boolean z = ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0;
        if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") != 0) {
            return false;
        }
        return z;
    }


}