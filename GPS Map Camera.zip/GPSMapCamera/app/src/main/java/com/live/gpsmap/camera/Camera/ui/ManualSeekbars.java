package com.live.gpsmap.camera.Camera.ui;

import android.util.Log;
import android.widget.SeekBar;
import androidx.work.WorkRequest;
import com.gpfreetech.awesomescanner.util.BarcodeUtils;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes3.dex */
public class ManualSeekbars {
    private static final String TAG = "ManualSeekbars";
    private static final int manual_n = 1000;
    private List<Long> seekbar_values_iso;
    private List<Long> seekbar_values_shutter_speed;
    private List<Long> seekbar_values_white_balance;

    public static double seekbarScaling(double d) {
        return (Math.pow(100.0d, d) - 1.0d) / 99.0d;
    }

    private static double seekbarScalingInverse(double d) {
        return Math.log((d * 99.0d) + 1.0d) / Math.log(100.0d);
    }

    public static void setProgressSeekbarScaled(SeekBar seekBar, double d, double d2, double d3) {
        int i = 1000;
        seekBar.setMax(1000);
        int seekbarScalingInverse = (int) ((seekbarScalingInverse((d3 - d) / (d2 - d)) * 1000.0d) + 0.5d);
        if (seekbarScalingInverse < 0) {
            i = 0;
        } else if (seekbarScalingInverse <= 1000) {
            i = seekbarScalingInverse;
        }
        seekBar.setProgress(i);
    }

    public int getWhiteBalanceTemperature(int i) {
        return this.seekbar_values_white_balance.get(i).intValue();
    }

    public int getISO(int i) {
        return this.seekbar_values_iso.get(i).intValue();
    }

    public long getExposureTime(int i) {
        return this.seekbar_values_shutter_speed.get(i).longValue();
    }

    private void setProgressBarToClosest(SeekBar seekBar, List<Long> list, long j) {
        Log.d(TAG, "setProgressBarToClosest");
        long j2 = 0;
        int i = -1;
        for (int i2 = 0; i2 < list.size(); i2++) {
            Log.d(TAG, "seekbar_values[" + i2 + "]: " + list.get(i2));
            long abs = Math.abs(list.get(i2).longValue() - j);
            StringBuilder sb = new StringBuilder();
            sb.append("    dist: ");
            sb.append(abs);
            Log.d(TAG, sb.toString());
            if (i == -1 || abs < j2) {
                i = i2;
                j2 = abs;
            }
        }
        Log.d(TAG, "closest_indx: " + i);
        if (i != -1) {
            seekBar.setProgress(i);
        }
    }

    void setISOProgressBarToClosest(SeekBar seekBar, long j) {
        setProgressBarToClosest(seekBar, this.seekbar_values_iso, j);
    }

    public void setProgressSeekbarWhiteBalance(SeekBar seekBar, long j, long j2, long j3) {
        Log.d(TAG, "setProgressSeekbarWhiteBalance");
        ArrayList arrayList = new ArrayList();
        this.seekbar_values_white_balance = arrayList;
        while (j < j2) {
            arrayList.add(Long.valueOf(j));
            j += 100;
        }
        arrayList.add(Long.valueOf(j2));
        seekBar.setMax(arrayList.size() - 1);
        setProgressBarToClosest(seekBar, arrayList, j3);
    }

    public void setProgressSeekbarISO(SeekBar seekBar, long j, long j2, long j3) {
        long j4;
        long j5;
        long j6;
        Log.d(TAG, "setProgressSeekbarISO");
        ArrayList arrayList = new ArrayList();
        this.seekbar_values_iso = arrayList;
        arrayList.add(Long.valueOf(j));
        for (long j7 = 1; j7 < 100; j7++) {
            if (j7 > j && j7 < j2) {
                arrayList.add(Long.valueOf(j7));
            }
        }
        long j8 = 100;
        while (true) {
            j4 = 500;
            if (j8 >= 500) {
                break;
            }
            if (j8 > j && j8 < j2) {
                arrayList.add(Long.valueOf(j8));
            }
            j8 += 5;
        }
        while (true) {
            j5 = 1000;
            if (j4 >= 1000) {
                break;
            }
            if (j4 > j && j4 < j2) {
                arrayList.add(Long.valueOf(j4));
            }
            j4 += 10;
        }
        while (true) {
            if (j5 >= 5000) {
                break;
            }
            if (j5 > j && j5 < j2) {
                arrayList.add(Long.valueOf(j5));
            }
            j5 += 50;
        }
        for (j6 = 5000; j6 < WorkRequest.MIN_BACKOFF_MILLIS; j6 += 100) {
            if (j6 > j && j6 < j2) {
                arrayList.add(Long.valueOf(j6));
            }
        }
        arrayList.add(Long.valueOf(j2));
        seekBar.setMax(arrayList.size() - 1);
        setProgressBarToClosest(seekBar, arrayList, j3);
    }

    public void setProgressSeekbarShutterSpeed(SeekBar seekBar, long j, long j2, long j3) {
        int i;
        int i2;
        int i3;
        int i4;
        Log.d(TAG, "setProgressSeekbarShutterSpeed");
        ArrayList arrayList = new ArrayList();
        this.seekbar_values_shutter_speed = arrayList;
        arrayList.add(Long.valueOf(j));
        for (int i5 = 10; i5 >= 1; i5--) {
            long j4 = 1000000000 / (i5 * 1000);
            if (j4 > j && j4 < j2) {
                arrayList.add(Long.valueOf(j4));
            }
        }
        for (int i6 = 9; i6 >= 1; i6--) {
            long j5 = 1000000000 / (i6 * 100);
            if (j5 > j && j5 < j2) {
                arrayList.add(Long.valueOf(j5));
            }
        }
        for (int i7 = 9; i7 >= 6; i7--) {
            long j6 = 1000000000 / (i7 * 10);
            if (j6 > j && j6 < j2) {
                arrayList.add(Long.valueOf(j6));
            }
        }
        for (int i8 = 50; i8 >= 10; i8 -= 5) {
            long j7 = 1000000000 / i8;
            if (j7 > j && j7 < j2) {
                arrayList.add(Long.valueOf(j7));
            }
        }
        int i9 = 1;
        while (true) {
            i = 20;
            if (i9 >= 20) {
                break;
            }
            long j8 = i9 * 100000000;
            if (j8 > j && j8 < j2) {
                arrayList.add(Long.valueOf(j8));
            }
            i9++;
        }
        for (int i10 = 2; i10 < 20; i10++) {
            long j9 = i10 * 1000000000;
            if (j9 > j && j9 < j2) {
                arrayList.add(Long.valueOf(j9));
            }
        }
        while (true) {
            i2 = 60;
            if (i >= 60) {
                break;
            }
            long j10 = i * 1000000000;
            if (j10 > j && j10 < j2) {
                arrayList.add(Long.valueOf(j10));
            }
            i += 5;
        }
        while (true) {
            i3 = BarcodeUtils.ROTATION_180;
            if (i2 >= 180) {
                break;
            }
            long j11 = i2 * 1000000000;
            if (j11 > j && j11 < j2) {
                arrayList.add(Long.valueOf(j11));
            }
            i2 += 15;
        }
        while (true) {
            if (i3 >= 600) {
                break;
            }
            long j12 = i3 * 1000000000;
            if (j12 > j && j12 < j2) {
                arrayList.add(Long.valueOf(j12));
            }
            i3 += 60;
        }
        for (i4 = 600; i4 <= 1200; i4 += 120) {
            long j13 = i4 * 1000000000;
            if (j13 > j && j13 < j2) {
                arrayList.add(Long.valueOf(j13));
            }
        }
        arrayList.add(Long.valueOf(j2));
        seekBar.setMax(arrayList.size() - 1);
        setProgressBarToClosest(seekBar, arrayList, j3);
    }
}
