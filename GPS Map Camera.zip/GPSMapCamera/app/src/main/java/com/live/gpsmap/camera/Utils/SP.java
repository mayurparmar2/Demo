package com.live.gpsmap.camera.Utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.live.gpsmap.camera.Model.ViewModel;
import java.util.ArrayList;
import java.util.List;
@SuppressWarnings("All")
public class SP {
    public static final String ACCURACY_COLOR = "ACCURACY_COLOR";
    public static final String ACCURACY_COLOR_CLASSIC = "ACCURACY_COLOR_CLASSIC";
    public static final String ACCURACY_SELECT = "accuracy_select";
    public static final String ACCURACY_SELECT_CLASSIC = "accuracy_select_classic";
    public static final String ACCURACY_VALUE = "Accuracy_value";
    public static final String ADDRESS_COLOR = "ADDRESS_COLOR";
    public static final String ADDRESS_COLOR_CLASSIC = "ADDRESS_COLOR_CLASSIC";
    public static final String ADDRESS_INDEX = "address_index";
    public static final String ADS_STATUS = "ads_status";
    public static final String ALARM_TIME_100_PHOTOS = "alarm_time_100_photos";
    public static final String ALARM_TIME_10_TIMES_OPEN = "alarm_time_10_times_open";
    public static final String ALARM_TIME_15_DAYS = "alarm_time_15_days";
    public static final String ALARM_TIME_2ND_DAY = "alarm_time_2nd_day";
    public static final String ALARM_TIME_3_TIME_NO_BUY = "alarm_time_3_time_no_buy";
    public static final String ALARM_TIME_3_TIME_NO_BUY_STAN = "alarm_time_3_time_no_buy_stan";
    public static final String ALARM_TIME_45_PHOTOS = "alarm_time_45_photos";
    public static final String ALARM_TIME_500_PHOTOS = "alarm_time_500_photos";
    public static final String ALARM_TIME_50_PHOTOS_PRO = "alarm_time_50_photos_pro";
    public static final String ALARM_TIME_CAMSET_OPEN_TIME = "alarm_time_camset_open_time";
    public static final String ALARM_TIME_FILE_OPEN_TIME = "alarm_time_file_open_time";
    public static final String ALARM_TIME_FOLD_OPEN_TIME = "alarm_time_fold_open_time";
    public static final String ALARM_TIME_FONT_OPEN_TIME = "alarm_time_font_open_time";
    public static final String ALARM_TIME_MAP_OPEN_TIME = "alarm_time_map_open_time";
    public static final String ALARM_TIME_STAMPPOS_OPEN_TIME = "alarm_time_stamppos_open_time";
    public static final String ALARM_TIME_TEMP_OPEN_TIME = "alarm_time_temp_open_time";
    public static final String ALL_PERMISSION_ACCESS = "all-permisiion_access";
    public static final String ALTITUDE_COLOR = "ALTITUDE_COLOR";
    public static final String ALTITUDE_COLOR_CLASSIC = "ALTITUDE_COLOR_CLASSIC";
    public static final String ALTITUDE_SELECT = "altitude_select";
    public static final String ALTITUDE_SELECT_CLASSIC = "altitude_select_classic";
    public static final String ALTITUDE_VALUE = "Altitude_value";
    public static final String APP_COUNT = "app_count";
    public static final String BACKGROUND_COLOR = "BACKGROUND_COLOR";
    public static final String BACKGROUND_COLOR_CLASSIC = "BACKGROUND_COLOR_CLASSIC";
    public static final String BADGE_COUNT = "badge_count";
    public static final String COMPASS_COLOR = "COMPASS_COLOR";
    public static final String COMPASS_COLOR_CLASSIC = "COMPASS_COLOR_CLASSIC";
    public static final String COMPASS_FOUND = "compass_found";
    public static final String COMPASS_VALUE = "compass_value";
    public static final String CUS_1_INDEX = "cus_1_index";
    public static final String CUS_2_INDEX = "cus_2_index";
    public static final String CUS_3_INDEX = "cus_3_index";
    public static final String CUS_VALUE_1 = "cus_1_value";
    public static final String CUS_VALUE_2 = "cus_2_value";
    public static final String CUS_VALUE_3 = "cus_3_value";
    public static final String DATE_FORMAT = "date_format";
    public static final String DATE_FORMAT_CLASSIC = "date_format_classic";
    public static final String DATE_TIME_COLOR = "DATE_TIME_COLOR";
    public static final String DATE_TIME_COLOR_CLASSIC = "DATE_TIME_COLOR_CLASSIC";
    public static final String DATE_TIME_INDEX = "dt_index";
    public static final String DEFAULT_NOTE = "DEFAULT_NOTE";
    public static final String ELEVATION_COLOR = "ELEVATION_COLOR";
    public static final String ELEVATION_COLOR_CLASSIC = "ELEVATION_COLOR_CLASSIC";
    public static final String FILE_ARRAY_LIST = "file_array_list";
    public static final String FIRSTFILENAME = "FIRSTFILENAME";
    public static final String FOLDER_PATH = "folder_path";
    public static final String FULL_FILE_NAME = "full_file_name";
    public static final String HEADER_USER_PROPERTY = "header_show";
    public static final String HUMIDITY_COLOR = "HUMIDITY_COLOR";
    public static final String HUMIDITY_COLOR_CLASSIC = "HUMIDITY_COLOR_CLASSIC";
    public static final String HUMIDITY_VALUE = "Humidity_value";
    public static final String IMAGE_URI = "image_uri";
    public static final String INAPP_FEATURES = "inapp_features";
    public static final String ISEXITNATIVE = "isexitnative";
    public static final String IS_24HR = "is_24hr";
    public static final String IS_ACCURACY = "is_accuracy";
    public static final String IS_ACCURACY_CLASSIC = "is_accuracy_classic";
    public static final String IS_ADDRESS = "is_address";
    public static final String IS_ADDRESS_CLASSIC = "is_address_classic";
    public static final String IS_ALTITUDE = "is_altitude";
    public static final String IS_ALTITUDE_CLASSIC = "is_altitude_classic";
    public static final String IS_CALL_WEATHER_API = "is_weather_once";
    public static final String IS_COMPASS = "is_compass";
    public static final String IS_COMPASS_CLASSIC = "is_compass_classic";
    public static final String IS_CUS_1 = "is_cus_1";
    public static final String IS_CUS_2 = "is_cus_2";
    public static final String IS_CUS_3 = "is_cus_3";
    public static final String IS_DATE_TIME = "is_date_time";
    public static final String IS_DATE_TIME_CLASSIC = "is_date_time_classic";
    public static final String IS_DECIMAL_FILE = "is_decimal_file";
    public static final String IS_DISPLAY_FOLDER_NAME = "is_display_folder_name";
    public static final String IS_DMS_FILE = "is_dms_file";
    public static final String IS_DT = "is_dt";
    public static final String IS_ELEVATION = "is_elevation";
    public static final String IS_ELEVATION_CLASSIC = "is_elevation_classic";
    public static final String IS_FILE_DATE_TIME = "is_main_dt";
    public static final String IS_HR_MIN_SEC = "is_hr_min_sec";
    public static final String IS_HUMIDITY = "is_humidity";
    public static final String IS_HUMIDITY_CLASSIC = "is_humidity_classic";
    public static final String IS_INCREMENT = "is_increment";
    public static final String IS_INCREMENT_CLASSIC = "is_increment_classic";
    public static final String IS_LAT_LNG = "is_lat_lng";
    public static final String IS_LAT_LNG_TEMPLATE = "is_lat_lng_template";
    public static final String IS_LAT_LNG_TEMPLATE_CLASSIC = "is_lat_lng_template_classic";
    public static final String IS_LINE_1 = "is_line_1";
    public static final String IS_LINE_2 = "is_line_2";
    public static final String IS_LINE_3 = "is_line_3";
    public static final String IS_LINE_4 = "is_line_4";
    public static final String IS_LOCATION_CHANGED = "is_location_chnaged";
    public static final String IS_LOGO = "is_logo";
    public static final String IS_LOGO_CLASSIC = "is_logo_classic";
    public static final String IS_MAGNETIC_FIELD = "is_magnetic_field";
    public static final String IS_MAGNETIC_FIELD_CLASSIC = "is_magnetic_field_classic";
    public static final String IS_MAIN_ADDRESS = "is_main_address";
    public static final String IS_MAP = "is_map";
    public static final String IS_MAP_CLASSIC = "is_map_classic";
    public static final String IS_NOTES = "is_notes";
    public static final String IS_NOTES_CLASSIC = "is_notes_classic";
    public static final String IS_NUMBERING = "is_numbering";
    public static final String IS_NUMBERING_CLASSIC = "is_numbering_classic";
    public static final String IS_ORIGINAL_IMAGE = "is_original_image";
    public static final String IS_PLUS_CODE = "is_plus_code";
    public static final String IS_PLUS_CODE_CLASSIC = "is_plus_code_classic";
    public static final String IS_PRESSURE = "is_pressure";
    public static final String IS_PRESSURE_CLASSIC = "is_pressure_classic";
    public static final String IS_SEQUENCE = "is_sequence";
    public static final String IS_TIMEZONE = "is_timezone";
    public static final String IS_TIMEZONE_CLASSIC = "is_timezone_classic";
    public static final String IS_WATER_MARK = "is_water_mark";
    public static final String IS_WEATHER = "is_weather";
    public static final String IS_WEATHER_CLASSIC = "is_weather_classic";
    public static final String IS_WEEK = "is_week";
    public static final String IS_WIND = "is_wind";
    public static final String IS_WIND_CLASSIC = "is_wind_classic";
    public static final String LANGUAGE_COUNT = "language_count";
    public static final String LANGUAGE_POS = "language_pos";
    public static final String LATITUDE = "latitude_1";
    public static final String LAT_LNG_COLOR = "LAT_LNG_COLOR";
    public static final String LAT_LNG_COLOR_CLASSIC = "LAT_LNG_COLOR_CLASSIC";
    public static final String LAT_LNG_INDEX = "lat_lng_index";
    public static final String LAT_LNG_TYPE = "lat_lng_type_1";
    public static final String LAT_LNG_TYPE_CLASSIC = "lat_lng_type_1_classic";
    public static final String LOCATION_SELECTION = "loction_selection";
    public static final String LOCATION_SELECTION_TITLE = "loction_selection_title";
    public static final String LOCATION_TYPE = "location_type";
    public static final String LOC_LINE_1_ADDRESS = "loc_address_line_1";
    public static final String LOC_LINE_2_CITY = "loc_city";
    public static final String LOC_LINE_3_STATE = "loc_state";
    public static final String LOC_LINE_4_COUNTRY = "loc_country";
    public static final String LOGO_URI = "logo_uri";
    public static final String LOGO_URI_CLASSIC = "logo_uri_classic";
    public static final String LONGITUDE = "longitude_1";
    public static final String MAGNETIC_FIELD_COLOR = "MAGNETIC_FIELD_COLOR";
    public static final String MAGNETIC_FIELD_COLOR_CLASSIC = "MAGNETIC_FIELD_COLOR_CLASSIC";
    public static final String MAGNETIC_FIELD_VALUE = "magnetic_field_value";
    public static final String MAP_POS = "map_pos";
    public static final String MAP_POS_CLASSIC = "map_pos_CLASSIC";
    public static final String MAP_TYPE = "map_type";
    public static final String MAP_TYPE_TEMPLATE = "map_type_template";
    public static final String MAP_TYPE_TEMPLATE_CLASSIC = "map_type_template_classic";
    public static final String NOTES_HASHTAG = "notes_hashtag";
    public static final String NOTES_HASHTAG_CLASSIC = "notes_hashtag_classic";
    public static final String NOTES_HASHTAG_COLOR = "NOTES_HASHTAG_COLOR";
    public static final String NOTES_HASHTAG_COLOR_CLASSIC = "NOTES_HASHTAG_COLOR_CLASSIC";
    public static final String NUMBERING_COLOR = "NUMBERING_COLOR";
    public static final String NUMBERING_COLOR_CLASSIC = "NUMBERING_COLOR_CLASSIC";
    public static final String OPEN_TIME = "open_time";
    public static final String PLUS_CODE = "PLUS_CODE";
    public static final String PLUS_CODE_COLOR = "PLUS_CODE_COLOR";
    public static final String PLUS_CODE_COLOR_CLASSIC = "PLUS_CODE_COLOR_CLASSIC";
    public static final String PLUS_CODE_TYPE = "plusCodeType";
    public static final String PLUS_CODE_TYPE_CLASSIC = "plusCodeType_classic";
    public static final String PREFIX = "PREFIX";
    public static final String PREFIX_CLASSIC = "PREFIX_CLASSIC";
    public static final String PRESSURE_COLOR = "PRESSURE_COLOR";
    public static final String PRESSURE_COLOR_CLASSIC = "PRESSURE_COLOR_CLASSIC";
    public static final String PRESSURE_SELECT = "pressure_select";
    public static final String PRESSURE_SELECT_CLASSIC = "pressure_select_classic";
    public static final String PRESSURE_VALUE = "Pressure_value";
    public static final String SCENEMODE = "scenemode";
    public static final String SELECTED_LANGUAGE = "selected_language";
    public static final String SEQUENCE = "SEQUENCE";
    public static final String SEQUENCE_CLASSIC = "SEQUENCE_CLASSIC";
    public static final String SEQUENCE_INDEX = "sn_index";
    public static final String SEQUENCE_VALUE = "sequence_value";
    public static final String STAMP_FONT_NAME = "stamp_font_name";
    public static final String STAMP_FONT_NAME_CLASSIC = "stamp_font_name_classic";
    public static final String STAMP_FONT_STYLE = "stamp_font_style";
    public static final String STAMP_FONT_STYLE_CLASSIC = "stamp_font_style_classic";
    public static final String STAMP_POS = "stamp_pos";
    public static final String STAMP_POS_CLASSIC = "stamp_pos_classic";
    public static final String STAMP_SIZE = "stamp_size";
    public static final String STAMP_SIZE_CLASSIC = "stamp_size_classic";
    public static final String SUFFIX = "SUFFIX";
    public static final String SUFFIX_CLASSIC = "SUFFIX_CLASSIC";
    public static final String TEMPLATE_TYPE = "template_type";
    public static final String TEMPRATURE_TYPE = "temprature_type";
    public static final String TEMPRATURE_TYPE_CLASSIC = "temprature_type_classic";
    public static final String TEMPRETURE_VALUE = "temprature_value";
    public static final String TIMEZONE = "TIME_ZONE";
    public static final String TIMEZONE_CLASSIC = "TIME_ZONE_CLASSIC";
    public static final String WEATHER_COLOR = "WEATHER_COLOR";
    public static final String WEATHER_COLOR_CLASSIC = "WEATHER_COLOR_CLASSIC";
    public static final String WEATHER_ICON = "weather_icon";
    public static final String WHITEBALANCE = "whitebalance";
    public static final String WIND_COLOR = "WIND_COLOR";
    public static final String WIND_COLOR_CLASSIC = "WIND_COLOR_CLASSIC";
    public static final String WIND_SELECT = "wind_select";
    public static final String WIND_SELECT_CLASSIC = "wind_select_classic";
    public static final String WIND_VALUE = "wind_value";
    public static SharedPreferences myPreference;

    public SP(Context context) {
        StrictMode.ThreadPolicy allowThreadDiskReads = StrictMode.allowThreadDiskReads();
        if (context != null) {
            try {
                myPreference = PreferenceManager.getDefaultSharedPreferences(context);
            } finally {
                StrictMode.setThreadPolicy(allowThreadDiskReads);
            }
        }
    }

    public void saveArrayList(Context context, ArrayList<ViewModel> arrayList) {
        if (myPreference == null) {
            myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        SharedPreferences.Editor edit = myPreference.edit();
        edit.putString(FILE_ARRAY_LIST, new Gson().toJson(arrayList));
        edit.commit();
    }

    public ArrayList<ViewModel> getArrayList(Context context) {
        if (myPreference == null) {
            myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        return (ArrayList) new Gson().fromJson(myPreference.getString(FILE_ARRAY_LIST, ""), new TypeToken<List<ViewModel>>() { // from class: com.live.gpsmap.camera.Utils.SP.1
        }.getType());
    }

    public void setString(Context context, String str, String str2) {
        if (myPreference == null) {
            myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        SharedPreferences.Editor edit = myPreference.edit();
        edit.putString(str, str2);
        edit.apply();
    }

    public String getString(Context context, String str, String str2) {
        if (myPreference == null) {
            myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        return myPreference.getString(str, str2);
    }

    public void setInteger(Context context, String str, int i) {
        if (myPreference == null) {
            myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        SharedPreferences.Editor edit = myPreference.edit();
        edit.putInt(str, i);
        edit.apply();
    }

    public int getInteger(Context context, String str) {
        if (myPreference == null) {
            myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        return myPreference.getInt(str, 0);
    }

    public void setFloat(Context context, String str, float f) {
        if (myPreference == null) {
            myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        SharedPreferences.Editor edit = myPreference.edit();
        edit.putFloat(str, f);
        edit.apply();
    }

    public float getFloat(Context context, String str) {
        if (myPreference == null) {
            myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        return myPreference.getFloat(str, 0.0f);
    }

    public int getInteger(Context context, String str, int i) {
        if (myPreference == null) {
            myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        return myPreference.getInt(str, i);
    }


    public void setBoolean(Context context, String str, boolean z) {
        if (myPreference == null) {
            myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        SharedPreferences.Editor edit = myPreference.edit();
        edit.putBoolean(str, z);
        edit.apply();
    }

    public boolean getBoolean(Context context, String str) {
        if (myPreference == null) {
            myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        return myPreference.getBoolean(str, false);
    }

    public boolean getBoolean(Context context, String str, boolean z) {
        if (myPreference == null) {
            myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        return myPreference.getBoolean(str, z);
    }

    public void setLong(Context context, String str, long j) {
        if (myPreference == null) {
            myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        SharedPreferences.Editor edit = myPreference.edit();
        edit.putLong(str, j);
        edit.apply();
    }

    public long getLong(Context context, String str, long j) {
        if (myPreference == null) {
            myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        return myPreference.getLong(str, j);
    }

    public void clearSharedPreferences(Context context) {
        if (myPreference == null) {
            myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        SharedPreferences.Editor edit = myPreference.edit();
        edit.clear();
        edit.apply();
    }

    public boolean saveImageuriArray(ArrayList<String> arrayList, String str, Context context) {
        SharedPreferences.Editor edit = myPreference.edit();
        edit.putInt(str + "_size", arrayList.size());
        for (int i = 0; i < arrayList.size(); i++) {
            edit.putString(str + "_" + i, arrayList.get(i));
        }
        return edit.commit();
    }

    public ArrayList<String> loadImageuriArray(String str, Context context) {
        SharedPreferences sharedPreferences = myPreference;
        int i = sharedPreferences.getInt(str + "_size", 0);
        ArrayList<String> arrayList = new ArrayList<>();
        for (int i2 = 0; i2 < i; i2++) {
            SharedPreferences sharedPreferences2 = myPreference;
            arrayList.add(sharedPreferences2.getString(str + "_" + i2, null));
        }
        return arrayList;
    }

    public static String getRatioPos_Key(String str) {
        return "resolution_pos" + str;
    }

    public static String getRatio_Key(String str) {
        return "camera_resolution_" + str;
    }

}