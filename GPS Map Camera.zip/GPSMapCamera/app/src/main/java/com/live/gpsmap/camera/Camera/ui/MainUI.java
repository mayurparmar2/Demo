package com.live.gpsmap.camera.Camera.ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Rect;
import android.media.AudioManager;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;

import com.gpfreetech.awesomescanner.util.BarcodeUtils;
import com.live.gpsmap.camera.Camera.CameraMainActivity;
import com.live.gpsmap.camera.Camera.PreferenceKeys;
import com.live.gpsmap.camera.R;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@SuppressWarnings("All")
public class MainUI {
    private static final String TAG = "MainUI";
    private static final boolean cache_popup = true;
    private static final String manual_iso_value = "m";
    private static final int view_rotate_animation_duration = 100;
    private int current_orientation;
    private boolean immersive_mode;
    private List<View> iso_buttons;
    private boolean keydown_volume_down;
    private boolean keydown_volume_up;
    private View mHighlightedIcon;
    private LinearLayout mHighlightedLine;
    private final CameraMainActivity main_activity;
    private volatile boolean popup_view_is_open;
    private boolean remote_control_mode;
    public volatile int test_navigation_gap;
    public int test_saved_popup_height;
    public int test_saved_popup_width;
    private boolean view_rotate_animation;
    private final int highlightColor = Color.rgb(183, 28, 28);
    private final int highlightColorExposureUIElement = Color.rgb(244, 67, 54);
    private final Map<String, View> test_ui_buttons = new Hashtable();
    private boolean force_destroy_popup = false;
    private UIPlacement ui_placement = UIPlacement.UIPLACEMENT_RIGHT;
    private View top_icon = null;
    private boolean show_gui_photo = true;
    private boolean show_gui_video = true;
    private int mPopupLine = 0;
    private int mPopupIcon = 0;
    private boolean mSelectingIcons = false;
    private boolean mSelectingLines = false;
    private int mExposureLine = 0;
    private boolean mSelectingExposureUIElement = false;
    private int iso_button_manual_index = -1;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes3.dex */
    public enum UIPlacement {
        UIPLACEMENT_RIGHT,
        UIPLACEMENT_LEFT,
        UIPLACEMENT_TOP
    }


    private void highlightExposureUILine(boolean z) {
    }

    private void highlightPopupLine(boolean z, boolean z2) {
    }

    private void resetExposureUIHighlights() {
    }

    public void audioControlStarted() {
    }

    public void audioControlStopped() {
    }

    public void destroyPopup() {
    }

    public String getEntryForAntiBanding(String str) {
        return str;
    }

    public String getEntryForNoiseReductionMode(String str) {
        return str;
    }

    public boolean isExposureUIOpen() {
        return false;
    }

    public void setPauseVideoContentDescription() {
    }

    public void setSwitchCameraContentDescription() {
    }

    public void setTakePhotoIcon() {
    }

    public void setupExposureUI() {
    }

    public void updateAutoLevelIcon() {
    }

    public void updateCycleRawIcon() {
    }

    public void updateExposureLockIcon() {
    }

    public void updateFaceDetectionIcon() {
    }

    public void updateRemoteConnectionIcon() {
    }

    public void updateStampIcon() {
    }

    public void updateStoreLocationIcon() {
    }

    public void updateTextStampIcon() {
    }

    public void updateWhiteBalanceLockIcon() {
    }

    public MainUI(CameraMainActivity mainActivity) {
        Log.d(TAG, TAG);
        this.main_activity = mainActivity;
        setSeekbarColors();
    }

    private void setSeekbarColors() {
        Log.d(TAG, "setSeekbarColors");
    }

    private void setViewRotation(View view, float f) {
        if (!this.view_rotate_animation) {
            view.setRotation(f);
        }
        float rotation = f - view.getRotation();
        if (rotation>181.0f) {
            rotation -= 360.0f;
        } else if (rotation<-181.0f) {
            rotation += 360.0f;
        }
        view.animate().rotationBy(rotation).setDuration(100L).setInterpolator(new AccelerateDecelerateInterpolator()).start();
    }

    public void layoutUI() {
        layoutUI(false);
    }

    private UIPlacement computeUIPlacement() {
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.main_activity);
        String str = "";
        String string = defaultSharedPreferences.getString(PreferenceKeys.UIPlacementPreferenceKey, str);
        string.hashCode();
        if (string.equals(str)) {
            return UIPlacement.UIPLACEMENT_TOP;
        }
        if (string.equals("ui_left")) {
            return UIPlacement.UIPLACEMENT_LEFT;
        }
        return UIPlacement.UIPLACEMENT_RIGHT;
    }

    private void layoutUI(boolean z) {
        Log.d(TAG, "layoutUI");
        System.currentTimeMillis();
        PreferenceManager.getDefaultSharedPreferences(this.main_activity);
        this.ui_placement = computeUIPlacement();
        Log.d(TAG, "ui_placement: " + this.ui_placement);
        int rotation = this.main_activity.getWindowManager().getDefaultDisplay().getRotation();
        int i = 0;
        if (rotation != 0) {
            if (rotation == 1) {
                i = 90;
            } else if (rotation == 2) {
                i = BarcodeUtils.ROTATION_180;
            } else if (rotation == 3) {
                i = BarcodeUtils.ROTATION_270;
            }
        }
        int i2 = (this.current_orientation + i) % 360;
        Log.d(TAG, "    current_orientation = " + this.current_orientation);
        Log.d(TAG, "    degrees = " + i);
        Log.d(TAG, "    relative_orientation = " + i2);
        int i3 = (360 - i2) % 360;
        this.main_activity.getPreview().setUIRotation(i3);
        if (this.ui_placement != UIPlacement.UIPLACEMENT_LEFT) {
            UIPlacement uIPlacement = UIPlacement.UIPLACEMENT_TOP;
        }
        Point point = new Point();
        this.main_activity.getWindowManager().getDefaultDisplay().getSize(point);
        Math.min(point.x, point.y);
        if (z) {
            return;
        }
        this.top_icon = null;
        View findViewById = this.main_activity.findViewById(R.id.img_camera_settings);
        findViewById.setLayoutParams((LinearLayout.LayoutParams) findViewById.getLayoutParams());
        float f = i3;
        setViewRotation(findViewById, f);
        View findViewById2 = this.main_activity.findViewById(R.id.img_fileName);
        findViewById2.setLayoutParams((LinearLayout.LayoutParams) findViewById2.getLayoutParams());
        setViewRotation(findViewById2, f);
        View findViewById3 = this.main_activity.findViewById(R.id.img_app_settings);
        findViewById3.setLayoutParams((LinearLayout.LayoutParams) findViewById3.getLayoutParams());
        setViewRotation(findViewById3, f);
        View findViewById4 = this.main_activity.findViewById(R.id.li_flash);
        findViewById4.setLayoutParams((LinearLayout.LayoutParams) findViewById4.getLayoutParams());
        setViewRotation(findViewById4, f);
        View findViewById5 = this.main_activity.findViewById(R.id.switch_camera);
        findViewById5.setLayoutParams((LinearLayout.LayoutParams) findViewById5.getLayoutParams());
        setViewRotation(findViewById5, f);
        View findViewById6 = this.main_activity.findViewById(R.id.rel_gallery);
        findViewById6.setLayoutParams((LinearLayout.LayoutParams) findViewById6.getLayoutParams());
        setViewRotation(findViewById6, f);
        View findViewById7 = this.main_activity.findViewById(R.id.rel_template);
        findViewById7.setLayoutParams((LinearLayout.LayoutParams) findViewById7.getLayoutParams());
        setViewRotation(findViewById7, f);
        View findViewById8 = this.main_activity.findViewById(R.id.rel_folder);
        findViewById8.setLayoutParams((LinearLayout.LayoutParams) findViewById8.getLayoutParams());
        setViewRotation(findViewById8, f);
        View findViewById9 = this.main_activity.findViewById(R.id.rel_gps);
        findViewById9.setLayoutParams((LinearLayout.LayoutParams) findViewById9.getLayoutParams());
        setViewRotation(findViewById9, f);
        View findViewById10 = this.main_activity.findViewById(R.id.take_photo);
        findViewById10.setLayoutParams((RelativeLayout.LayoutParams) findViewById10.getLayoutParams());
        setViewRotation(findViewById10, f);
    }

    public UIPlacement getUIPlacement() {
        return this.ui_placement;
    }


    public void onOrientationChanged(int i) {
        int i2;
        if (i == -1) {
            return;
        }
        int abs = Math.abs(i - this.current_orientation);
        if (abs > 180) {
            abs = 360 - abs;
        }
        if (abs <= 60 || (i2 = (((i + 45) / 90) * 90) % 360) == this.current_orientation) {
            return;
        }
        this.current_orientation = i2;
        Log.d(TAG, "current_orientation is now: " + this.current_orientation);
        this.view_rotate_animation = true;
        layoutUI();
        this.view_rotate_animation = false;
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.d(MainUI.TAG, "onOrientationChanged->postDelayed()");
                MainUI.this.main_activity.getApplicationInterface().getDrawPreview().updateSettings();
            }
        }, 120L);
    }

    public boolean showExposureLockIcon() {
        if (this.main_activity.getPreview().supportsExposureLock()) {
            return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowExposureLockPreferenceKey, false);
        }
        return false;
    }

    public boolean showWhiteBalanceLockIcon() {
        if (this.main_activity.getPreview().supportsWhiteBalanceLock()) {
            return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowWhiteBalanceLockPreferenceKey, false);
        }
        return false;
    }

    public boolean showCycleRawIcon() {
        if (this.main_activity.getPreview().supportsRaw() && this.main_activity.getApplicationInterface().isRawAllowed(this.main_activity.getApplicationInterface().getPhotoMode())) {
            return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowCycleRawPreferenceKey, false);
        }
        return false;
    }

    public boolean showStoreLocationIcon() {
        return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowStoreLocationPreferenceKey, false);
    }

    public boolean showTextStampIcon() {
        return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowTextStampPreferenceKey, false);
    }

    public boolean showStampIcon() {
        return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowStampPreferenceKey, false);
    }

    public boolean showAutoLevelIcon() {
        if (this.main_activity.supportsAutoStabilise()) {
            return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowAutoLevelPreferenceKey, false);
        }
        return false;
    }

    public boolean showCycleFlashIcon() {
        if (this.main_activity.getPreview().supportsFlash() && !this.main_activity.getPreview().isVideo()) {
            return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowCycleFlashPreferenceKey, false);
        }
        return false;
    }

    public boolean showFaceDetectionIcon() {
        if (this.main_activity.getPreview().supportsFaceDetection()) {
            return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowFaceDetectionPreferenceKey, false);
        }
        return false;
    }

    public void setImmersiveMode(final boolean z) {
        Log.d(TAG, "setImmersiveMode: " + z);
        this.immersive_mode = z;
        this.main_activity.runOnUiThread(new Runnable() { // from class: com.live.gpsmap.camera.Camera.ui.MainUI.2
            @Override // java.lang.Runnable
            public void run() {
                SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(MainUI.this.main_activity);
                int i = z ? 8 : 0;
                Log.d(MainUI.TAG, "setImmersiveMode: set visibility: " + i);
                View findViewById = MainUI.this.main_activity.findViewById(R.id.rel_gallery);
                View findViewById2 = MainUI.this.main_activity.findViewById(R.id.liMultiCamera);
                View findViewById3 = MainUI.this.main_activity.findViewById(R.id.img_gallery);
                if (MainUI.this.main_activity.getPreview().getCameraControllerManager().getNumberOfCameras()>1) {
                    findViewById.setVisibility(i);
                }
                if (MainUI.this.main_activity.showSwitchMultiCamIcon()) {
                    findViewById2.setVisibility(i);
                }
                findViewById3.setVisibility(i);
                Log.d(MainUI.TAG, "has_zoom: " + MainUI.this.main_activity.getPreview().supportsZoom());
                if (defaultSharedPreferences.getString(PreferenceKeys.ImmersiveModePreferenceKey, "immersive_mode_low_profile").equals("immersive_mode_everything") && defaultSharedPreferences.getBoolean(PreferenceKeys.ShowTakePhotoPreferenceKey, true)) {
                    MainUI.this.main_activity.findViewById(R.id.take_photo).setVisibility(i);
                }
                if (z) {
                    return;
                }
                MainUI.this.showGUI();
            }
        });
    }

    public boolean inImmersiveMode() {
        return this.immersive_mode;
    }

    public void showGUI(boolean z, boolean z2) {
        Log.d(TAG, "gui_video" + z);
        Log.d(TAG, "is_video: " + z2);
        if (z2) {
            this.show_gui_video = z;
        } else {
            this.show_gui_photo = z;
        }
    }

    public void showGUI() {
        Log.d(TAG, "showGUI");
        Log.d(TAG, "show_gui_photo: " + this.show_gui_photo);
        Log.d(TAG, "show_gui_video: " + this.show_gui_video);
        if (inImmersiveMode()) {
            return;
        }
        if ((this.show_gui_photo || this.show_gui_video) && this.main_activity.usingKitKatImmersiveMode()) {
            this.main_activity.initImmersiveMode();
        }
        this.main_activity.runOnUiThread(new Runnable() { // from class: com.live.gpsmap.camera.Camera.ui.MainUI.3
            @Override // java.lang.Runnable
            public void run() {
                boolean isRecording = MainUI.this.main_activity.getApplicationInterface().getGyroSensor().isRecording();
                int i = 8;
                if (!isRecording && MainUI.this.show_gui_photo && MainUI.this.show_gui_video) {
                    i = 0;
                }
                if (!isRecording) {
                    boolean unused = MainUI.this.show_gui_photo;
                }
                View findViewById = MainUI.this.main_activity.findViewById(R.id.rel_gallery);
                View findViewById2 = MainUI.this.main_activity.findViewById(R.id.imgMultiCamera);
                if (MainUI.this.main_activity.getPreview().getCameraControllerManager().getNumberOfCameras()>1) {
                    findViewById.setVisibility(i);
                }
                if (MainUI.this.main_activity.showSwitchMultiCamIcon()) {
                    findViewById2.setVisibility(i);
                }
                if (!MainUI.this.show_gui_photo || !MainUI.this.show_gui_video) {
                    MainUI.this.closePopup();
                }
                if (MainUI.this.show_gui_photo && MainUI.this.show_gui_video) {
                    MainUI.this.layoutUI();
                }
            }
        });
    }

    public void updateCycleFlashIcon() {
        String flashPref = this.main_activity.getApplicationInterface().getFlashPref();
        if (flashPref != null) {
            ImageView imageView = (ImageView) this.main_activity.findViewById(R.id.img_flash);
            flashPref.hashCode();
            char c = 65535;
            switch (flashPref.hashCode()) {
                case -1524012984:
                    if (flashPref.equals("flash_frontscreen_auto")) {
                        c = 0;
                        break;
                    }
                    break;
                case -1195303778:
                    if (flashPref.equals("flash_auto")) {
                        c = 1;
                        break;
                    }
                    break;
                case -1146923872:
                    if (flashPref.equals("flash_off")) {
                        c = 2;
                        break;
                    }
                    break;
                case -10523976:
                    if (flashPref.equals("flash_frontscreen_on")) {
                        c = 3;
                        break;
                    }
                    break;
                case 17603715:
                    if (flashPref.equals("flash_frontscreen_torch")) {
                        c = 4;
                        break;
                    }
                    break;
                case 1617654509:
                    if (flashPref.equals("flash_torch")) {
                        c = 5;
                        break;
                    }
                    break;
                case 1625570446:
                    if (flashPref.equals("flash_on")) {
                        c = 6;
                        break;
                    }
                    break;
                case 2008442932:
                    if (flashPref.equals("flash_red_eye")) {
                        c = 7;
                        break;
                    }
                    break;
            }
            switch (c) {
                case 0:
                case 1:
                    imageView.setImageResource(R.drawable.ic_auto);
                    return;
                case 2:
                    imageView.setImageResource(R.drawable.ic_flash_off_ic);
                    return;
                case 3:
                case 6:
                    imageView.setImageResource(R.drawable.ic_flash);
                    return;
                case 4:
                case 5:
                    imageView.setImageResource(R.drawable.ic_flash_on_ic);
                    return;
                case 7:
                    imageView.setImageResource(R.drawable.ic_flash_red_eye);
                    return;
                default:
                    return;
            }
        }
    }

    public void updateOnScreenIcons() {
        Log.d(TAG, "updateOnScreenIcons");
        updateExposureLockIcon();
        updateWhiteBalanceLockIcon();
        updateCycleRawIcon();
        updateStoreLocationIcon();
        updateTextStampIcon();
        updateStampIcon();
        updateAutoLevelIcon();
        updateCycleFlashIcon();
        updateFaceDetectionIcon();
    }

    public void toggleExposureUI() {
        Log.d(TAG, "toggleExposureUI");
        closePopup();
        this.mSelectingExposureUIElement = false;
        if (isExposureUIOpen() || this.main_activity.getPreview().getCameraController() == null) {
            return;
        }
        setupExposureUI();
        if (this.main_activity.getBluetoothRemoteControl().remoteEnabled()) {
            initRemoteControlForExposureUI();
        }
    }

    private void initRemoteControlForExposureUI() {
        Log.d(TAG, "initRemoteControlForExposureUI");
        if (isExposureUIOpen()) {
            this.remote_control_mode = true;
            this.mExposureLine = 0;
            highlightExposureUILine(true);
        }
    }

    private void clearRemoteControlForExposureUI() {
        Log.d(TAG, "clearRemoteControlForExposureUI");
        if (isExposureUIOpen() && this.remote_control_mode) {
            this.remote_control_mode = false;
            resetExposureUIHighlights();
        }
    }

    private void nextExposureUILine() {
        this.mExposureLine++;
        highlightExposureUILine(true);
    }

    private void previousExposureUILine() {
        this.mExposureLine--;
        highlightExposureUILine(false);
    }

    private void nextExposureUIItem() {
        Log.d(TAG, "nextExposureUIItem");
        if (this.mExposureLine != 0) {
            return;
        }
        nextIsoItem(false);
    }

    private void previousExposureUIItem() {
        Log.d(TAG, "previousExposureUIItem");
        if (this.mExposureLine != 0) {
            return;
        }
        nextIsoItem(true);
    }

    private void nextIsoItem(boolean z) {
        Log.d(TAG, "nextIsoItem: " + z);
        String string = PreferenceManager.getDefaultSharedPreferences(this.main_activity).getString(PreferenceKeys.ISOPreferenceKey, "auto");
        int size = this.iso_buttons.size();
        boolean z2 = true;
        int i = z ? -1 : 1;
        int i2 = 0;
        while (true) {
            if (i2>=size) {
                z2 = false;
                break;
            }
            if (("" + ((Object) ((Button) this.iso_buttons.get(i2)).getText())).contains(string)) {
                int i3 = i2 + size;
                Button button = (Button) this.iso_buttons.get((i3 + i) % size);
                if (("" + ((Object) button.getText())).contains(manual_iso_value)) {
                    button = (Button) this.iso_buttons.get((i3 + (i * 2)) % size);
                }
                button.callOnClick();
            } else {
                i2++;
            }
        }
        if (z2) {
            return;
        }
        this.iso_buttons.get(0).callOnClick();
    }

    private void selectExposureUILine() {
        Log.d(TAG, "selectExposureUILine");
        if (isExposureUIOpen()) {
            int i = this.mExposureLine;
            if (i != 0) {
                if (i == 1) {
                    this.mSelectingExposureUIElement = true;
                    return;
                } else if (i == 2) {
                    this.mSelectingExposureUIElement = true;
                    return;
                } else if (i == 3) {
                    this.mSelectingExposureUIElement = true;
                    return;
                } else if (i == 4) {
                    this.mSelectingExposureUIElement = true;
                    return;
                } else {
                    return;
                }
            }
            String string = PreferenceManager.getDefaultSharedPreferences(this.main_activity).getString(PreferenceKeys.ISOPreferenceKey, "auto");
            Button button = null;
            Iterator<View> it = this.iso_buttons.iterator();
            boolean z = false;
            while (it.hasNext()) {
                Button button2 = (Button) it.next();
                String str = "" + ((Object) button2.getText());
                if (str.contains(string)) {
                    z = true;
                } else {
                    if (str.contains(manual_iso_value)) {
                        button = button2;
                    }
                    button2.setBackgroundColor(0);
                }
            }
            if (!z && button != null) {
                button.setBackgroundColor(this.highlightColorExposureUIElement);
            }
            this.mSelectingExposureUIElement = true;
        }
    }

    int getMaxHeightDp(boolean z) {
        Display defaultDisplay = this.main_activity.getWindowManager().getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        defaultDisplay.getMetrics(displayMetrics);
        int min = (int) (Math.min(displayMetrics.widthPixels, displayMetrics.heightPixels) / this.main_activity.getResources().getDisplayMetrics().density);
        Log.d(TAG, "display size: " + displayMetrics.widthPixels + " " + displayMetrics.heightPixels);
        StringBuilder sb = new StringBuilder();
        sb.append("dpHeight: ");
        sb.append(min);
        Log.d(TAG, sb.toString());
        return min - (z ? 120 : 50);
    }

    public boolean isSelectingExposureUIElement() {
        Log.d(TAG, "isSelectingExposureUIElement returns:" + this.mSelectingExposureUIElement);
        return this.mSelectingExposureUIElement;
    }

    public boolean processRemoteUpButton() {
        Log.d(TAG, "processRemoteUpButton");
        if (popupIsOpen()) {
            if (selectingIcons()) {
                previousPopupIcon();
                return true;
            } else if (selectingLines()) {
                previousPopupLine();
                return true;
            } else {
                return true;
            }
        } else if (isExposureUIOpen()) {
            if (isSelectingExposureUIElement()) {
                nextExposureUIItem();
                return true;
            }
            previousExposureUILine();
            return true;
        } else {
            return false;
        }
    }

    public boolean processRemoteDownButton() {
        Log.d(TAG, "processRemoteDownButton");
        if (popupIsOpen()) {
            if (selectingIcons()) {
                nextPopupIcon();
                return true;
            } else if (selectingLines()) {
                nextPopupLine();
                return true;
            } else {
                return true;
            }
        } else if (isExposureUIOpen()) {
            if (isSelectingExposureUIElement()) {
                previousExposureUIItem();
                return true;
            }
            nextExposureUILine();
            return true;
        } else {
            return false;
        }
    }

    public void updateSelectedISOButton() {
        Log.d(TAG, "updateSelectedISOButton");
        if (this.main_activity.getPreview().supportsISORange() && isExposureUIOpen()) {
            String string = PreferenceManager.getDefaultSharedPreferences(this.main_activity).getString(PreferenceKeys.ISOPreferenceKey, "auto");
            Log.d(TAG, "current_iso: " + string);
            boolean z = false;
            Iterator<View> it = this.iso_buttons.iterator();
            while (it.hasNext()) {
                Button button = (Button) it.next();
                Log.d(TAG, "button: " + ((Object) button.getText()));
                if (("" + ((Object) button.getText())).contains(string)) {
                    z = true;
                }
            }
            if (z || string.equals("auto")) {
                return;
            }
            Log.d(TAG, "must be manual");
            int i = this.iso_button_manual_index;
            if (i<0 || i>=this.iso_buttons.size()) {
                return;
            }
            Button button2 = (Button) this.iso_buttons.get(this.iso_button_manual_index);
        }
    }

    public void setSeekbarZoom(int i) {
        String str = TAG;
        Log.d(str, "setSeekbarZoom: " + i);
        SeekBar seekBar = (SeekBar) this.main_activity.findViewById(R.id.zoom_seekbar);
        Log.d(str, "progress was: " + seekBar.getProgress());
        seekBar.setProgress(this.main_activity.getPreview().getMaxZoom() - i);
        Log.d(str, "progress is now: " + seekBar.getProgress());
    }

    public void changeSeekbar(int i, int i2) {
        Log.d(TAG, "changeSeekbar: " + i2);
        SeekBar seekBar = (SeekBar) this.main_activity.findViewById(i);
        int progress = seekBar.getProgress();
        int i3 = i2 + progress;
        if (i3<0) {
            i3 = 0;
        } else if (i3>seekBar.getMax()) {
            i3 = seekBar.getMax();
        }
        Log.d(TAG, "value: " + progress);
        Log.d(TAG, "new_value: " + i3);
        Log.d(TAG, "max: " + seekBar.getMax());
        if (i3 != progress) {
            seekBar.setProgress(i3);
        }
    }

    public void closePopup() {
        Log.d(TAG, "close popup");
        if (popupIsOpen()) {
            clearRemoteControlForPopup();
            clearSelectionState();
            this.popup_view_is_open = false;
            if (this.force_destroy_popup) {
                destroyPopup();
            }
            this.main_activity.initImmersiveMode();
        }
    }

    public boolean popupIsOpen() {
        return this.popup_view_is_open;
    }

    public boolean selectingIcons() {
        return this.mSelectingIcons;
    }

    public boolean selectingLines() {
        return this.mSelectingLines;
    }

    private void highlightPopupIcon(boolean z, boolean z2) {
        Log.d(TAG, "highlightPopupIcon");
        Log.d(TAG, "highlight: " + z);
        Log.d(TAG, "goLeft: " + z2);
        if (!popupIsOpen()) {
            clearSelectionState();
            return;
        }
        highlightPopupLine(false, false);
        int childCount = this.mHighlightedLine.getChildCount();
        boolean z3 = false;
        while (!z3) {
            int i = (this.mPopupIcon + childCount) % childCount;
            this.mPopupIcon = i;
            View childAt = this.mHighlightedLine.getChildAt(i);
            Log.d(TAG, "row: " + this.mPopupIcon + " view: " + childAt);
            if ((childAt instanceof ImageButton) || (childAt instanceof Button)) {
                if (z) {
                    childAt.setBackgroundColor(this.highlightColor);
                    this.mHighlightedIcon = childAt;
                    this.mSelectingIcons = true;
                } else {
                    childAt.setBackgroundColor(0);
                }
                Log.d(TAG, "found icon at row: " + this.mPopupIcon);
                z3 = true;
            } else {
                this.mPopupIcon += z2 ? -1 : 1;
            }
        }
    }

    private void nextPopupLine() {
        highlightPopupLine(false, false);
        this.mPopupLine++;
        highlightPopupLine(true, false);
    }

    private void previousPopupLine() {
        highlightPopupLine(false, true);
        this.mPopupLine--;
        highlightPopupLine(true, true);
    }

    private void nextPopupIcon() {
        highlightPopupIcon(false, false);
        this.mPopupIcon++;
        highlightPopupIcon(true, false);
    }

    private void previousPopupIcon() {
        highlightPopupIcon(false, true);
        this.mPopupIcon--;
        highlightPopupIcon(true, true);
    }

    private void clickSelectedIcon() {
        Log.d(TAG, "clickSelectedIcon: " + this.mHighlightedIcon);
        View view = this.mHighlightedIcon;
        if (view != null) {
            view.callOnClick();
        }
    }

    private void clearSelectionState() {
        Log.d(TAG, "clearSelectionState");
        this.mPopupLine = 0;
        this.mPopupIcon = 0;
        this.mSelectingIcons = false;
        this.mSelectingLines = false;
        this.mHighlightedIcon = null;
        this.mHighlightedLine = null;
    }

    public void togglePopupSettings() {
        this.main_activity.getPreview().cancelTimer();
        this.main_activity.stopAudioListeners();
        long currentTimeMillis = System.currentTimeMillis();
        this.popup_view_is_open = true;
        if (this.main_activity.getBluetoothRemoteControl().remoteEnabled()) {
            initRemoteControlForPopup();
        }
        Log.d(TAG, "time to create popup: " + (System.currentTimeMillis() - currentTimeMillis));
    }

    private void initRemoteControlForPopup() {
        Log.d(TAG, "initRemoteControlForPopup");
        if (popupIsOpen()) {
            clearSelectionState();
            this.remote_control_mode = true;
            this.mSelectingLines = true;
            highlightPopupLine(true, false);
        }
    }

    private void clearRemoteControlForPopup() {
        Log.d(TAG, "clearRemoteControlForPopup");
        if (popupIsOpen() && this.remote_control_mode) {
            this.remote_control_mode = false;
            new Rect();
        }
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        AudioManager audioManager;
        char c;
        Log.d(TAG, "onKeyDown: " + i);
        if (i != 19) {
            if (i != 20) {
                if (i != 24 && i != 25) {
                    if (i == 27) {
                        if (keyEvent.getRepeatCount() == 0) {
                            this.main_activity.takePicture(false);
                            return true;
                        }
                    } else {
                        if (i != 62) {
                            if (i != 69) {
                                if (i != 76) {
                                    if (i != 88) {
                                        if (i != 119) {
                                            if (i != 146) {
                                                if (i != 149) {
                                                    if (i != 152) {
                                                        if (i != 85 && i != 86) {
                                                            if (i != 168) {
                                                                if (i != 169) {
                                                                    switch (i) {
                                                                        case 80:
                                                                            break;
                                                                        case 81:
                                                                            break;
                                                                        case 82:
                                                                            return true;
                                                                        default:
                                                                            switch (i) {
                                                                                case 154:
                                                                                    break;
                                                                                case 155:
                                                                                    break;
                                                                                case 156:
                                                                                    break;
                                                                                case 157:
                                                                                    break;
                                                                                default:
                                                                                    return false;
                                                                            }
                                                                    }
                                                                }
                                                            }
                                                            this.main_activity.zoomIn();
                                                            return true;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        togglePopupSettings();
                                        return false;
                                    }
                                }
                                toggleExposureUI();
                                return false;
                            }
                            this.main_activity.zoomOut();
                            return true;
                        }
                        if (isExposureUIOpen() && this.remote_control_mode) {
                            commandMenuExposure();
                            return true;
                        } else if (popupIsOpen() && this.remote_control_mode) {
                            commandMenuPopup();
                            return true;
                        } else {
                            if (keyEvent.getRepeatCount() == 0) {
                                this.main_activity.takePicture(false);
                                return true;
                            }
                            return false;
                        }
                    }
                    if (keyEvent.getDownTime() == keyEvent.getEventTime() && !this.main_activity.getPreview().isFocusWaiting()) {
                        Log.d(TAG, "request focus due to focus key");
                        this.main_activity.getPreview().requestAutoFocus();
                    }
                    return true;
                }
                if (i == 24) {
                    this.keydown_volume_up = true;
                } else if (i == 25) {
                    this.keydown_volume_down = true;
                }
                SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.main_activity);
                String string = defaultSharedPreferences.getString(PreferenceKeys.VolumeKeysPreferenceKey, "volume_take_photo");
                if ((i != 88 && i != 85 && i != 86) || string.equals("volume_take_photo") || ((audioManager = (AudioManager) this.main_activity.getSystemService("audio")) != null && audioManager.isWiredHeadsetOn())) {
                    string.hashCode();
                    switch (string.hashCode()) {
                        case -1359912077:
                            if (string.equals("volume_focus")) {
                                c = 0;
                                break;
                            }
                            c = 65535;
                            break;
                        case -925372737:
                            if (string.equals("volume_take_photo")) {
                                c = 1;
                                break;
                            }
                            c = 65535;
                            break;
                        case -874555944:
                            if (string.equals("volume_zoom")) {
                                c = 2;
                                break;
                            }
                            c = 65535;
                            break;
                        case -692640628:
                            if (string.equals("volume_exposure")) {
                                c = 3;
                                break;
                            }
                            c = 65535;
                            break;
                        case 529947390:
                            if (string.equals("volume_really_nothing")) {
                                c = 4;
                                break;
                            }
                            c = 65535;
                            break;
                        case 915660971:
                            if (string.equals("volume_auto_stabilise")) {
                                c = 5;
                                break;
                            }
                            c = 65535;
                            break;
                        default:
                            c = 65535;
                            break;
                    }
                    switch (c) {
                        case 0:
                            if (this.keydown_volume_up && this.keydown_volume_down) {
                                Log.d(TAG, "take photo rather than focus, as both volume keys are down");
                                this.main_activity.takePicture(false);
                            } else if (this.main_activity.getPreview().getCurrentFocusValue() == null || !this.main_activity.getPreview().getCurrentFocusValue().equals("focus_mode_manual2")) {
                                if (keyEvent.getDownTime() == keyEvent.getEventTime() && !this.main_activity.getPreview().isFocusWaiting()) {
                                    Log.d(TAG, "request focus due to volume key");
                                    this.main_activity.getPreview().requestAutoFocus();
                                }
                            } else if (i == 24) {
                                this.main_activity.changeFocusDistance(-1, false);
                            } else {
                                this.main_activity.changeFocusDistance(1, false);
                            }
                            return true;
                        case 1:
                            this.main_activity.takePicture(false);
                            return true;
                        case 2:
                            if (i == 24) {
                                this.main_activity.zoomIn();
                            } else {
                                this.main_activity.zoomOut();
                            }
                            return true;
                        case 3:
                            if (this.main_activity.getPreview().getCameraController() != null) {
                                boolean z = !defaultSharedPreferences.getString(PreferenceKeys.ISOPreferenceKey, "auto").equals("auto");
                                if (i == 24) {
                                    if (z) {
                                        if (this.main_activity.getPreview().supportsISORange()) {
                                            this.main_activity.changeISO(1);
                                        }
                                    } else {
                                        this.main_activity.changeExposure(1);
                                    }
                                } else if (z) {
                                    if (this.main_activity.getPreview().supportsISORange()) {
                                        this.main_activity.changeISO(-1);
                                    }
                                } else {
                                    this.main_activity.changeExposure(-1);
                                }
                            }
                            return true;
                        case 4:
                            return true;
                        case 5:
                            if (this.main_activity.supportsAutoStabilise()) {
                                boolean z2 = !defaultSharedPreferences.getBoolean(PreferenceKeys.AutoStabilisePreferenceKey, false);
                                SharedPreferences.Editor edit = defaultSharedPreferences.edit();
                                edit.putBoolean(PreferenceKeys.AutoStabilisePreferenceKey, z2);
                                edit.apply();
                                StringBuilder sb = new StringBuilder();
                                sb.append(this.main_activity.getResources().getString(R.string.preference_auto_stabilise));
                                sb.append(": ");
                                sb.append(this.main_activity.getResources().getString(z2 ? R.string.on : R.string.off));
                                this.main_activity.getPreview().showToast(this.main_activity.getChangedAutoStabiliseToastBoxer(), sb.toString());
                                this.main_activity.getApplicationInterface().getDrawPreview().updateSettings();
                                destroyPopup();
                            } else {
                                this.main_activity.getPreview().showToast(this.main_activity.getChangedAutoStabiliseToastBoxer(), R.string.auto_stabilise_not_supported);
                            }
                            return true;
                    }
                }
                return false;
            }
            if (!this.remote_control_mode) {
                if (popupIsOpen()) {
                    initRemoteControlForPopup();
                    return true;
                } else if (isExposureUIOpen()) {
                    initRemoteControlForExposureUI();
                    return true;
                }
            } else if (processRemoteDownButton()) {
                return true;
            }
            return false;
        }
        if (!this.remote_control_mode) {
            if (popupIsOpen()) {
                initRemoteControlForPopup();
                return true;
            } else if (isExposureUIOpen()) {
                initRemoteControlForExposureUI();
                return true;
            }
        } else if (processRemoteUpButton()) {
            return true;
        }
        return false;
    }

    public void onKeyUp(int i, KeyEvent keyEvent) {
        Log.d(TAG, "onKeyUp: " + i);
        if (i == 24) {
            this.keydown_volume_up = false;
        } else if (i == 25) {
            this.keydown_volume_down = false;
        }
    }

    public void commandMenuExposure() {
        Log.d(TAG, "commandMenuExposure");
        if (isExposureUIOpen()) {
            if (isSelectingExposureUIElement()) {
                toggleExposureUI();
            } else {
                selectExposureUILine();
            }
        }
    }

    public void commandMenuPopup() {
        Log.d(TAG, "commandMenuPopup");
        if (popupIsOpen()) {
            if (selectingIcons()) {
                clickSelectedIcon();
            } else {
                highlightPopupIcon(true, false);
            }
        }
    }

    public AlertDialog showInfoDialog(int i, int i2, final String str) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this.main_activity);
        builder.setTitle(i);
        if (i2 != 0) {
            builder.setMessage(i2);
        }
        builder.setPositiveButton(17039370, (DialogInterface.OnClickListener) null);
        builder.setNegativeButton(R.string.dont_show_again, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i3) {
                Log.d(MainUI.TAG, "user clicked dont_show_again for info dialog");
                SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(MainUI.this.main_activity).edit();
                edit.putBoolean(str, true);
                edit.apply();
            }
        });
        this.main_activity.showPreview(false);
        this.main_activity.setWindowFlagsForSettings(false);
        AlertDialog create = builder.create();
        create.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.live.gpsmap.camera.Camera.ui.MainUI.5
            @Override // android.content.DialogInterface.OnDismissListener
            public void onDismiss(DialogInterface dialogInterface) {
                Log.d(MainUI.TAG, "info dialog dismissed");
                MainUI.this.main_activity.setWindowFlagsForCamera();
                MainUI.this.main_activity.showPreview(true);
            }
        });
        this.main_activity.showAlert(create);
        return create;
    }

    public String getEntryForWhiteBalance(String str) {
        char c;
        int i;
        str.hashCode();
        switch (str.hashCode()) {
            case -1081415738:
                if (str.equals("manual")) {
                    c = 0;
                    break;
                }
                c = 65535;
                break;
            case -939299377:
                if (str.equals("incandescent")) {
                    c = 1;
                    break;
                }
                c = 65535;
                break;
            case -719316704:
                if (str.equals("warm-fluorescent")) {
                    c = 2;
                    break;
                }
                c = 65535;
                break;
            case 3005871:
                if (str.equals("auto")) {
                    c = 3;
                    break;
                }
                c = 65535;
                break;
            case 109399597:
                if (str.equals("shade")) {
                    c = 4;
                    break;
                }
                c = 65535;
                break;
            case 474934723:
                if (str.equals("cloudy-daylight")) {
                    c = 5;
                    break;
                }
                c = 65535;
                break;
            case 1650323088:
                if (str.equals("twilight")) {
                    c = 6;
                    break;
                }
                c = 65535;
                break;
            case 1902580840:
                if (str.equals("fluorescent")) {
                    c = 7;
                    break;
                }
                c = 65535;
                break;
            case 1942983418:
                if (str.equals("daylight")) {
                    c = '\b';
                    break;
                }
                c = 65535;
                break;
            default:
                c = 65535;
                break;
        }
        switch (c) {
            case 0:
                i = R.string.white_balance_manual;
                break;
            case 1:
                i = R.string.white_balance_incandescent;
                break;
            case 2:
                i = R.string.white_balance_warm;
                break;
            case 3:
                i = R.string.white_balance_auto;
                break;
            case 4:
                i = R.string.white_balance_shade;
                break;
            case 5:
                i = R.string.white_balance_cloudy;
                break;
            case 6:
                i = R.string.white_balance_twilight;
                break;
            case 7:
                i = R.string.white_balance_fluorescent;
                break;
            case '\b':
                i = R.string.white_balance_daylight;
                break;
            default:
                i = -1;
                break;
        }
        return i != -1 ? this.main_activity.getResources().getString(i) : str;
    }

    public String getEntryForSceneMode(String str) {
        char c;
        int i;
        str.hashCode();
        switch (str.hashCode()) {
            case -1422950858:
                if (str.equals("action")) {
                    c = 0;
                    break;
                }
                c = 65535;
                break;
            case -1350043241:
                if (str.equals("theatre")) {
                    c = 1;
                    break;
                }
                c = 65535;
                break;
            case -895760513:
                if (str.equals("sports")) {
                    c = 2;
                    break;
                }
                c = 65535;
                break;
            case -891172202:
                if (str.equals("sunset")) {
                    c = 3;
                    break;
                }
                c = 65535;
                break;
            case -333584256:
                if (str.equals("barcode")) {
                    c = 4;
                    break;
                }
                c = 65535;
                break;
            case -300277408:
                if (str.equals("steadyphoto")) {
                    c = 5;
                    break;
                }
                c = 65535;
                break;
            case -264202484:
                if (str.equals("fireworks")) {
                    c = 6;
                    break;
                }
                c = 65535;
                break;
            case 3005871:
                if (str.equals("auto")) {
                    c = 7;
                    break;
                }
                c = 65535;
                break;
            case 3535235:
                if (str.equals("snow")) {
                    c = '\b';
                    break;
                }
                c = 65535;
                break;
            case 93610339:
                if (str.equals("beach")) {
                    c = '\t';
                    break;
                }
                c = 65535;
                break;
            case 104817688:
                if (str.equals("night")) {
                    c = '\n';
                    break;
                }
                c = 65535;
                break;
            case 106437350:
                if (str.equals("party")) {
                    c = 11;
                    break;
                }
                c = 65535;
                break;
            case 729267099:
                if (str.equals("portrait")) {
                    c = '\f';
                    break;
                }
                c = 65535;
                break;
            case 1430647483:
                if (str.equals("landscape")) {
                    c = '\r';
                    break;
                }
                c = 65535;
                break;
            case 1664284080:
                if (str.equals("night-portrait")) {
                    c = 14;
                    break;
                }
                c = 65535;
                break;
            case 1900012073:
                if (str.equals("candlelight")) {
                    c = 15;
                    break;
                }
                c = 65535;
                break;
            default:
                c = 65535;
                break;
        }
        switch (c) {
            case 0:
                i = R.string.scene_mode_action;
                break;
            case 1:
                i = R.string.scene_mode_theatre;
                break;
            case 2:
                i = R.string.scene_mode_sports;
                break;
            case 3:
                i = R.string.scene_mode_sunset;
                break;
            case 4:
                i = R.string.scene_mode_barcode;
                break;
            case 5:
                i = R.string.scene_mode_steady_photo;
                break;
            case 6:
                i = R.string.scene_mode_fireworks;
                break;
            case 7:
                i = R.string.scene_mode_auto;
                break;
            case '\b':
                i = R.string.scene_mode_snow;
                break;
            case '\t':
                i = R.string.scene_mode_beach;
                break;
            case '\n':
                i = R.string.scene_mode_night;
                break;
            case 11:
                i = R.string.scene_mode_party;
                break;
            case '\f':
                i = R.string.scene_mode_portrait;
                break;
            case '\r':
                i = R.string.scene_mode_landscape;
                break;
            case 14:
                i = R.string.scene_mode_night_portrait;
                break;
            case 15:
                i = R.string.scene_mode_candlelight;
                break;
            default:
                i = -1;
                break;
        }
        return i != -1 ? this.main_activity.getResources().getString(i) : str;
    }


    public String getEntryForColorEffect(String str) {
        char c;
        int i;
        str.hashCode();
        switch (str.hashCode()) {
            case -1635350969:
                if (str.equals("blackboard")) {
                    c = 0;
                    break;
                }
                c = 65535;
                break;
            case 3002044:
                if (str.equals("aqua")) {
                    c = 1;
                    break;
                }
                c = 65535;
                break;
            case 3357411:
                if (str.equals("mono")) {
                    c = 2;
                    break;
                }
                c = 65535;
                break;
            case 3387192:
                if (str.equals("none")) {
                    c = 3;
                    break;
                }
                c = 65535;
                break;
            case 109324790:
                if (str.equals("sepia")) {
                    c = 4;
                    break;
                }
                c = 65535;
                break;
            case 261182557:
                if (str.equals("whiteboard")) {
                    c = 5;
                    break;
                }
                c = 65535;
                break;
            case 921111605:
                if (str.equals("negative")) {
                    c = 6;
                    break;
                }
                c = 65535;
                break;
            case 1473417203:
                if (str.equals("solarize")) {
                    c = 7;
                    break;
                }
                c = 65535;
                break;
            case 2008448231:
                if (str.equals("posterize")) {
                    c = '\b';
                    break;
                }
                c = 65535;
                break;
            default:
                c = 65535;
                break;
        }
        switch (c) {
            case 0:
                i = R.string.color_effect_blackboard;
                break;
            case 1:
                i = R.string.color_effect_aqua;
                break;
            case 2:
                i = R.string.color_effect_mono;
                break;
            case 3:
                i = R.string.color_effect_none;
                break;
            case 4:
                i = R.string.color_effect_sepia;
                break;
            case 5:
                i = R.string.color_effect_whiteboard;
                break;
            case 6:
                i = R.string.color_effect_negative;
                break;
            case 7:
                i = R.string.color_effect_solarize;
                break;
            case '\b':
                i = R.string.color_effect_posterize;
                break;
            default:
                i = -1;
                break;
        }
        return i != -1 ? this.main_activity.getResources().getString(i) : str;
    }


    public View getTopIcon() {
        return this.top_icon;
    }

    public View getUIButton(String str) {
        Log.d(TAG, "getPopupButton(" + str + "): " + this.test_ui_buttons.get(str));
        StringBuilder sb = new StringBuilder();
        sb.append("this: ");
        sb.append(this);
        Log.d(TAG, sb.toString());
        Log.d(TAG, "popup_buttons: " + this.test_ui_buttons);
        return this.test_ui_buttons.get(str);
    }

    Map<String, View> getTestUIButtonsMap() {
        return this.test_ui_buttons;
    }

    public boolean testGetRemoteControlMode() {
        return this.remote_control_mode;
    }

    public int testGetPopupLine() {
        return this.mPopupLine;
    }

    public int testGetPopupIcon() {
        return this.mPopupIcon;
    }

    public int testGetExposureLine() {
        return this.mExposureLine;
    }
}
