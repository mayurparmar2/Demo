package com.live.gpsmap.camera.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.SP;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

@SuppressWarnings("All")
public class TimeZone_BottomSheet extends BottomSheetDialogFragment {
    public static final String TAG = "TimeZone_BottomSheet";
    ImageView iv_tz1;
    ImageView iv_tz2;
    ImageView iv_tz3;
    ImageView iv_tz4;
    ImageView iv_tz5;
    ImageView iv_tz6;
    ImageView iv_tz7;
    LinearLayout lin_tz1;
    LinearLayout lin_tz2;
    LinearLayout lin_tz3;
    LinearLayout lin_tz4;
    LinearLayout lin_tz5;
    LinearLayout lin_tz6;
    LinearLayout lin_tz7;
    SP mSP;
    OnSelectTimezone onSelectTimezone;
    int timezone;
    TextView tv_tz1;
    TextView tv_tz2;
    TextView tv_tz3;
    TextView tv_tz4;
    TextView tv_tz5;
    TextView tv_tz6;
    TextView tv_tz7;

    /* loaded from: classes3.dex */
    public interface OnSelectTimezone {
        void Onselect();
    }

    public void setOnSelectTimezone(OnSelectTimezone onSelectTimezone) {
        this.onSelectTimezone = onSelectTimezone;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_time_zone__bottom_sheet, viewGroup, false);
        this.lin_tz1 = (LinearLayout) inflate.findViewById(R.id.lin_tz1);
        this.lin_tz2 = (LinearLayout) inflate.findViewById(R.id.lin_tz2);
        this.lin_tz3 = (LinearLayout) inflate.findViewById(R.id.lin_tz3);
        this.lin_tz4 = (LinearLayout) inflate.findViewById(R.id.lin_tz4);
        this.lin_tz5 = (LinearLayout) inflate.findViewById(R.id.lin_tz5);
        this.lin_tz6 = (LinearLayout) inflate.findViewById(R.id.lin_tz6);
        this.lin_tz7 = (LinearLayout) inflate.findViewById(R.id.lin_tz7);
        this.iv_tz1 = (ImageView) inflate.findViewById(R.id.iv_tz1);
        this.iv_tz2 = (ImageView) inflate.findViewById(R.id.iv_tz2);
        this.iv_tz3 = (ImageView) inflate.findViewById(R.id.iv_tz3);
        this.iv_tz4 = (ImageView) inflate.findViewById(R.id.iv_tz4);
        this.iv_tz5 = (ImageView) inflate.findViewById(R.id.iv_tz5);
        this.iv_tz6 = (ImageView) inflate.findViewById(R.id.iv_tz6);
        this.iv_tz7 = (ImageView) inflate.findViewById(R.id.iv_tz7);
        this.tv_tz1 = (TextView) inflate.findViewById(R.id.tv_tz1);
        this.tv_tz2 = (TextView) inflate.findViewById(R.id.tv_tz2);
        this.tv_tz3 = (TextView) inflate.findViewById(R.id.tv_tz3);
        this.tv_tz4 = (TextView) inflate.findViewById(R.id.tv_tz4);
        this.tv_tz5 = (TextView) inflate.findViewById(R.id.tv_tz5);
        this.tv_tz6 = (TextView) inflate.findViewById(R.id.tv_tz6);
        this.tv_tz7 = (TextView) inflate.findViewById(R.id.tv_tz7);
        this.mSP = new SP(requireActivity());
        onClicklistners();
        return inflate;
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        int integer = this.mSP.getInteger(getActivity(), "timezone value", 7);
        this.timezone = integer;
        setStart(integer);
    }

    private void onClicklistners() {
        this.lin_tz1.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.TimeZone_BottomSheet.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                TimeZone_BottomSheet.this.mSP.setInteger(TimeZone_BottomSheet.this.getActivity(), "timezone value", 1);
                TimeZone_BottomSheet.this.setStart(1);
                TimeZone_BottomSheet.this.onSelectTimezone.Onselect();
                TimeZone_BottomSheet.this.dismiss();
            }
        });
        this.lin_tz2.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.TimeZone_BottomSheet.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                TimeZone_BottomSheet.this.mSP.setInteger(TimeZone_BottomSheet.this.getActivity(), "timezone value", 2);
                TimeZone_BottomSheet.this.setStart(2);
                TimeZone_BottomSheet.this.onSelectTimezone.Onselect();
                TimeZone_BottomSheet.this.dismiss();
            }
        });
        this.lin_tz3.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.TimeZone_BottomSheet.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                TimeZone_BottomSheet.this.mSP.setInteger(TimeZone_BottomSheet.this.getActivity(), "timezone value", 3);
                TimeZone_BottomSheet.this.setStart(3);
                TimeZone_BottomSheet.this.onSelectTimezone.Onselect();
                TimeZone_BottomSheet.this.dismiss();
            }
        });
        this.lin_tz4.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.TimeZone_BottomSheet.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                TimeZone_BottomSheet.this.mSP.setInteger(TimeZone_BottomSheet.this.getActivity(), "timezone value", 4);
                TimeZone_BottomSheet.this.setStart(4);
                TimeZone_BottomSheet.this.onSelectTimezone.Onselect();
                TimeZone_BottomSheet.this.dismiss();
            }
        });
        this.lin_tz5.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.TimeZone_BottomSheet.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                TimeZone_BottomSheet.this.mSP.setInteger(TimeZone_BottomSheet.this.getActivity(), "timezone value", 5);
                TimeZone_BottomSheet.this.setStart(5);
                TimeZone_BottomSheet.this.onSelectTimezone.Onselect();
                TimeZone_BottomSheet.this.dismiss();
            }
        });
        this.lin_tz6.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.TimeZone_BottomSheet.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                TimeZone_BottomSheet.this.mSP.setInteger(TimeZone_BottomSheet.this.getActivity(), "timezone value", 6);
                TimeZone_BottomSheet.this.setStart(6);
                TimeZone_BottomSheet.this.onSelectTimezone.Onselect();
                TimeZone_BottomSheet.this.dismiss();
            }
        });
        this.lin_tz7.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.TimeZone_BottomSheet.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                TimeZone_BottomSheet.this.mSP.setInteger(TimeZone_BottomSheet.this.getActivity(), "timezone value", 7);
                TimeZone_BottomSheet.this.setStart(7);
                TimeZone_BottomSheet.this.onSelectTimezone.Onselect();
                TimeZone_BottomSheet.this.dismiss();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setStart(int i) {
        String displayName = Calendar.getInstance().getTimeZone().getDisplayName(false, 1);
        Date time = Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.getDefault()).getTime();
        String format = new SimpleDateFormat("dd MMM yyyy").format(time);
        String format2 = new SimpleDateFormat("ZZZZZ", Locale.getDefault()).format(time);
        this.tv_tz1.setText(format);
        TextView textView = this.tv_tz2;
        textView.setText("UTC " + format);
        TextView textView2 = this.tv_tz3;
        textView2.setText("GMT " + format);
        this.tv_tz4.setText(format2);
        TextView textView3 = this.tv_tz5;
        textView3.setText("UTC " + format2);
        TextView textView4 = this.tv_tz6;
        textView4.setText("GMT " + format2);
        this.tv_tz7.setText(displayName);
        switch (i) {
            case 1:
                this.iv_tz1.setVisibility(View.VISIBLE);
                this.iv_tz2.setVisibility(View.GONE);
                this.iv_tz3.setVisibility(View.GONE);
                this.iv_tz4.setVisibility(View.GONE);
                this.iv_tz5.setVisibility(View.GONE);
                this.iv_tz6.setVisibility(View.GONE);
                this.iv_tz7.setVisibility(View.GONE);
                return;
            case 2:
                this.iv_tz1.setVisibility(View.GONE);
                this.iv_tz2.setVisibility(View.VISIBLE);
                this.iv_tz3.setVisibility(View.GONE);
                this.iv_tz4.setVisibility(View.GONE);
                this.iv_tz5.setVisibility(View.GONE);
                this.iv_tz6.setVisibility(View.GONE);
                this.iv_tz7.setVisibility(View.GONE);
                return;
            case 3:
                this.iv_tz1.setVisibility(View.GONE);
                this.iv_tz2.setVisibility(View.GONE);
                this.iv_tz3.setVisibility(View.VISIBLE);
                this.iv_tz4.setVisibility(View.GONE);
                this.iv_tz5.setVisibility(View.GONE);
                this.iv_tz6.setVisibility(View.GONE);
                this.iv_tz7.setVisibility(View.GONE);
                return;
            case 4:
                this.iv_tz1.setVisibility(View.GONE);
                this.iv_tz2.setVisibility(View.GONE);
                this.iv_tz3.setVisibility(View.GONE);
                this.iv_tz4.setVisibility(View.VISIBLE);
                this.iv_tz5.setVisibility(View.GONE);
                this.iv_tz6.setVisibility(View.GONE);
                this.iv_tz7.setVisibility(View.GONE);
                return;
            case 5:
                this.iv_tz1.setVisibility(View.GONE);
                this.iv_tz2.setVisibility(View.GONE);
                this.iv_tz3.setVisibility(View.GONE);
                this.iv_tz4.setVisibility(View.GONE);
                this.iv_tz5.setVisibility(View.VISIBLE);
                this.iv_tz6.setVisibility(View.GONE);
                this.iv_tz7.setVisibility(View.GONE);
                return;
            case 6:
                this.iv_tz1.setVisibility(View.GONE);
                this.iv_tz2.setVisibility(View.GONE);
                this.iv_tz3.setVisibility(View.GONE);
                this.iv_tz4.setVisibility(View.GONE);
                this.iv_tz5.setVisibility(View.GONE);
                this.iv_tz6.setVisibility(View.VISIBLE);
                this.iv_tz7.setVisibility(View.GONE);
                return;
            case 7:
                this.iv_tz1.setVisibility(View.GONE);
                this.iv_tz2.setVisibility(View.GONE);
                this.iv_tz3.setVisibility(View.GONE);
                this.iv_tz4.setVisibility(View.GONE);
                this.iv_tz5.setVisibility(View.GONE);
                this.iv_tz6.setVisibility(View.GONE);
                this.iv_tz7.setVisibility(View.VISIBLE);
                return;
            default:
                return;
        }
    }
}