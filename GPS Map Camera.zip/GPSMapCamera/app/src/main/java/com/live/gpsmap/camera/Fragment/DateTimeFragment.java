package com.live.gpsmap.camera.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.live.gpsmap.camera.Adapter.DateTimeAdapter;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.SP;

/* loaded from: classes.dex */
public class DateTimeFragment extends Fragment {
    OnDateSelectedListener callBack;
    private DateTimeAdapter mAdapter;
    String[] mDateArray;
    private RecyclerView mRecyclerview;
    private SP mSP;

    /* loaded from: classes2.dex */
    public interface OnDateSelectedListener {
        void onDateSelected();
    }

    public void setOnDate_SelectedListener(OnDateSelectedListener onDateSelectedListener) {
        this.callBack = onDateSelectedListener;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_template, viewGroup, false);
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        init(view);
    }

    private void init(View view) {
        this.mSP = new SP(getContext());
        this.mRecyclerview = (RecyclerView) view.findViewById(R.id.fragment_recyclerview);
        this.mDateArray = getResources().getStringArray(R.array.datetime_format_arry);
        setAdapter();
    }

    private void setAdapter() {
        this.mRecyclerview.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        this.mRecyclerview.setHasFixedSize(true);
        this.mRecyclerview.setAdapter(this.mAdapter);
    }
}