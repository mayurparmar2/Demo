package com.live.gpsmap.camera.Activity;


import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.text.Html;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.google.android.material.snackbar.Snackbar;
import com.live.gpsmap.camera.Compass.Compass;
import com.live.gpsmap.camera.Database.DateTimeDB;
import com.live.gpsmap.camera.Fragment.DateTimeFragment;
import com.live.gpsmap.camera.Fragment.DateTime_BottomSheet;
import com.live.gpsmap.camera.Fragment.Logo_BottomSheetfragment;
import com.live.gpsmap.camera.Fragment.MapTypeBottomSheetfragment;
import com.live.gpsmap.camera.Fragment.Note_bottom_sheetfragment;
import com.live.gpsmap.camera.Fragment.Numbering_BottomSheet;
import com.live.gpsmap.camera.Fragment.TimeZone_BottomSheet;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Default;
import com.live.gpsmap.camera.Utils.Helper.SingleClickListener;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.Utils.Util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.Executors;

@SuppressWarnings("All")
public class  TempletSettingActivity extends AppCompatActivity implements View.OnClickListener {
    int Humidity_color;
    String Logo_img;
    int accuracy_color;
    int accuracy_selection;
    int address_color;
    int altitude_color;
    int altitude_selection;
    int background_color;
    RelativeLayout banner_native_layout;
    private Compass compass;
    int compass_color;
    DateTimeDB dateTimeDB;
    DateTime_BottomSheet dateTime_bottomSheet;
    int date_time_color;
    int elevation_color;
    String font_style;
    ImageView imageview_logo;
    ImageView imageview_map;
    ImageView imgCompass;
    ImageView imgLogo;
    ImageView imgMap;
    ImageView imgWeather;
    ImageView img_accuracy;
    ImageView img_address;
    ImageView img_altitude;
    ImageView img_compass;
    ImageView img_datetime;
    ImageView img_elevation;
    ImageView img_humidity;
    ImageView img_humidity_stamp;
    ImageView img_latlog;
    ImageView img_logo;
    ImageView img_magnetic;
    ImageView img_magnetic_field;
    ImageView img_maptype;
    ImageView img_notes;
    ImageView img_numbering;
    ImageView img_pluscode;
    ImageView img_pressure;
    ImageView img_pressure_stamp;
    ImageView img_timezone;
    ImageView img_wether;
    ImageView img_wind;
    ImageView img_wind_stamp;
    ImageView imgstamp_1;
    ImageView imgstamp_2;
    boolean isAddress;
    boolean isCompass;
    boolean isCompassFound;
    boolean isDateTime;
    boolean isHumidity;
    boolean isIncrement;
    boolean isLatLng;
    boolean isMagneticField;
    boolean isMap;
    boolean isNumbering;
    boolean isPlusCode;
    boolean isWeather;
    boolean isaccuracy;
    boolean isaltitude;
    boolean iselevation;
    boolean islogo;
    boolean isnotes;
    boolean ispressure;
    boolean istimezone;
    boolean iswind;
    int lat_lng_color;
    LinearLayout li_address;
    LinearLayout li_compass;
    LinearLayout li_logo;
    LinearLayout li_magnetic_field;
    LinearLayout li_main_stamp_lay;
    LinearLayout li_rightView;
    LinearLayout li_stamp;
    LinearLayout li_weather;
    LinearLayout lin_accuracy;
    LinearLayout lin_altitude;
    LinearLayout lin_bottom_wether;
    LinearLayout lin_compass;
    LinearLayout lin_datetime;
    LinearLayout lin_fontstyle;
    LinearLayout lin_humity_stamp;
    LinearLayout lin_latlog;
    LinearLayout lin_logo;
    LinearLayout lin_magnetic;
    LinearLayout lin_map;
    LinearLayout lin_notes;
    LinearLayout lin_numbering;
    LinearLayout lin_pluscode;
    LinearLayout lin_pressure;
    LinearLayout lin_pressure_stamp;
    LinearLayout lin_stampcolor;
    LinearLayout lin_stampposition;
    LinearLayout lin_stampsize;
    LinearLayout lin_timezone;
    LinearLayout lin_waterma;
    LinearLayout lin_waterma_2;
    LinearLayout lin_wether;
    LinearLayout lin_wind;
    LinearLayout lin_wind_stamp;
    Logo_BottomSheetfragment logo_bottomSheetfragment;
    String[] mDateArray;
    String mDateFormat;
    Util mUtil;
    int mIconValue;
    int mLatLngType;
    String mMap_Type;
    String mPlusCodeType;
    int mPos_mapType;
    private SP mSP;
    String mStamp_Pos;
    String mStamp_Size;
    private RelativeLayout mToolbar_back;
    TypedArray mWeatherIcon;
    int magnetic_field_color;
    MapTypeBottomSheetfragment mapTypeBottomSheetfragment;
    float mfTemprature_value;
    String msTemprature_type;
    private TextView mtv_toolbar_title;
    Note_bottom_sheetfragment note_bottom_sheetfragment;
    int note_hastag_color;
    String notes;
    Numbering_BottomSheet numbering_bottomSheet;
    int numbering_color;
    int plus_code_color;
    String prefix;
    int pressure_color;
    int pressure_selection;
    int sequence;
    SharedPreferences sharedPreferences;
    String suffix;
    TimeZone_BottomSheet timeZone_bottomsheet;
    int timezone;
    TextView tv_address;
    TextView tv_address_line_1;
    TextView tv_compass;
    TextView tv_humidity;
    TextView tv_magnetic_field;
    TextView tv_pressure;
    TextView tv_weather;
    TextView tv_wind;
    TextView txt_accuracy;
    TextView txt_address;
    TextView txt_altitude;
    TextView txt_compass;
    TextView txt_datetime;
    TextView txt_fontstyle;
    TextView txt_humidity;
    TextView txt_latlog;
    TextView txt_magnetic;
    TextView txt_notes;
    TextView txt_numbering;
    TextView txt_pluscode;
    TextView txt_pressure;
    TextView txt_stampposition;
    TextView txt_stampsize;
    TextView txt_timezone;
    TextView txt_watermark_1;
    TextView txt_watermark_2;
    TextView txt_wether;
    TextView txt_wind;
    int weather_color;
    int wind_color;
    int wind_selected;
    int Temp_type = 0;
    Handler handler = new Handler();

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_templet_setting);
        this.mDateArray = getResources().getStringArray(R.array.datetime_format_arry);
        this.mSP = new SP(this);
        this.dateTimeDB = new DateTimeDB(this);
        this.sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        defindid();
        init();
        onclick();
        loadAds();
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
    }

    private void loadAds() {
//        this.ads = new Admob();
        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.rel_adaptive_banner);
        this.banner_native_layout = relativeLayout;
//        this.ads.loadAdaptive_banner(this, relativeLayout, getString(R.string.GMC_Banner_Details));
    }

    private void defindid() {
        this.mtv_toolbar_title = (TextView) findViewById(R.id.tv_toolbar_title);
        this.mToolbar_back = (RelativeLayout) findViewById(R.id.toolbar_back);
        this.mWeatherIcon = getResources().obtainTypedArray(R.array.wI);
        this.tv_address_line_1 = (TextView) findViewById(R.id.tv_address_line_1);
        this.tv_address = (TextView) findViewById(R.id.tv_address);
        this.tv_weather = (TextView) findViewById(R.id.tv_weather);
        this.tv_pressure = (TextView) findViewById(R.id.tv_pressure);
        this.txt_pressure = (TextView) findViewById(R.id.txt_pressure);
        this.tv_wind = (TextView) findViewById(R.id.tv_wind);
        this.tv_compass = (TextView) findViewById(R.id.tv_compass);
        this.tv_magnetic_field = (TextView) findViewById(R.id.tv_magnetic_field);
        this.txt_wether = (TextView) findViewById(R.id.txt_wether);
        this.txt_fontstyle = (TextView) findViewById(R.id.txt_fontstyle);
        this.txt_altitude = (TextView) findViewById(R.id.txt_altitude);
        this.txt_accuracy = (TextView) findViewById(R.id.txt_accuracy);
        this.txt_address = (TextView) findViewById(R.id.txt_address);
        this.txt_stampposition = (TextView) findViewById(R.id.txt_stampposition);
        this.txt_stampsize = (TextView) findViewById(R.id.txt_stampsize);
        this.txt_notes = (TextView) findViewById(R.id.txt_notes);
        this.txt_compass = (TextView) findViewById(R.id.txt_compass);
        this.txt_magnetic = (TextView) findViewById(R.id.txt_magnetic);
        this.txt_latlog = (TextView) findViewById(R.id.txt_latlog);
        this.txt_pluscode = (TextView) findViewById(R.id.txt_pluscode);
        this.txt_humidity = (TextView) findViewById(R.id.txt_humidity);
        this.tv_humidity = (TextView) findViewById(R.id.tv_humidity);
        this.txt_datetime = (TextView) findViewById(R.id.txt_datetime);
        this.txt_timezone = (TextView) findViewById(R.id.txt_timezone);
        this.txt_numbering = (TextView) findViewById(R.id.txt_numbering);
        this.imgMap = (ImageView) findViewById(R.id.imgMap);
        this.imageview_logo = (ImageView) findViewById(R.id.imageview_logo);
        this.imgLogo = (ImageView) findViewById(R.id.imgLogo);
        this.li_stamp = (LinearLayout) findViewById(R.id.li_stamp);
        this.lin_waterma = (LinearLayout) findViewById(R.id.lin_waterma);
        this.lin_waterma_2 = (LinearLayout) findViewById(R.id.lin_waterma_2);
        this.lin_pressure_stamp = (LinearLayout) findViewById(R.id.lin_pressure_stamp);
        this.lin_pressure = (LinearLayout) findViewById(R.id.lin_pressure);
        this.lin_wind_stamp = (LinearLayout) findViewById(R.id.lin_wind_stamp);
        this.lin_humity_stamp = (LinearLayout) findViewById(R.id.lin_humidity_stamp);
        this.lin_bottom_wether = (LinearLayout) findViewById(R.id.lin_bottom_wather);
        this.li_compass = (LinearLayout) findViewById(R.id.li_compass);
        this.lin_wind = (LinearLayout) findViewById(R.id.lin_wind);
        this.li_logo = (LinearLayout) findViewById(R.id.li_logo);
        this.txt_wind = (TextView) findViewById(R.id.txt_wind);
        this.imgCompass = (ImageView) findViewById(R.id.imgCompass);
        this.imgWeather = (ImageView) findViewById(R.id.imgWeather);
        this.img_pressure_stamp = (ImageView) findViewById(R.id.img_pressure_stamp);
        this.img_magnetic_field = (ImageView) findViewById(R.id.imgMagneticField);
        this.img_wind_stamp = (ImageView) findViewById(R.id.img_wind_stamp);
        this.img_humidity_stamp = (ImageView) findViewById(R.id.img_humidity_stamp);
        this.li_rightView = (LinearLayout) findViewById(R.id.li_rightView);
        this.li_magnetic_field = (LinearLayout) findViewById(R.id.li_magnetic_field);
        this.li_weather = (LinearLayout) findViewById(R.id.li_weather);
        this.li_main_stamp_lay = (LinearLayout) findViewById(R.id.li_main_stamp_lay);
        this.li_address = (LinearLayout) findViewById(R.id.li_address);
        this.lin_map = (LinearLayout) findViewById(R.id.lin_map);
        this.lin_latlog = (LinearLayout) findViewById(R.id.lin_latlog);
        this.lin_pluscode = (LinearLayout) findViewById(R.id.lin_pluscode);
        this.lin_fontstyle = (LinearLayout) findViewById(R.id.lin_fontstyle);
        this.lin_stampcolor = (LinearLayout) findViewById(R.id.lin_stampcolor);
        this.lin_datetime = (LinearLayout) findViewById(R.id.lin_datetime);
        this.lin_timezone = (LinearLayout) findViewById(R.id.lin_timezone);
        this.lin_numbering = (LinearLayout) findViewById(R.id.lin_numbering);
        this.lin_wether = (LinearLayout) findViewById(R.id.lin_wether);
        this.lin_altitude = (LinearLayout) findViewById(R.id.lin_altitude);
        this.lin_accuracy = (LinearLayout) findViewById(R.id.lin_accuracy);
        this.lin_stampposition = (LinearLayout) findViewById(R.id.lin_stampposition);
        this.lin_stampsize = (LinearLayout) findViewById(R.id.lin_stampsize);
        this.lin_logo = (LinearLayout) findViewById(R.id.lin_logo);
        this.lin_notes = (LinearLayout) findViewById(R.id.lin_notes);
        this.lin_magnetic = (LinearLayout) findViewById(R.id.lin_magnetic);
        this.lin_compass = (LinearLayout) findViewById(R.id.lin_compass);
        this.imgstamp_1 = (ImageView) findViewById(R.id.img_stamp);
        this.imgstamp_2 = (ImageView) findViewById(R.id.img_stamp_2);
        this.txt_watermark_1 = (TextView) findViewById(R.id.txt_watermark);
        this.txt_watermark_2 = (TextView) findViewById(R.id.txt_watermark_2);
        this.img_maptype = (ImageView) findViewById(R.id.img_maptype);
        this.img_address = (ImageView) findViewById(R.id.img_address);
        this.img_latlog = (ImageView) findViewById(R.id.img_latlog);
        this.img_pluscode = (ImageView) findViewById(R.id.img_pluscode);
        this.imageview_map = (ImageView) findViewById(R.id.imageview_map);
        this.img_datetime = (ImageView) findViewById(R.id.img_datetime);
        this.img_timezone = (ImageView) findViewById(R.id.img_timezone);
        this.img_numbering = (ImageView) findViewById(R.id.img_numbering);
        this.img_logo = (ImageView) findViewById(R.id.img_logo);
        this.img_notes = (ImageView) findViewById(R.id.img_notes);
        this.img_wether = (ImageView) findViewById(R.id.img_wether);
        this.img_compass = (ImageView) findViewById(R.id.img_compass);
        this.img_magnetic = (ImageView) findViewById(R.id.img_magnetic);
        this.img_wind = (ImageView) findViewById(R.id.img_wind);
        this.img_humidity = (ImageView) findViewById(R.id.img_humidity);
        this.img_pressure = (ImageView) findViewById(R.id.img_pressure);
        this.img_elevation = (ImageView) findViewById(R.id.img_elevation);
        this.img_altitude = (ImageView) findViewById(R.id.img_altitude);
        this.img_accuracy = (ImageView) findViewById(R.id.img_accuracy);
        this.li_main_stamp_lay.setVisibility(View.VISIBLE);
        this.li_main_stamp_lay.setBackgroundColor(getResources().getColor(R.color.trans_white));
    }

    private void init() {
        Intent intent = getIntent();
        if (intent != null) {
            this.Temp_type = intent.getIntExtra("temp_type", 0);
        }
        if (this.dateTimeDB.getNormalDates().size() == 0) {
            int i = 0;
            while (true) {
                String[] strArr = this.mDateArray;
                if (i >= strArr.length) {
                    break;
                }
                this.dateTimeDB.insetDate(strArr[i], "", 0, 0, 0, 0);
                i++;
            }
        }
        this.mUtil = new Util();
        if (this.Temp_type == 0) {
            this.mtv_toolbar_title.setText(getString(R.string.advance_template));
        } else {
            this.mtv_toolbar_title.setText(getString(R.string.classic_template));
        }
        int parseColor = Color.parseColor("#9c000000");
        int i2 = this.Temp_type;

        if (i2 == 0) {
            this.background_color = this.mSP.getInteger(this, SP.BACKGROUND_COLOR, parseColor);
            this.address_color = this.mSP.getInteger(this, SP.ADDRESS_COLOR, -1);
            this.date_time_color = this.mSP.getInteger(this, SP.DATE_TIME_COLOR, -1);
            this.lat_lng_color = this.mSP.getInteger(this, SP.LAT_LNG_COLOR, -1);
            this.plus_code_color = this.mSP.getInteger(this, SP.PLUS_CODE_COLOR, -1);
            this.weather_color = this.mSP.getInteger(this, SP.WEATHER_COLOR, -1);
            this.magnetic_field_color = this.mSP.getInteger(this, SP.MAGNETIC_FIELD_COLOR, -1);
            this.compass_color = this.mSP.getInteger(this, SP.COMPASS_COLOR, -1);
            this.note_hastag_color = this.mSP.getInteger(this, SP.NOTES_HASHTAG_COLOR, -1);
            this.wind_color = this.mSP.getInteger(this, SP.WIND_COLOR, -1);
            this.Humidity_color = this.mSP.getInteger(this, SP.HUMIDITY_COLOR, -1);
            this.pressure_color = this.mSP.getInteger(this, SP.PRESSURE_COLOR, -1);
            this.elevation_color = this.mSP.getInteger(this, SP.ELEVATION_COLOR, -1);
            this.altitude_color = this.mSP.getInteger(this, SP.ALTITUDE_COLOR, -1);
            this.accuracy_color = this.mSP.getInteger(this, SP.ACCURACY_COLOR, -1);
            this.numbering_color = this.mSP.getInteger(this, SP.NUMBERING_COLOR, -1);
            this.timezone = this.mSP.getInteger(this, SP.TIMEZONE, 6);
            this.sequence = this.mSP.getInteger(this, SP.SEQUENCE, 1);
            this.suffix = this.mSP.getString(this, SP.SUFFIX, "");
            this.prefix = this.mSP.getString(this, SP.PREFIX, "");
            this.isMap = this.mSP.getBoolean(this, SP.IS_MAP, true);
            this.isAddress = this.mSP.getBoolean(this, SP.IS_ADDRESS, true);
            this.isLatLng = this.mSP.getBoolean(this, SP.IS_LAT_LNG_TEMPLATE, true);
            this.isPlusCode = this.mSP.getBoolean(this, SP.IS_PLUS_CODE, false);
            this.isWeather = this.mSP.getBoolean(this, SP.IS_WEATHER, false);
            this.isDateTime = this.mSP.getBoolean(this, SP.IS_DATE_TIME, true);
            this.istimezone = this.mSP.getBoolean(this, SP.IS_TIMEZONE, true);
            this.isNumbering = this.mSP.getBoolean(this, SP.IS_NUMBERING, false);
            this.isIncrement = this.mSP.getBoolean(this, SP.IS_INCREMENT, true);
            this.isMagneticField = this.mSP.getBoolean(this, SP.IS_MAGNETIC_FIELD, false);
            this.isCompass = this.mSP.getBoolean(this, SP.IS_COMPASS, false);
            this.iswind = this.mSP.getBoolean(this, SP.IS_WIND, false);
            this.islogo = this.mSP.getBoolean(this, SP.IS_LOGO, false);
            this.isnotes = this.mSP.getBoolean(this, SP.IS_NOTES, false);
            this.ispressure = this.mSP.getBoolean(this, SP.IS_PRESSURE, false);
            this.isHumidity = this.mSP.getBoolean(this, SP.IS_HUMIDITY, false);
            this.iselevation = this.mSP.getBoolean(this, SP.IS_ELEVATION, false);
            this.isaltitude = this.mSP.getBoolean(this, SP.IS_ALTITUDE, false);
            this.isaccuracy = this.mSP.getBoolean(this, SP.IS_ACCURACY, false);
            this.Logo_img = this.mSP.getString(this, SP.LOGO_URI_CLASSIC, "no_logo");
            this.notes = this.mSP.getString(this, SP.NOTES_HASHTAG, Default.notes);
            this.font_style = this.mSP.getString(this, SP.STAMP_FONT_STYLE, Default.DEFAULT_FONT_STYLE);
            this.isCompassFound = this.mSP.getBoolean(this, SP.COMPASS_FOUND, false);
            this.mDateFormat = this.mSP.getString(this, SP.DATE_FORMAT, Default.DEFAULT_DATE_FORMAT);
            this.mLatLngType = this.mSP.getInteger(this, SP.LAT_LNG_TYPE, 1);
            this.msTemprature_type = this.mSP.getString(this, SP.TEMPRATURE_TYPE, "Celsius");
            this.mfTemprature_value = this.mSP.getFloat(this, SP.TEMPRETURE_VALUE);
            int integer = this.mSP.getInteger(this, SP.WEATHER_ICON, 0);
            this.mIconValue = integer;
            this.imgWeather.setImageResource(this.mWeatherIcon.getResourceId(integer, 0));
            this.mMap_Type = this.mSP.getString(this, SP.MAP_TYPE_TEMPLATE, Default.SETELLITE_2);
            this.mPos_mapType = this.mSP.getInteger(this, SP.MAP_POS, 1);
            this.mStamp_Pos = this.mSP.getString(this, SP.STAMP_POS, "Bottom");
            this.mStamp_Size = this.mSP.getString(this, SP.STAMP_SIZE, Default.TEMPLATE_SIZE);
            this.mPlusCodeType = this.mSP.getString(this, SP.PLUS_CODE_TYPE, Default.PLUSCODE_TYPE);
            this.wind_selected = this.mSP.getInteger(this, SP.WIND_SELECT, 0);
            this.altitude_selection = this.mSP.getInteger(this, SP.ALTITUDE_SELECT, 0);
            this.accuracy_selection = this.mSP.getInteger(this, SP.ACCURACY_SELECT, 0);
            this.pressure_selection = this.mSP.getInteger(this, SP.PRESSURE_SELECT, 0);
        } else {
            this.background_color = this.mSP.getInteger(this, SP.BACKGROUND_COLOR_CLASSIC, parseColor);
            this.address_color = this.mSP.getInteger(this, SP.ADDRESS_COLOR_CLASSIC, -1);
            this.date_time_color = this.mSP.getInteger(this, SP.DATE_TIME_COLOR_CLASSIC, -1);
            this.lat_lng_color = this.mSP.getInteger(this, SP.LAT_LNG_COLOR_CLASSIC, -1);
            this.plus_code_color = this.mSP.getInteger(this, SP.PLUS_CODE_COLOR_CLASSIC, -1);
            this.weather_color = this.mSP.getInteger(this, SP.WEATHER_COLOR_CLASSIC, -1);
            this.magnetic_field_color = this.mSP.getInteger(this, SP.MAGNETIC_FIELD_COLOR_CLASSIC, -1);
            this.compass_color = this.mSP.getInteger(this, SP.COMPASS_COLOR_CLASSIC, -1);
            this.note_hastag_color = this.mSP.getInteger(this, SP.NOTES_HASHTAG_COLOR_CLASSIC, -1);
            this.wind_color = this.mSP.getInteger(this, SP.WIND_COLOR_CLASSIC, -1);
            this.Humidity_color = this.mSP.getInteger(this, SP.HUMIDITY_COLOR_CLASSIC, -1);
            this.pressure_color = this.mSP.getInteger(this, SP.PRESSURE_COLOR_CLASSIC, -1);
            this.elevation_color = this.mSP.getInteger(this, SP.ELEVATION_COLOR_CLASSIC, -1);
            this.altitude_color = this.mSP.getInteger(this, SP.ALTITUDE_COLOR_CLASSIC, -1);
            this.accuracy_color = this.mSP.getInteger(this, SP.ACCURACY_COLOR_CLASSIC, -1);
            this.numbering_color = this.mSP.getInteger(this, SP.NUMBERING_COLOR_CLASSIC, -1);
            this.timezone = this.mSP.getInteger(this, SP.TIMEZONE_CLASSIC, 6);
            this.sequence = this.mSP.getInteger(this, SP.SEQUENCE_CLASSIC, 1);
            this.suffix = this.mSP.getString(this, SP.SUFFIX_CLASSIC, "");
            this.prefix = this.mSP.getString(this, SP.PREFIX_CLASSIC, "");
            this.isMap = this.mSP.getBoolean(this, SP.IS_MAP_CLASSIC, true);
            this.isAddress = this.mSP.getBoolean(this, SP.IS_ADDRESS, true);
            this.isLatLng = this.mSP.getBoolean(this, SP.IS_LAT_LNG_TEMPLATE, true);
            this.isPlusCode = this.mSP.getBoolean(this, SP.IS_PLUS_CODE_CLASSIC, false);
            this.isWeather = this.mSP.getBoolean(this, SP.IS_WEATHER_CLASSIC, false);
            this.isDateTime = this.mSP.getBoolean(this, SP.IS_DATE_TIME_CLASSIC, true);
            this.istimezone = this.mSP.getBoolean(this, SP.IS_TIMEZONE_CLASSIC, true);
            this.isNumbering = this.mSP.getBoolean(this, SP.IS_NUMBERING_CLASSIC, false);
            this.isIncrement = this.mSP.getBoolean(this, SP.IS_INCREMENT_CLASSIC, true);
            this.isMagneticField = this.mSP.getBoolean(this, SP.IS_MAGNETIC_FIELD_CLASSIC, false);
            this.isCompass = this.mSP.getBoolean(this, SP.IS_COMPASS_CLASSIC, false);
            this.iswind = this.mSP.getBoolean(this, SP.IS_WIND_CLASSIC, false);
            this.islogo = this.mSP.getBoolean(this, SP.IS_LOGO_CLASSIC, false);
            this.isnotes = this.mSP.getBoolean(this, SP.IS_NOTES_CLASSIC, false);
            this.ispressure = this.mSP.getBoolean(this, SP.IS_PRESSURE_CLASSIC, false);
            this.isHumidity = this.mSP.getBoolean(this, SP.IS_HUMIDITY_CLASSIC, false);
            this.iselevation = this.mSP.getBoolean(this, SP.IS_ELEVATION_CLASSIC, false);
            this.isaltitude = this.mSP.getBoolean(this, SP.IS_ALTITUDE_CLASSIC, false);
            this.isaccuracy = this.mSP.getBoolean(this, SP.IS_ACCURACY_CLASSIC, false);
            this.Logo_img = this.mSP.getString(this, SP.LOGO_URI_CLASSIC, "no_logo");
            this.notes = this.mSP.getString(this, SP.NOTES_HASHTAG_CLASSIC, Default.notes);
            this.font_style = this.mSP.getString(this, SP.STAMP_FONT_STYLE_CLASSIC, Default.DEFAULT_FONT_STYLE);
            this.isCompassFound = this.mSP.getBoolean(this, SP.COMPASS_FOUND, false);
            this.mDateFormat = this.mSP.getString(this, SP.DATE_FORMAT_CLASSIC, Default.DEFAULT_DATE_FORMAT);
            this.mLatLngType = this.mSP.getInteger(this, SP.LAT_LNG_TYPE_CLASSIC, 1);
            this.msTemprature_type = this.mSP.getString(this, SP.TEMPRATURE_TYPE_CLASSIC, "Celsius");
            this.mfTemprature_value = this.mSP.getFloat(this, SP.TEMPRETURE_VALUE);
            int integer2 = this.mSP.getInteger(this, SP.WEATHER_ICON, 0);
            this.mIconValue = integer2;
            this.imgWeather.setImageResource(this.mWeatherIcon.getResourceId(integer2, 0));
            this.mMap_Type = this.mSP.getString(this, SP.MAP_TYPE_TEMPLATE_CLASSIC, Default.SETELLITE_2);
            this.mPos_mapType = this.mSP.getInteger(this, SP.MAP_POS_CLASSIC, 1);
            this.mStamp_Pos = this.mSP.getString(this, SP.STAMP_POS_CLASSIC, "Bottom");
            this.mStamp_Size = this.mSP.getString(this, SP.STAMP_SIZE_CLASSIC, Default.TEMPLATE_SIZE);
            this.mPlusCodeType = this.mSP.getString(this, SP.PLUS_CODE_TYPE_CLASSIC, Default.PLUSCODE_TYPE);
            this.wind_selected = this.mSP.getInteger(this, SP.WIND_SELECT_CLASSIC, 0);
            this.altitude_selection = this.mSP.getInteger(this, SP.ALTITUDE_SELECT, 0);
            this.accuracy_selection = this.mSP.getInteger(this, SP.ACCURACY_SELECT_CLASSIC, 0);
            this.pressure_selection = this.mSP.getInteger(this, SP.PRESSURE_SELECT_CLASSIC, 0);
        }
        savePreviousData();
        setTempratureData();
        setMapType();
        setColors();
        setstamppostion();
        setstampsize();
        setLogo();
        setNotes();
        sethumidity();
        setwind();
        setpressure();
        setaltitude();
        setaccuracy();
        setfontstyle();
        setTemplate();
        setcompass();
        setmagnatic();
        if (getLocation_Type().equals(Default.AUTOMATIC)) {
            this.txt_address.setText(getString(R.string.automatic));
        } else {
            this.txt_address.setText(getString(R.string.manual));
        }
        setdate();
        settimezone(this.timezone);
        setNumbering();
        setlatlog();
        setPlusCode();
        if (this.isMap) {
            this.img_maptype.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_maptype.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        if (this.isAddress) {
            this.img_address.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_address.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        if (this.isCompass) {
            this.img_compass.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_compass.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        if (this.isDateTime) {
            this.img_datetime.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_datetime.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        if (this.istimezone) {
            this.img_timezone.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_timezone.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        if (this.isNumbering) {
            this.img_numbering.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_numbering.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        if (this.isLatLng) {
            this.img_latlog.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_latlog.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        if (this.isPlusCode) {
            this.img_pluscode.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_pluscode.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        if (this.isMagneticField) {
            this.img_magnetic.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_magnetic.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        if (this.isWeather) {
            this.img_wether.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_wether.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        if (this.iswind) {
            this.img_wind.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_wind.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        if (this.isHumidity) {
            this.img_humidity.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_humidity.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        if (this.ispressure) {
            this.img_pressure.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_pressure.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        if (this.iselevation) {
            this.img_elevation.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_elevation.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        if (this.isaltitude) {
            this.img_altitude.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_altitude.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        if (this.isaccuracy) {
            this.img_accuracy.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_accuracy.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        if (this.islogo) {
            this.img_logo.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_logo.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        if (this.isnotes) {
            this.img_notes.setImageResource(R.drawable.ic_select_btn);
        } else {
            this.img_notes.setImageResource(R.drawable.ic_uncheck_box_tple);
        }
        MapTypeBottomSheetfragment mapTypeBottomSheetfragment = new MapTypeBottomSheetfragment();
        this.mapTypeBottomSheetfragment = mapTypeBottomSheetfragment;
        mapTypeBottomSheetfragment.setOnMap_SelectedListener(new MapTypeBottomSheetfragment.OnMapTypeSelectedListener() {
            @Override
            public void onMapTypeSelected() {
                TempletSettingActivity.this.setMapType();
            }

            @Override
            public void onLatLngType() {
                TempletSettingActivity.this.setlatlog();
                TempletSettingActivity.this.setTemplate();
            }

            @Override
            public void Ontempraturechange() {
                TempletSettingActivity.this.setTempratureData();
            }

            @Override // com.gpsmapcamera.geotagginglocationonphoto.fragment.MapTypeBottomSheetfragment.OnMapTypeSelectedListener
            public void OnStampPositionchange() {
                TempletSettingActivity.this.setstamppostion();
            }

            @Override // com.gpsmapcamera.geotagginglocationonphoto.fragment.MapTypeBottomSheetfragment.OnMapTypeSelectedListener
            public void OnStampSizechange() {
                TempletSettingActivity.this.setstampsize();
            }

            @Override // com.gpsmapcamera.geotagginglocationonphoto.fragment.MapTypeBottomSheetfragment.OnMapTypeSelectedListener
            public void OnPlusCodeTypechange() {
                TempletSettingActivity.this.setPlusCode();
            }

            @Override // com.gpsmapcamera.geotagginglocationonphoto.fragment.MapTypeBottomSheetfragment.OnMapTypeSelectedListener
            public void Onwindselected() {
                TempletSettingActivity.this.setwind();
            }

            @Override // com.gpsmapcamera.geotagginglocationonphoto.fragment.MapTypeBottomSheetfragment.OnMapTypeSelectedListener
            public void OnFontselected() {
                TempletSettingActivity.this.setfontstyle();
            }

            @Override // com.gpsmapcamera.geotagginglocationonphoto.fragment.MapTypeBottomSheetfragment.OnMapTypeSelectedListener
            public void Onpressureselection() {
                TempletSettingActivity.this.setpressure();
            }

            @Override // com.gpsmapcamera.geotagginglocationonphoto.fragment.MapTypeBottomSheetfragment.OnMapTypeSelectedListener
            public void Onaltitudeselect() {
                TempletSettingActivity.this.setaltitude();
            }

            @Override // com.gpsmapcamera.geotagginglocationonphoto.fragment.MapTypeBottomSheetfragment.OnMapTypeSelectedListener
            public void Onaccuracyselect() {
                TempletSettingActivity.this.setaccuracy();
            }
        });
        DateTime_BottomSheet dateTime_BottomSheet = new DateTime_BottomSheet();
        this.dateTime_bottomSheet = dateTime_BottomSheet;
        dateTime_BottomSheet.setOnDate_SelectedListener(new DateTimeFragment.OnDateSelectedListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.TempletSettingActivity.2
            @Override // com.gpsmapcamera.geotagginglocationonphoto.fragment.DateTimeFragment.OnDateSelectedListener
            public void onDateSelected() {
                TempletSettingActivity.this.setdate();
                TempletSettingActivity.this.setTemplate();
            }
        });
        TimeZone_BottomSheet timeZone_BottomSheet = new TimeZone_BottomSheet();
        this.timeZone_bottomsheet = timeZone_BottomSheet;
        timeZone_BottomSheet.setOnSelectTimezone(new TimeZone_BottomSheet.OnSelectTimezone() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.TempletSettingActivity.3
            @Override // com.gpsmapcamera.geotagginglocationonphoto.fragment.TimeZone_BottomSheet.OnSelectTimezone
            public void Onselect() {
                TempletSettingActivity templetSettingActivity = TempletSettingActivity.this;
                templetSettingActivity.settimezone(templetSettingActivity.getTimezoneTemp());
                TempletSettingActivity.this.setTemplate();
            }
        });
        Numbering_BottomSheet numbering_BottomSheet = new Numbering_BottomSheet();
        this.numbering_bottomSheet = numbering_BottomSheet;
        numbering_BottomSheet.setOnSelectNumbering(new Numbering_BottomSheet.OnSelectNumbering() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.TempletSettingActivity.4
            @Override // com.gpsmapcamera.geotagginglocationonphoto.fragment.Numbering_BottomSheet.OnSelectNumbering
            public void Onselect() {
                TempletSettingActivity.this.setNumbering();
                TempletSettingActivity.this.setTemplate();
            }
        });
        Logo_BottomSheetfragment logo_BottomSheetfragment = new Logo_BottomSheetfragment();
        this.logo_bottomSheetfragment = logo_BottomSheetfragment;
        logo_BottomSheetfragment.setOnSelectlogo(new Logo_BottomSheetfragment.OnSelectlogo() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.TempletSettingActivity.5
            @Override // com.gpsmapcamera.geotagginglocationonphoto.fragment.Logo_BottomSheetfragment.OnSelectlogo
            public void Onselect() {
                TempletSettingActivity.this.setLogo();
            }
        });
        Note_bottom_sheetfragment note_bottom_sheetfragment = new Note_bottom_sheetfragment();
        this.note_bottom_sheetfragment = note_bottom_sheetfragment;
        note_bottom_sheetfragment.setOnselectitem(new Note_bottom_sheetfragment.Onselectitem() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.TempletSettingActivity.6
            @Override // com.gpsmapcamera.geotagginglocationonphoto.fragment.Note_bottom_sheetfragment.Onselectitem
            public void Onselect() {
                TempletSettingActivity.this.setNotes();
                TempletSettingActivity.this.setTemplate();
            }
        });
    }

    private void setmagnatic() {
        this.tv_magnetic_field.setText(getmagnetic());
        this.txt_magnetic.setText(getmagnetic());
    }

    private String getmagnetic() {
        return this.mSP.getString(this, SP.MAGNETIC_FIELD_VALUE, "");
    }

    private void setcompass() {
        this.tv_compass.setText(getCompassStr());
        this.txt_compass.setText(getCompassStr());
    }

    public String getCompassStr() {
        return this.mSP.getString(this, SP.COMPASS_VALUE, "");
    }


    public void setfontstyle() {
        String str = getfontstyle();
        this.txt_humidity.setTypeface(Util.getFontStyle(this, str));
        this.txt_wind.setTypeface(Util.getFontStyle(this, str));
        this.txt_pressure.setTypeface(Util.getFontStyle(this, str));
        this.tv_address_line_1.setTypeface(Util.getFontStyle(this, str));
        this.tv_address.setTypeface(Util.getFontStyle(this, str));
        this.tv_weather.setTypeface(Util.getFontStyle(this, str));
        this.tv_compass.setTypeface(Util.getFontStyle(this, str));
        this.tv_magnetic_field.setTypeface(Util.getFontStyle(this, str));
        this.txt_fontstyle.setText(getfontstyleName());
        this.txt_fontstyle.setTypeface(Typeface.createFromAsset(getResources().getAssets(), str));
    }

    private String getfontstyle() {
        if (this.Temp_type == 0) {
            return this.mSP.getString(this, SP.STAMP_FONT_STYLE, Default.DEFAULT_FONT_STYLE);
        }
        return this.mSP.getString(this, SP.STAMP_FONT_STYLE_CLASSIC, Default.DEFAULT_FONT_STYLE);
    }

    private String getfontstyleName() {
        if (this.Temp_type == 0) {
            return this.mSP.getString(this, SP.STAMP_FONT_NAME, Default.DEFAULT_FONT_NAME);
        }
        return this.mSP.getString(this, SP.STAMP_FONT_NAME_CLASSIC, Default.DEFAULT_FONT_NAME);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setaccuracy() {
        this.txt_accuracy.setText(Util.getAccuracy(this, getaccurcy()));
        setTemplate();
    }

    private int getaccurcy() {
        return this.mSP.getInteger(this, "accuracy_position", 0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setaltitude() {
        this.txt_altitude.setText(Util.getAltitudeconvert(this, getaltitude()));
        setTemplate();
    }

    private int getaltitude() {
        return this.mSP.getInteger(this, "altitude_position", 0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setpressure() {
        int i = getpressureslection();
        this.tv_pressure.setText(Util.getpressureConvert(this, i));
        if (ispressureTemp()) {
            this.txt_pressure.setText(Util.getpressureConvert(this, i));
            this.img_pressure_stamp.setImageResource(R.drawable.ic_pressure);
        }
    }

    private int getpressureslection() {
        return this.mSP.getInteger(this, "pressure_postion", 0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setwind() {
        String str = Util.getwindConvert(this, getwindselction());
        this.tv_wind.setText(str);
        if (isWindTemp()) {
            this.txt_wind.setText(str);
            this.img_wind_stamp.setImageResource(R.drawable.ic_wind);
        }
    }

    private int getwindselction() {
        return this.mSP.getInteger(this, "wind_postion", 0);
    }

    private void sethumidity() {
        String str = gethumnity();
        this.tv_humidity.setText(str);
        if (isHumidityTemp()) {
            this.txt_humidity.setText(str);
            this.img_humidity_stamp.setImageResource(R.drawable.ic_humidity);
        }
    }

    private String gethumnity() {
        return this.mSP.getString(this, SP.HUMIDITY_VALUE, "") + "%";
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setNotes() {
        this.txt_notes.setText(getnotes());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setLogo() {
        final String logo_image = getLogo_image();
        if (logo_image.equals(Default.LOGO_uri)) {
            this.imageview_logo.setImageResource(R.mipmap.ic_launcher);
            this.imgLogo.setImageResource(R.mipmap.ic_launcher);
            return;
        }
        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                final Bitmap decodeBase64 = Util.decodeBase64(logo_image);
                TempletSettingActivity.this.handler.post(new Runnable() {
                    @Override // java.lang.Runnable
                    public void run() {
                        Glide.with(TempletSettingActivity.this.getApplicationContext()).load(decodeBase64).into(TempletSettingActivity.this.imageview_logo);
                        Glide.with(TempletSettingActivity.this.getApplicationContext()).load(decodeBase64).into(TempletSettingActivity.this.imgLogo);
                    }
                });
            }
        });
    }

    private String getLogo_image() {
        return this.mSP.getString(this, "imge_logo", Default.LOGO_uri);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setstamppostion() {
        if (getStampPosTypeTemp().equals("Bottom")) {
            this.txt_stampposition.setText(getString(R.string.pos_bottom));
        } else {
            this.txt_stampposition.setText(getString(R.string.pos_top));
        }
        setColors();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setstampsize() {
        if (getStampSizeTypeTemp().equals("Large")) {
            this.txt_stampsize.setText(getResources().getString(R.string.size_large));
        } else if (getStampSizeTypeTemp().equals(Default.TEMPLATE_SIZE)) {
            this.txt_stampsize.setText(getResources().getString(R.string.size_medium));
        } else if (getStampSizeTypeTemp().equals("Small")) {
            this.txt_stampsize.setText(getResources().getString(R.string.size_small));
        } else {
            this.txt_stampsize.setText(getResources().getString(R.string.size_xtrasmall));
        }
        setTemplate();
    }

    public void setlatlog() {
        this.txt_latlog.setText(this.mUtil.getLatLong(this, getLatLngTemp_Type()));
    }


    public void setPlusCode() {
        String string = this.mSP.getString(this, SP.PLUS_CODE, "");
        if (!string.isEmpty()) {
            if (getPlusCodeTypeTemp().equals(Default.PLUSCODE_TYPE)) {
                this.txt_pluscode.setText(string);
            } else {
                this.txt_pluscode.setText(string.substring(4));
            }
        } else {
            this.txt_pluscode.setText("-");
        }
        setTemplate();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setdate() {
        this.txt_datetime.setText(Util.setDateTimeFormat(getDateTemp()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void settimezone(int i) {
        String displayName = Calendar.getInstance().getTimeZone().getDisplayName(false, 1);
        Date time = Calendar.getInstance(TimeZone.getTimeZone("GMT"), Locale.getDefault()).getTime();
        String format = new SimpleDateFormat("Z").format(time);
        String format2 = new SimpleDateFormat("ZZZZZ", Locale.getDefault()).format(time);
        switch (i) {
            case 1:
                this.txt_timezone.setText(format);
                return;
            case 2:
                TextView textView = this.txt_timezone;
                textView.setText("UTC " + format);
                return;
            case 3:
                TextView textView2 = this.txt_timezone;
                textView2.setText("GMT " + format);
                return;
            case 4:
                this.txt_timezone.setText(format2);
                return;
            case 5:
                TextView textView3 = this.txt_timezone;
                textView3.setText("UTC " + format2);
                return;
            case 6:
                TextView textView4 = this.txt_timezone;
                textView4.setText("GMT " + format2);
                return;
            case 7:
                this.txt_timezone.setText(displayName);
                return;
            default:
                return;
        }
    }

    private String getTimezone(int i) {
        String displayName = Calendar.getInstance().getTimeZone().getDisplayName(false, 1);
        Date time = Calendar.getInstance(TimeZone.getTimeZone("GMT"), Locale.getDefault()).getTime();
        String format = new SimpleDateFormat("Z").format(time);
        String format2 = new SimpleDateFormat("ZZZZZ", Locale.getDefault()).format(time);
        switch (i) {
            case 1:
                return format;
            case 2:
                return "UTC " + format;
            case 3:
                return "GMT " + format;
            case 4:
                return format2;
            case 5:
                return "UTC " + format2;
            case 6:
                return "GMT " + format2;
            case 7:
                return displayName;
            default:
                return "";
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setNumbering() {
        this.txt_numbering.setText((getPrefixtemp() + " " + getSequenceTemp() + " " + getSuffixTemp()).trim());
    }

    private void onclick() {
        this.mToolbar_back.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View view) {
                TempletSettingActivity.this.onBackPressed();
            }
        });
        this.img_maptype.setOnClickListener(this);
        this.img_address.setOnClickListener(this);
        this.img_latlog.setOnClickListener(this);
        this.img_pluscode.setOnClickListener(this);
        this.img_datetime.setOnClickListener(this);
        this.img_timezone.setOnClickListener(this);
        this.img_numbering.setOnClickListener(this);
        this.img_logo.setOnClickListener(this);
        this.img_notes.setOnClickListener(this);
        this.img_wether.setOnClickListener(this);
        this.img_compass.setOnClickListener(this);
        this.img_magnetic.setOnClickListener(this);
        this.img_wind.setOnClickListener(this);
        this.img_humidity.setOnClickListener(this);
        this.img_pressure.setOnClickListener(this);
        this.img_elevation.setOnClickListener(this);
        this.img_altitude.setOnClickListener(this);
        this.img_accuracy.setOnClickListener(this);
        this.lin_map.setOnClickListener(this);
        this.lin_latlog.setOnClickListener(this);
        this.lin_datetime.setOnClickListener(this);
        this.lin_timezone.setOnClickListener(this);
        this.lin_pluscode.setOnClickListener(this);
        this.lin_numbering.setOnClickListener(this);
        this.lin_wether.setOnClickListener(this);
        this.lin_stampposition.setOnClickListener(this);
        this.lin_stampsize.setOnClickListener(this);
        this.lin_logo.setOnClickListener(this);
        this.lin_notes.setOnClickListener(this);
        this.lin_wind.setOnClickListener(this);
        this.lin_pressure.setOnClickListener(this);
        this.lin_altitude.setOnClickListener(this);
        this.lin_accuracy.setOnClickListener(this);
        this.lin_stampcolor.setOnClickListener(this);
        this.lin_fontstyle.setOnClickListener(this);
    }

    private void savePreviousData() {
        SP sp = this.mSP;
        if (sp != null) {
            sp.setBoolean(this, "Map", this.isMap);
            this.mSP.setBoolean(this, "Address", this.isAddress);
            this.mSP.setBoolean(this, "Lat/Long", this.isLatLng);
            this.mSP.setBoolean(this, "pluscode", this.isPlusCode);
            this.mSP.setBoolean(this, "Weather", this.isWeather);
            this.mSP.setBoolean(this, "date_and_time", this.isDateTime);
            this.mSP.setBoolean(this, "timezone", this.istimezone);
            this.mSP.setBoolean(this, "isnumbering", this.isNumbering);
            this.mSP.setBoolean(this, "isincrement", this.isIncrement);
            this.mSP.setBoolean(this, "timezone", this.istimezone);
            this.mSP.setBoolean(this, "Magnetic Field", this.isMagneticField);
            this.mSP.setBoolean(this, "wind", this.iswind);
            this.mSP.setBoolean(this, "logo", this.islogo);
            this.mSP.setBoolean(this, "Compass", this.isCompass);
            this.mSP.setBoolean(this, "notes_hastag", this.isnotes);
            this.mSP.setBoolean(this, "humidity", this.isHumidity);
            this.mSP.setBoolean(this, "pressure", this.ispressure);
            this.mSP.setBoolean(this, "elevation", this.iselevation);
            this.mSP.setBoolean(this, "altitude", this.isaltitude);
            this.mSP.setBoolean(this, "accuracy", this.isaccuracy);
            this.mSP.setString(this, "date_format_temp", this.mDateFormat);
            this.mSP.setInteger(this, "Background Color", this.background_color);
            this.mSP.setInteger(this, "Address Color", this.address_color);
            this.mSP.setInteger(this, "Date & Time Color", this.date_time_color);
            this.mSP.setInteger(this, "Lat/Long Color", this.lat_lng_color);
            this.mSP.setInteger(this, "PlusCode Color", this.plus_code_color);
            this.mSP.setInteger(this, "WEATHER_COLOR", this.weather_color);//Changed
            this.mSP.setInteger(this, "Magnetic Field Color", this.magnetic_field_color);
            this.mSP.setInteger(this, "Compass Color", this.compass_color);
            this.mSP.setInteger(this, "Note & Hashtage Color", this.note_hastag_color);
            this.mSP.setInteger(this, "Wind Color", this.wind_color);
            this.mSP.setInteger(this, "Humidity Color", this.Humidity_color);
            this.mSP.setInteger(this, "Pressure Color", this.pressure_color);
            this.mSP.setInteger(this, "Elevation Color", this.elevation_color);
            this.mSP.setInteger(this, "Altitude Color", this.altitude_color);
            this.mSP.setInteger(this, "Accuracy Color", this.accuracy_color);
            this.mSP.setInteger(this, "Numbering Color", this.numbering_color);
            this.mSP.setInteger(this, "wind_postion", this.wind_selected);
            this.mSP.setInteger(this, "altitude_position", this.altitude_selection);
            this.mSP.setInteger(this, "accuracy_position", this.accuracy_selection);
            this.mSP.setInteger(this, "timezone value", this.timezone);
            this.mSP.setInteger(this, "sequence value", this.sequence);
            this.mSP.setString(this, "prefix", this.prefix);
            this.mSP.setString(this, "suffix", this.suffix);
            this.mSP.setInteger(this, "lat_lng_type_temp_1", this.mLatLngType);
            this.mSP.setString(this, "temprature_type_temp", this.msTemprature_type);
            this.mSP.setString(this, "map_type_temp", this.mMap_Type);
            this.mSP.setInteger(this, "map_type_temp_pos", this.mPos_mapType);
            this.mSP.setString(this, "pos_type_temp", this.mStamp_Pos);
            this.mSP.setString(this, "size_type_temp", this.mStamp_Size);
            this.mSP.setString(this, "plus_code_type", this.mPlusCodeType);
            this.mSP.setString(this, "imge_logo", this.Logo_img);
            this.mSP.setString(this, "notes", this.notes);
            if (this.Temp_type == 0) {
                this.mSP.setString(this, SP.STAMP_FONT_STYLE, this.font_style);
            } else {
                this.mSP.setString(this, SP.STAMP_FONT_STYLE_CLASSIC, this.font_style);
            }
            this.mSP.setString(this, "notes", this.notes);
            this.mSP.setInteger(this, "pressure_postion", this.pressure_selection);
        }
    }

    public void setColors() {
        this.tv_weather.setTextColor(getWeather_ColorTemp());
        this.tv_magnetic_field.setTextColor(getMagnetic_ColorTemp());
        this.tv_compass.setTextColor(getCompass_ColorTemp());
        this.txt_wind.setTextColor(getWind_ColorTemp());
        this.txt_pressure.setTextColor(getPressure_ColorTemp());
        this.txt_humidity.setTextColor(getHumidity_ColorTemp());
        String stampPosTypeTemp = getStampPosTypeTemp();
        int i = this.Temp_type;
        if (i == 0) {
            if (stampPosTypeTemp.equals("Bottom")) {
                this.li_stamp.setBackground(getResources().getDrawable(R.drawable.rect_grey_1));
            } else {
                this.li_stamp.setBackground(getResources().getDrawable(R.drawable.rect_grey_3));
            }
            this.lin_waterma.setBackground(getResources().getDrawable(R.drawable.rect_grey_2));
            this.lin_waterma_2.setBackground(getResources().getDrawable(R.drawable.rect_grey_4));
        } else {
            this.li_stamp.setBackground(getResources().getDrawable(R.drawable.classic_back));
            this.lin_waterma.setBackground(getResources().getDrawable(R.drawable.classic_back));
            this.lin_waterma_2.setBackground(getResources().getDrawable(R.drawable.classic_back));
        }
        ((GradientDrawable) this.li_stamp.getBackground().getCurrent()).setColor(getBackground_ColorTemp());
        if (stampPosTypeTemp.equals("Bottom")) {
            this.lin_waterma.setVisibility(View.VISIBLE);
            this.lin_waterma_2.setVisibility(View.GONE);
            ((GradientDrawable) this.lin_waterma.getBackground().getCurrent()).setColor(getBackground_ColorTemp());
        } else {
            this.lin_waterma.setVisibility(View.GONE);
            this.lin_waterma_2.setVisibility(View.VISIBLE);
            ((GradientDrawable) this.lin_waterma_2.getBackground().getCurrent()).setColor(getBackground_ColorTemp());
        }
        setTemplate();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setMapType() {
        String map_Type_Temp = getMap_Type_Temp();
        map_Type_Temp.hashCode();
        char c = 65535;
        switch (map_Type_Temp.hashCode()) {
            case -1579103941:
                if (map_Type_Temp.equals(Default.SETELLITE_2)) {
                    c = 0;
                    break;
                }
                break;
            case -1423437003:
                if (map_Type_Temp.equals(Default.TERRAIN_3)) {
                    c = 1;
                    break;
                }
                break;
            case -1202757124:
                if (map_Type_Temp.equals(Default.HYBRID_4)) {
                    c = 2;
                    break;
                }
                break;
            case 1366708796:
                if (map_Type_Temp.equals(Default.NORMAL_1)) {
                    c = 3;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                this.imgMap.setImageResource(R.drawable.setellite);
                this.imageview_map.setImageResource(R.drawable.setellite);
                return;
            case 1:
                this.imgMap.setImageResource(R.drawable.tarrain);
                this.imageview_map.setImageResource(R.drawable.tarrain);
                return;
            case 2:
                this.imgMap.setImageResource(R.drawable.hybrid);
                this.imageview_map.setImageResource(R.drawable.hybrid);
                return;
            case 3:
                this.imgMap.setImageResource(R.drawable.normal);
                this.imageview_map.setImageResource(R.drawable.normal);
                return;
            default:
                return;
        }
    }

    private String getMap_Type_Temp() {
        return this.mSP.getString(this, "map_type_temp", Default.SETELLITE_2);
    }

    private String getTemprature_Type_Temp() {
        return this.mSP.getString(this, "temprature_type_temp", "Celsius");
    }

    private boolean isCompassTemp() {
        return this.mSP.getBoolean(this, "Compass", false);
    }

    private boolean isMagneticFieldTemp() {
        return this.mSP.getBoolean(this, "Magnetic Field", false);
    }

    private boolean isWeatherTemp() {
        return this.mSP.getBoolean(this, "Weather", false);
    }

    private boolean isDateTimeTemp() {
        return this.mSP.getBoolean(this, "date_and_time", true);
    }

    private boolean isTimezoneTemp() {
        return this.mSP.getBoolean(this, "timezone", true);
    }

    private boolean isPlusCodeTemp() {
        return this.mSP.getBoolean(this, "pluscode", false);
    }

    private boolean isNumberingTemp() {
        return this.mSP.getBoolean(this, "isnumbering", false);
    }

    private boolean isIncementTemp() {
        return this.mSP.getBoolean(this, "isincrement", false);
    }

    private boolean isLogoTemp() {
        return this.mSP.getBoolean(this, "logo", false);
    }

    private boolean isNotesTemp() {
        return this.mSP.getBoolean(this, "notes_hastag", false);
    }

    private boolean isWindTemp() {
        return this.mSP.getBoolean(this, "wind", false);
    }

    private boolean isHumidityTemp() {
        return this.mSP.getBoolean(this, "humidity", false);
    }

    private boolean ispressureTemp() {
        return this.mSP.getBoolean(this, "pressure", false);
    }

    private boolean iselevationTemp() {
        return this.mSP.getBoolean(this, "elevation", false);
    }

    private boolean isAltitudeTemp() {
        return this.mSP.getBoolean(this, "altitude", false);
    }

    private boolean isAccuracyTemp() {
        return this.mSP.getBoolean(this, "accuracy", false);
    }

    private boolean isLatLngTemp() {
        return this.mSP.getBoolean(this, "Lat/Long", true);
    }

    private boolean isAddressTemp() {
        return this.mSP.getBoolean(this, "Address", true);
    }

    private boolean isMapTemp() {
        return this.mSP.getBoolean(this, "Map", true);
    }

    private String getDateTemp() {
        return this.mSP.getString(this, "date_format_temp", Default.DEFAULT_DATE_FORMAT);
    }

    private int getLatLng_ColorTemp() {
        return new SP(this).getInteger(this, "Lat/Long Color", -1);
    }

    private int getDate_ColorTemp() {
        return new SP(this).getInteger(this, "Date & Time Color", -1);
    }

    private int getAddress_ColorTemp() {
        return new SP(this).getInteger(this, "Address Color", -1);
    }

    private int getLatLngTemp_Type() {
        return this.mSP.getInteger(this, "lat_lng_type_temp_1", 1);
    }

    private String getLocation_Type() {
        return this.mSP.getString(this, SP.LOCATION_TYPE, Default.AUTOMATIC);
    }

    private int getBackground_ColorTemp() {
        return new SP(this).getInteger(this, "Background Color", Color.parseColor("#9c000000"));
    }

    private int getPlusCode_ColorTemp() {
        return new SP(this).getInteger(this, "PlusCode Color", -1);
    }

    private int getCompass_ColorTemp() {
        return new SP(this).getInteger(this, "Compass Color", -1);
    }

    private int getNote_hashtag_ColorTemp() {
        return new SP(this).getInteger(this, "Note & Hashtage Color", -1);
    }

    private int getWind_ColorTemp() {
        return new SP(this).getInteger(this, "Wind Color", -1);
    }

    private int getHumidity_ColorTemp() {
        return new SP(this).getInteger(this, "Humidity Color", -1);
    }

    private int getPressure_ColorTemp() {
        return new SP(this).getInteger(this, "Pressure Color", -1);
    }

    private int getElevation_ColorTemp() {
        return new SP(this).getInteger(this, "Elevation Color", -1);
    }

    private int getAltitude_ColorTemp() {
        return new SP(this).getInteger(this, "Altitude Color", -1);
    }

    private int getAccuracy_ColorTemp() {
        return new SP(this).getInteger(this, "Accuracy Color", -1);
    }

    private int getNumbering_ColorTemp() {
        return new SP(this).getInteger(this, "Numbering Color", -1);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getTimezoneTemp() {
        return new SP(this).getInteger(this, "timezone value", 6);
    }

    private int getSequenceTemp() {
        return new SP(this).getInteger(this, "sequence value", 1);
    }

    private String getPrefixtemp() {
        return new SP(this).getString(this, "prefix", "");
    }

    private String getSuffixTemp() {
        return new SP(this).getString(this, "suffix", "");
    }

    private int getMagnetic_ColorTemp() {
        return new SP(this).getInteger(this, "Magnetic Field Color", -1);
    }

    private int getWeather_ColorTemp() {
        return new SP(this).getInteger(this, "Weather Color", -1);
    }

    private int getPos_MapType_Temp() {
        return this.mSP.getInteger(this, "map_type_temp_pos", 0);
    }

    private String getStampPosTypeTemp() {
        return this.mSP.getString(this, "pos_type_temp", "Bottom");
    }

    private String getStampSizeTypeTemp() {
        return this.mSP.getString(this, "size_type_temp", Default.TEMPLATE_SIZE);
    }

    private String getPlusCodeTypeTemp() {
        return this.mSP.getString(this, "plus_code_type", Default.PLUSCODE_TYPE);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setTempratureData() {
        if (getTemprature_Type_Temp().equals("Celsius")) {
            this.tv_weather.setText(Util.getCelcius(this.mfTemprature_value));
            this.txt_wether.setText(Util.getCelcius(this.mfTemprature_value));
            return;
        }
        this.tv_weather.setText(Util.getFahrenheit(this.mfTemprature_value));
        this.txt_wether.setText(Util.getFahrenheit(this.mfTemprature_value));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setTemplate() {
        boolean z;
        boolean z2;
        Object obj;
        boolean z3;
        boolean z4;
        LinearLayout.LayoutParams layoutParams;
        boolean z5;
        Object obj2;
        Object obj3;
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        Object obj4;
        int i7;
        boolean isMapTemp = isMapTemp();
        boolean isAddressTemp = isAddressTemp();
        boolean isLatLngTemp = isLatLngTemp();
        boolean isPlusCodeTemp = isPlusCodeTemp();
        boolean isMagneticFieldTemp = isMagneticFieldTemp();
        boolean isCompassTemp = isCompassTemp();
        boolean isWeatherTemp = isWeatherTemp();
        boolean isDateTimeTemp = isDateTimeTemp();
        boolean isTimezoneTemp = isTimezoneTemp();
        boolean isNumberingTemp = isNumberingTemp();
        boolean isLogoTemp = isLogoTemp();
        boolean isNotesTemp = isNotesTemp();
        boolean isWindTemp = isWindTemp();
        boolean isHumidityTemp = isHumidityTemp();
        boolean ispressureTemp = ispressureTemp();
        iselevationTemp();
        boolean isAltitudeTemp = isAltitudeTemp();
        boolean isAccuracyTemp = isAccuracyTemp();
        String stampSizeTypeTemp = getStampSizeTypeTemp();
        boolean z6 = getResources().getBoolean(R.bool.isTablet);
        if (stampSizeTypeTemp.equals("Small") || stampSizeTypeTemp.equals(Default.TEMPLATE_SIZE)) {
            z = isAddressTemp;
            z2 = isLatLngTemp;
            obj = "Extra Small";
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.imgstamp_1.getLayoutParams();
            layoutParams2.height = Util.dpToPx(this, 20);
            layoutParams2.width = Util.dpToPx(this, 20);
            LinearLayout.LayoutParams layoutParams3 = (LinearLayout.LayoutParams) this.imgstamp_2.getLayoutParams();
            layoutParams3.height = Util.dpToPx(this, 20);
            layoutParams3.width = Util.dpToPx(this, 20);
            this.txt_watermark_1.setTextSize(7.0f);
            this.txt_watermark_2.setTextSize(7.0f);
        } else if (stampSizeTypeTemp.equals("Extra Small")) {
            z2 = isLatLngTemp;
            LinearLayout.LayoutParams layoutParams4 = (LinearLayout.LayoutParams) this.imgstamp_1.getLayoutParams();
            z = isAddressTemp;
            obj = "Extra Small";
            layoutParams4.height = Util.dpToPx(this, 14);
            layoutParams4.width = Util.dpToPx(this, 14);
            LinearLayout.LayoutParams layoutParams5 = (LinearLayout.LayoutParams) this.imgstamp_2.getLayoutParams();
            layoutParams5.height = Util.dpToPx(this, 14);
            layoutParams5.width = Util.dpToPx(this, 14);
            this.txt_watermark_1.setTextSize(5.0f);
            this.txt_watermark_2.setTextSize(5.0f);
        } else {
            z = isAddressTemp;
            z2 = isLatLngTemp;
            obj = "Extra Small";
            LinearLayout.LayoutParams layoutParams6 = (LinearLayout.LayoutParams) this.imgstamp_1.getLayoutParams();
            layoutParams6.height = Util.dpToPx(this, 24);
            layoutParams6.width = Util.dpToPx(this, 24);
            LinearLayout.LayoutParams layoutParams7 = (LinearLayout.LayoutParams) this.imgstamp_2.getLayoutParams();
            layoutParams7.height = Util.dpToPx(this, 24);
            layoutParams7.width = Util.dpToPx(this, 24);
            this.txt_watermark_1.setTextSize(9.0f);
            this.txt_watermark_2.setTextSize(9.0f);
        }
        LinearLayout.LayoutParams layoutParams8 = new LinearLayout.LayoutParams(-1, -2);
        if (stampSizeTypeTemp.equals("Large")) {
            z4 = isCompassTemp;
            z3 = isMagneticFieldTemp;
            layoutParams = new LinearLayout.LayoutParams((int) getResources().getDimension(R.dimen.stamp_icon_size_110), (int) getResources().getDimension(R.dimen.stamp_icon_size_110));
        } else {
            z3 = isMagneticFieldTemp;
            z4 = isCompassTemp;
            if (stampSizeTypeTemp.equals(Default.TEMPLATE_SIZE)) {
                layoutParams = new LinearLayout.LayoutParams((int) getResources().getDimension(R.dimen.stamp_icon_size_110), (int) getResources().getDimension(R.dimen.stamp_icon_size_70));
            } else if (stampSizeTypeTemp.equals("Small")) {
                layoutParams = new LinearLayout.LayoutParams((int) getResources().getDimension(R.dimen.stamp_icon_size_110), (int) getResources().getDimension(R.dimen.stamp_80dp));
            } else {
                layoutParams = new LinearLayout.LayoutParams((int) getResources().getDimension(R.dimen.stamp_icon_size_90), (int) getResources().getDimension(R.dimen.stamp_60dp));
            }
        }
        if (isMapTemp) {
            this.imgMap.setVisibility(View.VISIBLE);
            if (this.Temp_type == 0) {
                layoutParams8.setMargins((int) getResources().getDimension(R.dimen._8dp), 0, 0, 0);
                layoutParams.setMargins((int) getResources().getDimension(R.dimen._8dp), 0, 0, 0);
                if (stampSizeTypeTemp.equals("Large")) {
                    z5 = isMapTemp;
                    obj2 = "Small";
                    obj3 = Default.TEMPLATE_SIZE;
                    this.li_main_stamp_lay.setPadding((int) getResources().getDimension(R.dimen._8dp), (int) getResources().getDimension(R.dimen._8dp), (int) getResources().getDimension(R.dimen._8dp), (int) getResources().getDimension(R.dimen._8dp));
                } else {
                    z5 = isMapTemp;
                    obj2 = "Small";
                    obj3 = Default.TEMPLATE_SIZE;
                    this.li_main_stamp_lay.setPadding((int) getResources().getDimension(R.dimen._16dp), (int) getResources().getDimension(R.dimen._8dp), (int) getResources().getDimension(R.dimen._16dp), (int) getResources().getDimension(R.dimen._8dp));
                }
                layoutParams.gravity = 80;
            } else {
                z5 = isMapTemp;
                obj2 = "Small";
                obj3 = Default.TEMPLATE_SIZE;
                layoutParams8.setMargins(0, 0, 0, 0);
                layoutParams.setMargins(0, 0, 0, 0);
                layoutParams.gravity = 80;
                if (stampSizeTypeTemp.equals("Large")) {
                    this.li_main_stamp_lay.setPadding(0, (int) getResources().getDimension(R.dimen._8dp), 0, (int) getResources().getDimension(R.dimen._8dp));
                } else {
                    this.li_main_stamp_lay.setPadding(0, (int) getResources().getDimension(R.dimen._16dp), 0, (int) getResources().getDimension(R.dimen._16dp));
                }
                this.imgMap.setLayoutParams(layoutParams);
            }
            i = 0;
        } else {
            z5 = isMapTemp;
            obj2 = "Small";
            obj3 = Default.TEMPLATE_SIZE;
            this.imgMap.setVisibility(View.GONE);
            if (this.Temp_type == 0) {
                i = 0;
                layoutParams8.setMargins((int) getResources().getDimension(R.dimen._8dp), 0, 0, 0);
            } else {
                i = 0;
                layoutParams8.setMargins(0, 0, 0, 0);
            }
        }
        this.li_stamp.setLayoutParams(layoutParams8);
        if (isWeatherTemp) {
            this.li_weather.setVisibility(i);
            i2 = 8;
        } else {
            i2 = 8;
            this.li_weather.setVisibility(View.GONE);
        }
        if (isHumidityTemp || isAccuracyTemp || isAltitudeTemp || isWindTemp || ispressureTemp) {
            this.lin_bottom_wether.setVisibility(View.VISIBLE);
            if (z6) {
                ((LinearLayout.LayoutParams) this.lin_bottom_wether.getLayoutParams()).height++;
            }
        } else {
            this.lin_bottom_wether.setVisibility(i2);
        }
        if (isHumidityTemp) {
            i3 = 0;
            this.lin_humity_stamp.setVisibility(View.VISIBLE);
            i4 = 8;
        } else {
            i3 = 0;
            i4 = 8;
            this.lin_humity_stamp.setVisibility(View.GONE);
        }
        if (isWindTemp) {
            this.lin_wind_stamp.setVisibility(i3);
        } else {
            this.lin_wind_stamp.setVisibility(i4);
        }
        if (ispressureTemp) {
            this.lin_pressure_stamp.setVisibility(i3);
        } else {
            this.lin_pressure_stamp.setVisibility(i4);
        }
        if (isAltitudeTemp) {
            String altitudeconvert = Util.getAltitudeconvert(this, getaltitude());
            if (this.lin_pressure_stamp.getVisibility() == i4) {
                this.lin_pressure_stamp.setVisibility(View.VISIBLE);
                this.img_pressure_stamp.setImageResource(R.drawable.ic_altitiude);
                this.txt_pressure.setText(altitudeconvert);
                this.txt_pressure.setTextColor(getAltitude_ColorTemp());
            } else if (this.lin_wind_stamp.getVisibility() == 8) {
                this.lin_wind_stamp.setVisibility(View.VISIBLE);
                this.img_wind_stamp.setImageResource(R.drawable.ic_altitiude);
                this.txt_wind.setText(altitudeconvert);
                this.txt_wind.setTextColor(getAltitude_ColorTemp());
            } else if (this.lin_humity_stamp.getVisibility() == 8) {
                this.lin_humity_stamp.setVisibility(View.VISIBLE);
                this.img_humidity_stamp.setImageResource(R.drawable.ic_altitiude);
                this.txt_humidity.setText(altitudeconvert);
                this.txt_humidity.setTextColor(getAltitude_ColorTemp());
            }
        }
        if (isAccuracyTemp) {
            String accuracy = Util.getAccuracy(this, getaccurcy());
            if (this.lin_pressure_stamp.getVisibility() == 8) {
                this.lin_pressure_stamp.setVisibility(View.VISIBLE);
                this.img_pressure_stamp.setImageResource(R.drawable.ic_accuracy);
                this.txt_pressure.setText(accuracy);
                this.txt_pressure.setTextColor(getAccuracy_ColorTemp());
            } else if (this.lin_wind_stamp.getVisibility() == 8) {
                this.lin_wind_stamp.setVisibility(View.VISIBLE);
                this.img_wind_stamp.setImageResource(R.drawable.ic_accuracy);
                this.txt_wind.setText(accuracy);
                this.txt_wind.setTextColor(getAccuracy_ColorTemp());
            } else if (this.lin_humity_stamp.getVisibility() == 8) {
                this.lin_humity_stamp.setVisibility(View.VISIBLE);
                this.img_humidity_stamp.setImageResource(R.drawable.ic_accuracy);
                this.txt_humidity.setText(accuracy);
                this.txt_humidity.setTextColor(getAccuracy_ColorTemp());
            }
        }
        if (isHumidityTemp) {
            this.txt_humidity.setTextColor(getHumidity_ColorTemp());
        }
        if (isWindTemp) {
            this.txt_wind.setTextColor(getWind_ColorTemp());
        }
        if (ispressureTemp) {
            this.txt_pressure.setTextColor(getPressure_ColorTemp());
        }
        if (this.isCompassFound) {
            if (z3) {
                i7 = 0;
                this.li_magnetic_field.setVisibility(View.VISIBLE);
                i5 = 8;
            } else {
                i7 = 0;
                i5 = 8;
                this.li_magnetic_field.setVisibility(View.GONE);
            }
            if (z4) {
                this.li_compass.setVisibility(i7);
            } else {
                this.li_compass.setVisibility(i5);
            }
        } else {
            i5 = 8;
            this.li_magnetic_field.setVisibility(View.GONE);
            this.li_compass.setVisibility(View.GONE);
            this.lin_compass.setVisibility(View.GONE);
            this.lin_magnetic.setVisibility(View.GONE);
        }
        if (isWeatherTemp || z3 || z4 || isLogoTemp) {
            i6 = 0;
            this.li_rightView.setVisibility(View.VISIBLE);
        } else {
            this.li_rightView.setVisibility(i5);
            i6 = 0;
        }
        if (isLogoTemp) {
            this.li_logo.setVisibility(i6);
        } else {
            this.li_logo.setVisibility(View.GONE);
        }
        Object obj5 = obj3;
        if (stampSizeTypeTemp.equals(obj5)) {
            this.imgLogo.getLayoutParams().height = Util.dpToPx(this, 30);
            this.imgLogo.getLayoutParams().width = Util.dpToPx(this, 58);
            this.imgWeather.getLayoutParams().height = Util.dpToPx(this, 16);
            this.imgWeather.getLayoutParams().width = Util.dpToPx(this, 16);
            this.imgCompass.getLayoutParams().height = Util.dpToPx(this, 16);
            this.imgCompass.getLayoutParams().width = Util.dpToPx(this, 16);
            this.img_humidity_stamp.getLayoutParams().height = Util.dpToPx(this, 16);
            this.img_humidity_stamp.getLayoutParams().width = Util.dpToPx(this, 16);
            this.img_pressure_stamp.getLayoutParams().height = Util.dpToPx(this, 16);
            this.img_pressure_stamp.getLayoutParams().width = Util.dpToPx(this, 16);
            this.img_wind_stamp.getLayoutParams().height = Util.dpToPx(this, 16);
            this.img_wind_stamp.getLayoutParams().width = Util.dpToPx(this, 16);
            this.img_magnetic_field.getLayoutParams().height = Util.dpToPx(this, 16);
            this.img_magnetic_field.getLayoutParams().width = Util.dpToPx(this, 16);
            this.txt_wind.setTextSize(10.0f);
            this.txt_pressure.setTextSize(10.0f);
            this.txt_humidity.setTextSize(10.0f);
            this.tv_weather.setTextSize(10.0f);
            this.tv_compass.setTextSize(10.0f);
            this.tv_magnetic_field.setTextSize(10.0f);
            obj4 = obj2;
        } else {
            obj4 = obj2;
            if (stampSizeTypeTemp.equals(obj4)) {
                this.imgLogo.getLayoutParams().height = Util.dpToPx(this, 28);
                this.imgLogo.getLayoutParams().width = Util.dpToPx(this, 54);
                this.imgWeather.getLayoutParams().height = Util.dpToPx(this, 14);
                this.imgWeather.getLayoutParams().width = Util.dpToPx(this, 14);
                this.imgCompass.getLayoutParams().height = Util.dpToPx(this, 14);
                this.imgCompass.getLayoutParams().width = Util.dpToPx(this, 14);
                this.img_humidity_stamp.getLayoutParams().height = Util.dpToPx(this, 14);
                this.img_humidity_stamp.getLayoutParams().width = Util.dpToPx(this, 14);
                this.img_pressure_stamp.getLayoutParams().height = Util.dpToPx(this, 14);
                this.img_pressure_stamp.getLayoutParams().width = Util.dpToPx(this, 14);
                this.img_wind_stamp.getLayoutParams().height = Util.dpToPx(this, 14);
                this.img_wind_stamp.getLayoutParams().width = Util.dpToPx(this, 14);
                this.img_magnetic_field.getLayoutParams().height = Util.dpToPx(this, 14);
                this.img_magnetic_field.getLayoutParams().width = Util.dpToPx(this, 14);
                this.txt_wind.setTextSize(8.0f);
                this.txt_pressure.setTextSize(8.0f);
                this.txt_humidity.setTextSize(8.0f);
                this.tv_weather.setTextSize(8.0f);
                this.tv_compass.setTextSize(8.0f);
                this.tv_magnetic_field.setTextSize(8.0f);
            } else if (stampSizeTypeTemp.equals(obj)) {
                this.imgLogo.getLayoutParams().height = Util.dpToPx(this, 26);
                this.imgLogo.getLayoutParams().width = Util.dpToPx(this, 50);
                this.imgWeather.getLayoutParams().height = Util.dpToPx(this, 12);
                this.imgWeather.getLayoutParams().width = Util.dpToPx(this, 12);
                this.imgCompass.getLayoutParams().height = Util.dpToPx(this, 12);
                this.imgCompass.getLayoutParams().width = Util.dpToPx(this, 12);
                this.img_humidity_stamp.getLayoutParams().height = Util.dpToPx(this, 12);
                this.img_humidity_stamp.getLayoutParams().width = Util.dpToPx(this, 12);
                this.img_pressure_stamp.getLayoutParams().height = Util.dpToPx(this, 12);
                this.img_pressure_stamp.getLayoutParams().width = Util.dpToPx(this, 12);
                this.img_wind_stamp.getLayoutParams().height = Util.dpToPx(this, 12);
                this.img_wind_stamp.getLayoutParams().width = Util.dpToPx(this, 12);
                this.img_magnetic_field.getLayoutParams().height = Util.dpToPx(this, 12);
                this.img_magnetic_field.getLayoutParams().width = Util.dpToPx(this, 12);
                this.txt_wind.setTextSize(6.0f);
                this.txt_pressure.setTextSize(6.0f);
                this.txt_humidity.setTextSize(6.0f);
                this.tv_weather.setTextSize(6.0f);
                this.tv_compass.setTextSize(6.0f);
                this.tv_magnetic_field.setTextSize(6.0f);
            } else {
                this.imgLogo.getLayoutParams().height = Util.dpToPx(this, 32);
                this.imgLogo.getLayoutParams().width = Util.dpToPx(this, 62);
                this.imgWeather.getLayoutParams().height = Util.dpToPx(this, 18);
                this.imgWeather.getLayoutParams().width = Util.dpToPx(this, 18);
                this.imgCompass.getLayoutParams().height = Util.dpToPx(this, 18);
                this.imgCompass.getLayoutParams().width = Util.dpToPx(this, 18);
                this.img_humidity_stamp.getLayoutParams().height = Util.dpToPx(this, 18);
                this.img_humidity_stamp.getLayoutParams().width = Util.dpToPx(this, 18);
                this.img_pressure_stamp.getLayoutParams().height = Util.dpToPx(this, 18);
                this.img_pressure_stamp.getLayoutParams().width = Util.dpToPx(this, 18);
                this.img_wind_stamp.getLayoutParams().height = Util.dpToPx(this, 18);
                this.img_wind_stamp.getLayoutParams().width = Util.dpToPx(this, 18);
                this.img_magnetic_field.getLayoutParams().height = Util.dpToPx(this, 18);
                this.img_magnetic_field.getLayoutParams().width = Util.dpToPx(this, 18);
                this.txt_wind.setTextSize(12.0f);
                this.txt_pressure.setTextSize(12.0f);
                this.txt_humidity.setTextSize(12.0f);
                this.tv_weather.setTextSize(12.0f);
                this.tv_compass.setTextSize(12.0f);
                this.tv_magnetic_field.setTextSize(12.0f);
            }
        }
        if (z) {
            if (isNumberingTemp || isPlusCodeTemp) {
                this.tv_address_line_1.setMaxLines(12);
            } else {
                this.tv_address_line_1.setMaxLines(10);
            }
        } else if (z5 || ((isWeatherTemp || z3 || z4 || z2 || !isDateTimeTemp) && ((isWeatherTemp || z3 || z4 || isDateTimeTemp || !z2) && !(((isWeatherTemp || z4 || z3) && isDateTimeTemp && !z2) || ((isWeatherTemp || z4 || z3) && !isDateTimeTemp && z2))))) {
            if (isNumberingTemp || isPlusCodeTemp) {
                this.tv_address_line_1.setMaxLines(12);
            } else {
                this.tv_address_line_1.setMaxLines(10);
            }
        } else if ((z2 || isDateTimeTemp) && isNotesTemp) {
            if (isNumberingTemp || isPlusCodeTemp) {
                this.tv_address_line_1.setMaxLines(5);
            } else {
                this.tv_address_line_1.setMaxLines(3);
            }
        } else if (isNumberingTemp || isTimezoneTemp || isPlusCodeTemp) {
            this.tv_address_line_1.setMaxLines(3);
        } else {
            this.tv_address_line_1.setMaxLines(1);
        }
        if (z5) {
            if (z && z2) {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 0.0f, getResources().getDisplayMetrics()), 1.0f);
            } else if (z && (isWeatherTemp || z3 || z4)) {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, getResources().getDisplayMetrics()), 1.0f);
            } else if (isWeatherTemp || z3 || z4) {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 5.0f, getResources().getDisplayMetrics()), 1.0f);
            } else {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, getResources().getDisplayMetrics()), 1.2f);
            }
            String str = getPrefixtemp() + " " + getSequenceTemp() + " " + getSuffixTemp();
            if (isLogoTemp) {
                if (isNumberingTemp || isPlusCodeTemp) {
                    if (isAccuracyTemp || isAltitudeTemp || ispressureTemp || isHumidityTemp || isWindTemp) {
                        if (isNotesTemp && getnotes().length() > 35) {
                            if (stampSizeTypeTemp.equals("Large")) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_146);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_146);
                            } else if (stampSizeTypeTemp.equals(obj5)) {
                                System.out.println("Tem[plateCalled    ======>    1");
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                            } else if (stampSizeTypeTemp.equals(obj4)) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                            } else {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                            }
                        } else if (str.length() > 35) {
                            if (stampSizeTypeTemp.equals("Large")) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_146);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_146);
                            } else if (stampSizeTypeTemp.equals(obj5)) {
                                System.out.println("Tem[plateCalled    ======>    2");
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                            } else if (stampSizeTypeTemp.equals(obj4)) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                            } else {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                            }
                        } else if (stampSizeTypeTemp.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                        } else if (stampSizeTypeTemp.equals(obj5)) {
                            System.out.println("Tem[plateCalled    ======>    3");
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                        } else if (stampSizeTypeTemp.equals(obj4)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                        }
                    } else if (isNotesTemp && getnotes().length() > 35) {
                        if (stampSizeTypeTemp.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                        } else if (stampSizeTypeTemp.equals(obj5)) {
                            System.out.println("Tem[plateCalled    ======>    4");
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                        } else if (stampSizeTypeTemp.equals(obj4)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                        }
                    } else if (stampSizeTypeTemp.equals("Large")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                    } else if (stampSizeTypeTemp.equals(obj5)) {
                        System.out.println("Tem[plateCalled    ======>    5");
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                    } else if (stampSizeTypeTemp.equals(obj4)) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                    } else {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                    }
                } else if (isNotesTemp && getnotes().length() > 35) {
                    if (stampSizeTypeTemp.equals("Large")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                    } else if (stampSizeTypeTemp.equals(obj5)) {
                        System.out.println("Tem[plateCalled    ======>    6");
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                    } else if (stampSizeTypeTemp.equals(obj4)) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                    } else {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                    }
                } else if (stampSizeTypeTemp.equals("Large")) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                } else if (stampSizeTypeTemp.equals(obj5)) {
                    System.out.println("Tem[plateCalled    ======>    7");
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                } else if (stampSizeTypeTemp.equals(obj4)) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                } else {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_70);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_70);
                }
            } else if (isNumberingTemp || isPlusCodeTemp) {
                if (isAccuracyTemp || isAltitudeTemp || ispressureTemp || isHumidityTemp || isWindTemp) {
                    if (isNotesTemp && getnotes().length() > 35) {
                        if (stampSizeTypeTemp.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_126);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_126);
                        } else if (stampSizeTypeTemp.equals(obj5)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                        } else if (stampSizeTypeTemp.equals(obj4)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                        }
                    } else if (str.length() > 35) {
                        if (isNotesTemp) {
                            if (stampSizeTypeTemp.equals("Large")) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_126);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_126);
                            } else if (stampSizeTypeTemp.equals(obj5)) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                            } else if (stampSizeTypeTemp.equals(obj4)) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                            } else {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                            }
                        } else if (stampSizeTypeTemp.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                        } else if (stampSizeTypeTemp.equals(obj5)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                        } else if (stampSizeTypeTemp.equals(obj4)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                        }
                    } else if (isNotesTemp) {
                        if (stampSizeTypeTemp.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                        } else if (stampSizeTypeTemp.equals(obj5)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                        } else if (stampSizeTypeTemp.equals(obj4)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                        }
                    } else if (stampSizeTypeTemp.equals("Large")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                    } else if (stampSizeTypeTemp.equals(obj5)) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                    } else if (stampSizeTypeTemp.equals(obj4)) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                    } else {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                    }
                } else if (stampSizeTypeTemp.equals("Large")) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                } else if (stampSizeTypeTemp.equals(obj5)) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                } else if (stampSizeTypeTemp.equals(obj4)) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                } else {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                }
            } else if (isNotesTemp && getnotes().length() > 35) {
                if (stampSizeTypeTemp.equals("Large")) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                } else if (stampSizeTypeTemp.equals(obj5)) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                } else if (stampSizeTypeTemp.equals(obj4)) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                } else {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_70);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_70);
                }
            } else if (stampSizeTypeTemp.equals("Large")) {
                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
            } else if (stampSizeTypeTemp.equals(obj5)) {
                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
            } else if (stampSizeTypeTemp.equals(obj4)) {
                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_70);
                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_70);
            } else {
                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_55);
                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_55);
            }
        } else if (z2 || z || z3 || isWeatherTemp || z4) {
            if (!z) {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, getResources().getDisplayMetrics()), 1.2f);
                if ((isDateTimeTemp || z2) && (this.tv_address_line_1.getMaxLines() != 1 || ((z4 || z3 || isWeatherTemp) && ((!isWeatherTemp || z4 || z3) && ((!z4 || isWeatherTemp || z3) && (!z3 || isWeatherTemp || z4)))))) {
                    if (isNumberingTemp || isPlusCodeTemp) {
                        if (stampSizeTypeTemp.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                        } else if (stampSizeTypeTemp.equals(obj5)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                        } else if (stampSizeTypeTemp.equals(obj4)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                        }
                    } else if (stampSizeTypeTemp.equals("Large")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                    } else if (stampSizeTypeTemp.equals(obj5)) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                    } else if (stampSizeTypeTemp.equals(obj4)) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                    } else {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                    }
                } else if (this.lin_bottom_wether.getVisibility() != 8 || z4 || z3 || isWeatherTemp) {
                    if (isLogoTemp) {
                        if (isNumberingTemp || isPlusCodeTemp) {
                            if (stampSizeTypeTemp.equals("Large")) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                            } else if (stampSizeTypeTemp.equals(obj5)) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                            } else if (stampSizeTypeTemp.equals(obj4)) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                            } else {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                            }
                        } else if (stampSizeTypeTemp.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                        } else if (stampSizeTypeTemp.equals(obj5)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                        } else if (stampSizeTypeTemp.equals(obj4)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                        }
                    } else if (isNumberingTemp || isPlusCodeTemp) {
                        if (stampSizeTypeTemp.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_100dp);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                        }
                    } else if (stampSizeTypeTemp.equals("Large")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_90dp);
                    } else {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_60);
                    }
                } else if ((isDateTimeTemp || z2) && isNotesTemp) {
                    if (isNumberingTemp || isPlusCodeTemp) {
                        if (stampSizeTypeTemp.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_90dp);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_35);
                        }
                    } else if (stampSizeTypeTemp.equals("Large")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_80dp);
                    } else {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_30);
                    }
                } else if (isNumberingTemp || isPlusCodeTemp) {
                    if (stampSizeTypeTemp.equals("Large")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_80dp);
                    } else {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_30);
                    }
                } else if (stampSizeTypeTemp.equals("Large")) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_70dp);
                } else {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_25);
                }
            } else if (!z || z2) {
                if (isNumberingTemp || isPlusCodeTemp) {
                    if (stampSizeTypeTemp.equals("Large")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_130);
                    } else if (stampSizeTypeTemp.equals(obj5)) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                    } else if (stampSizeTypeTemp.equals(obj4)) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                    } else {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                    }
                } else if (stampSizeTypeTemp.equals("Large")) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                } else if (stampSizeTypeTemp.equals(obj5)) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                } else if (stampSizeTypeTemp.equals(obj4)) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                } else {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                }
            } else if (isNumberingTemp || isPlusCodeTemp) {
                if (stampSizeTypeTemp.equals("Large")) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                } else if (stampSizeTypeTemp.equals(obj5)) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                } else if (stampSizeTypeTemp.equals(obj4)) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                } else {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                }
            } else {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, getResources().getDisplayMetrics()), 1.2f);
                if (stampSizeTypeTemp.equals("Large")) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                } else if (stampSizeTypeTemp.equals(obj5)) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                } else if (stampSizeTypeTemp.equals(obj4)) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                } else {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                }
            }
        } else if (isNumberingTemp || isPlusCodeTemp) {
            if (stampSizeTypeTemp.equals("Large")) {
                if (!isNumberingTemp) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
                } else if (!isPlusCodeTemp) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
                } else {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_70);
                }
            } else if (!isNumberingTemp) {
                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
            } else if (!isPlusCodeTemp) {
                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
            } else {
                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_60);
            }
        } else if (stampSizeTypeTemp.equals("Large")) {
            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_70dp);
        } else if (!isLogoTemp && !isNotesTemp) {
            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_35);
        } else {
            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
        }
        if (!z && !z2 && !isDateTimeTemp && !isNotesTemp && !isWindTemp && !isHumidityTemp && !isAccuracyTemp && !ispressureTemp && !isAltitudeTemp && !isTimezoneTemp && !isNumberingTemp && !isPlusCodeTemp) {
            this.li_address.setVisibility(View.GONE);
            this.li_rightView.setOrientation(0);
            this.li_rightView.setGravity(17);
            this.li_rightView.getLayoutParams().width = -1;
            this.li_rightView.getLayoutParams().width = -1;
            if (isLogoTemp && !z5) {
                if (stampSizeTypeTemp.equals("Large")) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_80dp);
                } else {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
                }
            }
        } else {
            this.li_address.setVisibility(View.VISIBLE);
            this.li_rightView.setOrientation(1);
            this.li_rightView.setGravity(19);
            this.li_rightView.getLayoutParams().width = -2;
            this.li_rightView.getLayoutParams().width = -2;
        }
        if (!z2 && !z && !z3 && !isWeatherTemp && !z4 && !isDateTimeTemp && !z5 && !isNotesTemp && !isWindTemp && !isHumidityTemp && !isAccuracyTemp && !ispressureTemp && !isAltitudeTemp && !isLogoTemp && !isTimezoneTemp && !isNumberingTemp && !isPlusCodeTemp) {
            this.li_main_stamp_lay.setVisibility(View.GONE);
        } else {
            this.li_main_stamp_lay.setVisibility(View.VISIBLE);
            setText();
        }
        if (!z2 && !z && !isDateTimeTemp && !isNotesTemp && !isTimezoneTemp && !isNumberingTemp && !isPlusCodeTemp) {
            this.tv_address_line_1.setVisibility(View.GONE);
        } else {
            this.tv_address_line_1.setVisibility(View.VISIBLE);
        }
        if (z5 && !z && !z4 && !isDateTimeTemp && !z2 && !z3 && !isWeatherTemp && !isNotesTemp && !isWindTemp && !isHumidityTemp && !isAccuracyTemp && !ispressureTemp && !isAltitudeTemp && !isLogoTemp && !isTimezoneTemp && !isNumberingTemp && !isPlusCodeTemp) {
            this.li_stamp.setVisibility(4);
        } else {
            this.li_stamp.setVisibility(View.VISIBLE);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 69) {
            this.logo_bottomSheetfragment.onActivityResult(i, i2, intent);
        }
    }

    private void setText() {
        String str;
        String trim = this.mSP.getString(this, SP.LOC_LINE_1_ADDRESS, "").trim();
        String trim2 = this.mSP.getString(this, SP.LOC_LINE_2_CITY, "").trim();
        String trim3 = this.mSP.getString(this, SP.LOC_LINE_3_STATE, "").trim();
        String trim4 = this.mSP.getString(this, SP.LOC_LINE_4_COUNTRY, "").trim();
        if (trim2 == null || trim2.isEmpty()) {
            str = "";
        } else {
            str = "" + trim2 + ", ";
        }
        if (trim3 != null && !trim3.isEmpty()) {
            str = str + "" + trim3 + ", ";
        }
        if (trim4 != null && !trim4.isEmpty()) {
            str = str + trim4;
        }
        if (str != null && str.endsWith(", ")) {
            str = str.substring(0, str.length() - 2);
        }
        String coloredSpanned = (trim == null || trim.isEmpty()) ? "" : getColoredSpanned(trim, getAddress_ColorTemp());
        String coloredSpanned2 = getColoredSpanned(this.mUtil.getLatLong(this, getLatLngTemp_Type()), getLatLng_ColorTemp());
        Log.e("latLong11100000 : ", coloredSpanned2);
        if (coloredSpanned2 != null && getLatLngTemp_Type() != 6 && getLatLngTemp_Type() != 7 && coloredSpanned2.length() > 55 && isMapTemp() && !isWeatherTemp() && !isMagneticFieldTemp() && !isCompassTemp()) {
            String[] split = coloredSpanned2.split(" Long");
            coloredSpanned2 = split[0] + "<br/>Long " + split[1];
        }
        if (isAddressTemp()) {
            if (isLatLngTemp()) {
                coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned2;
            }
        } else if (isLatLngTemp() && !isAddressTemp()) {
            coloredSpanned = coloredSpanned2;
        }
        if (isPlusCodeTemp()) {
            String string = this.mSP.getString(this, SP.PLUS_CODE, "");
            if (!string.isEmpty() && getPlusCodeTypeTemp().equals("concise")) {
                string = string.substring(4);
            }
            String coloredSpanned3 = getColoredSpanned("Plus Code : " + string, getPlusCode_ColorTemp());
            if (isAddressTemp() || isLatLngTemp()) {
                coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned3;
            } else {
                coloredSpanned = coloredSpanned3;
            }
        }
        if (isDateTimeTemp()) {
            String coloredSpanned4 = getColoredSpanned(Util.setDateTimeFormat(getDateTemp()), getDate_ColorTemp());
            if (isAddressTemp() || isLatLngTemp() || isPlusCodeTemp()) {
                coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned4;
            } else {
                coloredSpanned = coloredSpanned4;
            }
        }
        if (isTimezoneTemp()) {
            String coloredSpanned5 = getColoredSpanned(getTimezone(getTimezoneTemp()), getDate_ColorTemp());
            if (!isDateTimeTemp()) {
                if (isAddressTemp() || isLatLngTemp() || isPlusCodeTemp()) {
                    coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned5;
                } else {
                    coloredSpanned = coloredSpanned5;
                }
            } else {
                coloredSpanned = coloredSpanned + " " + coloredSpanned5;
            }
        }
        if (isNotesTemp()) {
            String coloredSpanned6 = getColoredSpanned(getnotes(), getNote_hashtag_ColorTemp());
            if (isAddressTemp() || isLatLngTemp() || isDateTimeTemp() || isTimezoneTemp() || isPlusCodeTemp()) {
                coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned6;
            } else {
                coloredSpanned = coloredSpanned6;
            }
        }
        if (isNumberingTemp()) {
            String coloredSpanned7 = getColoredSpanned((getPrefixtemp() + " " + getSequenceTemp() + " " + getSuffixTemp()).trim(), getNumbering_ColorTemp());
            if (isAddressTemp() || isLatLngTemp() || isDateTimeTemp() || isTimezoneTemp() || isNotesTemp() || isPlusCodeTemp()) {
                coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned7;
            } else {
                coloredSpanned = coloredSpanned7;
            }
        }
        if (coloredSpanned.contains("null")) {
            coloredSpanned = coloredSpanned.replace("null", "Loading");
        }
        this.tv_address_line_1.setText(Html.fromHtml(coloredSpanned));
        if (str != null && !str.isEmpty() && isAddressTemp()) {
            this.tv_address.setVisibility(View.VISIBLE);
            if (str.equalsIgnoreCase("null")) {
                str = "Loading";
            }
            this.tv_address.setText(Html.fromHtml(getColoredSpanned(str, getAddress_ColorTemp())));
            return;
        }
        this.tv_address.setVisibility(View.GONE);
    }

    private String getnotes() {
        return this.mSP.getString(this, "notes", Default.notes);
    }

    private String getColoredSpanned(String str, int i) {
        return "<font color=" + i + ">" + str + "</font>";
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (isAllUnCheck()) {
            showSnackbar();
        } else {
            saveData();
        }
    }

    private void saveData() {
        if (this.Temp_type == 0) {
            this.mSP.setBoolean(this, SP.IS_MAP, isMapTemp());
            this.mSP.setBoolean(this, SP.IS_ADDRESS, isAddressTemp());
            this.mSP.setBoolean(this, SP.IS_LAT_LNG_TEMPLATE, isLatLngTemp());
            this.mSP.setBoolean(this, SP.IS_PLUS_CODE, isPlusCodeTemp());
            this.mSP.setBoolean(this, SP.IS_WEATHER, isWeatherTemp());
            this.mSP.setBoolean(this, SP.IS_DATE_TIME, isDateTimeTemp());
            this.mSP.setBoolean(this, SP.IS_TIMEZONE, isTimezoneTemp());
            this.mSP.setBoolean(this, SP.IS_NUMBERING, isNumberingTemp());
            this.mSP.setBoolean(this, SP.IS_INCREMENT, isIncementTemp());
            this.mSP.setBoolean(this, SP.IS_MAGNETIC_FIELD, isMagneticFieldTemp());
            this.mSP.setBoolean(this, SP.IS_COMPASS, isCompassTemp());
            this.mSP.setBoolean(this, SP.IS_LOGO, isLogoTemp());
            this.mSP.setBoolean(this, SP.IS_NOTES, isNotesTemp());
            this.mSP.setBoolean(this, SP.IS_HUMIDITY, isHumidityTemp());
            this.mSP.setBoolean(this, SP.IS_WIND, isWindTemp());
            this.mSP.setBoolean(this, SP.IS_PRESSURE, ispressureTemp());
            this.mSP.setBoolean(this, SP.IS_ELEVATION, iselevationTemp());
            this.mSP.setBoolean(this, SP.IS_ALTITUDE, isAltitudeTemp());
            this.mSP.setBoolean(this, SP.IS_ACCURACY, isAccuracyTemp());
            this.mSP.setString(this, SP.DATE_FORMAT, getDateTemp());
            this.mSP.setInteger(this, SP.BACKGROUND_COLOR, getBackground_ColorTemp());
            this.mSP.setInteger(this, SP.ADDRESS_COLOR, getAddress_ColorTemp());
            this.mSP.setInteger(this, SP.DATE_TIME_COLOR, getDate_ColorTemp());
            this.mSP.setInteger(this, SP.LAT_LNG_COLOR, getLatLng_ColorTemp());
            this.mSP.setInteger(this, SP.PLUS_CODE_COLOR, getPlusCode_ColorTemp());
            this.mSP.setInteger(this, SP.WEATHER_COLOR, getWeather_ColorTemp());
            this.mSP.setInteger(this, SP.MAGNETIC_FIELD_COLOR, getMagnetic_ColorTemp());
            this.mSP.setInteger(this, SP.COMPASS_COLOR, getCompass_ColorTemp());
            this.mSP.setInteger(this, SP.NOTES_HASHTAG_COLOR, getNote_hashtag_ColorTemp());
            this.mSP.setInteger(this, SP.WIND_COLOR, getWind_ColorTemp());
            this.mSP.setInteger(this, SP.HUMIDITY_COLOR, getHumidity_ColorTemp());
            this.mSP.setInteger(this, SP.PRESSURE_COLOR, getPressure_ColorTemp());
            this.mSP.setInteger(this, SP.ELEVATION_COLOR, getElevation_ColorTemp());
            this.mSP.setInteger(this, SP.ALTITUDE_COLOR, getAltitude_ColorTemp());
            this.mSP.setInteger(this, SP.ACCURACY_COLOR, getAccuracy_ColorTemp());
            this.mSP.setInteger(this, SP.NUMBERING_COLOR, getNumbering_ColorTemp());
            this.mSP.setInteger(this, SP.TIMEZONE, getTimezoneTemp());
            this.mSP.setInteger(this, SP.SEQUENCE, getSequenceTemp());
            this.mSP.setString(this, SP.PREFIX, getPrefixtemp());
            this.mSP.setString(this, SP.SUFFIX, getSuffixTemp());
            this.mSP.setInteger(this, SP.WIND_SELECT, getwindselction());
            this.mSP.setInteger(this, SP.PRESSURE_SELECT, getpressureslection());
            this.mSP.setInteger(this, SP.ALTITUDE_SELECT, getaltitude());
            this.mSP.setInteger(this, SP.ACCURACY_SELECT, getaccurcy());
            this.mSP.setString(this, SP.LOGO_URI, getLogo_image());
            this.mSP.setString(this, SP.NOTES_HASHTAG, getnotes());
            this.mSP.setString(this, SP.STAMP_FONT_STYLE, getfontstyle());
            this.mSP.setInteger(this, SP.LAT_LNG_TYPE, getLatLngTemp_Type());
            this.mSP.setString(this, SP.TEMPRATURE_TYPE, getTemprature_Type_Temp());
            this.mSP.setString(this, SP.MAP_TYPE_TEMPLATE, getMap_Type_Temp());
            this.mSP.setInteger(this, SP.MAP_POS, getPos_MapType_Temp());
            this.mSP.setString(this, SP.STAMP_POS, getStampPosTypeTemp());
            this.mSP.setString(this, SP.STAMP_SIZE_CLASSIC, getStampSizeTypeTemp());
            this.mSP.setString(this, SP.PLUS_CODE_TYPE, getPlusCodeTypeTemp());
        } else {
            this.mSP.setBoolean(this, SP.IS_MAP_CLASSIC, isMapTemp());
            this.mSP.setBoolean(this, SP.IS_ADDRESS_CLASSIC, isAddressTemp());
            this.mSP.setBoolean(this, SP.IS_LAT_LNG_TEMPLATE_CLASSIC, isLatLngTemp());
            this.mSP.setBoolean(this, SP.IS_PLUS_CODE_CLASSIC, isPlusCodeTemp());
            this.mSP.setBoolean(this, SP.IS_WEATHER_CLASSIC, isWeatherTemp());
            this.mSP.setBoolean(this, SP.IS_DATE_TIME_CLASSIC, isDateTimeTemp());
            this.mSP.setBoolean(this, SP.IS_TIMEZONE_CLASSIC, isTimezoneTemp());
            this.mSP.setBoolean(this, SP.IS_NUMBERING_CLASSIC, isNumberingTemp());
            this.mSP.setBoolean(this, SP.IS_INCREMENT_CLASSIC, isIncementTemp());
            this.mSP.setBoolean(this, SP.IS_MAGNETIC_FIELD_CLASSIC, isMagneticFieldTemp());
            this.mSP.setBoolean(this, SP.IS_COMPASS_CLASSIC, isCompassTemp());
            this.mSP.setBoolean(this, SP.IS_LOGO_CLASSIC, isLogoTemp());
            this.mSP.setBoolean(this, SP.IS_NOTES_CLASSIC, isNotesTemp());
            this.mSP.setBoolean(this, SP.IS_HUMIDITY_CLASSIC, isHumidityTemp());
            this.mSP.setBoolean(this, SP.IS_WIND_CLASSIC, isWindTemp());
            this.mSP.setBoolean(this, SP.IS_PRESSURE_CLASSIC, ispressureTemp());
            this.mSP.setBoolean(this, SP.IS_ELEVATION_CLASSIC, iselevationTemp());
            this.mSP.setBoolean(this, SP.IS_ALTITUDE_CLASSIC, isAltitudeTemp());
            this.mSP.setBoolean(this, SP.IS_ACCURACY_CLASSIC, isAccuracyTemp());
            this.mSP.setString(this, SP.DATE_FORMAT, getDateTemp());
            this.mSP.setInteger(this, SP.BACKGROUND_COLOR_CLASSIC, getBackground_ColorTemp());
            this.mSP.setInteger(this, SP.ADDRESS_COLOR_CLASSIC, getAddress_ColorTemp());
            this.mSP.setInteger(this, SP.DATE_TIME_COLOR_CLASSIC, getDate_ColorTemp());
            this.mSP.setInteger(this, SP.LAT_LNG_COLOR_CLASSIC, getLatLng_ColorTemp());
            this.mSP.setInteger(this, SP.PLUS_CODE_COLOR_CLASSIC, getPlusCode_ColorTemp());
            this.mSP.setInteger(this, SP.WEATHER_COLOR_CLASSIC, getWeather_ColorTemp());
            this.mSP.setInteger(this, SP.MAGNETIC_FIELD_COLOR_CLASSIC, getMagnetic_ColorTemp());
            this.mSP.setInteger(this, SP.COMPASS_COLOR_CLASSIC, getCompass_ColorTemp());
            this.mSP.setInteger(this, SP.NOTES_HASHTAG_COLOR_CLASSIC, getNote_hashtag_ColorTemp());
            this.mSP.setInteger(this, SP.WIND_COLOR_CLASSIC, getWind_ColorTemp());
            this.mSP.setInteger(this, SP.HUMIDITY_COLOR_CLASSIC, getHumidity_ColorTemp());
            this.mSP.setInteger(this, SP.PRESSURE_COLOR_CLASSIC, getPressure_ColorTemp());
            this.mSP.setInteger(this, SP.ELEVATION_COLOR_CLASSIC, getElevation_ColorTemp());
            this.mSP.setInteger(this, SP.ALTITUDE_COLOR_CLASSIC, getAltitude_ColorTemp());
            this.mSP.setInteger(this, SP.ACCURACY_COLOR_CLASSIC, getAccuracy_ColorTemp());
            this.mSP.setInteger(this, SP.NUMBERING_COLOR_CLASSIC, getNumbering_ColorTemp());
            this.mSP.setInteger(this, SP.TIMEZONE_CLASSIC, getTimezoneTemp());
            this.mSP.setInteger(this, SP.SEQUENCE_CLASSIC, getSequenceTemp());
            this.mSP.setString(this, SP.SUFFIX_CLASSIC, getSuffixTemp());
            this.mSP.setString(this, SP.PREFIX_CLASSIC, getPrefixtemp());
            this.mSP.setInteger(this, SP.WIND_SELECT_CLASSIC, getwindselction());
            this.mSP.setInteger(this, SP.PRESSURE_SELECT_CLASSIC, getpressureslection());
            this.mSP.setInteger(this, SP.ALTITUDE_SELECT_CLASSIC, getaltitude());
            this.mSP.setInteger(this, SP.ACCURACY_SELECT_CLASSIC, getaccurcy());
            this.mSP.setString(this, SP.LOGO_URI_CLASSIC, getLogo_image());
            this.mSP.setString(this, SP.NOTES_HASHTAG_CLASSIC, getnotes());
            this.mSP.setString(this, SP.STAMP_FONT_STYLE_CLASSIC, getfontstyle());
            this.mSP.setInteger(this, SP.LAT_LNG_TYPE_CLASSIC, getLatLngTemp_Type());
            this.mSP.setString(this, SP.TEMPRATURE_TYPE_CLASSIC, getTemprature_Type_Temp());
            this.mSP.setString(this, SP.MAP_TYPE_TEMPLATE_CLASSIC, getMap_Type_Temp());
            this.mSP.setInteger(this, SP.MAP_POS_CLASSIC, getPos_MapType_Temp());
            this.mSP.setString(this, SP.STAMP_POS_CLASSIC, getStampPosTypeTemp());
            this.mSP.setString(this, SP.STAMP_SIZE_CLASSIC, getStampSizeTypeTemp());
            this.mSP.setString(this, SP.PLUS_CODE_TYPE_CLASSIC, getPlusCodeTypeTemp());
        }
//        String str = isMapTemp() ? "On" : "Off";
//        String str2 = isAddressTemp() ? "On" : "Off";
//        String str3 = isLatLngTemp() ? "On" : "Off";
//        String str4 = isWeatherTemp() ? "On" : "Off";
//        String str5 = isDateTimeTemp() ? "On" : "Off";
//        String str6 = isTimezoneTemp() ? "On" : "Off";
//        String str7 = isMagneticFieldTemp() ? "On" : "Off";
//        String str8 = isCompassTemp() ? "On" : "Off";
//        Bundle bundle = new Bundle();
//        bundle.putString("Map", str);
//        bundle.putString("Address", str2);
//        bundle.putString(XePasdF.qLDf, str3);
//        bundle.putString("Date_Time", str5);
//        bundle.putString("Magnetic_Field", str7);
//        bundle.putString("Compass", str8);
//        bundle.putString("Weather", str4);
//        bundle.putString("Timezone", str6);
//        this.mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        finish();
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        DateTime_BottomSheet dateTime_BottomSheet;
        Logo_BottomSheetfragment logo_BottomSheetfragment;
        Note_bottom_sheetfragment note_bottom_sheetfragment;
        TimeZone_BottomSheet timeZone_BottomSheet;
        switch (view.getId()) {
            case R.id.img_accuracy /* 2131362241 */:
                if (isAccuracyTemp()) {
                    this.mSP.setBoolean(this, "accuracy", false);
                    this.img_accuracy.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                    setTemplate();
                    return;
                } else if (checkwethwr() < 3) {
                    this.mSP.setBoolean(this, "accuracy", true);
                    this.img_accuracy.setImageResource(R.drawable.ic_select_btn);
                    setTemplate();
                    return;
                } else {
                    Snackbar.make(view, getString(R.string.space_in_stamp), 0).show();
                    return;
                }
            case R.id.img_address /* 2131362243 */:
                boolean isAddressTemp = isAddressTemp();
                String str = "address";
                if (isAddressTemp) {
                    this.mSP.setBoolean(this, str, false);
                    this.img_address.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                } else {
                    this.mSP.setBoolean(this, str, true);
                    this.img_address.setImageResource(R.drawable.ic_select_btn);
                }
                setTemplate();
                return;
            case R.id.img_altitude /* 2131362244 */:
                if (isAltitudeTemp()) {
                    this.mSP.setBoolean(this, "altitude", false);
                    this.img_altitude.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                    setTemplate();
                    return;
                } else if (checkwethwr() < 3) {
                    this.mSP.setBoolean(this, "altitude", true);
                    this.img_altitude.setImageResource(R.drawable.ic_select_btn);
                    setTemplate();
                    return;
                } else {
                    Snackbar.make(view, getString(R.string.space_in_stamp), 0).show();
                    return;
                }
            case R.id.img_compass /* 2131362253 */:
                if (isCompassTemp()) {
                    this.mSP.setBoolean(this, "Compass", false);
                    this.img_compass.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                } else {
                    this.mSP.setBoolean(this, "Compass", true);
                    this.img_compass.setImageResource(R.drawable.ic_select_btn);
                }
                setTemplate();
                return;
            case R.id.img_datetime /* 2131362254 */:
                if (isDateTimeTemp()) {
                    this.mSP.setBoolean(this, "date_and_time", false);
                    this.img_datetime.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                } else {
                    this.mSP.setBoolean(this, "date_and_time", true);
                    this.img_datetime.setImageResource(R.drawable.ic_select_btn);
                }
                setTemplate();
                return;
            case R.id.img_elevation /* 2131362259 */:
                if (iselevationTemp()) {
                    this.mSP.setBoolean(this, "elevation", false);
                    this.img_elevation.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                } else {
                    this.mSP.setBoolean(this, "elevation", true);
                    this.img_elevation.setImageResource(R.drawable.ic_select_btn);
                }
                setTemplate();
                return;
            case R.id.img_humidity /* 2131362269 */:
                if (isHumidityTemp()) {
                    this.mSP.setBoolean(this, "humidity", false);
                    this.img_humidity.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                    sethumidity();
                    setTemplate();
                    return;
                } else if (checkwethwr() < 3) {
                    this.mSP.setBoolean(this, "humidity", true);
                    this.img_humidity.setImageResource(R.drawable.ic_select_btn);
                    sethumidity();
                    setTemplate();
                    return;
                } else {
                    Snackbar.make(view, getString(R.string.space_in_stamp), 0).show();
                    return;
                }
            case R.id.img_latlog /* 2131362272 */:
                if (isLatLngTemp()) {
                    this.mSP.setBoolean(this, "Lat/Long", false);
                    this.img_latlog.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                } else {
                    this.mSP.setBoolean(this, "Lat/Long", true);
                    this.img_latlog.setImageResource(R.drawable.ic_select_btn);
                }
                setTemplate();
                return;
            case R.id.img_logo /* 2131362274 */:
                if (isLogoTemp()) {
                    this.mSP.setBoolean(this, "logo", false);
                    this.img_logo.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                } else {
                    this.mSP.setBoolean(this, "logo", true);
                    this.img_logo.setImageResource(R.drawable.ic_select_btn);
                }
                setTemplate();
                return;
            case R.id.img_magnetic /* 2131362275 */:
                if (isMagneticFieldTemp()) {
                    this.mSP.setBoolean(this, "Magnetic Field", false);
                    this.img_magnetic.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                } else {
                    this.mSP.setBoolean(this, "Magnetic Field", true);
                    this.img_magnetic.setImageResource(R.drawable.ic_select_btn);
                }
                setTemplate();
                return;
            case R.id.img_maptype /* 2131362279 */:
                if (isMapTemp()) {
                    this.mSP.setBoolean(this, "Map", false);
                    this.img_maptype.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                } else {
                    this.mSP.setBoolean(this, "Map", true);
                    this.img_maptype.setImageResource(R.drawable.ic_select_btn);
                    maponotheroff();
                }
                setTemplate();
                return;
            case R.id.img_notes /* 2131362283 */:
                if (isNotesTemp()) {
                    this.mSP.setBoolean(this, "notes_hastag", false);
                    this.img_notes.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                } else {
                    this.mSP.setBoolean(this, "notes_hastag", true);
                    this.img_notes.setImageResource(R.drawable.ic_select_btn);
                }
                setTemplate();
                return;
            case R.id.img_numbering /* 2131362284 */:
                if (isNumberingTemp()) {
                    this.mSP.setBoolean(this, "isnumbering", false);
                    this.img_numbering.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                } else {
                    this.mSP.setBoolean(this, "isnumbering", true);
                    this.img_numbering.setImageResource(R.drawable.ic_select_btn);
                }
                setTemplate();
                return;
            case R.id.img_pluscode /* 2131362285 */:
                if (isPlusCodeTemp()) {
                    this.mSP.setBoolean(this, "pluscode", false);
                    this.img_pluscode.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                } else {
                    this.mSP.setBoolean(this, "pluscode", true);
                    this.img_pluscode.setImageResource(R.drawable.ic_select_btn);
                }
                setTemplate();
                return;
            case R.id.img_pressure /* 2131362286 */:
                if (ispressureTemp()) {
                    this.mSP.setBoolean(this, "pressure", false);
                    this.img_pressure.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                    setpressure();
                    setTemplate();
                    return;
                } else if (checkwethwr() < 3) {
                    this.mSP.setBoolean(this, "pressure", true);
                    this.img_pressure.setImageResource(R.drawable.ic_select_btn);
                    setpressure();
                    setTemplate();
                    return;
                } else {
                    Snackbar.make(view, getString(R.string.space_in_stamp), 0).show();
                    return;
                }
            case R.id.img_timezone /* 2131362301 */:
                if (isTimezoneTemp()) {
                    this.mSP.setBoolean(this, "timezone", false);
                    this.img_timezone.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                } else {
                    this.mSP.setBoolean(this, "timezone", true);
                    this.img_timezone.setImageResource(R.drawable.ic_select_btn);
                }
                setTemplate();
                return;
            case R.id.img_wether /* 2131362303 */:
                if (isWeatherTemp()) {
                    this.mSP.setBoolean(this, "Weather", false);
                    this.img_wether.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                } else {
                    this.mSP.setBoolean(this, "Weather", true);
                    this.img_wether.setImageResource(R.drawable.ic_select_btn);
                }
                setTemplate();
                return;
            case R.id.img_wind /* 2131362305 */:
                if (isWindTemp()) {
                    this.mSP.setBoolean(this, "wind", false);
                    this.img_wind.setImageResource(R.drawable.ic_uncheck_box_tple);
                    setdateselected();
                    setwind();
                    setTemplate();
                    return;
                } else if (checkwethwr() < 3) {
                    this.mSP.setBoolean(this, "wind", true);
                    this.img_wind.setImageResource(R.drawable.ic_select_btn);
                    setwind();
                    setTemplate();
                    return;
                } else {
                    Snackbar.make(view, getString(R.string.space_in_stamp), 0).show();
                    return;
                }
            case R.id.lin_accuracy /* 2131362384 */:
                if (this.mapTypeBottomSheetfragment.isAdded() || this.mapTypeBottomSheetfragment == null) {
                    return;
                }
                Bundle bundle = new Bundle();
                bundle.putInt("type", 8);
                this.mapTypeBottomSheetfragment.setArguments(bundle);
                this.mapTypeBottomSheetfragment.show(getSupportFragmentManager(), MapTypeBottomSheetfragment.TAG);
                return;
            case R.id.lin_altitude /* 2131362387 */:
                if (this.mapTypeBottomSheetfragment.isAdded() || this.mapTypeBottomSheetfragment == null) {
                    return;
                }
                Bundle bundle2 = new Bundle();
                bundle2.putInt("type", 7);
                this.mapTypeBottomSheetfragment.setArguments(bundle2);
                this.mapTypeBottomSheetfragment.show(getSupportFragmentManager(), MapTypeBottomSheetfragment.TAG);
                return;
            case R.id.lin_datetime /* 2131362391 */:
                if (this.dateTime_bottomSheet.isAdded() || (dateTime_BottomSheet = this.dateTime_bottomSheet) == null) {
                    return;
                }
                dateTime_BottomSheet.show(getSupportFragmentManager(), DateTime_BottomSheet.TAG);
                return;
            case R.id.lin_fontstyle /* 2131362393 */:
                if (this.mapTypeBottomSheetfragment.isAdded() || this.mapTypeBottomSheetfragment == null) {
                    return;
                }
                Bundle bundle3 = new Bundle();
                bundle3.putInt("type", 9);
                this.mapTypeBottomSheetfragment.setArguments(bundle3);
                this.mapTypeBottomSheetfragment.show(getSupportFragmentManager(), MapTypeBottomSheetfragment.TAG);
                return;
            case R.id.lin_latlog /* 2131362397 */:
                if (this.mapTypeBottomSheetfragment.isAdded() || this.mapTypeBottomSheetfragment == null) {
                    return;
                }
                Bundle bundle4 = new Bundle();
                bundle4.putInt("type", 2);
                this.mapTypeBottomSheetfragment.setArguments(bundle4);
                this.mapTypeBottomSheetfragment.show(getSupportFragmentManager(), MapTypeBottomSheetfragment.TAG);
                return;
            case R.id.lin_logo /* 2131362398 */:
                if (this.logo_bottomSheetfragment.isAdded() || (logo_BottomSheetfragment = this.logo_bottomSheetfragment) == null) {
                    return;
                }
                logo_BottomSheetfragment.show(getSupportFragmentManager(), Logo_BottomSheetfragment.TAG);
                return;
            case R.id.lin_map /* 2131362402 */:
                if (this.mapTypeBottomSheetfragment.isAdded() || this.mapTypeBottomSheetfragment == null) {
                    return;
                }
                Bundle bundle5 = new Bundle();
                bundle5.putInt("type", 1);
                this.mapTypeBottomSheetfragment.setArguments(bundle5);
                this.mapTypeBottomSheetfragment.show(getSupportFragmentManager(), MapTypeBottomSheetfragment.TAG);
                return;
            case R.id.lin_notes /* 2131362404 */:
                if (this.note_bottom_sheetfragment.isAdded() || (note_bottom_sheetfragment = this.note_bottom_sheetfragment) == null) {
                    return;
                }
                note_bottom_sheetfragment.show(getSupportFragmentManager(), Note_bottom_sheetfragment.TAG);
                return;
            case R.id.lin_numbering /* 2131362406 */:
                if (this.numbering_bottomSheet.isAdded() || this.numbering_bottomSheet == null) {
                    return;
                }
                Bundle bundle6 = new Bundle();
                bundle6.putInt("type", this.Temp_type);
                this.numbering_bottomSheet.setArguments(bundle6);
                this.numbering_bottomSheet.show(getSupportFragmentManager(), Numbering_BottomSheet.TAG);
                return;
            case R.id.lin_pluscode /* 2131362407 */:
                if (this.mapTypeBottomSheetfragment.isAdded() || this.mapTypeBottomSheetfragment == null) {
                    return;
                }
                Bundle bundle7 = new Bundle();
                bundle7.putInt("type", 11);
                this.mapTypeBottomSheetfragment.setArguments(bundle7);
                this.mapTypeBottomSheetfragment.show(getSupportFragmentManager(), MapTypeBottomSheetfragment.TAG);
                return;
            case R.id.lin_pressure /* 2131362408 */:
                if (this.mapTypeBottomSheetfragment.isAdded() || this.mapTypeBottomSheetfragment == null) {
                    return;
                }
                Bundle bundle8 = new Bundle();
                bundle8.putInt("type", 6);
                this.mapTypeBottomSheetfragment.setArguments(bundle8);
                this.mapTypeBottomSheetfragment.show(getSupportFragmentManager(), MapTypeBottomSheetfragment.TAG);
                return;
            case R.id.lin_stampcolor /* 2131362412 */:
//                startActivity(new Intent(this, StampColorActivity.class));
                return;
            case R.id.lin_stampposition /* 2131362413 */:
                if (this.mapTypeBottomSheetfragment.isAdded() || this.mapTypeBottomSheetfragment == null) {
                    return;
                }
                Bundle bundle9 = new Bundle();
                bundle9.putInt("type", 4);
                this.mapTypeBottomSheetfragment.setArguments(bundle9);
                this.mapTypeBottomSheetfragment.show(getSupportFragmentManager(), MapTypeBottomSheetfragment.TAG);
                return;
            case R.id.lin_stampsize /* 2131362414 */:
                if (this.mapTypeBottomSheetfragment.isAdded() || this.mapTypeBottomSheetfragment == null) {
                    return;
                }
                Bundle bundle10 = new Bundle();
                bundle10.putInt("type", 10);
                this.mapTypeBottomSheetfragment.setArguments(bundle10);
                this.mapTypeBottomSheetfragment.show(getSupportFragmentManager(), MapTypeBottomSheetfragment.TAG);
                return;
            case R.id.lin_timezone /* 2131362417 */:
                if (this.timeZone_bottomsheet.isAdded() || (timeZone_BottomSheet = this.timeZone_bottomsheet) == null) {
                    return;
                }
                timeZone_BottomSheet.show(getSupportFragmentManager(), TimeZone_BottomSheet.TAG);
                return;
            case R.id.lin_wether /* 2131362428 */:
                if (this.mapTypeBottomSheetfragment.isAdded() || this.mapTypeBottomSheetfragment == null) {
                    return;
                }
                Bundle bundle11 = new Bundle();
                bundle11.putInt("type", 3);
                this.mapTypeBottomSheetfragment.setArguments(bundle11);
                this.mapTypeBottomSheetfragment.show(getSupportFragmentManager(), MapTypeBottomSheetfragment.TAG);
                return;
            case R.id.lin_wind /* 2131362429 */:
                if (this.mapTypeBottomSheetfragment.isAdded() || this.mapTypeBottomSheetfragment == null) {
                    return;
                }
                Bundle bundle12 = new Bundle();
                bundle12.putInt("type", 5);
                this.mapTypeBottomSheetfragment.setArguments(bundle12);
                this.mapTypeBottomSheetfragment.show(getSupportFragmentManager(), MapTypeBottomSheetfragment.TAG);
                return;
            default:
                return;
        }
    }

    private void setdateselected() {
        if (!isMapTemp() && !isAddressTemp() && !isLatLngTemp() && !isPlusCodeTemp() && !isDateTimeTemp() && !isLogoTemp() && !isNotesTemp() && !isWeatherTemp() && !isCompassTemp() && !isMagneticFieldTemp() && !isWindTemp() && !isHumidityTemp() && !ispressureTemp() && !isAltitudeTemp() && !isAccuracyTemp() && !isNumberingTemp() && !isTimezoneTemp()) {
            this.mSP.setBoolean(this, "date_and_time", true);
            this.img_datetime.setImageResource(R.drawable.ic_select_btn);
        }
        maponotheroff();
    }

    private void maponotheroff() {
        if (!isMapTemp() || isAddressTemp() || isLatLngTemp() || isPlusCodeTemp() || isDateTimeTemp() || isLogoTemp() || isNotesTemp() || isWeatherTemp() || isCompassTemp() || isMagneticFieldTemp() || isWindTemp() || isHumidityTemp() || ispressureTemp() || isAltitudeTemp() || isAccuracyTemp() || isTimezoneTemp() || isNumberingTemp()) {
            return;
        }
        this.mSP.setBoolean(this, "date_and_time", true);
        this.img_datetime.setImageResource(R.drawable.ic_select_btn);
    }

    private void showSnackbar() {
        Snackbar.make(this.mToolbar_back, getString(R.string.no_select_template), -1).show();
    }

    private boolean isAllUnCheck() {
        return (isMapTemp() || isAddressTemp() || isLatLngTemp() || isLogoTemp() || isNotesTemp() || isWeatherTemp() || isDateTimeTemp() || isMagneticFieldTemp() || isCompassTemp() || isAccuracyTemp() || isAltitudeTemp() || ispressureTemp() || isWindTemp() || isHumidityTemp() || isTimezoneTemp() || isNumberingTemp() || isPlusCodeTemp()) ? false : true;
    }


    private int checkwethwr() {
        int v = 0;
        int v1 = 0;
        while(v < 5) {
            if(v != 0) {
                switch(v) {
                    case 1: {
                        if(this.isHumidityTemp()) {
                            ++v1;
                        }

                        break;
                    }
                    case 2: {
                        if(this.ispressureTemp()) {
                            ++v1;
                        }

                        break;
                    }
                    case 3: {
                        if(this.isAltitudeTemp()) {
                            ++v1;
                        }

                        break;
                    }
                    default: {
                        if(v == 4 && (this.isAccuracyTemp())) {
                            ++v1;
                        }
                    }
                }
            }
            else if(this.isWindTemp()) {
                ++v1;
            }

            ++v;
        }

        return v1;
    }


    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        if (this.dateTime_bottomSheet.isAdded()) {
            this.dateTime_bottomSheet.refrecedata();
            Log.e("datetime76", "refrese");
        }
        setColors();
    }
}