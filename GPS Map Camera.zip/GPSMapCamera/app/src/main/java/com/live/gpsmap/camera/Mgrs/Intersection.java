package com.live.gpsmap.camera.Mgrs;

import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

/* loaded from: classes2.dex */
public final class Intersection {
    protected Vec4 intersectionPoint;
    protected Position intersectionPosition;
    protected boolean isTangent;
    protected Object object;

    public Intersection(Vec4 vec4, boolean z) {
        if (vec4 != null) {
            this.intersectionPoint = vec4;
            this.isTangent = z;
            return;
        }
        throw new IllegalArgumentException("Intersection Point Is Null");
    }

    public Intersection(Vec4 vec4, Position position, boolean z, Object obj) {
        if (vec4 != null) {
            this.intersectionPoint = vec4;
            this.intersectionPosition = position;
            this.isTangent = z;
            this.object = obj;
            return;
        }
        throw new IllegalArgumentException("Intersection Point Is Null");
    }

    public Position getIntersectionPosition() {
        return this.intersectionPosition;
    }

    public void setIntersectionPosition(Position position) {
        this.intersectionPosition = position;
    }

    public Object getObject() {
        return this.object;
    }

    public void setObject(Object obj) {
        this.object = obj;
    }

    public Vec4 getIntersectionPoint() {
        return this.intersectionPoint;
    }

    public void setIntersectionPoint(Vec4 vec4) {
        this.intersectionPoint = vec4;
    }

    public boolean isTangent() {
        return this.isTangent;
    }

    public void setTangent(boolean z) {
        this.isTangent = z;
    }

    public static Queue<Intersection> sort(final Vec4 vec4, List<Intersection> list, List<Intersection> list2) {
        PriorityQueue priorityQueue = new PriorityQueue(10, new Comparator<Intersection>() { // from class: com.gpsmapcamera.geotagginglocationonphoto.Mgrs.Intersection.1
            @Override // java.util.Comparator
            public int compare(Intersection intersection, Intersection intersection2) {
                if (intersection.intersectionPoint == null || intersection2.intersectionPoint == null) {
                    return 0;
                }
                double distanceTo3 = vec4.distanceTo3(intersection.intersectionPoint);
                double distanceTo32 = vec4.distanceTo3(intersection2.intersectionPoint);
                if (distanceTo3 < distanceTo32) {
                    return -1;
                }
                return distanceTo3 != distanceTo32 ? 1 : 0;
            }
        });
        if (list != null) {
            for (Intersection intersection : list) {
                priorityQueue.add(intersection);
            }
        }
        if (list2 != null) {
            for (Intersection intersection2 : list2) {
                priorityQueue.add(intersection2);
            }
        }
        return priorityQueue;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Intersection intersection = (Intersection) obj;
        return this.isTangent == intersection.isTangent && this.intersectionPoint.equals(intersection.intersectionPoint);
    }

    public int hashCode() {
        return (this.intersectionPoint.hashCode() * 29) + (this.isTangent ? 1 : 0);
    }

    public String toString() {
        return ("Intersection Point: " + this.intersectionPoint) + (this.isTangent ? " is a tangent." : " not a tangent");
    }
}
