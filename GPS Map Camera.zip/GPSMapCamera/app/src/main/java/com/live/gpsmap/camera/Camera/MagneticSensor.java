package com.live.gpsmap.camera.Camera;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.preference.PreferenceManager;
import android.util.Log;
import com.live.gpsmap.camera.R;



public class MagneticSensor {
    private static final String TAG = "MagneticSensor";
    private Sensor mSensorMagnetic;
    private boolean magneticListenerIsRegistered;
    private AlertDialog magnetic_accuracy_dialog;
    private final CameraMainActivity main_activity;
    private int magnetic_accuracy = -1;
    private final SensorEventListener magneticListener = new SensorEventListener() {
        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {
            Log.d(MagneticSensor.TAG, "magneticListener.onAccuracyChanged: " + i);
            MagneticSensor.this.magnetic_accuracy = i;
            MagneticSensor.this.setMagneticAccuracyDialogText();
            MagneticSensor.this.checkMagneticAccuracy();
        }

        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            MagneticSensor.this.main_activity.getPreview().onMagneticSensorChanged(sensorEvent);
        }
    };
    private boolean shown_magnetic_accuracy_dialog = false;

    public MagneticSensor(CameraMainActivity mainActivity) {
        this.main_activity = mainActivity;
    }

    public void initSensor(SensorManager sensorManager) {
        Log.d(TAG, "initSensor");
        if (sensorManager.getDefaultSensor(2) != null) {
            Log.d(TAG, "found magnetic sensor");
            this.mSensorMagnetic = sensorManager.getDefaultSensor(2);
            return;
        }
//        Log.d(TAG, BpmjsspqlQd.CPNCKYbajWevZ);
    }

    public void registerMagneticListener(SensorManager sensorManager) {
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.main_activity);
        if (!this.magneticListenerIsRegistered) {
            if (needsMagneticSensor(defaultSharedPreferences)) {
                Log.d(TAG, "register magneticListener");
                sensorManager.registerListener(this.magneticListener, this.mSensorMagnetic, 3);
                this.magneticListenerIsRegistered = true;
                return;
            }
//            Log.d(TAG, IvpEABn.AScc);
        } else if (needsMagneticSensor(defaultSharedPreferences)) {
            Log.d(TAG, "magneticListener already registered");
        } else {
            Log.d(TAG, "magneticListener already registered but no longer needed");
            sensorManager.unregisterListener(this.magneticListener);
            this.magneticListenerIsRegistered = false;
        }
    }


    public void unregisterMagneticListener(SensorManager sensorManager) {
        if (this.magneticListenerIsRegistered) {
            Log.d(TAG, "unregister magneticListener");
            sensorManager.unregisterListener(this.magneticListener);
            this.magneticListenerIsRegistered = false;
            return;
        }
        Log.d(TAG, "magneticListener wasn't registered");
    }

    public void setMagneticAccuracyDialogText() {
        String str;
        Log.d(TAG, "setMagneticAccuracyDialogText()");
        if (this.magnetic_accuracy_dialog != null) {
            String str2 = this.main_activity.getResources().getString(R.string.magnetic_accuracy_info) + " ";
            int i = this.magnetic_accuracy;
            if (i == 0) {
                str = str2 + this.main_activity.getResources().getString(R.string.accuracy_unreliable);
            } else if (i == 1) {
                str = str2 + this.main_activity.getResources().getString(R.string.accuracy_low);
            } else if (i == 2) {
                str = str2 + this.main_activity.getResources().getString(R.string.accuracy_medium);
            } else if (i == 3) {
                str = str2 + this.main_activity.getResources().getString(R.string.accuracy_high);
            } else {
                str = str2 + this.main_activity.getResources().getString(R.string.accuracy_unknown);
            }
            Log.d(TAG, "message: " + str);
            this.magnetic_accuracy_dialog.setMessage(str);
        }
    }

    public void checkMagneticAccuracy() {
        Log.d(TAG, "checkMagneticAccuracy(): " + this.magnetic_accuracy);
        int i = this.magnetic_accuracy;
        if (i != 0 && i != 1) {
            Log.d(TAG, "accuracy is good enough (or accuracy not yet known)");
        } else if (this.shown_magnetic_accuracy_dialog) {
            Log.d(TAG, "already shown_magnetic_accuracy_dialog");
        } else if (this.main_activity.getPreview().isTakingPhotoOrOnTimer() || this.main_activity.getPreview().isVideoRecording()) {
            Log.d(TAG, "don't disturb whilst taking photo, on timer, or recording video");
        } else if (this.main_activity.isCameraInBackground()) {
            Log.d(TAG, "don't show magnetic accuracy dialog due to camera in background");
        } else {
            SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.main_activity);
            if (!needsMagneticSensor(defaultSharedPreferences)) {
                Log.d(TAG, "don't need magnetic sensor");
            } else if (defaultSharedPreferences.contains(PreferenceKeys.MagneticAccuracyPreferenceKey)) {
                Log.d(TAG, "user selected to no longer show the dialog");
                this.shown_magnetic_accuracy_dialog = true;
            } else {
                Log.d(TAG, "show dialog for magnetic accuracy");
                this.shown_magnetic_accuracy_dialog = true;
                this.magnetic_accuracy_dialog = this.main_activity.getMainUI().showInfoDialog(R.string.magnetic_accuracy_title, 0, PreferenceKeys.MagneticAccuracyPreferenceKey);
                setMagneticAccuracyDialogText();
            }
        }
    }

    private boolean needsMagneticSensor(SharedPreferences sharedPreferences) {
        return this.main_activity.getApplicationInterface().getGeodirectionPref() || sharedPreferences.getBoolean(PreferenceKeys.AddYPRToComments, false) || sharedPreferences.getBoolean(PreferenceKeys.ShowGeoDirectionLinesPreferenceKey, false) || sharedPreferences.getBoolean(PreferenceKeys.ShowGeoDirectionPreferenceKey, false);
    }

    int getMagneticAccuracy() {
        return this.magnetic_accuracy;
    }


    public void clearDialog() {
        this.magnetic_accuracy_dialog = null;
    }
}
