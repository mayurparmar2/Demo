package com.live.gpsmap.camera.Receiver;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import com.live.gpsmap.camera.Utils.SP;

import java.util.Calendar;

/* loaded from: classes2.dex */
public class AlarmTimingUtils {
    public static void setLastOpenTime(Context context, long j) {
        new SP(context).setLong(context, SP.OPEN_TIME, j);
    }

    public static long getLastOpenTime(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 16384);
            if (new SP(context).getLong(context, SP.OPEN_TIME, packageInfo.firstInstallTime) == packageInfo.firstInstallTime) {
                return packageInfo.firstInstallTime;
            }
            return new SP(context).getLong(context, SP.OPEN_TIME, packageInfo.firstInstallTime);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return 0L;
        }
    }

    public static boolean isWithin15Days(Context context) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(getLastOpenTime(context));
        Calendar calendar2 = Calendar.getInstance();
        calendar2.setTimeInMillis(System.currentTimeMillis());
        return Integer.parseInt(Long.toString(Math.abs(calendar2.getTimeInMillis() - calendar.getTimeInMillis()) / 86400000)) <= 14;
    }
}