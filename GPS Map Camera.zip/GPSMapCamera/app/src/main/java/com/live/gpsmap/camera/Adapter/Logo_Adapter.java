package com.live.gpsmap.camera.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.live.gpsmap.camera.Interface.OnRecyclerItemClickListener;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Util;
import com.live.gpsmap.camera.Widget.RoundImageView;

import java.util.ArrayList;
import java.util.Collections;

/* loaded from: classes2.dex */
public class Logo_Adapter extends RecyclerView.Adapter<Logo_Adapter.Holder> {
    Context mContext;
    public ArrayList<String> mList;
    OnRecyclerItemClickListener mOnRecyclerItemClickListener;

    public Logo_Adapter(Context context, ArrayList<String> arrayList, OnRecyclerItemClickListener onRecyclerItemClickListener) {
        new ArrayList();
        this.mContext = context;
        this.mList = arrayList;
        Collections.reverse(arrayList);
        this.mOnRecyclerItemClickListener = onRecyclerItemClickListener;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.logo_adapter, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(Holder holder, int i) {
        Glide.with(this.mContext).load(Util.decodeBase64(this.mList.get(i))).into(holder.img);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.mList.size();
    }

    /* loaded from: classes.dex */
    public class Holder extends RecyclerView.ViewHolder {
        RoundImageView img;
        LinearLayout lin_img_click;

        public Holder(View view) {
            super(view);
            this.lin_img_click = (LinearLayout) view.findViewById(R.id.lin_img_click);
            this.img = (RoundImageView) view.findViewById(R.id.img);
            this.lin_img_click.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.adapter.Logo_Adapter.Holder.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    if (Holder.this.getAdapterPosition() < 0 || Logo_Adapter.this.mOnRecyclerItemClickListener == null) {
                        return;
                    }
                    Logo_Adapter.this.mOnRecyclerItemClickListener.OnClick_(Holder.this.getAdapterPosition(), view2);
                }
            });
            this.lin_img_click.setOnLongClickListener(new View.OnLongClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.adapter.Logo_Adapter.Holder.2
                @Override // android.view.View.OnLongClickListener
                public boolean onLongClick(View view2) {
                    if (Logo_Adapter.this.mOnRecyclerItemClickListener != null) {
                        Logo_Adapter.this.mOnRecyclerItemClickListener.OnLongClick_(Holder.this.getAdapterPosition(), view2);
                        return true;
                    }
                    return true;
                }
            });
        }
    }
}