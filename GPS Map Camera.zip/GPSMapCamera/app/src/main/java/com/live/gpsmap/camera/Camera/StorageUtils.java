package com.live.gpsmap.camera.Camera;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.os.StatFs;
import android.preference.PreferenceManager;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v4.media.session.PlaybackStateCompat;
import android.system.Os;
import android.system.StructStatVfs;
import android.util.Log;

import androidx.core.content.ContextCompat;

import com.live.gpsmap.camera.Camera.Script.Say.TccIv;
import com.live.gpsmap.camera.Model.ViewModel;
import com.live.gpsmap.camera.Utils.Default;
import com.live.gpsmap.camera.Utils.Util;
import com.live.gpsmap.camera.Utils.SP;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

@SuppressWarnings("All")
public class StorageUtils {
    static final int MEDIA_TYPE_GYRO_INFO = 4;
    static final int MEDIA_TYPE_IMAGE = 1;
    static final int MEDIA_TYPE_PREFS = 3;
    static final int MEDIA_TYPE_VIDEO = 2;
    private static final String RELATIVE_FOLDER_BASE = Environment.DIRECTORY_DCIM;
    private static final String TAG = "StorageUtils";
    private final MyApplicationInterface applicationInterface;
    private final Context context;
    public volatile boolean failed_to_scan;
    private Uri last_media_scanned;

    public void broadcastFile(final File file, final boolean is_new_picture, final boolean is_new_video, final boolean set_last_scanned, final boolean hasnoexifdatetime, final Uri saf_uri) {
        if( MyDebug.LOG )
            Log.d(TAG, "broadcastFile: " + file.getAbsolutePath());
        // note that the new method means that the new folder shows up as a file when connected to a PC via MTP (at least tested on Windows 8)
        if( file.isDirectory() ) {
            //this.sendBroadcast(new Intent(Intent.ACTION_MEDIA_MOUNTED, Uri.fromFile(file)));
            // ACTION_MEDIA_MOUNTED no longer allowed on Android 4.4! Gives: SecurityException: Permission Denial: not allowed to send broadcast android.intent.action.MEDIA_MOUNTED
            // note that we don't actually need to broadcast anything, the folder and contents appear straight away (both in Gallery on device, and on a PC when connecting via MTP)
            // also note that we definitely don't want to broadcast ACTION_MEDIA_SCANNER_SCAN_FILE or use scanFile() for folders, as this means the folder shows up as a file on a PC via MTP (and isn't fixed by rebooting!)
        }
        else {
            // both of these work fine, but using MediaScannerConnection.scanFile() seems to be preferred over sending an intent
            //context.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file)));
            failed_to_scan = true; // set to true until scanned okay
            if( MyDebug.LOG )
                Log.d(TAG, "failed_to_scan set to true");
            MediaScannerConnection.scanFile(context, new String[] { file.getAbsolutePath() }, null,
                    new MediaScannerConnection.OnScanCompletedListener() {
                        public void onScanCompleted(String path, Uri uri) {
                            failed_to_scan = false;
                            if( MyDebug.LOG ) {
                                Log.d(TAG, "Scanned " + path + ":");
                                Log.d(TAG, "-> uri=" + uri);
                            }
                            if( set_last_scanned ) {
                                boolean is_raw = filenameIsRaw(file.getName());
                                setLastMediaScanned(uri, is_raw, hasnoexifdatetime, saf_uri != null ? saf_uri : uri);
                            }
                            announceUri(uri, is_new_picture, is_new_video);
                            applicationInterface.scannedFile(file, uri);

                            // If called from video intent, if not using scoped-storage, we'll have saved using File API (even if user preference is SAF), see
                            // MyApplicationInterface.createOutputVideoMethod().
                            // It seems caller apps seem to prefer the content:// Uri rather than one based on a File
                            // update for Android 7: seems that passing file uris is now restricted anyway, see https://code.google.com/p/android/issues/detail?id=203555
                            // So we pass the uri back to the caller here.
                            Activity activity = (Activity)context;
                            String action = activity.getIntent().getAction();
                            if( !CameraMainActivity.useScopedStorage() && MediaStore.ACTION_VIDEO_CAPTURE.equals(action) ) {
                                applicationInterface.finishVideoIntent(uri);
                            }
                        }
                    }
            );
        }
    }

    private boolean last_media_scanned_is_raw;
    private boolean last_media_scanned_hasnoexifdatetime;
    private Uri last_media_scanned_check_uri;
    void setLastMediaScanned(Uri uri, boolean is_raw, boolean hasnoexifdatetime, Uri check_uri) {
        last_media_scanned = uri;
        last_media_scanned_is_raw = is_raw;
        last_media_scanned_hasnoexifdatetime = hasnoexifdatetime;
        if( hasnoexifdatetime )
            last_media_scanned_check_uri = check_uri;
        else
            last_media_scanned_check_uri = null;
        if( MyDebug.LOG ) {
            Log.d(TAG, "set last_media_scanned to " + last_media_scanned);
            Log.d(TAG, "    last_media_scanned_is_raw: " + last_media_scanned_is_raw);
            Log.d(TAG, "    last_media_scanned_hasnoexifdatetime: " + last_media_scanned_hasnoexifdatetime);
            Log.d(TAG, "    last_media_scanned_check_uri: " + check_uri);
        }
    }

    public void broadcastUri(final Uri uri, final boolean is_new_picture, final boolean is_new_video, final boolean set_last_scanned, final boolean hasnoexifdatetime, final boolean image_capture_intent) {
        if( MyDebug.LOG )
            Log.d(TAG, "broadcastUri: " + uri);
        /* We still need to broadcastFile for SAF for various reasons:
            1. To call storageUtils.announceUri() to broadcast NEW_PICTURE etc.
               Whilst in theory we could do this directly, it seems external apps that use such broadcasts typically
               won't know what to do with a SAF based Uri (e.g, Owncloud crashes!) so better to broadcast the Uri
               corresponding to the real file, if it exists.
            2. Whilst the new file seems to be known by external apps such as Gallery without having to call media
               scanner, I've had reports this doesn't happen when saving to external SD cards. So better to explicitly
               scan.
            3. If set_last_scanned==true, it means we get the media uri which can be used to set the thumbnail uri
               (see setLastMediaScanned()). This is particularly important when using SAF with scoped storage, as
               getting the latest media via SAF APIs is (if not cached) very slow! N.B., most gallery apps need a
               mediastore uri, not the SAF uri.
        */
        File real_file = getFileFromDocumentUriSAF(uri, false);
        if( MyDebug.LOG )
            Log.d(TAG, "real_file: " + real_file);
        if( real_file != null ) {
            if( MyDebug.LOG )
                Log.d(TAG, "broadcast file");
            //Uri media_uri = broadcastFileRaw(real_file, current_date, location);
            //announceUri(media_uri, is_new_picture, is_new_video);
            broadcastFile(real_file, is_new_picture, is_new_video, set_last_scanned, hasnoexifdatetime, uri);
        }
        else if( !image_capture_intent ) {
            if( MyDebug.LOG )
                Log.d(TAG, "announce SAF uri");
            // shouldn't do this for an image capture intent - e.g., causes crash when calling from Google Keep
            announceUri(uri, is_new_picture, is_new_video);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public enum UriType {
        MEDIASTORE_IMAGES,
        MEDIASTORE_VIDEOS
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public StorageUtils(Context context, MyApplicationInterface myApplicationInterface) {
        this.context = context;
        this.applicationInterface = myApplicationInterface;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Uri getLastMediaScanned() {
        return this.last_media_scanned;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void clearLastMediaScanned() {
        this.last_media_scanned = null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void setLastMediaScanned(Uri uri) {
        this.last_media_scanned = uri;
        Log.d(TAG, "set last_media_scanned to " + this.last_media_scanned);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void announceUri(Uri uri, boolean z, boolean z2) {
        Log.d(TAG, "announceUri: " + uri);
        if (Build.VERSION.SDK_INT>=24) {
            Log.d(TAG, "broadcasts deprecated on Android 7 onwards, so don't send them");
        } else if (!z) {
            if (z2) {
                this.context.sendBroadcast(new Intent("android.hardware.action.NEW_VIDEO", uri));
            }
        } else {
            this.context.sendBroadcast(new Intent("android.hardware.action.NEW_PICTURE", uri));
            this.context.sendBroadcast(new Intent("com.android.camera.NEW_PICTURE", uri));
            Cursor query = this.context.getContentResolver().query(uri, new String[]{"_data", "_display_name", "mime_type", "datetaken", TccIv.jtc, "date_added"}, null, null, null);
            if (query == null) {
                Log.e(TAG, "Couldn't resolve given uri [1]: " + uri);
            } else if (!query.moveToFirst()) {
                Log.e(TAG, "Couldn't resolve given uri [2]: " + uri);
            } else {
                String string = query.getString(query.getColumnIndex("_data"));
                String string2 = query.getString(query.getColumnIndex("_display_name"));
                String string3 = query.getString(query.getColumnIndex("mime_type"));
                long j = query.getLong(query.getColumnIndex("datetaken"));
                long j2 = query.getLong(query.getColumnIndex("date_added"));
                Log.d(TAG, "file_path: " + string);
                Log.d(TAG, "file_name: " + string2);
                Log.d(TAG, "mime_type: " + string3);
                Log.d(TAG, "date_taken: " + j);
                Log.d(TAG, "date_added: " + j2);
                query.close();
            }
        }
    }

    public void broadcastFile(final File file, final boolean z, final boolean z2, final boolean z3) {
        Log.d(TAG, "broadcastFile: " + file.getAbsolutePath());
        if (file.isDirectory()) {
            return;
        }
        this.failed_to_scan = true;
        Log.d(TAG, "failed_to_scan set to true");
        MediaScannerConnection.scanFile(this.context, new String[]{file.getAbsolutePath()}, null, new MediaScannerConnection.OnScanCompletedListener() { // from class: com.live.gpsmap.camera.Camera.StorageUtils.1
            @Override // android.media.MediaScannerConnection.OnScanCompletedListener
            public void onScanCompleted(String str, Uri uri) {
                StorageUtils.this.failed_to_scan = false;
                Log.d(StorageUtils.TAG, "Scanned " + str + ":");
                StringBuilder sb = new StringBuilder();
                sb.append("-> uri=");
                sb.append(uri);
                Log.d(StorageUtils.TAG, sb.toString());
                if (z3) {
                    StorageUtils.this.setLastMediaScanned(uri);
                }
                StorageUtils.this.announceUri(uri, z, z2);
                StorageUtils.this.applicationInterface.scannedFile(file, uri);
                String action = ((Activity) StorageUtils.this.context).getIntent().getAction();
                if (CameraMainActivity.useScopedStorage() || !"android.media.action.VIDEO_CAPTURE".equals(action)) {
                    return;
                }
                StorageUtils.this.applicationInterface.finishVideoIntent(uri);
            }
        });
    }

    public void broadcastUri(Uri uri, boolean z, boolean z2, boolean z3, boolean z4) {
        Log.d(TAG, "broadcastUri: " + uri);
        File fileFromDocumentUriSAF = getFileFromDocumentUriSAF(uri, false);
        Log.d(TAG, "real_file: " + fileFromDocumentUriSAF);
        if (fileFromDocumentUriSAF != null) {
            Log.d(TAG, "broadcast file");
            broadcastFile(fileFromDocumentUriSAF, z, z2, z3);
        } else if (z4) {
        } else {
            Log.d(TAG, "announce SAF uri");
            announceUri(uri, z, z2);
        }
    }

    public boolean isUsingSAF() {
        return Build.VERSION.SDK_INT>=21 && PreferenceManager.getDefaultSharedPreferences(this.context).getBoolean(PreferenceKeys.UsingSAFPreferenceKey, false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public String getSaveLocation() {
        return PreferenceManager.getDefaultSharedPreferences(this.context).getString(PreferenceKeys.SaveLocationPreferenceKey, "OpenCamera");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public String getSaveLocationSAF() {
        return PreferenceManager.getDefaultSharedPreferences(this.context).getString(PreferenceKeys.SaveLocationSAFPreferenceKey, "");
    }

    public Uri getTreeUriSAF() {
        return Uri.parse(getSaveLocationSAF());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public File getSettingsFolder() {
        return new File(this.context.getExternalFilesDir(null), "backups");
    }

    public String getImageFolderPath() {
        File imageFolder = getImageFolder();
        if (imageFolder == null) {
            return null;
        }
        return imageFolder.getAbsolutePath();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public File getImageFolder() {
        if (isUsingSAF()) {
            return getFileFromDocumentUriSAF(getTreeUriSAF(), true);
        }
        return getImageFolder(getSaveLocation());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public String getSaveRelativeFolder() {
        return getSaveRelativeFolder(getSaveLocation());
    }

    private static String getSaveRelativeFolder(String str) {
        if (str.length()>0 && str.lastIndexOf(47) == str.length() - 1) {
            str = str.substring(0, str.length() - 1);
        }
        return RELATIVE_FOLDER_BASE + File.separator + str;
    }

    public static File getBaseFolder() {
        return Environment.getExternalStoragePublicDirectory(RELATIVE_FOLDER_BASE);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean saveFolderIsFull(String str) {
        return str.startsWith("/");
    }

    private static File getImageFolder(String str) {
        if (str.length()>0 && str.lastIndexOf(47) == str.length() - 1) {
            str = str.substring(0, str.length() - 1);
        }
        if (saveFolderIsFull(str)) {
            return new File(str);
        }
        return new File(getBaseFolder(), str);
    }

    public String getFilePathFromDocumentUriSAF(Uri uri, boolean z) {
        File fileFromDocumentUriSAF = getFileFromDocumentUriSAF(uri, z);
        if (fileFromDocumentUriSAF == null) {
            return null;
        }
        return fileFromDocumentUriSAF.getAbsolutePath();
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0117, code lost:
        r6 = new java.io.File(r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x01a2, code lost:
        if (r11.equals(com.facebook.internal.AnalyticsEvents.PARAMETER_SHARE_DIALOG_CONTENT_VIDEO) == false) goto L54;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public File getFileFromDocumentUriSAF(Uri uri, boolean z) {
        Uri uri2;
        Log.d(TAG, "is_folder?: " + z);
        String authority = uri.getAuthority();
        Log.d(TAG, "authority: " + authority);
        Log.d(TAG, "scheme: " + uri.getScheme());
        Log.d(TAG, "fragment: " + uri.getFragment());
        Log.d(TAG, "path: " + uri.getPath());
        Log.d(TAG, "last path segment: " + uri.getLastPathSegment());
        char c = 2;
        File r6 = null;
        if ("com.android.externalstorage.documents".equals(authority)) {
            String treeDocumentId = z ? DocumentsContract.getTreeDocumentId(uri) : DocumentsContract.getDocumentId(uri);
            Log.d(TAG, "id: " + treeDocumentId);
            String[] split = treeDocumentId.split(":");
            if (split.length>=1) {
                String str = split[0];
                String str2 = split.length>=2 ? split[1] : "";
                File[] listFiles = new File("/storage").listFiles();
                r6 = "primary".equalsIgnoreCase(str) ? new File(Environment.getExternalStorageDirectory(), str2) : null;
                for (int i = 0; listFiles != null && i<listFiles.length && r6 == null; i++) {
                    File file = new File(listFiles[i], str2);
                    if (file.exists()) {
                        r6 = file;
                    }
                }
            }
        } else if ("com.android.providers.downloads.documents".equals(authority)) {
            if (!z) {
                String documentId = DocumentsContract.getDocumentId(uri);
                if (documentId.startsWith("raw:")) {
                    r6 = new File(documentId.replaceFirst("raw:", ""));
                } else {
                    try {
                        String dataColumn = getDataColumn(ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"), Long.parseLong(documentId)), null, null);
                        if (dataColumn != null) {
                            r6 = new File(dataColumn);
                        }
                    } catch (NumberFormatException e) {
                        Log.e(TAG, "failed to parse id: " + documentId);
                        e.printStackTrace();
                    }
                }
            } else {
                Log.d(TAG, "downloads uri not supported for folders");
            }
        } else if ("com.android.providers.media.documents".equals(authority)) {
            String[] split2 = DocumentsContract.getDocumentId(uri).split(":");
            String str3 = split2[0];
            str3.hashCode();
            switch (str3.hashCode()) {
                case 93166550:
                    if (str3.equals("audio")) {
                        c = 0;
                        break;
                    }
                    c = 65535;
                    break;
                case 100313435:
                    if (str3.equals("image")) {
                        c = 1;
                        break;
                    }
                    c = 65535;
                    break;
                case 112202875:
                    break;
                default:
                    c = 65535;
                    break;
            }
            switch (c) {
                case 0:
                    uri2 = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                    break;
                case 1:
                    uri2 = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    break;
                case 2:
                    uri2 = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                    break;
                default:
                    uri2 = null;
                    break;
            }
            String dataColumn2 = getDataColumn(uri2, "_id=?", new String[]{split2[1]});
            if (dataColumn2 != null) {
                r6 = new File(dataColumn2);
            }
        }
        if (r6 != null) {
            Log.d(TAG, "file: " + r6.getAbsolutePath());
        } else {
            Log.d(TAG, "failed to find file");
        }
        return r6;
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x002f, code lost:
        if (r9 != null) goto L8;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0041, code lost:
        if (r9 == null) goto L6;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:33:0x004b  */
    /* JADX WARN: Type inference failed for: r7v0 */
    /* JADX WARN: Type inference failed for: r7v1, types: [android.database.Cursor] */
    /* JADX WARN: Type inference failed for: r7v2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private String getDataColumn(Uri uri0, String s, String[] arr_s) {
        String s1 = ""; //Changed All
        Cursor cursor0 = null;
        try {
            cursor0 = this.context.getContentResolver().query(uri0, new String[]{"_data"}, s, arr_s, null);
//            label_20:
            if (cursor0 != null) {
                try {
                    if (cursor0.moveToFirst()) {
                        s1 = cursor0.getString(cursor0.getColumnIndexOrThrow("_data"));
                        if (cursor0 != null) {
                            cursor0.close();
                        }
                    }
                } catch (SecurityException securityException0) {
//                    label_38:
                    securityException0.printStackTrace();
                    if (cursor0 != null) {
                        cursor0.close();
                        return null;
                    }

                    return null;
                }
            }
        } catch (IllegalArgumentException illegalArgumentException0) {
            cursor0 = null;
            illegalArgumentException0.printStackTrace();
            if (cursor0 != null) {
                cursor0.close();
                return null;
            }


//            label_53:
            if (cursor0 != null) {
                cursor0.close();
            }
        } catch (SecurityException securityException0) {
            securityException0.printStackTrace();
            if (cursor0 != null) {
                cursor0.close();
                return null;
            }
        }

        return s1;
    }

    public String getFileName(Uri uri0) {
        Cursor cursor0;
        Log.d("StorageUtils", "getFileName: " + uri0);
        Log.d("StorageUtils", "uri has path: " + uri0.getPath());
        String s = null;
        if (uri0.getScheme() != null && (uri0.getScheme().equals("content"))) {
            try {
                cursor0 = this.context.getContentResolver().query(uri0, null, null, null, null);
                if (cursor0 != null && (cursor0.moveToFirst())) {
                    s = cursor0.getString(cursor0.getColumnIndexOrThrow("_display_name"));
                    Log.d("StorageUtils", "found name from database: " + s);
                }
            } catch (Exception exception0) {
                try {
                    Log.e("StorageUtils", "Exception trying to find filename");
                    exception0.printStackTrace();
                } catch (Throwable throwable0) {
//                    label_77:

                }

//                if(((Cursor)s) != null) {
//                    ((Cursor)s).close();
//                }

                if (s == null) {
                    Log.d("StorageUtils", "resort to checking the uri\'s path");
                    s = uri0.getPath();
                    int v = s.lastIndexOf(0x2F);
                    if (v != -1) {
                        s = s.substring(v + 1);
                        Log.d("StorageUtils", "found name from path: " + s);
                    }
                }
            } catch (Throwable throwable0) {
//                label_77:
//                if(((Cursor)s) != null) {
//                    ((Cursor)s).close();
//                }

                throw throwable0;
            }

//            if(cursor0 != null) {
//                cursor0.close();
//            }
        }

//        label_92:
//        if(s == null) {
//            Log.d("StorageUtils", "resort to checking the uri\'s path");
//            s = uri0.getPath();
//            int v = s.lastIndexOf(0x2F);
//            if(v != -1) {
//                s = s.substring(v + 1);
//                Log.d("StorageUtils", "found name from path: " + s);
//            }
//        }

        return s;
    }

    boolean isNotEmpty(String str) {
        if (str == null) {
            return false;
        }
        return !str.trim().isEmpty();
    }


    public String createMediaFilename(int i, String str, int i2, String str2, Date date) {
        int i3;
        String str3;
        String str4;
        String str5;
        SP sp = new SP(this.context);
        sp.getBoolean(this.context, SP.IS_FILE_DATE_TIME, true);
        boolean z = sp.getBoolean(this.context, SP.IS_SEQUENCE, false);
        sp.getBoolean(this.context, SP.IS_CUS_1, true);
        sp.getBoolean(this.context, SP.IS_CUS_2, false);
        sp.getBoolean(this.context, SP.IS_CUS_3, false);
        boolean z2 = sp.getBoolean(this.context, SP.IS_LAT_LNG, false);
        boolean z3 = sp.getBoolean(this.context, SP.IS_MAIN_ADDRESS, false);
        new ArrayList();
        String str6 = "";
        if (sp.getArrayList(this.context) == null) {
            str6 = getTimeStamp() + Default.CUSTUM_NAME_1_VALUE;
            Log.e("file_name7600", str6);
        } else {
            ArrayList<ViewModel> arrayList = sp.getArrayList(this.context);
            int integer = sp.getInteger(this.context, SP.DATE_TIME_INDEX, 0);
            int integer2 = sp.getInteger(this.context, SP.SEQUENCE_INDEX, 1);
            int integer3 = sp.getInteger(this.context, SP.ADDRESS_INDEX, 5);
            int integer4 = sp.getInteger(this.context, SP.LAT_LNG_INDEX, 6);
            arrayList.get(integer).setValue(getTimeStamp());
            if (z) {
                int integer5 = sp.getInteger(this.context, SP.SEQUENCE_VALUE, 1);
                arrayList.get(integer2).setValue("" + integer5);
                int i4 = integer5 + 1;
                if (i4 == 100000) {
                    i4 = 1;
                }
                sp.setInteger(this.context, SP.SEQUENCE_VALUE, i4);
            }
            if (z3) {
                boolean z4 = sp.getBoolean(this.context, SP.IS_LINE_1, false);
                boolean z5 = sp.getBoolean(this.context, SP.IS_LINE_2, false);
                boolean z6 = sp.getBoolean(this.context, SP.IS_LINE_3, false);
                boolean z7 = sp.getBoolean(this.context, SP.IS_LINE_4, false);
                String string = sp.getString(this.context, SP.LOC_LINE_1_ADDRESS, "");
                String string2 = sp.getString(this.context, SP.LOC_LINE_2_CITY, "");
                String string3 = sp.getString(this.context, SP.LOC_LINE_3_STATE, "");
                i3 = integer4;
                String string4 = sp.getString(this.context, SP.LOC_LINE_4_COUNTRY, "");
                if (z4 && isNotEmpty(string)) {
                    str5 = "_" + string;
                } else {
                    str5 = "";
                }
                if (z5 && isNotEmpty(string2)) {
                    str5 = str5 + "_" + string2;
                }
                if (z6 && isNotEmpty(string3)) {
                    str5 = str5 + "_" + string3;
                }
                if (z7 && isNotEmpty(string4)) {
                    str5 = str5 + "_" + string4;
                }
                arrayList.get(integer3).setValue(str5);
            } else {
                i3 = integer4;
            }
            if (z2) {
                boolean z8 = sp.getBoolean(this.context, SP.IS_DECIMAL_FILE, false);
                boolean z9 = sp.getBoolean(this.context, SP.IS_DMS_FILE, false);
                String string5 = sp.getString(this.context, SP.LATITUDE, "");
                String string6 = sp.getString(this.context, SP.LONGITUDE, "");
                if (isNotEmpty(string5) && isNotEmpty(string6)) {
                    if (z8) {
                        str4 = "_" + string5 + "_" + string6;
                    } else {
                        str4 = "";
                    }
                    if (z9) {
                        str4 = str4 + "_" + Util.dms_latlng(this.context);
                    }
                    arrayList.get(i3).setValue(str4);
                }
            }
            if (arrayList != null && arrayList.size()>0) {
                if (arrayList.get(0).getSelected().booleanValue() && isNotEmpty(arrayList.get(0).getValue())) {
                    str3 = "" + arrayList.get(0).getValue();
                } else {
                    str3 = "";
                }
                if (arrayList.get(1).getSelected().booleanValue() && isNotEmpty(arrayList.get(1).getValue())) {
                    str3 = str3 + "_" + arrayList.get(1).getValue();
                }
                if (arrayList.get(2).getSelected().booleanValue() && isNotEmpty(arrayList.get(2).getValue())) {
                    str3 = str3 + "_" + arrayList.get(2).getValue();
                }
                if (arrayList.get(3).getSelected().booleanValue() && isNotEmpty(arrayList.get(3).getValue())) {
                    str3 = str3 + "_" + arrayList.get(3).getValue();
                }
                if (arrayList.get(4).getSelected().booleanValue() && isNotEmpty(arrayList.get(4).getValue())) {
                    str3 = str3 + "_" + arrayList.get(4).getValue();
                }
                if (arrayList.get(5).getSelected().booleanValue() && isNotEmpty(arrayList.get(5).getValue())) {
                    str3 = str3 + "_" + arrayList.get(5).getValue();
                }
                if (arrayList.get(6).getSelected().booleanValue() && isNotEmpty(arrayList.get(6).getValue())) {
                    str3 = str3 + "_" + arrayList.get(6).getValue();
                }
                if (isNotEmpty(str3)) {
                    if (str3.substring(0, 1).equals("_")) {
                        str3 = str3.replaceFirst("_", "");
                    }
                    str6 = str3.replace("__", "_");
                } else {
                    str6 = str3;
                }
            }
        }
        if (i != 1) {
            if (i == 2 || i == 3) {
                return "IMG";
            }
            if (i != 4) {
                Log.e(TAG, "unknown type: " + i);
                throw new RuntimeException();
            }
        }
        String str7 = str6 + str2;
        System.out.println("MediaFileMethodTypes        " + str7);
        return str7;
    }

    private String getTimeStamp() {
        String trim;
        SP sp = new SP(this.context);
        boolean z = sp.getBoolean(this.context, SP.IS_WEEK, false);
        if (sp.getBoolean(this.context, SP.IS_24HR, false)) {
            trim = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()).trim();
        } else {
            trim = new SimpleDateFormat("yyyyMMdd_hmmssa").format(new Date()).trim();
        }
        if (z) {
            return trim + "_" + getWeek();
        }
        return trim;
    }

    private String getWeek() {
        return new SimpleDateFormat("EEEE").format(new Date());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public File createOutputMediaFile(int i, String str, String str2, Date date) throws IOException {
        return createOutputMediaFile(getImageFolder(), i, str, str2, date);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void createFolderIfRequired(File file) throws IOException {
        if (file.exists()) {
            return;
        }
        Log.d(TAG, "create directory: " + file);
        if (!file.mkdirs()) {
            Log.e(TAG, "failed to create directory");
            throw new IOException();
        } else {
            broadcastFile(file, false, false, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public File createOutputMediaFile(File file, int i, String str, String str2, Date date) throws IOException {
        createFolderIfRequired(file);
        File file2 = null;
        int i2 = 0;
        while (true) {
            if (i2>=100) {
                break;
            }
            String createMediaFilename = createMediaFilename(i, str, i2, "." + str2, date);
            File file3 = new File(file.getPath() + File.separator + createMediaFilename);
            if (!file3.exists()) {
                file2 = file3;
                break;
            }
            i2++;
            file2 = file3;
        }
        Log.d(TAG, "getOutputMediaFile returns: " + file2);
        if (file2 != null) {
            return file2;
        }
        throw new IOException();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
//    public Uri createOutputFileSAF(String str, String str2) throws IOException {
//        try {
//            Uri treeUriSAF = getTreeUriSAF();
//            Log.d(TAG, "treeUri: " + treeUriSAF);
//            Uri buildDocumentUriUsingTree = DocumentsContract.buildDocumentUriUsingTree(treeUriSAF, DocumentsContract.getTreeDocumentId(treeUriSAF));
//            Log.d(TAG, AyDI.kmvrzKvcSkvDJD + buildDocumentUriUsingTree);
//            Uri createDocument = DocumentsContract.createDocument(this.context.getContentResolver(), buildDocumentUriUsingTree, str2, str);
//            if (createDocument != null) {
//                return createDocument;
//            }
//            throw new IOException();
//        } catch (IllegalArgumentException e) {
//            e = e;
//            Log.e(TAG, "createOutputMediaFileSAF failed with IllegalArgumentException");
//            e.printStackTrace();
//            throw new IOException();
//        } catch (IllegalStateException e2) {
//            Log.e(TAG, "createOutputMediaFileSAF failed with IllegalStateException");
//            e2.printStackTrace();
//            throw new IOException();
//        } catch (NullPointerException e3) {
//            e = e3;
//            Log.e(TAG, "createOutputMediaFileSAF failed with IllegalArgumentException");
//            e.printStackTrace();
//            throw new IOException();
//        } catch (SecurityException e4) {
//            Log.e(TAG, "createOutputMediaFileSAF failed with SecurityException");
//            e4.printStackTrace();
//            throw new IOException();
//        }
//    }

    // only valid if isUsingSAF()
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    Uri createOutputFileSAF(String filename, String mimeType) throws IOException {
        try {
            Uri treeUri = getTreeUriSAF();
            if (MyDebug.LOG)
                Log.d(TAG, "treeUri: " + treeUri);
            Uri docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri));
            if (MyDebug.LOG)
                Log.d(TAG, "docUri: " + docUri);
            // note that DocumentsContract.createDocument will automatically append to the filename if it already exists
            Uri fileUri = DocumentsContract.createDocument(context.getContentResolver(), docUri, mimeType, filename);
            if (MyDebug.LOG)
                Log.d(TAG, "returned fileUri: " + fileUri);
			/*if( true )
				throw new SecurityException(); // test*/
            if (fileUri == null)
                throw new IOException();
            return fileUri;
        } catch (IllegalArgumentException e) {
            // DocumentsContract.getTreeDocumentId throws this if URI is invalid
            if (MyDebug.LOG)
                Log.e(TAG, "createOutputMediaFileSAF failed with IllegalArgumentException");
            e.printStackTrace();
            throw new IOException();
        } catch (IllegalStateException e) {
            // Have reports of this from Google Play for DocumentsContract.createDocument - better to fail gracefully and tell user rather than crash!
            if (MyDebug.LOG)
                Log.e(TAG, "createOutputMediaFileSAF failed with IllegalStateException");
            e.printStackTrace();
            throw new IOException();
        } catch (SecurityException e) {
            // Have reports of this from Google Play - better to fail gracefully and tell user rather than crash!
            if (MyDebug.LOG)
                Log.e(TAG, "createOutputMediaFileSAF failed with SecurityException");
            e.printStackTrace();
            throw new IOException();
        }
    }


    /* JADX INFO: Access modifiers changed from: package-private */
    public String getImageMimeType(String str) {
        str.hashCode();
        char c = 65535;
        switch (str.hashCode()) {
            case 99613:
                if (str.equals("dng")) {
                    c = 0;
                    break;
                }
                break;
            case 111145:
                if (str.equals("png")) {
                    c = 1;
                    break;
                }
                break;
            case 3645340:
                if (str.equals("webp")) {
                    c = 2;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                return "image/dng";
            case 1:
                return "image/png";
            case 2:
                return "image/webp";
            default:
                return "image/jpeg";
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public String getVideoMimeType(String str) {
        str.hashCode();
        return !str.equals("3gp") ? !str.equals("webm") ? "video/mp4" : "video/webm" : "video/3gpp";
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Uri createOutputMediaFileSAF(int i, String str, String str2, Date date) throws IOException {
        String imageMimeType;
        if (i == 1) {
            imageMimeType = getImageMimeType(str2);
        } else if (i == 2) {
            imageMimeType = getVideoMimeType(str2);
        } else if (i != 3 && i != 4) {
            Log.e(TAG, "unknown type: " + i);
            throw new RuntimeException();
        } else {
            imageMimeType = "text/xml";
        }
        return createOutputFileSAF(createMediaFilename(i, str, 0, "." + str2, date), imageMimeType);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class Media {
        final long date;
        final String filename;
        final long id;
        final boolean mediastore;
        final int orientation;
        final Uri uri;
        final boolean video;

        Media(boolean z, long j, boolean z2, Uri uri, long j2, int i, String str) {
            this.mediastore = z;
            this.id = j;
            this.video = z2;
            this.uri = uri;
            this.date = j2;
            this.orientation = i;
            this.filename = str;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public Uri getMediaStoreUri(Context context) {
            if (this.mediastore) {
                return this.uri;
            }
            try {
                if (Build.VERSION.SDK_INT>=29) {
                    return MediaStore.getMediaUri(context, this.uri);
                }
                return null;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
    }

    private static boolean filenameIsRaw(String str) {
        return str.toLowerCase(Locale.US).endsWith(".dng");
    }

    private static String filenameWithoutExtension(String str) {
        String lowerCase = str.toLowerCase(Locale.US);
        return lowerCase.indexOf(".")>0 ? lowerCase.substring(0, lowerCase.lastIndexOf(".")) : lowerCase;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:86:0x031f  */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r1v20, types: [com.live.gpsmap.camera.Camera.StorageUtils$Media, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v24 */
    /* JADX WARN: Type inference failed for: r1v30 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */


    private Media getLatestMediaCore(Uri baseUri, String str, UriType uriType) {
        if (MyDebug.LOG)
            Log.d(TAG, "baseUri: " + baseUri);
        Log.d(TAG, "bucket_id: " + str);
        Log.d(TAG, "uri_type: " + uriType);
//        if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ) {
//            // needed for Android 6, in case users deny storage permission, otherwise we get java.lang.SecurityException from ContentResolver.query()
//            // see https://developer.android.com/training/permissions/requesting.html
//            // we now request storage permission before opening the camera, but keep this here just in case
//            // we restrict check to Android 6 or later just in case, see note in LocationSupplier.setupLocationListener()
//            if( MyDebug.LOG )
//                Log.e(TAG, "don't have READ_EXTERNAL_STORAGE permission");
//            return null;
//        }
        String[] projection;
        boolean z;
        int i = AnonymousClass2.$SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$StorageUtils$UriType[uriType.ordinal()];
        if (i == 1) {
            z = false;
            projection = new String[]{"_id", "datetaken", "_display_name", "orientation"};
        } else {
            z = true;
            projection = new String[]{"_id", "datetaken", "_display_name"};
        }
        String str2;
        String str3;
        String str4 = "";
        int i2 = AnonymousClass2.$SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$StorageUtils$UriType[uriType.ordinal()];
        if (i2 == 1) {
            if (str != null) {
                str4 = "bucket_id = " + str;
            }
            boolean z3 = str4.length() > 0;
            if (z3) {
                str4 = str4 + " AND ( ";
            }
            str4 = str4 + "mime_type='image/jpeg' OR mime_type='image/webp' OR mime_type='image/png' OR mime_type='image/x-adobe-dng'";
            if (z3) {
                str2 = str4 + " )";
                str3 = str2;
            }
            str3 = str4;
        } else if (i2 != 2) {
            throw new RuntimeException("unknown uri_type: " + uriType);
        } else {
            if (str != null) {
                str2 = "bucket_id = " + str;
                str3 = str2;
            }
            str3 = str4;
        }
        Media media = null;
//        baseUri = video ? Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        final int column_id_c = 0;
        final int column_date_taken_c = 1;
        final int column_data_c = 2; // full path and filename, including extension
        final int column_orientation_c = 3; // for images only
        // for images, we need to search for JPEG and RAW, to support RAW only mode (even if we're not currently in that mode, it may be that previously the user did take photos in RAW only mode)
//        String selection = z ? "" : MediaStore.Images.ImageColumns.MIME_TYPE + "='image/jpeg' OR " + MediaStore.Images.ImageColumns.MIME_TYPE + "='image/x-adobe-dng'";
        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(baseUri, projection, str3, null, "datetaken DESC,_id DESC");
            if (cursor != null && cursor.moveToFirst()) {
                if (MyDebug.LOG)
                    Log.d(TAG, "found: " + cursor.getCount());
                // now sorted in order of date - scan to most recent one in the Open Camera save folder
                boolean found = false;
                File save_folder = getImageFolder(); // may be null if using SAF
                String save_folder_string = save_folder == null ? null : save_folder.getAbsolutePath() + File.separator;
                if (MyDebug.LOG)
                    Log.d(TAG, "save_folder_string: " + save_folder_string);
                do {
                    String path = cursor.getString(column_data_c);
                    if (MyDebug.LOG)
                        Log.d(TAG, "path: " + path);
                    if (save_folder_string == null || (path != null && path.contains(save_folder_string))) {
                        if (MyDebug.LOG)
                            Log.d(TAG, "found most recent in Open Camera folder");
                        // we filter files with dates in future, in case there exists an image in the folder with incorrect datestamp set to the future
                        // we allow up to 2 days in future, to avoid risk of issues to do with timezone etc
                        long date = cursor.getLong(column_date_taken_c);
                        long current_time = System.currentTimeMillis();
                        if (date>current_time + 172800000) {
                            if (MyDebug.LOG)
                                Log.d(TAG, "skip date in the future!");
                        } else {
                            found = true;
                            break;
                        }
                    }
                }
                while (cursor.moveToNext());
                if (found) {
                    // make sure we prefer JPEG if there's a JPEG version of this image
                    // this is because we want to support RAW only and JPEG+RAW modes
                    String path = cursor.getString(column_data_c);
                    if (MyDebug.LOG)
                        Log.d(TAG, "path: " + path);
                    // path may be null on Android 4.4, see above!
                    if (path != null && path.toLowerCase(Locale.US).endsWith(".dng")) {
                        if (MyDebug.LOG)
                            Log.d(TAG, "try to find a JPEG version of the DNG");
                        int dng_pos = cursor.getPosition();
                        boolean found_jpeg = false;
                        String path_without_ext = path.toLowerCase(Locale.US);
                        if (path_without_ext.indexOf(".")>0)
                            path_without_ext = path_without_ext.substring(0, path_without_ext.lastIndexOf("."));
                        if (MyDebug.LOG)
                            Log.d(TAG, "path_without_ext: " + path_without_ext);
                        while (cursor.moveToNext()) {
                            String next_path = cursor.getString(column_data_c);
                            if (MyDebug.LOG)
                                Log.d(TAG, "next_path: " + next_path);
                            if (next_path == null)
                                break;
                            String next_path_without_ext = next_path.toLowerCase(Locale.US);
                            if (next_path_without_ext.indexOf(".")>0)
                                next_path_without_ext = next_path_without_ext.substring(0, next_path_without_ext.lastIndexOf("."));
                            if (MyDebug.LOG)
                                Log.d(TAG, "next_path_without_ext: " + next_path_without_ext);
                            if (!path_without_ext.equals(next_path_without_ext))
                                break;
                            // so we've found another file with matching filename - is it a JPEG?
                            if (next_path.toLowerCase(Locale.US).endsWith(".jpg")) {
                                if (MyDebug.LOG)
                                    Log.d(TAG, "found equivalent jpeg");
                                found_jpeg = true;
                                break;
                            }
                        }
                        if (!found_jpeg) {
                            if (MyDebug.LOG)
                                Log.d(TAG, "can't find equivalent jpeg");
                            cursor.moveToPosition(dng_pos);
                        }
                    }
                }
                if (!found) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "can't find suitable in Open Camera folder, so just go with most recent");
                    cursor.moveToFirst();
                }
                long id = cursor.getLong(column_id_c);
                long date = cursor.getLong(column_date_taken_c);
                int orientation = z ? 0 : cursor.getInt(column_orientation_c);
                Uri uri = ContentUris.withAppendedId(baseUri, id);
                String path = cursor.getString(column_data_c);
                if (MyDebug.LOG)
                    Log.d(TAG, "found most recent uri for " + (z ? "video" : "images") + ": " + uri);
                media = new Media(true, id, z, uri, date, orientation, path);
            }
        } catch (Exception e) {
            // have had exceptions such as SQLiteException, NullPointerException reported on Google Play from within getContentResolver().query() call
            if (MyDebug.LOG)
                Log.e(TAG, "Exception trying to find latest media");
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return media;
    }

    public static class AnonymousClass2 {
        static final int[] $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$StorageUtils$UriType;

        static {
            int[] iArr = new int[UriType.values().length];
            $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$StorageUtils$UriType = iArr;
            try {
                iArr[UriType.MEDIASTORE_IMAGES.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$StorageUtils$UriType[UriType.MEDIASTORE_VIDEOS.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }


    private Media getLatestMedia(UriType uriType) {
        Uri uri;
        Log.d(TAG, "getLatestMedia: " + uriType);
        if (!CameraMainActivity.useScopedStorage() && Build.VERSION.SDK_INT>=23 && ContextCompat.checkSelfPermission(this.context, "android.permission.READ_EXTERNAL_STORAGE") != 0) {
            Log.e(TAG, "don't have READ_EXTERNAL_STORAGE permission");
            return null;
        }
        String imageFolderPath = getImageFolderPath();
        Log.d(TAG, "save_folder: " + imageFolderPath);
        String valueOf = imageFolderPath != null ? String.valueOf(imageFolderPath.toLowerCase().hashCode()) : null;
        Log.d(TAG, "bucket_id: " + valueOf);
        int i = AnonymousClass2.$SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$StorageUtils$UriType[uriType.ordinal()];
        if (i == 1) {
            uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        } else if (i == 2) {
            uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        } else {
            throw new RuntimeException("unknown uri_type: " + uriType);
        }
        Log.d(TAG, "baseUri: " + uri);
        Media latestMediaCore = getLatestMediaCore(uri, valueOf, uriType);
        if (latestMediaCore == null && valueOf != null) {
            Log.d(TAG, "fall back to checking any folder");
            latestMediaCore = getLatestMediaCore(uri, null, uriType);
        }
        PrintStream printStream = System.out;
        printStream.println("Media        " + latestMediaCore);
        return latestMediaCore;
    }

    public Media getLatestMedia() {
        if (CameraMainActivity.useScopedStorage() && isUsingSAF()) {
//            return getLatestMediaSAF(getTreeUriSAF());
        }
        Media latestMedia = getLatestMedia(UriType.MEDIASTORE_IMAGES);
        Media latestMedia2 = getLatestMedia(UriType.MEDIASTORE_VIDEOS);
        if (latestMedia == null || latestMedia2 != null) {
            if (latestMedia == null && latestMedia2 != null) {
                Log.d(TAG, "only found videos");
            } else if (latestMedia == null || latestMedia2 == null) {
                latestMedia = null;
            } else {
                Log.d(TAG, "found images and videos");
                Log.d(TAG, "latest image date: " + latestMedia.date);
                Log.d(TAG, "latest video date: " + latestMedia2.date);
                if (latestMedia.date>=latestMedia2.date) {
                    Log.d(TAG, "latest image is newer");
                } else {
                    Log.d(TAG, "latest video is newer");
                }
            }
            latestMedia = latestMedia2;
        } else {
            Log.d(TAG, "only found images");
        }
        Log.d(TAG, "return latest media: " + latestMedia);
        return latestMedia;
    }

    private long freeMemorySAF() {
        Uri treeUriSAF = this.applicationInterface.getStorageUtils().getTreeUriSAF();
        Log.d(TAG, "treeUri: " + treeUriSAF);
        ParcelFileDescriptor parcelFileDescriptor = null;
        try {
            try {
                try {
                    try {
                        try {
                            Uri buildDocumentUriUsingTree = DocumentsContract.buildDocumentUriUsingTree(treeUriSAF, DocumentsContract.getTreeDocumentId(treeUriSAF));
                            Log.d(TAG, "docUri: " + buildDocumentUriUsingTree);
                            ParcelFileDescriptor openFileDescriptor = this.context.getContentResolver().openFileDescriptor(buildDocumentUriUsingTree, "r");
                            if (openFileDescriptor == null) {
                                Log.e(TAG, "pfd is null!");
                                throw new FileNotFoundException();
                            }
                            Log.d(TAG, "read direct from SAF uri");
                            StructStatVfs fstatvfs = Os.fstatvfs(openFileDescriptor.getFileDescriptor());
                            long j = (fstatvfs.f_bavail * fstatvfs.f_bsize) / PlaybackStateCompat.ACTION_SET_CAPTIONING_ENABLED;
                            if (openFileDescriptor != null) {
                                try {
                                    openFileDescriptor.close();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                            return j;
                        } catch (Exception e2) {
                            e2.printStackTrace();
                            if (0 != 0) {
                                parcelFileDescriptor.close();
                                return -1L;
                            }
                            return -1L;
                        }
                    } catch (FileNotFoundException e3) {
                        e3.printStackTrace();
                        if (0 != 0) {
                            parcelFileDescriptor.close();
                            return -1L;
                        }
                        return -1L;
                    }
                } catch (IllegalArgumentException e4) {
                    e4.printStackTrace();
                    if (0 != 0) {
                        parcelFileDescriptor.close();
                        return -1L;
                    }
                    return -1L;
                }
            } catch (IOException e5) {
                e5.printStackTrace();
                return -1L;
            }
        } catch (Throwable th) {
            if (0 != 0) {
                try {
                    parcelFileDescriptor.close();
                } catch (IOException e6) {
                    e6.printStackTrace();
                }
            }
            throw th;
        }
    }

    public long freeMemory() {
        long availableBlocks;
        long blockSize;
        long availableBlocks2;
        long blockSize2;
        Log.d(TAG, "freeMemory");
        if (this.applicationInterface.getStorageUtils().isUsingSAF() && Build.VERSION.SDK_INT>=21) {
            return freeMemorySAF();
        }
        try {
            try {
                File imageFolder = getImageFolder();
                if (imageFolder == null) {
                    throw new IllegalArgumentException();
                }
                StatFs statFs = new StatFs(imageFolder.getAbsolutePath());
                if (Build.VERSION.SDK_INT>=18) {
                    availableBlocks2 = statFs.getAvailableBlocksLong();
                    blockSize2 = statFs.getBlockSizeLong();
                } else {
                    availableBlocks2 = statFs.getAvailableBlocks();
                    blockSize2 = statFs.getBlockSize();
                }
                return (availableBlocks2 * blockSize2) / PlaybackStateCompat.ACTION_SET_CAPTIONING_ENABLED;
            } catch (IllegalArgumentException unused) {
                return -1L;
            }
        } catch (IllegalArgumentException unused2) {
            if (isUsingSAF() || saveFolderIsFull(getSaveLocation())) {
                return -1L;
            }
            StatFs statFs2 = new StatFs(getBaseFolder().getAbsolutePath());
            if (Build.VERSION.SDK_INT>=18) {
                availableBlocks = statFs2.getAvailableBlocksLong();
                blockSize = statFs2.getBlockSizeLong();
            } else {
                availableBlocks = statFs2.getAvailableBlocks();
                blockSize = statFs2.getBlockSize();
            }
            return (availableBlocks * blockSize) / PlaybackStateCompat.ACTION_SET_CAPTIONING_ENABLED;
        }
    }
}
