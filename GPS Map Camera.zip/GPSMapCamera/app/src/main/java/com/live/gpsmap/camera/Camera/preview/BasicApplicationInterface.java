package com.live.gpsmap.camera.Camera.preview;

import android.app.Activity;
import android.graphics.Canvas;
import android.location.Location;
import android.net.Uri;
import android.util.Pair;
import android.view.MotionEvent;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraController;
import com.live.gpsmap.camera.Camera.cameracontroller.RawImage;
import com.live.gpsmap.camera.Camera.preview.ApplicationInterface;
import java.util.Date;
import java.util.List;


public abstract class BasicApplicationInterface implements ApplicationInterface {
    @Override
    public boolean allowZoom() {
        return true;
    }

    @Override
    public void cameraClosed() {
    }

    @Override
    public void cameraInOperation(boolean z, boolean z2) {
    }

    @Override
    public void cameraSetup() {
    }

    @Override
    public boolean canTakeNewPhoto() {
        return true;
    }

    @Override
    public void clearColorEffectPref() {
    }

    @Override
    public void clearExposureCompensationPref() {
    }

    @Override
    public void clearExposureTimePref() {
    }

    @Override
    public void clearISOPref() {
    }

    @Override
    public void clearSceneModePref() {
    }

    @Override
    public void clearWhiteBalancePref() {
    }

    @Override
    public void deleteUnusedVideo(ApplicationInterface.VideoMethod videoMethod, Uri uri, String str) {
    }

    @Override
    public String getAntiBandingPref() {
        return "auto";
    }

    @Override
    public float getAperturePref() {
        return -1.0f;
    }

    @Override
    public boolean getBurstForNoiseReduction() {
        return false;
    }

    @Override
    public int getBurstNImages() {
        return 5;
    }

    @Override
    public double getCalibratedLevelAngle() {
        return 0.0d;
    }

    @Override
    public int getCameraExtensionPref() {
        return 0;
    }

    @Override
    public int getCameraIdPref() {
        return 0;
    }

    @Override
    public String getCameraNoiseReductionModePref() {
        return "default";
    }

    @Override
    public Pair<Integer, Integer> getCameraResolutionPref(ApplicationInterface.CameraResolutionConstraints cameraResolutionConstraints) {
        return null;
    }

    @Override
    public String getColorEffectPref() {
        return "none";
    }

    @Override
    public boolean getDoubleTapCapturePref() {
        return false;
    }

    @Override
    public String getEdgeModePref() {
        return "default";
    }

    @Override
    public int getExpoBracketingNImagesPref() {
        return 3;
    }

    @Override
    public double getExpoBracketingStopsPref() {
        return 2.0d;
    }

    @Override
    public int getExposureCompensationPref() {
        return 0;
    }

    @Override
    public long getExposureTimePref() {
        return CameraController.EXPOSURE_TIME_DEFAULT;
    }

    @Override
    public boolean getFaceDetectionPref() {
        return false;
    }

    @Override
    public String getFlashPref() {
        return "flash_off";
    }

    @Override
    public boolean getFocusBracketingAddInfinityPref() {
        return false;
    }

    @Override
    public int getFocusBracketingNImagesPref() {
        return 3;
    }

    @Override
    public float getFocusDistancePref(boolean z) {
        return 0.0f;
    }

    @Override
    public String getFocusPref(boolean z) {
        return "focus_mode_continuous_picture";
    }

    @Override
    public boolean getForce4KPref() {
        return false;
    }

    @Override
    public boolean getGeotaggingPref() {
        return false;
    }

    @Override
    public String getISOPref() {
        return "auto";
    }

    @Override
    public int getImageQualityPref() {
        return 90;
    }

    @Override
    public Location getLocation() {
        return null;
    }

    @Override
    public String getLockOrientationPref() {
        return "none";
    }

    @Override
    public int getMaxRawImages() {
        return 2;
    }

    @Override
    public boolean getPausePreviewPref() {
        return false;
    }

    @Override
    public String getPreviewSizePref() {
        return "preference_preview_size_wysiwyg";
    }

    @Override
    public String getRecordAudioChannelsPref() {
        return "audio_default";
    }

    @Override
    public boolean getRecordAudioPref() {
        return true;
    }

    @Override
    public String getRecordAudioSourcePref() {
        return "audio_src_camcorder";
    }

    @Override
    public String getRecordVideoOutputFormatPref() {
        return "preference_video_output_format_default";
    }

    @Override
    public long getRepeatIntervalPref() {
        return 0L;
    }

    @Override
    public String getRepeatPref() {
        return "1";
    }

    @Override
    public boolean getRequireLocationPref() {
        return false;
    }

    @Override
    public String getSceneModePref() {
        return "auto";
    }

    @Override
    public boolean getShowToastsPref() {
        return true;
    }

    @Override
    public boolean getShutterSoundPref() {
        return false;
    }

    @Override
    public boolean getStartupFocusPref() {
        return true;
    }

    @Override
    public long getTimerPref() {
        return 0L;
    }

    @Override
    public boolean getTouchCapturePref() {
        return false;
    }

    @Override
    public String getVideoBitratePref() {
        return "default";
    }

    @Override
    public float getVideoCaptureRateFactor() {
        return 1.0f;
    }

    @Override
    public String getVideoFPSPref() {
        return "default";
    }

    @Override
    public boolean getVideoFlashPref() {
        return false;
    }

    @Override
    public float getVideoLogProfileStrength() {
        return 0.0f;
    }

    @Override
    public boolean getVideoLowPowerCheckPref() {
        return true;
    }

    @Override
    public long getVideoMaxDurationPref() {
        return 0L;
    }

    @Override
    public float getVideoProfileGamma() {
        return 0.0f;
    }

    @Override
    public String getVideoQualityPref() {
        return "";
    }

    @Override
    public int getVideoRestartTimesPref() {
        return 0;
    }

    @Override
    public boolean getVideoStabilizationPref() {
        return false;
    }

    @Override
    public String getWhiteBalancePref() {
        return "auto";
    }

    @Override
    public int getWhiteBalanceTemperaturePref() {
        return 0;
    }

    @Override
    public int getZoomPref() {
        return -1;
    }

    @Override
    public void hasPausedPreview(boolean z) {
    }

    @Override
    public boolean imageQueueWouldBlock(int i, int i2) {
        return false;
    }

    @Override
    public boolean isCameraBurstPref() {
        return false;
    }

    @Override
    public boolean isCameraExtensionPref() {
        return false;
    }

    @Override
    public boolean isExpoBracketingPref() {
        return false;
    }

    @Override
    public boolean isFocusBracketingPref() {
        return false;
    }

    @Override
    public boolean isPreviewInBackground() {
        return false;
    }

    @Override
    public boolean isTestAlwaysFocus() {
        return false;
    }

    @Override
    public boolean isVideoPref() {
        return false;
    }

    @Override
    public void multitouchZoom(int i) {
    }

    @Override
    public boolean onBurstPictureTaken(List<byte[]> list, Date date) {
        return false;
    }

    @Override
    public void onCameraError() {
    }

    @Override
    public void onCaptureStarted() {
    }

    @Override
    public void onContinuousFocusMove(boolean z) {
    }

    @Override
    public void onDrawPreview(Canvas canvas) {
    }

    @Override
    public void onFailedCreateVideoFileError() {
    }

    @Override
    public void onFailedReconnectError() {
    }

    @Override
    public void onFailedStartPreview() {
    }

    @Override
    public void onPhotoError() {
    }

    @Override
    public void onPictureCompleted() {
    }

    @Override
    public boolean onRawBurstPictureTaken(List<RawImage> list, Date date) {
        return false;
    }

    @Override
    public boolean onRawPictureTaken(RawImage rawImage, Date date) {
        return false;
    }

    @Override
    public void onVideoError(int i, int i2) {
    }

    @Override
    public void onVideoInfo(int i, int i2) {
    }

    @Override
    public void onVideoRecordStartError(VideoProfile videoProfile) {
    }

    @Override
    public void onVideoRecordStopError(VideoProfile videoProfile) {
    }

    @Override
    public void requestTakePhoto() {
    }

    @Override
    public void restartedVideo(ApplicationInterface.VideoMethod videoMethod, Uri uri, String str) {
    }

    @Override
    public void setCameraIdPref(int i) {
    }

    @Override
    public void setCameraResolutionPref(int i, int i2) {
    }

    @Override
    public void setColorEffectPref(String str) {
    }

    @Override
    public void setExposureCompensationPref(int i) {
    }

    @Override
    public void setExposureTimePref(long j) {
    }

    @Override
    public void setFlashPref(String str) {
    }

    @Override
    public void setFocusDistancePref(float f, boolean z) {
    }

    @Override
    public void setFocusPref(String str, boolean z) {
    }

    @Override
    public void setISOPref(String str) {
    }

    @Override
    public void setSceneModePref(String str) {
    }

    @Override
    public void setVideoPref(boolean z) {
    }

    @Override
    public void setVideoQualityPref(String str) {
    }

    @Override
    public void setWhiteBalancePref(String str) {
    }

    @Override
    public void setWhiteBalanceTemperaturePref(int i) {
    }

    @Override
    public void setZoomPref(int i) {
    }

    @Override
    public void startedVideo() {
    }

    @Override
    public void startingVideo() {
    }

    @Override
    public void stoppedVideo(int videoMethod, Uri uri, String str) {
    }

    @Override
    public void stoppingVideo() {
    }

    @Override
    public void timerBeep(long j) {
    }

    @Override
    public void touchEvent(MotionEvent motionEvent) {
    }

    @Override
    public void turnFrontScreenFlashOn() {
    }

    @Override
    public boolean useCamera2DummyCaptureHack() {
        return false;
    }

    @Override
    public boolean useCamera2FakeFlash() {
        return false;
    }

    @Override
    public boolean useCamera2FastBurst() {
        return true;
    }

    @Override
    public boolean usePhotoVideoRecording() {
        return true;
    }

    @Override
    public CameraController.TonemapProfile getVideoTonemapProfile() {
        return CameraController.TonemapProfile.TONEMAPPROFILE_OFF;
    }

    @Override
    public ApplicationInterface.VideoMaxFileSize getVideoMaxFileSizePref() throws ApplicationInterface.NoFreeStorageException {
        ApplicationInterface.VideoMaxFileSize videoMaxFileSize = new ApplicationInterface.VideoMaxFileSize();
        videoMaxFileSize.max_filesize = 0L;
        videoMaxFileSize.auto_restart = true;
        return videoMaxFileSize;
    }

    @Override
    public int getDisplayRotation() {
        return ((Activity) getContext()).getWindowManager().getDefaultDisplay().getRotation();
    }

    @Override
    public ApplicationInterface.NRModePref getNRModePref() {
        return ApplicationInterface.NRModePref.NRMODE_NORMAL;
    }

    @Override
    public ApplicationInterface.RawPref getRawPref() {
        return ApplicationInterface.RawPref.RAWPREF_JPEG_ONLY;
    }
}
