package com.live.gpsmap.camera.Camera.preview.camerasurface;

import android.content.Context;
import android.graphics.Matrix;
import android.media.MediaRecorder;
import android.util.Log;
import android.view.MotionEvent;
import android.view.TextureView;
import android.view.View;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraController;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraControllerException;
import com.live.gpsmap.camera.Camera.preview.Preview;

/* loaded from: classes3.dex */
public class MyTextureView extends TextureView implements CameraSurface {
    private static final String TAG = "MyTextureView";
    private final int[] measure_spec;
    private final Preview preview;

    @Override
    public View getView() {
        return this;
    }

    @Override
    public void onPause() {
    }

    @Override
    public void onResume() {
    }

    @Override
    public void setVideoRecorder(MediaRecorder mediaRecorder) {
    }

    public MyTextureView(Context context, Preview preview) {
        super(context);
        this.measure_spec = new int[2];
        this.preview = preview;
        Log.d(TAG, "new MyTextureView");
        setSurfaceTextureListener(preview);
    }

    @Override
    public void setPreviewDisplay(CameraController cameraController) {
        Log.d(TAG, "setPreviewDisplay");
        try {
            cameraController.setPreviewTexture(this);
        } catch (CameraControllerException e) {
            Log.e(TAG, "Failed to set preview display: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {
        return this.preview.touchEvent(motionEvent);
    }

    @Override
    protected void onMeasure(int i, int i2) {
        Log.d(TAG, "onMeasure: " + i + " x " + i2);
        this.preview.getMeasureSpec(this.measure_spec, i, i2);
        int[] iArr = this.measure_spec;
        super.onMeasure(iArr[0], iArr[1]);
    }

    @Override
    public void setTransform(Matrix matrix) {
        super.setTransform(matrix);
    }
}
