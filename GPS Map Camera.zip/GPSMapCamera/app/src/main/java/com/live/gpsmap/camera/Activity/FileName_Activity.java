package com.live.gpsmap.camera.Activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.snackbar.Snackbar;
import com.live.gpsmap.camera.Camera.utils.NetworkState;
import com.live.gpsmap.camera.Model.ViewModel;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Default;
import com.live.gpsmap.camera.Utils.Helper.SingleClickListener;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.Utils.Util;
import com.live.gpsmap.camera.Widget.DragLinearLayout;

import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

@SuppressWarnings("All")
public class FileName_Activity extends AppCompatActivity implements View.OnClickListener, CompoundButton.OnCheckedChangeListener, View.OnFocusChangeListener {
    private boolean IS_ADS;
    String ads_status;
    int appCount;
    CheckBox chk_24_hr;
    CheckBox chk_Week;
    CheckBox chk_cus_1;
    CheckBox chk_cus_2;
    CheckBox chk_cus_3;
    CheckBox chk_decimal;
    CheckBox chk_dms;
    CheckBox chk_dt;
    CheckBox chk_hr_min;
    CheckBox chk_line_1;
    CheckBox chk_line_2;
    CheckBox chk_line_3;
    CheckBox chk_line_4;
    CheckBox chk_main_address;
    CheckBox chk_main_date_time;
    CheckBox chk_main_latlng;
    CheckBox chk_s_n;
    DragLinearLayout dragLinearLayout;
    ImageView img_drag_cus_1;
    boolean is_pro;
    LinearLayout li_child_address;
    LinearLayout li_child_cus_1;
    LinearLayout li_child_cus_2;
    LinearLayout li_child_cus_3;
    LinearLayout li_child_dt;
    LinearLayout li_child_lat_lng;
    LinearLayout li_child_sequence;
    EditText mEd_cus_1;
    EditText mEd_cus_2;
    EditText mEd_cus_3;
    EditText mEd_sequence;
    private Util mHelperClass;
    RelativeLayout mRel_add_address;
    RelativeLayout mRel_custom_1;
    RelativeLayout mRel_custom_2;
    RelativeLayout mRel_custom_3;
    RelativeLayout mRel_datetime;
    RelativeLayout mRel_lat_lng;
    RelativeLayout mRel_sequence_num;
    SP mSP;
    private RelativeLayout mToolbar_back;
    TextView mTv_click_address;
    TextView mTv_click_cus_1;
    TextView mTv_click_cus_2;
    TextView mTv_click_cus_3;
    TextView mTv_click_dt;
    TextView mTv_click_latlng;
    TextView mTv_click_sn;
    TextView mTv_filename;
    private RelativeLayout main_real;
    private TextView mtv_toolbar_title;
    RelativeLayout rel_inapp_address;
    RelativeLayout rel_inapp_cus_1;
    RelativeLayout rel_inapp_cus_2;
    RelativeLayout rel_inapp_cus_3;
    RelativeLayout rel_inapp_lat_lng;
    ArrayList<Integer> child_layList = new ArrayList<>();
    ArrayList<Integer> drop_down_List = new ArrayList<>();
    ArrayList<ViewModel> list_item = new ArrayList<>();


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Util Util = new Util();
        this.mHelperClass = new Util();
        com.live.gpsmap.camera.Utils.Util.SetLanguage(this);
        setContentView(R.layout.activity_file_name);
        init();
        loadAds();
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
    }

    private ArrayList<ViewModel> callTextViewData() {
        String str;
        String str2;
        String str3;
        String str4;
        String str5;
        String str6;
        ArrayList<ViewModel> arrayList = new ArrayList<>();
        ViewModel viewModel = new ViewModel();
        String str7 = "";
        if (this.chk_main_date_time.isChecked()) {
            str = getDateValue();
            viewModel.setSelected(true);
            if (this.chk_Week.isChecked()) {
                str = getDateValue();
                viewModel.setSelected(true);
            }
            if (this.chk_24_hr.isChecked()) {
                str = getDateValue();
                viewModel.setSelected(true);
            }
        } else {
            viewModel.setSelected(true);
            str = "";
        }
        viewModel.setId(R.id.rel_main_datetime);
        viewModel.setValue(str);
        viewModel.setTag(Default.DATETIME);
        arrayList.add(get_date_time_index(), viewModel);
        ViewModel viewModel2 = new ViewModel();
        if (this.chk_s_n.isChecked()) {
            str2 = getSequence_EdittextValue();
            viewModel2.setSelected(true);
        } else {
            viewModel2.setSelected(false);
            str2 = "";
        }
        viewModel2.setId(R.id.rel_sequence_num);
        viewModel2.setValue(str2);
        viewModel2.setTag(Default.SEQUENCE);
        arrayList.add(get_sequence_index(), viewModel2);
        ViewModel viewModel3 = new ViewModel();
        if (this.chk_cus_1.isChecked()) {
            str3 = getCustom_1_EditTextValue();
            viewModel3.setSelected(true);
        } else {
            viewModel3.setSelected(false);
            str3 = "";
        }
        viewModel3.setId(R.id.rel_custom_1);
        viewModel3.setValue(str3);
        viewModel3.setTag(Default.CUSTOM1);
        arrayList.add(get_custom1_index(), viewModel3);
        ViewModel viewModel4 = new ViewModel();
        if (this.chk_cus_2.isChecked()) {
            str4 = getCustom_2_EditTextValue();
            viewModel4.setSelected(true);
        } else {
            viewModel4.setSelected(false);
            str4 = "";
        }
        viewModel4.setId(R.id.rel_custom_2);
        viewModel4.setValue(str4);
        viewModel4.setTag(Default.CUSTOM2);
        arrayList.add(get_custom2_index(), viewModel4);
        ViewModel viewModel5 = new ViewModel();
        if (this.chk_cus_3.isChecked()) {
            str5 = getCustom_3_EditTextValue();
            viewModel5.setSelected(true);
        } else {
            viewModel5.setSelected(false);
            str5 = "";
        }
        viewModel5.setId(R.id.rel_custom_3);
        viewModel5.setValue(str5);
        viewModel5.setTag(Default.CUSTOM3);
        arrayList.add(get_custom3_index(), viewModel5);
        ViewModel viewModel6 = new ViewModel();
        if (this.chk_main_address.isChecked()) {
            if (this.chk_line_1.isChecked()) {
                viewModel6.setSelected(true);
            }
            if (this.chk_line_2.isChecked()) {
                viewModel6.setSelected(true);
            }
            if (this.chk_line_3.isChecked()) {
                viewModel6.setSelected(true);
            }
            if (this.chk_line_4.isChecked()) {
                viewModel6.setSelected(true);
            }
            str6 = getAddress();
        } else {
            viewModel6.setSelected(false);
            str6 = "";
        }
        viewModel6.setId(R.id.rel_add_address);
        viewModel6.setValue(str6);
        viewModel6.setTag(Default.ADDRESS);
        arrayList.add(get_address_index(), viewModel6);
        ViewModel viewModel7 = new ViewModel();
        if (this.chk_main_latlng.isChecked()) {
            if (this.chk_decimal.isChecked()) {
                str7 = getLatLong();
                viewModel7.setSelected(true);
            }
            if (this.chk_dms.isChecked()) {
                str7 = str7 + "_" + getLatLong();
                viewModel7.setSelected(true);
            }
        } else {
            viewModel7.setSelected(false);
        }
        viewModel7.setId(R.id.rel_lat_lng);
        viewModel7.setValue(str7);
        viewModel7.setTag(Default.LATLONG);
        arrayList.add(get_lat_long_index(), viewModel7);
        return arrayList;
    }

    private String getLatLong() {
        String str = "";
        if (this.chk_decimal.isChecked()) {
            str = "_" + this.mSP.getString(this, SP.LATITUDE, "") + "_" + this.mSP.getString(this, SP.LONGITUDE, "");
        }
        if (this.chk_dms.isChecked()) {
            return str + "_" + this.mHelperClass.dms_latlng(this);
        }
        return str;
    }

    private String getAddress() {
        String str;
        String line_1_address = getLine_1_address();
        if (this.chk_line_1.isChecked() && isNotEmpty(line_1_address)) {
            str = "_" + line_1_address;
        } else {
            str = "";
        }
        String line_2_address = getLine_2_address();
        if (this.chk_line_2.isChecked() && isNotEmpty(line_2_address)) {
            str = str + "_" + line_2_address;
        }
        String line_3_address = getLine_3_address();
        if (this.chk_line_3.isChecked() && isNotEmpty(line_3_address)) {
            str = str + "_" + line_3_address;
        }
        String line_4_address = getLine_4_address();
        if (this.chk_line_4.isChecked() && isNotEmpty(line_4_address)) {
            str = str + "_" + line_4_address;
        }
        return isNotEmpty(str) ? str : "";
    }

    private String getLine_4_address() {
        return this.mSP.getString(this, SP.LOC_LINE_4_COUNTRY, "");
    }

    private String getLine_3_address() {
        return this.mSP.getString(this, SP.LOC_LINE_3_STATE, "");
    }

    private String getLine_2_address() {
        return this.mSP.getString(this, SP.LOC_LINE_2_CITY, "");
    }

    private String getLine_1_address() {
        return this.mSP.getString(this, SP.LOC_LINE_1_ADDRESS, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String getCustom_3_EditTextValue() {
        return this.mEd_cus_3.getText().toString();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String getCustom_2_EditTextValue() {
        return this.mEd_cus_2.getText().toString();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String getCustom_1_EditTextValue() {
        return this.mEd_cus_1.getText().toString().trim();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String getSequence_EdittextValue() {
        return this.mEd_sequence.getText().toString().trim();
    }

    private String getDateValue() {
        String trim;
        if (this.chk_24_hr.isChecked()) {
            trim = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()).trim();
        } else {
            trim = new SimpleDateFormat("yyyyMMdd_hmmssa").format(new Date()).trim();
        }
        if (this.chk_Week.isChecked()) {
            return trim + "_" + getWeek();
        }
        return trim;
    }

    private String getWeek() {
        return new SimpleDateFormat("EEEE").format(new Date());
    }

    private void addExistingNote(int i, View view) {
        setNoteIndex(view, i);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setNoteIndex(View view, int i) {
        view.setTag(Integer.valueOf(i));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getNoteIndex(View view) {
        Object tag = view.getTag();
        if (tag == null) {
            return -1;
        }
        return ((Integer) tag).intValue();
    }

    private void loadAds() {
//        new Admob().loadAdaptive_banner(this, (RelativeLayout) findViewById(R.id.rel_adaptive_banner), getString(R.string.GMC_Banner_Details));
    }

    private void init() {
        SP sp = new SP(this);
        this.mSP = sp;
        this.appCount = sp.getInteger(this, SP.APP_COUNT, 0);
        this.mSP.setInteger(this, "FILE_NAME_OPEN_TIME", this.mSP.getInteger(this, "FILE_NAME_OPEN_TIME", 0) + 1);
        int i = this.appCount;
        if (i <= 3) {
            int i2 = i + 1;
            this.appCount = i2;
            this.mSP.setInteger(this, SP.APP_COUNT, i2);
        }
        this.ads_status = new SP(this).getString(this, SP.ADS_STATUS, "1");
        this.IS_ADS = new SP(this).getBoolean(this, "IS_PURCHESH_OR_NOT", false);
        this.mToolbar_back = (RelativeLayout) findViewById(R.id.toolbar_back);
        TextView textView = (TextView) findViewById(R.id.tv_toolbar_title);
        this.mtv_toolbar_title = textView;
        textView.setText(getString(R.string.file_name));
        this.dragLinearLayout = (DragLinearLayout) findViewById(R.id.container);
        this.main_real = (RelativeLayout) findViewById(R.id.main_real);
        this.mRel_datetime = (RelativeLayout) findViewById(R.id.rel_main_datetime);
        this.mRel_sequence_num = (RelativeLayout) findViewById(R.id.rel_sequence_num);
        this.mRel_custom_1 = (RelativeLayout) findViewById(R.id.rel_custom_1);
        this.mRel_custom_2 = (RelativeLayout) findViewById(R.id.rel_custom_2);
        this.mRel_custom_3 = (RelativeLayout) findViewById(R.id.rel_custom_3);
        this.mRel_add_address = (RelativeLayout) findViewById(R.id.rel_add_address);
        this.mRel_lat_lng = (RelativeLayout) findViewById(R.id.rel_lat_lng);
        this.child_layList.add(Integer.valueOf((int) R.id.li_child_dt));
        this.child_layList.add(Integer.valueOf((int) R.id.li_child_sequence));
        this.child_layList.add(Integer.valueOf((int) R.id.li_child_cus_1));
        this.child_layList.add(Integer.valueOf((int) R.id.li_child_cus_2));
        this.child_layList.add(Integer.valueOf((int) R.id.li_child_cus_3));
        this.child_layList.add(Integer.valueOf((int) R.id.li_child_address));
        this.child_layList.add(Integer.valueOf((int) R.id.li_child_lat_lng));
        this.drop_down_List.add(Integer.valueOf((int) R.id.tv_click_dt));
        this.drop_down_List.add(Integer.valueOf((int) R.id.tv_click_sn));
        this.drop_down_List.add(Integer.valueOf((int) R.id.tv_click_cus_1));
        this.drop_down_List.add(Integer.valueOf((int) R.id.tv_click_cus_2));
        this.drop_down_List.add(Integer.valueOf((int) R.id.tv_click_cus_3));
        this.drop_down_List.add(Integer.valueOf((int) R.id.tv_click_address));
        this.drop_down_List.add(Integer.valueOf((int) R.id.tv_click_latlng));
        this.li_child_dt = (LinearLayout) findViewById(R.id.li_child_dt);
        this.li_child_sequence = (LinearLayout) findViewById(R.id.li_child_sequence);
        this.li_child_cus_1 = (LinearLayout) findViewById(R.id.li_child_cus_1);
        this.li_child_cus_2 = (LinearLayout) findViewById(R.id.li_child_cus_2);
        this.li_child_cus_3 = (LinearLayout) findViewById(R.id.li_child_cus_3);
        this.li_child_address = (LinearLayout) findViewById(R.id.li_child_address);
        this.li_child_lat_lng = (LinearLayout) findViewById(R.id.li_child_lat_lng);
        this.mTv_click_dt = (TextView) findViewById(R.id.tv_click_dt);
        this.mTv_click_sn = (TextView) findViewById(R.id.tv_click_sn);
        this.mTv_click_cus_1 = (TextView) findViewById(R.id.tv_click_cus_1);
        this.mTv_click_cus_2 = (TextView) findViewById(R.id.tv_click_cus_2);
        this.mTv_click_cus_3 = (TextView) findViewById(R.id.tv_click_cus_3);
        this.mTv_click_address = (TextView) findViewById(R.id.tv_click_address);
        this.mTv_click_latlng = (TextView) findViewById(R.id.tv_click_latlng);
        this.chk_main_date_time = (CheckBox) findViewById(R.id.chk_main_date_time);
        this.chk_dt = (CheckBox) findViewById(R.id.chk_dt);
        this.chk_Week = (CheckBox) findViewById(R.id.chk_Week);
        this.chk_hr_min = (CheckBox) findViewById(R.id.chk_hr_min);
        this.chk_24_hr = (CheckBox) findViewById(R.id.chk_24_hr);
        this.chk_s_n = (CheckBox) findViewById(R.id.chk_s_n);
        this.chk_cus_1 = (CheckBox) findViewById(R.id.chk_cus_1);
        this.chk_cus_2 = (CheckBox) findViewById(R.id.chk_cus_2);
        this.chk_cus_3 = (CheckBox) findViewById(R.id.chk_cus_3);
        this.chk_main_address = (CheckBox) findViewById(R.id.chk_main_address);
        this.chk_main_latlng = (CheckBox) findViewById(R.id.chk_main_latlng);
        this.chk_main_latlng = (CheckBox) findViewById(R.id.chk_main_latlng);
        this.chk_decimal = (CheckBox) findViewById(R.id.chk_decimal);
        this.chk_dms = (CheckBox) findViewById(R.id.chk_dms);
        this.chk_line_1 = (CheckBox) findViewById(R.id.chk_line_1);
        this.chk_line_2 = (CheckBox) findViewById(R.id.chk_line_2);
        this.chk_line_3 = (CheckBox) findViewById(R.id.chk_line_3);
        this.chk_line_4 = (CheckBox) findViewById(R.id.chk_line_4);
        this.img_drag_cus_1 = (ImageView) findViewById(R.id.img_drag_cus_1);
        TextView textView2 = (TextView) findViewById(R.id.tv_filename);
        this.mTv_filename = textView2;
        textView2.setMovementMethod(new ScrollingMovementMethod());
        this.mEd_sequence = (EditText) findViewById(R.id.ed_sequence);
        this.mEd_cus_1 = (EditText) findViewById(R.id.ed_cus_1);
        this.mEd_cus_2 = (EditText) findViewById(R.id.ed_cus_2);
        this.mEd_cus_3 = (EditText) findViewById(R.id.ed_cus_3);
        this.rel_inapp_cus_1 = (RelativeLayout) findViewById(R.id.rel_inapp_cus_1);
        this.rel_inapp_cus_2 = (RelativeLayout) findViewById(R.id.rel_inapp_cus_2);
        this.rel_inapp_cus_3 = (RelativeLayout) findViewById(R.id.rel_inapp_cus_3);
        this.rel_inapp_address = (RelativeLayout) findViewById(R.id.rel_inapp_address);
        this.rel_inapp_lat_lng = (RelativeLayout) findViewById(R.id.rel_inapp_lat_lng);
        boolean z = this.mSP.getBoolean(this, SP.FIRSTFILENAME, true);
        this.is_pro = this.mSP.getBoolean(this, "IS_PURCHESH_OR_NOT", false) || this.mSP.getBoolean(this, "is_use_all_function", false);
        PrintStream printStream = System.out;
        printStream.println("FirstTime         " + z);
        if (!z) {
            ArrayList<ViewModel> arrayList = this.mSP.getArrayList(this);
            this.list_item = arrayList;
            if (arrayList != null) {
                newViews();
            }
        } else {
            this.mSP.setBoolean(this, SP.FIRSTFILENAME, false);
            this.list_item = null;
        }
        setRecyclerView();
        setData();
        PrintStream printStream2 = System.out;
        printStream2.println("FirstTime          " + this.list_item);
        if (this.list_item == null) {
            this.list_item = new ArrayList<>();
            this.list_item = callTextViewData();
        }
        setUpEditText();
        if (this.appCount == 1) {
            showToolTip();
        }
        onClicks();
    }

    private void showToolTip() {
        if (isFinishing()) {
            return;
        }
        new Handler().postDelayed(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FileName_Activity.1
            @Override // java.lang.Runnable
            public void run() {
                View inflate = View.inflate(FileName_Activity.this, R.layout.tooltip_lay, null);
                final PopupWindow popupWindow = new PopupWindow(inflate, -2, -2, true);
                popupWindow.setOutsideTouchable(false);
                ((RelativeLayout) inflate.findViewById(R.id.tooltip_close)).setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FileName_Activity.1.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        PopupWindow popupWindow2 = popupWindow;
                        if (popupWindow2 != null) {
                            popupWindow2.dismiss();
                        }
                    }
                });
                popupWindow.showAsDropDown(FileName_Activity.this.mRel_datetime, 0, -(FileName_Activity.this.mRel_datetime.getHeight() / 3), 5);
                SP sp = FileName_Activity.this.mSP;
                FileName_Activity fileName_Activity = FileName_Activity.this;
                sp.setString(fileName_Activity, SP.FULL_FILE_NAME, fileName_Activity.mTv_filename.getText().toString().trim());
            }
        }, 1000L);
    }

    private void newViews() {
        if (this.list_item.size() > 0) {
            try {
                View view = getView(this.list_item.get(0).getTag());
                ((ViewGroup) view.getParent()).removeView(view);
                View view2 = getView(this.list_item.get(1).getTag());
                ((ViewGroup) view2.getParent()).removeView(view2);
                View view3 = getView(this.list_item.get(2).getTag());
                ((ViewGroup) view3.getParent()).removeView(view3);
                View view4 = getView(this.list_item.get(3).getTag());
                ((ViewGroup) view4.getParent()).removeView(view4);
                View view5 = getView(this.list_item.get(4).getTag());
                ((ViewGroup) view5.getParent()).removeView(view5);
                View view6 = getView(this.list_item.get(5).getTag());
                ((ViewGroup) view6.getParent()).removeView(view6);
                View view7 = getView(this.list_item.get(6).getTag());
                ((ViewGroup) view7.getParent()).removeView(view7);
                this.dragLinearLayout.addView(view, 0);
                this.dragLinearLayout.addView(view2, 1);
                this.dragLinearLayout.addView(view3, 2);
                this.dragLinearLayout.addView(view4, 3);
                this.dragLinearLayout.addView(view5, 4);
                this.dragLinearLayout.addView(view6, 5);
                this.dragLinearLayout.addView(view7, 6);
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
        }
    }

    private View getView(String str) {
        if (str.equals(Default.DATETIME)) {
            return findViewById(R.id.rel_main_datetime);
        }
        if (str.equals(Default.SEQUENCE)) {
            return findViewById(R.id.rel_sequence_num);
        }
        if (str.equals(Default.CUSTOM1)) {
            return findViewById(R.id.rel_custom_1);
        }
        if (str.equals(Default.CUSTOM2)) {
            return findViewById(R.id.rel_custom_2);
        }
        if (str.equals(Default.CUSTOM3)) {
            return findViewById(R.id.rel_custom_3);
        }
        if (str.equals("address")) {
            return findViewById(R.id.rel_add_address);
        }
        return findViewById(R.id.rel_lat_lng);
    }

    private void setUpEditText() {
        this.mEd_sequence.addTextChangedListener(new TextWatcher() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FileName_Activity.2
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                if (charSequence.toString().length() > 0 && FileName_Activity.this.mEd_sequence.isFocused()) {
                    FileName_Activity.this.chk_s_n.setChecked(true);
                    FileName_Activity fileName_Activity = FileName_Activity.this;
                    fileName_Activity.updateListData(Integer.valueOf(fileName_Activity.get_sequence_index()), true, FileName_Activity.this.getSequence_EdittextValue());
                    Log.e(":::datata::", "onTextChanged: " + FileName_Activity.this.get_sequence_index());
                } else {
                    FileName_Activity.this.chk_s_n.setChecked(false);
                    FileName_Activity fileName_Activity2 = FileName_Activity.this;
                    fileName_Activity2.updateListData(Integer.valueOf(fileName_Activity2.get_sequence_index()), false, "");
                }
                FileName_Activity.this.setUpTextview();
            }
        });
        if (this.is_pro) {
            this.mEd_cus_1.setEnabled(true);
            this.mEd_cus_2.setEnabled(true);
            this.mEd_cus_3.setEnabled(true);
            this.chk_line_1.setEnabled(true);
            this.chk_line_2.setEnabled(true);
            this.chk_line_3.setEnabled(true);
            this.chk_line_4.setEnabled(true);
            this.chk_dms.setEnabled(true);
            this.chk_decimal.setEnabled(true);
            this.rel_inapp_cus_1.setVisibility(View.GONE);
            this.rel_inapp_cus_2.setVisibility(View.GONE);
            this.rel_inapp_cus_3.setVisibility(View.GONE);
            this.rel_inapp_lat_lng.setVisibility(View.GONE);
            this.rel_inapp_address.setVisibility(View.GONE);
            this.mEd_cus_1.addTextChangedListener(new TextWatcher() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FileName_Activity.3
                @Override // android.text.TextWatcher
                public void afterTextChanged(Editable editable) {
                }

                @Override // android.text.TextWatcher
                public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                }

                @Override // android.text.TextWatcher
                public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                    if (charSequence.toString().trim().length() > 0 && FileName_Activity.this.mEd_cus_1.isFocused()) {
                        FileName_Activity.this.chk_cus_1.setChecked(true);
                        FileName_Activity fileName_Activity = FileName_Activity.this;
                        fileName_Activity.updateListData(Integer.valueOf(fileName_Activity.get_custom1_index()), true, FileName_Activity.this.getCustom_1_EditTextValue());
                    } else {
                        FileName_Activity.this.chk_cus_1.setChecked(false);
                        FileName_Activity fileName_Activity2 = FileName_Activity.this;
                        fileName_Activity2.updateListData(Integer.valueOf(fileName_Activity2.get_custom1_index()), false, "");
                    }
                    FileName_Activity.this.setUpTextview();
                }
            });
            this.mEd_cus_2.addTextChangedListener(new TextWatcher() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FileName_Activity.4
                @Override // android.text.TextWatcher
                public void afterTextChanged(Editable editable) {
                }

                @Override // android.text.TextWatcher
                public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                }

                @Override // android.text.TextWatcher
                public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                    if (charSequence.toString().trim().length() > 0) {
                        FileName_Activity.this.chk_cus_2.setChecked(true);
                        FileName_Activity fileName_Activity = FileName_Activity.this;
                        fileName_Activity.updateListData(Integer.valueOf(fileName_Activity.get_custom2_index()), true, FileName_Activity.this.getCustom_2_EditTextValue());
                    } else {
                        FileName_Activity.this.chk_cus_2.setChecked(false);
                        FileName_Activity fileName_Activity2 = FileName_Activity.this;
                        fileName_Activity2.updateListData(Integer.valueOf(fileName_Activity2.get_custom2_index()), false, "");
                    }
                    FileName_Activity.this.setUpTextview();
                }
            });
            this.mEd_cus_3.addTextChangedListener(new TextWatcher() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FileName_Activity.5
                @Override // android.text.TextWatcher
                public void afterTextChanged(Editable editable) {
                }

                @Override // android.text.TextWatcher
                public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                }

                @Override // android.text.TextWatcher
                public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                    if (charSequence.toString().trim().length() > 0) {
                        FileName_Activity.this.chk_cus_3.setChecked(true);
                        FileName_Activity fileName_Activity = FileName_Activity.this;
                        fileName_Activity.updateListData(Integer.valueOf(fileName_Activity.get_custom3_index()), true, FileName_Activity.this.getCustom_3_EditTextValue());
                    } else {
                        FileName_Activity.this.chk_cus_3.setChecked(false);
                        FileName_Activity fileName_Activity2 = FileName_Activity.this;
                        fileName_Activity2.updateListData(Integer.valueOf(fileName_Activity2.get_custom3_index()), false, "");
                    }
                    FileName_Activity.this.setUpTextview();
                }
            });
            if (this.chk_main_address.isChecked()) {
                if (this.chk_line_1.isChecked() && !isNotEmpty(getLine_1_address())) {
                    this.chk_line_1.setChecked(false);
                }
                if (this.chk_line_2.isChecked() && !isNotEmpty(getLine_2_address())) {
                    this.chk_line_2.setChecked(false);
                }
                if (this.chk_line_3.isChecked() && !isNotEmpty(getLine_3_address())) {
                    this.chk_line_3.setChecked(false);
                }
                if (this.chk_line_4.isChecked() && !isNotEmpty(getLine_4_address())) {
                    this.chk_line_4.setChecked(false);
                }
                if (!this.chk_line_1.isChecked() && !this.chk_line_2.isChecked() && !this.chk_line_3.isChecked() && !this.chk_line_4.isChecked()) {
                    this.chk_main_address.setChecked(false);
                    updateListData(Integer.valueOf(get_address_index()), false, "");
                } else {
                    updateListData(Integer.valueOf(get_address_index()), true, getAddress());
                }
            }
            if (this.chk_main_latlng.isChecked()) {
                Integer valueOf = Integer.valueOf(get_lat_long_index());
                updateListData(valueOf, true, "" + getLatLong());
            }
        } else {
            this.rel_inapp_cus_1.setVisibility(View.VISIBLE);
            this.rel_inapp_cus_2.setVisibility(View.VISIBLE);
            this.rel_inapp_cus_3.setVisibility(View.VISIBLE);
            this.rel_inapp_lat_lng.setVisibility(View.VISIBLE);
            this.rel_inapp_address.setVisibility(View.VISIBLE);
            this.mEd_cus_1.setEnabled(false);
            this.mEd_cus_2.setEnabled(false);
            this.mEd_cus_3.setEnabled(false);
            this.chk_line_1.setEnabled(false);
            this.chk_line_2.setEnabled(false);
            this.chk_line_3.setEnabled(false);
            this.chk_line_4.setEnabled(false);
            this.chk_dms.setEnabled(false);
            this.chk_decimal.setEnabled(false);
        }
        if (this.chk_main_date_time.isChecked()) {
            updateListData(Integer.valueOf(get_date_time_index()), true, getDateValue());
        }
        if (this.chk_s_n.isChecked()) {
            Integer valueOf2 = Integer.valueOf(get_sequence_index());
            updateListData(valueOf2, true, "" + getSequenceText());
        }
        setUpTextview();
    }

    private void setData() {
        this.chk_main_date_time.setChecked(is_main_dt());
        this.chk_dt.setChecked(is_dt());
        this.chk_hr_min.setChecked(is_hr_min());
        this.chk_24_hr.setChecked(is_24HR());
        this.chk_Week.setChecked(is_week());
        this.chk_s_n.setChecked(is_sequence());
        this.chk_cus_1.setChecked(is_cus_1());
        this.chk_cus_2.setChecked(is_cus_2());
        this.chk_cus_3.setChecked(is_cus_3());
        this.chk_main_address.setChecked(is_main_address());
        this.chk_line_1.setChecked(is_line_1());
        this.chk_line_2.setChecked(is_line_2());
        this.chk_line_3.setChecked(is_line_3());
        this.chk_line_4.setChecked(is_line_4());
        this.chk_main_latlng.setChecked(is_main_lat_lng());
        this.chk_decimal.setChecked(is_decimal());
        this.chk_dms.setChecked(is_dms());
        EditText editText = this.mEd_sequence;
        editText.setText("" + getSequenceText());
        this.mEd_cus_1.setText(getCusText_1());
        this.mEd_cus_2.setText(getCusText_2());
        this.mEd_cus_3.setText(getCusText_3());
    }

    private String getCusText_1() {
        return this.mSP.getString(this, SP.CUS_VALUE_1, Default.CUSTUM_NAME_1_VALUE);
    }

    private String getCusText_2() {
        return this.mSP.getString(this, SP.CUS_VALUE_2, getString(R.string.cus_2));
    }

    private String getCusText_3() {
        return this.mSP.getString(this, SP.CUS_VALUE_3, getString(R.string.cus_3));
    }

    private int getSequenceText() {
        return this.mSP.getInteger(this, SP.SEQUENCE_VALUE, 1);
    }

    private boolean is_dms() {
        return this.mSP.getBoolean(this, SP.IS_DMS_FILE, false);
    }

    private boolean is_decimal() {
        return this.mSP.getBoolean(this, SP.IS_DECIMAL_FILE, false);
    }

    private boolean is_main_lat_lng() {
        return this.mSP.getBoolean(this, SP.IS_LAT_LNG, false);
    }

    private boolean is_line_4() {
        return this.mSP.getBoolean(this, SP.IS_LINE_4, false);
    }

    private boolean is_line_3() {
        return this.mSP.getBoolean(this, SP.IS_LINE_3, false);
    }

    private boolean is_line_2() {
        return this.mSP.getBoolean(this, SP.IS_LINE_2, false);
    }

    private boolean is_line_1() {
        return this.mSP.getBoolean(this, SP.IS_LINE_1, false);
    }

    private boolean is_main_address() {
        return this.mSP.getBoolean(this, SP.IS_MAIN_ADDRESS, false);
    }

    private boolean is_cus_3() {
        return this.mSP.getBoolean(this, SP.IS_CUS_3, false);
    }

    private boolean is_cus_2() {
        return this.mSP.getBoolean(this, SP.IS_CUS_2, false);
    }

    private boolean is_cus_1() {
        return this.mSP.getBoolean(this, SP.IS_CUS_1, true);
    }

    private boolean is_sequence() {
        return this.mSP.getBoolean(this, SP.IS_SEQUENCE, false);
    }

    private boolean is_week() {
        return this.mSP.getBoolean(this, SP.IS_WEEK, false);
    }

    private boolean is_24HR() {
        return this.mSP.getBoolean(this, SP.IS_24HR, false);
    }

    private boolean is_hr_min() {
        return this.mSP.getBoolean(this, SP.IS_HR_MIN_SEC, true);
    }

    private boolean is_dt() {
        return this.mSP.getBoolean(this, SP.IS_DT, true);
    }

    private boolean is_main_dt() {
        return this.mSP.getBoolean(this, SP.IS_FILE_DATE_TIME, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setUpTextview() {
        ArrayList<ViewModel> arrayList = this.list_item;
        if (arrayList == null || arrayList.size() <= 0) {
            return;
        }
        String str = "";
        for (int i = 0; i < this.list_item.size(); i++) {
            if (this.list_item.get(i).getSelected().booleanValue()) {
                str = str + "_" + this.list_item.get(i).getValue();
            }
        }
        if (isNotEmpty(str)) {
            if (str.substring(0, 1).equals("_")) {
                str = str.replaceFirst("_", "");
            }
            String replace = str.replace(" ", "_");
            this.mTv_filename.setText(replace + ".jpg");
        }
    }

    private void setRecyclerView() {
        for (int i = 0; i < this.dragLinearLayout.getChildCount(); i++) {
            View childAt = this.dragLinearLayout.getChildAt(i);
            this.dragLinearLayout.setViewDraggable(childAt, childAt);
            addExistingNote(i, childAt);
        }
        this.dragLinearLayout.setOnViewSwapListener(new DragLinearLayout.OnViewSwapListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FileName_Activity.6
            @Override // com.gpsmapcamera.geotagginglocationonphoto.dragView.DragLinearLayout.OnViewSwapListener
            public void onSwap(View view, int i2, View view2, int i3) {
                int noteIndex = FileName_Activity.this.getNoteIndex(view);
                int noteIndex2 = FileName_Activity.this.getNoteIndex(view2);
                FileName_Activity.this.setNoteIndex(view, noteIndex2);
                FileName_Activity.this.setNoteIndex(view2, noteIndex);
                Collections.swap(FileName_Activity.this.list_item, noteIndex2, noteIndex);
                FileName_Activity.this.setUpTextview();
            }
        });
    }

    private void onClicks() {
        this.mToolbar_back.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View view) {
                FileName_Activity.this.onBackPressed();
            }
        });
        this.mTv_click_dt.setOnClickListener(this);
        this.mTv_click_sn.setOnClickListener(this);
        this.mTv_click_cus_1.setOnClickListener(this);
        this.mTv_click_cus_2.setOnClickListener(this);
        this.mTv_click_cus_3.setOnClickListener(this);
        this.mTv_click_address.setOnClickListener(this);
        this.mTv_click_latlng.setOnClickListener(this);
        this.chk_main_date_time.setOnCheckedChangeListener(this);
        this.chk_dt.setOnCheckedChangeListener(this);
        this.chk_Week.setOnCheckedChangeListener(this);
        this.chk_hr_min.setOnCheckedChangeListener(this);
        this.chk_24_hr.setOnCheckedChangeListener(this);
        this.chk_s_n.setOnCheckedChangeListener(this);
        if (this.is_pro) {
            this.chk_cus_1.setOnCheckedChangeListener(this);
            this.chk_cus_2.setOnCheckedChangeListener(this);
            this.chk_cus_3.setOnCheckedChangeListener(this);
            this.chk_main_address.setOnCheckedChangeListener(this);
            this.chk_main_latlng.setOnCheckedChangeListener(this);
            this.chk_main_latlng.setOnCheckedChangeListener(this);
            this.chk_decimal.setOnCheckedChangeListener(this);
            this.chk_dms.setOnCheckedChangeListener(this);
            this.chk_line_1.setOnCheckedChangeListener(this);
            this.chk_line_2.setOnCheckedChangeListener(this);
            this.chk_line_3.setOnCheckedChangeListener(this);
            this.chk_line_4.setOnCheckedChangeListener(this);
        } else {
            this.rel_inapp_cus_1.setOnClickListener(this);
            this.rel_inapp_cus_2.setOnClickListener(this);
            this.rel_inapp_cus_3.setOnClickListener(this);
            this.rel_inapp_address.setOnClickListener(this);
            this.rel_inapp_lat_lng.setOnClickListener(this);
        }
        this.mEd_sequence.setOnFocusChangeListener(this);
        this.mEd_cus_1.setOnFocusChangeListener(this);
        this.mEd_cus_2.setOnFocusChangeListener(this);
        this.mEd_cus_3.setOnFocusChangeListener(this);
        this.chk_line_1.setOnClickListener(this);
        this.chk_line_2.setOnClickListener(this);
        this.chk_line_3.setOnClickListener(this);
        this.chk_line_4.setOnClickListener(this);
        this.chk_main_date_time.setOnClickListener(this);
        this.chk_main_address.setOnClickListener(this);
        this.chk_main_latlng.setOnClickListener(this);
        this.chk_s_n.setOnClickListener(this);
        this.chk_cus_1.setOnClickListener(this);
        this.chk_cus_2.setOnClickListener(this);
        this.chk_cus_3.setOnClickListener(this);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        int id = view.getId();
        switch (id) {
            case R.id.chk_cus_1 /* 2131362001 */:
                if (!isNotEmpty(this.mEd_cus_1.getText().toString())) {
                    RelativeLayout relativeLayout = this.mRel_datetime;
                    Snackbar.make(relativeLayout, "" + getString(R.string.cus_1_empty_msg), -1).show();
                }
                if (!this.is_pro) {
                    this.chk_cus_1.setChecked(true);
                }
                if (this.chk_cus_1.isChecked()) {
                    visibleUi(R.id.li_child_cus_1, true);
                    return;
                }
                return;
            case R.id.chk_cus_2 /* 2131362002 */:
                if (!isNotEmpty(this.mEd_cus_2.getText().toString())) {
                    RelativeLayout relativeLayout2 = this.mRel_datetime;
                    Snackbar.make(relativeLayout2, "" + getString(R.string.cus_2_empty_msg), -1).show();
                }
                if (this.chk_cus_2.isChecked()) {
                    if (!this.is_pro) {
                        this.chk_cus_2.setChecked(false);
                    }
                    visibleUi(R.id.li_child_cus_2, true);
                    return;
                }
                return;
            case R.id.chk_cus_3 /* 2131362003 */:
                if (!isNotEmpty(this.mEd_cus_3.getText().toString())) {
                    RelativeLayout relativeLayout3 = this.mRel_datetime;
                    Snackbar.make(relativeLayout3, "" + getString(R.string.cus_3_empty_msg), -1).show();
                }
                if (this.chk_cus_3.isChecked()) {
                    if (!this.is_pro) {
                        this.chk_cus_3.setChecked(false);
                    }
                    visibleUi(R.id.li_child_cus_3, true);
                    return;
                }
                return;
            default:
                switch (id) {
                    case R.id.chk_line_1 /* 2131362010 */:
                        if (isNotEmpty(getLine_1_address())) {
                            return;
                        }
                        RelativeLayout relativeLayout4 = this.mRel_datetime;
                        Snackbar.make(relativeLayout4, "" + getString(R.string.line1_address_empty_msg), -1).show();
                        return;
                    case R.id.chk_line_2 /* 2131362011 */:
                        if (isNotEmpty(getLine_2_address())) {
                            return;
                        }
                        RelativeLayout relativeLayout5 = this.mRel_datetime;
                        Snackbar.make(relativeLayout5, "" + getString(R.string.line2_address_empty_msg), -1).show();
                        return;
                    case R.id.chk_line_3 /* 2131362012 */:
                        if (isNotEmpty(getLine_3_address())) {
                            return;
                        }
                        RelativeLayout relativeLayout6 = this.mRel_datetime;
                        Snackbar.make(relativeLayout6, "" + getString(R.string.line3_address_empty_msg), -1).show();
                        return;
                    case R.id.chk_line_4 /* 2131362013 */:
                        if (isNotEmpty(getLine_4_address())) {
                            return;
                        }
                        RelativeLayout relativeLayout7 = this.mRel_datetime;
                        Snackbar.make(relativeLayout7, "" + getString(R.string.line4_address_empty_msg), -1).show();
                        return;
                    case R.id.chk_main_address /* 2131362014 */:
                        if (this.chk_main_address.isChecked()) {
                            if (!this.is_pro) {
                                this.chk_main_address.setChecked(false);
                            }
                            visibleUi(R.id.li_child_address, true);
                            return;
                        } else if (isNotEmpty(getLine_1_address()) || isNotEmpty(getLine_2_address()) || isNotEmpty(getLine_3_address()) || isNotEmpty(getLine_4_address())) {
                            return;
                        } else {
                            RelativeLayout relativeLayout8 = this.mRel_datetime;
                            Snackbar.make(relativeLayout8, "" + getString(R.string.all_address_empty_msg), -1).show();
                            return;
                        }
                    case R.id.chk_main_date_time /* 2131362015 */:
                        if (this.chk_main_date_time.isChecked()) {
                            visibleUi(R.id.li_child_dt, true);
                            return;
                        }
                        return;
                    case R.id.chk_main_latlng /* 2131362016 */:
                        if (this.chk_main_latlng.isChecked()) {
                            if (!this.is_pro) {
                                this.chk_main_latlng.setChecked(false);
                            }
                            visibleUi(R.id.li_child_lat_lng, true);
                            return;
                        }
                        return;
                    case R.id.chk_s_n /* 2131362017 */:
                        if (this.chk_s_n.isChecked()) {
                            visibleUi(R.id.li_child_sequence, true);
                            return;
                        }
                        return;
                    default:
                        switch (id) {
                            case R.id.rel_inapp_address /* 2131362627 */:
                            case R.id.rel_inapp_cus_1 /* 2131362628 */:
                            case R.id.rel_inapp_cus_2 /* 2131362629 */:
                            case R.id.rel_inapp_cus_3 /* 2131362630 */:
                            case R.id.rel_inapp_lat_lng /* 2131362631 */:
                                dialog();
                                return;
                            default:
                                switch (id) {
                                    case R.id.tv_click_address /* 2131362837 */:
                                        visibleUi(R.id.li_child_address, false);
                                        Util.hideSoftKeyboard(this, this.mRel_datetime);
                                        return;
                                    case R.id.tv_click_cus_1 /* 2131362838 */:
                                        visibleUi(R.id.li_child_cus_1, false);
                                        return;
                                    case R.id.tv_click_cus_2 /* 2131362839 */:
                                        visibleUi(R.id.li_child_cus_2, false);
                                        return;
                                    case R.id.tv_click_cus_3 /* 2131362840 */:
                                        visibleUi(R.id.li_child_cus_3, false);
                                        return;
                                    case R.id.tv_click_dt /* 2131362841 */:
                                        visibleUi(R.id.li_child_dt, false);
                                        Util.hideSoftKeyboard(this, this.mRel_datetime);
                                        return;
                                    case R.id.tv_click_latlng /* 2131362842 */:
                                        visibleUi(R.id.li_child_lat_lng, false);
                                        Util.hideSoftKeyboard(this, this.mRel_datetime);
                                        return;
                                    case R.id.tv_click_sn /* 2131362843 */:
                                        visibleUi(R.id.li_child_sequence, false);
                                        return;
                                    default:
                                        return;
                                }
                        }
                }
        }
    }

    private void dialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getResources().getString(R.string.file_inapp_msg));
        builder.setPositiveButton(getResources().getString(R.string.pro), new DialogInterface.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FileName_Activity.8
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                if (NetworkState.Companion.isOnline(FileName_Activity.this)) {
                    FileName_Activity.this.startActivity(new Intent(FileName_Activity.this, InAppPurchaseActivity.class));
                    return;
                }
                RelativeLayout relativeLayout = FileName_Activity.this.main_real;
                Snackbar.make(relativeLayout, "" + FileName_Activity.this.getString(R.string.no_internet_msg), -1).show();
            }
        });
        builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FileName_Activity.9
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.create().show();
    }

    private void visibleUi(int i, boolean z) {
        int size = this.child_layList.size();
        for (int i2 = 0; i2 < size; i2++) {
            View findViewById = findViewById(this.child_layList.get(i2).intValue());
            TextView textView = (TextView) findViewById(this.drop_down_List.get(i2).intValue());
            if (findViewById != null && textView != null) {
                if (this.child_layList.get(i2).intValue() != i) {
                    findViewById.setVisibility(View.GONE);
                    textView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_drop_down_black, 0);
                } else if (z) {
                    findViewById.setVisibility(View.VISIBLE);
                    textView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_drop_up, 0);
                } else if (findViewById.getVisibility() == 0) {
                    findViewById.setVisibility(View.GONE);
                    textView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_drop_down_black, 0);
                } else {
                    findViewById.setVisibility(View.VISIBLE);
                    textView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_drop_up, 0);
                }
            }
        }
    }

    private void saveData() {
        try {
            if (isFinishing()) {
                return;
            }
            this.mSP.saveArrayList(this, this.list_item);
            this.mSP.setString(this, SP.FULL_FILE_NAME, this.mTv_filename.getText().toString().trim());
            this.mSP.setBoolean(this, SP.IS_FILE_DATE_TIME, this.chk_main_date_time.isChecked());
            this.mSP.setBoolean(this, SP.IS_DT, this.chk_dt.isChecked());
            this.mSP.setBoolean(this, SP.IS_HR_MIN_SEC, this.chk_hr_min.isChecked());
            this.mSP.setBoolean(this, SP.IS_WEEK, this.chk_Week.isChecked());
            this.mSP.setBoolean(this, SP.IS_24HR, this.chk_24_hr.isChecked());
            this.mSP.setBoolean(this, SP.IS_SEQUENCE, this.chk_s_n.isChecked());
            this.mSP.setBoolean(this, SP.IS_CUS_1, this.chk_cus_1.isChecked());
            this.mSP.setBoolean(this, SP.IS_CUS_2, this.chk_cus_2.isChecked());
            this.mSP.setBoolean(this, SP.IS_CUS_3, this.chk_cus_3.isChecked());
            this.mSP.setBoolean(this, SP.IS_MAIN_ADDRESS, this.chk_main_address.isChecked());
            this.mSP.setBoolean(this, SP.IS_LINE_1, this.chk_line_1.isChecked());
            this.mSP.setBoolean(this, SP.IS_LINE_2, this.chk_line_2.isChecked());
            this.mSP.setBoolean(this, SP.IS_LINE_3, this.chk_line_3.isChecked());
            this.mSP.setBoolean(this, SP.IS_LINE_4, this.chk_line_4.isChecked());
            this.mSP.setBoolean(this, SP.IS_LAT_LNG, this.chk_main_latlng.isChecked());
            this.mSP.setBoolean(this, SP.IS_DECIMAL_FILE, this.chk_decimal.isChecked());
            this.mSP.setBoolean(this, SP.IS_DMS_FILE, this.chk_dms.isChecked());
            if (isNotEmpty(getSequence_EdittextValue())) {
                this.mSP.setInteger(this, SP.SEQUENCE_VALUE, Integer.parseInt(getSequence_EdittextValue()));
            }
            this.mSP.setString(this, SP.CUS_VALUE_1, getCustom_1_EditTextValue());
            this.mSP.setString(this, SP.CUS_VALUE_2, getCustom_2_EditTextValue());
            this.mSP.setString(this, SP.CUS_VALUE_3, getCustom_3_EditTextValue());
            this.mSP.setInteger(this, SP.DATE_TIME_INDEX, get_date_time_index());
            this.mSP.setInteger(this, SP.SEQUENCE_INDEX, get_sequence_index());
            this.mSP.setInteger(this, SP.CUS_1_INDEX, get_custom1_index());
            this.mSP.setInteger(this, SP.CUS_2_INDEX, get_custom2_index());
            this.mSP.setInteger(this, SP.CUS_3_INDEX, get_custom3_index());
            this.mSP.setInteger(this, SP.ADDRESS_INDEX, get_address_index());
            this.mSP.setInteger(this, SP.LAT_LNG_INDEX, get_lat_long_index());
            getexitads();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean isNotSelected() {
        return (this.chk_main_date_time.isChecked() || this.chk_s_n.isChecked() || this.chk_cus_1.isChecked() || this.chk_cus_2.isChecked() || this.chk_cus_3.isChecked() || this.chk_main_address.isChecked() || this.chk_main_latlng.isChecked()) ? false : true;
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (!isNotSelected()) {
            if (isChanges()) {
                saveData();
                return;
            } else {
                getexitads();
                return;
            }
        }
        RelativeLayout relativeLayout = this.mRel_datetime;
        Snackbar.make(relativeLayout, "" + getString(R.string.file_name_empty_msg), -1).show();
    }

    private void getexitads() {
//        int integer = this.mSP.getInteger(this, Util.COUNTADS, 0);
//        if (!this.ads_status.equals("1") || this.IS_ADS) {
//            finish();
//        } else if (integer == 2) {
//            if (NetworkState.Companion.isOnline(this)) {
//                Util.showProgressDialog(this, "Loading...");
//                new Handler().postDelayed(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FileName_Activity.10
//                    @Override // java.lang.Runnable
//                    public void run() {
//                        FileName_Activity.this.mSP.setInteger(FileName_Activity.this, Util.COUNTADS, 0);
//                        FileName_Activity fileName_Activity = FileName_Activity.this;
//                        fileName_Activity.inrequestadd(fileName_Activity);
//                    }
//                }, 200L);
//                new Handler().postDelayed(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FileName_Activity.11
//                    @Override // java.lang.Runnable
//                    public void run() {
//                        Util.dismissProgressDialog();
//                        if (FileName_Activity.this.mInterstitialAd != null) {
//                            FileName_Activity.this.mInterstitialAd.show(FileName_Activity.this);
//                        } else {
//                            FileName_Activity.this.finish();
//                        }
//                    }
//                }, 7000L);
//                return;
//            }
//            finish();
//        } else {
//            this.mSP.setInteger(this, Util.COUNTADS, integer + 1);
            finish();
//        }
    }

    /* JADX INFO: Access modifiers changed from: private */
//    public void inrequestadd(Context context) {
//        try {
//            InterstitialAd.load(this, getResources().getString(R.string.TC_3_click_FS), new AdRequest.Builder().build(), new InterstitialAdLoadCallback() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FileName_Activity.12
//                @Override // com.google.android.gms.ads.AdLoadCallback
//                public void onAdLoaded(InterstitialAd interstitialAd) {
//                    FileName_Activity.this.mInterstitialAd = interstitialAd;
//                    setFullScreenContentCallback();
//                    if (FileName_Activity.this.mInterstitialAd != null) {
//                        FileName_Activity.this.mInterstitialAd.show(FileName_Activity.this);
//                    }
//                }
//
//                private void setFullScreenContentCallback() {
//                    FileName_Activity.this.mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.FileName_Activity.12.1
//                        @Override // com.google.android.gms.ads.FullScreenContentCallback
//                        public void onAdDismissedFullScreenContent() {
//                            Log.d("TAG", "The ad was dismissed.");
//                            Util.dismissProgressDialog();
//                            FileName_Activity.this.finish();
//                        }
//
//                        @Override // com.google.android.gms.ads.FullScreenContentCallback
//                        public void onAdFailedToShowFullScreenContent(AdError adError) {
//                            Log.d("TAG", "The ad failed to show.");
//                            FileName_Activity.this.finish();
//                        }
//
//                        @Override // com.google.android.gms.ads.FullScreenContentCallback
//                        public void onAdShowedFullScreenContent() {
//                            FileName_Activity.this.mInterstitialAd = null;
//                            Log.d("TAG", "The ad was shown.");
//                        }
//                    });
//                }
//
//                @Override // com.google.android.gms.ads.AdLoadCallback
//                public void onAdFailedToLoad(LoadAdError loadAdError) {
//                    FileName_Activity.this.mInterstitialAd = null;
//                }
//            });
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    private boolean isChanges() {
        return !getFullFilename().equals(this.mTv_filename.getText().toString().trim());
    }

    private String getFullFilename() {
        return this.mSP.getString(this, SP.FULL_FILE_NAME, "");
    }

    private int get_date_time_index() {
        return ((Integer) this.mRel_datetime.getTag()).intValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int get_sequence_index() {
        return ((Integer) this.mRel_sequence_num.getTag()).intValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int get_custom1_index() {
        return ((Integer) this.mRel_custom_1.getTag()).intValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int get_custom2_index() {
        return ((Integer) this.mRel_custom_2.getTag()).intValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int get_custom3_index() {
        return ((Integer) this.mRel_custom_3.getTag()).intValue();
    }

    private int get_address_index() {
        return ((Integer) this.mRel_add_address.getTag()).intValue();
    }

    private int get_lat_long_index() {
        return ((Integer) this.mRel_lat_lng.getTag()).intValue();
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Removed duplicated region for block: B:151:0x0525  */
    /* JADX WARN: Removed duplicated region for block: B:152:0x053a  */
    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        switch (compoundButton.getId()) {
            case R.id.chk_24_hr /* 2131361999 */:
            case R.id.chk_Week /* 2131362000 */:
                if (!z) {
                    this.chk_main_date_time.setChecked(true);
                    updateListData(Integer.valueOf(get_date_time_index()), true, getDateValue());
                } else {
                    this.chk_main_date_time.setChecked(true);
                    updateListData(Integer.valueOf(get_date_time_index()), true, getDateValue());
                }
                Util.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_cus_1 /* 2131362001 */:
                if (z) {
                    if (this.mEd_cus_1.getText().toString().trim().isEmpty()) {
                        this.chk_cus_1.setChecked(false);
                        updateListData(Integer.valueOf(get_custom1_index()), false, "");
                        break;
                    } else {
                        updateListData(Integer.valueOf(get_custom1_index()), true, getCustom_1_EditTextValue());
                        break;
                    }
                } else {
                    updateListData(Integer.valueOf(get_custom1_index()), false, "");
                    break;
                }
            case R.id.chk_cus_2 /* 2131362002 */:
                if (z) {
                    if (this.mEd_cus_2.getText().toString().trim().isEmpty()) {
                        this.chk_cus_2.setChecked(false);
                        updateListData(Integer.valueOf(get_custom2_index()), false, "");
                        break;
                    } else {
                        updateListData(Integer.valueOf(get_custom2_index()), true, getCustom_2_EditTextValue());
                        break;
                    }
                } else {
                    updateListData(Integer.valueOf(get_custom2_index()), false, "");
                    break;
                }
            case R.id.chk_cus_3 /* 2131362003 */:
                if (z) {
                    if (this.mEd_cus_3.getText().toString().trim().isEmpty()) {
                        this.chk_cus_3.setChecked(false);
                        updateListData(Integer.valueOf(get_custom3_index()), false, "");
                        break;
                    } else {
                        updateListData(Integer.valueOf(get_custom3_index()), true, getCustom_3_EditTextValue());
                        break;
                    }
                } else {
                    updateListData(Integer.valueOf(get_custom3_index()), false, "");
                    break;
                }
            case R.id.chk_decimal /* 2131362004 */:
            case R.id.chk_dms /* 2131362006 */:
                if (z) {
                    this.chk_main_latlng.setChecked(true);
                    updateListData(Integer.valueOf(get_lat_long_index()), true, getLatLong());
                } else if (!this.chk_decimal.isChecked() && !this.chk_dms.isChecked()) {
                    this.chk_main_latlng.setChecked(false);
                    updateListData(Integer.valueOf(get_lat_long_index()), false, "");
                } else {
                    this.chk_main_latlng.setChecked(true);
                    updateListData(Integer.valueOf(get_lat_long_index()), true, getLatLong());
                }
                if (!z) {
                }
                Util.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_line_1 /* 2131362010 */:
                if (z) {
                    if (isNotEmpty(getLine_1_address())) {
                        this.chk_main_address.setChecked(true);
                        updateListData(Integer.valueOf(get_address_index()), true, getAddress());
                    } else {
                        this.chk_line_1.setChecked(false);
                    }
                    Log.e(":::file_name::::", "onCheckedChanged_111: ");
                } else if (!this.chk_line_1.isChecked() && !this.chk_line_2.isChecked() && !this.chk_line_3.isChecked() && !this.chk_line_4.isChecked()) {
                    this.chk_main_address.setChecked(false);
                    updateListData(Integer.valueOf(get_address_index()), false, "");
                } else if (isNotEmpty(getAddress())) {
                    this.chk_main_address.setChecked(true);
                    updateListData(Integer.valueOf(get_address_index()), true, getAddress());
                }
                Util.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_line_2 /* 2131362011 */:
                if (z) {
                    if (isNotEmpty(getLine_2_address())) {
                        this.chk_main_address.setChecked(true);
                        updateListData(Integer.valueOf(get_address_index()), true, getAddress());
                    } else {
                        this.chk_line_2.setChecked(false);
                    }
                } else if (!this.chk_line_1.isChecked() && !this.chk_line_2.isChecked() && !this.chk_line_3.isChecked() && !this.chk_line_4.isChecked()) {
                    this.chk_main_address.setChecked(false);
                    updateListData(Integer.valueOf(get_address_index()), false, "");
                } else if (isNotEmpty(getAddress())) {
                    this.chk_main_address.setChecked(true);
                    updateListData(Integer.valueOf(get_address_index()), true, getAddress());
                }
                Util.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_line_3 /* 2131362012 */:
                if (z) {
                    if (isNotEmpty(getLine_3_address())) {
                        this.chk_main_address.setChecked(true);
                        updateListData(Integer.valueOf(get_address_index()), true, getAddress());
                    } else {
                        this.chk_line_3.setChecked(false);
                    }
                } else if (!this.chk_line_1.isChecked() && !this.chk_line_2.isChecked() && !this.chk_line_3.isChecked() && !this.chk_line_4.isChecked()) {
                    this.chk_main_address.setChecked(false);
                    updateListData(Integer.valueOf(get_address_index()), false, "");
                } else if (isNotEmpty(getAddress())) {
                    this.chk_main_address.setChecked(true);
                    updateListData(Integer.valueOf(get_address_index()), true, getAddress());
                }
                Util.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_line_4 /* 2131362013 */:
                if (z) {
                    if (isNotEmpty(getLine_4_address())) {
                        this.chk_main_address.setChecked(true);
                        updateListData(Integer.valueOf(get_address_index()), true, getAddress());
                    } else {
                        this.chk_line_4.setChecked(false);
                    }
                } else if (!this.chk_line_1.isChecked() && !this.chk_line_2.isChecked() && !this.chk_line_3.isChecked() && !this.chk_line_4.isChecked()) {
                    this.chk_main_address.setChecked(false);
                    updateListData(Integer.valueOf(get_address_index()), false, "");
                } else if (isNotEmpty(getAddress())) {
                    this.chk_main_address.setChecked(true);
                    updateListData(Integer.valueOf(get_address_index()), true, getAddress());
                }
                Util.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_main_address /* 2131362014 */:
                if (z) {
                    if (!this.chk_line_1.isChecked() && !this.chk_line_2.isChecked() && !this.chk_line_3.isChecked() && !this.chk_line_4.isChecked()) {
                        if (isNotEmpty(getLine_1_address())) {
                            this.chk_main_address.setChecked(true);
                            this.chk_line_1.setChecked(true);
                            updateListData(Integer.valueOf(get_address_index()), true, getAddress());
                        } else if (isNotEmpty(getLine_2_address())) {
                            this.chk_main_address.setChecked(true);
                            this.chk_line_2.setChecked(true);
                            updateListData(Integer.valueOf(get_address_index()), true, getAddress());
                        } else if (isNotEmpty(getLine_3_address())) {
                            this.chk_main_address.setChecked(true);
                            this.chk_line_3.setChecked(true);
                            updateListData(Integer.valueOf(get_address_index()), true, getAddress());
                        } else if (isNotEmpty(getLine_4_address())) {
                            this.chk_main_address.setChecked(true);
                            this.chk_line_4.setChecked(true);
                            updateListData(Integer.valueOf(get_address_index()), true, getAddress());
                        } else {
                            this.chk_main_address.setChecked(false);
                            this.chk_line_1.setChecked(false);
                            updateListData(Integer.valueOf(get_address_index()), false, "");
                        }
                    } else if (isNotEmpty(getAddress())) {
                        this.chk_main_address.setChecked(true);
                        updateListData(Integer.valueOf(get_address_index()), true, getAddress());
                    } else {
                        this.chk_main_address.setChecked(false);
                        updateListData(Integer.valueOf(get_address_index()), false, "");
                    }
                } else {
                    this.chk_main_address.setChecked(false);
                    this.chk_line_1.setChecked(false);
                    this.chk_line_2.setChecked(false);
                    this.chk_line_3.setChecked(false);
                    this.chk_line_4.setChecked(false);
                    updateListData(Integer.valueOf(get_address_index()), false, "");
                }
                Util.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_main_date_time /* 2131362015 */:
                if (z) {
                    updateListData(Integer.valueOf(get_date_time_index()), true, getDateValue());
                }
                Util.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_main_latlng /* 2131362016 */:
                if (z) {
                    if (!this.chk_decimal.isChecked() && !this.chk_dms.isChecked()) {
                        this.chk_main_latlng.setChecked(true);
                        this.chk_decimal.setChecked(true);
                        updateListData(Integer.valueOf(get_lat_long_index()), true, getLatLong());
                    } else {
                        updateListData(Integer.valueOf(get_lat_long_index()), true, getLatLong());
                    }
                } else {
                    this.chk_decimal.setChecked(false);
                    this.chk_dms.setChecked(false);
                    updateListData(Integer.valueOf(get_lat_long_index()), false, "");
                }
                Util.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_s_n /* 2131362017 */:
                if (z) {
                    if (this.mEd_sequence.getText().toString().trim().isEmpty()) {
                        this.chk_s_n.setChecked(false);
                        updateListData(Integer.valueOf(get_sequence_index()), false, "");
                        RelativeLayout relativeLayout = this.mRel_datetime;
                        Snackbar.make(relativeLayout, "" + getString(R.string.s_n_empty_msg), -1).show();
                        break;
                    } else {
                        updateListData(Integer.valueOf(get_sequence_index()), true, getSequence_EdittextValue());
                        break;
                    }
                } else {
                    updateListData(Integer.valueOf(get_sequence_index()), false, "");
                    break;
                }
        }
        setUpTextview();
    }

    boolean isNotEmpty(String str) {
        if (str == null) {
            return false;
        }
        return !str.trim().isEmpty();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateListData(Integer num, boolean z, String str) {
        ArrayList<ViewModel> arrayList = this.list_item;
        if (arrayList == null || arrayList.size() <= 0) {
            return;
        }
        this.list_item.get(num.intValue()).setSelected(Boolean.valueOf(z));
        this.list_item.get(num.intValue()).setValue(str);
    }

    @Override // android.view.View.OnFocusChangeListener
    public void onFocusChange(View view, boolean z) {
        switch (view.getId()) {
            case R.id.ed_cus_1 /* 2131362133 */:
                if (z) {
                    if (this.chk_cus_1.isChecked()) {
                        return;
                    }
                    this.chk_cus_1.setChecked(true);
                    return;
                }
                Util.hideSoftKeyboard(this, this.mRel_datetime);
                return;
            case R.id.ed_cus_2 /* 2131362134 */:
                if (z) {
                    if (this.chk_cus_2.isChecked()) {
                        return;
                    }
                    this.chk_cus_2.setChecked(true);
                    return;
                }
                Util.hideSoftKeyboard(this, this.mRel_datetime);
                return;
            case R.id.ed_cus_3 /* 2131362135 */:
                if (z) {
                    if (this.chk_cus_3.isChecked()) {
                        return;
                    }
                    this.chk_cus_3.setChecked(true);
                    return;
                }
                Util.hideSoftKeyboard(this, this.mRel_datetime);
                return;
//            case R.id.ed_errormsg /* 2131362136 */:
            default:
                return;
            case R.id.ed_sequence /* 2131362137 */:
                if (z) {
                    if (this.chk_s_n.isChecked()) {
                        return;
                    }
                    this.chk_s_n.setChecked(true);
                    return;
                }
                Util.hideSoftKeyboard(this, this.mRel_datetime);
                return;
        }
    }
}