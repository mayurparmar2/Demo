package com.live.gpsmap.camera.Fragment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.BaseRequestOptions;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.live.gpsmap.camera.Adapter.Logo_Adapter;
import com.live.gpsmap.camera.Interface.OnRecyclerItemClickListener;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Default;
import com.live.gpsmap.camera.Utils.Helper.CPD;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.Utils.Util;
import com.live.gpsmap.camera.Widget.RoundImageView;
import com.yalantis.ucrop.UCrop;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.Executors;

/* loaded from: classes.dex */
public class Logo_BottomSheetfragment extends BottomSheetDialogFragment {
    private static final String SAMPLE_CROPPED_IMAGE_NAME = "SampleCropImage";
    public static final String TAG = "Logo_BottomSheetfragment";
    ImageView btn_add;
    Context context;
    RoundImageView img_select;
    LinearLayout lin_recentview;
        Logo_Adapter logo_adapter;
    SP msp;
    OnSelectlogo onSelectlogo;
    ProgressBar progressBar;
    RecyclerView rv_image;
    private final int PICK_IMAGE_WATERMARK = 103;
    ArrayList<String> image = new ArrayList<>();

    /* loaded from: classes2.dex */
    public interface OnSelectlogo {
        void Onselect();
    }

    public void setOnSelectlogo(OnSelectlogo onSelectlogo) {
        this.onSelectlogo = onSelectlogo;
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @SuppressLint("RestrictedApi")
    @Override // androidx.appcompat.app.AppCompatDialogFragment, androidx.fragment.app.DialogFragment
    public void setupDialog(Dialog dialog, int i) {
        super.setupDialog(dialog, i);
        View inflate = View.inflate(getContext(), R.layout.logo_bottom_sheet_fragment, null);
        this.rv_image = (RecyclerView) inflate.findViewById(R.id.rv_image);
        this.img_select = (RoundImageView) inflate.findViewById(R.id.img_select);
        this.btn_add = (ImageView) inflate.findViewById(R.id.btn_add);
        this.lin_recentview = (LinearLayout) inflate.findViewById(R.id.lin_recentview);
        this.progressBar = (ProgressBar) inflate.findViewById(R.id.lineprogressindicator);
        this.context = inflate.getContext();
        dialog.setContentView(inflate);
        init();
    }

    private void init() {
        this.msp = new SP(getContext());
        this.image.clear();
        this.image = this.msp.loadImageuriArray(SP.IMAGE_URI, getContext());
        String string = this.msp.getString(getContext(), "imge_logo", Default.LOGO_uri);
        this.btn_add.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.Logo_BottomSheetfragment.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Logo_BottomSheetfragment logo_BottomSheetfragment = Logo_BottomSheetfragment.this;
                logo_BottomSheetfragment.callImagePicker(logo_BottomSheetfragment.getActivity());
            }
        });
        if (this.image.size() > 0) {
            this.lin_recentview.setVisibility(View.VISIBLE);
        } else {
            this.lin_recentview.setVisibility(View.GONE);
        }
        if (string.equals(Default.LOGO_uri)) {
            this.img_select.setImageResource(R.mipmap.ic_launcher);
        } else {
            this.img_select.setImageBitmap(Util.decodeBase64(string));
        }
        setadapter();
    }

    private void setadapter() {
        this.rv_image.setLayoutManager(new GridLayoutManager((Context) getActivity(), 5, RecyclerView.VERTICAL, false));
        this.logo_adapter = new Logo_Adapter(getContext(), this.image, new OnRecyclerItemClickListener() {
            @Override
            public void OnClick_(int i, View view) {
                Logo_BottomSheetfragment.this.msp.setString(Logo_BottomSheetfragment.this.getContext(), "imge_logo", Logo_BottomSheetfragment.this.image.get(i));
                Logo_BottomSheetfragment.this.onSelectlogo.Onselect();
                Logo_BottomSheetfragment.this.dismiss();
            }

            @Override // com.gpsmapcamera.geotagginglocationonphoto.interfaces.OnRecyclerItemClickListener
            public void OnLongClick_(final int i, View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Logo_BottomSheetfragment.this.requireActivity());
                builder.setCancelable(false);
                builder.setTitle(Logo_BottomSheetfragment.this.requireActivity().getString(R.string.alert_delete_title));
                builder.setMessage(Html.fromHtml(Logo_BottomSheetfragment.this.getString(R.string.alert_delete_message)));
                builder.setPositiveButton(Logo_BottomSheetfragment.this.getString(R.string.yes), new DialogInterface.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.Logo_BottomSheetfragment.2.2
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        Logo_BottomSheetfragment.this.deleteLogo(i);
                        dialogInterface.dismiss();
                    }
                }).setNegativeButton(Logo_BottomSheetfragment.this.getString(R.string.no), new DialogInterface.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.Logo_BottomSheetfragment.2.1
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        dialogInterface.dismiss();
                    }
                });
                builder.create().show();
            }
        });
        this.rv_image.post(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.Logo_BottomSheetfragment.3
            @Override // java.lang.Runnable
            public void run() {
                Logo_BottomSheetfragment.this.progressBar.setVisibility(View.GONE);
                Logo_BottomSheetfragment.this.rv_image.setAdapter(Logo_BottomSheetfragment.this.logo_adapter);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void deleteLogo(int i) {
        this.image.remove(i);
        if (this.image.size() == 0) {
            this.lin_recentview.setVisibility(View.GONE);
            this.img_select.setImageResource(R.mipmap.ic_launcher);
            this.msp.setString(getContext(), "imge_logo", Default.LOGO_uri);
            this.msp.saveImageuriArray(this.image, SP.IMAGE_URI, getContext());
        } else {
            if (!this.image.contains(this.msp.getString(getContext(), "imge_logo", Default.LOGO_uri))) {
                if (i < 1) {
                    this.msp.setString(getContext(), "imge_logo", this.image.get(0));
                } else {
                    this.msp.setString(getContext(), "imge_logo", this.image.get(i - 1));
                }
            }
            this.img_select.setImageBitmap(Util.decodeBase64(this.msp.getString(getContext(), "imge_logo", Default.LOGO_uri)));
            Collections.reverse(this.image);
            this.msp.saveImageuriArray(this.image, SP.IMAGE_URI, getContext());
            setadapter();
        }
        this.onSelectlogo.Onselect();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void callImagePicker(Activity activity) {
        Intent addCategory = new Intent("android.intent.action.GET_CONTENT").setType("image/*").addCategory("android.intent.category.OPENABLE");
        if (Build.VERSION.SDK_INT >= 19) {
            addCategory.putExtra("android.intent.extra.MIME_TYPES", new String[]{"image/jpeg", "image/png"});
        }
        startActivityForResult(addCategory, 103);
    }

    @Override // androidx.fragment.app.Fragment
    public void onActivityResult(int i, int i2, Intent intent) {
        Uri output;
        super.onActivityResult(i, i2, intent);
        if (i2 != 0) {
            if (i == 103 && i2 == -1 && intent != null) {
                Uri data = intent.getData();
                if (data != null) {
                    startCrop(data);
                }
            } else if (i != 69 || (output = UCrop.getOutput(intent)) == null) {
            } else {
                try {
                    selectedImageGalary(output);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void selectedImageGalary(Uri uri) throws IOException {
        RoundImageView roundImageView = this.img_select;
        if (roundImageView != null && uri != null) {
            roundImageView.setImageURI(uri);
        }
        CPD.ShowDialog(requireActivity());
        Executors.newSingleThreadExecutor().execute(new AnonymousClass4(MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), uri), new Handler()));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.gpsmapcamera.geotagginglocationonphoto.fragment.Logo_BottomSheetfragment$4  reason: invalid class name */
    /* loaded from: classes.dex */
    public class AnonymousClass4 implements Runnable {
        final /* synthetic */ Bitmap val$bitmapSize;
        final /* synthetic */ Handler val$mHandler;

        AnonymousClass4(Bitmap bitmap, Handler handler) {
            this.val$bitmapSize = bitmap;
            this.val$mHandler = handler;
        }

        @Override // java.lang.Runnable
        public void run() {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            this.val$bitmapSize.compress(Bitmap.CompressFormat.PNG, 60, byteArrayOutputStream);
            final byte[] byteArray = byteArrayOutputStream.toByteArray();
            this.val$mHandler.post(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.Logo_BottomSheetfragment.4.1
                @Override // java.lang.Runnable
                public void run() {
                    Glide.with(Logo_BottomSheetfragment.this.requireActivity()).asBitmap().load(byteArray).apply((BaseRequestOptions<?>) new RequestOptions().override(150, 150)).listener(new RequestListener<Bitmap>() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.Logo_BottomSheetfragment.4.1.1
                        @Override // com.bumptech.glide.request.RequestListener
                        public boolean onLoadFailed(GlideException glideException, Object obj, Target<Bitmap> target, boolean z) {
                            return false;
                        }

                        @Override // com.bumptech.glide.request.RequestListener
                        public boolean onResourceReady(Bitmap bitmap, Object obj, Target<Bitmap> target, DataSource dataSource, boolean z) {
                            String encodeTobase64 = Util.encodeTobase64(Logo_BottomSheetfragment.this.compress(bitmap));
                            Collections.reverse(Logo_BottomSheetfragment.this.image);
                            if (Logo_BottomSheetfragment.this.image.size() < 10) {
                                Logo_BottomSheetfragment.this.image.add(encodeTobase64);
                            } else {
                                Logo_BottomSheetfragment.this.image.add(encodeTobase64);
                                Logo_BottomSheetfragment.this.image.remove(0);
                            }
                            Logo_BottomSheetfragment.this.msp.setString(Logo_BottomSheetfragment.this.getContext(), "imge_logo", encodeTobase64);
                            Logo_BottomSheetfragment.this.msp.saveImageuriArray(Logo_BottomSheetfragment.this.image, SP.IMAGE_URI, Logo_BottomSheetfragment.this.getContext());
                            CPD.DismissDialog();
                            Logo_BottomSheetfragment.this.onSelectlogo.Onselect();
                            return true;
                        }
                    }).submit();
                    Logo_BottomSheetfragment.this.dismiss();
                }
            });
        }
    }

    @Override // androidx.fragment.app.DialogFragment, android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        super.onDismiss(dialogInterface);
        new Handler().postDelayed(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.Logo_BottomSheetfragment.5
            @Override // java.lang.Runnable
            public void run() {
                Logo_BottomSheetfragment.this.onSelectlogo.Onselect();
            }
        }, 1000L);
    }

    public Bitmap compress(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        return BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
    }

    private void startCrop(Uri uri) {
        UCrop useSourceImageAspectRatio = UCrop.of(uri, Uri.fromFile(new File(getActivity().getCacheDir(), SAMPLE_CROPPED_IMAGE_NAME))).useSourceImageAspectRatio();
        UCrop.Options options = new UCrop.Options();
        options.setCompressionQuality(100);
        options.setHideBottomControls(false);
        options.setFreeStyleCropEnabled(true);
        options.setStatusBarColor(requireActivity().getResources().getColor(R.color.statusbar_color));
        useSourceImageAspectRatio.withOptions(options);
        useSourceImageAspectRatio.start(requireActivity());
    }
}