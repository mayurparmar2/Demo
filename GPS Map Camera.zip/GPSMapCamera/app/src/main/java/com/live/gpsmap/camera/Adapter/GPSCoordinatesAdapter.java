package com.live.gpsmap.camera.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import com.live.gpsmap.camera.Interface.OnRecyclerItemClickListener;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.Utils.Util;

public class GPSCoordinatesAdapter extends RecyclerView.Adapter<GPSCoordinatesAdapter.Holder> {
    Context mContext;
    Util mHelperClass = new Util();
    String[] mList;
    OnRecyclerItemClickListener mOnRecyclerItemClickListener;
    SP mSP;
    int selected_pos;

    public GPSCoordinatesAdapter(Context context, String[] strArr, OnRecyclerItemClickListener onRecyclerItemClickListener) {
        this.mContext = context;
        this.mList = strArr;
        this.mOnRecyclerItemClickListener = onRecyclerItemClickListener;
        this.mSP = new SP(this.mContext);
        this.selected_pos = this.mSP.getInteger(this.mContext, "lat_lng_type_temp_1", 0);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_date_time, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(Holder holder, int i) {
        holder.tv_dateFormat.setText(this.mList[i]);
        holder.txt_lat_log.setText(this.mHelperClass.getLatLong(this.mContext, i));
        if (this.selected_pos == i) {
            holder.img_selection.setVisibility(View.VISIBLE);
        } else {
            holder.img_selection.setVisibility(View.GONE);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.mList.length;
    }

    public void refAdapter(int i) {
        this.selected_pos = i;
        notifyDataSetChanged();
    }

    /* loaded from: classes.dex */
    public class Holder extends RecyclerView.ViewHolder {
        LinearLayout date_main_lay;
        ImageView img_selection;
        TextView tv_dateFormat;
        TextView txt_lat_log;

        public Holder(View view) {
            super(view);
            this.tv_dateFormat = (TextView) view.findViewById(R.id.tv_temp_name);
            this.txt_lat_log = (TextView) view.findViewById(R.id.txt_lat_log);
            this.date_main_lay = (LinearLayout) view.findViewById(R.id.dt_main_lay);
            this.img_selection = (ImageView) view.findViewById(R.id.img_selection);
            this.date_main_lay.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.adapter.GPSCoordinatesAdapter.Holder.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    if (Holder.this.getAdapterPosition() < 0 || GPSCoordinatesAdapter.this.mOnRecyclerItemClickListener == null) {
                        return;
                    }
                    GPSCoordinatesAdapter.this.mOnRecyclerItemClickListener.OnClick_(Holder.this.getAdapterPosition(), view2);
                }
            });
        }
    }
}