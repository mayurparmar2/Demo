package com.live.gpsmap.camera.os_notifications;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import androidx.appcompat.app.AlertDialog;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.live.gpsmap.camera.R;
import com.onesignal.OSNotificationOpenedResult;
import com.onesignal.OneSignal;
import com.live.gpsmap.camera.os_notifications.models.NotificationModel;
import org.json.JSONObject;

@SuppressWarnings("All")
public class OSNotificationHelper {
    static Context context;
    private static OSNotificationHelper helper;
    public static NotificationModel os_model;

    public OSNotificationHelper(Context context2) {
        context = context2;
    }

    public static OSNotificationHelper initOneSignal(Context context2, String str) {
        OneSignal.initWithContext(context2);
        OneSignal.setAppId(str);
        OSNotificationHelper oSNotificationHelper = new OSNotificationHelper(context2);
        helper = oSNotificationHelper;
        return oSNotificationHelper;
    }

    public OSNotificationHelper parseNotificationJson(final Activity activity) {
        OneSignal.setNotificationOpenedHandler(new OneSignal.OSNotificationOpenedHandler() { // from class: com.susamp.os_notifications.OSNotificationHelper$$ExternalSyntheticLambda4
            @Override // com.onesignal.OneSignal.OSNotificationOpenedHandler
            public final void notificationOpened(OSNotificationOpenedResult oSNotificationOpenedResult) {
                OSNotificationHelper.this.m909x3e7e1c1e(activity, oSNotificationOpenedResult);
            }
        });
        return helper;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$parseNotificationJson$0$com-susamp-os_notifications-OSNotificationHelper  reason: not valid java name */
    public /* synthetic */ void m909x3e7e1c1e(Activity activity, OSNotificationOpenedResult oSNotificationOpenedResult) {
        JSONObject additionalData = oSNotificationOpenedResult.getNotification().getAdditionalData();
        NotificationModel notificationModel = (NotificationModel) new Gson().fromJson(additionalData.toString(), new TypeToken<NotificationModel>() { // from class: com.susamp.os_notifications.OSNotificationHelper.1
        }.getType());
        os_model = notificationModel;
        NotificationParser.setNotificationModel(notificationModel);
        Intent intent = new Intent(context, activity.getClass());
        intent.setFlags(268566528);
        context.startActivity(intent);
    }

    public static OSNotificationHelper sendTag(String str, String str2) {
        OneSignal.sendTag(str, str2);
        return helper;
    }

    public static void showShareDialog(Context context2, int[] iArr, final ShareDialogBtnClickListener shareDialogBtnClickListener) {
        AlertDialog.Builder cancelable;
        NotificationModel notificationModel = os_model;
        if (notificationModel == null || !notificationModel.getType().equalsIgnoreCase("share")) {
            return;
        }
        if (iArr.length == 2) {
            if (isTablet(context2)) {
                cancelable = new AlertDialog.Builder(context2, iArr[1]).setCancelable(false);
            } else {
                cancelable = new AlertDialog.Builder(context2, iArr[0]).setCancelable(false);
            }
        } else {
            cancelable = new AlertDialog.Builder(context2).setCancelable(false);
        }
        cancelable.setTitle(notificationModel.getTitle()).setMessage(notificationModel.getMessage()).setPositiveButton(context2.getString(R.string.share_btn), new DialogInterface.OnClickListener() { // from class: com.susamp.os_notifications.OSNotificationHelper$$ExternalSyntheticLambda2
            @Override
            public final void onClick(DialogInterface dialogInterface, int i) {
                OSNotificationHelper.lambda$showShareDialog$1(shareDialogBtnClickListener, dialogInterface, i);
            }
        }).setNegativeButton(context2.getString(R.string.no_thanks_btn), new DialogInterface.OnClickListener() { // from class: com.susamp.os_notifications.OSNotificationHelper$$ExternalSyntheticLambda3
            @Override
            public final void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        AlertDialog create = cancelable.create();
        create.show();
        create.getButton(-1).setTextColor(Color.parseColor("#455a64"));
        create.getButton(-2).setTextColor(Color.parseColor("#455a64"));
        create.getButton(-3).setTextColor(Color.parseColor("#455a64"));
        os_model = null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$showShareDialog$1(ShareDialogBtnClickListener shareDialogBtnClickListener, DialogInterface dialogInterface, int i) {
        shareDialogBtnClickListener.onShareBtnClicked();
        dialogInterface.dismiss();
    }

    private static void openShareIntent(String str, String str2) {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.SUBJECT", context.getString(R.string.app_name));
        intent.putExtra("android.intent.extra.TEXT", str2);
        context.startActivity(Intent.createChooser(intent, str));
    }

    public static void showRateDialogNotification(Context context2, int[] iArr, final RateDialogBtnClickListener rateDialogBtnClickListener) {
        AlertDialog.Builder cancelable;
        NotificationModel notificationModel = os_model;
        if (notificationModel == null || !notificationModel.getType().equalsIgnoreCase("rate")) {
            return;
        }
        if (iArr.length == 2) {
            if (isTablet(context2)) {
                cancelable = new AlertDialog.Builder(context2, iArr[1]).setCancelable(false);
            } else {
                cancelable = new AlertDialog.Builder(context2, iArr[0]).setCancelable(false);
            }
        } else {
            cancelable = new AlertDialog.Builder(context2).setCancelable(false);
        }
        cancelable.setTitle(notificationModel.getTitle()).setMessage(notificationModel.getMessage()).setPositiveButton(context2.getString(R.string.rate_us), new DialogInterface.OnClickListener() { // from class: com.susamp.os_notifications.OSNotificationHelper$$ExternalSyntheticLambda0
            @Override
            public final void onClick(DialogInterface dialogInterface, int i) {
                OSNotificationHelper.lambda$showRateDialogNotification$3(rateDialogBtnClickListener, dialogInterface, i);
            }
        }).setNegativeButton(context2.getString(R.string.no_thanks_btn), new DialogInterface.OnClickListener() { // from class: com.susamp.os_notifications.OSNotificationHelper$$ExternalSyntheticLambda1
            @Override
            public final void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        AlertDialog create = cancelable.create();
        create.show();
        create.getButton(-1).setTextColor(Color.parseColor("#455a64"));
        create.getButton(-2).setTextColor(Color.parseColor("#455a64"));
        create.getButton(-3).setTextColor(Color.parseColor("#455a64"));
        os_model = null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$showRateDialogNotification$3(RateDialogBtnClickListener rateDialogBtnClickListener, DialogInterface dialogInterface, int i) {
        rateDialogBtnClickListener.onRateBtnClicked();
        dialogInterface.dismiss();
    }

    public static void showMessageDialog(Context context2, int[] iArr, final MessageDialogBtnClickListener messageDialogBtnClickListener) {
        AlertDialog.Builder cancelable;
        NotificationModel notificationModel = os_model;
        if (notificationModel == null || !notificationModel.getType().equalsIgnoreCase("message")) {
            return;
        }
        if (iArr.length == 2) {
            if (isTablet(context2)) {
                cancelable = new AlertDialog.Builder(context2, iArr[1]).setCancelable(false);
            } else {
                cancelable = new AlertDialog.Builder(context2, iArr[0]).setCancelable(false);
            }
        } else {
            cancelable = new AlertDialog.Builder(context2).setCancelable(false);
        }
        cancelable.setTitle(notificationModel.getTitle()).setMessage(notificationModel.getMessage()).setPositiveButton(context2.getString(R.string.ok), new DialogInterface.OnClickListener() { // from class: com.susamp.os_notifications.OSNotificationHelper$$ExternalSyntheticLambda7
            @Override
            public final void onClick(DialogInterface dialogInterface, int i) {
                OSNotificationHelper.lambda$showMessageDialog$5(messageDialogBtnClickListener, dialogInterface, i);
            }
        });
        AlertDialog create = cancelable.create();
        create.show();
        create.getButton(-1).setTextColor(Color.parseColor("#455a64"));
        os_model = null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$showMessageDialog$5(MessageDialogBtnClickListener messageDialogBtnClickListener, DialogInterface dialogInterface, int i) {
        dialogInterface.dismiss();
        messageDialogBtnClickListener.onMessageBtnClicked();
    }

    public static void showLinkDialogNotification(Context context2, int[] iArr, final LinkDialogBtnClickListener linkDialogBtnClickListener) {
        AlertDialog.Builder cancelable;
        final NotificationModel notificationModel = os_model;
        if (notificationModel == null || !notificationModel.getType().equalsIgnoreCase("link")) {
            return;
        }
        if (iArr.length == 2) {
            if (isTablet(context2)) {
                cancelable = new AlertDialog.Builder(context2, iArr[1]).setCancelable(false);
            } else {
                cancelable = new AlertDialog.Builder(context2, iArr[0]).setCancelable(false);
            }
        } else {
            cancelable = new AlertDialog.Builder(context2).setCancelable(false);
        }
        cancelable.setTitle(notificationModel.getTitle()).setMessage(notificationModel.getMessage()).setPositiveButton(context2.getString(R.string.open), new DialogInterface.OnClickListener() { // from class: com.susamp.os_notifications.OSNotificationHelper$$ExternalSyntheticLambda6
            @Override
            public final void onClick(DialogInterface dialogInterface, int i) {
                OSNotificationHelper.lambda$showLinkDialogNotification$6(linkDialogBtnClickListener, notificationModel, dialogInterface, i);
            }
        });
        AlertDialog create = cancelable.create();
        create.show();
        create.getButton(-1).setTextColor(Color.parseColor("#455a64"));
        os_model = null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$showLinkDialogNotification$6(LinkDialogBtnClickListener linkDialogBtnClickListener, NotificationModel notificationModel, DialogInterface dialogInterface, int i) {
        dialogInterface.dismiss();
        linkDialogBtnClickListener.onLinkBtnClicked(notificationModel.getUrl());
    }

    public static void showOfferDialogNotification(Context context2, int[] iArr, final OfferDialogBtnClickListener offerDialogBtnClickListener) {
        AlertDialog.Builder cancelable;
        NotificationModel notificationModel = os_model;
        if (notificationModel == null || !notificationModel.getType().equalsIgnoreCase("offer")) {
            return;
        }
        if (iArr.length == 2) {
            if (isTablet(context2)) {
                cancelable = new AlertDialog.Builder(context2, iArr[1]).setCancelable(false);
            } else {
                cancelable = new AlertDialog.Builder(context2, iArr[0]).setCancelable(false);
            }
        } else {
            cancelable = new AlertDialog.Builder(context2).setCancelable(false);
        }
        cancelable.setTitle(notificationModel.getTitle()).setMessage(notificationModel.getMessage()).setPositiveButton(context2.getString(R.string.pro), new DialogInterface.OnClickListener() { // from class: com.susamp.os_notifications.OSNotificationHelper$$ExternalSyntheticLambda5
            @Override
            public final void onClick(DialogInterface dialogInterface, int i) {
                OSNotificationHelper.lambda$showOfferDialogNotification$7(offerDialogBtnClickListener, dialogInterface, i);
            }
        });
        AlertDialog create = cancelable.create();
        create.show();
        create.getButton(-1).setTextColor(Color.parseColor("#455a64"));
        os_model = null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$showOfferDialogNotification$7(OfferDialogBtnClickListener offerDialogBtnClickListener, DialogInterface dialogInterface, int i) {
        dialogInterface.dismiss();
        offerDialogBtnClickListener.onOfferBtnClicked();
    }

    public static boolean isTablet(Context context2) {
        return (context2.getResources().getConfiguration().screenLayout & 15) >= 3;
    }
}
