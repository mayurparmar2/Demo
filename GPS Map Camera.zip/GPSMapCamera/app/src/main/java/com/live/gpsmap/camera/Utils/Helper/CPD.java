package com.live.gpsmap.camera.Utils.Helper;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.appcompat.app.AlertDialog;

import com.live.gpsmap.camera.R;

/* loaded from: classes2.dex */
public class CPD {
    static AlertDialog alertDialog;
    static AlertDialog.Builder builder;

    public static void ShowDialog(Activity activity) {
        builder = new AlertDialog.Builder(activity);
        builder.setView(LayoutInflater.from(activity).inflate(R.layout.custom_progress, (ViewGroup) activity.findViewById(16908290), false));
        builder.setCancelable(false);
        AlertDialog create = builder.create();
        alertDialog = create;
        if (create.isShowing()) {
            return;
        }
        alertDialog.show();
    }

    public static void DismissDialog() {
        AlertDialog alertDialog2 = alertDialog;
        if (alertDialog2 == null || !alertDialog2.isShowing()) {
            return;
        }
        alertDialog.dismiss();
    }
}