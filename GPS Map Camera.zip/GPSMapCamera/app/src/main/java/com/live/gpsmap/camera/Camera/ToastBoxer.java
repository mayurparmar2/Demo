package com.live.gpsmap.camera.Camera;

import android.widget.Toast;


public class ToastBoxer {
    public Toast toast;
}
