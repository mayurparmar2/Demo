package com.live.gpsmap.camera.os_notifications;

import com.live.gpsmap.camera.os_notifications.models.NotificationModel;

/* loaded from: classes2.dex */
public class NotificationParser {
    public static NotificationModel notificationModel;

    public static void setNotificationModel(NotificationModel notificationModel2) {
        notificationModel = notificationModel2;
    }

    public static NotificationModel getNotificationModel() {
        return notificationModel;
    }
}
