package com.live.gpsmap.camera.Camera.preview;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Handler;
import android.util.Log;
import android.view.View;


public class CanvasView extends View {
    private static final String TAG = "CanvasView";
    private final Handler handler;
    private final int[] measure_spec;
    private final Preview preview;
    private final Runnable tick;


    public CanvasView(Context context, final Preview preview) {
        super(context);
        this.measure_spec = new int[2];
        this.handler = new Handler();
        this.preview = preview;
        Log.d(TAG, "new CanvasView");
        this.tick = new Runnable() {
            @Override
            public void run() {
                preview.test_ticker_called = true;
                CanvasView.this.invalidate();
                CanvasView.this.handler.postDelayed(this, preview.getFrameRate());
            }
        };
    }

    @Override
    public void onDraw(Canvas canvas) {
        this.preview.draw(canvas);
    }

    @Override
    protected void onMeasure(int i, int i2) {
        Log.d(TAG, "onMeasure: " + i + " x " + i2);
        this.preview.getMeasureSpec(this.measure_spec, i, i2);
        int[] iArr = this.measure_spec;
        super.onMeasure(iArr[0], iArr[1]);
    }


    public void onPause() {
        Log.d(TAG, "onPause()");
        this.handler.removeCallbacks(this.tick);
    }


    public void onResume() {
        Log.d(TAG, "onResume()");
        this.tick.run();
    }
}
