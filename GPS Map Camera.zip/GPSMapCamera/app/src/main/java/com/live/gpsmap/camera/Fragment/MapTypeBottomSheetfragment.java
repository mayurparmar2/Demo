package com.live.gpsmap.camera.Fragment;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import com.live.gpsmap.camera.Adapter.FontstyleAdapter;
import com.live.gpsmap.camera.Adapter.GPSCoordinatesAdapter;
import com.live.gpsmap.camera.Adapter.MapAdapter;
import com.live.gpsmap.camera.Adapter.PlusCodeType_Adapter;
import com.live.gpsmap.camera.Adapter.StampSize_Adapter;
import com.live.gpsmap.camera.Adapter.Stampposition_Adapter;
import com.live.gpsmap.camera.Adapter.TempratureAdapeter;
import com.live.gpsmap.camera.Adapter.WindAdapter;
import com.live.gpsmap.camera.Interface.OnRecyclerItemClickListener;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Default;
import com.live.gpsmap.camera.Utils.SP;

public class MapTypeBottomSheetfragment extends BottomSheetDialogFragment {
    public static final String TAG = "MapTypeBottomSheetfragment";
    String[] Temprature;
    OnMapTypeSelectedListener callBack;
    Context context;
    String[] fontstyle;
    FontstyleAdapter fontstyleAdapter;
    String[] fontstyleList;
    private GPSCoordinatesAdapter gpsCoordinatesAdapter;
    private MapAdapter mAdapter;
    String[] mGPS_Coordinates_array;
    TypedArray mIconArray;
    String[] mMapArray;
    private SP mSP;
    PlusCodeType_Adapter plusCodeType_adapter;
    String[] pluscodetype;
    String[] pressure;
    RecyclerView rv_maptype;
    StampSize_Adapter stampSize_adapter;
    Stampposition_Adapter stampposition_adapter;
    String[] stamppostion;
    String[] stampsize;
    TempratureAdapeter tempratureAdapeter;
    TextView txt_title;
    int type = 0;
    String[] wind;
    WindAdapter windAdapter;

    /* loaded from: classes3.dex */
    public interface OnMapTypeSelectedListener {
        void OnFontselected();

        void OnPlusCodeTypechange();

        void OnStampPositionchange();

        void OnStampSizechange();

        void Onaccuracyselect();

        void Onaltitudeselect();

        void Onpressureselection();

        void Ontempraturechange();

        void Onwindselected();

        void onLatLngType();

        void onMapTypeSelected();
    }

    public void setOnMap_SelectedListener(OnMapTypeSelectedListener onMapTypeSelectedListener) {
        this.callBack = onMapTypeSelectedListener;
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.mSP = new SP(getActivity());
        if (getArguments() != null) {
            this.type = getArguments().getInt("type");
        }
    }

    @SuppressLint("RestrictedApi")
    @Override
    public void setupDialog(Dialog dialog, int i) {
        super.setupDialog(dialog, i);
        View inflate = View.inflate(getContext(), R.layout.map_type_bottom_sheet_fragment, null);
        this.rv_maptype = (RecyclerView) inflate.findViewById(R.id.rv_maptype);
        this.txt_title = (TextView) inflate.findViewById(R.id.txt_title);
        this.context = inflate.getContext();
        dialog.setContentView(inflate);
        init();
    }

    private void init() {
        int i = this.type;
        if (i == 1) {
            this.mMapArray = getResources().getStringArray(R.array.map_title_array);
            this.mIconArray = getResources().obtainTypedArray(R.array.map_icon_array);
            this.txt_title.setText(getString(R.string.map_type));
            setAdapter();
        } else if (i == 2) {
            this.mGPS_Coordinates_array = getResources().getStringArray(R.array.gps_coordinates_array);
            this.txt_title.setText(getString(R.string.lat_lng));
            setAdapterLATLog();
        } else if (i == 3) {
            this.Temprature = getResources().getStringArray(R.array.temprature);
            this.txt_title.setText(getString(R.string.weather));
            setAdapterTempratcure();
        } else if (i == 4) {
            this.mSP.setInteger(getActivity(), "STAMP_POS_OPEN_TIME", this.mSP.getInteger(getActivity(), "STAMP_POS_OPEN_TIME", 0) + 1);
            this.stamppostion = getResources().getStringArray(R.array.stamp_position);
            this.txt_title.setText(getString(R.string.stamp_pos));
            setAdapterposition();
        } else if (i == 5) {
            this.wind = getResources().getStringArray(R.array.wind);
            this.txt_title.setText(getString(R.string.wind));
            setAdapterwind(1);
        } else if (i == 6) {
            this.wind = getResources().getStringArray(R.array.pressure);
            this.txt_title.setText(getString(R.string.pressure));
            setAdapterwind(2);
        } else if (i == 7) {
            this.wind = getResources().getStringArray(R.array.altitude);
            this.txt_title.setText(getString(R.string.altitude));
            setAdapterwind(3);
        } else if (i == 8) {
            this.wind = getResources().getStringArray(R.array.altitude);
            this.txt_title.setText(getString(R.string.accuracy));
            setAdapterwind(4);
        } else if (i == 9) {
            this.mSP.setInteger(getActivity(), "FONT_STYLE_OPEN_TIME", this.mSP.getInteger(getActivity(), "FONT_STYLE_OPEN_TIME", 0) + 1);
            this.fontstyleList = getResources().getStringArray(R.array.fontstyle);
            this.fontstyle = this.context.getResources().getStringArray(R.array.fontstyle_assets);
            this.txt_title.setText(getString(R.string.font_style));
            setfontstyleadapter();
        } else if (i == 10) {
            this.stampsize = getResources().getStringArray(R.array.stamp_size);
            this.txt_title.setText(requireContext().getString(R.string.stamp_size));
            setAdapterSize();
        } else if (i == 11) {
            this.pluscodetype = getResources().getStringArray(R.array.pluscode_type);
            this.txt_title.setText(requireContext().getString(R.string.plus_code));
            setAdapterPlus();
        }
    }

    private void setfontstyleadapter() {
        this.rv_maptype.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        FontstyleAdapter fontstyleAdapter = new FontstyleAdapter(getActivity(), this.mSP.getInteger(getActivity(), SP.TEMPLATE_TYPE, 0), this.fontstyleList, this.fontstyle, new OnRecyclerItemClickListener() {
            @Override
            public void OnLongClick_(int i, View view) {
            }

            @Override
            public void OnClick_(int i, View view) {
                if (MapTypeBottomSheetfragment.this.mSP.getInteger(MapTypeBottomSheetfragment.this.context, SP.TEMPLATE_TYPE, 0) == 0) {
                    MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getActivity(), SP.STAMP_FONT_STYLE, MapTypeBottomSheetfragment.this.fontstyle[i]);
                    MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getActivity(), SP.STAMP_FONT_NAME, MapTypeBottomSheetfragment.this.fontstyleList[i]);
                } else {
                    MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getActivity(), SP.STAMP_FONT_STYLE_CLASSIC, MapTypeBottomSheetfragment.this.fontstyle[i]);
                    MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getActivity(), SP.STAMP_FONT_NAME_CLASSIC, MapTypeBottomSheetfragment.this.fontstyleList[i]);
                }
                if (MapTypeBottomSheetfragment.this.callBack != null) {
                    MapTypeBottomSheetfragment.this.callBack.OnFontselected();
                    MapTypeBottomSheetfragment.this.dismiss();
                }
            }
        });
        this.fontstyleAdapter = fontstyleAdapter;
        this.rv_maptype.setAdapter(fontstyleAdapter);
    }

    private void setAdapterwind(final int i) {
        this.rv_maptype.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        WindAdapter windAdapter = new WindAdapter(getActivity(), this.wind, i, new OnRecyclerItemClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.MapTypeBottomSheetfragment.2
            @Override
            public void OnLongClick_(int i2, View view) {
            }

            @Override
            public void OnClick_(int i2, View view) {
                int i3 = i;
                if (i3 == 1) {
                    MapTypeBottomSheetfragment.this.mSP.setInteger(MapTypeBottomSheetfragment.this.getActivity(), "wind_postion", i2);
                    if (MapTypeBottomSheetfragment.this.callBack != null) {
                        MapTypeBottomSheetfragment.this.callBack.Onwindselected();
                        MapTypeBottomSheetfragment.this.dismiss();
                    }
                } else if (i3 == 2) {
                    MapTypeBottomSheetfragment.this.mSP.setInteger(MapTypeBottomSheetfragment.this.getActivity(), "pressure_postion", i2);
                    if (MapTypeBottomSheetfragment.this.callBack != null) {
                        MapTypeBottomSheetfragment.this.callBack.Onpressureselection();
                        MapTypeBottomSheetfragment.this.dismiss();
                    }
                } else if (i3 == 3) {
                    MapTypeBottomSheetfragment.this.mSP.setInteger(MapTypeBottomSheetfragment.this.getActivity(), "altitude_position", i2);
                    if (MapTypeBottomSheetfragment.this.callBack != null) {
                        MapTypeBottomSheetfragment.this.callBack.Onaltitudeselect();
                        MapTypeBottomSheetfragment.this.dismiss();
                    }
                } else if (i3 == 4) {
                    MapTypeBottomSheetfragment.this.mSP.setInteger(MapTypeBottomSheetfragment.this.getActivity(), "accuracy_position", i2);
                    if (MapTypeBottomSheetfragment.this.callBack != null) {
                        MapTypeBottomSheetfragment.this.callBack.Onaccuracyselect();
                        MapTypeBottomSheetfragment.this.dismiss();
                    }
                }
            }
        });
        this.windAdapter = windAdapter;
        this.rv_maptype.setAdapter(windAdapter);
    }

    private void setAdapterposition() {
        this.rv_maptype.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        Stampposition_Adapter stampposition_Adapter = new Stampposition_Adapter(getActivity(), this.stamppostion, new OnRecyclerItemClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.MapTypeBottomSheetfragment.3
            @Override
            public void OnLongClick_(int i, View view) {
            }

            @Override
            public void OnClick_(int i, View view) {
                if (i == 0) {
                    MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getActivity(), "pos_type_temp", "Top");
                } else {
                    MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getActivity(), "pos_type_temp", "Bottom");
                }
                if (MapTypeBottomSheetfragment.this.callBack != null) {
                    MapTypeBottomSheetfragment.this.callBack.OnStampPositionchange();
                    MapTypeBottomSheetfragment.this.dismiss();
                }
            }
        });
        this.stampposition_adapter = stampposition_Adapter;
        this.rv_maptype.setAdapter(stampposition_Adapter);
    }

    private void setAdapterSize() {
        this.rv_maptype.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        StampSize_Adapter stampSize_Adapter = new StampSize_Adapter(requireContext(), this.stampsize, new OnRecyclerItemClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.MapTypeBottomSheetfragment.4
            @Override
            public void OnLongClick_(int i, View view) {
            }

            @Override
            public void OnClick_(int i, View view) {
                if (i == 0) {
                    MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getActivity(), "size_type_temp", "Large");
                } else if (i == 1) {
                    MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getActivity(), "size_type_temp", Default.TEMPLATE_SIZE);
                } else if (i == 2) {
                    MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getActivity(), "size_type_temp", "Small");
                } else {
                    MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getActivity(), "size_type_temp", "Extra Small");
                }
                if (MapTypeBottomSheetfragment.this.callBack != null) {
                    MapTypeBottomSheetfragment.this.callBack.OnStampSizechange();
                    MapTypeBottomSheetfragment.this.dismiss();
                }
            }
        });
        this.stampSize_adapter = stampSize_Adapter;
        this.rv_maptype.setAdapter(stampSize_Adapter);
    }

    private void setAdapterPlus() {
        this.rv_maptype.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        PlusCodeType_Adapter plusCodeType_Adapter = new PlusCodeType_Adapter(requireContext(), this.pluscodetype, new OnRecyclerItemClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.MapTypeBottomSheetfragment.5
            @Override
            public void OnLongClick_(int i, View view) {
            }

            @Override
            public void OnClick_(int i, View view) {
                if (i == 0) {
                    MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getActivity(), "plus_code_type", Default.PLUSCODE_TYPE);
                } else if (i == 1) {
                    MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getActivity(), "plus_code_type", Default.PLUSCODE_TYPE);
                }
                if (MapTypeBottomSheetfragment.this.callBack != null) {
                    MapTypeBottomSheetfragment.this.callBack.OnPlusCodeTypechange();
                    MapTypeBottomSheetfragment.this.dismiss();
                }
            }
        });
        this.plusCodeType_adapter = plusCodeType_Adapter;
        this.rv_maptype.setAdapter(plusCodeType_Adapter);
    }

    private void setAdapterTempratcure() {
        float f = this.mSP.getFloat(getActivity(), SP.TEMPRETURE_VALUE);
        this.rv_maptype.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        TempratureAdapeter tempratureAdapeter = new TempratureAdapeter(getContext(), this.Temprature, f, new OnRecyclerItemClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.MapTypeBottomSheetfragment.6
            @Override
            public void OnLongClick_(int i, View view) {
            }

            @Override
            public void OnClick_(final int i, View view) {
                new Handler().postDelayed(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.MapTypeBottomSheetfragment.6.1
                    @Override // java.lang.Runnable
                    public void run() {
                        if (i == 0) {
                            MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getActivity(), "temprature_type_temp", "Celsius");
                        } else {
                            MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getActivity(), "temprature_type_temp", "Celsius");
                        }
                        if (MapTypeBottomSheetfragment.this.callBack != null) {
                            MapTypeBottomSheetfragment.this.callBack.Ontempraturechange();
                            MapTypeBottomSheetfragment.this.dismiss();
                        }
                    }
                }, 50L);
            }
        });
        this.tempratureAdapeter = tempratureAdapeter;
        this.rv_maptype.setAdapter(tempratureAdapeter);
    }

    private void setAdapterLATLog() {
        this.rv_maptype.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        GPSCoordinatesAdapter gPSCoordinatesAdapter = new GPSCoordinatesAdapter(getContext(), this.mGPS_Coordinates_array, new OnRecyclerItemClickListener() {
            @Override
            public void OnLongClick_(int i, View view) {
            }

            @Override
            public void OnClick_(final int i, View view) {
                MapTypeBottomSheetfragment.this.mSP.setInteger(MapTypeBottomSheetfragment.this.getContext(), "lat_lng_type_temp_1", i);
                new Handler().postDelayed(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.MapTypeBottomSheetfragment.7.1
                    @Override // java.lang.Runnable
                    public void run() {
                        if (MapTypeBottomSheetfragment.this.gpsCoordinatesAdapter != null) {
                            MapTypeBottomSheetfragment.this.gpsCoordinatesAdapter.refAdapter(i);
                        }
                        if (MapTypeBottomSheetfragment.this.callBack != null) {
                            MapTypeBottomSheetfragment.this.callBack.onLatLngType();
                            MapTypeBottomSheetfragment.this.dismiss();
                        }
                    }
                }, 50L);
            }
        });
        this.gpsCoordinatesAdapter = gPSCoordinatesAdapter;
        this.rv_maptype.setAdapter(gPSCoordinatesAdapter);
    }

    private void setAdapter() {
        this.rv_maptype.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        MapAdapter mapAdapter = new MapAdapter(getContext(), this.mMapArray, this.mIconArray, new OnRecyclerItemClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.MapTypeBottomSheetfragment.8
            @Override
            public void OnLongClick_(int i, View view) {
            }

            @Override
            public void OnClick_(final int i, View view) {
                MapTypeBottomSheetfragment.this.mSP.setInteger(MapTypeBottomSheetfragment.this.getContext(), "map_type_temp_pos", i);
                if (i == 0) {
                    MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getContext(), "map_type_temp", Default.NORMAL_1);
                } else if (i == 1) {
                    MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getContext(), "map_type_temp", Default.SETELLITE_2);
                } else if (i == 2) {
                    MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getContext(), "map_type_temp", Default.TERRAIN_3);
                } else if (i == 3) {
                    MapTypeBottomSheetfragment.this.mSP.setString(MapTypeBottomSheetfragment.this.getContext(), "map_type_temp", Default.HYBRID_4);
                }
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        MapTypeBottomSheetfragment.this.mAdapter.refAdapter(i);
                        if (MapTypeBottomSheetfragment.this.callBack != null) {
                            MapTypeBottomSheetfragment.this.callBack.onMapTypeSelected();
                            MapTypeBottomSheetfragment.this.dismiss();
                        }
                    }
                }, 50L);
            }
        });
        this.mAdapter = mapAdapter;
        this.rv_maptype.setAdapter(mapAdapter);
    }
}