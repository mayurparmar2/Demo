package com.live.gpsmap.camera.Camera;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class GyroSensor implements SensorEventListener {
    private static final float NS2S = 1.0E-9f;
    private static final String TAG = "GyroSensor";
    private boolean hasTarget;
    private boolean has_gyroVector;
    private boolean has_lastTargetAngle;
    private boolean has_original_rotation_matrix;
    private boolean has_rotationVector;
    private boolean is_recording;
    private int is_upright;
    private float lastTargetAngle;
    private final Sensor mSensor;
    private final Sensor mSensorAccel;
    private final SensorManager mSensorManager;
    private boolean targetAchieved;
    private float targetAngle;
    private TargetCallback targetCallback;
    private long timestamp;
    private float tooFarAngle;
    private float uprightAngleTol;
    private final float[] deltaRotationVector = new float[4];
    private final float[] gyroVector = new float[3];
    private final float[] currentRotationMatrix = new float[9];
    private final float[] currentRotationMatrixGyroOnly = new float[9];
    private final float[] deltaRotationMatrix = new float[9];
    private final float[] tempMatrix = new float[9];
    private final float[] temp2Matrix = new float[9];
    private boolean has_init_accel = false;
    private final float[] initAccelVector = new float[3];
    private final float[] accelVector = new float[3];
    private final float[] originalRotationMatrix = new float[9];
    private final float[] rotationVector = new float[3];
    private final float[] tempVector = new float[3];
    private final float[] inVector = new float[3];
    private final List<float[]> targetVectors = new ArrayList();

    /* loaded from: classes.dex */
    public interface TargetCallback {
        void onAchieved(int i);

        void onTooFar();
    }

    @Override // android.hardware.SensorEventListener
    public void onAccuracyChanged(Sensor sensor, int i) {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public GyroSensor(Context context) {
        SensorManager sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        this.mSensorManager = sensorManager;
        Sensor defaultSensor = sensorManager.getDefaultSensor(4);
        this.mSensor = defaultSensor;
        Sensor defaultSensor2 = sensorManager.getDefaultSensor(1);
        this.mSensorAccel = defaultSensor2;
        Log.d(TAG, TAG);
        if (defaultSensor == null) {
            Log.d(TAG, "gyroscope not available");
        } else if (defaultSensor2 == null) {
            Log.d(TAG, "accelerometer not available");
        }
        setToIdentity();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean hasSensors() {
        return (this.mSensor == null || this.mSensorAccel == null) ? false : true;
    }

    private void setToIdentity() {
        for (int i = 0; i < 9; i++) {
            this.currentRotationMatrix[i] = 0.0f;
        }
        float[] fArr = this.currentRotationMatrix;
        fArr[0] = 1.0f;
        fArr[4] = 1.0f;
        fArr[8] = 1.0f;
        System.arraycopy(fArr, 0, this.currentRotationMatrixGyroOnly, 0, 9);
        for (int i2 = 0; i2 < 3; i2++) {
            this.initAccelVector[i2] = 0.0f;
        }
        this.has_init_accel = false;
        this.has_original_rotation_matrix = false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setVector(float[] fArr, float f, float f2, float f3) {
        fArr[0] = f;
        fArr[1] = f2;
        fArr[2] = f3;
    }

    private static float getMatrixComponent(float[] fArr, int i, int i2) {
        return fArr[(i * 3) + i2];
    }

    private static void setMatrixComponent(float[] fArr, int i, int i2, float f) {
        fArr[(i * 3) + i2] = f;
    }

    public static void transformVector(float[] fArr, float[] fArr2, float[] fArr3) {
        for (int i = 0; i < 3; i++) {
            fArr[i] = 0.0f;
            for (int i2 = 0; i2 < 3; i2++) {
                fArr[i] = fArr[i] + (getMatrixComponent(fArr2, i, i2) * fArr3[i2]);
            }
        }
    }

    private void transformTransposeVector(float[] fArr, float[] fArr2, float[] fArr3) {
        for (int i = 0; i < 3; i++) {
            fArr[i] = 0.0f;
            for (int i2 = 0; i2 < 3; i2++) {
                fArr[i] = fArr[i] + (getMatrixComponent(fArr2, i2, i) * fArr3[i2]);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void enableSensors() {
        Log.d(TAG, "enableSensors");
        this.has_rotationVector = false;
        this.has_gyroVector = false;
        for (int i = 0; i < 3; i++) {
            this.accelVector[i] = 0.0f;
            this.rotationVector[i] = 0.0f;
            this.gyroVector[i] = 0.0f;
        }
        Sensor sensor = this.mSensor;
        if (sensor != null) {
            this.mSensorManager.registerListener(this, sensor, 2);
        }
        Sensor sensor2 = this.mSensorAccel;
        if (sensor2 != null) {
            this.mSensorManager.registerListener(this, sensor2, 2);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void disableSensors() {
        Log.d(TAG, "disableSensors");
        this.mSensorManager.unregisterListener(this);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void startRecording() {
        Log.d(TAG, "startRecording");
        this.is_recording = true;
        this.timestamp = 0L;
        setToIdentity();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void stopRecording() {
        if (this.is_recording) {
            Log.d(TAG, "stopRecording");
            this.is_recording = false;
            this.timestamp = 0L;
        }
    }

    public boolean isRecording() {
        return this.is_recording;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void setTarget(float f, float f2, float f3, float f4, float f5, float f6, TargetCallback targetCallback) {
        this.hasTarget = true;
        this.targetVectors.clear();
        addTarget(f, f2, f3);
        this.targetAngle = f4;
        this.uprightAngleTol = f5;
        this.tooFarAngle = f6;
        this.targetCallback = targetCallback;
        this.has_lastTargetAngle = false;
        this.lastTargetAngle = 0.0f;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void addTarget(float f, float f2, float f3) {
        this.targetVectors.add(new float[]{f, f2, f3});
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void clearTarget() {
        this.hasTarget = false;
        this.targetVectors.clear();
        this.targetCallback = null;
        this.has_lastTargetAngle = false;
        this.lastTargetAngle = 0.0f;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void disableTargetCallback() {
        this.targetCallback = null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean hasTarget() {
        return this.hasTarget;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean isTargetAchieved() {
        return this.hasTarget && this.targetAchieved;
    }

    public int isUpright() {
        return this.is_upright;
    }

    private void adjustGyroForAccel() {
        if (this.timestamp != 0 && this.has_init_accel) {
            transformVector(this.tempVector, this.currentRotationMatrix, this.accelVector);
            float[] fArr = this.tempVector;
            float f = fArr[0];
            float[] fArr2 = this.initAccelVector;
            double d = (f * fArr2[0]) + (fArr[1] * fArr2[1]) + (fArr[2] * fArr2[2]);
            if (d >= 0.99999999995d) {
                return;
            }
            double cos = Math.cos(Math.acos(d) * 0.019999999552965164d);
            float[] fArr3 = this.tempVector;
            float f2 = fArr3[1];
            float[] fArr4 = this.initAccelVector;
            float f3 = fArr4[2];
            float f4 = fArr3[2];
            float f5 = fArr4[1];
            double d2 = (f2 * f3) - (f4 * f5);
            float f6 = fArr4[0];
            float f7 = fArr3[0];
            double d3 = (f4 * f6) - (f3 * f7);
            double d4 = (f7 * f5) - (f2 * f6);
            double sqrt = Math.sqrt((d2 * d2) + (d3 * d3) + (d4 * d4));
            if (sqrt < 1.0E-5d) {
                return;
            }
            double d5 = d2 / sqrt;
            double d6 = d3 / sqrt;
            double d7 = d4 / sqrt;
            double sqrt2 = Math.sqrt(1.0d - (cos * cos));
            double d8 = 1.0d - cos;
            setMatrixComponent(this.tempMatrix, 0, 0, (float) ((d5 * d5 * d8) + cos));
            double d9 = d5 * d6 * d8;
            double d10 = sqrt2 * d7;
            setMatrixComponent(this.tempMatrix, 0, 1, (float) (d9 - d10));
            double d11 = d5 * d7 * d8;
            double d12 = sqrt2 * d6;
            setMatrixComponent(this.tempMatrix, 0, 2, (float) (d11 + d12));
            setMatrixComponent(this.tempMatrix, 1, 0, (float) (d9 + d10));
            setMatrixComponent(this.tempMatrix, 1, 1, (float) ((d6 * d6 * d8) + cos));
            double d13 = d6 * d7 * d8;
            double d14 = sqrt2 * d5;
            setMatrixComponent(this.tempMatrix, 1, 2, (float) (d13 - d14));
            setMatrixComponent(this.tempMatrix, 2, 0, (float) (d11 - d12));
            setMatrixComponent(this.tempMatrix, 2, 1, (float) (d13 + d14));
            setMatrixComponent(this.tempMatrix, 2, 2, (float) ((d7 * d7 * d8) + cos));
            for (int i = 0; i < 3; i++) {
                for (int i2 = 0; i2 < 3; i2++) {
                    float f8 = 0.0f;
                    for (int i3 = 0; i3 < 3; i3++) {
                        f8 += getMatrixComponent(this.tempMatrix, i, i3) * getMatrixComponent(this.currentRotationMatrix, i3, i2);
                    }
                    setMatrixComponent(this.temp2Matrix, i, i2, f8);
                }
            }
            System.arraycopy(this.temp2Matrix, 0, this.currentRotationMatrix, 0, 9);
        }
    }


    @Override  // android.hardware.SensorEventListener
    public void onSensorChanged(SensorEvent sensorEvent0) {
        GyroSensor gyroSensor0 = this;
        SensorEvent sensorEvent1 = sensorEvent0;
        if(sensorEvent1.sensor.getType() == 1) {
            int v;
            for(v = 0; v < 3; ++v) {
                gyroSensor0.accelVector[v] = gyroSensor0.accelVector[v] * 0.8f + sensorEvent1.values[v] * 0.2f;
            }

            double f = Math.sqrt(gyroSensor0.accelVector[0] * gyroSensor0.accelVector[0] + gyroSensor0.accelVector[1] * gyroSensor0.accelVector[1] + gyroSensor0.accelVector[2] * gyroSensor0.accelVector[2]);
            if(f > 1.000000E-08) {
                gyroSensor0.accelVector[0] = (float)(((double)gyroSensor0.accelVector[0]) / f);
                gyroSensor0.accelVector[1] = (float)(((double)gyroSensor0.accelVector[1]) / f);
                gyroSensor0.accelVector[2] = (float)(((double)gyroSensor0.accelVector[2]) / f);
            }

            if(!gyroSensor0.has_init_accel) {
                System.arraycopy(gyroSensor0.accelVector, 0, gyroSensor0.initAccelVector, 0, 3);
                gyroSensor0.has_init_accel = true;
            }

            this.adjustGyroForAccel();
        }
        else if(sensorEvent1.sensor.getType() == 4) {
            if(gyroSensor0.has_gyroVector) {
                int v1;
                for(v1 = 0; v1 < 3; ++v1) {
                    gyroSensor0.gyroVector[v1] = gyroSensor0.gyroVector[v1] * 0.5f + sensorEvent1.values[v1] * 0.5f;
                }
            }
            else {
                System.arraycopy(sensorEvent1.values, 0, gyroSensor0.gyroVector, 0, 3);
                gyroSensor0.has_gyroVector = true;
            }

            if(gyroSensor0.timestamp != 0L) {
                float f1 = ((float)(sensorEvent1.timestamp - gyroSensor0.timestamp)) * 1.000000E-09f;
                float f2 = gyroSensor0.gyroVector[0];
                float f3 = gyroSensor0.gyroVector[1];
                float f4 = gyroSensor0.gyroVector[2];
                double f5 = Math.sqrt(f2 * f2 + f3 * f3 + f4 * f4);
                if(f5 > 0.00001) {
                    f2 = (float)(((double)f2) / f5);
                    f3 = (float)(((double)f3) / f5);
                    f4 = (float)(((double)f4) / f5);
                }

                double f6 = f5 * ((double)f1) / 2.0;
                float f7 = (float)Math.sin(f6);
                gyroSensor0.deltaRotationVector[0] = f2 * f7;
                gyroSensor0.deltaRotationVector[1] = f3 * f7;
                gyroSensor0.deltaRotationVector[2] = f7 * f4;
                gyroSensor0.deltaRotationVector[3] = (float)Math.cos(f6);
                SensorManager.getRotationMatrixFromVector(gyroSensor0.deltaRotationMatrix, gyroSensor0.deltaRotationVector);
                int v2;
                for(v2 = 0; v2 < 3; ++v2) {
                    int v3;
                    for(v3 = 0; v3 < 3; ++v3) {
                        float f8 = 0.0f;
                        int v4;
                        for(v4 = 0; v4 < 3; ++v4) {
                            float f9 = GyroSensor.getMatrixComponent(gyroSensor0.deltaRotationMatrix, v4, v3);
                            f8 += GyroSensor.getMatrixComponent(gyroSensor0.currentRotationMatrix, v2, v4) * f9;
                        }

                        GyroSensor.setMatrixComponent(gyroSensor0.tempMatrix, v2, v3, f8);
                    }
                }

                System.arraycopy(gyroSensor0.tempMatrix, 0, gyroSensor0.currentRotationMatrix, 0, 9);
                int v5;
                for(v5 = 0; v5 < 3; ++v5) {
                    int v6;
                    for(v6 = 0; v6 < 3; ++v6) {
                        float f10 = 0.0f;
                        int v7;
                        for(v7 = 0; v7 < 3; ++v7) {
                            float f11 = GyroSensor.getMatrixComponent(gyroSensor0.deltaRotationMatrix, v7, v6);
                            f10 += GyroSensor.getMatrixComponent(gyroSensor0.currentRotationMatrixGyroOnly, v5, v7) * f11;
                        }

                        GyroSensor.setMatrixComponent(gyroSensor0.tempMatrix, v5, v6, f10);
                    }
                }

                System.arraycopy(gyroSensor0.tempMatrix, 0, gyroSensor0.currentRotationMatrixGyroOnly, 0, 9);
                this.adjustGyroForAccel();
            }

            gyroSensor0.timestamp = sensorEvent1.timestamp;
        }
        else if(sensorEvent1.sensor.getType() == 11 || sensorEvent1.sensor.getType() == 15) {
            if(gyroSensor0.has_rotationVector) {
                int v8;
                for(v8 = 0; v8 < 3; ++v8) {
                    gyroSensor0.rotationVector[v8] = gyroSensor0.rotationVector[v8] * 0.8f + sensorEvent1.values[v8] * 0.2f;
                }
            }
            else {
                System.arraycopy(sensorEvent1.values, 0, gyroSensor0.rotationVector, 0, 3);
                gyroSensor0.has_rotationVector = true;
            }

            SensorManager.getRotationMatrixFromVector(gyroSensor0.tempMatrix, gyroSensor0.rotationVector);
            if(!gyroSensor0.has_original_rotation_matrix) {
                System.arraycopy(gyroSensor0.tempMatrix, 0, gyroSensor0.originalRotationMatrix, 0, 9);
                gyroSensor0.has_original_rotation_matrix = ((double)sensorEvent1.values[3]) != 1.0;
            }

            int v9;
            for(v9 = 0; v9 < 3; ++v9) {
                int v10;
                for(v10 = 0; v10 < 3; ++v10) {
                    float f12 = 0.0f;
                    int v11;
                    for(v11 = 0; v11 < 3; ++v11) {
                        float f13 = GyroSensor.getMatrixComponent(gyroSensor0.tempMatrix, v11, v10);
                        f12 += GyroSensor.getMatrixComponent(gyroSensor0.originalRotationMatrix, v11, v9) * f13;
                    }

                    GyroSensor.setMatrixComponent(gyroSensor0.currentRotationMatrix, v9, v10, f12);
                }
            }

            Log.d("GyroSensor", "### values: " + sensorEvent1.values[0] + " , " + sensorEvent1.values[1] + " , " + sensorEvent1.values[2] + " , " + sensorEvent1.values[3]);
            Log.d("GyroSensor", "    " + gyroSensor0.currentRotationMatrix[0] + " , " + gyroSensor0.currentRotationMatrix[1] + " , " + gyroSensor0.currentRotationMatrix[2]);
            Log.d("GyroSensor", "    " + gyroSensor0.currentRotationMatrix[3] + " , " + gyroSensor0.currentRotationMatrix[4] + " , " + gyroSensor0.currentRotationMatrix[5]);
            Log.d("GyroSensor", "    " + gyroSensor0.currentRotationMatrix[6] + " , " + gyroSensor0.currentRotationMatrix[7] + " , " + gyroSensor0.currentRotationMatrix[8]);
        }

        if(gyroSensor0.hasTarget) {
            gyroSensor0.targetAchieved = false;
            int v12 = 0;
            int v13 = 0;
            while(v12 < gyroSensor0.targetVectors.size()) {
                float[] arr_f = (float[])gyroSensor0.targetVectors.get(v12);
                GyroSensor.setVector(gyroSensor0.inVector, 0.0f, 1.0f, 0.0f);
                GyroSensor.transformVector(gyroSensor0.tempVector, gyroSensor0.currentRotationMatrix, gyroSensor0.inVector);
                gyroSensor0.is_upright = 0;
                float f14 = gyroSensor0.tempVector[0];
                float f15 = gyroSensor0.tempVector[1];
                float f16 = gyroSensor0.tempVector[2];
                float f17 = arr_f[0];
                float f18 = arr_f[1];
                float f19 = f14 * f17 + f15 * f18 + f16 * arr_f[2];
                float f20 = f14 - f17 * f19;
                float f21 = f15 - f18 * f19;
                float f22 = f16 - f19 * arr_f[2];
                double f23 = Math.sqrt(f20 * f20 + f21 * f21 + f22 * f22);
                if(f23 > 0.00001) {
                    float f24 = (float)(((double)f20) / f23);
                    float f25 = -((float)(((double)f22) / f23));
                    GyroSensor.setVector(gyroSensor0.inVector, 0.0f, 0.0f, -1.0f);
                    GyroSensor.transformVector(gyroSensor0.tempVector, gyroSensor0.currentRotationMatrix, gyroSensor0.inVector);
                    if(Math.abs(((float)Math.asin(((float)Math.sqrt(f25 * f25 + f24 * f24))))) > gyroSensor0.uprightAngleTol) {
                        gyroSensor0.is_upright = f25 * gyroSensor0.tempVector[0] + f24 * gyroSensor0.tempVector[2] >= 0.0f ? -1 : 1;
                    }
                }

                float f26 = (float)Math.acos(gyroSensor0.tempVector[0] * arr_f[0] + gyroSensor0.tempVector[1] * arr_f[1] + gyroSensor0.tempVector[2] * arr_f[2]);
                if(gyroSensor0.is_upright == 0 && f26 <= gyroSensor0.targetAngle) {
                    Log.d("GyroSensor", "    ### achieved target angle: " + Math.toDegrees(f26) + " degrees");
                    gyroSensor0.targetAchieved = true;
                    if(gyroSensor0.targetCallback != null && (gyroSensor0.has_lastTargetAngle)) {
                        Log.d("GyroSensor", "        last target angle: " + Math.toDegrees(gyroSensor0.lastTargetAngle) + " degrees");
                        if(f26 > gyroSensor0.lastTargetAngle) {
                            gyroSensor0.targetCallback.onAchieved(v12);
                        }
                    }

                    gyroSensor0.has_lastTargetAngle = true;
                    gyroSensor0.lastTargetAngle = f26;
                }

                if(f26 > gyroSensor0.tooFarAngle) {
                    ++v13;
                }

                ++v12;
            }

            if(v13 > 0 && v13 == gyroSensor0.targetVectors.size()) {
                TargetCallback gyroSensor$TargetCallback0 = gyroSensor0.targetCallback;
                if(gyroSensor$TargetCallback0 != null) {
                    gyroSensor$TargetCallback0.onTooFar();
                }
            }
        }
    }
    public void getRelativeInverseVector(float[] fArr, float[] fArr2) {
        transformTransposeVector(fArr, this.currentRotationMatrix, fArr2);
    }

    public void getRelativeInverseVectorGyroOnly(float[] fArr, float[] fArr2) {
        transformTransposeVector(fArr, this.currentRotationMatrixGyroOnly, fArr2);
    }

    public void getRotationMatrix(float[] fArr) {
        System.arraycopy(this.currentRotationMatrix, 0, fArr, 0, 9);
    }

    public void testForceTargetAchieved(int i) {
        Log.d(TAG, "testForceTargetAchieved: " + i);
        TargetCallback targetCallback = this.targetCallback;
        if (targetCallback != null) {
            targetCallback.onAchieved(i);
        }
    }
}
