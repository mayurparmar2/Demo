package com.live.gpsmap.camera.Camera.preview;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.hardware.SensorEvent;
import android.hardware.SensorManager;
import android.location.Location;
import android.media.CamcorderProfile;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.ParcelFileDescriptor;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RSInvalidStateException;
import android.renderscript.RenderScript;
import android.renderscript.Type;
import android.util.Log;
import android.util.Pair;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.OrientationEventListener;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.common.ConnectionResult;
import com.gpfreetech.awesomescanner.util.BarcodeUtils;
import com.live.gpsmap.camera.Camera.CameraMainActivity;
import com.live.gpsmap.camera.Camera.MyDebug;
import com.live.gpsmap.camera.Camera.PreferenceKeys;
import com.live.gpsmap.camera.Camera.Script.ScriptC_histogram_compute;
import com.live.gpsmap.camera.Camera.TakePhoto;
import com.live.gpsmap.camera.Camera.ToastBoxer;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraController;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraController1;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraController2;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraControllerException;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraControllerManager;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraControllerManager1;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraControllerManager2;
import com.live.gpsmap.camera.Camera.cameracontroller.RawImage;
import com.live.gpsmap.camera.Camera.preview.camerasurface.CameraSurface;
import com.live.gpsmap.camera.Camera.preview.camerasurface.MySurfaceView;
import com.live.gpsmap.camera.Camera.preview.camerasurface.MyTextureView;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.SP;

import java.io.File;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;


@SuppressWarnings("All")
public class Preview implements SurfaceHolder.Callback, TextureView.SurfaceTextureListener {
    private static final int FOCUS_DONE = 3;
    private static final int FOCUS_FAILED = 2;
    private static final int FOCUS_SUCCESS = 1;
    private static final int FOCUS_WAITING = 0;
    private static final int PHASE_NORMAL = 0;
    private static final int PHASE_PREVIEW_PAUSED = 3;
    private static final int PHASE_TAKING_PHOTO = 2;
    private static final int PHASE_TIMER = 1;
    private static final String TAG = "Preview";
    private static final long min_safe_restart_video_time = 1000;
    private static final float sensor_alpha = 0.8f;
    private final AccessibilityManager accessibility_manager;
    private List<String> antibanding;
    private final ApplicationInterface applicationInterface;
    private double aspect_ratio = 0.0f;
    private boolean autofocus_in_continuous_mode;
    private TimerTask batteryCheckVideoTimerTask;
    private TimerTask beepTimerTask;
    private final CameraSurface cameraSurface;
    private CameraController camera_controller;
    private final CameraControllerManager camera_controller_manager;
    private boolean camera_controller_supports_zoom;
    private boolean can_disable_shutter_sound;
    private CanvasView canvasView;
    private CloseCameraTask close_camera_task;
    private List<String> color_effects;
    private boolean continuous_focus_move_is_started;
    public volatile int count_cameraAutoFocus;
    public volatile int count_cameraContinuousFocusMoving;
    public volatile int count_cameraStartPreview;
    public volatile int count_cameraTakePicture;
    private int current_orientation;
    private int current_rotation;
    private List<String> edge_modes;
    private float exposure_step;
    private List<String> exposures;
    private CameraController.Face[] faces_detected;
    private TimerTask flashVideoTimerTask;
    private Bitmap focus_peaking_bitmap;
    private Bitmap focus_peaking_bitmap_buffer;
    private int focus_screen_x;
    private int focus_screen_y;
    private final GestureDetector gestureDetector;
    private boolean has_aspect_ratio;
    private boolean has_capture_rate_factor;
    private boolean has_focus_area;
    private boolean has_geo_direction;
    private boolean has_geomagnetic;
    private boolean has_gravity;
    private boolean has_level_angle;
    private boolean has_pitch_angle;
    private boolean has_surface;
    private boolean has_zoom;
    private int[] histogram;
    private ScriptC_histogram_compute histogramScript;
    private boolean is_exposure_lock_supported;
    private boolean is_exposure_locked;
    private boolean is_preview_started;
    private boolean is_test;
    private boolean is_video;
    private boolean is_white_balance_lock_supported;
    private boolean is_white_balance_locked;
    private List<String> isos;
    private long last_histogram_time_ms;
    private long last_preview_bitmap_time_ms;
    private Toast last_toast;
    private long last_toast_time_ms;
    private double level_angle;
    SP mSP;
    public CameraMainActivity mainActivity;
    private int max_expo_bracketing_n_images;
    private int max_exposure;
    private long max_exposure_time;
    private int max_iso;
    private int max_num_focus_areas;
    private int max_temperature;
    private int max_zoom_factor;
    private int min_exposure;
    private long min_exposure_time;
    private int min_iso;
    private int min_temperature;
    private float minimum_focus_distance;
    private double natural_level_angle;
    private VideoFileInfo nextVideoFileInfo;
    private List<String> noise_reduction_modes;
    private AsyncTask<Void, Void, CameraController> open_camera_task;
    private OrientationEventListener orientationEventListener;
    private double orig_level_angle;
    private ApplicationInterface.CameraResolutionConstraints photo_size_constraints;
    private List<CameraController.Size> photo_sizes;
    private double pitch_angle;
    private Bitmap preview_bitmap;
    private int preview_h;
    private double preview_targetRatio;
    private int preview_w;
    private RefreshPreviewBitmapTask refreshPreviewBitmapTask;
    private int remaining_repeat_photos;
    private int remaining_restart_video;
    private Runnable reset_continuous_focus_runnable;
    private RenderScript rs;
    private final ScaleGestureDetector scaleGestureDetector;
    private List<String> scene_modes;
    private boolean set_preview_size;
    private boolean set_textureview_size;
    private boolean successfully_focused;
    private float[] supported_apertures;
    private List<String> supported_flash_values;
    private List<String> supported_focus_values;
    private List<CameraController.Size> supported_preview_sizes;
    private boolean supports_burst;
    private boolean supports_expo_bracketing;
    private boolean supports_exposure_time;
    private boolean supports_face_detection;
    private boolean supports_focus_bracketing;
    private boolean supports_iso_range;
    private boolean supports_optical_stabilization;
    private boolean supports_photo_video_recording;
    private boolean supports_raw;
    private boolean supports_tonemap_curve;
    private boolean supports_video;
    private boolean supports_video_high_speed;
    private boolean supports_video_stabilization;
    private boolean supports_white_balance_temperature;
    private TimerTask takePictureTimerTask;
    private boolean take_photo_after_autofocus;
    private long take_photo_time;
    public volatile boolean test_burst_resolution;
    public volatile boolean test_called_next_output_file;
    public volatile boolean test_fail_open_camera;
    public volatile boolean test_runtime_on_video_stop;
    public volatile boolean test_started_next_output_file;
    public volatile boolean test_ticker_called;
    public volatile boolean test_video_cameracontrollerexception;
    public volatile boolean test_video_failure;
    public volatile boolean test_video_ioexception;
    private int textureview_h;
    private int textureview_w;
    private int tonemap_max_curve_points;
    private float touch_orig_x;
    private float touch_orig_y;
    private boolean touch_was_multitouch;
    private int ui_rotation;
    private final boolean using_android_l;
    private boolean using_face_detection;
    private long video_accumulated_time;
    private boolean video_high_speed;
    private volatile MediaRecorder video_recorder;
    private boolean video_recorder_is_paused;
    private boolean video_restart_on_max_filesize;
    private long video_start_time;
    private volatile boolean video_start_time_set;
    private float view_angle_x;
    private float view_angle_y;
    private boolean want_focus_peaking;
    private boolean want_histogram;
    private boolean want_preview_bitmap;
    private boolean want_zebra_stripes;
    private List<String> white_balances;
    private Bitmap zebra_stripes_bitmap;
    private Bitmap zebra_stripes_bitmap_buffer;
    private int zebra_stripes_color_background;
    private int zebra_stripes_color_foreground;
    private int zebra_stripes_threshold;
    private List<Integer> zoom_ratios;
    private HistogramType histogram_type = HistogramType.HISTOGRAM_TYPE_VALUE;
    private final ToastBoxer flash_toast = new ToastBoxer();
    private final Matrix camera_to_preview_matrix = new Matrix();
    private final Matrix preview_to_camera_matrix = new Matrix();
    private boolean app_is_paused = true;
    private boolean is_paused = true;
    private CameraOpenState camera_open_state = CameraOpenState.CAMERAOPENSTATE_CLOSED;
    private boolean has_permissions = true;
    private VideoFileInfo videoFileInfo = new VideoFileInfo();
    private volatile int phase = 0;
    private final Timer takePictureTimer = new Timer();
    private final Timer beepTimer = new Timer();
    private final Timer flashVideoTimer = new Timer();
    private final IntentFilter battery_ifilter = new IntentFilter("android.intent.action.BATTERY_CHANGED");
    private final Timer batteryCheckVideoTimer = new Timer();
    private int current_flash_index = -1;
    private int current_focus_index = -1;
    private int current_size_index = -1;
    private float capture_rate_factor = 1.0f;
    private final VideoQualityHandler video_quality_handler = new VideoQualityHandler();
    private final ToastBoxer focus_flash_toast = new ToastBoxer();
    private final ToastBoxer take_photo_toast = new ToastBoxer();
    private final ToastBoxer pause_video_toast = new ToastBoxer();
    private final RectF face_rect = new RectF();
    private long focus_complete_time = -1;
    private long focus_started_time = -1;
    private int focus_success = 3;
    private String set_flash_value_after_autofocus = "";
    private long successfully_focused_time = -1;
    private final float[] gravity = new float[3];
    private final float[] geomagnetic = new float[3];
    private final float[] deviceRotation = new float[9];
    private final float[] cameraRotation = new float[9];
    private final float[] deviceInclination = new float[9];
    private final float[] geo_direction = new float[3];
    private final float[] new_geo_direction = new float[3];
    private final DecimalFormat decimal_format_1dp = new DecimalFormat("#.#");
    private final DecimalFormat decimal_format_2dp_force0 = new DecimalFormat("0.00");
    private final Handler reset_continuous_focus_handler = new Handler();
    private final Handler fake_toast_handler = new Handler();
    private RotatedTextView active_fake_toast = null;


    public enum CameraOpenState {
        CAMERAOPENSTATE_CLOSED, CAMERAOPENSTATE_OPENING, CAMERAOPENSTATE_OPENED, CAMERAOPENSTATE_CLOSING
    }


    /* loaded from: classes.dex */
    public interface CloseCameraCallback {
        void onClosed();
    }


    public enum FaceLocation {
        FACELOCATION_UNSET, FACELOCATION_UNKNOWN, FACELOCATION_LEFT, FACELOCATION_RIGHT, FACELOCATION_TOP, FACELOCATION_BOTTOM, FACELOCATION_CENTRE
    }


    public enum HistogramType {
        HISTOGRAM_TYPE_RGB, HISTOGRAM_TYPE_LUMINANCE, HISTOGRAM_TYPE_VALUE, HISTOGRAM_TYPE_INTENSITY, HISTOGRAM_TYPE_LIGHTNESS
    }


    /* loaded from: classes.dex */
    public static class VideoFileInfo {
        private final String video_filename;
        private final ApplicationInterface.VideoMethod video_method;
        private final ParcelFileDescriptor video_pfd_saf;
        private final Uri video_uri;

        VideoFileInfo() {
            this.video_method = ApplicationInterface.VideoMethod.FILE;
            this.video_uri = null;
            this.video_filename = null;
            this.video_pfd_saf = null;
        }

        VideoFileInfo(ApplicationInterface.VideoMethod videoMethod, Uri uri, String str, ParcelFileDescriptor parcelFileDescriptor) {
            this.video_method = videoMethod;
            this.video_uri = uri;
            this.video_filename = str;
            this.video_pfd_saf = parcelFileDescriptor;
        }

        void close() {
            ParcelFileDescriptor parcelFileDescriptor = this.video_pfd_saf;
            if (parcelFileDescriptor != null) {
                try {
                    parcelFileDescriptor.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public Preview(ApplicationInterface applicationInterface, ViewGroup viewGroup, CameraMainActivity mainActivity) {
        boolean z = true;
        Log.d(TAG, "new Preview");
        this.applicationInterface = applicationInterface;
        this.mainActivity = mainActivity;
        Activity activity = (Activity) getContext();
        if (activity.getIntent() != null && activity.getIntent().getExtras() != null) {
            this.is_test = activity.getIntent().getExtras().getBoolean("test_project");
            Log.d(TAG, "is_test: " + this.is_test);
        }
        z = (Build.VERSION.SDK_INT<21 || !applicationInterface.useCamera2()) ? false : false;
        this.using_android_l = z;
        Log.d(TAG, "using_android_l?: " + z);
        if (z) {
            this.cameraSurface = new MyTextureView(getContext(), this);
            this.canvasView = new CanvasView(getContext(), this);
            this.camera_controller_manager = new CameraControllerManager2(getContext());
        } else {
            this.cameraSurface = new MySurfaceView(getContext(), this);
            this.camera_controller_manager = new CameraControllerManager1();
        }
        GestureDetector gestureDetector = new GestureDetector(getContext(), new GestureDetector.SimpleOnGestureListener());
        this.gestureDetector = gestureDetector;
        gestureDetector.setOnDoubleTapListener(new DoubleTapListener());
        this.scaleGestureDetector = new ScaleGestureDetector(getContext(), new ScaleListener());
        this.accessibility_manager = (AccessibilityManager) activity.getSystemService(Context.ACCESSIBILITY_SERVICE);
        viewGroup.addView(this.cameraSurface.getView());
        CanvasView canvasView = this.canvasView;
        if (canvasView != null) {
            viewGroup.addView(canvasView);
        }
    }


    public Resources getResources() {
        return this.cameraSurface.getView().getResources();
    }

    public View getView() {
        return this.cameraSurface.getView();
    }

    private void calculateCameraToPreviewMatrix() {
        Log.d(TAG, "calculateCameraToPreviewMatrix");
        if (this.camera_controller == null) {
            return;
        }
        this.camera_to_preview_matrix.reset();
        if (!this.using_android_l) {
            this.camera_to_preview_matrix.setScale(this.camera_controller.getFacing() == CameraController.Facing.FACING_FRONT ? -1.0f : 1.0f, 1.0f);
            int displayOrientation = this.camera_controller.getDisplayOrientation();
            Log.d(TAG, "orientation of display relative to camera orientaton: " + displayOrientation);
            this.camera_to_preview_matrix.postRotate((float) displayOrientation);
        } else {
            this.camera_to_preview_matrix.setScale(1.0f, this.camera_controller.getFacing() == CameraController.Facing.FACING_FRONT ? -1.0f : 1.0f);
            int displayRotationDegrees = getDisplayRotationDegrees();
            int cameraOrientation = ((this.camera_controller.getCameraOrientation() - displayRotationDegrees) + 360) % 360;
            Log.d(TAG, "orientation of display relative to natural orientaton: " + displayRotationDegrees);
            Log.d(TAG, "orientation of display relative to camera orientaton: " + cameraOrientation);
            this.camera_to_preview_matrix.postRotate((float) cameraOrientation);
        }
        this.camera_to_preview_matrix.postScale(this.cameraSurface.getView().getWidth() / 2000.0f, this.cameraSurface.getView().getHeight() / 2000.0f);
        this.camera_to_preview_matrix.postTranslate(this.cameraSurface.getView().getWidth() / 2.0f, this.cameraSurface.getView().getHeight() / 2.0f);
    }


    private void calculatePreviewToCameraMatrix() {
        if (this.camera_controller == null) {
            return;
        }
        calculateCameraToPreviewMatrix();
        if (this.camera_to_preview_matrix.invert(this.preview_to_camera_matrix)) {
            return;
        }
        Log.d(TAG, "calculatePreviewToCameraMatrix failed to invert matrix!?");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Matrix getCameraToPreviewMatrix() {
        calculateCameraToPreviewMatrix();
        return this.camera_to_preview_matrix;
    }


    private ArrayList<CameraController.Area> getAreas(float f, float f2) {
        float[] fArr = {f, f2};
        calculatePreviewToCameraMatrix();
        this.preview_to_camera_matrix.mapPoints(fArr);
        float f3 = fArr[0];
        float f4 = fArr[1];
        Log.d(TAG, "x, y: " + f + ", " + f2);
        Log.d(TAG, "focus x, y: " + f3 + ", " + f4);
        Rect rect = new Rect();
        int i = (int) f3;
        rect.left = i + (-50);
        rect.right = i + 50;
        int i2 = (int) f4;
        rect.top = i2 - 50;
        rect.bottom = i2 + 50;
        if (rect.left<-1000) {
            rect.left = NotificationManagerCompat.IMPORTANCE_UNSPECIFIED;
            rect.right = rect.left + 100;
        } else if (rect.right>1000) {
            rect.right = 1000;
            rect.left = rect.right - 100;
        }
        if (rect.top<-1000) {
            rect.top = NotificationManagerCompat.IMPORTANCE_UNSPECIFIED;
            rect.bottom = rect.top + 100;
        } else if (rect.bottom>1000) {
            rect.bottom = 1000;
            rect.top = rect.bottom - 100;
        }
        ArrayList<CameraController.Area> arrayList = new ArrayList<>();
        arrayList.add(new CameraController.Area(rect, 1000));
        return arrayList;
    }


    public boolean touchEvent(MotionEvent motionEvent) {
        Log.d(TAG, "touch event at : " + motionEvent.getX() + " , " + motionEvent.getY() + " at time " + motionEvent.getEventTime());
        clearActiveFakeToast();
        boolean z = this.is_preview_started ^ true;
        StringBuilder sb = new StringBuilder();
        sb.append("was_paused: ");
        sb.append(z);
        Log.d(TAG, sb.toString());
        if (this.gestureDetector.onTouchEvent(motionEvent)) {
            Log.d(TAG, "touch event handled by gestureDetector");
            return true;
        }
        this.scaleGestureDetector.onTouchEvent(motionEvent);
        if (this.camera_controller == null) {
            Log.d(TAG, "received touch event, but camera not available");
            return true;
        }
        this.applicationInterface.touchEvent(motionEvent);
        if (motionEvent.getPointerCount() != 1) {
            this.touch_was_multitouch = true;
            return true;
        } else if (motionEvent.getAction() != 1) {
            if (motionEvent.getAction() == 0 && motionEvent.getPointerCount() == 1) {
                this.touch_was_multitouch = false;
                if (motionEvent.getAction() == 0) {
                    this.touch_orig_x = motionEvent.getX();
                    this.touch_orig_y = motionEvent.getY();
                    Log.d(TAG, "touch down at " + this.touch_orig_x + " , " + this.touch_orig_y);
                    this.mainActivity.showExposureButton();
                }
            }
            return true;
        } else if (this.touch_was_multitouch) {
            return true;
        } else {
            if (this.is_video || !isTakingPhotoOrOnTimer()) {
                float x = motionEvent.getX();
                float y = motionEvent.getY();
                float f = x - this.touch_orig_x;
                float f2 = y - this.touch_orig_y;
                float f3 = (f * f) + (f2 * f2);
                float f4 = (getResources().getDisplayMetrics().density * 31.0f) + 0.5f;
                Log.d(TAG, "touched from " + this.touch_orig_x + " , " + this.touch_orig_y + " to " + x + " , " + y);
                StringBuilder sb2 = new StringBuilder();
                sb2.append("dist: ");
                sb2.append(Math.sqrt((double) f3));
                Log.d(TAG, sb2.toString());
                StringBuilder sb3 = new StringBuilder();
                sb3.append("tol: ");
                sb3.append(f4);
                Log.d(TAG, sb3.toString());
                if (f3>f4 * f4) {
                    Log.d(TAG, "touch was a swipe");
                    return true;
                }
                if (!this.is_video) {
                    startCameraPreview();
                }
                cancelAutoFocus();
                if (this.camera_controller != null && !this.using_face_detection && !z) {
                    this.has_focus_area = false;
                    if (this.camera_controller.setFocusAndMeteringArea(getAreas(motionEvent.getX(), motionEvent.getY()))) {
                        Log.d(TAG, "set focus (and metering?) area");
                        this.has_focus_area = true;
                        this.focus_screen_x = (int) motionEvent.getX();
                        this.focus_screen_y = (int) motionEvent.getY();
                    } else {
                        Log.d(TAG, "didn't set focus area in this mode, may have set metering");
                    }
                }
                if (this.is_video || z || !this.applicationInterface.getTouchCapturePref()) {
                    if (!z) {
                        tryAutoFocus(false, true);
                    }
                    return true;
                }
                Log.d(TAG, "touch to capture");
                takePicturePressed(false, false);
                return true;
            }
            return true;
        }
    }


    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        private ScaleListener() {
        }

        @Override
        public boolean onScale(ScaleGestureDetector scaleGestureDetector) {
            if (Preview.this.camera_controller == null || !Preview.this.has_zoom) {
                return true;
            }
            if (Preview.this.applicationInterface.getZoomPref() == 0 && scaleGestureDetector.getScaleFactor()>1.0f) {
                Preview.this.zoomTo(16);
            }
            Preview.this.scaleZoom(scaleGestureDetector.getScaleFactor());
            return true;
        }
    }

    public boolean onDoubleTap() {
        Log.d(TAG, "onDoubleTap()");
        if (this.is_video || !this.applicationInterface.getDoubleTapCapturePref()) {
            return true;
        }
        Log.d(TAG, "double-tap to capture");
        takePicturePressed(false, false);
        return true;
    }

    /* loaded from: classes.dex */
    private class DoubleTapListener extends GestureDetector.SimpleOnGestureListener {
        private DoubleTapListener() {
        }

        @Override
        // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTap(MotionEvent motionEvent) {
            Log.d(Preview.TAG, "onDoubleTap()");
            return Preview.this.onDoubleTap();
        }
    }

    public void clearFocusAreas() {
        Log.d(TAG, "clearFocusAreas()");
        CameraController cameraController = this.camera_controller;
        if (cameraController == null) {
            Log.d(TAG, "camera not opened!");
            return;
        }
        cameraController.clearFocusAndMetering();
        this.has_focus_area = false;
        this.focus_success = 3;
        this.successfully_focused = false;
    }

    public void getMeasureSpec(int[] iArr, int i, int i2) {
        Log.d(TAG, "getMeasureSpec");
        if (!hasAspectRatio()) {
            Log.d(TAG, "doesn't have aspect ratio");
            iArr[0] = i;
            iArr[1] = i2;
            return;
        }
        double aspectRatio = getAspectRatio();
        int size = View.MeasureSpec.getSize(i);
        int size2 = View.MeasureSpec.getSize(i2);
        int paddingLeft = this.cameraSurface.getView().getPaddingLeft() + this.cameraSurface.getView().getPaddingRight();
        int paddingTop = this.cameraSurface.getView().getPaddingTop() + this.cameraSurface.getView().getPaddingBottom();
        int i3 = size - paddingLeft;
        int i4 = size2 - paddingTop;
        boolean z = i3>i4;
        int i5 = z ? i3 : i4;
        if (z) {
            i3 = i4;
        }
        double d = i5;
        double d2 = i3 * aspectRatio;
        if (d>d2) {
            i5 = (int) d2;
        } else {
            i3 = (int) (d / aspectRatio);
        }
        if (z) {
            int i6 = i5;
            i5 = i3;
            i3 = i6;
        }
        iArr[0] = View.MeasureSpec.makeMeasureSpec(i3 + paddingLeft, 1073741824);
        iArr[1] = View.MeasureSpec.makeMeasureSpec(i5 + paddingTop, 1073741824);
        Log.d(TAG, "return: " + iArr[0] + " x " + iArr[1]);
    }

    private void mySurfaceCreated() {
        Log.d(TAG, "mySurfaceCreated");
        this.has_surface = true;
        openCamera();
    }

    private void mySurfaceDestroyed() {
        Log.d(TAG, "mySurfaceDestroyed");
        this.has_surface = false;
        closeCamera(false, null);
    }

    private void mySurfaceChanged() {
        if (this.camera_controller == null) {
            Log.d(TAG, "camera not opened!");
        }
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        Log.d(TAG, "surfaceCreated()");
        mySurfaceCreated();
        this.cameraSurface.getView().setWillNotDraw(false);
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        Log.d(TAG, "surfaceDestroyed()");
        mySurfaceDestroyed();
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
        Log.d(TAG, "surfaceChanged " + i2 + ", " + i3);
        if (surfaceHolder.getSurface() == null) {
            return;
        }
        mySurfaceChanged();
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i2) {
        Log.d(TAG, "onSurfaceTextureAvailable()");
        this.set_textureview_size = true;
        this.textureview_w = i;
        this.textureview_h = i2;
        mySurfaceCreated();
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        Log.d(TAG, "onSurfaceTextureDestroyed()");
        this.set_textureview_size = false;
        this.textureview_w = 0;
        this.textureview_h = 0;
        mySurfaceDestroyed();
        return true;
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i2) {
        Log.d(TAG, "onSurfaceTextureSizeChanged " + i + ", " + i2);
        CameraController cameraController = this.camera_controller;
        if (cameraController != null) {
            cameraController.test_texture_view_buffer_w = i;
            this.camera_controller.test_texture_view_buffer_h = i2;
            if (this.set_preview_size && (i != this.preview_w || i2 != this.preview_h)) {
                Log.d(TAG, "updatePreviewTexture");
                this.camera_controller.updatePreviewTexture();
            }
        }
        this.set_textureview_size = true;
        this.textureview_w = i;
        this.textureview_h = i2;
        mySurfaceChanged();
        configureTransform();
        recreatePreviewBitmap();
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
        refreshPreviewBitmap();
    }


    private void configureTransform() {
        Log.d(TAG, "configureTransform");
        if (this.camera_controller == null || !this.set_preview_size || !this.set_textureview_size) {
            Log.d(TAG, "nothing to do");
            return;
        }
        Log.d(TAG, "textureview size: " + this.textureview_w + ", " + this.textureview_h);
        int displayRotation = getDisplayRotation();
        Matrix matrix = new Matrix();
        RectF rectF = new RectF(0.0f, 0.0f, (float) this.textureview_w, (float) this.textureview_h);
        RectF rectF2 = new RectF(0.0f, 0.0f, (float) this.preview_h, (float) this.preview_w);
        float centerX = rectF.centerX();
        float centerY = rectF.centerY();
        if (1 == displayRotation || 3 == displayRotation) {
            rectF2.offset(centerX - rectF2.centerX(), centerY - rectF2.centerY());
            matrix.setRectToRect(rectF, rectF2, Matrix.ScaleToFit.FILL);
            float max = Math.max(this.textureview_h / this.preview_h, this.textureview_w / this.preview_w);
            matrix.postScale(max, max, centerX, centerY);
            matrix.postRotate((displayRotation - 2) * 90, centerX, centerY);
        }
        this.cameraSurface.setTransform(matrix);
    }

    public void stopVideo(boolean z) {
        Log.d(TAG, "stopVideo()");
        if (this.video_recorder == null) {
            Log.d(TAG, "video wasn't recording anyway");
            return;
        }
        this.applicationInterface.stoppingVideo();
        TimerTask timerTask = this.flashVideoTimerTask;
        if (timerTask != null) {
            timerTask.cancel();
            this.flashVideoTimerTask = null;
        }
        TimerTask timerTask2 = this.batteryCheckVideoTimerTask;
        if (timerTask2 != null) {
            timerTask2.cancel();
            this.batteryCheckVideoTimerTask = null;
        }
        if (!z) {
            this.remaining_restart_video = 0;
        }
        if (this.video_recorder != null) {
            Log.d(TAG, "stop video recording");
            this.video_recorder.setOnErrorListener(null);
            this.video_recorder.setOnInfoListener(null);
            try {
                Log.d(TAG, "about to call video_recorder.stop()");
            } catch (RuntimeException unused) {
                Log.d(TAG, "runtime exception when stopping video");
                this.applicationInterface.deleteUnusedVideo(this.videoFileInfo.video_method, this.videoFileInfo.video_uri, this.videoFileInfo.video_filename);
                this.videoFileInfo = new VideoFileInfo();
                this.nextVideoFileInfo = null;
                if (!this.video_start_time_set || System.currentTimeMillis() - this.video_start_time>2000) {
                    this.applicationInterface.onVideoRecordStopError(getVideoProfile());
                }
            }
            if (this.test_runtime_on_video_stop) {
                throw new RuntimeException();
            }
            this.video_recorder.stop();
            Log.d(TAG, "done video_recorder.stop()");
            videoRecordingStopped();
        }
    }

    private void videoRecordingStopped() {
        Log.d(TAG, "reset video_recorder");
        this.video_recorder.reset();
        Log.d(TAG, "release video_recorder");
        this.video_recorder.release();
        this.video_recorder = null;
        this.video_recorder_is_paused = false;
        this.applicationInterface.cameraInOperation(false, true);
        reconnectCamera(false);
        this.videoFileInfo.close();
        this.applicationInterface.stoppedVideo(this.videoFileInfo.video_method.getDeclaringClass().getModifiers(), this.videoFileInfo.video_uri, this.videoFileInfo.video_filename);
        if (this.nextVideoFileInfo != null) {
            Log.d(TAG, "delete ununused next video file");
            this.nextVideoFileInfo.close();
            this.applicationInterface.deleteUnusedVideo(this.nextVideoFileInfo.video_method, this.nextVideoFileInfo.video_uri, this.nextVideoFileInfo.video_filename);
        }
        this.videoFileInfo = new VideoFileInfo();
        this.nextVideoFileInfo = null;
    }


    public Context getContext() {
        return this.applicationInterface.getContext();
    }


    public void restartVideo(boolean z) {
        String str;
        Log.d(TAG, "restartVideo()");
        if (this.video_recorder != null) {
            if (z) {
                long currentTimeMillis = System.currentTimeMillis() - this.video_start_time;
                this.video_accumulated_time += currentTimeMillis;
                Log.d(TAG, "last_time: " + currentTimeMillis);
                Log.d(TAG, "video_accumulated_time is now: " + this.video_accumulated_time);
            } else {
                this.video_accumulated_time = 0L;
            }
            stopVideo(true);
            if (z) {
                Log.d(TAG, "restarting due to maximum filesize");
            } else {
                Log.d(TAG, "remaining_restart_video is: " + this.remaining_restart_video);
            }
            if (z) {
                long videoMaxDurationPref = this.applicationInterface.getVideoMaxDurationPref();
                if (videoMaxDurationPref>0) {
                    long j = videoMaxDurationPref - this.video_accumulated_time;
                    if (j<min_safe_restart_video_time) {
                        Log.d(TAG, "hit max filesize, but max time duration is also set, with remaining time less than 1s: " + j);
                        z = false;
                    }
                }
            }
            if (z || this.remaining_restart_video>0) {
                if (this.is_video) {
                    if (z) {
                        str = null;
                    } else {
                        str = this.remaining_restart_video + " " + getContext().getResources().getString(R.string.repeats_to_go);
                    }
                    takePicture(z, false, false);
                    if (z) {
                        return;
                    }
                    showToast((ToastBoxer) null, str);
                    this.remaining_restart_video--;
                    return;
                }
                this.remaining_restart_video = 0;
            }
        }
    }

    private void reconnectCamera(boolean z) {
        Log.d(TAG, "reconnectCamera()");
        CameraController cameraController = this.camera_controller;
        if (cameraController != null) {
            try {
                cameraController.reconnect();
                setPreviewPaused(false);
            } catch (CameraControllerException e) {
                Log.e(TAG, "failed to reconnect to camera");
                e.printStackTrace();
                this.applicationInterface.onFailedReconnectError();
                closeCamera(false, null);
            }
            try {
                tryAutoFocus(false, false);
            } catch (RuntimeException e2) {
                Log.e(TAG, "tryAutoFocus() threw exception: " + e2.getMessage());
                e2.printStackTrace();
                this.is_preview_started = false;
                if (!z) {
                    this.applicationInterface.onVideoRecordStopError(getVideoProfile());
                }
                this.camera_controller.release();
                this.camera_controller = null;
                this.camera_open_state = CameraOpenState.CAMERAOPENSTATE_CLOSED;
                openCamera();
            }
        }
    }


    /* loaded from: classes.dex */
    public class CloseCameraTask extends AsyncTask<Void, Void, Void> {
        private static final String TAG = "CloseCameraTask";
        final CameraController camera_controller_local;
        final CloseCameraCallback closeCameraCallback;
        boolean reopen;

        CloseCameraTask(CameraController cameraController, CloseCameraCallback closeCameraCallback) {
            this.camera_controller_local = cameraController;
            this.closeCameraCallback = closeCameraCallback;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Void doInBackground(Void... voidArr) {
            Log.d(TAG, "doInBackground, async task: " + this);
            long currentTimeMillis = System.currentTimeMillis();
            this.camera_controller_local.stopPreview();
            Log.d(TAG, "time to stop preview: " + (System.currentTimeMillis() - currentTimeMillis));
            this.camera_controller_local.release();
            Log.d(TAG, "time to release camera controller: " + (System.currentTimeMillis() - currentTimeMillis));
            return null;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Void r3) {
            Log.d(TAG, "onPostExecute, async task: " + this);
            Preview.this.camera_open_state = CameraOpenState.CAMERAOPENSTATE_CLOSED;
            Preview.this.close_camera_task = null;
            if (this.closeCameraCallback != null) {
                Log.d(TAG, "onPostExecute, calling closeCameraCallback.onClosed");
                this.closeCameraCallback.onClosed();
            }
            if (this.reopen) {
                Log.d(TAG, "onPostExecute, reopen camera");
                Preview.this.openCamera();
            }
            Log.d(TAG, "onPostExecute done, async task: " + this);
        }
    }

    private void closeCamera(boolean z, CloseCameraCallback closeCameraCallback) {
        Log.d(TAG, "closeCamera()");
        Log.d(TAG, "async: " + z);
        long currentTimeMillis = System.currentTimeMillis();
        removePendingContinuousFocusReset();
        this.has_focus_area = false;
        this.focus_success = 3;
        this.focus_started_time = -1L;
        synchronized (this) {
            this.take_photo_after_autofocus = false;
        }
        this.set_flash_value_after_autofocus = "";
        this.successfully_focused = false;
        this.preview_targetRatio = 0.0d;
        if (this.continuous_focus_move_is_started) {
            this.continuous_focus_move_is_started = false;
            this.applicationInterface.onContinuousFocusMove(false);
        }
        this.applicationInterface.cameraClosed();
        cancelTimer();
        cancelRepeat();
        if (this.camera_controller != null) {
            if (this.video_recorder != null) {
                stopVideo(false);
            }
            updateFocusForVideo();
            if (this.camera_controller != null) {
                Log.d(TAG, "closeCamera: about to pause preview: " + (System.currentTimeMillis() - currentTimeMillis));
                pausePreview(false);
                CameraController cameraController = this.camera_controller;
                this.camera_controller = null;
                if (z) {
                    Log.d(TAG, "close camera on background async");
                    this.camera_open_state = CameraOpenState.CAMERAOPENSTATE_CLOSING;
                    CloseCameraTask closeCameraTask = new CloseCameraTask(cameraController, closeCameraCallback);
                    this.close_camera_task = closeCameraTask;
                    closeCameraTask.execute(new Void[0]);
                } else {
                    Log.d(TAG, "closeCamera: about to release camera controller: " + (System.currentTimeMillis() - currentTimeMillis));
                    cameraController.stopPreview();
                    Log.d(TAG, "time to stop preview: " + (System.currentTimeMillis() - currentTimeMillis));
                    cameraController.release();
                    this.camera_open_state = CameraOpenState.CAMERAOPENSTATE_CLOSED;
                }
            }
        } else {
            Log.d(TAG, "camera_controller isn't open");
            if (closeCameraCallback != null) {
                Log.d(TAG, "calling closeCameraCallback.onClosed");
                closeCameraCallback.onClosed();
            }
        }
        if (this.orientationEventListener != null) {
            Log.d(TAG, "free orientationEventListener");
            this.orientationEventListener.disable();
            this.orientationEventListener = null;
        }
        Log.d(TAG, "closeCamera: total time: " + (System.currentTimeMillis() - currentTimeMillis));
    }

    public void cancelTimer() {
        Log.d(TAG, "cancelTimer()");
        if (isOnTimer()) {
            this.takePictureTimerTask.cancel();
            this.takePictureTimerTask = null;
            TimerTask timerTask = this.beepTimerTask;
            if (timerTask != null) {
                timerTask.cancel();
                this.beepTimerTask = null;
            }
            this.phase = 0;
        }
    }

    public void cancelRepeat() {
        Log.d(TAG, "cancelRepeat()");
        this.remaining_repeat_photos = 0;
    }

    public void pausePreview(boolean z) {
        Log.d(TAG, "pausePreview()");
        long currentTimeMillis = System.currentTimeMillis();
        if (this.camera_controller == null) {
            return;
        }
        updateFocusForVideo();
        setPreviewPaused(false);
        if (z) {
            Log.d(TAG, "pausePreview: about to stop preview: " + (System.currentTimeMillis() - currentTimeMillis));
            this.camera_controller.stopPreview();
            Log.d(TAG, "pausePreview: time to stop preview: " + (System.currentTimeMillis() - currentTimeMillis));
        }
        this.phase = 0;
        this.is_preview_started = false;
        Log.d(TAG, "pausePreview: about to call cameraInOperation: " + (System.currentTimeMillis() - currentTimeMillis));
        Log.d(TAG, "pausePreview: total time: " + (System.currentTimeMillis() - currentTimeMillis));
    }


    public void openCamera() {
        Log.d(TAG, "openCamera()");
        long currentTimeMillis = System.currentTimeMillis();
        if (this.applicationInterface.isPreviewInBackground()) {
            Log.d(TAG, "don't open camera as preview in background");
        } else if (this.camera_open_state == CameraOpenState.CAMERAOPENSTATE_OPENING) {
            Log.d(TAG, "already opening camera in background thread");
        } else if (this.camera_open_state == CameraOpenState.CAMERAOPENSTATE_CLOSING) {
            Log.d(TAG, "tried to open camera while camera is still closing in background thread");
        } else {
            this.is_preview_started = false;
            this.set_preview_size = false;
            this.preview_w = 0;
            this.preview_h = 0;
            this.has_focus_area = false;
            this.focus_success = 3;
            this.focus_started_time = -1L;
            synchronized (this) {
                this.take_photo_after_autofocus = false;
            }
            this.set_flash_value_after_autofocus = "";
            this.successfully_focused = false;
            this.preview_targetRatio = 0.0d;
            this.scene_modes = null;
            this.camera_controller_supports_zoom = false;
            this.has_zoom = false;
            this.max_zoom_factor = 0;
            this.minimum_focus_distance = 0.0f;
            this.zoom_ratios = null;
            this.faces_detected = null;
            this.supports_face_detection = false;
            this.using_face_detection = false;
            this.supports_optical_stabilization = false;
            this.supports_video_stabilization = false;
            this.supports_photo_video_recording = false;
            this.can_disable_shutter_sound = false;
            this.tonemap_max_curve_points = 0;
            this.supports_tonemap_curve = false;
            this.color_effects = null;
            this.white_balances = null;
            this.antibanding = null;
            this.edge_modes = null;
            this.noise_reduction_modes = null;
            this.isos = null;
            this.supports_white_balance_temperature = false;
            this.min_temperature = 0;
            this.max_temperature = 0;
            this.supports_iso_range = false;
            this.min_iso = 0;
            this.max_iso = 0;
            this.supports_exposure_time = false;
            this.min_exposure_time = 0L;
            this.max_exposure_time = 0L;
            this.exposures = null;
            this.min_exposure = 0;
            this.max_exposure = 0;
            this.exposure_step = 0.0f;
            this.supports_expo_bracketing = false;
            this.max_expo_bracketing_n_images = 0;
            this.supports_focus_bracketing = false;
            this.supports_burst = false;
            this.supports_raw = false;
            this.view_angle_x = 55.0f;
            this.view_angle_y = 43.0f;
            this.photo_sizes = null;
            this.current_size_index = -1;
            this.photo_size_constraints = null;
            this.has_capture_rate_factor = false;
            this.capture_rate_factor = 1.0f;
            this.video_high_speed = false;
            this.supports_video = true;
            this.supports_video_high_speed = false;
            this.video_quality_handler.resetCurrentQuality();
            this.supported_flash_values = null;
            this.current_flash_index = -1;
            this.supported_focus_values = null;
            this.current_focus_index = -1;
            this.max_num_focus_areas = 0;
            this.applicationInterface.cameraInOperation(false, false);
            if (this.is_video) {
                this.applicationInterface.cameraInOperation(false, true);
            }
            if (!this.has_surface) {
                Log.d(TAG, "preview surface not yet available");
            } else if (this.is_paused) {
                Log.d(TAG, "don't open camera as paused");
            } else {
                if (Build.VERSION.SDK_INT>=23) {
                    Log.d(TAG, "check for permissions");
                    if (ContextCompat.checkSelfPermission(getContext(), "android.permission.CAMERA") != 0) {
                        Log.d(TAG, "camera permission not available");
                        this.has_permissions = false;
                        this.applicationInterface.requestCameraPermission();
                        return;
                    }
                    if (Build.VERSION.SDK_INT>32) {
                        if (ContextCompat.checkSelfPermission(getContext(), "android.permission.READ_MEDIA_IMAGES") != 0) {
                            Log.d(TAG, "storage permission not available");
                            this.has_permissions = false;
                            this.applicationInterface.requestStoragePermission();
                            return;
                        }
                    } else if (ContextCompat.checkSelfPermission(getContext(), "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
                        Log.d(TAG, "storage permission not available");
                        this.has_permissions = false;
                        this.applicationInterface.requestStoragePermission();
                        return;
                    }
                    Log.d(TAG, "permissions available");
                }
                this.has_permissions = true;
                this.camera_open_state = CameraOpenState.CAMERAOPENSTATE_OPENING;
                int cameraIdPref = this.applicationInterface.getCameraIdPref();
                if (cameraIdPref<0 || cameraIdPref>=this.camera_controller_manager.getNumberOfCameras()) {
                    Log.d(TAG, "invalid cameraId: " + cameraIdPref);
                    this.applicationInterface.setCameraIdPref(0);
                    cameraIdPref = 0;
                }
                if (Build.VERSION.SDK_INT>=23) {
                    int finalCameraIdPref = cameraIdPref;
                    this.open_camera_task = new AsyncTask<Void, Void, CameraController>() {
                        private static final String TAG = "Preview/openCamera";


                        @Override
                        public CameraController doInBackground(Void... voidArr) {
                            Log.d(TAG, "doInBackground, async task: " + this);
                            return Preview.this.openCameraCore(finalCameraIdPref);
                        }

                        @Override
                        public void onPostExecute(CameraController cameraController) {
                            Log.d(TAG, "onPostExecute, async task: " + this);
                            Preview.this.camera_controller = cameraController;
                            Preview.this.cameraOpened();
                            Preview.this.camera_open_state = CameraOpenState.CAMERAOPENSTATE_OPENED;
                            Preview.this.open_camera_task = null;
                            Log.d(TAG, "onPostExecute done, async task: " + this);
                        }


                        @Override
                        public void onCancelled(CameraController cameraController) {
                            Log.d(TAG, "onCancelled, async task: " + this);
                            Log.d(TAG, "camera_controller: " + cameraController);
                            if (cameraController != null) {
                                cameraController.release();
                            }
                            Preview.this.camera_open_state = CameraOpenState.CAMERAOPENSTATE_OPENED;
                            Preview.this.open_camera_task = null;
                            Log.d(TAG, "onCancelled done, async task: " + this);
                        }
                    }.execute(new Void[0]);
                } else {
                    this.camera_controller = openCameraCore(cameraIdPref);
                    Log.d(TAG, "openCamera: time after opening camera: " + (System.currentTimeMillis() - currentTimeMillis));
                    cameraOpened();
                    this.camera_open_state = CameraOpenState.CAMERAOPENSTATE_OPENED;
                }
                Log.d(TAG, "openCamera: total time to open camera: " + (System.currentTimeMillis() - currentTimeMillis));
            }
        }
    }


    public CameraController openCameraCore(int i) {
        CameraController cameraController;
        Log.d(TAG, "openCameraCore()");
        long currentTimeMillis = System.currentTimeMillis();
        Log.d(TAG, "try to open camera: " + i);
        Log.d(TAG, "openCamera: time before opening camera: " + (System.currentTimeMillis() - currentTimeMillis));
        if (this.test_fail_open_camera) {
            Log.d(TAG, "test failing to open camera");
            try {
                throw new CameraControllerException();
            } catch (CameraControllerException e) {
                e.printStackTrace();
            }
        }
        CameraController.ErrorCallback errorCallback = new CameraController.ErrorCallback() {
            @Override
            public void onError() {
                Log.e(Preview.TAG, "error from CameraController: camera device failed");
                if (Preview.this.camera_controller != null) {
                    Preview.this.camera_controller = null;
                    Preview.this.camera_open_state = CameraOpenState.CAMERAOPENSTATE_CLOSED;
                    Preview.this.applicationInterface.onCameraError();
                }
            }
        };
        if (this.using_android_l && Build.VERSION.SDK_INT>=21) {
            try {
                cameraController = new CameraController2(getContext(), i, new CameraController.ErrorCallback() {
                    @Override
                    public void onError() {
                        Log.e(Preview.TAG, "error from CameraController: preview failed to start");
                        Preview.this.applicationInterface.onFailedStartPreview();
                    }
                }, errorCallback);
            } catch (CameraControllerException e) {
                throw new RuntimeException(e);
            }
            if (this.applicationInterface.useCamera2FakeFlash()) {
                cameraController.setUseCamera2FakeFlash(true);
            }
        } else {
            try {
                cameraController = new CameraController1(i, errorCallback);
            } catch (CameraControllerException e) {
                throw new RuntimeException(e);
            }
        }
        Log.d(TAG, "openCamera: total time for openCameraCore: " + (System.currentTimeMillis() - currentTimeMillis));
        return cameraController;
    }


    public void cameraOpened() {
        Log.d(TAG, "cameraOpened()");
        long currentTimeMillis = System.currentTimeMillis();
        if (this.camera_controller != null) {
            Activity activity = (Activity) getContext();
            boolean z = TakePhoto.TAKE_PHOTO;
            if (z) {
                TakePhoto.TAKE_PHOTO = false;
            }
            Log.d(TAG, "take_photo?: " + z);
            setCameraDisplayOrientation();
            if (this.orientationEventListener == null) {
                Log.d(TAG, "create orientationEventListener");
                OrientationEventListener orientationEventListener = new OrientationEventListener(activity) {
                    @Override // android.view.OrientationEventListener
                    public void onOrientationChanged(int i) {
                        Preview.this.onOrientationChanged(i);
                    }
                };
                this.orientationEventListener = orientationEventListener;
                orientationEventListener.enable();
            }
            Log.d(TAG, "openCamera: time after setting orientation: " + (System.currentTimeMillis() - currentTimeMillis));
            Log.d(TAG, "call setPreviewDisplay");
            this.cameraSurface.setPreviewDisplay(this.camera_controller);
            Log.d(TAG, "openCamera: time after setting preview display: " + (System.currentTimeMillis() - currentTimeMillis));
            setupCamera(z);
            if (this.using_android_l) {
                configureTransform();
            }
        }
        Log.d(TAG, "openCamera: total time for cameraOpened: " + (System.currentTimeMillis() - currentTimeMillis));
    }

    public void retryOpenCamera() {
        Log.d(TAG, "retryOpenCamera()");
        if (this.camera_controller == null) {
            Log.d(TAG, "try to reopen camera");
            openCamera();
            return;
        }
        Log.d(TAG, "camera already open");
    }

    public void reopenCamera() {
        Log.d(TAG, "reopenCamera()");
        closeCamera(true, new CloseCameraCallback() {
            @Override
            public void onClosed() {
                Log.d(Preview.TAG, "CloseCameraCallback.onClosed");
                Preview.this.openCamera();
            }
        });
    }

    public boolean hasPermissions() {
        return this.has_permissions;
    }

    public boolean isOpeningCamera() {
        return this.camera_open_state == CameraOpenState.CAMERAOPENSTATE_OPENING;
    }

    public boolean openCameraAttempted() {
        return this.camera_open_state == CameraOpenState.CAMERAOPENSTATE_OPENED;
    }

    public boolean openCameraFailed() {
        return this.camera_open_state == CameraOpenState.CAMERAOPENSTATE_OPENED && this.camera_controller == null;
    }

    public void setupCamera(boolean z) {
        String str = TAG;
        Log.d(str, "setupCamera()");
        long currentTimeMillis = System.currentTimeMillis();
        if (this.camera_controller == null) {
            Log.d(str, "camera not opened!");
            return;
        }
        boolean z2 = !z && this.applicationInterface.getStartupFocusPref();
        Log.d(str, "take_photo? " + z);
        Log.d(str, "do_startup_focus? " + z2);
        updateFocusForVideo();
        CameraController.Size size = null;
        try {
            initCameraParameters();
            boolean isVideoPref = this.applicationInterface.isVideoPref();
            Log.d(str, "saved_is_video: " + isVideoPref);
            if (isVideoPref && !this.supports_video) {
                Log.d(str, "but video not supported");
                isVideoPref = false;
            }
            if (isVideoPref != this.is_video) {
                Log.d(str, "switch video mode as not in correct mode");
                switchVideo(true, false);
            }
            setupCameraParameters();
            updateFlashForVideo();
            if (z && this.is_video) {
                Log.d(str, "switch to video for take_photo widget");
                switchVideo(true, true);
            }
            Log.d(str, "is_video?: " + this.is_video);
            if (this.is_video) {
                CameraController.TonemapProfile tonemapProfile = CameraController.TonemapProfile.TONEMAPPROFILE_OFF;
                if (this.supports_tonemap_curve) {
                    tonemapProfile = this.applicationInterface.getVideoTonemapProfile();
                }
                float videoLogProfileStrength = tonemapProfile == CameraController.TonemapProfile.TONEMAPPROFILE_LOG ? this.applicationInterface.getVideoLogProfileStrength() : 0.0f;
                float videoProfileGamma = tonemapProfile == CameraController.TonemapProfile.TONEMAPPROFILE_GAMMA ? this.applicationInterface.getVideoProfileGamma() : 0.0f;
                Log.d(str, "tonemap_profile: " + tonemapProfile);
                Log.d(str, "video_log_profile_strength: " + videoLogProfileStrength);
                Log.d(str, "fHDtJax.NPJq" + videoProfileGamma);
                this.camera_controller.setTonemapProfile(tonemapProfile, videoLogProfileStrength, videoProfileGamma);
            }
            this.camera_controller.setVideoHighSpeed(this.is_video && this.video_high_speed);
            if (z2 && this.using_android_l && this.camera_controller.supportsAutoFocus()) {
                this.set_flash_value_after_autofocus = "";
                String flashValue = this.camera_controller.getFlashValue();
                if (flashValue.length()>0 && !flashValue.equals("flash_off") && !flashValue.equals("flash_torch")) {
                    this.set_flash_value_after_autofocus = flashValue;
                    this.camera_controller.setFlashValue("flash_off");
                }
                Log.d(str, "set_flash_value_after_autofocus is now: " + this.set_flash_value_after_autofocus);
            }
            if (this.supports_raw && this.applicationInterface.getRawPref() != ApplicationInterface.RawPref.RAWPREF_JPEG_ONLY) {
                this.camera_controller.setRaw(true, this.applicationInterface.getMaxRawImages());
            } else {
                this.camera_controller.setRaw(false, 0);
            }
            setupBurstMode();
            if (this.camera_controller.isBurstOrExpo()) {
                Log.d(str, "check photo resolution supports burst");
                CameraController.Size currentPictureSize = getCurrentPictureSize();
                if (currentPictureSize != null) {
                    Log.d(str, "current_size: " + currentPictureSize.width + " x " + currentPictureSize.height + " supports_burst? " + currentPictureSize.supports_burst);
                }
                if (currentPictureSize != null && !currentPictureSize.supports_burst) {
                    Log.d(str, "burst mode: current picture size doesn't support burst");
                    for (int i = 0; i<this.photo_sizes.size(); i++) {
                        CameraController.Size size2 = this.photo_sizes.get(i);
                        if (size2.supports_burst && size2.width * size2.height<=currentPictureSize.width * currentPictureSize.height && (size == null || size2.width * size2.height>size.width * size.height)) {
                            this.current_size_index = i;
                            size = size2;
                        }
                    }
                    if (size == null) {
                        Log.e(str, "can't find burst-supporting picture size smaller than the current picture size");
                        for (int i2 = 0; i2<this.photo_sizes.size(); i2++) {
                            CameraController.Size size3 = this.photo_sizes.get(i2);
                            if (size3.supports_burst && (size == null || size3.width * size3.height>size.width * size.height)) {
                                this.current_size_index = i2;
                                size = size3;
                            }
                        }
                        if (size == null) {
                            Log.e(str, "can't find burst-supporting picture size");
                        }
                    }
                }
            }
            this.camera_controller.setOptimiseAEForDRO(this.applicationInterface.getOptimiseAEForDROPref());
            setPreviewSize();
            Log.d(str, "setupCamera: time after setting preview size: " + (System.currentTimeMillis() - currentTimeMillis));
            startCameraPreview();
            Log.d(str, "setupCamera: time after starting camera preview: " + (System.currentTimeMillis() - currentTimeMillis));
            if (this.has_zoom && this.applicationInterface.getZoomPref() != 0) {
                zoomTo(this.applicationInterface.getZoomPref());
                Log.d(str, "setupCamera: total time after zoomTo: " + (System.currentTimeMillis() - currentTimeMillis));
            } else if (this.camera_controller_supports_zoom && !this.has_zoom) {
                Log.d(str, "camera supports zoom but application disabled zoom, so reset zoom to default");
                this.camera_controller.setZoom(0);
            }
            this.applicationInterface.cameraSetup();
            Log.d(str, "setupCamera: total time after cameraSetup: " + (System.currentTimeMillis() - currentTimeMillis));
            if (z) {
                String currentFocusValue = getCurrentFocusValue();
                int i3 = (currentFocusValue == null || !currentFocusValue.equals("focus_mode_continuous_picture")) ? 500 : ConnectionResult.DRIVE_EXTERNAL_STORAGE_REQUIRED;
                Log.d(str, "delay for take photo: " + i3);
                new Handler().postDelayed(new Runnable() { // from class: com.live.gpsmap.camera.Camera.preview.Preview.6
                    @Override // java.lang.Runnable
                    public void run() {
                        Log.d(Preview.TAG, "do automatic take picture");
                        Preview.this.takePicture(false, false, false);
                    }
                }, (long) i3);
            }
            if (z2) {
                new Handler().postDelayed(new Runnable() { // from class: com.live.gpsmap.camera.Camera.preview.Preview.7
                    @Override // java.lang.Runnable
                    public void run() {
                        Log.d(Preview.TAG, "do startup autofocus");
                        Preview.this.tryAutoFocus(true, false);
                    }
                }, 500L);
            }
            Log.d(str, "setupCamera: total time after setupCamera: " + (System.currentTimeMillis() - currentTimeMillis));
        } catch (CameraControllerException e) {
            e.printStackTrace();
            this.applicationInterface.onCameraError();
            closeCamera(false, null);
        }
    }

    public void setupBurstMode() {
        Log.d(TAG, "setupBurstMode()");
        if (this.supports_expo_bracketing && this.applicationInterface.isExpoBracketingPref()) {
            this.camera_controller.setBurstType(CameraController.BurstType.BURSTTYPE_EXPO);
            this.camera_controller.setExpoBracketingNImages(this.applicationInterface.getExpoBracketingNImagesPref());
            this.camera_controller.setExpoBracketingStops(this.applicationInterface.getExpoBracketingStopsPref());
        } else if (this.supports_focus_bracketing && this.applicationInterface.isFocusBracketingPref()) {
            this.camera_controller.setBurstType(CameraController.BurstType.BURSTTYPE_FOCUS);
            this.camera_controller.setFocusBracketingNImages(this.applicationInterface.getFocusBracketingNImagesPref());
            this.camera_controller.setFocusBracketingAddInfinity(this.applicationInterface.getFocusBracketingAddInfinityPref());
        } else if (this.supports_burst && this.applicationInterface.isCameraBurstPref()) {
            if (this.applicationInterface.getBurstForNoiseReduction()) {
                if (this.supports_exposure_time) {
                    ApplicationInterface.NRModePref nRModePref = this.applicationInterface.getNRModePref();
                    this.camera_controller.setBurstType(CameraController.BurstType.BURSTTYPE_NORMAL);
                    this.camera_controller.setBurstForNoiseReduction(true, nRModePref == ApplicationInterface.NRModePref.NRMODE_LOW_LIGHT);
                    return;
                }
                this.camera_controller.setBurstType(CameraController.BurstType.BURSTTYPE_NONE);
                return;
            }
            this.camera_controller.setBurstType(CameraController.BurstType.BURSTTYPE_NORMAL);
            this.camera_controller.setBurstForNoiseReduction(false, false);
            this.camera_controller.setBurstNImages(this.applicationInterface.getBurstNImages());
        } else {
            this.camera_controller.setBurstType(CameraController.BurstType.BURSTTYPE_NONE);
        }
    }

    private void initCameraParameters() throws CameraControllerException {
        Log.d(TAG, "initCameraParameters()");
        Log.d(TAG, "set up scene mode");
        String sceneModePref = this.applicationInterface.getSceneModePref();
        Log.d(TAG, "saved scene mode: " + sceneModePref);
        CameraController.SupportedValues sceneMode = this.camera_controller.setSceneMode(sceneModePref);
        if (sceneMode != null) {
            this.scene_modes = sceneMode.values;
            this.applicationInterface.setSceneModePref(sceneMode.selected_value);
        } else {
            this.applicationInterface.clearSceneModePref();
        }
        Log.d(TAG, "grab info from parameters");
        CameraController.CameraFeatures cameraFeatures = this.camera_controller.getCameraFeatures();
        this.camera_controller_supports_zoom = cameraFeatures.is_zoom_supported;
        boolean z = true;
        boolean z2 = cameraFeatures.is_zoom_supported && this.applicationInterface.allowZoom();
        this.has_zoom = z2;
        CameraController.Size size = null;
        if (z2) {
            this.max_zoom_factor = cameraFeatures.max_zoom;
            this.zoom_ratios = cameraFeatures.zoom_ratios;
        } else {
            this.max_zoom_factor = 0;
            this.zoom_ratios = null;
        }
        this.minimum_focus_distance = cameraFeatures.minimum_focus_distance;
        this.supports_face_detection = cameraFeatures.supports_face_detection;
        if (cameraFeatures.picture_sizes != null) {
            ArrayList arrayList = new ArrayList();
            this.photo_sizes = arrayList;
            arrayList.clear();
            if (cameraFeatures.picture_sizes.size()>7) {
                for (int i = 0; i<7; i++) {
                    String aspectRatio = getAspectRatio(cameraFeatures.picture_sizes.get(i).width, cameraFeatures.picture_sizes.get(i).height);
                    if (aspectRatio.equals("4:3") || aspectRatio.equals("16:9") || aspectRatio.equals("1:1")) {
                        this.photo_sizes.add(cameraFeatures.picture_sizes.get(i));
                    }
                }
                if (this.photo_sizes.size() == 0) {
                    for (int i2 = 0; i2<7; i2++) {
                        this.photo_sizes.add(cameraFeatures.picture_sizes.get(i2));
                    }
                }
            } else {
                this.photo_sizes = cameraFeatures.picture_sizes;
            }
        }
        if (this.test_burst_resolution) {
            for (int i3 = 0; i3<this.photo_sizes.size(); i3++) {
                CameraController.Size size2 = this.photo_sizes.get(i3);
                if (size == null || size2.width * size2.height>size.width * size.height) {
                    size = size2;
                }
            }
            if (size != null) {
                size.supports_burst = false;
            }
        }
        this.supported_flash_values = cameraFeatures.supported_flash_values;
        this.supported_focus_values = cameraFeatures.supported_focus_values;
        this.max_num_focus_areas = cameraFeatures.max_num_focus_areas;
        this.is_exposure_lock_supported = cameraFeatures.is_exposure_lock_supported;
        this.is_white_balance_lock_supported = cameraFeatures.is_white_balance_lock_supported;
        this.supports_optical_stabilization = cameraFeatures.is_optical_stabilization_supported;
        this.supports_video_stabilization = cameraFeatures.is_video_stabilization_supported;
        this.supports_photo_video_recording = cameraFeatures.is_photo_video_recording_supported;
        this.can_disable_shutter_sound = cameraFeatures.can_disable_shutter_sound;
        this.tonemap_max_curve_points = cameraFeatures.tonemap_max_curve_points;
        this.supports_tonemap_curve = cameraFeatures.supports_tonemap_curve;
        this.supported_apertures = cameraFeatures.apertures;
        this.supports_white_balance_temperature = cameraFeatures.supports_white_balance_temperature;
        this.min_temperature = cameraFeatures.min_temperature;
        this.max_temperature = cameraFeatures.max_temperature;
        this.supports_iso_range = cameraFeatures.supports_iso_range;
        this.min_iso = cameraFeatures.min_iso;
        this.max_iso = cameraFeatures.max_iso;
        this.supports_exposure_time = cameraFeatures.supports_exposure_time;
        this.min_exposure_time = cameraFeatures.min_exposure_time;
        this.max_exposure_time = cameraFeatures.max_exposure_time;
        this.min_exposure = cameraFeatures.min_exposure;
        this.max_exposure = cameraFeatures.max_exposure;
        this.exposure_step = cameraFeatures.exposure_step;
        this.supports_expo_bracketing = cameraFeatures.supports_expo_bracketing;
        this.max_expo_bracketing_n_images = cameraFeatures.max_expo_bracketing_n_images;
        this.supports_focus_bracketing = cameraFeatures.supports_focus_bracketing;
        this.supports_burst = cameraFeatures.supports_burst;
        this.supports_raw = cameraFeatures.supports_raw;
        this.view_angle_x = cameraFeatures.view_angle_x;
        this.view_angle_y = cameraFeatures.view_angle_y;
        this.supports_video_high_speed = (cameraFeatures.video_sizes_high_speed == null || cameraFeatures.video_sizes_high_speed.size()<=0) ? false : false;
        this.video_quality_handler.setVideoSizes(cameraFeatures.video_sizes);
        this.video_quality_handler.setVideoSizesHighSpeed(cameraFeatures.video_sizes_high_speed);
        this.supported_preview_sizes = cameraFeatures.preview_sizes;
    }

    private void setupCameraParameters() {
        class MyFaceDetectionListener implements CameraController.FaceDetectionListener {
            private final Handler handler;
            private FaceLocation last_face_location;
            private int last_n_faces;

            MyFaceDetectionListener() {
                this.handler = new Handler();
                this.last_n_faces = -1;
                this.last_face_location = FaceLocation.FACELOCATION_UNSET;
            }

            @Override
            public void onFaceDetection(CameraController.Face[] arr_cameraController$Face1) {
                Log.d("Preview", "onFaceDetection: " + arr_cameraController$Face1.length + " : " + Arrays.toString(arr_cameraController$Face1));
                if (Preview.this.camera_controller == null) {
                    ((Activity) Preview.this.getContext()).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Preview.this.faces_detected = null;
                        }
                    });
                    return;
                }

                ((Activity) Preview.this.getContext()).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Matrix matrix0 = Preview.this.getCameraToPreviewMatrix();
                        CameraController.Face[] arr_cameraController$Face = arr_cameraController$Face1;
                        int v;
                        for (v = 0; v<arr_cameraController$Face.length; ++v) {
                            CameraController.Face cameraController$Face0 = arr_cameraController$Face[v];
                            Preview.this.face_rect.set(cameraController$Face0.rect);
                            matrix0.mapRect(Preview.this.face_rect);
                            Preview.this.face_rect.round(cameraController$Face0.rect);
                        }

                        MyFaceDetectionListener.this.reportFaces(arr_cameraController$Face);
                        if (Preview.this.faces_detected == null || Preview.this.faces_detected.length != arr_cameraController$Face.length) {
                            Log.d("Preview", "allocate new faces_detected");
                            Preview.this.faces_detected = new CameraController.Face[arr_cameraController$Face.length];
                        }

                        CameraController.Face[] arr_cameraController$Face1 = Preview.this.faces_detected;
                        System.arraycopy(arr_cameraController$Face, 0, arr_cameraController$Face1, 0, arr_cameraController$Face.length);
                    }
                });
            }

            private void reportFaces(CameraController.Face[] arr_cameraController$Face) {
                float f9;
                if (Build.VERSION.SDK_INT>=16 && (Preview.this.accessibility_manager.isEnabled()) && (Preview.this.accessibility_manager.isTouchExplorationEnabled())) {
                    FaceLocation preview$FaceLocation0 = FaceLocation.FACELOCATION_UNKNOWN;
                    if (arr_cameraController$Face.length>0) {
                        float f = 0.0f;
                        float f1 = 0.0f;
                        int v = 0;
                        int v1 = 1;
                        while (v<arr_cameraController$Face.length) {
                            CameraController.Face cameraController$Face0 = arr_cameraController$Face[v];
                            float f2 = (float) cameraController$Face0.rect.centerX();
                            float f3 = (float) cameraController$Face0.rect.centerY();
                            float f4 = f2 / ((float) Preview.this.cameraSurface.getView().getWidth());
                            float f5 = f3 / ((float) Preview.this.cameraSurface.getView().getHeight());
                            if (v1 != 0 && (f4<0.35f || f4>0.65f || f5<0.35f || f5>0.65f)) {
                                v1 = 0;
                            }

                            f += f4;
                            f1 += f5;
                            ++v;
                        }

                        float f6 = (float) arr_cameraController$Face.length;
                        float f7 = f / f6;
                        float f8 = f1 / f6;
                        Log.d("Preview", "    avg_x: " + f7);
                        Log.d("Preview", "    avg_y: " + f8);
                        Log.d("Preview", "    ui_rotation: " + Preview.this.ui_rotation);
                        if (v1 == 0) {
                            int v2 = Preview.this.ui_rotation;
                            if (v2 == 90) {
                                f9 = 1.0f - f7;
                                f7 = f8;
                            } else {
                                switch (v2) {
                                    case 180: {
                                        f7 = 1.0f - f7;
                                        f9 = 1.0f - f8;
                                        break;
                                    }
                                    case 270: {
                                        f9 = f7;
                                        f7 = 1.0f - f8;
                                        break;
                                    }
                                    default: {
                                        f9 = f8;
                                    }
                                }
                            }

                            Log.d("Preview", "    avg_x: " + f7);
                            Log.d("Preview", "    avg_y: " + f9);
                            if (f7<0.35f) {
                                preview$FaceLocation0 = FaceLocation.FACELOCATION_LEFT;
                            } else if (f7>0.65f) {
                                preview$FaceLocation0 = FaceLocation.FACELOCATION_RIGHT;
                            } else if (f9<0.35f) {
                                preview$FaceLocation0 = FaceLocation.FACELOCATION_TOP;
                            } else if (f9>0.65f) {
                                preview$FaceLocation0 = FaceLocation.FACELOCATION_BOTTOM;
                            }
                        } else {
                            preview$FaceLocation0 = FaceLocation.FACELOCATION_CENTRE;
                        }
                    }

                    int v3 = this.last_n_faces;
                    if (arr_cameraController$Face.length != v3 || preview$FaceLocation0 != this.last_face_location) {
                        if (arr_cameraController$Face.length != 0 || v3 != -1) {
                            String s = arr_cameraController$Face.length + " " + Preview.this.getContext().getResources().getString((arr_cameraController$Face.length == 1 ? R.string.face_detected : R.string.face_detected));  // string:face_detected "face"
                            if (arr_cameraController$Face.length>0 && preview$FaceLocation0 != FaceLocation.FACELOCATION_UNKNOWN) {
                                int v4 = AnonymousClass24.$SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$preview$Preview$FaceLocation[preview$FaceLocation0.ordinal()];
                                if (v4 == 1) {
                                    s = s + " " + Preview.this.getContext().getResources().getString(R.string.centre_of_screen);  // string:centre_of_screen "at centre"
                                } else {
                                    switch (v4) {
                                        case 2: {
                                            s = s + " " + Preview.this.getContext().getResources().getString(R.string.left_of_screen);  // string:left_of_screen "at left of screen"
                                            break;
                                        }
                                        case 3: {
                                            s = s + " " + Preview.this.getContext().getResources().getString(R.string.right_of_screen);  // string:right_of_screen "at right of screen"
                                            break;
                                        }
                                        case 4: {
                                            s = s + " " + Preview.this.getContext().getResources().getString(R.string.top_of_screen);  // string:top_of_screen "at top of screen"
                                            break;
                                        }
                                        case 5: {
                                            s = s + " " + Preview.this.getContext().getResources().getString(R.string.bottom_of_screen);  // string:bottom_of_screen "at bottom of screen"
                                        }
                                    }
                                }
                            }

                            Log.d("Preview", s);
                            this.handler.removeCallbacksAndMessages(null);
                            String finalS = s;
                            this.handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    Log.d("Preview", "announceForAccessibility: " + finalS);
                                    if (Build.VERSION.SDK_INT>=16) {
                                        Preview.this.getView().announceForAccessibility(finalS);
                                    }

                                }
                            }, 500L);
                        }

                        this.last_n_faces = arr_cameraController$Face.length;
                        this.last_face_location = preview$FaceLocation0;
                    }
                }
            }
        }

        float f5;
        int v6;
        int v3;
        Preview preview0 = this;
        Log.d("Preview", "setupCameraParameters()");
        long v = System.currentTimeMillis();
        Log.d("Preview", "set up face detection");
        preview0.faces_detected = null;
        preview0.using_face_detection = preview0.supports_face_detection ? preview0.applicationInterface.getFaceDetectionPref() : false;
        Log.d("Preview", "supports_face_detection?: " + preview0.supports_face_detection);
        Log.d("Preview", "using_face_detection?: " + preview0.using_face_detection);
        if (preview0.using_face_detection) {
            preview0.camera_controller.setFaceDetectionListener(new MyFaceDetectionListener());
        }

        Log.d("Preview", "setupCameraParameters: time after setting face detection: " + (System.currentTimeMillis() - v));
        Log.d("Preview", "set up video stabilization");
        Log.d("Preview", "is_video?: " + preview0.is_video);
        if (preview0.supports_video_stabilization) {
            int v1 = !preview0.is_video || !preview0.applicationInterface.getVideoStabilizationPref() ? 0 : 1;
            boolean v1b = true;
            if (v1 == 0) {
                v1b = false;
            }
            preview0.camera_controller.setVideoStabilization(v1b);
        }

        Log.d("Preview", "supports_video_stabilization?: " + preview0.supports_video_stabilization);
        Log.d("Preview", "setupCameraParameters: time after video stabilization: " + (System.currentTimeMillis() - v));
        Log.d("Preview", "set up color effect");
        String s = preview0.applicationInterface.getColorEffectPref();
        Log.d("Preview", "saved color effect: " + s);
        CameraController.SupportedValues cameraController$SupportedValues0 = preview0.camera_controller.setColorEffect(s);
        if (cameraController$SupportedValues0 == null) {
            preview0.applicationInterface.clearColorEffectPref();
        } else {
            preview0.color_effects = cameraController$SupportedValues0.values;
            System.out.println("CameraControler       " + preview0.color_effects);
            preview0.applicationInterface.setColorEffectPref(cameraController$SupportedValues0.selected_value);
        }

        Log.d("Preview", "setupCameraParameters: time after color effect: " + (System.currentTimeMillis() - v));
        Log.d("Preview", "set up white balance");
        String s1 = preview0.applicationInterface.getWhiteBalancePref();
        Log.d("Preview", "saved white balance: " + s1);
        CameraController.SupportedValues cameraController$SupportedValues1 = preview0.camera_controller.setWhiteBalance(s1);
        if (cameraController$SupportedValues1 == null) {
            preview0.applicationInterface.clearWhiteBalancePref();
        } else {
            preview0.white_balances = cameraController$SupportedValues1.values;
            preview0.applicationInterface.setWhiteBalancePref(cameraController$SupportedValues1.selected_value);
            if ((cameraController$SupportedValues1.selected_value.equals("manual")) && (preview0.supports_white_balance_temperature)) {
                int v2 = preview0.applicationInterface.getWhiteBalanceTemperaturePref();
                preview0.camera_controller.setWhiteBalanceTemperature(v2);
                Log.d("Preview", "saved white balance: " + s1);
            }
        }

        Log.d("Preview", "setupCameraParameters: time after white balance: " + (System.currentTimeMillis() - v));
        Log.d("Preview", "set up antibanding");
        String s2 = preview0.applicationInterface.getAntiBandingPref();
        Log.d("Preview", "saved antibanding: " + s2);
        CameraController.SupportedValues cameraController$SupportedValues2 = preview0.camera_controller.setAntiBanding(s2);
        if (cameraController$SupportedValues2 != null) {
            preview0.antibanding = cameraController$SupportedValues2.values;
        }

        Log.d("Preview", "set up edge_mode");
        String s3 = preview0.applicationInterface.getEdgeModePref();
        Log.d("Preview", "saved edge_mode: " + s3);
        CameraController.SupportedValues cameraController$SupportedValues3 = preview0.camera_controller.setEdgeMode(s3);
        if (cameraController$SupportedValues3 != null) {
            preview0.edge_modes = cameraController$SupportedValues3.values;
        }

        Log.d("Preview", "set up noise_reduction_mode");
        String s4 = preview0.applicationInterface.getCameraNoiseReductionModePref();
        Log.d("Preview", "saved noise_reduction_mode: " + s4);
        CameraController.SupportedValues cameraController$SupportedValues4 = preview0.camera_controller.setNoiseReductionMode(s4);
        if (cameraController$SupportedValues4 != null) {
            preview0.noise_reduction_modes = cameraController$SupportedValues4.values;
        }

        Log.d("Preview", "set up iso");
        String s5 = preview0.applicationInterface.getISOPref();
        Log.d("Preview", "saved iso: " + s5);
        if (preview0.supports_iso_range) {
            preview0.isos = null;
            if (s5.equals("auto")) {
                Log.d("Preview", "setting auto iso");
                preview0.camera_controller.setManualISO(false, 0);
                v3 = 0;
            } else {
                int v4 = preview0.parseManualISOValue(s5);
                if (v4>=0) {
                    Log.d("Preview", "iso: " + v4);
                    preview0.camera_controller.setManualISO(true, v4);
                    v3 = 1;
                } else {
                    preview0.camera_controller.setManualISO(false, 0);
                    s5 = "auto";
                    v3 = 0;
                }

                preview0.applicationInterface.setISOPref(s5);
            }
        } else {
            CameraController.SupportedValues cameraController$SupportedValues5 = preview0.camera_controller.setISO(s5);
            if (cameraController$SupportedValues5 == null) {
                preview0.applicationInterface.clearISOPref();
                v3 = 0;
            } else {
                preview0.isos = cameraController$SupportedValues5.values;
                if (cameraController$SupportedValues5.selected_value.equals("auto")) {
                    v3 = 0;
                } else {
                    Log.d("Preview", "has manual iso");
                    v3 = 1;
                }

                preview0.applicationInterface.setISOPref(cameraController$SupportedValues5.selected_value);
            }
        }

        if (v3 != 0) {
            if (preview0.supports_exposure_time) {
                long v5 = preview0.applicationInterface.getExposureTimePref();
                Log.d("Preview", "saved exposure_time: " + v5);
                if (v5<this.getMinimumExposureTime()) {
                    v5 = this.getMinimumExposureTime();
                } else if (v5>this.getMaximumExposureTime()) {
                    v5 = this.getMaximumExposureTime();
                }

                preview0.camera_controller.setExposureTime(v5);
                preview0.applicationInterface.setExposureTimePref(v5);
            } else {
                preview0.applicationInterface.clearExposureTimePref();
            }

            if (preview0.supported_flash_values != null) {
                Log.d("Preview", "restrict flash modes for manual mode");
                ArrayList arrayList0 = new ArrayList();
                for (Object object0 : preview0.supported_flash_values) {
                    String s6 = (String) object0;
                    s6.hashCode();
                    switch (s6.hashCode()) {
                        case 0xBBA354A0: {
                            v6 = s6.equals("flash_off") ? 0 : -1;
                            break;
                        }
                        case 0xFF5F6AB8: {
                            v6 = s6.equals("flash_frontscreen_on") ? 1 : -1;
                            break;
                        }
                        case 0x10C9C83: {
                            v6 = s6.equals("flash_frontscreen_torch") ? 2 : -1;
                            break;
                        }
                        case 0x606B72ED: {
                            v6 = s6.equals("flash_torch") ? 3 : -1;
                            break;
                        }
                        case 0x60E43C8E: {
                            v6 = s6.equals("flash_on") ? 4 : -1;
                            break;
                        }
                        default: {
                            v6 = -1;
                        }
                    }

                    switch (v6) {
                        case 0:
                        case 1:
                        case 2:
                        case 3:
                        case 4: {
//                            label_441:
                            arrayList0.add(s6);
                        }
                    }

                    continue;

                }

                preview0.supported_flash_values = arrayList0;
            }
        }

        Log.d("Preview", "setupCameraParameters: time after manual iso: " + (System.currentTimeMillis() - v));
        Log.d("Preview", "set up exposure compensation");
        Log.d("Preview", "min_exposure: " + preview0.min_exposure);
        Log.d("Preview", "max_exposure: " + preview0.max_exposure);
        preview0.exposures = null;
        if (preview0.min_exposure == 0 && preview0.max_exposure == 0) {
            preview0.applicationInterface.clearExposureCompensationPref();
        } else {
            preview0.exposures = new ArrayList();
            int v7;
            for (v7 = preview0.min_exposure; v7<=preview0.max_exposure; ++v7) {
                preview0.exposures.add("" + v7);
            }

            if (v3 == 0) {
                int v8 = preview0.applicationInterface.getExposureCompensationPref();
                if (v8<preview0.min_exposure || v8>preview0.max_exposure) {
                    Log.d("Preview", "saved exposure not supported, reset to 0");
                    if (preview0.min_exposure<=0 && preview0.max_exposure>=0) {
                        v8 = 0;
                    } else {
                        Log.d("Preview", "zero isn\'t an allowed exposure?! reset to min " + preview0.min_exposure);
                        v8 = preview0.min_exposure;
                    }
                }

                preview0.camera_controller.setExposureCompensation(v8);
                preview0.applicationInterface.setExposureCompensationPref(v8);
            }
        }

        Log.d("Preview", "setupCameraParameters: time after exposures: " + (System.currentTimeMillis() - v));
        if (preview0.supported_apertures != null) {
            float f = preview0.applicationInterface.getAperturePref();
            if (f>0.0f) {
                float[] arr_f = preview0.supported_apertures;
                int v9 = arr_f.length;
                int v10;
                for (v10 = 0; v10<v9; ++v10) {
                    if (arr_f[v10] == f) {
                        preview0.camera_controller.setAperture(f);
                    }
                }
            }
        }

        Log.d("Preview", "set up picture sizes");
        int v11;
        for (v11 = 0; v11<preview0.photo_sizes.size(); ++v11) {
            CameraController.Size cameraController$Size0 = (CameraController.Size) preview0.photo_sizes.get(v11);
            Log.d("Preview", "supported picture size: " + cameraController$Size0.width + " , " + cameraController$Size0.height);
        }

        preview0.current_size_index = -1;
        ApplicationInterface.CameraResolutionConstraints applicationInterface$CameraResolutionConstraints0 = new ApplicationInterface.CameraResolutionConstraints();
        preview0.photo_size_constraints = applicationInterface$CameraResolutionConstraints0;
        Pair pair0 = preview0.applicationInterface.getCameraResolutionPref(applicationInterface$CameraResolutionConstraints0);
        if (pair0 != null) {
            int v12 = (int) (((Integer) pair0.first));
            int v13 = (int) (((Integer) pair0.second));
            int v14;
            for (v14 = 0; v14<preview0.photo_sizes.size() && preview0.current_size_index == -1; ++v14) {
                CameraController.Size cameraController$Size1 = (CameraController.Size) preview0.photo_sizes.get(v14);
                if (cameraController$Size1.width == v12 && cameraController$Size1.height == v13) {
                    preview0.current_size_index = v14;
                    Log.d("Preview", "set current_size_index to: " + preview0.current_size_index);
                }
            }

            if (preview0.current_size_index == -1) {
                Log.e("Preview", "failed to find valid size");
            }
        }

        if (preview0.current_size_index == -1) {
            CameraController.Size cameraController$Size2 = null;
            int v15;
            for (v15 = 0; v15<preview0.photo_sizes.size(); ++v15) {
                CameraController.Size cameraController$Size3 = (CameraController.Size) preview0.photo_sizes.get(v15);
                if (cameraController$Size2 == null || cameraController$Size3.width * cameraController$Size3.height>cameraController$Size2.width * cameraController$Size2.height) {
                    preview0.current_size_index = v15;
                    cameraController$Size2 = cameraController$Size3;
                }
            }
        }

        CameraController.Size cameraController$Size4 = this.getCurrentPictureSize();
        if (cameraController$Size4 != null) {
            Log.d("Preview", "Current size index " + preview0.current_size_index + ": " + cameraController$Size4.width + ", " + cameraController$Size4.height);
            preview0.applicationInterface.setCameraResolutionPref(cameraController$Size4.width, cameraController$Size4.height);
            if (!preview0.photo_size_constraints.satisfies(cameraController$Size4)) {
                Log.d("Preview", "current size index fail to satisfy constraints");
                CameraController.Size cameraController$Size5 = null;
                int v16;
                for (v16 = 0; v16<preview0.photo_sizes.size(); ++v16) {
                    CameraController.Size cameraController$Size6 = (CameraController.Size) preview0.photo_sizes.get(v16);
                    if ((preview0.photo_size_constraints.satisfies(cameraController$Size6)) && (cameraController$Size5 == null || cameraController$Size6.width * cameraController$Size6.height>cameraController$Size5.width * cameraController$Size5.height)) {
                        preview0.current_size_index = v16;
                        cameraController$Size5 = cameraController$Size6;
                    }
                }

                if (cameraController$Size5 == null) {
                    Log.e("Preview", "can\'t find picture size that satisfies the constraints!");
                    int v17;
                    for (v17 = 0; v17<preview0.photo_sizes.size(); ++v17) {
                        CameraController.Size cameraController$Size7 = (CameraController.Size) preview0.photo_sizes.get(v17);
                        if (cameraController$Size5 == null || cameraController$Size7.width * cameraController$Size7.height<cameraController$Size5.width * cameraController$Size5.height) {
                            preview0.current_size_index = v17;
                            cameraController$Size5 = cameraController$Size7;
                        }
                    }
                }

                Log.d("Preview", "Updated size index " + preview0.current_size_index + ": " + cameraController$Size4.width + ", " + cameraController$Size4.height);
            }
        }

        Log.d("Preview", "setupCameraParameters: time after picture sizes: " + (System.currentTimeMillis() - v));
        int v18 = preview0.applicationInterface.getImageQualityPref();
        Log.d("Preview", "set up jpeg quality: " + v18);
        preview0.camera_controller.setJpegQuality(v18);
        Log.d("Preview", "setupCameraParameters: time after jpeg quality: " + (System.currentTimeMillis() - v));
        this.initialiseVideoSizes();
        this.initialiseVideoQuality();
        Log.d("Preview", "setupCameraParameters: time after video sizes: " + (System.currentTimeMillis() - v));
        String s7 = preview0.applicationInterface.getVideoQualityPref();
        Log.d("Preview", "video_quality_value: " + s7);
        preview0.video_quality_handler.setCurrentVideoQualityIndex(-1);
        if (s7.length()>0) {
            int v19;
            for (v19 = 0; v19<preview0.video_quality_handler.getSupportedVideoQuality().size() && preview0.video_quality_handler.getCurrentVideoQualityIndex() == -1; ++v19) {
                if (((String) preview0.video_quality_handler.getSupportedVideoQuality().get(v19)).equals(s7)) {
                    preview0.video_quality_handler.setCurrentVideoQualityIndex(v19);
                    Log.d("Preview", "set current_video_quality to: " + preview0.video_quality_handler.getCurrentVideoQualityIndex());
                }
            }

            if (preview0.video_quality_handler.getCurrentVideoQualityIndex() == -1) {
                Log.e("Preview", "failed to find valid video_quality");
            }
        }

        if (preview0.video_quality_handler.getCurrentVideoQualityIndex() == -1 && preview0.video_quality_handler.getSupportedVideoQuality().size()>0) {
            preview0.video_quality_handler.setCurrentVideoQualityIndex(0);
            int v20;
            for (v20 = 0; v20<preview0.video_quality_handler.getSupportedVideoQuality().size(); ++v20) {
                Log.d("Preview", "check video quality: " + ((String) preview0.video_quality_handler.getSupportedVideoQuality().get(v20)));
                CamcorderProfile camcorderProfile0 = preview0.getCamcorderProfile(((String) preview0.video_quality_handler.getSupportedVideoQuality().get(v20)));
                if (camcorderProfile0.videoFrameWidth == 0x780 && camcorderProfile0.videoFrameHeight == 1080) {
                    preview0.video_quality_handler.setCurrentVideoQualityIndex(v20);
                    break;
                }
            }

            Log.d("Preview", "set video_quality value to " + preview0.video_quality_handler.getCurrentVideoQuality());
        }

        if (preview0.video_quality_handler.getCurrentVideoQualityIndex() == -1) {
            Log.e("Preview", "no video qualities found");
            preview0.supports_video = false;
        } else {
            String s8 = preview0.video_quality_handler.getCurrentVideoQuality();
            preview0.applicationInterface.setVideoQualityPref(s8);
        }

        Log.d("Preview", "setupCameraParameters: time after handling video quality: " + (System.currentTimeMillis() - v));
        if (preview0.supports_video) {
            float f1 = preview0.applicationInterface.getVideoCaptureRateFactor();
            preview0.capture_rate_factor = f1;
            preview0.has_capture_rate_factor = Math.abs(f1 - 1.0f)>0.00001f;
            Log.d("Preview", "has_capture_rate_factor: " + preview0.has_capture_rate_factor);
            Log.d("Preview", "capture_rate_factor: " + preview0.capture_rate_factor);
            preview0.video_high_speed = false;
            if (preview0.supports_video_high_speed) {
                VideoProfile videoProfile0 = this.getVideoProfile();
                Log.d("Preview", "check if we need high speed video for " + videoProfile0.videoFrameWidth + " x " + videoProfile0.videoFrameHeight + " at fps " + videoProfile0.videoCaptureRate);
                CameraController.Size cameraController$Size8 = preview0.video_quality_handler.findVideoSizeForFrameRate(videoProfile0.videoFrameWidth, videoProfile0.videoFrameHeight, videoProfile0.videoCaptureRate);
                if (cameraController$Size8 == null && preview0.video_quality_handler.getSupportedVideoSizesHighSpeed() != null) {
                    Log.e("Preview", "can\'t find match for capture rate: " + videoProfile0.videoCaptureRate + " and video size: " + videoProfile0.videoFrameWidth + " x " + videoProfile0.videoFrameHeight + " at fps " + videoProfile0.videoCaptureRate);
                    CameraController.Size cameraController$Size9 = preview0.video_quality_handler.getMaxSupportedVideoSizeHighSpeed();
                    videoProfile0.videoFrameWidth = cameraController$Size9.width;
                    videoProfile0.videoFrameHeight = cameraController$Size9.height;
                    cameraController$Size8 = CameraController.CameraFeatures.findSize(preview0.video_quality_handler.getSupportedVideoSizesHighSpeed(), cameraController$Size9, videoProfile0.videoCaptureRate, false);
                    if (cameraController$Size8 != null) {
                        Log.d("Preview", "fall back to a supported video size for high speed fps");
                        preview0.video_quality_handler.setCurrentVideoQualityIndex(-1);
                        int v21;
                        for (v21 = 0; v21<preview0.video_quality_handler.getSupportedVideoQuality().size(); ++v21) {
                            Log.d("Preview", "check video quality: " + ((String) preview0.video_quality_handler.getSupportedVideoQuality().get(v21)));
                            CamcorderProfile camcorderProfile1 = preview0.getCamcorderProfile(((String) preview0.video_quality_handler.getSupportedVideoQuality().get(v21)));
                            if (camcorderProfile1.videoFrameWidth == videoProfile0.videoFrameWidth && camcorderProfile1.videoFrameHeight == videoProfile0.videoFrameHeight) {
                                preview0.video_quality_handler.setCurrentVideoQualityIndex(v21);
                                break;
                            }
                        }

                        if (preview0.video_quality_handler.getCurrentVideoQualityIndex() == -1) {
                            Log.d("Preview", "but couldn\'t find a corresponding video quality");
                            cameraController$Size8 = null;
                        } else {
                            Log.d("Preview", "reset to video quality: " + preview0.video_quality_handler.getCurrentVideoQuality());
                            String s9 = preview0.video_quality_handler.getCurrentVideoQuality();
                            preview0.applicationInterface.setVideoQualityPref(s9);
                        }
                    }
                }

                if (cameraController$Size8 == null) {
                    Log.e("Preview", "fps not supported for this video size: " + videoProfile0.videoFrameWidth + " x " + videoProfile0.videoFrameHeight + " at fps " + videoProfile0.videoCaptureRate);
                } else if (cameraController$Size8.high_speed) {
                    preview0.video_high_speed = true;
                }
            }

            Log.d("Preview", "video_high_speed?: " + preview0.video_high_speed);
        }

        if ((preview0.is_video) && (preview0.video_high_speed) && (preview0.supports_iso_range) && v3 != 0) {
            Log.d("Preview", "manual mode not supported for video_high_speed");
            preview0.camera_controller.setManualISO(false, 0);
            v3 = 0;
        }

        Log.d("Preview", "set up flash");
        Log.d("Preview", "flash values: " + preview0.supported_flash_values);
        preview0.current_flash_index = -1;
        if (preview0.supported_flash_values != null && preview0.supported_flash_values.size()>1) {
            String s10 = preview0.applicationInterface.getFlashPref();
            if (s10.length()>0) {
                Log.d("Preview", "found existing flash_value: " + s10);
                if (!preview0.updateFlash(s10, false)) {
                    Log.d("Preview", "flash value no longer supported!");
                    boolean v3b = true;
                    if (v3 == 0) {
                        v3b = false;
                    }
                    preview0.updateFlash(0, v3b);
                }
            } else {
                Log.d("Preview", "found no existing flash_value");
                if (preview0.supported_flash_values.contains("flash_auto")) {
                    preview0.updateFlash("flash_auto", true);
                } else {
                    preview0.updateFlash("flash_off", true);
                }
            }
        } else {
            Log.d("Preview", "flash not supported");
            preview0.supported_flash_values = null;
            preview0.mainActivity.findViewById(0x7F0A0238).setVisibility(View.GONE);  // id:li_flash
        }

        Log.d("Preview", "setupCameraParameters: time after setting up flash: " + (System.currentTimeMillis() - v));
        Log.d("Preview", "set up focus");
        preview0.current_focus_index = -1;
        if (preview0.supported_focus_values != null && preview0.supported_focus_values.size()>1) {
            Log.d("Preview", "focus values: " + preview0.supported_focus_values);
            preview0.setFocusPref(true);
        } else {
            Log.d("Preview", "focus not supported");
            preview0.supported_focus_values = null;
        }

        float f2 = preview0.applicationInterface.getFocusDistancePref(false);
        Log.d("Preview", "saved focus_distance: " + f2);
        if (f2<0.0f) {
            f2 = 0.0f;
        } else {
            float f3 = preview0.minimum_focus_distance;
            if (f2>f3) {
                f2 = f3;
            }
        }

        preview0.camera_controller.setFocusDistance(f2);
        preview0.camera_controller.setFocusBracketingSourceDistance(f2);
        preview0.applicationInterface.setFocusDistancePref(f2, false);
        float f4 = preview0.applicationInterface.getFocusDistancePref(true);
        Log.d("Preview", "saved focus_bracketing_target_distance: " + f4);
        if (f4<0.0f) {
            f5 = 0.0f;
        } else {
            f5 = preview0.minimum_focus_distance;
            if (f4<=f5) {
                f5 = f4;
            }
        }

        preview0.camera_controller.setFocusBracketingTargetDistance(f5);
        preview0.applicationInterface.setFocusDistancePref(f5, true);
        Log.d("Preview", "setupCameraParameters: time after setting up focus: " + (System.currentTimeMillis() - v));
        Log.d("Preview", "set up exposure lock");
        preview0.is_exposure_locked = false;
        Log.d("Preview", "set up white balance lock");
        preview0.is_white_balance_locked = false;
        Log.d("Preview", "setupCameraParameters: total time for setting up camera parameters: " + (System.currentTimeMillis() - v));
    }

    private void setPreviewSize() {
        CameraController.Size currentPictureSize;
        Log.d(TAG, "setPreviewSize()");
        if (this.camera_controller == null) {
            Log.d(TAG, "camera not opened!");
        } else if (this.is_preview_started) {
            Log.e(TAG, "setPreviewSize() shouldn't be called when preview is running");
        } else {
            if (!this.using_android_l) {
                cancelAutoFocus();
            }
            if (this.is_video) {
                VideoProfile videoProfile = getVideoProfile();
                Log.d(TAG, "video size: " + videoProfile.videoFrameWidth + " x " + videoProfile.videoFrameHeight);
                if (this.video_high_speed) {
                    currentPictureSize = new CameraController.Size(videoProfile.videoFrameWidth, videoProfile.videoFrameHeight);
                } else {
                    currentPictureSize = getOptimalVideoPictureSize(this.photo_sizes, videoProfile.videoFrameWidth / videoProfile.videoFrameHeight);
                }
            } else {
                currentPictureSize = getCurrentPictureSize();
            }
            if (currentPictureSize != null) {
                this.camera_controller.setPictureSize(currentPictureSize.width, currentPictureSize.height);
            }
            List<CameraController.Size> list = this.supported_preview_sizes;
            if (list.size()>0) {
                Log.d("RRRR", "List" + list.toString());
                CameraController.Size optimalPreviewSize = getOptimalPreviewSize(this.supported_preview_sizes);
                this.camera_controller.setPreviewSize(optimalPreviewSize.width, optimalPreviewSize.height);
                this.set_preview_size = true;
                this.preview_w = optimalPreviewSize.width;
                this.preview_h = optimalPreviewSize.height;
                Log.d("RRRR", "SIZE" + preview_w + "::::" + preview_h);
                if (optimalPreviewSize.width == 1920 && optimalPreviewSize.height == 1080) {
                    setAspectRatio(1.3);
                } else {
                    setAspectRatio(optimalPreviewSize.width / optimalPreviewSize.height);
                }
            }
            this.mainActivity.refreshAdapter(this.current_size_index, currentPictureSize.width, currentPictureSize.height);
            this.mainActivity.findViewById(R.id.hide_container).setVisibility(View.GONE);
        }
    }

    private void initialiseVideoSizes() {
        if (this.camera_controller == null) {
            Log.d(TAG, "camera not opened!");
        } else {
            this.video_quality_handler.sortVideoSizes();
        }
    }

    private void initialiseVideoQuality() {
        int cameraId = this.camera_controller.getCameraId();
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        if (CamcorderProfile.hasProfile(cameraId, 1)) {
            CamcorderProfile camcorderProfile = CamcorderProfile.get(cameraId, 1);
            arrayList.add(1);
            arrayList2.add(new VideoQualityHandler.Dimension2D(camcorderProfile.videoFrameWidth, camcorderProfile.videoFrameHeight));
        }
        if (Build.VERSION.SDK_INT>=21 && CamcorderProfile.hasProfile(cameraId, 8)) {
            CamcorderProfile camcorderProfile2 = CamcorderProfile.get(cameraId, 8);
            arrayList.add(8);
            arrayList2.add(new VideoQualityHandler.Dimension2D(camcorderProfile2.videoFrameWidth, camcorderProfile2.videoFrameHeight));
        }
        if (CamcorderProfile.hasProfile(cameraId, 6)) {
            CamcorderProfile camcorderProfile3 = CamcorderProfile.get(cameraId, 6);
            arrayList.add(6);
            arrayList2.add(new VideoQualityHandler.Dimension2D(camcorderProfile3.videoFrameWidth, camcorderProfile3.videoFrameHeight));
        }
        if (CamcorderProfile.hasProfile(cameraId, 5)) {
            CamcorderProfile camcorderProfile4 = CamcorderProfile.get(cameraId, 5);
            arrayList.add(5);
            arrayList2.add(new VideoQualityHandler.Dimension2D(camcorderProfile4.videoFrameWidth, camcorderProfile4.videoFrameHeight));
        }
        if (CamcorderProfile.hasProfile(cameraId, 4)) {
            CamcorderProfile camcorderProfile5 = CamcorderProfile.get(cameraId, 4);
            arrayList.add(4);
            arrayList2.add(new VideoQualityHandler.Dimension2D(camcorderProfile5.videoFrameWidth, camcorderProfile5.videoFrameHeight));
        }
        if (CamcorderProfile.hasProfile(cameraId, 3)) {
            CamcorderProfile camcorderProfile6 = CamcorderProfile.get(cameraId, 3);
            arrayList.add(3);
            arrayList2.add(new VideoQualityHandler.Dimension2D(camcorderProfile6.videoFrameWidth, camcorderProfile6.videoFrameHeight));
        }
        if (CamcorderProfile.hasProfile(cameraId, 7)) {
            CamcorderProfile camcorderProfile7 = CamcorderProfile.get(cameraId, 7);
            arrayList.add(7);
            arrayList2.add(new VideoQualityHandler.Dimension2D(camcorderProfile7.videoFrameWidth, camcorderProfile7.videoFrameHeight));
        }
        if (CamcorderProfile.hasProfile(cameraId, 2)) {
            CamcorderProfile camcorderProfile8 = CamcorderProfile.get(cameraId, 2);
            arrayList.add(2);
            arrayList2.add(new VideoQualityHandler.Dimension2D(camcorderProfile8.videoFrameWidth, camcorderProfile8.videoFrameHeight));
        }
        if (CamcorderProfile.hasProfile(cameraId, 0)) {
            CamcorderProfile camcorderProfile9 = CamcorderProfile.get(cameraId, 0);
            arrayList.add(0);
            arrayList2.add(new VideoQualityHandler.Dimension2D(camcorderProfile9.videoFrameWidth, camcorderProfile9.videoFrameHeight));
        }
        this.video_quality_handler.initialiseVideoQualityFromProfiles(arrayList, arrayList2);
    }

    private CamcorderProfile getCamcorderProfile(String str) {
        String str2;
        int i;
        Log.d(TAG, "getCamcorderProfile(): " + str);
        CameraController cameraController = this.camera_controller;
        if (cameraController == null) {
            Log.d(TAG, "camera not opened!");
            return CamcorderProfile.get(0, 1);
        }
        int cameraId = cameraController.getCameraId();
        CamcorderProfile camcorderProfile = CamcorderProfile.get(cameraId, 1);
        try {
            int indexOf = str.indexOf(95);
            if (indexOf != -1) {
                str2 = str.substring(0, indexOf);
                Log.d(TAG, "    profile_string: " + str2);
            } else {
                str2 = str;
            }
            camcorderProfile = CamcorderProfile.get(cameraId, Integer.parseInt(str2));
            if (indexOf != -1 && (i = indexOf + 1)<str.length()) {
                String substring = str.substring(i);
                Log.d(TAG, "    override_string: " + substring);
                if (substring.charAt(0) == 'r' && substring.length()>=4) {
                    int indexOf2 = substring.indexOf(120);
                    if (indexOf2 == -1) {
                        Log.d(TAG, "override_string invalid format, can't find x");
                    } else {
                        String substring2 = substring.substring(1, indexOf2);
                        String substring3 = substring.substring(indexOf2 + 1);
                        Log.d(TAG, "resolution_w_s: " + substring2);
                        Log.d(TAG, "resolution_h_s: " + substring3);
                        int parseInt = Integer.parseInt(substring2);
                        int parseInt2 = Integer.parseInt(substring3);
                        camcorderProfile.videoFrameWidth = parseInt;
                        camcorderProfile.videoFrameHeight = parseInt2;
                    }
                } else {
                    Log.d(TAG, "unknown override_string initial code, or otherwise invalid format");
                }
            }
        } catch (NumberFormatException e) {
            Log.e(TAG, "failed to parse video quality: " + str);
            e.printStackTrace();
        }
        return camcorderProfile;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public VideoProfile getVideoProfile() {
        CamcorderProfile camcorderProfile;
        char c;
        char c2;
        if (this.camera_controller == null) {
            VideoProfile videoProfile = new VideoProfile();
            Log.e(TAG, "camera not opened! returning default video profile for QUALITY_HIGH");
            return videoProfile;
        }
        boolean recordAudioPref = this.applicationInterface.getRecordAudioPref();
        String recordAudioChannelsPref = this.applicationInterface.getRecordAudioChannelsPref();
        String videoFPSPref = this.applicationInterface.getVideoFPSPref();
        String videoBitratePref = this.applicationInterface.getVideoBitratePref();
        boolean force4KPref = this.applicationInterface.getForce4KPref();
        int cameraId = this.camera_controller.getCameraId();
        if (force4KPref && !this.video_high_speed) {
            Log.d(TAG, "force 4K UHD video");
            camcorderProfile = CamcorderProfile.get(cameraId, 1);
            camcorderProfile.videoFrameWidth = 3840;
            camcorderProfile.videoFrameHeight = 2160;
            camcorderProfile.videoBitRate = (int) (camcorderProfile.videoBitRate * 2.8d);
        } else {
            camcorderProfile = this.video_quality_handler.getCurrentVideoQualityIndex() != -1 ? getCamcorderProfile(this.video_quality_handler.getCurrentVideoQuality()) : null;
        }
        VideoProfile videoProfile2 = camcorderProfile != null ? new VideoProfile(camcorderProfile) : new VideoProfile();
        if (!videoFPSPref.equals("default")) {
            try {
                int parseInt = Integer.parseInt(videoFPSPref);
                Log.d(TAG, "fps: " + parseInt);
                videoProfile2.videoFrameRate = parseInt;
                videoProfile2.videoCaptureRate = (double) parseInt;
            } catch (NumberFormatException unused) {
                Log.d(TAG, "fps invalid format, can't parse to int: " + videoFPSPref);
            }
        }
        if (!videoBitratePref.equals("default")) {
            try {
                int parseInt2 = Integer.parseInt(videoBitratePref);
                Log.d(TAG, "bitrate: " + parseInt2);
                videoProfile2.videoBitRate = parseInt2;
            } catch (NumberFormatException unused2) {
                Log.d(TAG, "bitrate invalid format, can't parse to int: " + videoBitratePref);
            }
        }
        if (this.video_high_speed && videoProfile2.videoBitRate<56000000) {
            videoProfile2.videoBitRate = 56000000;
            Log.d(TAG, "set minimum bitrate for high speed: " + videoProfile2.videoBitRate);
        }
        if (this.has_capture_rate_factor) {
            Log.d(TAG, "set video profile frame rate for slow motion or timelapse, capture rate: " + this.capture_rate_factor);
            float f = this.capture_rate_factor;
            if (f<1.0d) {
                videoProfile2.videoFrameRate = (int) ((videoProfile2.videoFrameRate * this.capture_rate_factor) + 0.5f);
                videoProfile2.videoBitRate = (int) ((videoProfile2.videoBitRate * this.capture_rate_factor) + 0.5f);
                Log.d(TAG, "scaled frame rate to: " + videoProfile2.videoFrameRate);
                if (Math.abs(this.capture_rate_factor - 0.5f)<1.0E-5f) {
                    videoProfile2.videoCaptureRate += 0.001d;
                    Log.d(TAG, "fudged videoCaptureRate to: " + videoProfile2.videoCaptureRate);
                }
            } else if (f>1.0d) {
                videoProfile2.videoCaptureRate /= this.capture_rate_factor;
                Log.d(TAG, "scaled capture rate to: " + videoProfile2.videoCaptureRate);
                if (Math.abs(this.capture_rate_factor - 2.0f)<1.0E-5f) {
                    videoProfile2.videoCaptureRate -= 0.0010000000474974513d;
                    Log.d(TAG, "fudged videoCaptureRate to: " + videoProfile2.videoCaptureRate);
                }
            }
            recordAudioPref = false;
        }
        if (this.using_android_l && Build.VERSION.SDK_INT>=21) {
            videoProfile2.videoSource = 2;
        } else {
            videoProfile2.videoSource = 1;
        }
        if (Build.VERSION.SDK_INT>=23 && recordAudioPref && ContextCompat.checkSelfPermission(getContext(), "android.permission.RECORD_AUDIO") != 0) {
            Log.e(TAG, "don't have RECORD_AUDIO permission");
            videoProfile2.no_audio_permission = true;
            recordAudioPref = false;
        }
        videoProfile2.record_audio = recordAudioPref;
        if (recordAudioPref) {
            String recordAudioSourcePref = this.applicationInterface.getRecordAudioSourcePref();
            Log.d(TAG, "pref_audio_src: " + recordAudioSourcePref);
            switch (recordAudioSourcePref.hashCode()) {
                case -1778647043:
                    if (recordAudioSourcePref.equals("audio_src_default")) {
                        c2 = 1;
                        break;
                    }
                    c2 = 65535;
                    break;
                case -1591996925:
                    if (recordAudioSourcePref.equals("audio_src_mic")) {
                        c2 = 0;
                        break;
                    }
                    c2 = 65535;
                    break;
                case 349734033:
                    if (recordAudioSourcePref.equals("audio_src_unprocessed")) {
                        c2 = 4;
                        break;
                    }
                    c2 = 65535;
                    break;
                case 573829957:
                    if (recordAudioSourcePref.equals("audio_src_voice_communication")) {
                        c2 = 2;
                        break;
                    }
                    c2 = 65535;
                    break;
                case 799584998:
                    if (recordAudioSourcePref.equals("audio_src_voice_recognition")) {
                        c2 = 3;
                        break;
                    }
                    c2 = 65535;
                    break;
                case 1217798166:
                    if (recordAudioSourcePref.equals("audio_src_camcorder")) {
                        c2 = 5;
                        break;
                    }
                    c2 = 65535;
                    break;
                default:
                    c2 = 65535;
                    break;
            }
            if (c2 == 0) {
                videoProfile2.audioSource = 1;
            } else if (c2 == 1) {
                videoProfile2.audioSource = 0;
            } else if (c2 == 2) {
                videoProfile2.audioSource = 7;
            } else if (c2 == 3) {
                videoProfile2.audioSource = 6;
            } else if (c2 == 4) {
                if (Build.VERSION.SDK_INT>=24) {
                    videoProfile2.audioSource = 9;
                } else {
                    Log.e(TAG, "audio_src_voice_unprocessed requires Android 7");
                    videoProfile2.audioSource = 5;
                }
            } else {
                videoProfile2.audioSource = 5;
            }
            Log.d(TAG, "audio_source: " + videoProfile2.audioSource);
            Log.d(TAG, "pref_audio_channels: " + recordAudioChannelsPref);
            if (recordAudioChannelsPref.equals("audio_mono")) {
                videoProfile2.audioChannels = 1;
            } else if (recordAudioChannelsPref.equals("audio_stereo")) {
                videoProfile2.audioChannels = 2;
            }
        }
        String recordVideoOutputFormatPref = this.applicationInterface.getRecordVideoOutputFormatPref();
        Log.d(TAG, "pref_video_output_format: " + recordVideoOutputFormatPref);
        recordVideoOutputFormatPref.hashCode();
        switch (recordVideoOutputFormatPref.hashCode()) {
            case 474898602:
                if (recordVideoOutputFormatPref.equals("preference_video_output_format_mpeg4_h264")) {
                    c = 0;
                    break;
                }
                c = 65535;
                break;
            case 474949644:
                if (recordVideoOutputFormatPref.equals("preference_video_output_format_mpeg4_hevc")) {
                    c = 1;
                    break;
                }
                c = 65535;
                break;
            case 527338191:
                if (recordVideoOutputFormatPref.equals("preference_video_output_format_default")) {
                    c = 2;
                    break;
                }
                c = 65535;
                break;
            case 1642530246:
                if (recordVideoOutputFormatPref.equals("preference_video_output_format_3gpp")) {
                    c = 3;
                    break;
                }
                c = 65535;
                break;
            case 1644553675:
                if (recordVideoOutputFormatPref.equals("preference_video_output_format_webm")) {
                    c = 4;
                    break;
                }
                c = 65535;
                break;
            default:
                c = 65535;
                break;
        }
        switch (c) {
            case 0:
                videoProfile2.fileFormat = 2;
                videoProfile2.videoCodec = 2;
                videoProfile2.audioCodec = 3;
                break;
            case 1:
                if (Build.VERSION.SDK_INT>=24) {
                    videoProfile2.fileFormat = 2;
                    videoProfile2.videoCodec = 5;
                    videoProfile2.audioCodec = 3;
                    break;
                }
                break;
            case 2:
                break;
            case 3:
                videoProfile2.fileFormat = 1;
                videoProfile2.fileExtension = "3gp";
                break;
            case 4:
                if (Build.VERSION.SDK_INT>=21) {
                    videoProfile2.fileFormat = 9;
                    videoProfile2.videoCodec = 4;
                    videoProfile2.audioCodec = 6;
                    videoProfile2.fileExtension = "webm";
                    break;
                }
                break;
            default:
                Log.e(TAG, "unknown pref_video_output_format: " + recordVideoOutputFormatPref);
                break;
        }
        Log.d(TAG, "returning video_profile: " + videoProfile2);
        return videoProfile2;
    }

    private static String formatFloatToString(float f) {
        int i = (int) f;
        return f == ((float) i) ? Integer.toString(i) : String.format(Locale.getDefault(), "%.2f", Float.valueOf(f));
    }

    private static int greatestCommonFactor(int a, int b) {
        while (b>0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

//    private static int greatestCommonFactor(int i, int i2) {
//        while (true) {
//            int i3 = i2;
//            int i4 = i;
//            i = i3;
//            if (i<=0) {
//                return i4;
//            }
//            i2 = i4 % i;
//        }
//    }

    public static String getAspectRatio(int i, int i2) {
        int greatestCommonFactor = greatestCommonFactor(i, i2);
        if (greatestCommonFactor>0) {
            i /= greatestCommonFactor;
            i2 /= greatestCommonFactor;
        }
        return i + ":" + i2;
    }

    public static String getMPString(int i, int i2) {
        return formatFloatToString((i * i2) / 1000000.0f) + "MP";
    }

    private static String getBurstString(Resources resources, boolean z) {
        if (z) {
            return "";
        }
        return ", " + resources.getString(R.string.no_burst);
    }

    public static String getAspectRatioMPString(Resources resources, int i, int i2, boolean z) {
        return "" + getAspectRatio(i, i2) + ", " + getMPString(i, i2) + getBurstString(resources, z) + ")";
    }

    private String getCamcorderProfileDescriptionType(CamcorderProfile camcorderProfile) {
        return (camcorderProfile.videoFrameWidth == 3840 && camcorderProfile.videoFrameHeight == 2160) ? "4K" : (camcorderProfile.videoFrameWidth == 1920 && camcorderProfile.videoFrameHeight == 1080) ? "2K" : (camcorderProfile.videoFrameWidth == 1280 && camcorderProfile.videoFrameHeight == 720) ? "HD" : (camcorderProfile.videoFrameWidth == 720 && camcorderProfile.videoFrameHeight == 480) ? "SD" : (camcorderProfile.videoFrameWidth == 640 && camcorderProfile.videoFrameHeight == 480) ? "VGA" : (camcorderProfile.videoFrameWidth == 352 && camcorderProfile.videoFrameHeight == 288) ? "CIF" : (camcorderProfile.videoFrameWidth == 320 && camcorderProfile.videoFrameHeight == 240) ? "QVGA" : (camcorderProfile.videoFrameWidth == 176 && camcorderProfile.videoFrameHeight == 144) ? "QCIF" : "";
    }

    public String getCamcorderProfileDescriptionShort(String str) {
        if (this.camera_controller == null) {
            return "";
        }
        CamcorderProfile camcorderProfile = getCamcorderProfile(str);
        String camcorderProfileDescriptionType = getCamcorderProfileDescriptionType(camcorderProfile);
        String str2 = camcorderProfileDescriptionType.length() != 0 ? " " : "";
        return camcorderProfile.videoFrameWidth + "x" + camcorderProfile.videoFrameHeight + str2 + camcorderProfileDescriptionType;
    }

    public String getCamcorderProfileDescription(String str) {
        if (this.camera_controller == null) {
            return "";
        }
        CamcorderProfile camcorderProfile = getCamcorderProfile(str);
        String camcorderProfileDescriptionType = getCamcorderProfileDescriptionType(camcorderProfile);
        String str2 = camcorderProfileDescriptionType.length() != 0 ? " " : "";
        return camcorderProfileDescriptionType + str2 + camcorderProfile.videoFrameWidth + "x" + camcorderProfile.videoFrameHeight + " " + getAspectRatioMPString(getResources(), camcorderProfile.videoFrameWidth, camcorderProfile.videoFrameHeight, true);
    }

    public double getTargetRatio() {
        return this.preview_targetRatio;
    }

//    private double calculateTargetRatioForPreview(Point display_size) {
//        double targetRatio;
//        String preview_size = applicationInterface.getPreviewSizePref();
//        // should always use wysiwig for video mode, otherwise we get incorrect aspect ratio shown when recording video (at least on Galaxy Nexus, e.g., at 640x480)
//        // also not using wysiwyg mode with video caused corruption on Samsung cameras (tested with Samsung S3, Android 4.3, front camera, infinity focus)
//        if (preview_size.equals("preference_preview_size_wysiwyg") || this.is_video) {
//            if (this.is_video) {
//                if (MyDebug.LOG)
//                    Log.d(TAG, "set preview aspect ratio from video size (wysiwyg)");
//                VideoProfile profile = getVideoProfile();
//                if (MyDebug.LOG)
//                    Log.d(TAG, "video size: " + profile.videoFrameWidth + " x " + profile.videoFrameHeight);
//                targetRatio = ((double) profile.videoFrameWidth) / (double) profile.videoFrameHeight;
//            } else {
//                if (MyDebug.LOG)
//                    Log.d(TAG, "set preview aspect ratio from photo size (wysiwyg)");
//                CameraController.Size picture_size = camera_controller.getPictureSize();
//                if (MyDebug.LOG)
//                    Log.d(TAG, "picture_size: " + picture_size.width + " x " + picture_size.height);
//                targetRatio = ((double) picture_size.width) / (double) picture_size.height;
//            }
//        } else {
//            if (MyDebug.LOG)
//                Log.d(TAG, "set preview aspect ratio from display size");
//            // base target ratio from display size - means preview will fill the device's display as much as possible
//            // but if the preview's aspect ratio differs from the actual photo/video size, the preview will show a cropped version of what is actually taken
//            targetRatio = ((double) display_size.x) / (double) display_size.y;
//        }
//        this.preview_targetRatio = targetRatio;
//        if (MyDebug.LOG)
//            Log.d(TAG, "targetRatio: " + targetRatio);
//        return targetRatio;
//    }

    private double calculateTargetRatioForPreview(Point point0) {
        int v;
        double f;
        if (!this.applicationInterface.getPreviewSizePref().equals("preference_preview_size_wysiwyg") && !this.is_video) {
            Log.d("Preview", "set preview aspect ratio from display size");
            f = (double) point0.x;
            v = point0.y;
        } else if (this.is_video) {
            Log.d("Preview", "set preview aspect ratio from video size (wysiwyg)");
            VideoProfile videoProfile0 = this.getVideoProfile();
            Log.d("Preview", "video size: " + videoProfile0.videoFrameWidth + " x " + videoProfile0.videoFrameHeight);
            f = (double) videoProfile0.videoFrameWidth;
            v = videoProfile0.videoFrameHeight;
        } else {
//            Log.d("Preview", hBLTwvEiEoJfQT.EBPkglma);
            CameraController.Size cameraController$Size0 = this.camera_controller.getPictureSize();
            Log.d("Preview", "GfRTdme.UgoQYMfalhHJ" + cameraController$Size0.width + " x " + cameraController$Size0.height);
            f = (double) cameraController$Size0.width;
            v = cameraController$Size0.height;
        }

        double f1 = f / ((double) v);
        this.preview_targetRatio = f1;

        Log.d("RRRR", "targetRatio: " + f1);
        return f1;
    }

    private static CameraController.Size getClosestSize(List<CameraController.Size> list, double d, CameraController.Size size) {
        Log.d(TAG, "getClosestSize()");
        CameraController.Size size2 = null;
        double d2 = Double.MAX_VALUE;
        for (CameraController.Size size3 : list) {
            double d3 = size3.width / size3.height;
            if (size == null || (size3.width<=size.width && size3.height<=size.height)) {
                double d4 = d3 - d;
                if (Math.abs(d4)<d2) {
                    d2 = Math.abs(d4);
                    size2 = size3;
                }
            }
        }

        return size2;
    }


    //    private static CameraController.Size getClosestSize(List list0, double f, CameraController.Size cameraController$Size0) {
//        Log.d("Preview", "getClosestSize()");
//        Iterator iterator0 = list0.iterator();
//        CameraController.Size cameraController$Size1 = null;
//        double f1 = 1.797693E+308;
//        while(iterator0.hasNext()) {
//            Object object0 = iterator0.next();
//            CameraController.Size cameraController$Size2 = (CameraController.Size)object0;
//            double f2 = ((double)cameraController$Size2.width) / ((double)cameraController$Size2.height);
//            if(cameraController$Size0 != null && (cameraController$Size2.width > cameraController$Size0.width || cameraController$Size2.height > cameraController$Size0.height)) {
//                continue;
//            }
//
//            double f3 = f2 - f;
//            if(Math.abs(f3) >= f1) {
//                continue;
//            }
//
//            f1 = Math.abs(f3);
//            cameraController$Size1 = cameraController$Size2;
//        }
//
//        return cameraController$Size1;
//    }
    public CameraController.Size getOptimalPreviewSize(List<CameraController.Size> list) {
        Log.d(TAG, "getOptimalPreviewSize()");
        if (list == null) {
            return null;
        }
        if (this.is_video && this.video_high_speed) {
            VideoProfile videoProfile = getVideoProfile();
            Log.d(TAG, "video size: " + videoProfile.videoFrameWidth + " x " + videoProfile.videoFrameHeight);
            return new CameraController.Size(videoProfile.videoFrameWidth, videoProfile.videoFrameHeight);
        }
        double d = Double.MAX_VALUE;
        Point point = new Point();
        ((Activity) getContext()).getWindowManager().getDefaultDisplay().getSize(point);
        if (point.x<point.y) {
            point.set(point.y, point.x);
        }
        Log.d(TAG, "display_size: " + point.x + " x " + point.y);
        double calculateTargetRatioForPreview = calculateTargetRatioForPreview(point);
        int min = Math.min(point.y, point.x);
        if (min<=0) {
            min = point.y;
        }
        Iterator<CameraController.Size> it = list.iterator();
        CameraController.Size size = null;
        while (it.hasNext()) {
            CameraController.Size next = it.next();
            Log.d(TAG, "    supported preview size: " + next.width + ", " + next.height);
            Iterator<CameraController.Size> it2 = it;
            if (Math.abs((next.width / next.height) - calculateTargetRatioForPreview)<=0.05d && Math.abs(next.height - min)<d) {
                d = Math.abs(next.height - min);
                size = next;
            }
            it = it2;
        }
        if (size == null) {
            Log.d("RRRR", "no preview size matches the aspect ratio");
            size = getClosestSize(list, calculateTargetRatioForPreview, null);

        }
        Log.d(TAG, "chose optimalSize: " + size.width + " x " + size.height);
        StringBuilder sb = new StringBuilder();
        sb.append("optimalSize ratio: ");
        sb.append(((double) size.width) / ((double) size.height));
        Log.d(TAG, sb.toString());
        Log.d("RRRR", "OptimalPSize" + size);
        return size;

    }


    public CameraController.Size getOptimalVideoPictureSize(List<CameraController.Size> list, double d) {
        Log.d(TAG, "getOptimalVideoPictureSize()");
        return getOptimalVideoPictureSize(list, d, this.video_quality_handler.getMaxSupportedVideoSize());
    }

    public static CameraController.Size getOptimalVideoPictureSize(List<CameraController.Size> list, double d, CameraController.Size size) {
        Log.d(TAG, "getOptimalVideoPictureSize()");
        CameraController.Size size2 = null;
        if (list == null) {
            return null;
        }
        Log.d(TAG, "max_video_size: " + size.width + ", " + size.height);
        for (CameraController.Size size3 : list) {
            Log.d(TAG, "    supported preview size: " + size3.width + ", " + size3.height);
            if (Math.abs((size3.width / size3.height) - d)<=0.05d && size3.width<=size.width && size3.height<=size.height && (size2 == null || size3.width>size2.width)) {
                size2 = size3;
            }
        }
        if (size2 == null) {
            Log.d(TAG, "no picture size matches the aspect ratio");
            size2 = getClosestSize(list, d, size);
        }
        Log.d(TAG, "chose optimalSize: " + size2.width + " x " + size2.height);
        StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(((double) size2.width) / ((double) size2.height));
        Log.d(TAG, sb.toString());
        return size2;
    }

    private void setAspectRatio(double d) {
        Log.d("RRRR", "new aspect ratio:double " + d);
        if (d<=0.0d) {
            throw new IllegalArgumentException();
        }
        Log.d("RRRR", "new aspect ratio: " + this.aspect_ratio + "::::" + d);
        this.has_aspect_ratio = true;
        if (this.aspect_ratio != d) {
            this.aspect_ratio = d;
            Log.d("RRRR", "new aspect ratio: " + this.aspect_ratio);
            this.cameraSurface.getView().requestLayout();
            CanvasView canvasView = this.canvasView;
            if (canvasView != null) {
                canvasView.requestLayout();
            }
        }/*else {
            this.aspect_ratio = 1.3;
            this.cameraSurface.getView().requestLayout();
            CanvasView canvasView = this.canvasView;
            if (canvasView != null) {
                canvasView.requestLayout();
            }
        }*/

    }

    private boolean hasAspectRatio() {
        return this.has_aspect_ratio;
    }

    private double getAspectRatio() {
        return this.aspect_ratio;
    }

    public int getDisplayRotation() {
        int rotation = ((Activity) getContext()).getWindowManager().getDefaultDisplay().getRotation();
        String previewRotationPref = this.applicationInterface.getPreviewRotationPref();
        Log.d(TAG, "    rotate_preview = " + previewRotationPref);
        if (previewRotationPref.equals("180")) {
            if (rotation != 0) {
                if (rotation != 1) {
                    if (rotation != 2) {
                        if (rotation != 3) {
                            return rotation;
                        }
                        return 1;
                    }
                    return 0;
                }
                return 3;
            }
            return 2;
        }
        return rotation;
    }

    private int getDisplayRotationDegrees() {
        int rotation = applicationInterface.getDisplayRotation();
        int degrees = 0;
        switch (rotation) {
            case Surface.ROTATION_0:
                degrees = 0;
                break;
            case Surface.ROTATION_90:
                degrees = 90;
                break;
            case Surface.ROTATION_180:
                degrees = 180;
                break;
            case Surface.ROTATION_270:
                degrees = 270;
                break;
            default:
                break;
        }
        if (MyDebug.LOG)
            Log.d(TAG, "    degrees = " + degrees);
        return degrees;
    }

//    public int getDisplayRotationDegrees() {
//        int displayRotation = getDisplayRotation();
//        int i = 0;
//        if (displayRotation != 0) {
//            if (displayRotation == 1) {
//                i = 90;
//            } else if (displayRotation == 2) {
//                i = BarcodeUtils.ROTATION_180;
//            } else if (displayRotation == 3) {
//                i = BarcodeUtils.ROTATION_270;
//            }
//        }
//        Log.d(TAG, "    degrees = " + i);
//        return i;
//    }

    public void setCameraDisplayOrientation() {
        Log.d(TAG, "setCameraDisplayOrientation()");
        if (this.camera_controller == null) {
            Log.d(TAG, "camera not opened!");
        } else if (this.using_android_l) {
            configureTransform();
        } else {
            int displayRotationDegrees = getDisplayRotationDegrees();
            Log.d(TAG, "    degrees = " + displayRotationDegrees);
            this.camera_controller.setDisplayOrientation(displayRotationDegrees);
        }
    }


    public void onOrientationChanged(int i) {
        CameraController cameraController;
        int i2;
        if (i == -1 || (cameraController = this.camera_controller) == null) {
            return;
        }
        int i3 = ((i + 45) / 90) * 90;
        this.current_orientation = i3 % 360;
        int cameraOrientation = cameraController.getCameraOrientation();
        if (this.camera_controller.getFacing() == CameraController.Facing.FACING_FRONT) {
            i2 = ((cameraOrientation - i3) + 360) % 360;
        } else {
            i2 = (i3 + cameraOrientation) % 360;
        }
        if (i2 != this.current_rotation) {
            Log.d(TAG, "    current_orientation is " + this.current_orientation);
            Log.d(TAG, "    info orientation is " + cameraOrientation);
            Log.d(TAG, "    set Camera rotation from " + this.current_rotation + " to " + i2);
            this.current_rotation = i2;
        }
    }

    private int getDeviceDefaultOrientation() {
        Configuration configuration = getResources().getConfiguration();
        int rotation = ((WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRotation();
        return (((rotation == 0 || rotation == 2) && configuration.orientation == 2) || ((rotation == 1 || rotation == 3) && configuration.orientation == 1)) ? 2 : 1;
    }

    private int getImageVideoRotation() {
        Log.d(TAG, "getImageVideoRotation() from current_rotation " + this.current_rotation);
        String lockOrientationPref = this.applicationInterface.getLockOrientationPref();
        if (lockOrientationPref.equals("landscape")) {
            int cameraOrientation = this.camera_controller.getCameraOrientation();
            if (getDeviceDefaultOrientation() == 1) {
                if (this.camera_controller.getFacing() == CameraController.Facing.FACING_FRONT) {
                    cameraOrientation = (cameraOrientation + 90) % 360;
                } else {
                    cameraOrientation = (cameraOrientation + BarcodeUtils.ROTATION_270) % 360;
                }
            }
            Log.d(TAG, "getImageVideoRotation() lock to landscape, returns " + cameraOrientation);
            return cameraOrientation;
        } else if (lockOrientationPref.equals("portrait")) {
            int cameraOrientation2 = this.camera_controller.getCameraOrientation();
            if (getDeviceDefaultOrientation() != 1) {
                if (this.camera_controller.getFacing() == CameraController.Facing.FACING_FRONT) {
                    cameraOrientation2 = (cameraOrientation2 + BarcodeUtils.ROTATION_270) % 360;
                } else {
                    cameraOrientation2 = (cameraOrientation2 + 90) % 360;
                }
            }
            Log.d(TAG, "getImageVideoRotation() lock to portrait, returns " + cameraOrientation2);
            return cameraOrientation2;
        } else {
            Log.d(TAG, "getImageVideoRotation() returns current_rotation " + this.current_rotation);
            return this.current_rotation;
        }
    }

    public void draw(Canvas canvas) {
        if (this.is_paused) {
            return;
        }
        if (this.focus_success != 3 && this.focus_complete_time != -1 && System.currentTimeMillis()>this.focus_complete_time + min_safe_restart_video_time) {
            this.focus_success = 3;
        }
        this.applicationInterface.onDrawPreview(canvas);
    }

    public int getScaledZoomFactor(float scale_factor) {
        if (MyDebug.LOG) Log.d(TAG, "scaleZoom() " + scale_factor);
        if (this.camera_controller != null && this.has_zoom) {
            int zoom_factor = camera_controller.getZoom();
            float zoom_ratio = this.zoom_ratios.get(zoom_factor) / 100.0f;
            zoom_ratio *= scale_factor;

            int new_zoom_factor = zoom_factor;
            if (zoom_ratio<=1.0f) {
                new_zoom_factor = 0;
            } else if (zoom_ratio>=zoom_ratios.get(max_zoom_factor) / 100.0f) {
                new_zoom_factor = max_zoom_factor;
            } else {
                // find the closest zoom level
                if (scale_factor>1.0f) {
                    // zooming in
                    for (int i = zoom_factor; i<zoom_ratios.size(); i++) {
                        if (zoom_ratios.get(i) / 100.0f>=zoom_ratio) {
                            if (MyDebug.LOG)
                                Log.d(TAG, "zoom int, found new zoom by comparing " + zoom_ratios.get(i) / 100.0f + " >= " + zoom_ratio);
                            new_zoom_factor = i;
                            break;
                        }
                    }
                } else {
                    // zooming out
                    for (int i = zoom_factor; i>=0; i--) {
                        if (zoom_ratios.get(i) / 100.0f<=zoom_ratio) {
                            if (MyDebug.LOG)
                                Log.d(TAG, "zoom out, found new zoom by comparing " + zoom_ratios.get(i) / 100.0f + " <= " + zoom_ratio);
                            new_zoom_factor = i;
                            break;
                        }
                    }
                }
            }
            if (MyDebug.LOG) {
                Log.d(TAG, "ScaleListener.onScale zoom_ratio is now " + zoom_ratio);
                Log.d(TAG, "    old zoom_factor " + zoom_factor + " ratio " + zoom_ratios.get(zoom_factor) / 100.0f);
                Log.d(TAG, "    chosen new zoom_factor " + new_zoom_factor + " ratio " + zoom_ratios.get(new_zoom_factor) / 100.0f);
            }
            // n.b., don't call zoomTo; this should be called indirectly by applicationInterface.multitouchZoom()
            applicationInterface.multitouchZoom(new_zoom_factor);
            return new_zoom_factor;
        }
        return 0;
    }

    public void scaleZoom(float f) {
        Log.d(TAG, "scaleZoom() " + f);
        if (this.camera_controller == null || !this.has_zoom) {
            return;
        }
        this.applicationInterface.multitouchZoom(getScaledZoomFactor(f));
    }

    public void zoomTo(int i) {
        Log.d(TAG, "ZoomTo(): " + i);
        if (i<0) {
            i = 0;
        } else {
            int i2 = this.max_zoom_factor;
            if (i>i2) {
                i = i2;
            }
        }
        CameraController cameraController = this.camera_controller;
        if (cameraController == null || !this.has_zoom) {
            return;
        }
        cameraController.setZoom(i);
        this.applicationInterface.setZoomPref(i);
        clearFocusAreas();
    }


    public void setFocusDistance(float f, boolean z) {
        String string;
        Log.d(TAG, "setFocusDistance: " + f);
        Log.d(TAG, "is_target_distance: " + z);
        CameraController cameraController = this.camera_controller;
        if (cameraController == null) {
            return;
        }
        if (f<0.0f) {
            f = 0.0f;
        } else {
            float f2 = this.minimum_focus_distance;
            if (f>f2) {
                f = f2;
            }
        }
        boolean z2 = false;
        if (z) {
            cameraController.setFocusBracketingTargetDistance(f);
            this.camera_controller.setFocusDistance(f);
        } else {
            if (cameraController.setFocusDistance(f)) {
                this.camera_controller.setFocusBracketingSourceDistance(f);
            }
            if (z2) {
                return;
            }
            this.applicationInterface.setFocusDistancePref(f, z);
            if (f>0.0f) {
                float f3 = 1.0f / f;
                string = this.decimal_format_2dp_force0.format(f3) + getResources().getString(R.string.metres_abbreviation);
            } else {
                string = getResources().getString(R.string.infinite);
            }
            int i = R.string.focus_distance;
            if (this.supports_focus_bracketing && this.applicationInterface.isFocusBracketingPref()) {
                i = z ? R.string.focus_bracketing_target_distance : R.string.focus_bracketing_source_distance;
            }
            showToast(getResources().getString(i) + " " + string, true);
            return;
        }
        z2 = true;
        if (z2) {
        }
    }

    public void stoppedSettingFocusDistance(boolean z) {
        Log.d(TAG, "stoppedSettingFocusDistance");
        Log.d(TAG, "is_target_distance: " + z);
        if (!z || this.camera_controller == null) {
            return;
        }
        Log.d(TAG, "set manual focus distance back to start");
        CameraController cameraController = this.camera_controller;
        cameraController.setFocusDistance(cameraController.getFocusBracketingSourceDistance());
    }
//
//    public void setExposure(int i) {
//        Log.d(TAG, "setExposure(): " + i);
//        if (this.camera_controller != null) {
//            if (this.min_exposure == 0 && this.max_exposure == 0) {
//                return;
//            }
//            cancelAutoFocus();
//            int i2 = this.min_exposure;
//            if (i<i2 || i>(i2 = this.max_exposure)) {
//                i = i2;
//            }
//            if (this.camera_controller.setExposureCompensation(i)) {
//                this.applicationInterface.setExposureCompensationPref(i);
//                showToast(getExposureCompensationString(i), 0, true);
//            }
//        }
//    }


    public void setExposure(int i) {
        Log.d(TAG, "setExposure(): " + i);
        if (this.camera_controller == null) {
            return;
        }
        if (this.min_exposure != 0 || this.max_exposure != 0) {
            cancelAutoFocus();
            int i2 = this.min_exposure;
            if (i < i2 || i > (i2 = this.max_exposure)) {
                i = i2;
            }
            if (this.camera_controller.setExposureCompensation(i)) {
                this.applicationInterface.setExposureCompensationPref(i);
                showToast(getExposureCompensationString(i), 0, true);
            }
        }
    }


    public void setWhiteBalanceTemperature(int i) {
        Log.d(TAG, "seWhiteBalanceTemperature(): " + i);
        CameraController cameraController = this.camera_controller;
        if (cameraController == null || !cameraController.setWhiteBalanceTemperature(i)) {
            return;
        }
        this.applicationInterface.setWhiteBalanceTemperaturePref(i);
        showToast(getResources().getString(R.string.white_balance) + " " + i, 0, true);
    }

    public int parseManualISOValue(String str) {
        try {
            Log.d(TAG, "setting manual iso");
            int parseInt = Integer.parseInt(str);
            Log.d(TAG, "iso: " + parseInt);
            return parseInt;
        } catch (NumberFormatException unused) {
            return -1;
        }
    }

    public void setISO(int i) {
        CameraController cameraController = this.camera_controller;
        if (cameraController == null || !this.supports_iso_range) {
            return;
        }
        int i2 = this.min_iso;
        if (i<i2 || i>(i2 = this.max_iso)) {
            i = i2;
        }
        if (cameraController.setISO(i)) {
            ApplicationInterface applicationInterface = this.applicationInterface;
            applicationInterface.setISOPref("" + i);
            showToast(getISOString(i), 0, true);
        }
    }

    public void setExposureTime(long j) {
        Log.d(TAG, "setExposureTime(): " + j);
        if (this.camera_controller == null || !this.supports_exposure_time) {
            return;
        }
        if (j<getMinimumExposureTime()) {
            j = getMinimumExposureTime();
        } else if (j>getMaximumExposureTime()) {
            j = getMaximumExposureTime();
        }
        if (this.camera_controller.setExposureTime(j)) {
            this.applicationInterface.setExposureTimePref(j);
            showToast(getExposureTimeString(j), 0, true);
        }
    }

    public String getExposureCompensationString(int i) {
        float f = i * this.exposure_step;
        StringBuilder sb = new StringBuilder();
        sb.append(getResources().getString(R.string.exposure_compensation));
        sb.append(" ");
        sb.append(i>=0 ? "+" : "");
        sb.append(this.decimal_format_2dp_force0.format(f));
        sb.append(" EV");
        return sb.toString();
    }

    public String getISOString(int i) {
        return getResources().getString(R.string.iso) + " " + i;
    }

    public String getExposureTimeString(long j) {
        double d = j / 1.0E9d;
        if (j>100000000) {
            return this.decimal_format_1dp.format(d) + getResources().getString(R.string.seconds_abbreviation);
        }
        double d2 = 1.0d / d;
        return " 1/" + ((int) (d2 + 0.5d)) + getResources().getString(R.string.seconds_abbreviation);
    }

    public String getFrameDurationString(long j) {
        double d = 1.0d / (j / 1.0E9d);
        return getResources().getString(R.string.fps) + " " + this.decimal_format_1dp.format(d);
    }

    public boolean canSwitchCamera() {
        if (this.phase == 2 || isVideoRecording()) {
            Log.d(TAG, "currently taking a photo");
            return false;
        }
        int numberOfCameras = this.camera_controller_manager.getNumberOfCameras();
        Log.d(TAG, "found " + numberOfCameras + " cameras");
        return numberOfCameras != 0;
    }

    public void setCamera(int i) {
        Log.d(TAG, "setCamera(): " + i);
        if (i<0 || i>=this.camera_controller_manager.getNumberOfCameras()) {
            Log.d(TAG, "invalid cameraId: " + i);
            i = 0;
        }
        if (this.camera_open_state == CameraOpenState.CAMERAOPENSTATE_OPENING) {
            Log.d(TAG, "already opening camera in background thread");
        } else if (canSwitchCamera()) {
            int finalI = i;
            closeCamera(true, new CloseCameraCallback() {
                @Override
                public void onClosed() {
                    Log.d(Preview.TAG, "CloseCameraCallback.onClosed");
                    Preview.this.applicationInterface.setCameraIdPref(finalI);
                    Preview.this.openCamera();
                }
            });
        }
    }

    public static int[] matchPreviewFpsToVideo(List<int[]> list, int i) {
        String str;
        char c;
        char c2;
        Log.d(TAG, "matchPreviewFpsToVideo()");
        Iterator<int[]> it = list.iterator();
        int i2 = -1;
        int i3 = -1;
        int i4 = -1;
        while (true) {
            boolean hasNext = it.hasNext();
            str = "";
            c = 1;
            c2 = 0;
            if (!hasNext) {
                break;
            }
            int[] next = it.next();
            Log.d(TAG, str + next[0] + " to " + next[1]);
            int i5 = next[0];
            int i6 = next[1];
            if (i5<=i && i6>=i) {
                int i7 = i6 - i5;
                if (i4 == -1 || i7<i4) {
                    i3 = i6;
                    i2 = i5;
                    i4 = i7;
                }
            }
        }
        if (i2 != -1) {
            Log.d(TAG, "    chosen fps range: " + i2 + " to " + i3);
        } else {
            int i8 = -1;
            int i9 = -1;
            for (int[] iArr : list) {
                int i10 = iArr[c2];
                int i11 = iArr[c];
                int i12 = i11 - i10;
                int i13 = i11<i ? i - i11 : i10 - i;
                Log.d(TAG, str + i10 + " to " + i11 + " " + i13 + " and diff " + i12);
                if (i8 == -1 || i13<i8 || (i13 == i8 && i12<i9)) {
                    i3 = i11;
                    i2 = i10;
                    i9 = i12;
                    i8 = i13;
                }
                c = 1;
                c2 = 0;
            }
            Log.e(TAG, "    can't find match for fps range, so choose closest: " + i2 + " to " + i3);
        }
        return new int[]{i2, i3};
    }

    public static int[] chooseBestPreviewFps(List<int[]> list) {
        Log.d(TAG, "chooseBestPreviewFps()");
        int i = -1;
        int i2 = -1;
        for (int[] iArr : list) {
            Log.d(TAG, "    supported fps range: " + iArr[0] + " to " + iArr[1]);
            int i3 = iArr[0];
            int i4 = iArr[1];
            if (i4>=30000 && (i == -1 || i3<i || (i3 == i && i4>i2))) {
                i2 = i4;
                i = i3;
            }
        }
        if (i != -1) {
            Log.d(TAG, "    chosen fps range: " + i + " to " + i2);
        } else {
            int i5 = -1;
            for (int[] iArr2 : list) {
                int i6 = iArr2[0];
                int i7 = iArr2[1];
                int i8 = i7 - i6;
                if (i5 == -1 || i8>i5 || (i8 == i5 && i7>i2)) {
                    i2 = i7;
                    i = i6;
                    i5 = i8;
                }
            }
            Log.d(TAG, "    can't find fps range 30fps or better, so picked widest range: " + i + " to " + i2);
        }
        return new int[]{i, i2};
    }

    private void setPreviewFps() {
        int[] matchPreviewFpsToVideo;
        Log.d(TAG, "setPreviewFps()");
        VideoProfile videoProfile = getVideoProfile();
        List<int[]> supportedPreviewFpsRange = this.camera_controller.getSupportedPreviewFpsRange();
        if (supportedPreviewFpsRange == null || supportedPreviewFpsRange.size() == 0) {
            Log.d(TAG, "fps_ranges not available");
            return;
        }
        int[] iArr = null;
        if (this.is_video) {
            boolean z = this.using_android_l || Build.MODEL.equals("Nexus 5") || Build.MODEL.equals("Nexus 6");
            String videoFPSPref = this.applicationInterface.getVideoFPSPref();
            Log.d(TAG, "preview_too_dark? " + z);
            Log.d(TAG, "fps_value: " + videoFPSPref);
            if (videoFPSPref.equals("default") && this.using_android_l) {
                Log.d(TAG, "don't set preview fps for camera2 and default fps video");
            } else {
                if (videoFPSPref.equals("default") && z) {
                    matchPreviewFpsToVideo = chooseBestPreviewFps(supportedPreviewFpsRange);
                } else {
                    matchPreviewFpsToVideo = matchPreviewFpsToVideo(supportedPreviewFpsRange, (int) (videoProfile.videoCaptureRate * 1000.0d));
                }
                iArr = matchPreviewFpsToVideo;
            }
        } else if (this.using_android_l) {
            Log.d(TAG, "don't set preview fps for camera2 and photo");
        } else {
            iArr = chooseBestPreviewFps(supportedPreviewFpsRange);
        }
        if (iArr != null) {
            Log.d(TAG, "set preview fps range: " + Arrays.toString(iArr));
            this.camera_controller.setPreviewFpsRange(iArr[0], iArr[1]);
        } else if (this.using_android_l) {
            this.camera_controller.clearPreviewFpsRange();
        }
    }

    public void switchVideo(boolean z, boolean z2) {
        Log.d(TAG, "switchVideo()");
        if (this.camera_controller == null) {
            Log.d(TAG, "camera not opened!");
            return;
        }
        boolean z3 = this.is_video;
        if (!z3 && !this.supports_video) {
            Log.d(TAG, "video not supported");
            return;
        }
        if (z3) {
            if (this.video_recorder != null) {
                stopVideo(false);
            }
            this.is_video = false;
        } else if (isOnTimer()) {
            cancelTimer();
            this.is_video = true;
        } else if (this.phase == 2) {
            Log.d(TAG, "wait until photo taken");
        } else {
            this.is_video = true;
        }
        if (this.is_video != z3) {
            setFocusPref(false);
            if (z2) {
                this.applicationInterface.setVideoPref(this.is_video);
            }
            if (!z) {
                updateFlashForVideo();
            }
            if (!z) {
                int i = this.current_focus_index;
                String str = i != -1 ? this.supported_focus_values.get(i) : null;
                Log.d(TAG, "focus_value is " + str);
                reopenCamera();
            }
            if (this.is_video && Build.VERSION.SDK_INT>=23 && this.applicationInterface.getRecordAudioPref()) {
                Log.d(TAG, "check for record audio permission");
                if (ContextCompat.checkSelfPermission(getContext(), "android.permission.RECORD_AUDIO") != 0) {
                    Log.d(TAG, "record audio permission not available");
                    this.applicationInterface.requestRecordAudioPermission();
                }
            }
        }
    }

    private boolean focusIsVideo() {
        CameraController cameraController = this.camera_controller;
        if (cameraController != null) {
            return cameraController.focusIsVideo();
        }
        return false;
    }

    private void setFocusPref(boolean z) {
        Log.d(TAG, "setFocusPref()");
        String focusPref = this.applicationInterface.getFocusPref(this.is_video);
        Log.e(":::focus:::", "setFocusPref: " + focusPref);
        if (focusPref.length()>0) {
            Log.d(TAG, "found existing focus_value: " + focusPref);
            if (updateFocus(focusPref, true, false, z)) {
                return;
            }
            updateFocus(0, true, true, z);
            return;
        }
        Log.d(TAG, "found no existing focus_value");
        updateFocus(this.is_video ? "focus_mode_continuous_video" : "focus_mode_auto", true, true, z);
    }

    private String updateFocusForVideo() {
        Log.d(TAG, "updateFocusForVideo()");
        if (this.supported_focus_values != null && this.camera_controller != null && this.is_video) {
            boolean focusIsVideo = focusIsVideo();
            Log.d(TAG, "focus_is_video: " + focusIsVideo + " , is_video: " + this.is_video);
            if (focusIsVideo != this.is_video) {
                Log.d(TAG, "need to change focus mode");
                String currentFocusValue = getCurrentFocusValue();
                updateFocus("focus_mode_continuous_video", true, false, false);
                return currentFocusValue;
            }
        }
        return null;
    }

    private void updateFlashForVideo() {
        String currentFlashValue;
        Log.d(TAG, "updateFlashForVideo()");
        if (!this.is_video || (currentFlashValue = getCurrentFlashValue()) == null || isFlashSupportedForVideo(currentFlashValue)) {
            return;
        }
        Log.d(TAG, "disable flash for video mode");
        this.current_flash_index = -1;
        updateFlash("flash_off", false);
    }

    public static boolean isFlashSupportedForVideo(String str) {
        return str != null && (str.equals("flash_off") || str.equals("flash_torch") || str.equals("flash_frontscreen_torch"));
    }

    public String getErrorFeatures(VideoProfile videoProfile) {
        String str;
        boolean z = true;
        boolean r1 = true;
        boolean z2 = videoProfile.videoFrameWidth == 3840 && videoProfile.videoFrameHeight == 2160 && this.applicationInterface.getForce4KPref();
        boolean z3 = !this.applicationInterface.getVideoBitratePref().equals("default");
        String videoFPSPref = this.applicationInterface.getVideoFPSPref();
        if (this.applicationInterface.getVideoCaptureRateFactor()>=0.99999f) {
            r1 = videoFPSPref.equals("default") ? false : true;
            z = false;
        }
        if (z2 || z3 || r1 || z) {
            String string = z2 ? getContext().getResources().getString(R.string.error_features_4k) : "";
            if (z3) {
                if (string.length() == 0) {
                    string = getContext().getResources().getString(R.string.error_features_bitrate);
                } else {
                    string = string + "/" + getContext().getResources().getString(R.string.error_features_bitrate);
                }
            }
            if (r1) {
                if (string.length() == 0) {
                    str = getContext().getResources().getString(R.string.error_features_frame_rate);
                } else {
                    str = string + "/" + getContext().getResources().getString(R.string.error_features_frame_rate);
                }
                string = str;
            }
            if (z) {
                if (string.length() == 0) {
                    return getContext().getResources().getString(R.string.error_features_slow_motion);
                }
                return string + "/" + getContext().getResources().getString(R.string.error_features_slow_motion);
            }
            return string;
        }
        return "";
    }

    public void updateFlash(String str) {
        Log.d(TAG, "updateFlash(): " + str);
        if (this.phase == 2 && !this.is_video) {
            Log.d(TAG, "currently taking a photo");
        } else {
            updateFlash(str, true);
        }
    }

    public boolean updateFlash(String str, boolean z) {
        Log.d(TAG, "updateFlash(): " + str);
        List<String> list = this.supported_flash_values;
        if (list != null) {
            int indexOf = list.indexOf(str);
            Log.d(TAG, "new_flash_index: " + indexOf);
            if (indexOf != -1) {
                setFlash(str);
                if (z) {
                    this.applicationInterface.setFlashPref(str);
                    this.applicationInterface.setFlashPref_Pos(indexOf);
                    return true;
                }
                return true;
            }
            return false;
        }
        return false;
    }

    public void setWhiteBalance(String str) {
        this.applicationInterface.setWhiteBalancePref(str);
        onResume();
    }

    public void setSceneModes(String str) {
        this.applicationInterface.setSceneModePref(str);
        onResume();
    }

    public ArrayList<String> getSceneModes() {
        return (ArrayList) this.scene_modes;
    }

    public ArrayList<String> getWhiteBalance() {
        return (ArrayList) this.white_balances;
    }

    public void setColorEffects(String str) {
        this.applicationInterface.setColorEffectPref(str);
    }

    public void cycleFlash(boolean z, boolean z2) {
        Log.d(TAG, "cycleFlash()");
        Log.e(":::flash_icon:::", "current_flash_index: " + this.current_flash_index);
        this.current_flash_index = this.applicationInterface.getFlashPref_Pos();
        Log.e(":::flash_icon_111:::", "supported_flash_values: " + this.current_flash_index);
        int i = this.current_flash_index + 1;
        this.current_flash_index = i;
        List<String> list = this.supported_flash_values;
        if (list != null) {
            if (i == list.size()) {
                this.current_flash_index = 0;
            } else if (this.supported_flash_values.get(this.current_flash_index).equals("flash_red_eye")) {
                this.current_flash_index = 0;
            }
            Log.e(":::flash_icon:::", "supported_flash_values: " + this.current_flash_index);
            int i2 = this.current_flash_index;
            if (i2<0 || i2>=this.supported_flash_values.size()) {
                return;
            }
            updateFlash(this.supported_flash_values.get(this.current_flash_index), true);
            this.mSP.setInteger(getContext(), PreferenceKeys.FLASH_POS, this.current_flash_index);
        }
    }

    private void updateFlash(int i, boolean z) {
        int i2;
        Log.d(TAG, "updateFlash(): " + i);
        if (this.supported_flash_values == null || i == (i2 = this.current_flash_index)) {
            return;
        }
        boolean z2 = i2 == 0;
        this.current_flash_index = i;
        Log.d(TAG, "    current_flash_index is now " + this.current_flash_index + " (initial " + z2 + ")");
        String[] stringArray = getResources().getStringArray(R.array.flash_entries);
        String str = this.supported_flash_values.get(this.current_flash_index);
        StringBuilder sb = new StringBuilder();
        sb.append("    flash_value: ");
        sb.append(str);
        Log.d(TAG, sb.toString());
        String[] stringArray2 = getResources().getStringArray(R.array.flash_values);
        for (int i3 = 0; i3<stringArray2.length; i3++) {
            if (str.equals(stringArray2[i3])) {
                Log.d(TAG, "    found entry: " + i3);
                if (z2) {
                    return;
                }
                showToast(this.flash_toast, stringArray[i3]);
                return;
            }
        }
    }

    private void setFlash(String str) {
        Log.d(TAG, "setFlash() " + str);
        this.set_flash_value_after_autofocus = str;
        if (this.camera_controller == null) {
            Log.d(TAG, "camera not opened!");
            return;
        }
        cancelAutoFocus();
        this.camera_controller.setFlashValue(str);
    }

    public String getCurrentFlashValue() {
        List<String> list;
        int i = this.current_flash_index;
        if (i == -1 || (list = this.supported_flash_values) == null) {
            return null;
        }
        return list.get(i);
    }

    public void updateFocus(String str, boolean z, boolean z2) {
        Log.d(TAG, "updateFocus(): " + str);
        if (this.phase == 2) {
            Log.d(TAG, "currently taking a photo");
        } else {
            updateFocus(str, z, true, z2);
        }
    }

    private boolean supportedFocusValue(String str) {
        Log.d(TAG, "supportedFocusValue(): " + str);
        List<String> list = this.supported_focus_values;
        if (list != null) {
            int indexOf = list.indexOf(str);
            Log.d(TAG, "new_focus_index: " + indexOf);
            return indexOf != -1;
        }
        return false;
    }

    private boolean updateFocus(String str, boolean z, boolean z2, boolean z3) {
        Log.d(TAG, "updateFocus(): " + str);
        List<String> list = this.supported_focus_values;
        if (list != null) {
            int indexOf = list.indexOf(str);
            Log.d(TAG, "new_focus_index: " + indexOf);
            if (indexOf != -1) {
                updateFocus(indexOf, z, z2, z3);
                return true;
            }
            return false;
        }
        return false;
    }

    private String findEntryForValue(String str, int i, int i2) {
        String[] stringArray = getResources().getStringArray(i);
        String[] stringArray2 = getResources().getStringArray(i2);
        for (int i3 = 0; i3<stringArray2.length; i3++) {
            Log.d(TAG, "    compare to value: " + stringArray2[i3]);
            if (str.equals(stringArray2[i3])) {
                Log.d(TAG, "    found entry: " + i3);
                return stringArray[i3];
            }
        }
        return null;
    }

    public String findFocusEntryForValue(String str) {
        return findEntryForValue(str, R.array.focus_mode_entries, R.array.focus_mode_values);
    }

    private void updateFocus(int i, boolean z, boolean z2, boolean z3) {
        Log.d(TAG, "updateFocus(): " + i + " current_focus_index: " + this.current_focus_index);
        if (this.supported_focus_values == null || i == this.current_focus_index) {
            return;
        }
        this.current_focus_index = i;
        Log.d(TAG, "    current_focus_index is now " + this.current_focus_index);
        String str = this.supported_focus_values.get(this.current_focus_index);
        Log.d(TAG, "    focus_value: " + str);
        if (!z) {
            findFocusEntryForValue(str);
        }
        setFocusValue(str, z3);
        if (z2) {
            this.applicationInterface.setFocusPref(str, this.is_video);
        }
    }

    public String getCurrentFocusValue() {
        int i;
        Log.d(TAG, "getCurrentFocusValue()");
        if (this.camera_controller == null) {
            Log.d(TAG, "camera not opened!");
            return null;
        }
        List<String> list = this.supported_focus_values;
        if (list == null || (i = this.current_focus_index) == -1) {
            return null;
        }
        return list.get(i);
    }

    private void setFocusValue(String str, boolean z) {
        Log.d(TAG, "setFocusValue() " + str);
        if (this.camera_controller == null) {
            Log.d(TAG, "camera not opened!");
            return;
        }
        cancelAutoFocus();
        removePendingContinuousFocusReset();
        this.autofocus_in_continuous_mode = false;
        this.camera_controller.setFocusValue(str);
        setupContinuousFocusMove();
        clearFocusAreas();
        if (!z || str.equals("focus_mode_locked")) {
            return;
        }
        tryAutoFocus(false, false);
    }

    private void setupContinuousFocusMove() {
        Log.d(TAG, "setupContinuousFocusMove()");
        if (this.continuous_focus_move_is_started) {
            this.continuous_focus_move_is_started = false;
            this.applicationInterface.onContinuousFocusMove(false);
        }
        int i = this.current_focus_index;
        String str = i != -1 ? this.supported_focus_values.get(i) : null;
        Log.d(TAG, "focus_value is " + str);
        if (this.camera_controller != null && str != null && str.equals("focus_mode_continuous_picture") && !this.is_video) {
            Log.d(TAG, "set continuous picture focus move callback");
            this.camera_controller.setContinuousFocusMoveCallback(new CameraController.ContinuousFocusMoveCallback() {
                @Override
                public void onContinuousFocusMove(boolean z) {
                    if (z != Preview.this.continuous_focus_move_is_started) {
                        Preview.this.continuous_focus_move_is_started = z;
                        Preview.this.count_cameraContinuousFocusMoving++;
                        Preview.this.applicationInterface.onContinuousFocusMove(z);
                    }
                }
            });
        } else if (this.camera_controller != null) {
            Log.d(TAG, "remove continuous picture focus move callback");
            this.camera_controller.setContinuousFocusMoveCallback(null);
        }
    }

    public void toggleWhiteBalanceLock() {
        Log.d(TAG, "toggleWhiteBalanceLock()");
        if (this.phase == 2) {
            Log.d(TAG, "currently taking a photo");
        } else if (this.camera_controller == null) {
            Log.d(TAG, "camera not opened!");
        } else if (this.is_white_balance_lock_supported) {
            this.is_white_balance_locked = !this.is_white_balance_locked;
            cancelAutoFocus();
            this.camera_controller.setAutoWhiteBalanceLock(this.is_white_balance_locked);
        }
    }

    public void toggleExposureLock() {
        Log.d(TAG, "toggleExposureLock()");
        if (this.phase == 2) {
            Log.d(TAG, "currently taking a photo");
        } else if (this.camera_controller == null) {
            Log.d(TAG, "camera not opened!");
        } else if (this.is_exposure_lock_supported) {
            this.is_exposure_locked = !this.is_exposure_locked;
            cancelAutoFocus();
            this.camera_controller.setAutoExposureLock(this.is_exposure_locked);
        }
    }

//    public void takePicturePressed(boolean photo_snapshot) {
//        if (MyDebug.LOG) Log.d(TAG, "takePicturePressed");
//        if (camera_controller == null) {
//            if (MyDebug.LOG) Log.d(TAG, "camera not opened!");
//            this.phase = PHASE_NORMAL;
//            return;
//        }
//        if (!this.has_surface) {
//            if (MyDebug.LOG) Log.d(TAG, "preview surface not yet available");
//            this.phase = PHASE_NORMAL;
//            return;
//        }
//        if (this.isOnTimer()) {
//            cancelTimer();
//            showToast(take_photo_toast, R.string.cancelled_timer);
//            return;
//        }
//        //if( !photo_snapshot && this.phase == PHASE_TAKING_PHOTO ) {
//        //if( (is_video && is_video_recording && !photo_snapshot) || this.phase == PHASE_TAKING_PHOTO ) {
//        if (is_video && isVideoRecording() && !photo_snapshot) {
//            // user requested stop video
//            if (!video_start_time_set || System.currentTimeMillis() - video_start_time<500) {
//                // if user presses to stop too quickly, we ignore
//                // firstly to reduce risk of corrupt video files when stopping too quickly (see RuntimeException we have to catch in stopVideo),
//                // secondly, to reduce a backlog of events which slows things down, if user presses start/stop repeatedly too quickly
//                if (MyDebug.LOG) Log.d(TAG, "ignore pressing stop video too quickly after start");
//            } else {
//                stopVideo(false);
//            }
//            return;
//        } else if ((!is_video || photo_snapshot) && this.phase == PHASE_TAKING_PHOTO) {
//            // user requested take photo while already taking photo
//            if (MyDebug.LOG) Log.d(TAG, "already taking a photo");
//            if (remaining_repeat_photos != 0) {
//                cancelRepeat();
//                showToast(take_photo_toast, R.string.cancelled_repeat_mode);
//            }
//            return;
//        }
//
//        if (!is_video || photo_snapshot) {
//            // check it's okay to take a photo
//            if (!applicationInterface.canTakeNewPhoto()) {
//                if (MyDebug.LOG) Log.d(TAG, "don't take another photo, queue is full");
//                //showToast(take_photo_toast, "Still processing...");
//                return;
//            }
//        }
//
//        // make sure that preview running (also needed to hide trash/share icons)
//        this.startCameraPreview();
//
//        if (photo_snapshot) {
//            // go straight to taking a photo, ignore timer or repeat options
//            takePicture(false, photo_snapshot);
//            return;
//        }
//
//        long timer_delay = VoiceInterface.timerDelay == 0 ? applicationInterface.getTimerPref() : VoiceInterface.timerDelay;
//
//        String repeat_mode_value = applicationInterface.getRepeatPref();
//        if (repeat_mode_value.equals("unlimited")) {
//            if (MyDebug.LOG) Log.d(TAG, "unlimited repeat");
//            remaining_repeat_photos = -1;
//        } else {
//            int n_repeat;
//            try {
//                n_repeat = Integer.parseInt(repeat_mode_value);
//                if (MyDebug.LOG) Log.d(TAG, "n_repeat: " + n_repeat);
//            } catch (NumberFormatException e) {
//                if (MyDebug.LOG)
//                    Log.e(TAG, "failed to parse repeat_mode value: " + repeat_mode_value);
//                e.printStackTrace();
//                n_repeat = 1;
//            }
//            remaining_repeat_photos = n_repeat - 1;
//        }
//
//        if (timer_delay == 0) {
//            takePicture(false, photo_snapshot);
//        } else {
//            takePictureOnTimer(timer_delay, false);
//        }
//        if (MyDebug.LOG) Log.d(TAG, "takePicturePressed exit");
//    }

    public void takePicturePressed(boolean z, boolean z2) {
        int i;
        Log.d(TAG, "takePicturePressed");
        if (this.camera_controller == null) {
            Log.d(TAG, "camera not opened!");
            this.phase = 0;
        } else if (!this.has_surface) {
            Log.d(TAG, "preview surface not yet available");
            this.phase = 0;
        } else if (this.is_video && z2) {
            Log.e(TAG, "continuous_fast_burst not supported for video mode");
            this.phase = 0;
        } else if (isOnTimer()) {
            cancelTimer();
            showToast(this.take_photo_toast, R.string.cancelled_timer);
            CameraMainActivity.window.clearFlags(16);
        } else if (this.is_video && isVideoRecording() && !z) {
            if (!this.video_start_time_set || System.currentTimeMillis() - this.video_start_time<500) {
                Log.d(TAG, "ignore pressing stop video too quickly after start");
            } else {
                stopVideo(false);
            }
        } else if ((!this.is_video || z) && this.phase == 2) {
            Log.d(TAG, "already taking a photo");
            if (this.remaining_repeat_photos != 0) {
                cancelRepeat();
                showToast(this.take_photo_toast, R.string.cancelled_repeat_mode);
            } else if (!this.is_video && this.camera_controller.getBurstType() == CameraController.BurstType.BURSTTYPE_FOCUS && this.camera_controller.isCapturingBurst()) {
                this.camera_controller.stopFocusBracketingBurst();
                showToast(this.take_photo_toast, R.string.cancelled_focus_bracketing);
            }
        } else if ((!this.is_video || z) && !this.applicationInterface.canTakeNewPhoto()) {
            Log.d(TAG, "don't take another photo, queue is full");
        } else {
            startCameraPreview();
            if (z || z2) {
                takePicture(false, z, z2);
                return;
            }
            long timerPref = this.applicationInterface.getTimerPref();
            String repeatPref = this.applicationInterface.getRepeatPref();
            if (repeatPref.equals("unlimited")) {
                Log.d(TAG, "unlimited repeat");
                this.remaining_repeat_photos = -1;
            } else {
                try {
                    i = Integer.parseInt(repeatPref);
                    Log.d(TAG, "n_repeat: " + i);
                } catch (NumberFormatException e) {
                    Log.e(TAG, "failed to parse repeat_mode value: " + repeatPref);
                    e.printStackTrace();
                    i = 1;
                }
                this.remaining_repeat_photos = i - 1;
            }
            if (timerPref == 0) {
                takePicture(false, z, z2);
            } else {
                takePictureOnTimer(timerPref, false);
            }
            Log.d(TAG, "takePicturePressed exit");
        }
    }

    private void takePictureOnTimer(long j, boolean z) {
        CameraMainActivity.window.setFlags(16, 16);
        Log.d(TAG, "takePictureOnTimer");
        Log.d(TAG, "timer_delay: " + j);
        this.phase = 1;
        this.take_photo_time = System.currentTimeMillis() + j;
        Log.d(TAG, "take photo at: " + this.take_photo_time);
        Timer timer = this.takePictureTimer;
        TimerTask timerTask = new TimerTask() { // from class: com.live.gpsmap.camera.Camera.preview.Preview.1TakePictureTimerTask
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                if (Preview.this.beepTimerTask != null) {
                    Preview.this.beepTimerTask.cancel();
                    Preview.this.beepTimerTask = null;
                }
                ((Activity) Preview.this.getContext()).runOnUiThread(new Runnable() { // from class: com.live.gpsmap.camera.Camera.preview.Preview.1TakePictureTimerTask.1
                    @Override // java.lang.Runnable
                    public void run() {
                        CameraMainActivity.window.clearFlags(16);
                        if (Preview.this.camera_controller != null && Preview.this.takePictureTimerTask != null) {
                            Preview.this.takePicture(false, false, false);
                        } else {
                            Log.d(Preview.TAG, "takePictureTimerTask: don't take picture, as already cancelled");
                        }
                    }
                });
            }
        };
        this.takePictureTimerTask = timerTask;
        timer.schedule(timerTask, j);
        Timer timer2 = this.beepTimer;
        TimerTask timerTask2 = new TimerTask() {
            private long remaining_time;
            final long val$timer_delay;

            {
                this.val$timer_delay = j;
                this.remaining_time = j;
            }

            @Override
            public void run() {
                if (this.remaining_time>0) {
                    Preview.this.applicationInterface.timerBeep(this.remaining_time);
                }
                this.remaining_time -= Preview.min_safe_restart_video_time;
            }
        };
        this.beepTimerTask = timerTask2;
        timer2.schedule(timerTask2, 0L, min_safe_restart_video_time);
    }


    public void flashVideo() {
        String currentFlashValue;
        Log.d(TAG, "flashVideo");
        String flashValue = this.camera_controller.getFlashValue();
        if (flashValue.length() == 0 || (currentFlashValue = getCurrentFlashValue()) == null || currentFlashValue.equals("flash_torch")) {
            return;
        }
        if (flashValue.equals("flash_torch")) {
            cancelAutoFocus();
            this.camera_controller.setFlashValue(currentFlashValue);
            return;
        }
        cancelAutoFocus();
        this.camera_controller.setFlashValue("flash_torch");
        try {
            Thread.sleep(100L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        cancelAutoFocus();
        this.camera_controller.setFlashValue(currentFlashValue);
    }


    public void onVideoInfo(int i, int i2) {
        VideoFileInfo createVideoFile;
        Log.d(TAG, "onVideoInfo: " + i + " extra: " + i2);
        boolean z = false;
        if (Build.VERSION.SDK_INT>=26 && i == 802 && this.video_restart_on_max_filesize) {
            Log.d(TAG, "seamless restart due to max filesize approaching - try setNextOutputFile");
            if (this.video_recorder == null) {
                Log.d(TAG, "video_recorder is null!");
            } else if (this.applicationInterface.getVideoMaxDurationPref()>0) {
                Log.d(TAG, "don't use setNextOutputFile with setMaxDuration");
            } else {
                try {
                    this.applicationInterface.getVideoMaxFileSizePref();
                    z = true;
                } catch (ApplicationInterface.NoFreeStorageException unused) {
                    Log.d(TAG, "don't call setNextOutputFile, not enough space remaining");
                }
                VideoProfile videoProfile = getVideoProfile();
                if (videoProfile.fileExtension.equals("3gp")) {
                    Log.d(TAG, "seamless restart not supported for 3gpp");
                } else if (z && (createVideoFile = createVideoFile(videoProfile.fileExtension)) != null) {
                    try {
                        if (createVideoFile.video_method == ApplicationInterface.VideoMethod.FILE) {
                            this.video_recorder.setNextOutputFile(new File(createVideoFile.video_filename));
                        } else {
                            this.video_recorder.setNextOutputFile(createVideoFile.video_pfd_saf.getFileDescriptor());
                        }
                        Log.d(TAG, "setNextOutputFile succeeded");
                        this.test_called_next_output_file = true;
                        this.nextVideoFileInfo = createVideoFile;
                    } catch (IOException e) {
                        Log.e(TAG, "failed to setNextOutputFile");
                        e.printStackTrace();
                        createVideoFile.close();
                    }
                }
            }
        } else if (Build.VERSION.SDK_INT>=26 && i == 803 && this.video_restart_on_max_filesize) {
            Log.d(TAG, "seamless restart with setNextOutputFile has now occurred");
            if (this.nextVideoFileInfo == null) {
                Log.e(TAG, "received MEDIA_RECORDER_INFO_NEXT_OUTPUT_FILE_STARTED but nextVideoFileInfo is null");
            } else {
                this.videoFileInfo.close();
                this.applicationInterface.restartedVideo(this.videoFileInfo.video_method, this.videoFileInfo.video_uri, this.videoFileInfo.video_filename);
                this.videoFileInfo = this.nextVideoFileInfo;
                this.nextVideoFileInfo = null;
                this.test_started_next_output_file = true;
            }
        } else if (i == 801 && this.video_restart_on_max_filesize) {
            Log.d(TAG, "restart due to max filesize reached - do manual restart");
            ((Activity) getContext()).runOnUiThread(new Runnable() { // from class: com.live.gpsmap.camera.Camera.preview.Preview.10
                @Override // java.lang.Runnable
                public void run() {
                    if (Preview.this.camera_controller != null) {
                        Preview.this.restartVideo(true);
                    } else {
                        Log.d(Preview.TAG, "don't restart video, as already cancelled");
                    }
                }
            });
        } else if (i == 800) {
            Log.d(TAG, "reached max duration - see if we need to restart?");
            ((Activity) getContext()).runOnUiThread(new Runnable() { // from class: com.live.gpsmap.camera.Camera.preview.Preview.11
                @Override // java.lang.Runnable
                public void run() {
                    if (Preview.this.camera_controller != null) {
                        Preview.this.restartVideo(false);
                    } else {
                        Log.d(Preview.TAG, "don't restart video, as already cancelled");
                    }
                }
            });
        } else if (i == 801) {
            stopVideo(false);
        }
        this.applicationInterface.onVideoInfo(i, i2);
    }


    public void onVideoError(int i, int i2) {
        Log.d(TAG, "onVideoError: " + i + " " + i2);
        stopVideo(false);
        this.applicationInterface.onVideoError(i, i2);
    }

//    private void takePicture(boolean max_filesize_restart, boolean photo_snapshot) {
//        if (MyDebug.LOG) Log.d(TAG, "takePicture");
//        //this.thumbnail_anim = false;
//        if (!is_video || photo_snapshot) this.phase = PHASE_TAKING_PHOTO;
//        else {
//            if (phase == PHASE_TIMER)
//                this.phase = PHASE_NORMAL; // in case we were previously on timer for starting the video
//        }
//        synchronized (this) {
//            // synchronise for consistency (keep FindBugs happy)
//            take_photo_after_autofocus = false;
//        }
//        if (camera_controller == null) {
//            if (MyDebug.LOG) Log.d(TAG, "camera not opened!");
//            this.phase = PHASE_NORMAL;
//            applicationInterface.cameraInOperation(false, false);
//            if (is_video) applicationInterface.cameraInOperation(false, true);
//            return;
//        }
//        if (!this.has_surface) {
//            if (MyDebug.LOG) Log.d(TAG, "preview surface not yet available");
//            this.phase = PHASE_NORMAL;
//            applicationInterface.cameraInOperation(false, false);
//            if (is_video) applicationInterface.cameraInOperation(false, true);
//            return;
//        }
//
//        boolean store_location = applicationInterface.getGeotaggingPref();
//        if (store_location) {
//            boolean require_location = applicationInterface.getRequireLocationPref();
//            if (require_location) {
//                if (applicationInterface.getLocation() != null) {
//                    // fine, we have location
//                } else {
//                    if (MyDebug.LOG) Log.d(TAG, "location data required, but not available");
//                    showToast(null, R.string.location_not_available);
//                    if (!is_video || photo_snapshot) this.phase = PHASE_NORMAL;
//                    applicationInterface.cameraInOperation(false, false);
//                    if (is_video) applicationInterface.cameraInOperation(false, true);
//                    return;
//                }
//            }
//        }
//
//        if (is_video && !photo_snapshot) {
//            if (MyDebug.LOG) Log.d(TAG, "start video recording");
//            startVideoRecording(max_filesize_restart);
//            return;
//        }
//
//        takePhoto(false);
//        if (MyDebug.LOG) Log.d(TAG, "takePicture exit");
//    }

    public void takePicture(boolean z, boolean z2, boolean z3) {
        this.mainActivity.blinkAnimation();
        Log.d(TAG, "takePicture");
        if (!this.is_video || z2) {
            this.phase = 2;
        } else if (this.phase == 1) {
            this.phase = 0;
        }
        synchronized (this) {
            this.take_photo_after_autofocus = false;
        }
        if (this.camera_controller == null) {
            Log.d(TAG, "camera not opened!");
            this.phase = 0;
            this.applicationInterface.cameraInOperation(false, false);
            if (this.is_video) {
                this.applicationInterface.cameraInOperation(false, true);
            }
        } else if (!this.has_surface) {
            Log.d(TAG, "preview surface not yet available");
            this.phase = 0;
            this.applicationInterface.cameraInOperation(false, false);
            if (this.is_video) {
                this.applicationInterface.cameraInOperation(false, true);
            }
        } else if (this.applicationInterface.getGeotaggingPref() && this.applicationInterface.getRequireLocationPref() && this.applicationInterface.getLocation() == null) {
            Log.d(TAG, "location data required, but not available");
            showToast((ToastBoxer) null, R.string.location_not_available);
            if (!this.is_video || z2) {
                this.phase = 0;
            }
            this.applicationInterface.cameraInOperation(false, false);
            if (this.is_video) {
                this.applicationInterface.cameraInOperation(false, true);
            }
        } else if (this.is_video && !z2) {
            Log.d(TAG, "start video recording");
            startVideoRecording(z);
        } else {
            takePhoto(false, z3);
            Log.d(TAG, "takePicture exit");
        }
    }

    private VideoFileInfo createVideoFile(String s) {
        Uri uri0;
        String s2;
        ParcelFileDescriptor parcelFileDescriptor0 = null;
        Log.d("Preview", "createVideoFile");
        try {
            ApplicationInterface.VideoMethod applicationInterface$VideoMethod0 = this.applicationInterface.createOutputVideoMethod();
            Log.d("Preview", "method? " + applicationInterface$VideoMethod0);
            if (applicationInterface$VideoMethod0 == ApplicationInterface.VideoMethod.FILE) {
                String s1 = this.applicationInterface.createOutputVideoFile(s).getAbsolutePath();
                Log.d("Preview", "save to: " + s1);
                s2 = s1;
                uri0 = null;
                parcelFileDescriptor0 = null;
            } else {
                if (applicationInterface$VideoMethod0 == ApplicationInterface.VideoMethod.SAF) {
                    uri0 = this.applicationInterface.createOutputVideoSAF(s);
                } else {
                    uri0 = applicationInterface$VideoMethod0 == ApplicationInterface.VideoMethod.MEDIASTORE ? this.applicationInterface.createOutputVideoMediaStore(s) : this.applicationInterface.createOutputVideoUri();
                }

                Log.d("Preview", "save to: " + uri0);
                ParcelFileDescriptor parcelFileDescriptor1 = this.getContext().getContentResolver().openFileDescriptor(uri0, "rw");
                parcelFileDescriptor0 = parcelFileDescriptor1;
                s2 = null;
            }

            return new VideoFileInfo(applicationInterface$VideoMethod0, uri0, s2, parcelFileDescriptor0);
        } catch (IOException iOException0) {
            Log.e("Preview", "Couldn\'t create media video file; check storage permissions?");
            iOException0.printStackTrace();
            if (parcelFileDescriptor0 != null) {
                Log.d("Preview", "failed, so clean up video_pfd_saf");
                try {
                    parcelFileDescriptor0.close();
                } catch (IOException iOException1) {
                    iOException1.printStackTrace();
                }

                return null;
            }

            return null;
        }
    }

    private void startVideoRecording(boolean z) {
        boolean z2;
        boolean z3;
        Log.d(TAG, "startVideoRecording");
        this.focus_success = 3;
        boolean z4 = false;
        this.test_called_next_output_file = false;
        this.test_started_next_output_file = false;
        this.nextVideoFileInfo = null;
        VideoProfile videoProfile = getVideoProfile();
        VideoFileInfo createVideoFile = createVideoFile(videoProfile.fileExtension);
        if (createVideoFile == null) {
            this.videoFileInfo = new VideoFileInfo();
            this.applicationInterface.onFailedCreateVideoFileError();
            this.applicationInterface.cameraInOperation(false, true);
            return;
        }
        this.videoFileInfo = createVideoFile;
        Log.d(TAG, "current_video_quality: " + this.video_quality_handler.getCurrentVideoQualityIndex());
        if (this.video_quality_handler.getCurrentVideoQualityIndex() != -1) {
            Log.d(TAG, "current_video_quality value: " + this.video_quality_handler.getCurrentVideoQuality());
        }
        Log.d(TAG, "resolution " + videoProfile.videoFrameWidth + " x " + videoProfile.videoFrameHeight);
        StringBuilder sb = new StringBuilder();
        sb.append("bit rate ");
        sb.append(videoProfile.videoBitRate);
        Log.d(TAG, sb.toString());
        boolean shutterSoundPref = this.applicationInterface.getShutterSoundPref();
        Log.d(TAG, "enable_sound? " + shutterSoundPref);
        this.camera_controller.enableShutterSound(false);
        MediaRecorder mediaRecorder = new MediaRecorder();
        this.camera_controller.unlock();
        Log.d(TAG, "set video listeners");
        mediaRecorder.setOnInfoListener(new MediaRecorder.OnInfoListener() {
            @Override
            public void onInfo(MediaRecorder mediaRecorder2, final int i, final int i2) {
                Log.d(Preview.TAG, "MediaRecorder info: " + i + " extra: " + i2);
                ((Activity) Preview.this.getContext()).runOnUiThread(new Runnable() {
                    @Override // java.lang.Runnable
                    public void run() {
                        Preview.this.onVideoInfo(i, i2);
                    }
                });
            }
        });
        mediaRecorder.setOnErrorListener(new MediaRecorder.OnErrorListener() {
            @Override // android.media.MediaRecorder.OnErrorListener
            public void onError(MediaRecorder mediaRecorder2, final int i, final int i2) {
                ((Activity) Preview.this.getContext()).runOnUiThread(new Runnable() {
                    @Override // java.lang.Runnable
                    public void run() {
                        Preview.this.onVideoError(i, i2);
                    }
                });
            }
        });
        this.camera_controller.initVideoRecorderPrePrepare(mediaRecorder);
        if (videoProfile.no_audio_permission) {
            showToast((ToastBoxer) null, R.string.permission_record_audio_not_available);
        }
        if (this.applicationInterface.getGeotaggingPref() && this.applicationInterface.getLocation() != null) {
            Location location = this.applicationInterface.getLocation();
            mediaRecorder.setLocation((float) location.getLatitude(), (float) location.getLongitude());
        }
        Log.d(TAG, "copy video profile to media recorder");
        videoProfile.copyToMediaRecorder(mediaRecorder);
        try {
            ApplicationInterface.VideoMaxFileSize videoMaxFileSizePref = this.applicationInterface.getVideoMaxFileSizePref();
            long j = videoMaxFileSizePref.max_filesize;
            if (j>0) {
                Log.d(TAG, "set max file size of: " + j);
                try {
                    mediaRecorder.setMaxFileSize(j);
                } catch (RuntimeException e) {
                    Log.e(TAG, "failed to set max filesize of: " + j);
                    e.printStackTrace();
                }
            }
            this.video_restart_on_max_filesize = videoMaxFileSizePref.auto_restart;
            long videoMaxDurationPref = this.applicationInterface.getVideoMaxDurationPref();
            Log.d(TAG, " " + videoMaxDurationPref);
            if (!z) {
                this.video_accumulated_time = 0L;
            } else if (videoMaxDurationPref>0) {
                videoMaxDurationPref -= this.video_accumulated_time;
                if (videoMaxDurationPref<min_safe_restart_video_time) {
                    Log.e(TAG, "trying to restart video with too short a time: " + videoMaxDurationPref);
                    videoMaxDurationPref = 1000L;
                }
            }
            Log.d(TAG, "actual video_max_duration: " + videoMaxDurationPref);
            mediaRecorder.setMaxDuration((int) videoMaxDurationPref);
            if (this.videoFileInfo.video_method == ApplicationInterface.VideoMethod.FILE) {
                mediaRecorder.setOutputFile(this.videoFileInfo.video_filename);
            } else {
                mediaRecorder.setOutputFile(this.videoFileInfo.video_pfd_saf.getFileDescriptor());
            }
            this.applicationInterface.cameraInOperation(true, true);
        } catch (ApplicationInterface.NoFreeStorageException e3) {
            e3.printStackTrace();
            z3 = false;
        }
        try {
            this.applicationInterface.startingVideo();
            this.cameraSurface.setVideoRecorder(mediaRecorder);
            mediaRecorder.setOrientationHint(getImageVideoRotation());
            Log.d(TAG, "about to prepare video recorder");
            mediaRecorder.prepare();
            if (this.test_video_ioexception) {
                Log.d(TAG, "test_video_ioexception is true");
                throw new IOException();
            }
            this.camera_controller.initVideoRecorderPostPrepare(mediaRecorder, supportsPhotoVideoRecording() && this.applicationInterface.usePhotoVideoRecording());
            if (this.test_video_cameracontrollerexception) {
                Log.d(TAG, "test_video_cameracontrollerexception is true");
                throw new CameraControllerException();
            }
            Log.d(TAG, "about to start video recorder");
            try {
                mediaRecorder.start();
                if (this.test_video_failure) {
                    Log.d(TAG, "test_video_failure is true");
                    throw new RuntimeException();
                }
                this.video_recorder = mediaRecorder;
                videoRecordingStarted(z);
            } catch (RuntimeException e5) {
                Log.e(TAG, "runtime exception starting video recorder");
                e5.printStackTrace();
                this.video_recorder = mediaRecorder;
                this.applicationInterface.stoppingVideo();
                failedToStartVideoRecorder(videoProfile);
            }
        } catch (CameraControllerException e6) {
            z4 = true;
            Log.e(TAG, "camera exception starting video recorder");
            e6.printStackTrace();
            this.video_recorder = mediaRecorder;
            if (z4) {
                this.applicationInterface.stoppingVideo();
            }
            failedToStartVideoRecorder(videoProfile);
        } catch (IOException e8) {
            z2 = true;
            Log.e(TAG, "failed to save video");
            e8.printStackTrace();
            this.video_recorder = mediaRecorder;
            if (z2) {
                this.applicationInterface.stoppingVideo();
            }
            this.applicationInterface.onFailedCreateVideoFileError();
            this.video_recorder.reset();
            this.video_recorder.release();
            this.video_recorder = null;
            this.video_recorder_is_paused = false;
            this.applicationInterface.deleteUnusedVideo(this.videoFileInfo.video_method, this.videoFileInfo.video_uri, this.videoFileInfo.video_filename);
            this.videoFileInfo = new VideoFileInfo();
            this.applicationInterface.cameraInOperation(false, true);
            reconnectCamera(true);
        }
    }

    private void videoRecordingStarted(boolean z) {
        Log.d(TAG, "video recorder started");
        this.video_recorder_is_paused = false;
        if (this.using_face_detection && !this.using_android_l) {
            Log.d(TAG, "restart face detection");
            this.camera_controller.startFaceDetection();
            this.faces_detected = null;
        }
        if (this.test_video_failure) {
            Log.d(TAG, "test_video_failure is true");
            throw new RuntimeException();
        }
        this.video_start_time = System.currentTimeMillis();
        this.video_start_time_set = true;
        this.applicationInterface.startedVideo();
        if (this.remaining_restart_video == 0 && !z) {
            this.remaining_restart_video = this.applicationInterface.getVideoRestartTimesPref();
            Log.d(TAG, "initialised remaining_restart_video to: " + this.remaining_restart_video);
        }
        if (this.applicationInterface.getVideoFlashPref() && supportsFlash()) {
            Timer timer = this.flashVideoTimer;
            TimerTask timerTask = new TimerTask() { // from class: com.live.gpsmap.camera.Camera.preview.Preview.1FlashVideoTimerTask
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    Log.e(Preview.TAG, "FlashVideoTimerTask");
                    ((Activity) Preview.this.getContext()).runOnUiThread(new Runnable() { // from class: com.live.gpsmap.camera.Camera.preview.Preview.1FlashVideoTimerTask.1
                        @Override // java.lang.Runnable
                        public void run() {
                            if (Preview.this.camera_controller != null && Preview.this.flashVideoTimerTask != null) {
                                Preview.this.flashVideo();
                            } else {
                                Log.d(Preview.TAG, "flashVideoTimerTask: don't flash video, as already cancelled");
                            }
                        }
                    });
                }
            };
            this.flashVideoTimerTask = timerTask;
            timer.schedule(timerTask, 0L, min_safe_restart_video_time);
        }
        if (this.applicationInterface.getVideoLowPowerCheckPref()) {
            Timer timer2 = this.batteryCheckVideoTimer;
            TimerTask timerTask2 = new TimerTask() { // from class: com.live.gpsmap.camera.Camera.preview.Preview.1BatteryCheckVideoTimerTask
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    Log.d(Preview.TAG, "BatteryCheckVideoTimerTask");
                    Intent registerReceiver = Preview.this.getContext().registerReceiver(null, Preview.this.battery_ifilter);
                    double intExtra = registerReceiver.getIntExtra("level", -1) / registerReceiver.getIntExtra("scale", -1);
                    Log.d(Preview.TAG, "batteryCheckVideoTimerTask: battery level at: " + intExtra);
                    if (intExtra<=0.03d) {
                        Log.d(Preview.TAG, "batteryCheckVideoTimerTask: battery at critical level, switching off video");
                        ((Activity) Preview.this.getContext()).runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (Preview.this.camera_controller != null && Preview.this.batteryCheckVideoTimerTask != null) {
                                    Preview.this.stopVideo(false);
                                    Preview.this.showToast((ToastBoxer) null, Preview.this.getContext().getResources().getString(R.string.video_power_critical));
                                    return;
                                }
                                Log.d(Preview.TAG, "batteryCheckVideoTimerTask: don't stop video, as already cancelled");
                            }
                        });
                    }
                }
            };
            this.batteryCheckVideoTimerTask = timerTask2;
            timer2.schedule(timerTask2, 60000L, 60000L);
        }
    }

    private void failedToStartVideoRecorder(VideoProfile videoProfile) {
        this.applicationInterface.onVideoRecordStartError(videoProfile);
        this.video_recorder.reset();
        this.video_recorder.release();
        this.video_recorder = null;
        this.video_recorder_is_paused = false;
        this.applicationInterface.cameraInOperation(false, true);
        reconnectCamera(true);
    }

    public void pauseVideo() {
        Log.d(TAG, "pauseVideo");
        if (Build.VERSION.SDK_INT<24) {
            Log.e(TAG, "pauseVideo called but requires Android N");
        } else if (isVideoRecording()) {
            if (this.video_recorder_is_paused) {
                Log.d(TAG, "resuming...");
                this.video_recorder.resume();
                this.video_recorder_is_paused = false;
                this.video_start_time = System.currentTimeMillis();
                showToast(this.pause_video_toast, R.string.video_resume);
                return;
            }
            Log.d(TAG, "pausing...");
            this.video_recorder.pause();
            this.video_recorder_is_paused = true;
            long currentTimeMillis = System.currentTimeMillis() - this.video_start_time;
            this.video_accumulated_time += currentTimeMillis;
            Log.d(TAG, "last_time: " + currentTimeMillis);
            Log.d(TAG, "video_accumulated_time is now: " + this.video_accumulated_time);
            showToast(this.pause_video_toast, R.string.video_pause);
        } else {
            Log.e(TAG, "pauseVideo called but not video recording");
        }
    }

//    private void takePhoto(boolean skip_autofocus) {
//        if (MyDebug.LOG) Log.d(TAG, "takePhoto");
//        if (camera_controller == null) {
//            Log.e(TAG, "camera not opened in takePhoto!");
//            return;
//        }
//        applicationInterface.cameraInOperation(true, false);
//        String current_ui_focus_value = getCurrentFocusValue();
//        if (MyDebug.LOG) Log.d(TAG, "current_ui_focus_value is " + current_ui_focus_value);
//
//        if (autofocus_in_continuous_mode) {
//            if (MyDebug.LOG) Log.d(TAG, "continuous mode where user touched to focus");
//            synchronized (this) {
//                // as below, if an autofocus is in progress, then take photo when it's completed
//                if (focus_success == FOCUS_WAITING) {
//                    if (MyDebug.LOG)
//                        Log.d(TAG, "autofocus_in_continuous_mode: take photo after current focus");
//                    take_photo_after_autofocus = true;
//                    camera_controller.setCaptureFollowAutofocusHint(true);
//                } else {
//                    // when autofocus_in_continuous_mode==true, it means the user recently touched to focus in continuous focus mode, so don't do another focus
//                    if (MyDebug.LOG) Log.d(TAG, "autofocus_in_continuous_mode: no need to refocus");
//                    takePhotoWhenFocused();
//                }
//            }
//        } else if (camera_controller.focusIsContinuous()) {
//            if (MyDebug.LOG) Log.d(TAG, "call autofocus for continuous focus mode");
//            // we call via autoFocus(), to avoid risk of taking photo while the continuous focus is focusing - risk of blurred photo, also sometimes get bug in such situations where we end of repeatedly focusing
//            // this is the case even if skip_autofocus is true (as we still can't guarantee that continuous focusing might be occurring)
//            // note: if the user touches to focus in continuous mode, we camera controller may be in auto focus mode, so we should only enter this codepath if the camera_controller is in continuous focus mode
//            CameraController.AutoFocusCallback autoFocusCallback = new CameraController.AutoFocusCallback() {
//                @Override
//                public void onAutoFocus(boolean success) {
//                    if (MyDebug.LOG) Log.d(TAG, "continuous mode autofocus complete: " + success);
//                    takePhotoWhenFocused();
//                }
//            };
//            camera_controller.autoFocus(autoFocusCallback, true);
//        } else if (skip_autofocus || this.recentlyFocused()) {
//            if (MyDebug.LOG) {
//                if (skip_autofocus) {
//                    Log.d(TAG, "skip_autofocus flag set");
//                } else {
//                    Log.d(TAG, "recently focused successfully, so no need to refocus");
//                }
//            }
//            takePhotoWhenFocused();
//        } else if (current_ui_focus_value != null && (current_ui_focus_value.equals("focus_mode_auto") || current_ui_focus_value.equals("focus_mode_macro"))) {
//            // n.b., we check focus_value rather than camera_controller.supportsAutoFocus(), as we want to discount focus_mode_locked
//            synchronized (this) {
//                if (focus_success == FOCUS_WAITING) {
//                    // Needed to fix bug (on Nexus 6, old camera API): if flash was on, pointing at a dark scene, and we take photo when already autofocusing, the autofocus never returned so we got stuck!
//                    // In general, probably a good idea to not redo a focus - just use the one that's already in progress
//                    if (MyDebug.LOG) Log.d(TAG, "take photo after current focus");
//                    take_photo_after_autofocus = true;
//                    camera_controller.setCaptureFollowAutofocusHint(true);
//                } else {
//                    focus_success = FOCUS_DONE; // clear focus rectangle for new refocus
//                    CameraController.AutoFocusCallback autoFocusCallback = new CameraController.AutoFocusCallback() {
//                        @Override
//                        public void onAutoFocus(boolean success) {
//                            if (MyDebug.LOG) Log.d(TAG, "autofocus complete: " + success);
//                            ensureFlashCorrect(); // need to call this in case user takes picture before startup focus completes!
//                            prepareAutoFocusPhoto();
//                            takePhotoWhenFocused();
//                        }
//                    };
//                    if (MyDebug.LOG) Log.d(TAG, "start autofocus to take picture");
//                    camera_controller.autoFocus(autoFocusCallback, true);
//                    count_cameraAutoFocus++;
//                }
//            }
//        } else {
//            takePhotoWhenFocused();
//        }
//    }

    private void takePhoto(boolean skip_autofocus, final boolean continuous_fast_burst) {
        if (MyDebug.LOG)
            Log.d(TAG, "takePhoto");
        if (camera_controller == null) {
            Log.e(TAG, "camera not opened in takePhoto!");
            return;
        }
        applicationInterface.cameraInOperation(true, false);
        String current_ui_focus_value = getCurrentFocusValue();
        if (MyDebug.LOG)
            Log.d(TAG, "current_ui_focus_value is " + current_ui_focus_value);

        if (autofocus_in_continuous_mode) {
            if (MyDebug.LOG)
                Log.d(TAG, "continuous mode where user touched to focus");

            boolean wait_for_focus;

            synchronized (this) {
                // as below, if an autofocus is in progress, then take photo when it's completed
                if (focus_success == FOCUS_WAITING) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "autofocus_in_continuous_mode: take photo after current focus");
                    wait_for_focus = true;
                    take_photo_after_autofocus = true;
                } else {
                    // when autofocus_in_continuous_mode==true, it means the user recently touched to focus in continuous focus mode, so don't do another focus
                    if (MyDebug.LOG)
                        Log.d(TAG, "autofocus_in_continuous_mode: no need to refocus");
                    wait_for_focus = false;
                }
            }

            // call CameraController outside the lock
            if (wait_for_focus) {
                camera_controller.setCaptureFollowAutofocusHint(true);
            } else {
                takePhotoWhenFocused(continuous_fast_burst);
            }
        } else if (camera_controller.focusIsContinuous()) {
            if (MyDebug.LOG)
                Log.d(TAG, "call autofocus for continuous focus mode");
            // we call via autoFocus(), to avoid risk of taking photo while the continuous focus is focusing - risk of blurred photo, also sometimes get bug in such situations where we end of repeatedly focusing
            // this is the case even if skip_autofocus is true (as we still can't guarantee that continuous focusing might be occurring)
            // note: if the user touches to focus in continuous mode, we camera controller may be in auto focus mode, so we should only enter this codepath if the camera_controller is in continuous focus mode
            CameraController.AutoFocusCallback autoFocusCallback = new CameraController.AutoFocusCallback() {
                @Override
                public void onAutoFocus(boolean success) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "continuous mode autofocus complete: " + success);
                    takePhotoWhenFocused(continuous_fast_burst);
                }
            };
            camera_controller.autoFocus(autoFocusCallback, true);
        } else if (skip_autofocus || this.recentlyFocused()) {
            if (MyDebug.LOG) {
                if (skip_autofocus) {
                    Log.d(TAG, "skip_autofocus flag set");
                } else {
                    Log.d(TAG, "recently focused successfully, so no need to refocus");
                }
            }
            takePhotoWhenFocused(continuous_fast_burst);
        } else if (current_ui_focus_value != null && (current_ui_focus_value.equals("focus_mode_auto") || current_ui_focus_value.equals("focus_mode_macro"))) {
            boolean wait_for_focus;
            // n.b., we check focus_value rather than camera_controller.supportsAutoFocus(), as we want to discount focus_mode_locked
            synchronized (this) {
                if (focus_success == FOCUS_WAITING) {
                    // Needed to fix bug (on Nexus 6, old camera API): if flash was on, pointing at a dark scene, and we take photo when already autofocusing, the autofocus never returned so we got stuck!
                    // In general, probably a good idea to not redo a focus - just use the one that's already in progress
                    if (MyDebug.LOG)
                        Log.d(TAG, "take photo after current focus");
                    wait_for_focus = true;
                    take_photo_after_autofocus = true;
                } else {
                    wait_for_focus = false;
                    focus_success = FOCUS_DONE; // clear focus rectangle for new refocus
                }
            }

            // call CameraController outside the lock
            if (wait_for_focus) {
                camera_controller.setCaptureFollowAutofocusHint(true);
            } else {
                CameraController.AutoFocusCallback autoFocusCallback = new CameraController.AutoFocusCallback() {
                    @Override
                    public void onAutoFocus(boolean success) {
                        if (MyDebug.LOG)
                            Log.d(TAG, "autofocus complete: " + success);
                        ensureFlashCorrect(); // need to call this in case user takes picture before startup focus completes!
                        prepareAutoFocusPhoto();
                        takePhotoWhenFocused(continuous_fast_burst);
                    }
                };
                if (MyDebug.LOG)
                    Log.d(TAG, "start autofocus to take picture");
                camera_controller.autoFocus(autoFocusCallback, true);
                count_cameraAutoFocus++;
            }
        } else {
            takePhotoWhenFocused(continuous_fast_burst);
        }
    }


    public void prepareAutoFocusPhoto() {
        Log.d(TAG, "prepareAutoFocusPhoto");
        if (this.using_android_l) {
            String flashValue = this.camera_controller.getFlashValue();
            if (flashValue.length()>0) {
                if (flashValue.equals("flash_auto") || flashValue.equals("flash_red_eye")) {
                    Log.d(TAG, "wait for a bit...");
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }


//    private void takePhotoWhenFocused() {
//        // should be called when auto-focused
//        if (MyDebug.LOG) Log.d(TAG, "takePhotoWhenFocused");
//        if (camera_controller == null) {
//            if (MyDebug.LOG) Log.d(TAG, "camera not opened!");
//            this.phase = PHASE_NORMAL;
//            applicationInterface.cameraInOperation(false, false);
//            return;
//        }
//        if (!this.has_surface) {
//            if (MyDebug.LOG) Log.d(TAG, "preview surface not yet available");
//            this.phase = PHASE_NORMAL;
//            applicationInterface.cameraInOperation(false, false);
//            return;
//        }
//
//        final String focus_value = current_focus_index != -1 ? supported_focus_values.get(current_focus_index) : null;
//        if (MyDebug.LOG) {
//            Log.d(TAG, "focus_value is " + focus_value);
//            Log.d(TAG, "focus_success is " + focus_success);
//        }
//
//        if (focus_value != null && focus_value.equals("focus_mode_locked") && focus_success == FOCUS_WAITING) {
//            // make sure there isn't an autofocus in progress - can happen if in locked mode we take a photo while autofocusing - see testTakePhotoLockedFocus() (although that test doesn't always properly test the bug...)
//            // we only cancel when in locked mode and if still focusing, as I had 2 bug reports for v1.16 that the photo was being taken out of focus; both reports said it worked fine in 1.15, and one confirmed that it was due to the cancelAutoFocus() line, and that it's now fixed with this fix
//            // they said this happened in every focus mode, including locked - so possible that on some devices, cancelAutoFocus() actually pulls the camera out of focus, or reverts to preview focus?
//            cancelAutoFocus();
//        }
//        removePendingContinuousFocusReset(); // to avoid switching back to continuous focus mode while taking a photo - instead we'll always make sure we switch back after taking a photo
//        updateParametersFromLocation(); // do this now, not before, so we don't set location parameters during focus (sometimes get RuntimeException)
//
//        focus_success = FOCUS_DONE; // clear focus rectangle if not already done
//        successfully_focused = false; // so next photo taken will require an autofocus
//        if (MyDebug.LOG) Log.d(TAG, "remaining_repeat_photos: " + remaining_repeat_photos);
//
//        CameraController.PictureCallback pictureCallback = new CameraController.PictureCallback() {
//            private boolean success = false; // whether jpeg callback succeeded
//            private boolean has_date = false;
//            private Date current_date = null;
//
//            public void onStarted() {
//                if (MyDebug.LOG) Log.d(TAG, "onStarted");
//                applicationInterface.onCaptureStarted();
//            }
//
//            public void onCompleted() {
//                if (MyDebug.LOG) Log.d(TAG, "onCompleted");
//                applicationInterface.onPictureCompleted();
//                if (!using_android_l) {
//                    is_preview_started = false; // preview automatically stopped due to taking photo on original Camera API
//                }
//                phase = PHASE_NORMAL; // need to set this even if remaining repeat photos, so we can restart the preview
//                if (remaining_repeat_photos == -1 || remaining_repeat_photos>0) {
//                    if (!is_preview_started) {
//                        // we need to restart the preview; and we do this in the callback, as we need to restart after saving the image
//                        // (otherwise this can fail, at least on Nexus 7)
//                        if (MyDebug.LOG)
//                            Log.d(TAG, "repeat mode photos remaining: onPictureTaken about to start preview: " + remaining_repeat_photos);
//                        startCameraPreview();
//                        if (MyDebug.LOG)
//                            Log.d(TAG, "repeat mode photos remaining: onPictureTaken started preview: " + remaining_repeat_photos);
//                    }
//                } else {
//                    phase = PHASE_NORMAL;
//                    boolean pause_preview = applicationInterface.getPausePreviewPref();
//                    if (MyDebug.LOG) Log.d(TAG, "pause_preview? " + pause_preview);
//                    if (pause_preview && success) {
//                        if (is_preview_started) {
//                            // need to manually stop preview on Android L Camera2
//                            if (camera_controller != null) {
//                                camera_controller.stopPreview();
//                            }
//                            is_preview_started = false;
//                        }
//                        setPreviewPaused(true);
//                    } else {
//                        if (!is_preview_started) {
//                            // we need to restart the preview; and we do this in the callback, as we need to restart after saving the image
//                            // (otherwise this can fail, at least on Nexus 7)
//                            startCameraPreview();
//                        }
//                        applicationInterface.cameraInOperation(false, false);
//                        if (MyDebug.LOG) Log.d(TAG, "onPictureTaken started preview");
//                    }
//                }
//                continuousFocusReset(); // in case we took a photo after user had touched to focus (causing us to switch from continuous to autofocus mode)
//                if (camera_controller != null && focus_value != null && (focus_value.equals("focus_mode_continuous_picture") || focus_value.equals("focus_mode_continuous_video"))) {
//                    if (MyDebug.LOG) Log.d(TAG, "cancelAutoFocus to restart continuous focusing");
//                    camera_controller.cancelAutoFocus(); // needed to restart continuous focusing
//                }
//
//                if (MyDebug.LOG)
//                    Log.d(TAG, "do we need to take another photo? remaining_repeat_photos: " + remaining_repeat_photos);
//                if (remaining_repeat_photos == -1 || remaining_repeat_photos>0) {
//                    takeRemainingRepeatPhotos();
//                }
//            }
//
//            /** Ensures we get the same date for both JPEG and RAW; and that we set the date ASAP so that it corresponds to actual
//             *  photo time.
//             */
//            private void initDate() {
//                if (!has_date) {
//                    has_date = true;
//                    current_date = new Date();
//                    if (MyDebug.LOG) Log.d(TAG, "picture taken on date: " + current_date);
//                }
//            }
//
//            public void onPictureTaken(byte[] data) {
//                if (MyDebug.LOG) Log.d(TAG, "onPictureTaken");
//                // n.b., this is automatically run in a different thread
//                initDate();
//                if (!applicationInterface.onPictureTaken(data, current_date)) {
//                    if (MyDebug.LOG) Log.e(TAG, "applicationInterface.onPictureTaken failed");
//                    success = false;
//                } else {
//                    success = true;
//                }
//            }
//
//            public void onRawPictureTaken(RawImage raw_image) {
//                if (MyDebug.LOG) Log.d(TAG, "onRawPictureTaken");
//                initDate();
//                if (!applicationInterface.onRawPictureTaken(raw_image, current_date)) {
//                    if (MyDebug.LOG) Log.e(TAG, "applicationInterface.onRawPictureTaken failed");
//                }
//            }
//
//            public void onBurstPictureTaken(List<byte[]> images) {
//                if (MyDebug.LOG) Log.d(TAG, "onBurstPictureTaken");
//                // n.b., this is automatically run in a different thread
//                initDate();
//
//                success = true;
//                if (!applicationInterface.onBurstPictureTaken(images, current_date)) {
//                    if (MyDebug.LOG) Log.e(TAG, "applicationInterface.onBurstPictureTaken failed");
//                    success = false;
//                }
//            }
//
//            public void onFrontScreenTurnOn() {
//                if (MyDebug.LOG) Log.d(TAG, "onFrontScreenTurnOn");
//                applicationInterface.turnFrontScreenFlashOn();
//            }
//        };
//        CameraController.ErrorCallback errorCallback = new CameraController.ErrorCallback() {
//            public void onError() {
//                if (MyDebug.LOG) Log.e(TAG, "error from takePicture");
//                count_cameraTakePicture--; // cancel out the increment from after the takePicture() call
//                applicationInterface.onPhotoError();
//                phase = PHASE_NORMAL;
//                startCameraPreview();
//                applicationInterface.cameraInOperation(false, false);
//            }
//        };
//        {
//            camera_controller.setRotation(getImageVideoRotation());
//
//            boolean enable_sound = applicationInterface.getShutterSoundPref();
//            if (is_video && isVideoRecording())
//                enable_sound = false; // always disable shutter sound if we're taking a photo while recording video
//            if (MyDebug.LOG) Log.d(TAG, "enable_sound? " + enable_sound);
//            camera_controller.enableShutterSound(enable_sound);
//            if (using_android_l) {
//                boolean use_camera2_fast_burst = applicationInterface.useCamera2FastBurst();
//                if (MyDebug.LOG) Log.d(TAG, "use_camera2_fast_burst? " + use_camera2_fast_burst);
//                camera_controller.setUseExpoFastBurst(use_camera2_fast_burst);
//            }
//            if (MyDebug.LOG) Log.d(TAG, "about to call takePicture");
//            camera_controller.takePicture(pictureCallback, errorCallback);
//            count_cameraTakePicture++;
//        }
//        if (MyDebug.LOG) Log.d(TAG, "takePhotoWhenFocused exit");
//    }

    private void takePhotoWhenFocused(boolean continuous_fast_burst) {
        // should be called when auto-focused
        if (MyDebug.LOG)
            Log.d(TAG, "takePhotoWhenFocused");
        if (camera_controller == null) {
            if (MyDebug.LOG)
                Log.d(TAG, "camera not opened!");
            this.phase = PHASE_NORMAL;
            applicationInterface.cameraInOperation(false, false);
            return;
        }
        if (!this.has_surface) {
            if (MyDebug.LOG)
                Log.d(TAG, "preview surface not yet available");
            this.phase = PHASE_NORMAL;
            applicationInterface.cameraInOperation(false, false);
            return;
        }

        final String focus_value = current_focus_index != -1 ? supported_focus_values.get(current_focus_index) : null;
        if (MyDebug.LOG) {
            Log.d(TAG, "focus_value is " + focus_value);
            Log.d(TAG, "focus_success is " + focus_success);
        }

        if (focus_value != null && focus_value.equals("focus_mode_locked") && focus_success == FOCUS_WAITING) {
            // make sure there isn't an autofocus in progress - can happen if in locked mode we take a photo while autofocusing - see testTakePhotoLockedFocus() (although that test doesn't always properly test the bug...)
            // we only cancel when in locked mode and if still focusing, as I had 2 bug reports for v1.16 that the photo was being taken out of focus; both reports said it worked fine in 1.15, and one confirmed that it was due to the cancelAutoFocus() line, and that it's now fixed with this fix
            // they said this happened in every focus mode, including locked - so possible that on some devices, cancelAutoFocus() actually pulls the camera out of focus, or reverts to preview focus?
            cancelAutoFocus();
        }
        removePendingContinuousFocusReset(); // to avoid switching back to continuous focus mode while taking a photo - instead we'll always make sure we switch back after taking a photo
        updateParametersFromLocation(); // do this now, not before, so we don't set location parameters during focus (sometimes get RuntimeException)

        focus_success = FOCUS_DONE; // clear focus rectangle if not already done
        successfully_focused = false; // so next photo taken will require an autofocus
        if (MyDebug.LOG)
            Log.d(TAG, "remaining_repeat_photos: " + remaining_repeat_photos);

        CameraController.PictureCallback pictureCallback = new CameraController.PictureCallback() {
            private boolean success = false; // whether jpeg callback succeeded
            private boolean has_date = false;
            private Date current_date = null;

            public void onStarted() {
                if (MyDebug.LOG)
                    Log.d(TAG, "onStarted");
                applicationInterface.onCaptureStarted();
                if (applicationInterface.getBurstForNoiseReduction() && applicationInterface.getNRModePref() == ApplicationInterface.NRModePref.NRMODE_LOW_LIGHT) {
                    if (camera_controller.getBurstTotal()>=CameraController.N_IMAGES_NR_DARK_LOW_LIGHT) {
                        showToast(null, R.string.preference_nr_mode_low_light_message, true);
                    }
                }
            }

            public void onCompleted() {
                if (MyDebug.LOG)
                    Log.d(TAG, "onCompleted");
                applicationInterface.onPictureCompleted();
                if (!using_android_l) {
                    is_preview_started = false; // preview automatically stopped due to taking photo on original Camera API
                }
                phase = PHASE_NORMAL; // need to set this even if remaining repeat photos, so we can restart the preview
                if (remaining_repeat_photos == -1 || remaining_repeat_photos>0) {
                    if (!is_preview_started) {
                        // we need to restart the preview; and we do this in the callback, as we need to restart after saving the image
                        // (otherwise this can fail, at least on Nexus 7)
                        if (MyDebug.LOG)
                            Log.d(TAG, "repeat mode photos remaining: onPictureTaken about to start preview: " + remaining_repeat_photos);
                        startCameraPreview();
                        if (MyDebug.LOG)
                            Log.d(TAG, "repeat mode photos remaining: onPictureTaken started preview: " + remaining_repeat_photos);
                    }
                    applicationInterface.cameraInOperation(false, false);
                } else {
                    phase = PHASE_NORMAL;
                    boolean pause_preview = applicationInterface.getPausePreviewPref();
                    if (MyDebug.LOG)
                        Log.d(TAG, "pause_preview? " + pause_preview);
                    if (pause_preview && success) {
                        if (is_preview_started) {
                            // need to manually stop preview on Android L Camera2
                            // also note: even though we now draw the last image on top of the screen instead of relying on the
                            // camera preview being paused, it's still good practice to pause the preview/camera for privacy reasons
                            if (camera_controller != null) {
                                camera_controller.stopPreview();
                            }
                            is_preview_started = false;
                        }
                        setPreviewPaused(true);
                    } else {
                        if (!is_preview_started) {
                            // we need to restart the preview; and we do this in the callback, as we need to restart after saving the image
                            // (otherwise this can fail, at least on Nexus 7)
                            startCameraPreview();
                        }
                        applicationInterface.cameraInOperation(false, false);
                        if (MyDebug.LOG)
                            Log.d(TAG, "onPictureTaken started preview");
                    }
                }
                continuousFocusReset(); // in case we took a photo after user had touched to focus (causing us to switch from continuous to autofocus mode)
                if (camera_controller != null && focus_value != null && (focus_value.equals("focus_mode_continuous_picture") || focus_value.equals("focus_mode_continuous_video"))) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "cancelAutoFocus to restart continuous focusing");
                    camera_controller.cancelAutoFocus(); // needed to restart continuous focusing
                }

                if (camera_controller != null && camera_controller.getBurstType() == CameraController.BurstType.BURSTTYPE_CONTINUOUS) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "continuous burst mode ended, so revert to standard mode");
                    setupBurstMode();
                }

                if (MyDebug.LOG)
                    Log.d(TAG, "do we need to take another photo? remaining_repeat_photos: " + remaining_repeat_photos);
                if (remaining_repeat_photos == -1 || remaining_repeat_photos>0) {
                    takeRemainingRepeatPhotos();
                }
            }

            /** Ensures we get the same date for both JPEG and RAW; and that we set the date ASAP so that it corresponds to actual
             *  photo time.
             */
            private void initDate() {
                if (!has_date) {
                    has_date = true;
                    current_date = new Date();
                    if (MyDebug.LOG)
                        Log.d(TAG, "picture taken on date: " + current_date);
                }
            }

            public void onPictureTaken(byte[] data) {
                if (MyDebug.LOG)
                    Log.d(TAG, "onPictureTaken");
                initDate();
                if (!applicationInterface.onPictureTaken(data, current_date)) {
                    if (MyDebug.LOG)
                        Log.e(TAG, "applicationInterface.onPictureTaken failed");
                    success = false;
                } else {
                    success = true;
                }
            }

            public void onRawPictureTaken(RawImage raw_image) {
                if (MyDebug.LOG)
                    Log.d(TAG, "onRawPictureTaken");
                initDate();
                if (!applicationInterface.onRawPictureTaken(raw_image, current_date)) {
                    if (MyDebug.LOG)
                        Log.e(TAG, "applicationInterface.onRawPictureTaken failed");
                }
            }

            public void onBurstPictureTaken(List<byte[]> images) {
                if (MyDebug.LOG)
                    Log.d(TAG, "onBurstPictureTaken");
                initDate();

                success = true;
                if (!applicationInterface.onBurstPictureTaken(images, current_date)) {
                    if (MyDebug.LOG)
                        Log.e(TAG, "applicationInterface.onBurstPictureTaken failed");
                    success = false;
                }
            }

            public void onRawBurstPictureTaken(List<RawImage> raw_images) {
                if (MyDebug.LOG)
                    Log.d(TAG, "onRawBurstPictureTaken");
                initDate();

                if (!applicationInterface.onRawBurstPictureTaken(raw_images, current_date)) {
                    if (MyDebug.LOG)
                        Log.e(TAG, "applicationInterface.onRawBurstPictureTaken failed");
                }
            }

            public boolean imageQueueWouldBlock(int n_raw, int n_jpegs) {
                if (MyDebug.LOG)
                    Log.d(TAG, "imageQueueWouldBlock");
                return applicationInterface.imageQueueWouldBlock(n_raw, n_jpegs);
            }

            public void onFrontScreenTurnOn() {
                if (MyDebug.LOG)
                    Log.d(TAG, "onFrontScreenTurnOn");
                applicationInterface.turnFrontScreenFlashOn();
            }
        };
        CameraController.ErrorCallback errorCallback = new CameraController.ErrorCallback() {
            public void onError() {
                if (MyDebug.LOG)
                    Log.e(TAG, "error from takePicture");
                count_cameraTakePicture--; // cancel out the increment from after the takePicture() call
                if (MyDebug.LOG) {
                    Log.d(TAG, "count_cameraTakePicture is now: " + count_cameraTakePicture);
                }
                applicationInterface.onPhotoError();
                phase = PHASE_NORMAL;
                startCameraPreview();
                applicationInterface.cameraInOperation(false, false);
            }
        };
        {
            camera_controller.setRotation(getImageVideoRotation());

            boolean enable_sound = applicationInterface.getShutterSoundPref();
            if (is_video && isVideoRecording())
                enable_sound = false; // always disable shutter sound if we're taking a photo while recording video
            if (MyDebug.LOG)
                Log.d(TAG, "enable_sound? " + enable_sound);
            camera_controller.enableShutterSound(enable_sound);
            if (using_android_l) {
                boolean camera2_dummy_capture_hack = applicationInterface.useCamera2DummyCaptureHack();
                if (MyDebug.LOG)
                    Log.d(TAG, "camera2_dummy_capture_hack? " + camera2_dummy_capture_hack);
                camera_controller.setDummyCaptureHack(camera2_dummy_capture_hack);

                boolean use_camera2_fast_burst = applicationInterface.useCamera2FastBurst();
                if (MyDebug.LOG)
                    Log.d(TAG, "use_camera2_fast_burst? " + use_camera2_fast_burst);
                camera_controller.setUseExpoFastBurst(use_camera2_fast_burst);
            }
            if (continuous_fast_burst) {
                camera_controller.setBurstType(CameraController.BurstType.BURSTTYPE_CONTINUOUS);
            }

            if (MyDebug.LOG)
                Log.d(TAG, "about to call takePicture");
            camera_controller.takePicture(pictureCallback, errorCallback);
            count_cameraTakePicture++;
            if (MyDebug.LOG) {
                Log.d(TAG, "count_cameraTakePicture is now: " + count_cameraTakePicture);
            }
        }
        if (MyDebug.LOG)
            Log.d(TAG, "takePhotoWhenFocused exit");
    }


    private void takeRemainingRepeatPhotos() {
        if (MyDebug.LOG)
            Log.d(TAG, "takeRemainingRepeatPhotos");
        if (remaining_repeat_photos == -1 || remaining_repeat_photos>0) {
            if (camera_controller == null) {
                Log.e(TAG, "remaining_repeat_photos still set, but camera is closed!: " + remaining_repeat_photos);
                cancelRepeat();
            } else {
                // check it's okay to take a photo
                if (!applicationInterface.canTakeNewPhoto()) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "takeRemainingRepeatPhotos: still processing...");
                    // wait a bit then check again
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (MyDebug.LOG)
                                Log.d(TAG, "takeRemainingRepeatPhotos: check again from post delayed runnable");
                            takeRemainingRepeatPhotos();
                        }
                    }, 500);
                    return;
                }

                if (remaining_repeat_photos>0)
                    remaining_repeat_photos--;

                long timer_delay = applicationInterface.getRepeatIntervalPref();
                if (timer_delay == 0) {
                    // we set skip_autofocus to go straight to taking a photo rather than refocusing, for speed
                    // need to manually set the phase
                    phase = PHASE_TAKING_PHOTO;
                    takePhoto(true, false);
                } else {
                    takePictureOnTimer(timer_delay, true);
                }
            }
        }
    }


//    public void takeRemainingRepeatPhotos() {
//        Log.d(TAG, "takeRemainingRepeatPhotos");
//        int i = this.remaining_repeat_photos;
//        if (i == -1 || i>0) {
//            if (this.camera_controller == null) {
//                Log.e(TAG, "remaining_repeat_photos still set, but camera is closed!: " + this.remaining_repeat_photos);
//                cancelRepeat();
//            } else if (!this.applicationInterface.canTakeNewPhoto()) {
//                Log.d(TAG, "takeRemainingRepeatPhotos: still processing...");
//                new Handler().postDelayed(new Runnable() { // from class: com.live.gpsmap.camera.Camera.preview.Preview.18
//                    @Override // java.lang.Runnable
//                    public void run() {
//                        Log.d(Preview.TAG, "takeRemainingRepeatPhotos: check again from post delayed runnable");
//                        Preview.this.takeRemainingRepeatPhotos();
//                    }
//                }, 500L);
//            } else {
//                int i2 = this.remaining_repeat_photos;
//                if (i2>0) {
//                    this.remaining_repeat_photos = i2 - 1;
//                }
//                Log.d(TAG, "takeRemainingRepeatPhotos: remaining_repeat_photos is now: " + this.remaining_repeat_photos);
//                long repeatIntervalPref = this.applicationInterface.getRepeatIntervalPref();
//                if (repeatIntervalPref == 0) {
//                    this.phase = 2;
//                    takePhoto(true, false);
//                    return;
//                }
//                takePictureOnTimer(repeatIntervalPref, true);
//            }
//        }
//    }

    public void requestAutoFocus() {
        Log.d(TAG, "requestAutoFocus");
        cancelAutoFocus();
        tryAutoFocus(false, true);
    }


    public void tryAutoFocus(boolean z, final boolean z2) {
        Log.d(TAG, "tryAutoFocus");
        Log.d(TAG, "startup? " + z);
        Log.d(TAG, "manual? " + z2);
        if (this.camera_controller == null) {
            Log.d(TAG, "camera not opened!");
        } else if (!this.has_surface) {
            Log.d(TAG, "preview surface not yet available");
        } else if (!this.is_preview_started) {
            Log.d(TAG, "preview not yet started");
        } else if ((!z2 || !this.is_video) && (isVideoRecording() || isTakingPhotoOrOnTimer())) {
            Log.d(TAG, "currently taking a photo");
        } else {
            if (z2) {
                removePendingContinuousFocusReset();
            }
            if (z2 && !this.is_video && this.camera_controller.focusIsContinuous() && supportedFocusValue("focus_mode_auto")) {
                Log.d(TAG, "switch from continuous to autofocus mode for touch focus");
                this.camera_controller.setFocusValue("focus_mode_auto");
                this.autofocus_in_continuous_mode = true;
            }
            if (this.camera_controller.supportsAutoFocus()) {
                Log.d(TAG, "try to start autofocus");
                if (!this.using_android_l) {
                    this.set_flash_value_after_autofocus = "";
                    String flashValue = this.camera_controller.getFlashValue();
                    if (z && flashValue.length()>0 && !flashValue.equals("flash_off") && !flashValue.equals("")) {
                        this.set_flash_value_after_autofocus = flashValue;
                        this.camera_controller.setFlashValue("flash_off");
                    }
                    Log.d(TAG, "set_flash_value_after_autofocus is now: " + this.set_flash_value_after_autofocus);
                }
                CameraController.AutoFocusCallback autoFocusCallback = new CameraController.AutoFocusCallback() {
                    @Override
                    public void onAutoFocus(boolean z3) {
                        Log.d(Preview.TAG, "autofocus complete: " + z3);
                        Preview.this.autoFocusCompleted(z2, z3, false);
                    }
                };
                this.focus_success = 0;
                Log.d(TAG, "set focus_success to " + this.focus_success);
                this.focus_complete_time = -1L;
                this.successfully_focused = false;
                this.camera_controller.autoFocus(autoFocusCallback, false);
                this.count_cameraAutoFocus++;
                this.focus_started_time = System.currentTimeMillis();
                Log.d(TAG, "autofocus started, count now: " + this.count_cameraAutoFocus);
            } else if (this.has_focus_area) {
                this.focus_success = 1;
                this.focus_complete_time = System.currentTimeMillis();
            }
        }
    }

    private void removePendingContinuousFocusReset() {
        String str = TAG;
        Log.d(str, "removePendingContinuousFocusReset");
        if (this.reset_continuous_focus_runnable != null) {
            Log.d(str, "remove pending reset_continuous_focus_runnable");
            this.reset_continuous_focus_handler.removeCallbacks(this.reset_continuous_focus_runnable);
            this.reset_continuous_focus_runnable = null;
        }
    }


    public void continuousFocusReset() {
        Log.d(TAG, "switch back to continuous focus after autofocus?");
        if (this.camera_controller == null || !this.autofocus_in_continuous_mode) {
            return;
        }
        this.autofocus_in_continuous_mode = false;
        String currentFocusValue = getCurrentFocusValue();
        if (currentFocusValue != null && !this.camera_controller.getFocusValue().equals(currentFocusValue) && this.camera_controller.getFocusValue().equals("focus_mode_auto")) {
            this.camera_controller.cancelAutoFocus();
            this.camera_controller.setFocusValue(currentFocusValue);
            return;
        }
    }

    private void cancelAutoFocus() {
        Log.d(TAG, "cancelAutoFocus");
        CameraController cameraController = this.camera_controller;
        if (cameraController != null) {
            cameraController.cancelAutoFocus();
            autoFocusCompleted(false, false, true);
        }
    }


    public void ensureFlashCorrect() {
        if (this.set_flash_value_after_autofocus.length()<=0 || this.camera_controller == null) {
            return;
        }
        Log.d(TAG, "set flash back to: " + this.set_flash_value_after_autofocus);
        this.camera_controller.setFlashValue(this.set_flash_value_after_autofocus);
        this.set_flash_value_after_autofocus = "";
    }


    public void autoFocusCompleted(boolean z, boolean z2, boolean z3) {
        boolean z4;
        CameraController cameraController;
        Log.d(TAG, "autoFocusCompleted");
        Log.d(TAG, "    manual? " + z);
        Log.d(TAG, "    success? " + z2);
        Log.d(TAG, "    cancelled? " + z3);
        if (z3) {
            this.focus_success = 3;
        } else {
            this.focus_success = z2 ? 1 : 2;
            this.focus_complete_time = System.currentTimeMillis();
        }
        if (z && !z3 && (z2 || this.applicationInterface.isTestAlwaysFocus())) {
            this.successfully_focused = true;
            this.successfully_focused_time = this.focus_complete_time;
        }
        if (z && this.camera_controller != null && this.autofocus_in_continuous_mode) {
            String currentFocusValue = getCurrentFocusValue();
            Log.d(TAG, "current_ui_focus_value: " + currentFocusValue);
            if (currentFocusValue != null && !this.camera_controller.getFocusValue().equals(currentFocusValue) && this.camera_controller.getFocusValue().equals("focus_mode_auto")) {
                Runnable runnable = new Runnable() { // from class: com.live.gpsmap.camera.Camera.preview.Preview.20
                    @Override // java.lang.Runnable
                    public void run() {
                        Log.d(Preview.TAG, "reset_continuous_focus_runnable running...");
                        Preview.this.reset_continuous_focus_runnable = null;
                        Preview.this.continuousFocusReset();
                    }
                };
                this.reset_continuous_focus_runnable = runnable;
                this.reset_continuous_focus_handler.postDelayed(runnable, 3000L);
            }
        }
        ensureFlashCorrect();
        if (this.using_face_detection && !z3 && (cameraController = this.camera_controller) != null) {
            cameraController.cancelAutoFocus();
        }
        synchronized (this) {
            z4 = this.take_photo_after_autofocus;
            this.take_photo_after_autofocus = false;
        }
        if (z4) {
            Log.d(TAG, "take_photo_after_autofocus is set");
            prepareAutoFocusPhoto();
            takePhotoWhenFocused(false);
        }
        Log.d(TAG, "autoFocusCompleted exit");
    }

    public void startCameraPreview() {
        Log.d(TAG, "startCameraPreview");
        long currentTimeMillis = System.currentTimeMillis();
        if (this.camera_controller != null && !isTakingPhotoOrOnTimer() && !this.is_preview_started) {
            Log.d(TAG, "starting the camera preview");
            Log.d(TAG, "setRecordingHint: " + this.is_video);
            this.camera_controller.setRecordingHint(this.is_video);
            setPreviewFps();
            try {
                this.camera_controller.startPreview();
                this.count_cameraStartPreview++;
                this.is_preview_started = true;
                Log.d(TAG, "startCameraPreview: time after starting camera preview: " + (System.currentTimeMillis() - currentTimeMillis));
                if (this.using_face_detection) {
                    Log.d(TAG, "start face detection");
                    this.camera_controller.startFaceDetection();
                    this.faces_detected = null;
                }
            } catch (CameraControllerException e) {
                Log.d(TAG, "CameraControllerException trying to startPreview");
                e.printStackTrace();
                this.applicationInterface.onFailedStartPreview();
                return;
            }
        }
        setPreviewPaused(false);
        setupContinuousFocusMove();
        Log.d(TAG, "startCameraPreview: total time for startCameraPreview: " + (System.currentTimeMillis() - currentTimeMillis));
    }


    public void setPreviewPaused(boolean z) {
        Log.d(TAG, "setPreviewPaused: " + z);
        this.applicationInterface.hasPausedPreview(z);
        if (z) {
            this.phase = 3;
            return;
        }
        this.phase = 0;
        this.applicationInterface.cameraInOperation(false, false);
    }

    public void onAccelerometerSensorChanged(SensorEvent sensorEvent) {
        this.has_gravity = true;
        for (int i = 0; i<3; i++) {
            float[] fArr = this.gravity;
            fArr[i] = (fArr[i] * sensor_alpha) + (sensorEvent.values[i] * 0.19999999f);
        }
        calculateGeoDirection();
        float[] fArr2 = this.gravity;
        double d = fArr2[0];
        double d2 = fArr2[1];
        double d3 = fArr2[2];
        double sqrt = Math.sqrt((d * d) + (d2 * d2) + (d3 * d3));
        this.has_pitch_angle = false;
        if (sqrt>1.0E-8d) {
            this.has_pitch_angle = true;
            this.pitch_angle = (Math.asin((-d3) / sqrt) * 180.0d) / 3.141592653589793d;
            this.has_level_angle = true;
            double atan2 = (Math.atan2(-d, d2) * 180.0d) / 3.141592653589793d;
            this.natural_level_angle = atan2;
            if (atan2<-0.0d) {
                this.natural_level_angle = atan2 + 360.0d;
            }
            updateLevelAngles();
            return;
        }
        Log.e(TAG, "accel sensor has zero mag: " + sqrt);
        this.has_level_angle = false;
    }

    public void updateLevelAngles() {
        if (this.has_level_angle) {
            this.level_angle = this.natural_level_angle;
            double calibratedLevelAngle = this.level_angle - this.applicationInterface.getCalibratedLevelAngle();
            this.orig_level_angle = calibratedLevelAngle;
            double d = calibratedLevelAngle - this.current_orientation;
            this.level_angle = d;
            if (d<-180.0d) {
                this.level_angle = d + 360.0d;
            } else if (d>180.0d) {
                this.level_angle = d - 360.0d;
            }
        }
    }

    public boolean hasLevelAngle() {
        return this.has_level_angle;
    }

    public boolean hasLevelAngleStable() {
        if (this.is_test || !this.has_pitch_angle || Math.abs(this.pitch_angle)<=70.0d) {
            return this.has_level_angle;
        }
        return false;
    }

    public double getLevelAngleUncalibrated() {
        return this.natural_level_angle - this.current_orientation;
    }

    public double getLevelAngle() {
        return this.level_angle;
    }

    public double getOrigLevelAngle() {
        return this.orig_level_angle;
    }

    public boolean hasPitchAngle() {
        return this.has_pitch_angle;
    }

    public double getPitchAngle() {
        return this.pitch_angle;
    }

    public void onMagneticSensorChanged(SensorEvent sensorEvent) {
        this.has_geomagnetic = true;
        for (int i = 0; i<3; i++) {
            float[] fArr = this.geomagnetic;
            fArr[i] = (fArr[i] * sensor_alpha) + (sensorEvent.values[i] * 0.19999999f);
        }
        calculateGeoDirection();
    }

    private void calculateGeoDirection() {
        if (this.has_gravity && this.has_geomagnetic && SensorManager.getRotationMatrix(this.deviceRotation, this.deviceInclination, this.gravity, this.geomagnetic)) {
            SensorManager.remapCoordinateSystem(this.deviceRotation, 1, 3, this.cameraRotation);
            boolean z = this.has_geo_direction;
            this.has_geo_direction = true;
            SensorManager.getOrientation(this.cameraRotation, this.new_geo_direction);
            for (int i = 0; i<3; i++) {
                float degrees = (float) Math.toDegrees(this.geo_direction[i]);
                float degrees2 = (float) Math.toDegrees(this.new_geo_direction[i]);
                if (z) {
                    degrees2 = lowPassFilter(degrees, degrees2, 0.1f, 10.0f);
                }
                this.geo_direction[i] = (float) Math.toRadians(degrees2);
            }
        }
    }

    private float lowPassFilter(float f, float f2, float f3, float f4) {
        float f5 = f2 - f;
        float abs = Math.abs(f5);
        if (abs<180.0f) {
            return abs>f4 ? f2 : f + (f3 * f5);
        } else if (360.0f - abs>f4) {
            return f2;
        } else {
            return ((f>f2 ? f + (f3 * (((f2 + 360.0f) - f) % 360.0f)) : f - (f3 * (((360.0f - f2) + f) % 360.0f))) + 360.0f) % 360.0f;
        }
    }

    public boolean hasGeoDirection() {
        return this.has_geo_direction;
    }

    public double getGeoDirection() {
        return this.geo_direction[0];
    }

    public boolean supportsFaceDetection() {
        return this.supports_face_detection;
    }

    public boolean supportsOpticalStabilization() {
        Log.d(TAG, "supportsOpticalStabilization");
        return this.supports_optical_stabilization;
    }

    public boolean getOpticalStabilization() {
        Log.d(TAG, "getOpticalStabilization");
        CameraController cameraController = this.camera_controller;
        if (cameraController == null) {
            Log.d(TAG, "camera not opened!");
            return false;
        }
        return cameraController.getOpticalStabilization();
    }

    public boolean supportsVideoStabilization() {
        Log.d(TAG, "supportsVideoStabilization");
        return this.supports_video_stabilization;
    }

    public boolean getVideoStabilization() {
        Log.d(TAG, "getVideoStabilization");
        CameraController cameraController = this.camera_controller;
        if (cameraController == null) {
            Log.d(TAG, "camera not opened!");
            return false;
        }
        return cameraController.getVideoStabilization();
    }

    public boolean supportsPhotoVideoRecording() {
        return this.supports_photo_video_recording && !this.video_high_speed;
    }

    public boolean isVideoHighSpeed() {
        Log.d(TAG, "isVideoHighSpeed");
        return this.is_video && this.video_high_speed;
    }

    public boolean canDisableShutterSound() {
        Log.d(TAG, "canDisableShutterSound");
        return this.can_disable_shutter_sound;
    }

    public int getTonemapMaxCurvePoints() {
        Log.d(TAG, "getTonemapMaxCurvePoints");
        return this.tonemap_max_curve_points;
    }

    public boolean supportsTonemapCurve() {
        Log.d(TAG, "supportsTonemapCurve");
        return this.supports_tonemap_curve;
    }

    public float[] getSupportedApertures() {
        Log.d(TAG, "getSupportedApertures");
        return this.supported_apertures;
    }

    public List<String> getSupportedColorEffects() {
        Log.d(TAG, "getSupportedColorEffects");
        return this.color_effects;
    }

    public List<String> getSupportedSceneModes() {
        Log.d(TAG, "getSupportedSceneModes");
        return this.scene_modes;
    }

    public List<String> getSupportedWhiteBalances() {
        Log.d(TAG, "getSupportedWhiteBalances");
        return this.white_balances;
    }

    public List<String> getSupportedAntiBanding() {
        Log.d(TAG, "getSupportedAntiBanding");
        return this.antibanding;
    }

    public List<String> getSupportedEdgeModes() {
        Log.d(TAG, "getSupportedEdgeModes");
        return this.edge_modes;
    }

    public List<String> getSupportedNoiseReductionModes() {
        Log.d(TAG, "getSupportedNoiseReductionModes");
        return this.noise_reduction_modes;
    }

    public String getISOKey() {
        Log.d(TAG, "getISOKey");
        CameraController cameraController = this.camera_controller;
        return cameraController == null ? "" : cameraController.getISOKey();
    }

    public boolean supportsWhiteBalanceTemperature() {
        Log.d(TAG, "supportsWhiteBalanceTemperature");
        return this.supports_white_balance_temperature;
    }

    public int getMinimumWhiteBalanceTemperature() {
        Log.d(TAG, "getMinimumWhiteBalanceTemperature");
        return this.min_temperature;
    }

    public int getMaximumWhiteBalanceTemperature() {
        Log.d(TAG, "getMaximumWhiteBalanceTemperature");
        return this.max_temperature;
    }

    public boolean supportsISORange() {
        Log.d(TAG, "supportsISORange");
        return this.supports_iso_range;
    }

    public List<String> getSupportedISOs() {
        Log.d(TAG, "getSupportedISOs");
        return this.isos;
    }

    public int getMinimumISO() {
        Log.d(TAG, "getMinimumISO");
        return this.min_iso;
    }

    public int getMaximumISO() {
        Log.d(TAG, "getMaximumISO");
        return this.max_iso;
    }

    public float getMinimumFocusDistance() {
        return this.minimum_focus_distance;
    }

    public boolean supportsExposureTime() {
        return this.supports_exposure_time;
    }

    public long getMinimumExposureTime() {
        Log.d(TAG, "getMinimumExposureTime: " + this.min_exposure_time);
        return this.min_exposure_time;
    }

    public long getMaximumExposureTime() {
        Log.d(TAG, "getMaximumExposureTime: " + this.max_exposure_time);
        long j = this.max_exposure_time;
        if (this.applicationInterface.isExpoBracketingPref() || this.applicationInterface.isFocusBracketingPref() || this.applicationInterface.isCameraBurstPref()) {
            if (this.applicationInterface.getBurstForNoiseReduction()) {
                j = Math.min(this.max_exposure_time, 2000000000L);
            } else {
                j = Math.min(this.max_exposure_time, 500000000L);
            }
        }
        Log.d(TAG, "max: " + j);
        return j;
    }

    public boolean supportsExposures() {
        Log.d(TAG, "supportsExposures");
        return this.exposures != null;
    }

    public int getMinimumExposure() {
        Log.d(TAG, "getMinimumExposure");
        return this.min_exposure;
    }

    public int getMaximumExposure() {
        Log.d(TAG, "getMaximumExposure");
        return this.max_exposure;
    }

    public int getCurrentExposure() {
        Log.d(TAG, "getCurrentExposure");
        CameraController cameraController = this.camera_controller;
        if (cameraController == null) {
            return 0;
        }
        return cameraController.getExposureCompensation();
    }

    public boolean supportsExpoBracketing() {
        return this.supports_expo_bracketing;
    }

    public int maxExpoBracketingNImages() {
        Log.d(TAG, "maxExpoBracketingNImages");
        return this.max_expo_bracketing_n_images;
    }

    public boolean supportsFocusBracketing() {
        return this.supports_focus_bracketing;
    }

    public boolean supportsBurst() {
        return this.supports_burst;
    }

    public boolean supportsRaw() {
        return this.supports_raw;
    }

    public float getViewAngleX(boolean z) {
        Log.d(TAG, "getViewAngleX: " + z);
        CameraController.Size currentPreviewSize = z ? getCurrentPreviewSize() : getCurrentPictureSize();
        if (currentPreviewSize == null) {
            Log.e(TAG, "can't find view angle x size");
            return this.view_angle_x;
        }
        float f = this.view_angle_x / this.view_angle_y;
        float f2 = currentPreviewSize.width / currentPreviewSize.height;
        if (Math.abs(f2 - f)<1.0E-5f) {
            return this.view_angle_x;
        }
        if (f2>f) {
            return this.view_angle_x;
        }
        return (float) Math.toDegrees(Math.atan((f2 / f) * Math.tan(Math.toRadians(this.view_angle_x) / 2.0d)) * 2.0d);
    }

    public float getViewAngleY(boolean z) {
        Log.d(TAG, " " + z);
        CameraController.Size currentPreviewSize = z ? getCurrentPreviewSize() : getCurrentPictureSize();
        if (currentPreviewSize == null) {
            Log.e(TAG, "can't find view angle y size");
            return this.view_angle_y;
        }
        float f = this.view_angle_x / this.view_angle_y;
        float f2 = currentPreviewSize.width / currentPreviewSize.height;
        if (Math.abs(f2 - f)<1.0E-5f) {
            return this.view_angle_y;
        }
        if (f2>f) {
            return (float) Math.toDegrees(Math.atan((f / f2) * Math.tan(Math.toRadians(this.view_angle_y) / 2.0d)) * 2.0d);
        }
        return this.view_angle_y;
    }

    public List<CameraController.Size> getSupportedPreviewSizes() {
        Log.d(TAG, "getSupportedPreviewSizes");
        return this.supported_preview_sizes;
    }

    public CameraController.Size getCurrentPreviewSize() {
        return new CameraController.Size(this.preview_w, this.preview_h);
    }

    public double getCurrentPreviewAspectRatio() {
        return ((double) this.preview_w) / ((double) this.preview_h);
    }


    public List<CameraController.Size> getSupportedPictureSizes(boolean z) {
        Log.d(TAG, "getSupportedPictureSizes");
        CameraController cameraController = this.camera_controller;
        boolean z2 = true;
        boolean z3 = cameraController != null && cameraController.isBurstOrExpo();
        ApplicationInterface.CameraResolutionConstraints cameraResolutionConstraints = this.photo_size_constraints;
        z2 = (cameraResolutionConstraints == null || !cameraResolutionConstraints.hasConstraints()) ? false : false;
        if (z && (z3 || z2)) {
            Log.d(TAG, "need to filter picture sizes for burst mode and/or constraints");
            ArrayList arrayList = new ArrayList();
            for (CameraController.Size size : this.photo_sizes) {
                if (!z3 || size.supports_burst) {
                    if (this.photo_size_constraints.satisfies(size)) {
                        arrayList.add(size);
                    }
                }
            }
            return arrayList;
        }
        return this.photo_sizes;
    }

    public CameraController.Size getCurrentPictureSize() {
        List<CameraController.Size> list;
        int i = this.current_size_index;
        if (i == -1 || (list = this.photo_sizes) == null) {
            return null;
        }
        return list.get(i);
    }

    public VideoQualityHandler getVideoQualityHander() {
        return this.video_quality_handler;
    }

    public List<String> getSupportedVideoQuality(String str) {
        Log.d(TAG, "getSupportedVideoQuality: " + str);
        if (!str.equals("default") && this.supports_video_high_speed) {
            try {
                int parseInt = Integer.parseInt(str);
                Log.d(TAG, "fps: " + parseInt);
                ArrayList arrayList = new ArrayList();
                for (String str2 : this.video_quality_handler.getSupportedVideoQuality()) {
                    Log.d(TAG, "quality: " + str2);
                    CamcorderProfile camcorderProfile = getCamcorderProfile(str2);
                    Log.d(TAG, "    width: " + camcorderProfile.videoFrameWidth);
                    Log.d(TAG, "    height: " + camcorderProfile.videoFrameHeight);
                    if (this.video_quality_handler.findVideoSizeForFrameRate(camcorderProfile.videoFrameWidth, camcorderProfile.videoFrameHeight, parseInt) != null) {
                        Log.d(TAG, "    requested frame rate is supported");
                        arrayList.add(str2);
                    } else {
                        Log.d(TAG, "    requested frame rate is NOT supported");
                    }
                }
                return arrayList;
            } catch (NumberFormatException unused) {
                Log.d(TAG, "fps invalid format, can't parse to int: " + str);
            }
        }
        return this.video_quality_handler.getSupportedVideoQuality();
    }

    public boolean fpsIsHighSpeed(String str) {
        Log.d(TAG, "fpsIsHighSpeed: " + str);
        if (!str.equals("default") && this.supports_video_high_speed) {
            try {
                int parseInt = Integer.parseInt(str);
                Log.d(TAG, "fps: " + parseInt);
                if (this.video_quality_handler.videoSupportsFrameRate(parseInt)) {
                    Log.d(TAG, "fps is normal");
                    return false;
                } else if (this.video_quality_handler.videoSupportsFrameRateHighSpeed(parseInt)) {
                    Log.d(TAG, "fps is high speed");
                    return true;
                } else {
                    Log.e(TAG, "fps is neither normal nor high speed");
                    return false;
                }
            } catch (NumberFormatException unused) {
                Log.d(TAG, "fps invalid format, can't parse to int: " + str);
            }
        }
        Log.d(TAG, "fps is not high speed");
        return false;
    }

    public boolean supportsVideoHighSpeed() {
        return this.supports_video_high_speed;
    }

    public List<String> getSupportedFlashValues() {
        return this.supported_flash_values;
    }

    public List<String> getSupportedFocusValues() {
        return this.supported_focus_values;
    }

    public int getCameraId() {
        CameraController cameraController = this.camera_controller;
        if (cameraController == null) {
            return 0;
        }
        return cameraController.getCameraId();
    }

    public String getCameraAPI() {
        CameraController cameraController = this.camera_controller;
        return cameraController == null ? "None" : cameraController.getAPI();
    }

    public void onResume() {
        this.mSP = new SP(getContext());
        Log.d(TAG, "onResume");
        recreatePreviewBitmap();
        this.app_is_paused = false;
        this.is_paused = false;
        this.cameraSurface.onResume();
        if (this.canvasView != null) {
            this.canvasView.onResume();
        }
        if (this.camera_open_state == CameraOpenState.CAMERAOPENSTATE_CLOSING) {
            Log.d(TAG, "camera still closing");
            CloseCameraTask closeCameraTask = this.close_camera_task;
            if (closeCameraTask != null) {
                closeCameraTask.reopen = true;
                return;
            } else {
                Log.e(TAG, "onResume: state is CAMERAOPENSTATE_CLOSING, but close_camera_task is null");
                return;
            }
        }
        openCamera();
    }

    public void onPause() {
        onPause(true);
    }

    public void onPause(boolean z) {
        Log.d(TAG, "onPause");
        this.is_paused = true;
        if (z) {
            this.app_is_paused = true;
        }
        if (this.camera_open_state == CameraOpenState.CAMERAOPENSTATE_OPENING) {
            Log.d(TAG, "cancel open_camera_task");
            AsyncTask<Void, Void, CameraController> asyncTask = this.open_camera_task;
            if (asyncTask != null) {
                asyncTask.cancel(true);
            } else {
                Log.e(TAG, "onPause: state is CAMERAOPENSTATE_OPENING, but open_camera_task is null");
            }
        }
        closeCamera(true, null);
        this.cameraSurface.onPause();
        CanvasView canvasView = this.canvasView;
        if (canvasView != null) {
            canvasView.onPause();
        }
        freePreviewBitmap();
    }

    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        if (refreshPreviewBitmapTaskIsRunning()) {
            try {
                this.refreshPreviewBitmapTask.get();
            } catch (InterruptedException | ExecutionException e) {
                Log.e(TAG, "exception while waiting for background_task to finish");
                e.printStackTrace();
            }
        }
        freePreviewBitmap();
        RenderScript renderScript = this.rs;
        if (renderScript != null) {
            try {
                renderScript.destroy();
            } catch (RSInvalidStateException e2) {
                e2.printStackTrace();
            }
            this.rs = null;
        }
        if (this.camera_open_state == CameraOpenState.CAMERAOPENSTATE_CLOSING) {
            Log.d(TAG, "wait for close_camera_task");
            if (this.close_camera_task != null) {
                long currentTimeMillis = System.currentTimeMillis();
                try {
                    this.close_camera_task.get(3000L, TimeUnit.MILLISECONDS);
                } catch (InterruptedException | ExecutionException | TimeoutException e3) {
                    Log.e(TAG, "exception while waiting for close_camera_task to finish");
                    e3.printStackTrace();
                }
                Log.d(TAG, "done waiting for close_camera_task");
                Log.d(TAG, "### time after waiting for close_camera_task: " + (System.currentTimeMillis() - currentTimeMillis));
                return;
            }
            Log.e(TAG, "onResume: state is CAMERAOPENSTATE_CLOSING, but close_camera_task is null");
        }
    }

    public void onSaveInstanceState(Bundle bundle) {
        Log.d(TAG, "onSaveInstanceState");
    }

    private class RotatedTextView extends View {
        private final Rect bounds;
        private String[] lines;
        private int offset_y;
        private final Paint paint;
        private final RectF rect;
        private final boolean style_outline;
        private final Rect sub_bounds;

        RotatedTextView(String str, int i, boolean z, Context context) {
            super(context);
            Paint paint = new Paint(1);
            this.paint = paint;
            this.bounds = new Rect();
            this.sub_bounds = new Rect();
            this.rect = new RectF();
            this.lines = str.split("\n");
            this.offset_y = i;
            this.style_outline = z;
            if (z) {
                paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            }
        }

        void setText(String str) {
            this.lines = str.split("\n");
        }

        void setOffsetY(int i) {
            this.offset_y = i;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            String[] strArr;
            float f = Preview.this.getResources().getDisplayMetrics().density;
            float f2 = (14.0f * f) + 0.5f;
            this.paint.setTextSize(f2);
            if (!this.style_outline) {
                this.paint.setShadowLayer(1.0f, 0.0f, 1.0f, -16777216);
            }
            boolean z = true;
            for (String str : this.lines) {
                this.paint.getTextBounds(str, 0, str.length(), this.sub_bounds);
                if (z) {
                    this.bounds.set(this.sub_bounds);
                    z = false;
                } else {
                    this.bounds.top = Math.min(this.sub_bounds.top, this.bounds.top);
                    this.bounds.bottom = Math.max(this.sub_bounds.bottom, this.bounds.bottom);
                    this.bounds.left = Math.min(this.sub_bounds.left, this.bounds.left);
                    this.bounds.right = Math.max(this.sub_bounds.right, this.bounds.right);
                }
            }
            this.paint.getTextBounds("Ap", 0, 2, this.sub_bounds);
            this.bounds.top = this.sub_bounds.top;
            this.bounds.bottom = this.sub_bounds.bottom;
            int i = this.bounds.bottom - this.bounds.top;
            this.bounds.bottom += ((this.lines.length - 1) * i) / 2;
            this.bounds.top -= ((this.lines.length - 1) * i) / 2;
            canvas.save();
            canvas.rotate(Preview.this.ui_rotation, canvas.getWidth() / 2.0f, canvas.getHeight() / 2.0f);
            float f3 = (int) f2;
            this.rect.left = (((canvas.getWidth() / 2.0f) - (this.bounds.width() / 2.0f)) + this.bounds.left) - f3;
            this.rect.top = (((canvas.getHeight() / 2.0f) + this.bounds.top) - f3) + this.offset_y;
            this.rect.right = ((canvas.getWidth() / 2.0f) - (this.bounds.width() / 2.0f)) + this.bounds.right + f3;
            this.rect.bottom = (canvas.getHeight() / 2.0f) + this.bounds.bottom + f3 + this.offset_y;
            this.paint.setStyle(Paint.Style.FILL);
            if (!this.style_outline) {
                this.paint.setColor(Color.rgb(50, 50, 50));
                float f4 = (f * 24.0f) + 0.5f;
                canvas.drawRoundRect(this.rect, f4, f4, this.paint);
            }
            this.paint.setColor(-1);
            int height = (canvas.getHeight() / 2) + this.offset_y;
            String[] strArr2 = this.lines;
            int length = height - (((strArr2.length - 1) * i) / 2);
            for (String str2 : strArr2) {
                float f5 = length;
                canvas.drawText(str2, (canvas.getWidth() / 2.0f) - (this.bounds.width() / 2.0f), f5, this.paint);
                if (this.style_outline) {
                    int color = this.paint.getColor();
                    this.paint.setColor(-16777216);
                    this.paint.setStyle(Paint.Style.STROKE);
                    this.paint.setStrokeWidth(1.0f);
                    canvas.drawText(str2, (canvas.getWidth() / 2.0f) - (this.bounds.width() / 2.0f), f5, this.paint);
                    this.paint.setStyle(Paint.Style.FILL);
                    this.paint.setColor(color);
                }
                length += i;
            }
            canvas.restore();
        }
    }

    public void clearActiveFakeToast() {
        clearActiveFakeToast(false);
    }

    public void clearActiveFakeToast(boolean z) {
        if (!z) {
            this.fake_toast_handler.removeCallbacksAndMessages(null);
        }
        ((Activity) getContext()).runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (Preview.this.active_fake_toast != null) {
                    Log.d(Preview.TAG, "remove fake toast: " + Preview.this.active_fake_toast);
                    ViewParent parent = Preview.this.active_fake_toast.getParent();
                    if (parent != null) {
                        ((ViewGroup) parent).removeView(Preview.this.active_fake_toast);
                    }
                    Preview.this.active_fake_toast = null;
                }
            }
        });
    }

    public void showToast(ToastBoxer toastBoxer, int i) {
        showToast(toastBoxer, getResources().getString(i), false);
    }

    public void showToast(ToastBoxer toastBoxer, String str) {
        showToast(toastBoxer, str, false);
    }

    public void showToast(String str, boolean z) {
        showToast((ToastBoxer) null, str, z);
    }

    public void showToast(ToastBoxer toastBoxer, String str, boolean z) {
        showToast(toastBoxer, str, 32, z);
    }

    public void showToast(String str, int i, boolean z) {
        showToast(null, str, i, z);
    }

    private void showToast(final ToastBoxer toastBoxer, final String str, final int i, final boolean z) {
        if (this.applicationInterface.getShowToastsPref()) {
            Log.d(TAG, "showToast: " + str);
            if (this.app_is_paused) {
                Log.e(TAG, "don't show toast as application is paused: " + str);
                return;
            }
            final Activity activity = (Activity) getContext();
            activity.runOnUiThread(new Runnable() {
                @SuppressLint("ResourceType")
                @Override
                public void run() {
                    Toast toast;
                    if (Preview.this.app_is_paused) {
                        Log.e(Preview.TAG, "don't show toast as application is paused: " + str);
                        return;
                    }
                    int i2 = (int) ((i * Preview.this.getResources().getDisplayMetrics().density) + 0.5f);
                    if (z) {
                        if (Preview.this.active_fake_toast != null) {
                            Log.d(Preview.TAG, "re-use fake toast: " + Preview.this.active_fake_toast);
                            Preview.this.active_fake_toast.setText(str);
                            Preview.this.active_fake_toast.setOffsetY(i2);
                            Preview.this.active_fake_toast.invalidate();
                        } else {
                            Preview.this.active_fake_toast = new RotatedTextView(str, i2, true, activity);
                            Log.d(Preview.TAG, "create new fake toast: " + Preview.this.active_fake_toast);
                            ((FrameLayout) ((Activity) Preview.this.getContext()).findViewById(16908290)).addView(Preview.this.active_fake_toast);
                        }
                        Preview.this.fake_toast_handler.removeCallbacksAndMessages(null);
                        Preview.this.fake_toast_handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Log.d(Preview.TAG, "destroy fake toast due to time expired");
                                Preview.this.clearActiveFakeToast(true);
                            }
                        }, 2000L);
                        return;
                    }
                    Log.d(Preview.TAG, "clear_toast: " + toastBoxer);
                    if (toastBoxer != null) {
                        Log.d(Preview.TAG, "clear_toast.toast: " + toastBoxer.toast);
                    }
                    Log.d(Preview.TAG, "last_toast: " + Preview.this.last_toast);
                    Log.d(Preview.TAG, "last_toast_time_ms: " + Preview.this.last_toast_time_ms);
                    long currentTimeMillis = System.currentTimeMillis();
                    ToastBoxer toastBoxer2 = toastBoxer;
                    if (toastBoxer2 != null && toastBoxer2.toast != null && toastBoxer.toast == Preview.this.last_toast && currentTimeMillis<Preview.this.last_toast_time_ms + 2000) {
                        Log.d(Preview.TAG, "reuse last toast: " + Preview.this.last_toast);
                        toast = toastBoxer.toast;
                        RotatedTextView rotatedTextView = (RotatedTextView) toast.getView();
                        rotatedTextView.setText(str);
                        rotatedTextView.setOffsetY(i2);
                        rotatedTextView.invalidate();
                        toast.setView(rotatedTextView);
                    } else {
                        ToastBoxer toastBoxer3 = toastBoxer;
                        if (toastBoxer3 != null && toastBoxer3.toast != null) {
                            Log.d(Preview.TAG, "cancel last toast: " + toastBoxer.toast);
                            toastBoxer.toast.cancel();
                        }
                        toast = new Toast(activity);
                        Log.d(Preview.TAG, "created new toast: " + toast);
                        ToastBoxer toastBoxer4 = toastBoxer;
                        if (toastBoxer4 != null) {
                            toastBoxer4.toast = toast;
                        }
                        toast.setView(new RotatedTextView(str, i2, false, activity));
                        Preview.this.last_toast_time_ms = currentTimeMillis;
                    }
                    toast.setDuration(Toast.LENGTH_SHORT);
                    if (!((Activity) Preview.this.getContext()).isFinishing()) {
                        toast.show();
                    }
                    Preview.this.last_toast = toast;
                }
            });
        }
    }

    public void setUIRotation(int i) {
        Log.d(TAG, "setUIRotation");
        this.ui_rotation = i;
    }

    public int getUIRotation() {
        return this.ui_rotation;
    }

    private void updateParametersFromLocation() {
        Log.d(TAG, "updateParametersFromLocation");
        if (this.camera_controller != null) {
            boolean geotaggingPref = this.applicationInterface.getGeotaggingPref();
            Log.e(":::storelocation:::", "updateParametersFromLocation: " + this.applicationInterface.getLocation());
            if (geotaggingPref && this.applicationInterface.getLocation() != null) {
                Location location = this.applicationInterface.getLocation();
                Log.d(TAG, "updating parameters from location...");
                this.camera_controller.setLocationInfo(location);
                return;
            }
            Log.e(":::storelocation:::", "noneeee: ");
            this.camera_controller.removeLocationInfo();
        }
    }

    public void enablePreviewBitmap() {
        Log.d(TAG, "enablePreviewBitmap");
        if (this.cameraSurface instanceof TextureView) {
            this.want_preview_bitmap = true;
            recreatePreviewBitmap();
        }
    }

    public void disablePreviewBitmap() {
        Log.d(TAG, "disablePreviewBitmap");
        freePreviewBitmap();
        this.want_preview_bitmap = false;
        this.histogramScript = null;
    }

    public boolean isPreviewBitmapEnabled() {
        return this.want_preview_bitmap;
    }

    public boolean refreshPreviewBitmapTaskIsRunning() {
        return this.refreshPreviewBitmapTask != null;
    }

    private void recycleBitmapForPreviewTask(final Bitmap bitmap) {
        Log.d(TAG, "recycleBitmapForPreviewTask");
        if (!refreshPreviewBitmapTaskIsRunning()) {
            Log.d(TAG, "refreshPreviewBitmapTask not running, can recycle bitmap");
            bitmap.recycle();
            return;
        }
        Log.d(TAG, "refreshPreviewBitmapTask still running, wait before recycle bitmap");
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() { // from class: com.live.gpsmap.camera.Camera.preview.Preview.23
            @Override // java.lang.Runnable
            public void run() {
                if (!Preview.this.refreshPreviewBitmapTaskIsRunning()) {
                    Log.d(Preview.TAG, "refreshPreviewBitmapTask not running now, can recycle bitmap");
                    bitmap.recycle();
                    return;
                }
                Log.d(Preview.TAG, "refreshPreviewBitmapTask still running, wait again before recycle bitmap");
                handler.postDelayed(this, 500L);
            }
        }, 500L);
    }

    private void freePreviewBitmap() {
        cancelRefreshPreviewBitmap();
        this.histogram = null;
        Bitmap bitmap = this.preview_bitmap;
        if (bitmap != null) {
            recycleBitmapForPreviewTask(bitmap);
            this.preview_bitmap = null;
        }
        freeZebraStripesBitmap();
        freeFocusPeakingBitmap();
    }

    private void recreatePreviewBitmap() {
        Log.d(TAG, "recreatePreviewBitmap");
        freePreviewBitmap();
        if (this.want_preview_bitmap) {
            int i = this.textureview_w / 4;
            int i2 = this.textureview_h / 4;
            int displayRotationDegrees = getDisplayRotationDegrees();
            if (displayRotationDegrees == 90 || displayRotationDegrees == 270) {
                i2 = i;
                i = i2;
            }
            Log.d(TAG, "bitmap_width: " + i);
            Log.d(TAG, "bitmap_height: " + i2);
            Log.d(TAG, "rotation: " + displayRotationDegrees);
            try {
                this.preview_bitmap = Bitmap.createBitmap(i, i2, Bitmap.Config.ARGB_8888);
            } catch (IllegalArgumentException e) {
                Log.e(TAG, "failed to create preview_bitmap");
                e.printStackTrace();
            }
            createZebraStripesBitmap();
            createFocusPeakingBitmap();
        }
    }

    private void freeZebraStripesBitmap() {
        Log.d(TAG, "freeZebraStripesBitmap");
        Bitmap bitmap = this.zebra_stripes_bitmap_buffer;
        if (bitmap != null) {
            recycleBitmapForPreviewTask(bitmap);
            this.zebra_stripes_bitmap_buffer = null;
        }
        Bitmap bitmap2 = this.zebra_stripes_bitmap;
        if (bitmap2 != null) {
            bitmap2.recycle();
            this.zebra_stripes_bitmap = null;
        }
    }

    private void createZebraStripesBitmap() {
        Log.d("Preview", "createZebraStripesBitmap");
        if (this.want_zebra_stripes) {
            Bitmap bitmap0 = this.preview_bitmap;
            if (bitmap0 != null) {
                try {
                    this.zebra_stripes_bitmap_buffer = Bitmap.createBitmap(bitmap0.getWidth(), this.preview_bitmap.getHeight(), Bitmap.Config.ARGB_8888);
                } catch (IllegalArgumentException illegalArgumentException0) {
                    Log.e("Preview", "failed to create zebra_stripes_bitmap_buffer");
                    illegalArgumentException0.printStackTrace();
                }

                return;
            }
        }
    }


//    private void createZebraStripesBitmap() {
//        Bitmap bitmap;
//        Log.d(TAG, "createZebraStripesBitmap");
//        if (!this.want_zebra_stripes || (bitmap = this.preview_bitmap) == null) {
//            return;
//        }
//        try {
//            this.zebra_stripes_bitmap_buffer = Bitmap.createBitmap(bitmap.getWidth(), this.preview_bitmap.getHeight(), Bitmap.Config.ARGB_8888);
//        } catch (IllegalArgumentException e) {
//            Log.e(TAG, "failed to create zebra_stripes_bitmap_buffer");
//            e.printStackTrace();
//        }
//    }

    private void freeFocusPeakingBitmap() {
        Log.d(TAG, "freeFocusPeakingBitmap");
        Bitmap bitmap = this.focus_peaking_bitmap_buffer;
        if (bitmap != null) {
            recycleBitmapForPreviewTask(bitmap);
            this.focus_peaking_bitmap_buffer = null;
        }
        Bitmap bitmap2 = this.focus_peaking_bitmap;
        if (bitmap2 != null) {
            bitmap2.recycle();
            this.focus_peaking_bitmap = null;
        }
    }

    private void createFocusPeakingBitmap() {
        Log.d(TAG, "createFocusPeakingBitmap");
        boolean z = this.want_focus_peaking;
        Bitmap bitmap = this.preview_bitmap;
        if (z && (bitmap != null)) {
            try {
                this.focus_peaking_bitmap_buffer = Bitmap.createBitmap(bitmap.getWidth(), this.preview_bitmap.getHeight(), Bitmap.Config.ARGB_8888);
            } catch (IllegalArgumentException e) {
                Log.e(TAG, "failed to create focus_peaking_bitmap_buffer");
                e.printStackTrace();
            }
        }
    }

    public void enableHistogram(HistogramType histogramType) {
        this.want_histogram = true;
        this.histogram_type = histogramType;
    }

    public void disableHistogram() {
        this.want_histogram = false;
    }

    public int[] getHistogram() {
        return this.histogram;
    }

    public void enableZebraStripes(int i, int i2, int i3) {
        this.want_zebra_stripes = true;
        this.zebra_stripes_threshold = i;
        this.zebra_stripes_color_foreground = i2;
        this.zebra_stripes_color_background = i3;
        if (this.zebra_stripes_bitmap_buffer == null) {
            createZebraStripesBitmap();
        }
    }

    public void disableZebraStripes() {
        if (this.want_zebra_stripes) {
            this.want_zebra_stripes = false;
            freeZebraStripesBitmap();
        }
    }

    public Bitmap getZebraStripesBitmap() {
        return this.zebra_stripes_bitmap;
    }

    public void enableFocusPeaking() {
        this.want_focus_peaking = true;
        if (this.focus_peaking_bitmap_buffer == null) {
            createFocusPeakingBitmap();
        }
    }

    public void disableFocusPeaking() {
        if (this.want_focus_peaking) {
            this.want_focus_peaking = false;
            freeFocusPeakingBitmap();
        }
    }

    public Bitmap getFocusPeakingBitmap() {
        return this.focus_peaking_bitmap;
    }


    /* loaded from: classes.dex */
    public static class RefreshPreviewBitmapTaskResult {
        Bitmap new_focus_peaking_bitmap;
        int[] new_histogram;
        Bitmap new_zebra_stripes_bitmap;

        private RefreshPreviewBitmapTaskResult() {
        }
    }


    /* loaded from: classes.dex */
    public static class RefreshPreviewBitmapTask extends AsyncTask<Void, Void, RefreshPreviewBitmapTaskResult> {
        private static final String TAG = "RefreshPreviewBmTask";
        private final WeakReference<Bitmap> focus_peaking_bitmap_bufferReference;
        private final WeakReference<ScriptC_histogram_compute> histogramScriptReference;
        private final WeakReference<Preview> previewReference;
        private final WeakReference<Bitmap> preview_bitmapReference;
        private final boolean update_histogram;
        private final WeakReference<Bitmap> zebra_stripes_bitmap_bufferReference;

        RefreshPreviewBitmapTask(Preview preview, boolean z) {
            this.previewReference = new WeakReference<>(preview);
            this.preview_bitmapReference = new WeakReference<>(preview.preview_bitmap);
            this.zebra_stripes_bitmap_bufferReference = new WeakReference<>(preview.zebra_stripes_bitmap_buffer);
            this.focus_peaking_bitmap_bufferReference = new WeakReference<>(preview.focus_peaking_bitmap_buffer);
            this.update_histogram = z;
            if (preview.rs == null) {
                Log.d(TAG, "create renderscript object");
                preview.rs = RenderScript.create(preview.getContext());
            }
            if (preview.histogramScript == null) {
                Log.d(TAG, "create histogramScript");
                preview.histogramScript = new ScriptC_histogram_compute(preview.rs);
            }
            this.histogramScriptReference = new WeakReference<>(preview.histogramScript);
        }

        private static int[] computeHistogram(Allocation allocation0, RenderScript renderScript0, ScriptC_histogram_compute scriptC_histogram_compute0, HistogramType preview$HistogramType0) {
            int[] arr_v;
            Log.d("RefreshPreviewBmTask", "computeHistogram");
            long v = System.currentTimeMillis();
            if (preview$HistogramType0 == HistogramType.HISTOGRAM_TYPE_RGB) {
                Log.d("RefreshPreviewBmTask", "rgb histogram");
                Allocation allocation1 = Allocation.createSized(renderScript0, Element.I32(renderScript0), 0x100);
                Allocation allocation2 = Allocation.createSized(renderScript0, Element.I32(renderScript0), 0x100);
                Allocation allocation3 = Allocation.createSized(renderScript0, Element.I32(renderScript0), 0x100);
                Log.d("RefreshPreviewBmTask", "bind histogram allocations");
                scriptC_histogram_compute0.bind_histogram_r(allocation1);
                scriptC_histogram_compute0.bind_histogram_g(allocation2);
                scriptC_histogram_compute0.bind_histogram_b(allocation3);
                scriptC_histogram_compute0.invoke_init_histogram_rgb();
                Log.d("RefreshPreviewBmTask", "call histogramScript");
                Log.d("RefreshPreviewBmTask", "time before histogramScript: " + (System.currentTimeMillis() - v));
                scriptC_histogram_compute0.forEach_histogram_compute_rgb(allocation0);
                Log.d("RefreshPreviewBmTask", "time after histogramScript: " + (System.currentTimeMillis() - v));
                arr_v = new int[0x300];
                int[] arr_v1 = new int[0x100];
                allocation1.copyTo(arr_v1);
                int v1 = 0;
                int v2 = 0;
                int v3;
                for (v3 = 0; v2<0x100; ++v3) {
                    arr_v[v3] = arr_v1[v2];
                    ++v2;
                }

                allocation2.copyTo(arr_v1);
                int v4 = 0;
                while (v4<0x100) {
                    arr_v[v3] = arr_v1[v4];
                    ++v4;
                    ++v3;
                }

                allocation3.copyTo(arr_v1);
                while (v1<0x100) {
                    arr_v[v3] = arr_v1[v1];
                    ++v1;
                    ++v3;
                }

                Log.d("RefreshPreviewBmTask", "time after copying histogram data: " + (System.currentTimeMillis() - v));
                allocation1.destroy();
                allocation2.destroy();
                allocation3.destroy();
                Log.d("RefreshPreviewBmTask", "time after destroying allocations: " + (System.currentTimeMillis() - v));
                return arr_v;
            }

            Log.d("RefreshPreviewBmTask", "single channel histogram");
            Allocation allocation4 = Allocation.createSized(renderScript0, Element.I32(renderScript0), 0x100);
            Log.d("RefreshPreviewBmTask", "bind histogram allocation");
            scriptC_histogram_compute0.bind_histogram(allocation4);
            scriptC_histogram_compute0.invoke_init_histogram();
            Log.d("RefreshPreviewBmTask", "call histogramScript");
            Log.d("RefreshPreviewBmTask", "time before histogramScript: " + (System.currentTimeMillis() - v));
            int v5 = AnonymousClass24.$SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$preview$Preview$HistogramType[preview$HistogramType0.ordinal()];
            if (v5 == 1) {
                scriptC_histogram_compute0.forEach_histogram_compute_by_luminance(allocation0);
            } else {
                switch (v5) {
                    case 2: {
                        scriptC_histogram_compute0.forEach_histogram_compute_by_value(allocation0);
                        break;
                    }
                    case 3: {
                        scriptC_histogram_compute0.forEach_histogram_compute_by_intensity(allocation0);
                        break;
                    }
                    case 4: {
                        scriptC_histogram_compute0.forEach_histogram_compute_by_lightness(allocation0);
                    }
                }
            }

            Log.d("RefreshPreviewBmTask", "time after histogramScript: " + (System.currentTimeMillis() - v));
            arr_v = new int[0x100];
            allocation4.copyTo(arr_v);
            Log.d("RefreshPreviewBmTask", "time after copying histogram data: " + (System.currentTimeMillis() - v));
            allocation4.destroy();
            Log.d("RefreshPreviewBmTask", "time after destroying allocations: " + (System.currentTimeMillis() - v));
            return arr_v;
        }
//        private static int[] computeHistogram(Allocation allocation, RenderScript renderScript, ScriptC_histogram_compute scriptC_histogram_compute, HistogramType histogramType) {
//            Log.d(TAG, "computeHistogram");
//            long currentTimeMillis = System.currentTimeMillis();
//            if (histogramType == HistogramType.HISTOGRAM_TYPE_RGB) {
//                Log.d(TAG, "rgb histogram");
//                Allocation createSized = Allocation.createSized(renderScript, Element.I32(renderScript), 256);
//                Allocation createSized2 = Allocation.createSized(renderScript, Element.I32(renderScript), 256);
//                Allocation createSized3 = Allocation.createSized(renderScript, Element.I32(renderScript), 256);
//                Log.d(TAG, "bind histogram allocations");
//                scriptC_histogram_compute.bind_histogram_r(createSized);
//                scriptC_histogram_compute.bind_histogram_g(createSized2);
//                scriptC_histogram_compute.bind_histogram_b(createSized3);
//                scriptC_histogram_compute.invoke_init_histogram_rgb();
//                Log.d(TAG, "call histogramScript");
//                Log.d(TAG, "time before histogramScript: " + (System.currentTimeMillis() - currentTimeMillis));
//                scriptC_histogram_compute.forEach_histogram_compute_rgb(allocation);
//                Log.d(TAG, "time after histogramScript: " + (System.currentTimeMillis() - currentTimeMillis));
//                int[] iArr = new int[768];
//                int[] iArr2 = new int[256];
//                createSized.copyTo(iArr2);
//                int i = 0;
//                int i2 = 0;
//                int i3 = 0;
//                while (i2<256) {
//                    iArr[i3] = iArr2[i2];
//                    i2++;
//                    i3++;
//                }
//                createSized2.copyTo(iArr2);
//                int i4 = 0;
//                while (i4<256) {
//                    iArr[i3] = iArr2[i4];
//                    i4++;
//                    i3++;
//                }
//                createSized3.copyTo(iArr2);
//                while (i<256) {
//                    iArr[i3] = iArr2[i];
//                    i++;
//                    i3++;
//                }
//                Log.d(TAG, "time after copying histogram data: " + (System.currentTimeMillis() - currentTimeMillis));
//                createSized.destroy();
//                createSized2.destroy();
//                createSized3.destroy();
//                Log.d(TAG, "time after destroying allocations: " + (System.currentTimeMillis() - currentTimeMillis));
//                return iArr;
//            }
//            Log.d(TAG, "single channel histogram");
//            Allocation createSized4 = Allocation.createSized(renderScript, Element.I32(renderScript), 256);
//            Log.d(TAG, "bind histogram allocation");
//            scriptC_histogram_compute.bind_histogram(createSized4);
//            scriptC_histogram_compute.invoke_init_histogram();
//            Log.d(TAG, "call histogramScript");
//            Log.d(TAG, "time before histogramScript: " + (System.currentTimeMillis() - currentTimeMillis));
//            int i5 = AnonymousClass24.$SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$preview$Preview$HistogramType[histogramType.ordinal()];
//            if (i5 == 1) {
//                scriptC_histogram_compute.forEach_histogram_compute_by_luminance(allocation);
//            } else if (i5 == 2) {
//                scriptC_histogram_compute.forEach_histogram_compute_by_value(allocation);
//            } else if (i5 == 3) {
//                scriptC_histogram_compute.forEach_histogram_compute_by_intensity(allocation);
//            } else if (i5 == 4) {
//                scriptC_histogram_compute.forEach_histogram_compute_by_lightness(allocation);
//            }
//            Log.d(TAG, "time after histogramScript: " + (System.currentTimeMillis() - currentTimeMillis));
//            int[] iArr3 = new int[256];
//            createSized4.copyTo(iArr3);
//            Log.d(TAG, "time after copying histogram data: " + (System.currentTimeMillis() - currentTimeMillis));
//            createSized4.destroy();
//            Log.d(TAG, "time after destroying allocations: " + (System.currentTimeMillis() - currentTimeMillis));
//            return iArr3;
//        }


        @Override
        public RefreshPreviewBitmapTaskResult doInBackground(Void... voidArr) {
            RefreshPreviewBitmapTaskResult refreshPreviewBitmapTaskResult;
            Log.d(TAG, "doInBackground, async task: " + this);
            long currentTimeMillis = System.currentTimeMillis();
            Preview preview = this.previewReference.get();
            if (preview == null) {
                Log.d(TAG, "preview is null");
                return null;
            }
            ScriptC_histogram_compute scriptC_histogram_compute = this.histogramScriptReference.get();
            if (scriptC_histogram_compute == null) {
                Log.d(TAG, "histogramScript is null");
                return null;
            }
            Bitmap bitmap = this.preview_bitmapReference.get();
            if (bitmap == null) {
                Log.d(TAG, "preview_bitmap is null");
                return null;
            }
            Bitmap bitmap2 = this.zebra_stripes_bitmap_bufferReference.get();
            Bitmap bitmap3 = this.focus_peaking_bitmap_bufferReference.get();
            Activity activity = (Activity) preview.getContext();
            if (activity == null || activity.isFinishing()) {
                Log.d(TAG, "activity is null or finishing");
                return null;
            }
            RefreshPreviewBitmapTaskResult refreshPreviewBitmapTaskResult2 = new RefreshPreviewBitmapTaskResult();
            try {
                Log.d(TAG, "time before getBitmap: " + (System.currentTimeMillis() - currentTimeMillis));
                ((TextureView) preview.cameraSurface).getBitmap(bitmap);
                Log.d(TAG, "time after getBitmap: " + (System.currentTimeMillis() - currentTimeMillis));
                Allocation createFromBitmap = Allocation.createFromBitmap(preview.rs, bitmap);
                Log.d(TAG, "time after createFromBitmap: " + (System.currentTimeMillis() - currentTimeMillis));
                if (this.update_histogram) {
                    Log.d(TAG, "generate histogram");
                    Log.d(TAG, "time before computeHistogram: " + (System.currentTimeMillis() - currentTimeMillis));
                    refreshPreviewBitmapTaskResult2.new_histogram = computeHistogram(createFromBitmap, preview.rs, scriptC_histogram_compute, preview.histogram_type);
                    Log.d(TAG, "time after computeHistogram: " + (System.currentTimeMillis() - currentTimeMillis));
                }
                if (!preview.want_zebra_stripes || bitmap2 == null) {
                    refreshPreviewBitmapTaskResult = refreshPreviewBitmapTaskResult2;
                } else {
                    Log.d(TAG, "generate zebra stripes bitmap");
                    Allocation createFromBitmap2 = Allocation.createFromBitmap(preview.rs, bitmap2);
                    scriptC_histogram_compute.set_zebra_stripes_threshold(preview.zebra_stripes_threshold);
                    scriptC_histogram_compute.set_zebra_stripes_foreground_r(Color.red(preview.zebra_stripes_color_foreground));
                    scriptC_histogram_compute.set_zebra_stripes_foreground_g(Color.green(preview.zebra_stripes_color_foreground));
                    scriptC_histogram_compute.set_zebra_stripes_foreground_b(Color.blue(preview.zebra_stripes_color_foreground));
                    scriptC_histogram_compute.set_zebra_stripes_foreground_a(Color.alpha(preview.zebra_stripes_color_foreground));
                    scriptC_histogram_compute.set_zebra_stripes_background_r(Color.red(preview.zebra_stripes_color_background));
                    scriptC_histogram_compute.set_zebra_stripes_background_g(Color.green(preview.zebra_stripes_color_background));
                    scriptC_histogram_compute.set_zebra_stripes_background_b(Color.blue(preview.zebra_stripes_color_background));
                    scriptC_histogram_compute.set_zebra_stripes_background_a(Color.alpha(preview.zebra_stripes_color_background));
                    scriptC_histogram_compute.set_zebra_stripes_width(bitmap2.getWidth() / 20);
                    Log.d(TAG, "time before histogramScript generate_zebra_stripes: " + (System.currentTimeMillis() - currentTimeMillis));
                    scriptC_histogram_compute.forEach_generate_zebra_stripes(createFromBitmap, createFromBitmap2);
                    Log.d(TAG, "time after histogramScript generate_zebra_stripes: " + (System.currentTimeMillis() - currentTimeMillis));
                    createFromBitmap2.copyTo(bitmap2);
                    createFromBitmap2.destroy();
                    int displayRotationDegrees = preview.getDisplayRotationDegrees();
                    Log.d(TAG, "time before creating new_zebra_stripes_bitmap: " + (System.currentTimeMillis() - currentTimeMillis));
                    Matrix matrix = new Matrix();
                    matrix.postRotate((float) (-displayRotationDegrees));
                    refreshPreviewBitmapTaskResult = refreshPreviewBitmapTaskResult2;
                    try {
                        refreshPreviewBitmapTaskResult.new_zebra_stripes_bitmap = Bitmap.createBitmap(bitmap2, 0, 0, bitmap2.getWidth(), bitmap2.getHeight(), matrix, false);
                        Log.d(TAG, "time after creating new_zebra_stripes_bitmap: " + (System.currentTimeMillis() - currentTimeMillis));
                    } catch (RSInvalidStateException e) {
                        e = e;
                        Log.e(TAG, "renderscript failure");
                        e.printStackTrace();
                        Log.d(TAG, "time taken: " + (System.currentTimeMillis() - currentTimeMillis));
                        return refreshPreviewBitmapTaskResult;
                    } catch (IllegalStateException e2) {
                        Log.e(TAG, "failed to getBitmap");
                        e2.printStackTrace();
                        Log.d(TAG, "time taken: " + (System.currentTimeMillis() - currentTimeMillis));
                        return refreshPreviewBitmapTaskResult;
                    }
                }
                if (preview.want_focus_peaking && bitmap3 != null) {
                    Log.d(TAG, "generate focus peaking bitmap");
                    Allocation createFromBitmap3 = Allocation.createFromBitmap(preview.rs, bitmap3);
                    scriptC_histogram_compute.set_bitmap(createFromBitmap);
                    Log.d(TAG, "time before histogramScript generate_focus_peaking: " + (System.currentTimeMillis() - currentTimeMillis));
                    scriptC_histogram_compute.forEach_generate_focus_peaking(createFromBitmap, createFromBitmap3);
                    Log.d(TAG, "time after histogramScript generate_focus_peaking: " + (System.currentTimeMillis() - currentTimeMillis));
                    Allocation createTyped = Allocation.createTyped(preview.rs, Type.createXY(preview.rs, Element.RGBA_8888(preview.rs), bitmap3.getWidth(), bitmap3.getHeight()));
                    scriptC_histogram_compute.set_bitmap(createFromBitmap3);
                    Log.d(TAG, "time before histogramScript generate_focus_peaking_filtered: " + (System.currentTimeMillis() - currentTimeMillis));
                    scriptC_histogram_compute.forEach_generate_focus_peaking_filtered(createFromBitmap3, createTyped);
                    Log.d(TAG, "time after histogramScript generate_focus_peaking_filtered: " + (System.currentTimeMillis() - currentTimeMillis));
                    createFromBitmap3.destroy();
                    createTyped.copyTo(bitmap3);
                    createTyped.destroy();
                    int displayRotationDegrees2 = preview.getDisplayRotationDegrees();
                    Log.d(TAG, "time before creating new_focus_peaking_bitmap: " + (System.currentTimeMillis() - currentTimeMillis));
                    Matrix matrix2 = new Matrix();
                    matrix2.postRotate((float) (-displayRotationDegrees2));
                    refreshPreviewBitmapTaskResult.new_focus_peaking_bitmap = Bitmap.createBitmap(bitmap3, 0, 0, bitmap3.getWidth(), bitmap3.getHeight(), matrix2, false);
                    Log.d(TAG, "time after creating new_focus_peaking_bitmap: " + (System.currentTimeMillis() - currentTimeMillis));
                }
                createFromBitmap.destroy();
            } catch (RSInvalidStateException e3) {
                refreshPreviewBitmapTaskResult = refreshPreviewBitmapTaskResult2;
            } catch (IllegalStateException e4) {
                refreshPreviewBitmapTaskResult = refreshPreviewBitmapTaskResult2;
            }
            Log.d(TAG, "time taken: " + (System.currentTimeMillis() - currentTimeMillis));
            return refreshPreviewBitmapTaskResult;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(RefreshPreviewBitmapTaskResult refreshPreviewBitmapTaskResult) {
            Activity activity;
            Log.d(TAG, "onPostExecute, async task: " + this);
            Preview preview = this.previewReference.get();
            if (preview == null || (activity = (Activity) preview.getContext()) == null || activity.isFinishing() || refreshPreviewBitmapTaskResult == null) {
                return;
            }
            if (refreshPreviewBitmapTaskResult.new_histogram != null) {
                preview.histogram = refreshPreviewBitmapTaskResult.new_histogram;
            }
            if (preview.zebra_stripes_bitmap != null) {
                preview.zebra_stripes_bitmap.recycle();
            }
            preview.zebra_stripes_bitmap = refreshPreviewBitmapTaskResult.new_zebra_stripes_bitmap;
            if (preview.focus_peaking_bitmap != null) {
                preview.focus_peaking_bitmap.recycle();
            }
            preview.focus_peaking_bitmap = refreshPreviewBitmapTaskResult.new_focus_peaking_bitmap;
            preview.refreshPreviewBitmapTask = null;
            Log.d(TAG, "onPostExecute done, async task: " + this);
        }

        @Override // android.os.AsyncTask
        protected void onCancelled() {
            Log.d(TAG, "onCancelled, async task: " + this);
            Preview preview = this.previewReference.get();
            if (preview == null) {
                return;
            }
            preview.refreshPreviewBitmapTask = null;
        }
    }


    public static class AnonymousClass24 {
        static final int[] $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$preview$Preview$FaceLocation;
        static final int[] $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$preview$Preview$HistogramType;

        static {
            int[] iArr = new int[HistogramType.values().length];
            $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$preview$Preview$HistogramType = iArr;
            try {
                iArr[HistogramType.HISTOGRAM_TYPE_LUMINANCE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$preview$Preview$HistogramType[HistogramType.HISTOGRAM_TYPE_VALUE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$preview$Preview$HistogramType[HistogramType.HISTOGRAM_TYPE_INTENSITY.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$preview$Preview$HistogramType[HistogramType.HISTOGRAM_TYPE_LIGHTNESS.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            int[] iArr2 = new int[FaceLocation.values().length];
            $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$preview$Preview$FaceLocation = iArr2;
            try {
                iArr2[FaceLocation.FACELOCATION_CENTRE.ordinal()] = 1;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$preview$Preview$FaceLocation[FaceLocation.FACELOCATION_LEFT.ordinal()] = 2;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$preview$Preview$FaceLocation[FaceLocation.FACELOCATION_RIGHT.ordinal()] = 3;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$preview$Preview$FaceLocation[FaceLocation.FACELOCATION_TOP.ordinal()] = 4;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$preview$Preview$FaceLocation[FaceLocation.FACELOCATION_BOTTOM.ordinal()] = 5;
            } catch (NoSuchFieldError unused9) {
            }
        }
    }

    private void refreshPreviewBitmap() {
        long j = (this.want_zebra_stripes || this.want_focus_peaking) ? 40L : 200L;
        long currentTimeMillis = System.currentTimeMillis();
        if (!this.want_preview_bitmap || this.preview_bitmap == null || Build.VERSION.SDK_INT<21 || this.is_paused || this.applicationInterface.isPreviewInBackground() || refreshPreviewBitmapTaskIsRunning() || currentTimeMillis<=this.last_preview_bitmap_time_ms + j) {
            return;
        }
        Log.d(TAG, "refreshPreviewBitmap");
        boolean z = this.want_histogram && currentTimeMillis>this.last_histogram_time_ms + 200;
        Log.d(TAG, "update_histogram: " + z);
        Log.d(TAG, "want_histogram: " + this.want_histogram);
        Log.d(TAG, "time_now: " + currentTimeMillis);
        Log.d(TAG, "last_preview_bitmap_time_ms: " + this.last_preview_bitmap_time_ms);
        Log.d(TAG, "last_histogram_time_ms: " + this.last_histogram_time_ms);
        this.last_preview_bitmap_time_ms = currentTimeMillis;
        if (z) {
            this.last_histogram_time_ms = currentTimeMillis;
        }
        RefreshPreviewBitmapTask refreshPreviewBitmapTask = new RefreshPreviewBitmapTask(this, z);
        this.refreshPreviewBitmapTask = refreshPreviewBitmapTask;
        refreshPreviewBitmapTask.execute(new Void[0]);
    }

    private void cancelRefreshPreviewBitmap() {
        Log.d(TAG, "cancelRefreshPreviewBitmap");
        if (refreshPreviewBitmapTaskIsRunning()) {
            this.refreshPreviewBitmapTask.cancel(true);
        }
    }

    public boolean isVideo() {
        return this.is_video;
    }

    public boolean isVideoRecording() {
        return this.video_recorder != null && this.video_start_time_set;
    }

    public boolean isVideoRecordingPaused() {
        return isVideoRecording() && this.video_recorder_is_paused;
    }

    public long getVideoTime() {
        if (isVideoRecordingPaused()) {
            return this.video_accumulated_time;
        }
        return (System.currentTimeMillis() - this.video_start_time) + this.video_accumulated_time;
    }

    public long getVideoAccumulatedTime() {
        return this.video_accumulated_time;
    }

    public int getMaxAmplitude() {
        if (this.video_recorder != null) {
            return this.video_recorder.getMaxAmplitude();
        }
        return 0;
    }


    public long getFrameRate() {
        if (Build.VERSION.SDK_INT>=24) {
            return 16L;
        }
        return isTakingPhoto() ? 500L : 100L;
    }

    public boolean isTakingPhoto() {
        return this.phase == 2;
    }

    public boolean usingCamera2API() {
        return this.using_android_l;
    }

    public CameraController getCameraController() {
        return this.camera_controller;
    }

    public CameraControllerManager getCameraControllerManager() {
        return this.camera_controller_manager;
    }

    public boolean supportsFocus() {
        return this.supported_focus_values != null;
    }

    public boolean supportsFlash() {
        return this.supported_flash_values != null;
    }

    public boolean supportsExposureLock() {
        return this.is_exposure_lock_supported;
    }

    public boolean isExposureLocked() {
        return this.is_exposure_locked;
    }

    public boolean supportsWhiteBalanceLock() {
        return this.is_white_balance_lock_supported;
    }

    public boolean isWhiteBalanceLocked() {
        return this.is_white_balance_locked;
    }

    public boolean supportsZoom() {
        return this.has_zoom;
    }

    public int getMaxZoom() {
        return this.max_zoom_factor;
    }

    public boolean hasFocusArea() {
        return this.has_focus_area;
    }

    public Pair<Integer, Integer> getFocusPos() {
        return new Pair<>(Integer.valueOf(this.focus_screen_x), Integer.valueOf(this.focus_screen_y));
    }

    public int getMaxNumFocusAreas() {
        return this.max_num_focus_areas;
    }

    public boolean isTakingPhotoOrOnTimer() {
        return this.phase == 2 || this.phase == 1;
    }

    public boolean isOnTimer() {
        return this.phase == 1;
    }

    public long getTimerEndTime() {
        return this.take_photo_time;
    }

    public boolean isPreviewPaused() {
        return this.phase == 3;
    }

    public boolean isPreviewStarted() {
        return this.is_preview_started;
    }

    public boolean isFocusWaiting() {
        return this.focus_success == 0;
    }

    public boolean isFocusRecentSuccess() {
        return this.focus_success == 1;
    }

    public long timeSinceStartedAutoFocus() {
        if (this.focus_started_time != -1) {
            return System.currentTimeMillis() - this.focus_started_time;
        }
        return 0L;
    }

    public boolean isFocusRecentFailure() {
        return this.focus_success == 2;
    }

    private boolean recentlyFocused() {
        return this.successfully_focused && System.currentTimeMillis()<this.successfully_focused_time + 5000;
    }

    public CameraController.Face[] getFacesDetected() {
        return this.faces_detected;
    }

    public float getZoomRatio() {
        if (this.zoom_ratios == null) {
            return 1.0f;
        }
        return this.zoom_ratios.get(this.camera_controller.getZoom()).intValue() / 100.0f;
    }
}
