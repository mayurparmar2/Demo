package com.live.gpsmap.camera.Utils.Helper;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.AcknowledgePurchaseResponseListener;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.ProductDetailsResponseListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchaseHistoryRecord;
import com.android.billingclient.api.PurchaseHistoryResponseListener;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchaseHistoryParams;
import com.live.gpsmap.camera.R;

import java.util.ArrayList;
import java.util.List;


public class PurchaseHelper {
    private int billingSetupResponseCode;
    private Context context;
    private BillingClient mBillingClient;
    private boolean mIsServiceConnected;
    private PurchaseHelperListener purchaseHelperListener;

    /* loaded from: classes2.dex */
    public interface PurchaseHelperListener {
        void onProductQueryResponse(List<ProductDetails> list);

        void onPurchasehistoryResponse(List<PurchaseHistoryRecord> list);

        void onPurchasesUpdated(BillingResult billingResult, List<Purchase> list);

        void onServiceConnected(int i);
    }

    public PurchaseHelper(Context context, PurchaseHelperListener purchaseHelperListener) {
        this.context = context;
        this.mBillingClient = BillingClient.newBuilder(context).enablePendingPurchases().setListener(getPurchaseUpdatedListener()).build();
        this.purchaseHelperListener = purchaseHelperListener;
        startConnection(getServiceConnectionRequest());
    }

    private void startConnection(final Runnable runnable) {
        this.mBillingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(BillingResult billingResult) {
                if (billingResult.getResponseCode() == 0) {
                    PurchaseHelper.this.mIsServiceConnected = true;
                    PurchaseHelper.this.billingSetupResponseCode = billingResult.getResponseCode();
                    Runnable runnable2 = runnable;
                    if (runnable2 != null) {
                        runnable2.run();
                    }
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                PurchaseHelper.this.mIsServiceConnected = false;
            }
        });
    }

    public boolean isServiceConnected() {
        return this.mIsServiceConnected;
    }

    public void endConnection() {
        BillingClient billingClient = this.mBillingClient;
        if (billingClient == null || !billingClient.isReady()) {
            return;
        }
        this.mBillingClient.endConnection();
        this.mBillingClient = null;
    }

    private Runnable getServiceConnectionRequest() {
        return new Runnable() {
            @Override
            public void run() {
                if (PurchaseHelper.this.purchaseHelperListener != null) {
                    PurchaseHelper.this.purchaseHelperListener.onServiceConnected(PurchaseHelper.this.billingSetupResponseCode);
                }
            }
        };
    }

    public void getPurchasedItems(final String str) {
        executeServiceRequest(new Runnable() {
            @Override
            public void run() {
                PurchaseHelper.this.mBillingClient.queryPurchaseHistoryAsync(QueryPurchaseHistoryParams.newBuilder().setProductType(str).build(), new PurchaseHistoryResponseListener() {
                    @Override
                    public void onPurchaseHistoryResponse(BillingResult billingResult, List<PurchaseHistoryRecord> list) {
                        if (PurchaseHelper.this.purchaseHelperListener != null) {
                            PurchaseHelper.this.purchaseHelperListener.onPurchasehistoryResponse(list);
                        }
                    }
                });
            }
        });
    }

    public void getSkuDetails(List<String> list, final String str) {
        executeServiceRequest(new Runnable() {
            @Override
            public void run() {
                ArrayList arrayList = new ArrayList();
                arrayList.add(QueryProductDetailsParams.Product.newBuilder().setProductId(PurchaseHelper.this.context.getResources().getString(R.string.PRODUCT_ID_ALL)).setProductType(str).build());
                arrayList.add(QueryProductDetailsParams.Product.newBuilder().setProductId(PurchaseHelper.this.context.getResources().getString(R.string.PRODUCT_ID_WITH_AD)).setProductType(str).build());
                arrayList.add(QueryProductDetailsParams.Product.newBuilder().setProductId(PurchaseHelper.this.context.getResources().getString(R.string.PRODUCT_ID_AD)).setProductType(str).build());
                PurchaseHelper.this.mBillingClient.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(arrayList).build(), new ProductDetailsResponseListener() {
                    @Override
                    public void onProductDetailsResponse(BillingResult billingResult, List<ProductDetails> list2) {
                        if (billingResult.getResponseCode() != 0 || list2 == null || PurchaseHelper.this.purchaseHelperListener == null) {
                            return;
                        }
                        PurchaseHelper.this.purchaseHelperListener.onProductQueryResponse(list2);
                    }
                });
            }
        });
    }

    public void launchBillingFLow(final ProductDetails productDetails) {
        executeServiceRequest(new Runnable() {
            @Override
            public void run() {
                ArrayList arrayList = new ArrayList();
                arrayList.add(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(productDetails).build());
                PurchaseHelper.this.mBillingClient.launchBillingFlow((Activity) PurchaseHelper.this.context, BillingFlowParams.newBuilder().setProductDetailsParamsList(arrayList).build());
            }
        });
    }

    public void gotoManageSubscription() {
        String packageName = this.context.getPackageName();
        this.context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/account/subscriptions?package=" + packageName)));
    }

    private PurchasesUpdatedListener getPurchaseUpdatedListener() {
        return new PurchasesUpdatedListener() {
            @Override
            public void onPurchasesUpdated(BillingResult billingResult, List<Purchase> list) {
                if (billingResult.getResponseCode() == 0 && list != null && list.size() > 0 && PurchaseHelper.this.purchaseHelperListener != null) {
                    PurchaseHelper.this.purchaseHelperListener.onPurchasesUpdated(billingResult, list);
                } else {
                    billingResult.getResponseCode();
                }
            }
        };
    }

    public void handlePurchase(Purchase purchase) {
        if (purchase.getPurchaseState() == 1) {
            if (purchase.isAcknowledged()) {
                return;
            }
            this.mBillingClient.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build(), new AcknowledgePurchaseResponseListener() {
                @Override
                public void onAcknowledgePurchaseResponse(BillingResult billingResult) {
                }
            });
            return;
        }
        purchase.getPurchaseState();
    }

    private void executeServiceRequest(Runnable runnable) {
        if (this.mIsServiceConnected) {
            runnable.run();
        } else {
            startConnection(runnable);
        }
    }
}