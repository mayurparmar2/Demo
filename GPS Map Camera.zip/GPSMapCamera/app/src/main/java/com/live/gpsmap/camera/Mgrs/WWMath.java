package com.live.gpsmap.camera.Mgrs;



/* loaded from: classes3.dex */
public class WWMath {
    public static final double DAY_TO_MILLIS = 8.64E7d;
    public static final double HOUR_TO_MILLIS = 3600000.0d;
    public static final LatLon LONGITUDE_OFFSET_180 = LatLon.fromDegrees(0.0d, 180.0d);
    public static final double METERS_TO_FEET = 3.280839895d;
    public static final double METERS_TO_KILOMETERS = 0.001d;
    public static final double METERS_TO_MILES = 6.21371192E-4d;
    public static final double METERS_TO_NAUTICAL_MILES = 5.39956803E-4d;
    public static final double METERS_TO_YARDS = 1.0936133d;
    public static final double MINUTE_TO_MILLIS = 60000.0d;
    public static final double SECOND_TO_MILLIS = 1000.0d;
    public static final double SQUARE_METERS_TO_ACRES = 2.47105381E-4d;
    public static final double SQUARE_METERS_TO_HECTARES = 1.0E-4d;
    public static final double SQUARE_METERS_TO_SQUARE_FEET = 10.7639104d;
    public static final double SQUARE_METERS_TO_SQUARE_KILOMETERS = 1.0E-6d;
    public static final double SQUARE_METERS_TO_SQUARE_MILES = 3.86102159E-7d;
    public static final double SQUARE_METERS_TO_SQUARE_YARDS = 1.19599005d;

    public static double clamp(double d, double d2, double d3) {
        return d < d2 ? d2 : d > d3 ? d3 : d;
    }

    public static int clamp(int i, int i2, int i3) {
        return i < i2 ? i2 : i > i3 ? i3 : i;
    }

    public static double convertDaysToMillis(double d) {
        return d * 8.64E7d;
    }

    public static double convertFeetToMeters(double d) {
        return d / 3.280839895d;
    }

    public static double convertHoursToMillis(double d) {
        return d * 3600000.0d;
    }

    public static double convertMetersToFeet(double d) {
        return d * 3.280839895d;
    }

    public static double convertMetersToMiles(double d) {
        return d * 6.21371192E-4d;
    }

    public static double convertMillisToDays(double d) {
        return d / 8.64E7d;
    }

    public static double convertMillisToHours(double d) {
        return d / 3600000.0d;
    }

    public static double convertMillisToMinutes(double d) {
        return d / 60000.0d;
    }

    public static double convertMillisToSeconds(double d) {
        return d / 1000.0d;
    }

    public static double convertMinutesToMillis(double d) {
        return d * 60000.0d;
    }

    public static double convertSecondsToMillis(double d) {
        return d * 1000.0d;
    }

    public static double logBase2(double d) {
        return Math.log(d) / Math.log(2.0d);
    }

    public static boolean isPowerOfTwo(int i) {
        return i == powerOfTwoCeiling(i);
    }

    public static int powerOfTwoCeiling(int i) {
        return (int) Math.pow(2.0d, (int) Math.ceil(Math.log(i) / Math.log(2.0d)));
    }

    public static int powerOfTwoFloor(int i) {
        return (int) Math.pow(2.0d, (int) Math.floor(Math.log(i) / Math.log(2.0d)));
    }

    protected static int[] computePowers(int i, int i2) {
        int[] iArr = new int[i2];
        iArr[0] = 1;
        for (int i3 = 1; i3 < i2; i3++) {
            iArr[i3] = iArr[i3] + (iArr[i3 - 1] * i);
        }
        return iArr;
    }

    public static double computeInterpolationFactor(double d, double d2, double d3) {
        return clamp((d - d2) / (d3 - d2), (double) 0.0d, 1.0d);
    }

    public static double mix(double d, double d2, double d3) {
        return d2 + (clamp(d, (double) 0.0d, 1.0d) * (d3 - d2));
    }

    public static double mixSmooth(double d, double d2, double d3) {
        double clamp = clamp(d, (double) 0.0d, 1.0d);
        return d2 + (clamp * clamp * (3.0d - (clamp * 2.0d)) * (d3 - d2));
    }
}
