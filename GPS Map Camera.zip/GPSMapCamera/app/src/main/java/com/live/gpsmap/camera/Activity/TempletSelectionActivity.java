package com.live.gpsmap.camera.Activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.text.Html;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import com.bumptech.glide.Glide;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.Utils.Util;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@SuppressWarnings("All")
public class TempletSelectionActivity extends AppCompatActivity implements View.OnClickListener {
    ImageView Classic_imgCompass;
    ImageView Classic_imgLogo;
    ImageView Classic_imgMap;
    ImageView Classic_imgWeather;
    ImageView Classic_img_humidity_stamp;
    ImageView Classic_img_magnetic_field;
    ImageView Classic_img_pressure_stamp;
    ImageView Classic_img_wind_stamp;
    ImageView Classic_imgstamp_1;
    ImageView Classic_imgstamp_2;
    LinearLayout Classic_li_address;
    LinearLayout Classic_li_compass;
    LinearLayout Classic_li_logo;
    LinearLayout Classic_li_magnetic_field;
    LinearLayout Classic_li_main_stamp_lay;
    LinearLayout Classic_li_rightView;
    LinearLayout Classic_li_stamp;
    LinearLayout Classic_li_weather;
    LinearLayout Classic_lin_bottom_wether;
    LinearLayout Classic_lin_humity_stamp;
    LinearLayout Classic_lin_pressure_stamp;
    LinearLayout Classic_lin_waterma;
    LinearLayout Classic_lin_waterma_2;
    LinearLayout Classic_lin_wind;
    LinearLayout Classic_lin_wind_stamp;
    TextView Classic_tv_address;
    TextView Classic_tv_compass;
    TextView Classic_tv_humidity;
    TextView Classic_tv_magnetic_field;
    TextView Classic_tv_pressure;
    TextView Classic_tv_weather;
    TextView Classic_tv_wind;
    TextView Classic_txt_watermark_1;
    TextView Classic_txt_watermark_2;
    int Humidity_color;
    int Humidity_color_classic;
    private boolean IS_ADS;
    String Logo_img;
    String Logo_img_classic;
    int accuracy_color;
    int accuracy_color_classic;
    int accuracy_selection;
    int accuracy_selection_classic;
    int address_color;
    int address_color_classic;
    String ads_status;
    int altitude_color;
    int altitude_color_classic;
    int altitude_selection;
    int altitude_selection_classic;
    int background_color;
    int background_color_classic;
    RelativeLayout banner_native_layout;
    TextView classic_tv_address_line_1;
    int compass_color;
    int compass_color_classic;
    int date_time_color;
    int date_time_color_classic;
    int elevation_color;
    int elevation_color_classic;
    String font_style;
    String font_style_classic;
    ImageView imf_advance_temlent;
    ImageView imf_classic_templet;
    ImageView imgCompass;
    ImageView imgLogo;
    ImageView imgMap;
    ImageView imgWeather;
    ImageView img_humidity_stamp;
    ImageView img_magnetic_field;
    ImageView img_pressure_stamp;
    ImageView img_wind_stamp;
    ImageView imgstamp_1;
    ImageView imgstamp_2;
    boolean isAddress;
    boolean isAddress_classic;
    boolean isCompass;
    boolean isCompassFound;
    boolean isCompass_classic;
    boolean isDateTime;
    boolean isDateTime_classic;
    boolean isHumidity;
    boolean isHumidity_classic;
    boolean isLatLng;
    boolean isLatLng_classic;
    boolean isMagneticField;
    boolean isMagneticField_classic;
    boolean isMap;
    boolean isMap_classic;
    boolean isNumbering;
    boolean isNumbering_classic;
    boolean isPlusCode;
    boolean isPlusCode_classic;
    boolean isWeather;
    boolean isWeather_classic;
    boolean isaccuracy;
    boolean isaccuracy_classic;
    boolean isaltitude;
    boolean isaltitude_classic;
    boolean iselevation;
    boolean iselevation_classic;
    boolean islogo;
    boolean islogo_classic;
    boolean isnotes;
    boolean isnotes_classic;
    boolean ispressure;
    boolean ispressure_classic;
    boolean istimezone;
    boolean istimezone_classic;
    boolean iswind;
    boolean iswind_classic;
    int lat_lng_color;
    int lat_lng_color_classic;
    LinearLayout li_address;
    LinearLayout li_compass;
    LinearLayout li_logo;
    LinearLayout li_magnetic_field;
    LinearLayout li_main_stamp_lay;
    LinearLayout li_rightView;
    LinearLayout li_stamp;
    LinearLayout li_weather;
    LinearLayout lin_bottom_wether;
    LinearLayout lin_humity_stamp;
    LinearLayout lin_pressure;
    LinearLayout lin_pressure_stamp;
    LinearLayout lin_waterma;
    LinearLayout lin_waterma_2;
    LinearLayout lin_wind;
    LinearLayout lin_wind_stamp;
    String mDateFormat;
    String mDateFormat_classic;
    Util mUtil;
    int mIconValue;
    int mIconValue_classic;
    int mLatLngType;
    int mLatLngType_classic;
    String mMap_Type;
    String mMap_Type_classic;
    String mPluscode_type;
    String mPluscode_type_classic;
    int mPos_mapType;
    int mPos_mapType_classic;
    SP mSP;
    String mStamp_Pos;
    String mStamp_Pos_classic;
    String mStamp_size;
    String mStamp_size_classic;
    private RelativeLayout mToolbar_back;
    TypedArray mWeatherIcon;
    int magnetic_field_color;
    int magnetic_field_color_classic;
    float mfTemprature_value;
    String msTemprature_type;
    String msTemprature_type_classic;
    private TextView mtv_toolbar_title;
    int note_hastag_color;
    int note_hastag_color_classic;
    String notes;
    String notes_classic;
    int numbering_color;
    int numbering_color_classic;
    int plus_code_color;
    int plus_code_color_classic;
    String prefix;
    String prefix_classic;
    int pressure_color;
    int pressure_color_classic;
    int pressure_selection;
    int pressure_selection_classic;
    LinearLayout relStampLay;
    LinearLayout relStampLay_claasic;
    int sequence;
    int sequence_classic;
    SharedPreferences sharedPreferences;
    String suffix;
    String suffix_classic;
    int timezone;
    int timezone_classic;
    TextView tv_address;
    TextView tv_address_line_1;
    TextView tv_compass;
    TextView tv_humidity;
    TextView tv_magnetic_field;
    TextView tv_pressure;
    TextView tv_weather;
    TextView tv_wind;
    TextView txt_watermark_1;
    TextView txt_watermark_2;
    int weather_color;
    int weather_color_classic;
    int wind_color;
    int wind_color_classic;
    int wind_selected;
    int wind_selected_classic;
    int templet_type = 0;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_templet_selection);
//        this.ads_status = new SP(this).getString(this, SP.ADS_STATUS, AppEventsConstants.EVENT_PARAM_VALUE_YES);
//        this.IS_ADS = new SP(this).getBoolean(this, Util.IS_PURCHESH_OR_NOT, false);
        this.sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        defindid();
        inti();
        OnClick();
//        loadAds();
    }

//    private void getexitads() {
//        int integer = this.mSP.getInteger(this, Util.COUNTADS, 0);
//        if (!this.ads_status.equals(AppEventsConstants.EVENT_PARAM_VALUE_YES) || this.IS_ADS) {
//            finish();
//        } else if (integer == 2) {
//            if (NetworkState.Companion.isOnline(this)) {
//                Util.showProgressDialog(this, "Loading...");
//                new Handler().postDelayed(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.TempletSelectionActivity.1
//                    @Override // java.lang.Runnable
//                    public void run() {
//                        TempletSelectionActivity.this.mSP.setInteger(TempletSelectionActivity.this, Util.COUNTADS, 0);
//                        TempletSelectionActivity templetSelectionActivity = TempletSelectionActivity.this;
//                        templetSelectionActivity.inrequestadd(templetSelectionActivity);
//                    }
//                }, 200L);
//                new Handler().postDelayed(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.TempletSelectionActivity.2
//                    @Override // java.lang.Runnable
//                    public void run() {
//                        if (TempletSelectionActivity.this.mInterstitialAd != null) {
//                            TempletSelectionActivity.this.mInterstitialAd.show(TempletSelectionActivity.this);
//                        } else {
//                            TempletSelectionActivity.this.finish();
//                        }
//                    }
//                }, 7000L);
//                return;
//            }
//            finish();
//        } else {
//            this.mSP.setInteger(this, Util.COUNTADS, integer + 1);
//            finish();
//        }
//    }

    /* JADX INFO: Access modifiers changed from: private */
//    public void inrequestadd(Context context) {
//        try {
//            InterstitialAd.load(this, getResources().getString(R.string.TC_3_click_FS), new AdRequest.Builder().build(), new InterstitialAdLoadCallback() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.TempletSelectionActivity.3
//                @Override // com.google.android.gms.ads.AdLoadCallback
//                public void onAdLoaded(InterstitialAd interstitialAd) {
//                    TempletSelectionActivity.this.mInterstitialAd = interstitialAd;
//                    setFullScreenContentCallback();
//                    if (TempletSelectionActivity.this.mInterstitialAd != null) {
//                        TempletSelectionActivity.this.mInterstitialAd.show(TempletSelectionActivity.this);
//                    }
//                }
//
//                private void setFullScreenContentCallback() {
//                    TempletSelectionActivity.this.mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.TempletSelectionActivity.3.1
//                        @Override // com.google.android.gms.ads.FullScreenContentCallback
//                        public void onAdDismissedFullScreenContent() {
//                            Log.d("TAG", "The ad was dismissed.");
//                            Util.dismissProgressDialog();
//                            TempletSelectionActivity.this.finish();
//                        }
//
//                        @Override // com.google.android.gms.ads.FullScreenContentCallback
//                        public void onAdFailedToShowFullScreenContent(AdError adError) {
//                            Log.d("TAG", "The ad failed to show.");
//                            TempletSelectionActivity.this.finish();
//                        }
//
//                        @Override // com.google.android.gms.ads.FullScreenContentCallback
//                        public void onAdShowedFullScreenContent() {
//                            TempletSelectionActivity.this.mInterstitialAd = null;
//                            Log.d("TAG", "The ad was shown.");
//                        }
//                    });
//                }
//
//                @Override // com.google.android.gms.ads.AdLoadCallback
//                public void onAdFailedToLoad(LoadAdError loadAdError) {
//                    TempletSelectionActivity.this.mInterstitialAd = null;
//                }
//            });
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    private void loadAds() {
//        this.ads = new Admob();
//        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.rel_adaptive_banner);
//        this.banner_native_layout = relativeLayout;
//        this.ads.loadAdaptive_banner(this, relativeLayout, getString(R.string.GMC_Banner_Details));
//    }

    private void defindid() {
        this.mtv_toolbar_title = (TextView) findViewById(R.id.tv_toolbar_title);
        this.mToolbar_back = (RelativeLayout) findViewById(R.id.toolbar_back);
        this.imf_advance_temlent = (ImageView) findViewById(R.id.imf_advance_temlent);
        this.imf_classic_templet = (ImageView) findViewById(R.id.imf_classic_templet);
        this.Classic_imgMap = (ImageView) findViewById(R.id.classic_imgMap);
        this.Classic_imgLogo = (ImageView) findViewById(R.id.classic_imgLogo);
        this.Classic_imgCompass = (ImageView) findViewById(R.id.classic_mgCompass);
        this.Classic_imgWeather = (ImageView) findViewById(R.id.classic_imgWeather);
        this.Classic_img_pressure_stamp = (ImageView) findViewById(R.id.classic_img_pressure_stamp);
        this.Classic_img_wind_stamp = (ImageView) findViewById(R.id.classic_img_wind_stamp);
        this.Classic_img_magnetic_field = (ImageView) findViewById(R.id.classic_imgMagneticField);
        this.Classic_img_humidity_stamp = (ImageView) findViewById(R.id.classic_img_humidity_stamp);
        this.classic_tv_address_line_1 = (TextView) findViewById(R.id.classic_tv_address_line_1);
        this.Classic_tv_address = (TextView) findViewById(R.id.classic_tv_address);
        this.Classic_tv_weather = (TextView) findViewById(R.id.classic_tv_weather);
        this.Classic_tv_pressure = (TextView) findViewById(R.id.classic_txt_pressure);
        this.Classic_tv_humidity = (TextView) findViewById(R.id.classic_txt_humidity);
        this.Classic_tv_wind = (TextView) findViewById(R.id.classic_txt_wind);
        this.Classic_tv_compass = (TextView) findViewById(R.id.classic_tv_compass);
        this.Classic_tv_magnetic_field = (TextView) findViewById(R.id.classic_tv_magnetic_field);
        this.Classic_lin_wind_stamp = (LinearLayout) findViewById(R.id.classic_lin_wind_stamp);
        this.Classic_li_compass = (LinearLayout) findViewById(R.id.classic_li_compass);
        this.Classic_li_logo = (LinearLayout) findViewById(R.id.classic_li_logo);
        this.Classic_li_rightView = (LinearLayout) findViewById(R.id.classic_li_rightView);
        this.Classic_li_magnetic_field = (LinearLayout) findViewById(R.id.classic_li_magnetic_field);
        this.Classic_li_weather = (LinearLayout) findViewById(R.id.classic_li_weather);
        this.Classic_li_main_stamp_lay = (LinearLayout) findViewById(R.id.classic_li_main_stamp_lay);
        this.Classic_li_address = (LinearLayout) findViewById(R.id.classic_li_address);
        this.Classic_li_stamp = (LinearLayout) findViewById(R.id.classic_li_stamp);
        this.Classic_lin_waterma = (LinearLayout) findViewById(R.id.classic_lin_waterma);
        this.Classic_lin_waterma_2 = (LinearLayout) findViewById(R.id.classic_lin_waterma_2);
        this.Classic_imgstamp_1 = (ImageView) findViewById(R.id.iclassic_mg_stamp);
        this.Classic_imgstamp_2 = (ImageView) findViewById(R.id.iclassic_mg_stamp_2);
        this.Classic_txt_watermark_1 = (TextView) findViewById(R.id.classic_txt_watermark);
        this.Classic_txt_watermark_2 = (TextView) findViewById(R.id.classic_txt_watermark_2);
        this.Classic_lin_pressure_stamp = (LinearLayout) findViewById(R.id.classic_lin_pressure_stamp);
        this.Classic_lin_humity_stamp = (LinearLayout) findViewById(R.id.classic_lin_humidity_stamp);
        this.Classic_lin_bottom_wether = (LinearLayout) findViewById(R.id.classic_lin_bottom_wather);
        this.relStampLay_claasic = (LinearLayout) findViewById(R.id.relStampLay_claasic);
        this.relStampLay = (LinearLayout) findViewById(R.id.relStampLay);
        this.imgMap = (ImageView) findViewById(R.id.imgMap);
        this.imgLogo = (ImageView) findViewById(R.id.imgLogo);
        this.imgCompass = (ImageView) findViewById(R.id.imgCompass);
        this.imgWeather = (ImageView) findViewById(R.id.imgWeather);
        this.img_pressure_stamp = (ImageView) findViewById(R.id.img_pressure_stamp);
        this.img_wind_stamp = (ImageView) findViewById(R.id.img_wind_stamp);
        this.img_magnetic_field = (ImageView) findViewById(R.id.imgMagneticField);
        this.img_humidity_stamp = (ImageView) findViewById(R.id.img_humidity_stamp);
        this.tv_address_line_1 = (TextView) findViewById(R.id.tv_address_line_1);
        this.tv_address = (TextView) findViewById(R.id.tv_address);
        this.tv_weather = (TextView) findViewById(R.id.tv_weather);
        this.tv_pressure = (TextView) findViewById(R.id.txt_pressure);
        this.tv_humidity = (TextView) findViewById(R.id.txt_humidity);
        this.tv_wind = (TextView) findViewById(R.id.txt_wind);
        this.tv_compass = (TextView) findViewById(R.id.tv_compass);
        this.tv_magnetic_field = (TextView) findViewById(R.id.tv_magnetic_field);
//        this.lin_wind = (LinearLayout) findViewById(R.id.lin_wind);
        this.li_compass = (LinearLayout) findViewById(R.id.li_compass);
        this.li_logo = (LinearLayout) findViewById(R.id.li_logo);
        this.li_rightView = (LinearLayout) findViewById(R.id.li_rightView);
        this.li_magnetic_field = (LinearLayout) findViewById(R.id.li_magnetic_field);
        this.li_weather = (LinearLayout) findViewById(R.id.li_weather);
        this.li_main_stamp_lay = (LinearLayout) findViewById(R.id.li_main_stamp_lay);
        this.li_address = (LinearLayout) findViewById(R.id.li_address);
        this.li_stamp = (LinearLayout) findViewById(R.id.li_stamp);
//        this.lin_pressure = (LinearLayout) findViewById(R.id.lin_pressure);
        this.lin_waterma = (LinearLayout) findViewById(R.id.lin_waterma);
        this.lin_waterma_2 = (LinearLayout) findViewById(R.id.lin_waterma_2);
        this.imgstamp_1 = (ImageView) findViewById(R.id.img_stamp);
        this.imgstamp_2 = (ImageView) findViewById(R.id.img_stamp_2);
        this.txt_watermark_1 = (TextView) findViewById(R.id.txt_watermark);
        this.txt_watermark_2 = (TextView) findViewById(R.id.txt_watermark_2);
        this.lin_pressure_stamp = (LinearLayout) findViewById(R.id.lin_pressure_stamp);
        this.lin_wind_stamp = (LinearLayout) findViewById(R.id.lin_wind_stamp);
        this.lin_humity_stamp = (LinearLayout) findViewById(R.id.lin_humidity_stamp);
        this.lin_bottom_wether = (LinearLayout) findViewById(R.id.lin_bottom_wather);
    }

    private void inti() {
        this.mtv_toolbar_title.setText(getString(R.string.template));
        SP sp = new SP(this);
        this.mSP = sp;
        this.mSP.setInteger(this, "TEMPLT_OPEN_TIME", sp.getInteger(this, "TEMPLT_OPEN_TIME", 0) + 1);
        this.mUtil = new Util();
        int integer = this.mSP.getInteger(this, SP.TEMPLATE_TYPE, 0);
        this.templet_type = integer;
        if (integer == 1) {
            this.imf_advance_temlent.setVisibility(View.GONE);
            this.imf_classic_templet.setVisibility(View.VISIBLE);
            return;
        }
        this.imf_advance_temlent.setVisibility(View.VISIBLE);
        this.imf_classic_templet.setVisibility(View.GONE);
    }

    private void setclassic_temp() {
        boolean z;
        boolean z2;
        int i;
        boolean z3;
        this.mWeatherIcon = getResources().obtainTypedArray(R.array.wI);
        this.background_color_classic = this.mSP.getInteger(this, SP.BACKGROUND_COLOR_CLASSIC, Color.parseColor("#9c000000"));
        this.address_color_classic = this.mSP.getInteger(this, SP.ADDRESS_COLOR_CLASSIC, -1);
        this.date_time_color_classic = this.mSP.getInteger(this, SP.DATE_TIME_COLOR_CLASSIC, -1);
        this.lat_lng_color_classic = this.mSP.getInteger(this, SP.LAT_LNG_COLOR_CLASSIC, -1);
        this.plus_code_color_classic = this.mSP.getInteger(this, SP.PLUS_CODE_COLOR_CLASSIC, -1);
        this.weather_color_classic = this.mSP.getInteger(this, SP.WEATHER_COLOR_CLASSIC, -1);
        this.magnetic_field_color_classic = this.mSP.getInteger(this, SP.MAGNETIC_FIELD_COLOR_CLASSIC, -1);
        this.compass_color_classic = this.mSP.getInteger(this, SP.COMPASS_COLOR_CLASSIC, -1);
        this.note_hastag_color_classic = this.mSP.getInteger(this, SP.NOTES_HASHTAG_COLOR_CLASSIC, -1);
        this.wind_color_classic = this.mSP.getInteger(this, SP.WIND_COLOR_CLASSIC, -1);
        this.Humidity_color_classic = this.mSP.getInteger(this, SP.HUMIDITY_COLOR_CLASSIC, -1);
        this.pressure_color_classic = this.mSP.getInteger(this, SP.PRESSURE_COLOR_CLASSIC, -1);
        this.elevation_color_classic = this.mSP.getInteger(this, SP.ELEVATION_COLOR_CLASSIC, -1);
        this.altitude_color_classic = this.mSP.getInteger(this, SP.ALTITUDE_COLOR_CLASSIC, -1);
        this.accuracy_color_classic = this.mSP.getInteger(this, SP.ACCURACY_COLOR_CLASSIC, -1);
        this.numbering_color_classic = this.mSP.getInteger(this, SP.NUMBERING_COLOR_CLASSIC, -1);
        this.timezone_classic = this.mSP.getInteger(this, SP.TIMEZONE_CLASSIC, 6);
        this.sequence_classic = this.mSP.getInteger(this, SP.SEQUENCE_CLASSIC, 1);
        this.suffix_classic = this.mSP.getString(this, SP.SUFFIX_CLASSIC, "");
        this.prefix_classic = this.mSP.getString(this, SP.PREFIX_CLASSIC, "");
        this.isMap_classic = this.mSP.getBoolean(this, SP.IS_MAP_CLASSIC, true);
        this.isAddress_classic = this.mSP.getBoolean(this, SP.IS_ADDRESS_CLASSIC, true);
        this.isLatLng_classic = this.mSP.getBoolean(this, SP.IS_LAT_LNG_TEMPLATE_CLASSIC, true);
        this.isPlusCode_classic = this.mSP.getBoolean(this, SP.IS_PLUS_CODE_CLASSIC, false);
        this.isWeather_classic = this.mSP.getBoolean(this, SP.IS_WEATHER_CLASSIC, false);
        this.isDateTime_classic = this.mSP.getBoolean(this, SP.IS_DATE_TIME_CLASSIC, true);
        this.istimezone_classic = this.mSP.getBoolean(this, SP.IS_TIMEZONE_CLASSIC, true);
        this.isNumbering_classic = this.mSP.getBoolean(this, SP.IS_NUMBERING_CLASSIC, false);
        this.isMagneticField_classic = this.mSP.getBoolean(this, SP.IS_MAGNETIC_FIELD_CLASSIC, false);
        this.isCompass_classic = this.mSP.getBoolean(this, SP.IS_COMPASS_CLASSIC, false);
        this.iswind_classic = this.mSP.getBoolean(this, SP.IS_WIND_CLASSIC, false);
        this.islogo_classic = this.mSP.getBoolean(this, SP.IS_LOGO_CLASSIC, false);
        this.isnotes_classic = this.mSP.getBoolean(this, SP.IS_NOTES_CLASSIC, false);
        this.ispressure_classic = this.mSP.getBoolean(this, SP.IS_PRESSURE_CLASSIC, false);
        this.isHumidity_classic = this.mSP.getBoolean(this, SP.IS_HUMIDITY_CLASSIC, false);
        this.iselevation_classic = this.mSP.getBoolean(this, SP.IS_ELEVATION_CLASSIC, false);
        this.isaltitude_classic = this.mSP.getBoolean(this, SP.IS_ALTITUDE_CLASSIC, false);
        this.isaccuracy_classic = this.mSP.getBoolean(this, SP.IS_ACCURACY_CLASSIC, false);
        this.Logo_img_classic = this.mSP.getString(this, SP.LOGO_URI_CLASSIC, "no_logo");
        this.notes_classic = this.mSP.getString(this, SP.NOTES_HASHTAG_CLASSIC, "Note : Captured by GPS Map Camera");
        this.font_style_classic = this.mSP.getString(this, SP.STAMP_FONT_STYLE_CLASSIC, "sfuitext_regular.otf");
        this.mDateFormat_classic = this.mSP.getString(this, SP.DATE_FORMAT_CLASSIC, "dd/MM/yy hh:mm a");
        this.mLatLngType_classic = this.mSP.getInteger(this, SP.LAT_LNG_TYPE_CLASSIC, 1);
        this.msTemprature_type_classic = this.mSP.getString(this, SP.TEMPRATURE_TYPE_CLASSIC, "Celsius");
        this.mIconValue_classic = this.mSP.getInteger(this, SP.WEATHER_ICON, 0);
        this.Classic_imgWeather.setImageResource(this.mWeatherIcon.getResourceId(this.mIconValue, 0));
        this.mMap_Type_classic = this.mSP.getString(this, SP.MAP_TYPE_TEMPLATE_CLASSIC, "satellite");
        this.mPos_mapType_classic = this.mSP.getInteger(this, SP.MAP_POS_CLASSIC, 1);
        this.mStamp_Pos_classic = this.mSP.getString(this, SP.STAMP_POS_CLASSIC, "Bottom");
        this.mStamp_size_classic = this.mSP.getString(this, SP.STAMP_SIZE_CLASSIC, "Medium");
        this.mPluscode_type_classic = this.mSP.getString(this, SP.PLUS_CODE_TYPE_CLASSIC, "accurate");
        this.wind_selected_classic = this.mSP.getInteger(this, SP.WIND_SELECT_CLASSIC, 0);
        this.altitude_selection_classic = this.mSP.getInteger(this, SP.ALTITUDE_SELECT_CLASSIC, 0);
        this.accuracy_selection_classic = this.mSP.getInteger(this, SP.ACCURACY_SELECT_CLASSIC, 0);
        this.pressure_selection_classic = this.mSP.getInteger(this, SP.PRESSURE_SELECT_CLASSIC, 0);
        boolean z4 = getResources().getBoolean(R.bool.isTablet);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        if (this.isMap_classic) {
            this.Classic_imgMap.setVisibility(View.VISIBLE);
        } else {
            this.Classic_imgMap.setVisibility(View.GONE);
        }
        layoutParams.setMargins(0, 0, 0, 0);
        this.Classic_li_stamp.setLayoutParams(layoutParams);
        if (this.isWeather_classic) {
            this.Classic_li_weather.setVisibility(View.VISIBLE);
        } else {
            this.Classic_li_weather.setVisibility(View.GONE);
        }
        if (this.isHumidity_classic || this.isaccuracy_classic || this.isaltitude_classic || this.iswind_classic || this.ispressure_classic) {
            this.Classic_lin_bottom_wether.setVisibility(View.VISIBLE);
            if (z4) {
                ((LinearLayout.LayoutParams) this.Classic_lin_bottom_wether.getLayoutParams()).height += 2;
            }
        } else {
            this.Classic_lin_bottom_wether.setVisibility(View.GONE);
        }
        if (this.iswind_classic) {
            this.Classic_lin_wind_stamp.setVisibility(View.VISIBLE);
        } else {
            this.Classic_lin_wind_stamp.setVisibility(View.GONE);
        }
        if (this.isHumidity_classic) {
            this.Classic_lin_humity_stamp.setVisibility(View.VISIBLE);
        } else {
            this.Classic_lin_humity_stamp.setVisibility(View.GONE);
        }
        if (this.ispressure_classic) {
            this.Classic_lin_pressure_stamp.setVisibility(View.VISIBLE);
        } else {
            this.Classic_lin_pressure_stamp.setVisibility(View.GONE);
        }
        if (this.isaltitude_classic) {
            String altitudeconvert = Util.getAltitudeconvert(this, this.altitude_selection_classic);
            if (this.Classic_lin_pressure_stamp.getVisibility() == 8) {
                this.Classic_lin_pressure_stamp.setVisibility(View.VISIBLE);
                this.Classic_img_pressure_stamp.setImageResource(R.drawable.ic_altitiude);
                this.Classic_tv_pressure.setText(altitudeconvert);
                this.Classic_tv_pressure.setTextColor(this.altitude_color_classic);
            } else if (this.Classic_lin_wind_stamp.getVisibility() == 8) {
                this.Classic_lin_wind_stamp.setVisibility(View.VISIBLE);
                this.Classic_img_wind_stamp.setImageResource(R.drawable.ic_altitiude);
                this.Classic_tv_wind.setText(altitudeconvert);
                this.Classic_tv_wind.setTextColor(this.altitude_color_classic);
            } else if (this.Classic_lin_humity_stamp.getVisibility() == 8) {
                this.Classic_lin_humity_stamp.setVisibility(View.VISIBLE);
                this.Classic_img_humidity_stamp.setImageResource(R.drawable.ic_altitiude);
                this.Classic_tv_humidity.setText(altitudeconvert);
                this.Classic_tv_humidity.setTextColor(this.altitude_color_classic);
            }
        }
        if (this.isaccuracy_classic) {
            String accuracy = Util.getAccuracy(this, this.accuracy_selection_classic);
            if (this.Classic_lin_pressure_stamp.getVisibility() == 8) {
                this.Classic_lin_pressure_stamp.setVisibility(View.VISIBLE);
                this.Classic_img_pressure_stamp.setImageResource(R.drawable.ic_accuracy);
                this.Classic_tv_pressure.setText(accuracy);
                this.Classic_tv_pressure.setTextColor(this.accuracy_color_classic);
            } else if (this.Classic_lin_wind_stamp.getVisibility() == 8) {
                this.Classic_lin_wind_stamp.setVisibility(View.VISIBLE);
                this.Classic_img_wind_stamp.setImageResource(R.drawable.ic_accuracy);
                this.Classic_tv_wind.setText(accuracy);
                this.Classic_tv_wind.setTextColor(this.accuracy_color_classic);
            } else if (this.Classic_lin_humity_stamp.getVisibility() == 8) {
                this.Classic_lin_humity_stamp.setVisibility(View.VISIBLE);
                this.Classic_img_humidity_stamp.setImageResource(R.drawable.ic_accuracy);
                this.Classic_tv_humidity.setText(accuracy);
                this.Classic_tv_humidity.setTextColor(this.accuracy_color_classic);
            }
        }
        if (this.isCompassFound) {
            if (this.isMagneticField_classic) {
                this.Classic_li_magnetic_field.setVisibility(View.VISIBLE);
            } else {
                this.Classic_li_magnetic_field.setVisibility(View.GONE);
            }
            if (this.isCompass_classic) {
                this.Classic_li_compass.setVisibility(View.VISIBLE);
            } else {
                this.Classic_li_compass.setVisibility(View.GONE);
            }
        } else {
            this.Classic_li_magnetic_field.setVisibility(View.GONE);
            this.Classic_li_compass.setVisibility(View.GONE);
        }
        if (this.isWeather_classic || this.isMagneticField_classic || this.isCompass_classic || this.islogo_classic) {
            this.Classic_li_rightView.setVisibility(View.VISIBLE);
        } else {
            this.Classic_li_rightView.setVisibility(View.GONE);
        }
        if (this.islogo_classic) {
            this.Classic_li_logo.setVisibility(View.VISIBLE);
        } else {
            this.Classic_li_logo.setVisibility(View.GONE);
        }
        if (this.mStamp_size_classic.equals("Medium")) {
            this.Classic_imgLogo.getLayoutParams().height = Util.dpToPx(this, 30);
            this.Classic_imgLogo.getLayoutParams().width = Util.dpToPx(this, 58);
            this.Classic_imgWeather.getLayoutParams().height = Util.dpToPx(this, 16);
            this.Classic_imgWeather.getLayoutParams().width = Util.dpToPx(this, 16);
            this.Classic_imgCompass.getLayoutParams().height = Util.dpToPx(this, 16);
            this.Classic_imgCompass.getLayoutParams().width = Util.dpToPx(this, 16);
            this.Classic_img_humidity_stamp.getLayoutParams().height = Util.dpToPx(this, 16);
            this.Classic_img_humidity_stamp.getLayoutParams().width = Util.dpToPx(this, 16);
            this.Classic_img_pressure_stamp.getLayoutParams().height = Util.dpToPx(this, 16);
            this.Classic_img_pressure_stamp.getLayoutParams().width = Util.dpToPx(this, 16);
            this.Classic_img_wind_stamp.getLayoutParams().height = Util.dpToPx(this, 16);
            this.Classic_img_wind_stamp.getLayoutParams().width = Util.dpToPx(this, 16);
            this.Classic_img_magnetic_field.getLayoutParams().height = Util.dpToPx(this, 16);
            this.Classic_img_magnetic_field.getLayoutParams().width = Util.dpToPx(this, 16);
            this.Classic_tv_wind.setTextSize(10.0f);
            this.Classic_tv_pressure.setTextSize(10.0f);
            this.Classic_tv_humidity.setTextSize(10.0f);
            this.Classic_tv_weather.setTextSize(10.0f);
            this.Classic_tv_compass.setTextSize(10.0f);
            this.Classic_tv_magnetic_field.setTextSize(10.0f);
        } else if (this.mStamp_size_classic.equals("Small")) {
            this.Classic_imgLogo.getLayoutParams().height = Util.dpToPx(this, 28);
            this.Classic_imgLogo.getLayoutParams().width = Util.dpToPx(this, 54);
            this.Classic_imgWeather.getLayoutParams().height = Util.dpToPx(this, 14);
            this.Classic_imgWeather.getLayoutParams().width = Util.dpToPx(this, 14);
            this.Classic_imgCompass.getLayoutParams().height = Util.dpToPx(this, 14);
            this.Classic_imgCompass.getLayoutParams().width = Util.dpToPx(this, 14);
            this.Classic_img_humidity_stamp.getLayoutParams().height = Util.dpToPx(this, 14);
            this.Classic_img_humidity_stamp.getLayoutParams().width = Util.dpToPx(this, 14);
            this.Classic_img_pressure_stamp.getLayoutParams().height = Util.dpToPx(this, 14);
            this.Classic_img_pressure_stamp.getLayoutParams().width = Util.dpToPx(this, 14);
            this.Classic_img_wind_stamp.getLayoutParams().height = Util.dpToPx(this, 14);
            this.Classic_img_wind_stamp.getLayoutParams().width = Util.dpToPx(this, 14);
            this.Classic_img_magnetic_field.getLayoutParams().height = Util.dpToPx(this, 14);
            this.Classic_img_magnetic_field.getLayoutParams().width = Util.dpToPx(this, 14);
            this.Classic_tv_wind.setTextSize(8.0f);
            this.Classic_tv_pressure.setTextSize(8.0f);
            this.Classic_tv_humidity.setTextSize(8.0f);
            this.Classic_tv_weather.setTextSize(8.0f);
            this.Classic_tv_compass.setTextSize(8.0f);
            this.Classic_tv_magnetic_field.setTextSize(8.0f);
        } else if (this.mStamp_size_classic.equals("Extra Small")) {
            this.Classic_imgLogo.getLayoutParams().height = Util.dpToPx(this, 26);
            this.Classic_imgLogo.getLayoutParams().width = Util.dpToPx(this, 50);
            this.Classic_imgWeather.getLayoutParams().height = Util.dpToPx(this, 12);
            this.Classic_imgWeather.getLayoutParams().width = Util.dpToPx(this, 12);
            this.Classic_imgCompass.getLayoutParams().height = Util.dpToPx(this, 12);
            this.Classic_imgCompass.getLayoutParams().width = Util.dpToPx(this, 12);
            this.Classic_img_humidity_stamp.getLayoutParams().height = Util.dpToPx(this, 12);
            this.Classic_img_humidity_stamp.getLayoutParams().width = Util.dpToPx(this, 12);
            this.Classic_img_pressure_stamp.getLayoutParams().height = Util.dpToPx(this, 12);
            this.Classic_img_pressure_stamp.getLayoutParams().width = Util.dpToPx(this, 12);
            this.Classic_img_wind_stamp.getLayoutParams().height = Util.dpToPx(this, 12);
            this.Classic_img_wind_stamp.getLayoutParams().width = Util.dpToPx(this, 12);
            this.Classic_img_magnetic_field.getLayoutParams().height = Util.dpToPx(this, 12);
            this.Classic_img_magnetic_field.getLayoutParams().width = Util.dpToPx(this, 12);
            this.Classic_tv_wind.setTextSize(6.0f);
            this.Classic_tv_pressure.setTextSize(6.0f);
            this.Classic_tv_humidity.setTextSize(6.0f);
            this.Classic_tv_weather.setTextSize(6.0f);
            this.Classic_tv_compass.setTextSize(6.0f);
            this.Classic_tv_magnetic_field.setTextSize(6.0f);
        } else {
            this.Classic_imgLogo.getLayoutParams().height = Util.dpToPx(this, 32);
            this.Classic_imgLogo.getLayoutParams().width = Util.dpToPx(this, 62);
            this.Classic_imgWeather.getLayoutParams().height = Util.dpToPx(this, 18);
            this.Classic_imgWeather.getLayoutParams().width = Util.dpToPx(this, 18);
            this.Classic_imgCompass.getLayoutParams().height = Util.dpToPx(this, 18);
            this.Classic_imgCompass.getLayoutParams().width = Util.dpToPx(this, 18);
            this.Classic_img_humidity_stamp.getLayoutParams().height = Util.dpToPx(this, 18);
            this.Classic_img_humidity_stamp.getLayoutParams().width = Util.dpToPx(this, 18);
            this.Classic_img_pressure_stamp.getLayoutParams().height = Util.dpToPx(this, 18);
            this.Classic_img_pressure_stamp.getLayoutParams().width = Util.dpToPx(this, 18);
            this.Classic_img_wind_stamp.getLayoutParams().height = Util.dpToPx(this, 18);
            this.Classic_img_wind_stamp.getLayoutParams().width = Util.dpToPx(this, 18);
            this.Classic_img_magnetic_field.getLayoutParams().height = Util.dpToPx(this, 18);
            this.Classic_img_magnetic_field.getLayoutParams().width = Util.dpToPx(this, 18);
            this.Classic_tv_wind.setTextSize(12.0f);
            this.Classic_tv_pressure.setTextSize(12.0f);
            this.Classic_tv_humidity.setTextSize(12.0f);
            this.Classic_tv_weather.setTextSize(12.0f);
            this.Classic_tv_compass.setTextSize(12.0f);
            this.Classic_tv_magnetic_field.setTextSize(12.0f);
        }
        if (!this.isAddress_classic) {
            if (!this.isMap_classic && ((!(z3 = this.isWeather_classic) && !this.isMagneticField_classic && !this.isCompass_classic && !this.isLatLng_classic && this.isDateTime_classic) || ((!z3 && !this.isMagneticField_classic && !this.isCompass_classic && !this.isDateTime_classic && this.isLatLng_classic) || (((z3 || this.isCompass_classic || this.isMagneticField_classic) && this.isDateTime_classic && !this.isLatLng_classic) || ((z3 || this.isCompass_classic || this.isMagneticField_classic) && !this.isDateTime_classic && this.isLatLng_classic))))) {
                if ((this.isDateTime_classic || this.isLatLng_classic) && this.isnotes_classic) {
                    if (this.isNumbering_classic || this.isPlusCode_classic) {
                        this.classic_tv_address_line_1.setMaxLines(5);
                    } else {
                        this.classic_tv_address_line_1.setMaxLines(3);
                    }
                } else if (this.isNumbering_classic || this.istimezone_classic || this.isPlusCode_classic) {
                    this.classic_tv_address_line_1.setMaxLines(3);
                } else {
                    this.classic_tv_address_line_1.setMaxLines(1);
                }
            } else if (this.isNumbering_classic || this.isPlusCode_classic) {
                this.classic_tv_address_line_1.setMaxLines(12);
            } else {
                this.classic_tv_address_line_1.setMaxLines(10);
            }
        } else if (this.isNumbering_classic || this.isPlusCode_classic) {
            this.classic_tv_address_line_1.setMaxLines(12);
        } else {
            this.classic_tv_address_line_1.setMaxLines(10);
        }
        if (this.isMap_classic) {
            boolean z5 = this.isAddress_classic;
            if (z5 && this.isLatLng_classic) {
                this.classic_tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 0.0f, getResources().getDisplayMetrics()), 1.0f);
            } else if (z5 && (this.isWeather_classic || this.isMagneticField_classic || this.isCompass_classic)) {
                this.classic_tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, getResources().getDisplayMetrics()), 1.0f);
            } else if (this.isWeather_classic || this.isMagneticField_classic || this.isCompass_classic) {
                this.classic_tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 5.0f, getResources().getDisplayMetrics()), 1.0f);
            } else {
                this.classic_tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, getResources().getDisplayMetrics()), 1.2f);
            }
            if (this.isMap_classic) {
                boolean z6 = this.isAddress_classic;
                if (z6 && this.isLatLng_classic) {
                    this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 0.0f, getResources().getDisplayMetrics()), 1.0f);
                } else if (z6 && (this.isWeather_classic || this.isMagneticField_classic || this.isCompass_classic)) {
                    this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, getResources().getDisplayMetrics()), 1.0f);
                } else if (this.isWeather_classic || this.isMagneticField_classic || this.isCompass_classic) {
                    this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 5.0f, getResources().getDisplayMetrics()), 1.0f);
                } else {
                    this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, getResources().getDisplayMetrics()), 1.2f);
                }
                String str = this.prefix_classic + " " + this.sequence_classic + " " + this.suffix_classic;
                if (this.islogo_classic) {
                    if (this.isNumbering_classic || this.isPlusCode_classic) {
                        if (this.isaccuracy_classic || this.isaltitude_classic || this.ispressure_classic || this.isHumidity_classic || this.iswind_classic) {
                            if (this.isnotes_classic && this.notes_classic.length() > 35) {
                                if (this.mStamp_size_classic.equals("Large")) {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_146);
                                    this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_146);
                                } else if (this.mStamp_size_classic.equals("Medium")) {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                                    this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                                } else if (this.mStamp_size_classic.equals("Small")) {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                                    this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                                } else {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                                    this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                                }
                            } else if (str.length() > 35) {
                                if (this.mStamp_size_classic.equals("Large")) {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_146);
                                    this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_146);
                                } else if (this.mStamp_size_classic.equals("Medium")) {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                                    this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                                } else if (this.mStamp_size_classic.equals("Small")) {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                                    this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                                } else {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                                    this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                                }
                            } else if (this.mStamp_size_classic.equals("Large")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                            } else if (this.mStamp_size_classic.equals("Medium")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                            } else if (this.mStamp_size_classic.equals("Small")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                            } else {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                            }
                        } else if (this.isnotes_classic && this.notes_classic.length() > 35) {
                            if (this.mStamp_size_classic.equals("Large")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                            } else if (this.mStamp_size_classic.equals("Medium")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                            } else if (this.mStamp_size_classic.equals("Small")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                            } else {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                            }
                        } else if (this.mStamp_size_classic.equals("Large")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_126);
                            this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_126);
                        } else if (this.mStamp_size_classic.equals("Medium")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                            this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                        } else if (this.mStamp_size_classic.equals("Small")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                            this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                        } else {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                            this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                        }
                    } else if (this.isnotes_classic && this.notes_classic.length() > 35) {
                        if (this.mStamp_size_classic.equals("Large")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                            this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                        } else if (this.mStamp_size_classic.equals("Medium")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                            this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                        } else if (this.mStamp_size_classic.equals("Small")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                            this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                        } else {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                            this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                        }
                    } else if (this.mStamp_size_classic.equals("Large")) {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                        this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                    } else if (this.mStamp_size_classic.equals("Medium")) {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                        this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                    } else if (this.mStamp_size_classic.equals("Small")) {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                        this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                    } else {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                        this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                    }
                } else if (this.isNumbering_classic || this.isPlusCode_classic) {
                    if (this.isaccuracy_classic || this.isaltitude_classic || this.ispressure_classic || this.isHumidity_classic || this.iswind_classic) {
                        if (this.isnotes_classic && this.notes_classic.length() > 35) {
                            if (this.mStamp_size_classic.equals("Large")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_126);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_126);
                            } else if (this.mStamp_size_classic.equals("Medium")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                            } else if (this.mStamp_size_classic.equals("Small")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                            } else {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                            }
                        } else if (str.length() > 35) {
                            if (this.isnotes_classic) {
                                if (this.mStamp_size_classic.equals("Large")) {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_126);
                                    this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_126);
                                } else if (this.mStamp_size_classic.equals("Medium")) {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                                    this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                                } else if (this.mStamp_size_classic.equals("Small")) {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                                    this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                                } else {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                                    this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                                }
                            } else if (this.mStamp_size_classic.equals("Large")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                            } else if (this.mStamp_size_classic.equals("Medium")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                            } else if (this.mStamp_size_classic.equals("Small")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                            } else {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                            }
                        } else if (this.isnotes_classic) {
                            if (this.mStamp_size_classic.equals("Large")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                            } else if (this.mStamp_size_classic.equals("Medium")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                            } else if (this.mStamp_size_classic.equals("Small")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                            } else {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                                this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                            }
                        } else if (this.mStamp_size_classic.equals("Large")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                            this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                        } else if (this.mStamp_size_classic.equals("Medium")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                            this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                        } else if (this.mStamp_size_classic.equals("Small")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                            this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                        } else {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                            this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                        }
                    } else if (this.mStamp_size_classic.equals("Large")) {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                        this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                    } else if (this.mStamp_size_classic.equals("Medium")) {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                        this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                    } else if (this.mStamp_size_classic.equals("Small")) {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                        this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                    } else {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                        this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                    }
                } else if (this.isnotes_classic && this.notes_classic.length() > 35) {
                    if (this.mStamp_size_classic.equals("Large")) {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                        this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                    } else if (this.mStamp_size_classic.equals("Medium")) {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                        this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                    } else if (this.mStamp_size_classic.equals("Small")) {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                        this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                    } else {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                        this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                    }
                } else if (this.mStamp_size_classic.equals("Large")) {
                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                    this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                } else if (this.mStamp_size_classic.equals("Medium")) {
                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                    this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                } else if (this.mStamp_size_classic.equals("Small")) {
                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_70);
                    this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_70);
                } else {
                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_55);
                    this.Classic_imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_55);
                }
            }
        } else {
            boolean z7 = this.isLatLng_classic;
            if (z7 || this.isAddress_classic || this.isMagneticField_classic || this.isWeather_classic || this.isCompass_classic) {
                boolean z8 = this.isAddress_classic;
                if (!z8) {
                    this.classic_tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, getResources().getDisplayMetrics()), 1.2f);
                    if ((!this.isDateTime_classic && !this.isLatLng_classic) || (this.classic_tv_address_line_1.getMaxLines() == 1 && ((!(z = this.isCompass_classic) && !this.isMagneticField_classic && !this.isWeather_classic) || (((z2 = this.isWeather_classic) && !z && !this.isMagneticField_classic) || ((z && !z2 && !this.isMagneticField_classic) || (this.isMagneticField_classic && !z2 && !z)))))) {
                        if (this.Classic_lin_bottom_wether.getVisibility() == 8 && !this.isCompass_classic && !this.isMagneticField_classic && !this.isWeather_classic) {
                            if ((this.isDateTime_classic || this.isLatLng_classic) && this.isnotes_classic) {
                                if (this.isNumbering_classic || this.isPlusCode_classic) {
                                    if (this.mStamp_size_classic.equals("Large")) {
                                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_100dp);
                                    } else {
                                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_45);
                                    }
                                } else if (this.mStamp_size_classic.equals("Large")) {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_90dp);
                                } else {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_35);
                                }
                            } else if (this.isNumbering_classic || this.isPlusCode_classic) {
                                if (this.mStamp_size_classic.equals("Large")) {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_80dp);
                                } else {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_30);
                                }
                            } else if (this.mStamp_size_classic.equals("Large")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_70dp);
                            } else {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_25);
                            }
                        } else if (this.islogo_classic) {
                            if (this.isNumbering_classic || this.isPlusCode_classic) {
                                if (this.mStamp_size_classic.equals("Large")) {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                                } else if (this.mStamp_size_classic.equals("Medium")) {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                                } else if (this.mStamp_size_classic.equals("Small")) {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                                } else {
                                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                                }
                            } else if (this.mStamp_size_classic.equals("Large")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                            } else if (this.mStamp_size_classic.equals("Medium")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                            } else if (this.mStamp_size_classic.equals("Small")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                            } else {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                            }
                        } else if (this.isNumbering_classic || this.isPlusCode_classic) {
                            if (this.mStamp_size_classic.equals("Large")) {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_100dp);
                            } else {
                                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_60);
                            }
                        } else if (this.mStamp_size_classic.equals("Large")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_90dp);
                        } else {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_50);
                        }
                    } else if (this.isNumbering_classic || this.isPlusCode_classic) {
                        if (this.mStamp_size_classic.equals("Large")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                        } else if (this.mStamp_size_classic.equals("Medium")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                        } else if (this.mStamp_size_classic.equals("Small")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                        } else {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                        }
                    } else if (this.mStamp_size_classic.equals("Large")) {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                    } else if (this.mStamp_size_classic.equals("Medium")) {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                    } else if (this.mStamp_size_classic.equals("Small")) {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                    } else {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                    }
                } else if (z8 && !z7) {
                    if (this.isNumbering_classic || this.isPlusCode_classic) {
                        if (this.mStamp_size_classic.equals("Large")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                        } else if (this.mStamp_size_classic.equals("Medium")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                        } else if (this.mStamp_size_classic.equals("Small")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                        } else {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                        }
                    } else {
                        this.classic_tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, getResources().getDisplayMetrics()), 1.2f);
                        if (this.mStamp_size_classic.equals("Large")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                        } else if (this.mStamp_size_classic.equals("Medium")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                        } else if (this.mStamp_size_classic.equals("Small")) {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                        } else {
                            this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                        }
                    }
                } else if (this.isNumbering_classic || this.isPlusCode_classic) {
                    if (this.mStamp_size_classic.equals("Large")) {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_130);
                    } else if (this.mStamp_size_classic.equals("Medium")) {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                    } else if (this.mStamp_size_classic.equals("Small")) {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                    } else {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                    }
                } else if (this.mStamp_size_classic.equals("Large")) {
                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                } else if (this.mStamp_size_classic.equals("Medium")) {
                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                } else if (this.mStamp_size_classic.equals("Small")) {
                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                } else {
                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                }
            } else if (this.isNumbering_classic || this.isPlusCode_classic) {
                if (this.mStamp_size_classic.equals("Large")) {
                    if (!this.isNumbering_classic) {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
                    } else if (!this.isPlusCode_classic) {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
                    } else {
                        this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_60);
                    }
                } else if (!this.isNumbering_classic) {
                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
                } else if (!this.isPlusCode_classic) {
                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
                } else {
                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_60);
                }
            } else if (this.mStamp_size_classic.equals("Large")) {
                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_70dp);
            } else if (!this.islogo_classic && !this.isnotes_classic) {
                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_35);
            } else {
                this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
            }
        }
        if (!this.isAddress_classic && !this.isLatLng_classic && !this.isDateTime_classic && !this.isnotes_classic && !this.iswind_classic && !this.isHumidity_classic && !this.isaccuracy_classic && !this.ispressure_classic && !this.isaltitude_classic && !this.isNumbering_classic && !this.istimezone_classic && !this.isPlusCode_classic) {
            this.Classic_li_address.setVisibility(View.GONE);
            this.Classic_li_rightView.setOrientation(0);
            this.Classic_li_rightView.setGravity(17);
            this.Classic_li_rightView.getLayoutParams().width = -1;
            this.Classic_li_rightView.getLayoutParams().width = -1;
            if (this.islogo_classic && !this.isMap_classic) {
                if (this.mStamp_size_classic.equals("Large")) {
                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_80dp);
                } else {
                    this.Classic_li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
                }
            }
        } else {
            this.Classic_li_address.setVisibility(View.VISIBLE);
            this.Classic_li_rightView.setOrientation(1);
            this.Classic_li_rightView.setGravity(19);
            this.Classic_li_rightView.getLayoutParams().width = -2;
            this.Classic_li_rightView.getLayoutParams().width = -2;
        }
        if (!this.isLatLng_classic && !this.isAddress_classic && !this.isMagneticField_classic && !this.isWeather_classic && !this.isCompass_classic && !this.isDateTime_classic && !this.isNumbering_classic && !this.istimezone_classic && !this.isMap_classic && !this.isnotes_classic && !this.iswind_classic && !this.isHumidity_classic && !this.isaccuracy_classic && !this.ispressure_classic && !this.isaltitude_classic && !this.islogo_classic && !this.isPlusCode_classic) {
            this.Classic_li_main_stamp_lay.setVisibility(View.GONE);
        } else {
            this.Classic_li_main_stamp_lay.setVisibility(View.VISIBLE);
            setTextClassic();
        }
        if (!this.isLatLng_classic && !this.isAddress_classic && !this.isDateTime_classic && !this.isnotes_classic && !this.isNumbering_classic && !this.istimezone_classic && !this.isPlusCode_classic) {
            this.classic_tv_address_line_1.setVisibility(View.GONE);
        } else {
            this.classic_tv_address_line_1.setVisibility(View.VISIBLE);
        }
        if (this.isMap_classic && !this.isAddress_classic && !this.isCompass_classic && !this.isDateTime_classic && !this.isNumbering_classic && !this.istimezone_classic && !this.isLatLng_classic && !this.isMagneticField_classic && !this.isWeather_classic && !this.isnotes_classic && !this.iswind_classic && !this.isHumidity_classic && !this.isaccuracy_classic && !this.ispressure_classic && !this.isaltitude_classic && !this.islogo_classic && !this.isPlusCode_classic) {
            this.Classic_li_stamp.setVisibility(4);
            i = 0;
        } else {
            i = 0;
            this.Classic_li_stamp.setVisibility(View.VISIBLE);
        }
        if (this.sharedPreferences.getString(SP.STAMP_POS_CLASSIC, "Bottom").equals("Bottom")) {
            this.Classic_lin_waterma.setVisibility(i);
            this.Classic_lin_waterma_2.setVisibility(View.GONE);
            ((GradientDrawable) this.Classic_lin_waterma.getBackground().getCurrent()).setColor(this.background_color_classic);
        } else {
            this.Classic_lin_waterma.setVisibility(View.GONE);
            this.Classic_lin_waterma_2.setVisibility(View.VISIBLE);
            ((GradientDrawable) this.Classic_lin_waterma_2.getBackground().getCurrent()).setColor(this.background_color_classic);
        }
        if (this.mStamp_size_classic.equals("Small") || this.mStamp_size_classic.equals("Medium")) {
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.Classic_imgstamp_1.getLayoutParams();
            layoutParams2.height = Util.dpToPx(this, 20);
            layoutParams2.width = Util.dpToPx(this, 20);
            LinearLayout.LayoutParams layoutParams3 = (LinearLayout.LayoutParams) this.Classic_imgstamp_2.getLayoutParams();
            layoutParams3.height = Util.dpToPx(this, 20);
            layoutParams3.width = Util.dpToPx(this, 20);
            this.Classic_txt_watermark_1.setTextSize(7.0f);
            this.Classic_txt_watermark_2.setTextSize(7.0f);
        } else if (this.mStamp_size_classic.equals("Extra Small")) {
            LinearLayout.LayoutParams layoutParams4 = (LinearLayout.LayoutParams) this.Classic_imgstamp_1.getLayoutParams();
            layoutParams4.height = Util.dpToPx(this, 14);
            layoutParams4.width = Util.dpToPx(this, 14);
            LinearLayout.LayoutParams layoutParams5 = (LinearLayout.LayoutParams) this.Classic_imgstamp_2.getLayoutParams();
            layoutParams5.height = Util.dpToPx(this, 14);
            layoutParams5.width = Util.dpToPx(this, 14);
            this.Classic_txt_watermark_1.setTextSize(5.0f);
            this.Classic_txt_watermark_2.setTextSize(5.0f);
        } else {
            LinearLayout.LayoutParams layoutParams6 = (LinearLayout.LayoutParams) this.Classic_imgstamp_1.getLayoutParams();
            layoutParams6.height = Util.dpToPx(this, 24);
            layoutParams6.width = Util.dpToPx(this, 24);
            LinearLayout.LayoutParams layoutParams7 = (LinearLayout.LayoutParams) this.Classic_imgstamp_2.getLayoutParams();
            layoutParams7.height = Util.dpToPx(this, 24);
            layoutParams7.width = Util.dpToPx(this, 24);
            this.Classic_txt_watermark_1.setTextSize(9.0f);
            this.Classic_txt_watermark_2.setTextSize(9.0f);
        }
        ((GradientDrawable) this.Classic_li_stamp.getBackground().getCurrent()).setColor(this.background_color_classic);
        setMapTypeclassic();
    }

    private void setMapTypeclassic() {
        String str = this.mMap_Type_classic;
        str.hashCode();
        char c = 65535;
        switch (str.hashCode()) {
            case -1579103941:
                if (str.equals("satellite")) {
                    c = 0;
                    break;
                }
                break;
            case -1423437003:
                if (str.equals("terrain")) {
                    c = 1;
                    break;
                }
                break;
            case -1202757124:
                if (str.equals("hybrid")) {
                    c = 2;
                    break;
                }
                break;
            case 1366708796:
                if (str.equals("roadmap")) {
                    c = 3;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                this.Classic_imgMap.setImageResource(R.drawable.setellite);
                return;
            case 1:
                this.Classic_imgMap.setImageResource(R.drawable.tarrain);
                return;
            case 2:
                this.Classic_imgMap.setImageResource(R.drawable.hybrid);
                return;
            case 3:
                this.Classic_imgMap.setImageResource(R.drawable.normal);
                return;
            default:
                return;
        }
    }

    private void setTextClassic() {
        String str;
        int i;
        String trim = this.mSP.getString(this, SP.LOC_LINE_1_ADDRESS, "").trim();
        String trim2 = this.mSP.getString(this, SP.LOC_LINE_2_CITY, "").trim();
        String trim3 = this.mSP.getString(this, SP.LOC_LINE_3_STATE, "").trim();
        String trim4 = this.mSP.getString(this, SP.LOC_LINE_4_COUNTRY, "").trim();
        String trim5 = this.mSP.getString(this, SP.PLUS_CODE, "").trim();
        if (!trim5.isEmpty() && this.mPluscode_type_classic.equals("concise")) {
            trim5 = trim5.substring(4);
        }
        if (trim2 == null || trim2.isEmpty()) {
            str = "";
        } else {
            str = "" + trim2 + ", ";
        }
        if (trim3 != null && !trim3.isEmpty()) {
            str = str + "" + trim3 + ", ";
        }
        if (trim4 != null && !trim4.isEmpty()) {
            str = str + trim4;
        }
        if (str != null && str.endsWith(", ")) {
            str = str.substring(0, str.length() - 2);
        }
        String coloredSpanned = (trim == null || trim.isEmpty()) ? "" : getColoredSpanned(trim, this.address_color_classic);
        String coloredSpanned2 = getColoredSpanned(this.mUtil.getLatLong(this, this.mLatLngType_classic), this.lat_lng_color_classic);
        Log.e("latLong111 : ", coloredSpanned2);
        if (coloredSpanned2 != null && (i = this.mLatLngType_classic) != 6 && i != 7 && coloredSpanned2.length() > 55 && this.isMap_classic && !this.isWeather_classic && !this.isMagneticField_classic && !this.isCompass_classic) {
            String[] split = coloredSpanned2.split(" Long");
            coloredSpanned2 = split[0] + "<br/>Long " + split[1];
        }
        boolean z = this.isAddress_classic;
        if (z) {
            if (this.isLatLng_classic) {
                coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned2;
            }
        } else if (this.isLatLng_classic && !z) {
            coloredSpanned = coloredSpanned2;
        }
        if (this.isPlusCode_classic) {
            String coloredSpanned3 = getColoredSpanned("Plus Code : " + trim5, this.plus_code_color_classic);
            if (this.isAddress_classic || this.isLatLng_classic) {
                coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned3;
            } else {
                coloredSpanned = coloredSpanned3;
            }
        }
        if (this.isDateTime_classic) {
            String coloredSpanned4 = getColoredSpanned(Util.setDateTimeFormat(this.mSP.getString(this, SP.DATE_FORMAT_CLASSIC, "dd/MM/yy hh:mm a")), this.date_time_color_classic);
            if (this.isAddress_classic || this.isLatLng_classic || this.isPlusCode_classic) {
                coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned4;
            } else {
                coloredSpanned = coloredSpanned4;
            }
        }
        if (this.istimezone_classic) {
            String coloredSpanned5 = getColoredSpanned(getTimezone(this.mSP.getInteger(this, SP.TIMEZONE_CLASSIC, 6)), this.date_time_color_classic);
            if (!this.isDateTime_classic) {
                if (this.isAddress_classic || this.isLatLng_classic || this.isPlusCode_classic) {
                    coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned5;
                } else {
                    coloredSpanned = coloredSpanned5;
                }
            } else {
                coloredSpanned = coloredSpanned + " " + coloredSpanned5;
            }
        }
        if (this.isnotes_classic) {
            String coloredSpanned6 = getColoredSpanned(this.mSP.getString(this, SP.NOTES_HASHTAG_CLASSIC, "Note : Captured by GPS Map Camera"), this.note_hastag_color_classic);
            if (this.isAddress_classic || this.isLatLng_classic || this.isDateTime_classic || this.istimezone_classic || this.isPlusCode_classic) {
                coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned6;
            } else {
                coloredSpanned = coloredSpanned6;
            }
        }
        if (this.isNumbering_classic) {
            String coloredSpanned7 = getColoredSpanned((this.prefix_classic + " " + this.sequence_classic + " " + this.suffix_classic).trim(), this.numbering_color_classic);
            if (this.isAddress_classic || this.isLatLng_classic || this.isDateTime_classic || this.istimezone_classic || this.isnotes_classic || this.isPlusCode_classic) {
                coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned7;
            } else {
                coloredSpanned = coloredSpanned7;
            }
        }
        if (this.iswind_classic) {
            this.Classic_tv_wind.setText(Util.getwindConvert(this, this.wind_selected_classic));
            this.Classic_tv_wind.setTextColor(this.wind_color_classic);
            this.Classic_img_wind_stamp.setImageResource(R.drawable.ic_wind);
        }
        if (this.isCompass_classic) {
            this.Classic_tv_compass.setText(this.mSP.getString(this, SP.COMPASS_VALUE, ""));
            this.Classic_tv_compass.setTextColor(this.compass_color_classic);
        }
        if (this.isWeather_classic) {
            if (this.msTemprature_type_classic.equals("Celsius")) {
                this.Classic_tv_weather.setText(Util.getCelcius(this.mfTemprature_value));
            } else {
                this.Classic_tv_weather.setText(Util.getFahrenheit(this.mfTemprature_value));
            }
            this.Classic_tv_weather.setTextColor(this.weather_color_classic);
        }
        if (this.isMagneticField_classic) {
            this.Classic_tv_magnetic_field.setText(this.mSP.getString(this, SP.MAGNETIC_FIELD_VALUE, ""));
            this.Classic_tv_magnetic_field.setTextColor(this.magnetic_field_color_classic);
        }
        if (this.isHumidity_classic) {
            this.Classic_tv_humidity.setText(this.mSP.getString(this, SP.HUMIDITY_VALUE, "") + "%");
            this.Classic_tv_humidity.setTextColor(this.Humidity_color_classic);
            this.Classic_img_humidity_stamp.setImageResource(R.drawable.ic_humidity);
        }
        if (this.ispressure_classic) {
            this.Classic_tv_pressure.setText(Util.getpressureConvert(this, this.pressure_selection_classic));
            this.Classic_tv_pressure.setTextColor(this.pressure_color_classic);
            this.Classic_img_pressure_stamp.setImageResource(R.drawable.ic_pressure);
        }
        if (coloredSpanned.contains("null")) {
            coloredSpanned = coloredSpanned.replace("null", "Loading");
        }
        this.classic_tv_address_line_1.setText(Html.fromHtml(coloredSpanned));
        if (str != null && !str.isEmpty() && this.isAddress_classic) {
            this.Classic_tv_address.setVisibility(View.VISIBLE);
            if (str.equalsIgnoreCase("null")) {
                str = "Loading";
            }
            this.Classic_tv_address.setText(Html.fromHtml(getColoredSpanned(str, this.address_color_classic)));
        } else {
            this.Classic_tv_address.setVisibility(View.GONE);
        }
        if (this.Logo_img_classic.equals("no_logo")) {
            this.Classic_imgLogo.setImageResource(R.mipmap.ic_launcher);
        } else {
            ExecutorService newSingleThreadExecutor = Executors.newSingleThreadExecutor();
            final Handler handler = new Handler();
            newSingleThreadExecutor.execute(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.TempletSelectionActivity.4
                @Override // java.lang.Runnable
                public void run() {
                    final Bitmap decodeBase64 = Util.decodeBase64(TempletSelectionActivity.this.Logo_img_classic);
                    handler.post(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.TempletSelectionActivity.4.1
                        @Override // java.lang.Runnable
                        public void run() {
                            Glide.with((FragmentActivity) TempletSelectionActivity.this).load(decodeBase64).into(TempletSelectionActivity.this.Classic_imgLogo);
                        }
                    });
                }
            });
        }
        this.Classic_tv_humidity.setTypeface(Util.getFontStyle(this, this.font_style_classic));
        this.Classic_tv_wind.setTypeface(Util.getFontStyle(this, this.font_style_classic));
        this.Classic_tv_pressure.setTypeface(Util.getFontStyle(this, this.font_style_classic));
        this.classic_tv_address_line_1.setTypeface(Util.getFontStyle(this, this.font_style_classic));
        this.Classic_tv_address.setTypeface(Util.getFontStyle(this, this.font_style_classic));
        this.Classic_tv_weather.setTypeface(Util.getFontStyle(this, this.font_style_classic));
        this.Classic_tv_compass.setTypeface(Util.getFontStyle(this, this.font_style_classic));
        this.Classic_tv_magnetic_field.setTypeface(Util.getFontStyle(this, this.font_style_classic));
    }

    private void setadavnceTemplet() {
        boolean z;
        boolean z2;
        int i;
        boolean z3;
        this.mWeatherIcon = getResources().obtainTypedArray(R.array.wI);
        this.background_color = this.mSP.getInteger(this, SP.BACKGROUND_COLOR, Color.parseColor("#9c000000"));
        this.address_color = this.mSP.getInteger(this, SP.ADDRESS_COLOR, -1);
        this.date_time_color = this.mSP.getInteger(this, SP.DATE_TIME_COLOR, -1);
        this.lat_lng_color = this.mSP.getInteger(this, SP.LAT_LNG_COLOR, -1);
        this.plus_code_color = this.mSP.getInteger(this, SP.PLUS_CODE_COLOR, -1);
        this.weather_color = this.mSP.getInteger(this, SP.WEATHER_COLOR, -1);
        this.magnetic_field_color = this.mSP.getInteger(this, SP.MAGNETIC_FIELD_COLOR, -1);
        this.compass_color = this.mSP.getInteger(this, SP.COMPASS_COLOR, -1);
        this.note_hastag_color = this.mSP.getInteger(this, SP.NOTES_HASHTAG_COLOR, -1);
        this.wind_color = this.mSP.getInteger(this, SP.WIND_COLOR, -1);
        this.Humidity_color = this.mSP.getInteger(this, SP.HUMIDITY_COLOR, -1);
        this.pressure_color = this.mSP.getInteger(this, SP.PRESSURE_COLOR, -1);
        this.elevation_color = this.mSP.getInteger(this, SP.ELEVATION_COLOR, -1);
        this.altitude_color = this.mSP.getInteger(this, SP.ALTITUDE_COLOR, -1);
        this.accuracy_color = this.mSP.getInteger(this, SP.ACCURACY_COLOR, -1);
        this.numbering_color = this.mSP.getInteger(this, SP.NUMBERING_COLOR, -1);
        this.timezone = this.mSP.getInteger(this, SP.TIMEZONE, 6);
        this.sequence = this.mSP.getInteger(this, SP.SEQUENCE, 1);
        this.suffix = this.mSP.getString(this, SP.SUFFIX, "");
        this.prefix = this.mSP.getString(this, SP.PREFIX, "");
        this.isMap = this.mSP.getBoolean(this, SP.IS_MAP, true);
        this.isAddress = this.mSP.getBoolean(this, SP.IS_ADDRESS, true);
        this.isLatLng = this.mSP.getBoolean(this, SP.IS_LAT_LNG_TEMPLATE, true);
        this.isPlusCode = this.mSP.getBoolean(this, SP.IS_PLUS_CODE, false);
        this.isWeather = this.mSP.getBoolean(this, SP.IS_WEATHER, false);
        this.isDateTime = this.mSP.getBoolean(this, SP.IS_DATE_TIME, true);
        this.isNumbering = this.mSP.getBoolean(this, SP.IS_NUMBERING, false);
        this.istimezone = this.mSP.getBoolean(this, SP.IS_TIMEZONE, true);
        this.isMagneticField = this.mSP.getBoolean(this, SP.IS_MAGNETIC_FIELD, false);
        this.isCompass = this.mSP.getBoolean(this, SP.IS_COMPASS, false);
        this.iswind = this.mSP.getBoolean(this, SP.IS_WIND, false);
        this.islogo = this.mSP.getBoolean(this, SP.IS_LOGO, false);
        this.isnotes = this.mSP.getBoolean(this, SP.IS_NOTES, false);
        this.ispressure = this.mSP.getBoolean(this, SP.IS_PRESSURE, false);
        this.isHumidity = this.mSP.getBoolean(this, SP.IS_HUMIDITY, false);
        this.iselevation = this.mSP.getBoolean(this, SP.IS_ELEVATION, false);
        this.isaltitude = this.mSP.getBoolean(this, SP.IS_ALTITUDE, false);
        this.isaccuracy = this.mSP.getBoolean(this, SP.IS_ACCURACY, false);
        this.Logo_img = this.mSP.getString(this, SP.LOGO_URI, "no_logo");
        this.notes = this.mSP.getString(this, SP.NOTES_HASHTAG, "Note : Captured by GPS Map Camera");
        this.font_style = this.mSP.getString(this, SP.STAMP_FONT_STYLE, "sfuitext_regular.otf");
        this.isCompassFound = this.mSP.getBoolean(this, SP.COMPASS_FOUND, false);
        this.mDateFormat = this.mSP.getString(this, SP.DATE_FORMAT, "dd/MM/yy hh:mm a");
        this.mLatLngType = this.mSP.getInteger(this, SP.LAT_LNG_TYPE, 1);
        this.msTemprature_type = this.mSP.getString(this, SP.TEMPRATURE_TYPE, "Celsius");
        this.mfTemprature_value = this.mSP.getFloat(this, SP.TEMPRETURE_VALUE);
        int integer = this.mSP.getInteger(this, SP.WEATHER_ICON, 0);
        this.mIconValue = integer;
        this.imgWeather.setImageResource(this.mWeatherIcon.getResourceId(integer, 0));
        this.mMap_Type = this.mSP.getString(this, SP.MAP_TYPE_TEMPLATE, "satellite");
        this.mPos_mapType = this.mSP.getInteger(this, SP.MAP_POS, 1);
        this.mStamp_Pos = this.mSP.getString(this, SP.STAMP_POS, "Bottom");
        SP sp = this.mSP;
        String str = "Medium";
        this.mStamp_size = sp.getString(this, SP.STAMP_SIZE, str);
        this.mPluscode_type = this.mSP.getString(this, SP.PLUS_CODE_TYPE, "accurate");
        this.wind_selected = this.mSP.getInteger(this, SP.WIND_SELECT, 0);
        this.altitude_selection = this.mSP.getInteger(this, SP.ALTITUDE_SELECT, 0);
        this.accuracy_selection = this.mSP.getInteger(this, SP.ACCURACY_SELECT, 0);
        this.pressure_selection = this.mSP.getInteger(this, SP.PRESSURE_SELECT, 0);
        boolean z4 = getResources().getBoolean(R.bool.isTablet);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        if (this.isMap) {
            this.imgMap.setVisibility(View.VISIBLE);
            layoutParams.setMargins((int) getResources().getDimension(R.dimen._8dp), 0, 0, 0);
        } else {
            this.imgMap.setVisibility(View.GONE);
            layoutParams.setMargins((int) getResources().getDimension(R.dimen._8dp), 0, 0, 0);
        }
        this.li_stamp.setLayoutParams(layoutParams);
        if (this.isWeather) {
            this.li_weather.setVisibility(View.VISIBLE);
        } else {
            this.li_weather.setVisibility(View.GONE);
        }
        if (this.isHumidity || this.isaccuracy || this.isaltitude || this.iswind || this.ispressure) {
            this.lin_bottom_wether.setVisibility(View.VISIBLE);
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.lin_bottom_wether.getLayoutParams();
            if (z4) {
                ((LinearLayout.LayoutParams) this.lin_bottom_wether.getLayoutParams()).height += 2;
            }
        } else {
            this.lin_bottom_wether.setVisibility(View.GONE);
        }
        if (this.iswind) {
            this.lin_wind_stamp.setVisibility(View.VISIBLE);
        } else {
            this.lin_wind_stamp.setVisibility(View.GONE);
        }
        if (this.isHumidity) {
            this.lin_humity_stamp.setVisibility(View.VISIBLE);
        } else {
            this.lin_humity_stamp.setVisibility(View.GONE);
        }
        if (this.ispressure) {
            this.lin_pressure_stamp.setVisibility(View.VISIBLE);
        } else {
            this.lin_pressure_stamp.setVisibility(View.GONE);
        }
        if (this.isaltitude) {
            String altitudeconvert = Util.getAltitudeconvert(this, this.altitude_selection);
            if (this.lin_pressure_stamp.getVisibility() == 8) {
                this.lin_pressure_stamp.setVisibility(View.VISIBLE);
                this.img_pressure_stamp.setImageResource(R.drawable.ic_altitiude);
                this.tv_pressure.setText(altitudeconvert);
                this.tv_pressure.setTextColor(this.altitude_color);
            } else if (this.lin_wind_stamp.getVisibility() == 8) {
                this.lin_wind_stamp.setVisibility(View.VISIBLE);
                this.img_wind_stamp.setImageResource(R.drawable.ic_altitiude);
                this.tv_wind.setText(altitudeconvert);
                this.tv_wind.setTextColor(this.altitude_color);
            } else if (this.lin_humity_stamp.getVisibility() == 8) {
                this.lin_humity_stamp.setVisibility(View.VISIBLE);
                this.img_humidity_stamp.setImageResource(R.drawable.ic_altitiude);
                this.tv_humidity.setText(altitudeconvert);
                this.tv_humidity.setTextColor(this.altitude_color);
            }
        }
        if (this.isaccuracy) {
            String accuracy = Util.getAccuracy(this, this.accuracy_selection);
            if (this.lin_pressure_stamp.getVisibility() == 8) {
                this.lin_pressure_stamp.setVisibility(View.VISIBLE);
                this.img_pressure_stamp.setImageResource(R.drawable.ic_accuracy);
                this.tv_pressure.setText(accuracy);
                this.tv_pressure.setTextColor(this.accuracy_color);
            } else if (this.lin_wind_stamp.getVisibility() == 8) {
                this.lin_wind_stamp.setVisibility(View.VISIBLE);
                this.img_wind_stamp.setImageResource(R.drawable.ic_accuracy);
                this.tv_wind.setText(accuracy);
                this.tv_wind.setTextColor(this.accuracy_color);
            } else if (this.lin_humity_stamp.getVisibility() == 8) {
                this.lin_humity_stamp.setVisibility(View.VISIBLE);
                this.img_humidity_stamp.setImageResource(R.drawable.ic_accuracy);
                this.tv_humidity.setText(accuracy);
                this.tv_humidity.setTextColor(this.accuracy_color);
            }
        }
        if (this.isCompassFound) {
            if (this.isMagneticField) {
                this.li_magnetic_field.setVisibility(View.VISIBLE);
            } else {
                this.li_magnetic_field.setVisibility(View.GONE);
            }
            if (this.isCompass) {
                this.li_compass.setVisibility(View.VISIBLE);
            } else {
                this.li_compass.setVisibility(View.GONE);
            }
        } else {
            this.li_magnetic_field.setVisibility(View.GONE);
            this.li_compass.setVisibility(View.GONE);
        }
        if (this.isWeather || this.isMagneticField || this.isCompass || this.islogo) {
            this.li_rightView.setVisibility(View.VISIBLE);
        } else {
            this.li_rightView.setVisibility(View.GONE);
        }
        if (this.islogo) {
            this.li_logo.setVisibility(View.VISIBLE);
        } else {
            this.li_logo.setVisibility(View.GONE);
        }
        if (this.mStamp_size.equals(str)) {
            this.imgLogo.getLayoutParams().height = Util.dpToPx(this, 30);
            this.imgLogo.getLayoutParams().width = Util.dpToPx(this, 58);
            this.imgWeather.getLayoutParams().height = Util.dpToPx(this, 16);
            this.imgWeather.getLayoutParams().width = Util.dpToPx(this, 16);
            this.imgCompass.getLayoutParams().height = Util.dpToPx(this, 16);
            this.imgCompass.getLayoutParams().width = Util.dpToPx(this, 16);
            this.img_humidity_stamp.getLayoutParams().height = Util.dpToPx(this, 16);
            this.img_humidity_stamp.getLayoutParams().width = Util.dpToPx(this, 16);
            this.img_pressure_stamp.getLayoutParams().height = Util.dpToPx(this, 16);
            this.img_pressure_stamp.getLayoutParams().width = Util.dpToPx(this, 16);
            this.img_wind_stamp.getLayoutParams().height = Util.dpToPx(this, 16);
            this.img_wind_stamp.getLayoutParams().width = Util.dpToPx(this, 16);
            this.img_magnetic_field.getLayoutParams().height = Util.dpToPx(this, 16);
            this.img_magnetic_field.getLayoutParams().width = Util.dpToPx(this, 16);
            this.tv_wind.setTextSize(10.0f);
            this.tv_pressure.setTextSize(10.0f);
            this.tv_humidity.setTextSize(10.0f);
            this.tv_weather.setTextSize(10.0f);
            this.tv_compass.setTextSize(10.0f);
            this.tv_magnetic_field.setTextSize(10.0f);
        } else if (this.mStamp_size.equals("Small")) {
            this.imgLogo.getLayoutParams().height = Util.dpToPx(this, 28);
            this.imgLogo.getLayoutParams().width = Util.dpToPx(this, 54);
            this.imgWeather.getLayoutParams().height = Util.dpToPx(this, 14);
            this.imgWeather.getLayoutParams().width = Util.dpToPx(this, 14);
            this.imgCompass.getLayoutParams().height = Util.dpToPx(this, 14);
            this.imgCompass.getLayoutParams().width = Util.dpToPx(this, 14);
            this.img_humidity_stamp.getLayoutParams().height = Util.dpToPx(this, 14);
            this.img_humidity_stamp.getLayoutParams().width = Util.dpToPx(this, 14);
            this.img_pressure_stamp.getLayoutParams().height = Util.dpToPx(this, 14);
            this.img_pressure_stamp.getLayoutParams().width = Util.dpToPx(this, 14);
            this.img_wind_stamp.getLayoutParams().height = Util.dpToPx(this, 14);
            this.img_wind_stamp.getLayoutParams().width = Util.dpToPx(this, 14);
            this.img_magnetic_field.getLayoutParams().height = Util.dpToPx(this, 14);
            this.img_magnetic_field.getLayoutParams().width = Util.dpToPx(this, 14);
            this.tv_wind.setTextSize(8.0f);
            this.tv_pressure.setTextSize(8.0f);
            this.tv_humidity.setTextSize(8.0f);
            this.tv_weather.setTextSize(8.0f);
            this.tv_compass.setTextSize(8.0f);
            this.tv_magnetic_field.setTextSize(8.0f);
        } else if (this.mStamp_size.equals("Extra Small")) {
            this.imgLogo.getLayoutParams().height = Util.dpToPx(this, 26);
            this.imgLogo.getLayoutParams().width = Util.dpToPx(this, 50);
            this.imgWeather.getLayoutParams().height = Util.dpToPx(this, 12);
            this.imgWeather.getLayoutParams().width = Util.dpToPx(this, 12);
            this.imgCompass.getLayoutParams().height = Util.dpToPx(this, 12);
            this.imgCompass.getLayoutParams().width = Util.dpToPx(this, 12);
            this.img_humidity_stamp.getLayoutParams().height = Util.dpToPx(this, 12);
            this.img_humidity_stamp.getLayoutParams().width = Util.dpToPx(this, 12);
            this.img_pressure_stamp.getLayoutParams().height = Util.dpToPx(this, 12);
            this.img_pressure_stamp.getLayoutParams().width = Util.dpToPx(this, 12);
            this.img_wind_stamp.getLayoutParams().height = Util.dpToPx(this, 12);
            this.img_wind_stamp.getLayoutParams().width = Util.dpToPx(this, 12);
            this.img_magnetic_field.getLayoutParams().height = Util.dpToPx(this, 12);
            this.img_magnetic_field.getLayoutParams().width = Util.dpToPx(this, 12);
            this.tv_wind.setTextSize(6.0f);
            this.tv_pressure.setTextSize(6.0f);
            this.tv_humidity.setTextSize(6.0f);
            this.tv_weather.setTextSize(6.0f);
            this.tv_compass.setTextSize(6.0f);
            this.tv_magnetic_field.setTextSize(6.0f);
        } else {
            this.imgLogo.getLayoutParams().height = Util.dpToPx(this, 32);
            this.imgLogo.getLayoutParams().width = Util.dpToPx(this, 62);
            this.imgWeather.getLayoutParams().height = Util.dpToPx(this, 18);
            this.imgWeather.getLayoutParams().width = Util.dpToPx(this, 18);
            this.imgCompass.getLayoutParams().height = Util.dpToPx(this, 18);
            this.imgCompass.getLayoutParams().width = Util.dpToPx(this, 18);
            this.img_humidity_stamp.getLayoutParams().height = Util.dpToPx(this, 18);
            this.img_humidity_stamp.getLayoutParams().width = Util.dpToPx(this, 18);
            this.img_pressure_stamp.getLayoutParams().height = Util.dpToPx(this, 18);
            this.img_pressure_stamp.getLayoutParams().width = Util.dpToPx(this, 18);
            this.img_wind_stamp.getLayoutParams().height = Util.dpToPx(this, 18);
            this.img_wind_stamp.getLayoutParams().width = Util.dpToPx(this, 18);
            this.img_magnetic_field.getLayoutParams().height = Util.dpToPx(this, 18);
            this.img_magnetic_field.getLayoutParams().width = Util.dpToPx(this, 18);
            this.tv_wind.setTextSize(12.0f);
            this.tv_pressure.setTextSize(12.0f);
            this.tv_humidity.setTextSize(12.0f);
            this.tv_weather.setTextSize(12.0f);
            this.tv_compass.setTextSize(12.0f);
            this.tv_magnetic_field.setTextSize(12.0f);
        }
        if (!this.isAddress) {
            if (!this.isMap && ((!(z3 = this.isWeather) && !this.isMagneticField && !this.isCompass && !this.isLatLng && this.isDateTime) || ((!z3 && !this.isMagneticField && !this.isCompass && !this.isDateTime && this.isLatLng) || (((z3 || this.isCompass || this.isMagneticField) && this.isDateTime && !this.isLatLng) || ((z3 || this.isCompass || this.isMagneticField) && !this.isDateTime && this.isLatLng))))) {
                if ((this.isDateTime || this.isLatLng) && this.isnotes) {
                    if (this.isNumbering || this.isPlusCode) {
                        this.tv_address_line_1.setMaxLines(5);
                    } else {
                        this.tv_address_line_1.setMaxLines(3);
                    }
                } else if (this.isNumbering || this.istimezone || this.isPlusCode) {
                    this.tv_address_line_1.setMaxLines(3);
                } else {
                    this.tv_address_line_1.setMaxLines(1);
                }
            } else if (this.isNumbering || this.isPlusCode) {
                this.tv_address_line_1.setMaxLines(12);
            } else {
                this.tv_address_line_1.setMaxLines(10);
            }
        } else if (this.isNumbering || this.isPlusCode) {
            this.tv_address_line_1.setMaxLines(12);
        } else {
            this.tv_address_line_1.setMaxLines(10);
        }
        if (this.isMap) {
            boolean z5 = this.isAddress;
            if (z5 && this.isLatLng) {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 0.0f, getResources().getDisplayMetrics()), 1.0f);
            } else if (z5 && (this.isWeather || this.isMagneticField || this.isCompass)) {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, getResources().getDisplayMetrics()), 1.0f);
            } else if (this.isWeather || this.isMagneticField || this.isCompass) {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 5.0f, getResources().getDisplayMetrics()), 1.0f);
            } else {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, getResources().getDisplayMetrics()), 1.2f);
            }
            String str2 = this.prefix + " " + this.sequence + " " + this.suffix;
            if (this.islogo) {
                if (this.isNumbering || this.isPlusCode) {
                    if (this.isaccuracy || this.isaltitude || this.ispressure || this.isHumidity || this.iswind) {
                        if (this.isnotes && this.notes.length() > 35) {
                            if (this.mStamp_size.equals("Large")) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_146);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_146);
                            } else if (this.mStamp_size.equals(str)) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                            } else if (this.mStamp_size.equals("Small")) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                            } else {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                            }
                        } else if (str2.length() > 35) {
                            if (this.mStamp_size.equals("Large")) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_146);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_146);
                            } else if (this.mStamp_size.equals(str)) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                            } else if (this.mStamp_size.equals("Small")) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                            } else {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                            }
                        } else if (this.mStamp_size.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                        } else if (this.mStamp_size.equals(str)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                        } else if (this.mStamp_size.equals("Small")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                        }
                    } else if (this.isnotes && this.notes.length() > 35) {
                        if (this.mStamp_size.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                        } else if (this.mStamp_size.equals(str)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                        } else if (this.mStamp_size.equals("Small")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                        }
                    } else if (this.mStamp_size.equals("Large")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                    } else if (this.mStamp_size.equals(str)) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                    } else if (this.mStamp_size.equals("Small")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                    } else {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                    }
                } else if (this.isnotes && this.notes.length() > 35) {
                    if (this.mStamp_size.equals("Large")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_136);
                    } else if (this.mStamp_size.equals(str)) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                    } else if (this.mStamp_size.equals("Small")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                    } else {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                    }
                } else if (this.mStamp_size.equals("Large")) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                } else if (this.mStamp_size.equals(str)) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                } else if (this.mStamp_size.equals("Small")) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                } else {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                }
            } else if (this.isNumbering || this.isPlusCode) {
                if (this.isaccuracy || this.isaltitude || this.ispressure || this.isHumidity || this.iswind) {
                    if (this.isnotes && this.notes.length() > 35) {
                        if (this.mStamp_size.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_126);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_126);
                        } else if (this.mStamp_size.equals(str)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                        } else if (this.mStamp_size.equals("Small")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                        }
                    } else if (str2.length() > 35) {
                        if (this.isnotes) {
                            if (this.mStamp_size.equals("Large")) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_126);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_126);
                            } else if (this.mStamp_size.equals(str)) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                            } else if (this.mStamp_size.equals("Small")) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                            } else {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                            }
                        } else if (this.mStamp_size.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                        } else if (this.mStamp_size.equals(str)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                        } else if (this.mStamp_size.equals("Small")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                        }
                    } else if (this.isnotes) {
                        if (this.mStamp_size.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                        } else if (this.mStamp_size.equals(str)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                        } else if (this.mStamp_size.equals("Small")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                            this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                        }
                    } else if (this.mStamp_size.equals("Large")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                    } else if (this.mStamp_size.equals(str)) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                    } else if (this.mStamp_size.equals("Small")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                    } else {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                        this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                    }
                } else if (this.mStamp_size.equals("Large")) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                } else if (this.mStamp_size.equals(str)) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                } else if (this.mStamp_size.equals("Small")) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                } else {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                }
            } else if (this.isnotes && this.notes.length() > 35) {
                if (this.mStamp_size.equals("Large")) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                } else if (this.mStamp_size.equals(str)) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                } else if (this.mStamp_size.equals("Small")) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                } else {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                    this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                }
            } else if (this.mStamp_size.equals("Large")) {
                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_100);
            } else if (this.mStamp_size.equals(str)) {
                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_85);
            } else if (this.mStamp_size.equals("Small")) {
                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_70);
                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_70);
            } else {
                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_55);
                this.imgMap.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_55);
            }
        } else {
            boolean z6 = this.isLatLng;
            if (z6 || this.isAddress || this.isMagneticField || this.isWeather || this.isCompass) {
                boolean z7 = this.isAddress;
                if (!z7) {
                    this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, getResources().getDisplayMetrics()), 1.2f);
                    if ((!this.isDateTime && !this.isLatLng) || (this.tv_address_line_1.getMaxLines() == 1 && ((!(z = this.isCompass) && !this.isMagneticField && !this.isWeather) || (((z2 = this.isWeather) && !z && !this.isMagneticField) || ((z && !z2 && !this.isMagneticField) || (this.isMagneticField && !z2 && !z)))))) {
                        if (this.lin_bottom_wether.getVisibility() == 8 && !this.isCompass && !this.isMagneticField && !this.isWeather) {
                            if ((this.isDateTime || this.isLatLng) && this.isnotes) {
                                if (this.isNumbering || this.isPlusCode) {
                                    if (this.mStamp_size.equals("Large")) {
                                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_100dp);
                                    } else {
                                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_45);
                                    }
                                } else if (this.mStamp_size.equals("Large")) {
                                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_90dp);
                                } else {
                                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_35);
                                }
                            } else if (this.isNumbering || this.isPlusCode) {
                                if (this.mStamp_size.equals("Large")) {
                                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_80dp);
                                } else {
                                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_30);
                                }
                            } else if (this.mStamp_size.equals("Large")) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_70dp);
                            } else {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_25);
                            }
                        } else if (this.islogo) {
                            if (this.isNumbering || this.isPlusCode) {
                                if (this.mStamp_size.equals("Large")) {
                                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                                } else if (this.mStamp_size.equals(str)) {
                                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                                } else if (this.mStamp_size.equals("Small")) {
                                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                                } else {
                                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                                }
                            } else if (this.mStamp_size.equals("Large")) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                            } else if (this.mStamp_size.equals(str)) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                            } else if (this.mStamp_size.equals("Small")) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                            } else {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                            }
                        } else if (this.isNumbering || this.isPlusCode) {
                            if (this.mStamp_size.equals("Large")) {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_100dp);
                            } else {
                                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_60);
                            }
                        } else if (this.mStamp_size.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_90dp);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_50);
                        }
                    } else if (this.isNumbering || this.isPlusCode) {
                        if (this.mStamp_size.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                        } else if (this.mStamp_size.equals(str)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                        } else if (this.mStamp_size.equals("Small")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                        }
                    } else if (this.mStamp_size.equals("Large")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                    } else if (this.mStamp_size.equals(str)) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                    } else if (this.mStamp_size.equals("Small")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                    } else {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                    }
                } else if (z7 && !z6) {
                    if (this.isNumbering || this.isPlusCode) {
                        if (this.mStamp_size.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                        } else if (this.mStamp_size.equals(str)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                        } else if (this.mStamp_size.equals("Small")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_90);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_75);
                        }
                    } else {
                        this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, getResources().getDisplayMetrics()), 1.2f);
                        if (this.mStamp_size.equals("Large")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                        } else if (this.mStamp_size.equals(str)) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                        } else if (this.mStamp_size.equals("Small")) {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                        } else {
                            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_65);
                        }
                    }
                } else if (this.isNumbering || this.isPlusCode) {
                    if (this.mStamp_size.equals("Large")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_130);
                    } else if (this.mStamp_size.equals(str)) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_120);
                    } else if (this.mStamp_size.equals("Small")) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                    } else {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                    }
                } else if (this.mStamp_size.equals("Large")) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_115);
                } else if (this.mStamp_size.equals(str)) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_105);
                } else if (this.mStamp_size.equals("Small")) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_95);
                } else {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_80);
                }
            } else if (this.isNumbering || this.isPlusCode) {
                if (this.mStamp_size.equals("Large")) {
                    if (!this.isNumbering) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
                    } else if (!this.isPlusCode) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
                    } else {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_60);
                    }
                } else if (!this.isNumbering) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
                } else if (!this.isPlusCode) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
                } else {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_60);
                }
            } else if (this.mStamp_size.equals("Large")) {
                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_70dp);
            } else if (!this.islogo && !this.isnotes) {
                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_35);
            } else {
                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
            }
        }
        if (!this.isAddress && !this.isLatLng && !this.isDateTime && !this.isnotes && !this.iswind && !this.isHumidity && !this.isaccuracy && !this.ispressure && !this.isaltitude && !this.isNumbering && !this.istimezone && !this.isPlusCode) {
            this.li_address.setVisibility(View.GONE);
            this.li_rightView.setOrientation(0);
            this.li_rightView.setGravity(17);
            this.li_rightView.getLayoutParams().width = -1;
            this.li_rightView.getLayoutParams().width = -1;
            if (this.islogo && !this.isMap) {
                if (this.mStamp_size.equals("Large")) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_80dp);
                } else {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_40);
                }
            }
        } else {
            this.li_address.setVisibility(View.VISIBLE);
            this.li_rightView.setOrientation(1);
            this.li_rightView.setGravity(19);
            this.li_rightView.getLayoutParams().width = -2;
            this.li_rightView.getLayoutParams().width = -2;
        }
        if (!this.isAddress && !this.isLatLng && !this.isDateTime && !this.isnotes && !this.isNumbering && !this.istimezone && !this.isPlusCode && this.lin_bottom_wether.getVisibility() == 0) {
            this.lin_bottom_wether.setGravity(17);
            this.lin_bottom_wether.getLayoutParams().width = -1;
        }
        if (!this.isLatLng && !this.isAddress && !this.isMagneticField && !this.isWeather && !this.isCompass && !this.isDateTime && !this.isNumbering && !this.istimezone && !this.isMap && !this.isnotes && !this.iswind && !this.isHumidity && !this.isaccuracy && !this.ispressure && !this.isaltitude && !this.islogo && !this.isPlusCode) {
            this.li_main_stamp_lay.setVisibility(View.GONE);
        } else {
            this.li_main_stamp_lay.setVisibility(View.VISIBLE);
            setText();
        }
        if (!this.isLatLng && !this.isAddress && !this.isDateTime && !this.isnotes && !this.isNumbering && !this.istimezone && !this.isPlusCode) {
            this.tv_address_line_1.setVisibility(View.GONE);
        } else {
            this.tv_address_line_1.setVisibility(View.VISIBLE);
        }
        if (this.isMap && !this.isAddress && !this.isCompass && !this.isDateTime && !this.isLatLng && !this.isMagneticField && !this.isWeather && !this.isnotes && !this.iswind && !this.isHumidity && !this.isaccuracy && !this.ispressure && !this.isaltitude && !this.islogo && !this.isNumbering && !this.istimezone && !this.isPlusCode) {
            this.li_stamp.setVisibility(4);
            i = 0;
        } else {
            i = 0;
            this.li_stamp.setVisibility(View.VISIBLE);
        }
        if (this.sharedPreferences.getString(SP.STAMP_POS, "Bottom").equals("Bottom")) {
            this.lin_waterma.setVisibility(i);
            this.lin_waterma_2.setVisibility(View.GONE);
            ((GradientDrawable) this.lin_waterma.getBackground().getCurrent()).setColor(this.background_color);
        } else {
            this.li_stamp.setBackground(getResources().getDrawable(R.drawable.rect_grey_3));
            this.lin_waterma.setVisibility(View.GONE);
            this.lin_waterma_2.setVisibility(View.VISIBLE);
            this.lin_waterma_2.setBackground(getResources().getDrawable(R.drawable.rect_grey_4));
            ((GradientDrawable) this.lin_waterma_2.getBackground().getCurrent()).setColor(this.background_color);
        }
        if (this.mStamp_size.equals("Small") || this.mStamp_size.equals(str)) {
            LinearLayout.LayoutParams layoutParams3 = (LinearLayout.LayoutParams) this.imgstamp_1.getLayoutParams();
            layoutParams3.height = Util.dpToPx(this, 20);
            layoutParams3.width = Util.dpToPx(this, 20);
            LinearLayout.LayoutParams layoutParams4 = (LinearLayout.LayoutParams) this.imgstamp_2.getLayoutParams();
            layoutParams4.height = Util.dpToPx(this, 20);
            layoutParams4.width = Util.dpToPx(this, 20);
            this.txt_watermark_1.setTextSize(7.0f);
            this.txt_watermark_2.setTextSize(7.0f);
        } else if (this.mStamp_size.equals("Extra Small")) {
            LinearLayout.LayoutParams layoutParams5 = (LinearLayout.LayoutParams) this.imgstamp_1.getLayoutParams();
            layoutParams5.height = Util.dpToPx(this, 14);
            layoutParams5.width = Util.dpToPx(this, 14);
            LinearLayout.LayoutParams layoutParams6 = (LinearLayout.LayoutParams) this.imgstamp_2.getLayoutParams();
            layoutParams6.height = Util.dpToPx(this, 14);
            layoutParams6.width = Util.dpToPx(this, 14);
            this.txt_watermark_1.setTextSize(5.0f);
            this.txt_watermark_2.setTextSize(5.0f);
        } else {
            LinearLayout.LayoutParams layoutParams7 = (LinearLayout.LayoutParams) this.imgstamp_1.getLayoutParams();
            layoutParams7.height = Util.dpToPx(this, 24);
            layoutParams7.width = Util.dpToPx(this, 24);
            LinearLayout.LayoutParams layoutParams8 = (LinearLayout.LayoutParams) this.imgstamp_2.getLayoutParams();
            layoutParams8.height = Util.dpToPx(this, 24);
            layoutParams8.width = Util.dpToPx(this, 24);
            this.txt_watermark_1.setTextSize(9.0f);
            this.txt_watermark_2.setTextSize(9.0f);
        }
        ((GradientDrawable) this.li_stamp.getBackground().getCurrent()).setColor(this.background_color);
        setMapType();
    }

    private String getTimezone(int i) {
        String displayName = Calendar.getInstance().getTimeZone().getDisplayName(false, 1);
        Date time = Calendar.getInstance(TimeZone.getTimeZone("GMT"), Locale.getDefault()).getTime();
        String format = new SimpleDateFormat("Z").format(time);
        String format2 = new SimpleDateFormat("ZZZZZ", Locale.getDefault()).format(time);
        switch (i) {
            case 1:
                return format;
            case 2:
                return "UTC " + format;
            case 3:
                return "GMT " + format;
            case 4:
                return format2;
            case 5:
                return "UTC " + format2;
            case 6:
                return "GMT " + format2;
            case 7:
                return displayName;
            default:
                return "";
        }
    }

    private void setMapType() {
        String str = this.mMap_Type;
        str.hashCode();
        char c = 65535;
        switch (str.hashCode()) {
            case -1579103941:
                if (str.equals("satellite")) {
                    c = 0;
                    break;
                }
                break;
            case -1423437003:
                if (str.equals("terrain")) {
                    c = 1;
                    break;
                }
                break;
            case -1202757124:
                if (str.equals("hybrid")) {
                    c = 2;
                    break;
                }
                break;
            case 1366708796:
                if (str.equals("roadmap")) {
                    c = 3;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                this.imgMap.setImageResource(R.drawable.setellite);
                return;
            case 1:
                this.imgMap.setImageResource(R.drawable.tarrain);
                return;
            case 2:
                this.imgMap.setImageResource(R.drawable.hybrid);
                return;
            case 3:
                this.imgMap.setImageResource(R.drawable.normal);
                return;
            default:
                return;
        }
    }

    private void setText() {
        String str;
        int i;
        String trim = this.mSP.getString(this, SP.LOC_LINE_1_ADDRESS, "").trim();
        String trim2 = this.mSP.getString(this, SP.LOC_LINE_2_CITY, "").trim();
        String trim3 = this.mSP.getString(this, SP.LOC_LINE_3_STATE, "").trim();
        String trim4 = this.mSP.getString(this, SP.LOC_LINE_4_COUNTRY, "").trim();
        String trim5 = this.mSP.getString(this, SP.PLUS_CODE, "").trim();
        if (!trim5.isEmpty() && this.mPluscode_type.equals("concise")) {
            trim5 = trim5.substring(4);
        }
        if (trim2 == null || trim2.isEmpty()) {
            str = "";
        } else {
            str = "" + trim2 + ", ";
        }
        if (trim3 != null && !trim3.isEmpty()) {
            str = str + "" + trim3 + ", ";
        }
        if (trim4 != null && !trim4.isEmpty()) {
            str = str + trim4;
        }
        if (str != null && str.endsWith(", ")) {
            str = str.substring(0, str.length() - 2);
        }
        String coloredSpanned = (trim == null || trim.isEmpty()) ? "" : getColoredSpanned(trim, this.address_color);
        String coloredSpanned2 = getColoredSpanned(this.mUtil.getLatLong(this, this.mLatLngType), this.lat_lng_color);
        Log.e("latLong111222 : ", coloredSpanned2);
        if (coloredSpanned2 != null && (i = this.mLatLngType) != 6 && i != 7 && coloredSpanned2.length() > 55 && this.isMap && !this.isWeather && !this.isMagneticField && !this.isCompass) {
            String[] split = coloredSpanned2.split(" Long");
            coloredSpanned2 = split[0] + "<br/>Long " + split[1];
        }
        boolean z = this.isAddress;
        if (z) {
            if (this.isLatLng) {
                coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned2;
            }
        } else if (this.isLatLng && !z) {
            coloredSpanned = coloredSpanned2;
        }
        if (this.isPlusCode) {
            String coloredSpanned3 = getColoredSpanned("Plus Code : " + trim5, this.plus_code_color);
            if (this.isAddress || this.isLatLng) {
                coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned3;
            } else {
                coloredSpanned = coloredSpanned3;
            }
        }
        if (this.isDateTime) {
            String coloredSpanned4 = getColoredSpanned(Util.setDateTimeFormat(this.mSP.getString(this, SP.DATE_FORMAT, "dd/MM/yy hh:mm a")), this.date_time_color);
            if (this.isAddress || this.isLatLng || this.isPlusCode) {
                coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned4;
            } else {
                coloredSpanned = coloredSpanned4;
            }
        }
        if (this.istimezone) {
            String coloredSpanned5 = getColoredSpanned(getTimezone(this.mSP.getInteger(this, SP.TIMEZONE, 6)), this.date_time_color);
            if (!this.isDateTime) {
                if (this.isAddress || this.isLatLng || this.isPlusCode) {
                    coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned5;
                } else {
                    coloredSpanned = coloredSpanned5;
                }
            } else {
                coloredSpanned = coloredSpanned + " " + coloredSpanned5;
            }
        }
        if (this.isnotes) {
            String coloredSpanned6 = getColoredSpanned(this.mSP.getString(this, SP.NOTES_HASHTAG, "Note : Captured by GPS Map Camera"), this.note_hastag_color);
            if (this.isAddress || this.isLatLng || this.isDateTime || this.istimezone || this.isPlusCode) {
                coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned6;
            } else {
                coloredSpanned = coloredSpanned6;
            }
        }
        if (this.isNumbering) {
            String coloredSpanned7 = getColoredSpanned((this.prefix + " " + this.sequence + " " + this.suffix).trim(), this.numbering_color);
            if (this.isAddress || this.isLatLng || this.isDateTime || this.istimezone || this.isnotes || this.isPlusCode) {
                coloredSpanned = coloredSpanned + "<br/>" + coloredSpanned7;
            } else {
                coloredSpanned = coloredSpanned7;
            }
        }
        if (this.iswind) {
            this.tv_wind.setText(Util.getwindConvert(this, this.wind_selected));
            this.tv_wind.setTextColor(this.wind_color);
            this.img_wind_stamp.setImageResource(R.drawable.ic_wind);
        }
        if (this.isCompass) {
            this.tv_compass.setText(this.mSP.getString(this, SP.COMPASS_VALUE, ""));
            this.tv_compass.setTextColor(this.compass_color);
        }
        if (this.isWeather) {
            if (this.msTemprature_type.equals("Celsius")) {
                this.tv_weather.setText(Util.getCelcius(this.mfTemprature_value));
            } else {
                this.tv_weather.setText(Util.getFahrenheit(this.mfTemprature_value));
            }
            this.tv_weather.setTextColor(this.weather_color);
        }
        if (this.isMagneticField) {
            this.tv_magnetic_field.setText(this.mSP.getString(this, SP.MAGNETIC_FIELD_VALUE, ""));
            this.tv_magnetic_field.setTextColor(this.magnetic_field_color);
        }
        if (this.isHumidity) {
            this.tv_humidity.setText(this.mSP.getString(this, SP.HUMIDITY_VALUE, "") + "%");
            this.tv_humidity.setTextColor(this.Humidity_color);
            this.img_humidity_stamp.setImageResource(R.drawable.ic_humidity);
        }
        if (this.ispressure) {
            this.tv_pressure.setText(Util.getpressureConvert(this, this.pressure_selection));
            this.tv_pressure.setTextColor(this.pressure_color);
            this.img_pressure_stamp.setImageResource(R.drawable.ic_pressure);
        }
        if (coloredSpanned.contains("null")) {
            coloredSpanned = coloredSpanned.replace("null", "Loading");
        }
        this.tv_address_line_1.setText(Html.fromHtml(coloredSpanned));
        if (str != null && !str.isEmpty() && this.isAddress) {
            this.tv_address.setVisibility(View.VISIBLE);
            if (str.equalsIgnoreCase("null")) {
                str = "Loading";
            }
            this.tv_address.setText(Html.fromHtml(getColoredSpanned(str, this.address_color)));
        } else {
            this.tv_address.setVisibility(View.GONE);
        }
        if (this.Logo_img.equals("no_logo")) {
            this.imgLogo.setImageResource(R.mipmap.ic_launcher);
        } else {
            ExecutorService newSingleThreadExecutor = Executors.newSingleThreadExecutor();
            final Handler handler = new Handler();
            newSingleThreadExecutor.execute(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.TempletSelectionActivity.5
                @Override // java.lang.Runnable
                public void run() {
                    final Bitmap decodeBase64 = Util.decodeBase64(TempletSelectionActivity.this.Logo_img);
                    handler.post(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.TempletSelectionActivity.5.1
                        @Override // java.lang.Runnable
                        public void run() {
                            Glide.with((FragmentActivity) TempletSelectionActivity.this).load(decodeBase64).into(TempletSelectionActivity.this.imgLogo);
                        }
                    });
                }
            });
        }
        this.tv_humidity.setTypeface(Util.getFontStyle(this, this.font_style));
        this.tv_wind.setTypeface(Util.getFontStyle(this, this.font_style));
        this.tv_pressure.setTypeface(Util.getFontStyle(this, this.font_style));
        this.tv_address_line_1.setTypeface(Util.getFontStyle(this, this.font_style));
        this.tv_address.setTypeface(Util.getFontStyle(this, this.font_style));
        this.tv_weather.setTypeface(Util.getFontStyle(this, this.font_style));
        this.tv_compass.setTypeface(Util.getFontStyle(this, this.font_style));
        this.tv_magnetic_field.setTypeface(Util.getFontStyle(this, this.font_style));
    }

    private String getColoredSpanned(String str, int i) {
        return "<font color=" + i + ">" + str + "</font>";
    }

    private void OnClick() {
        this.mToolbar_back.setOnClickListener(this);
        this.imf_classic_templet.setOnClickListener(this);
        this.imf_advance_temlent.setOnClickListener(this);
        this.relStampLay.setOnClickListener(this);
        this.relStampLay_claasic.setOnClickListener(this);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.imf_advance_temlent /* 2131362227 */:
                Intent intent = new Intent(this, TempletSettingActivity.class);
                intent.putExtra("temp_type", this.templet_type);
                startActivity(intent);
                return;
            case R.id.imf_classic_templet /* 2131362228 */:
                Intent intent2 = new Intent(this, TempletSettingActivity.class);
                intent2.putExtra("temp_type", this.templet_type);
                startActivity(intent2);
                return;
            case R.id.relStampLay /* 2131362607 */:
                if (this.templet_type == 1) {
                    this.imf_advance_temlent.setVisibility(View.VISIBLE);
                    this.imf_classic_templet.setVisibility(View.GONE);
                    this.templet_type = 0;
                    this.mSP.setInteger(this, SP.TEMPLATE_TYPE, 0);
                    return;
                }
                return;
            case R.id.relStampLay_claasic /* 2131362608 */:
                if (this.templet_type == 0) {
                    this.imf_advance_temlent.setVisibility(View.GONE);
                    this.imf_classic_templet.setVisibility(View.VISIBLE);
                    this.templet_type = 1;
                    this.mSP.setInteger(this, SP.TEMPLATE_TYPE, 1);
                    return;
                }
                return;
            case R.id.toolbar_back /* 2131362806 */:
                onBackPressed();
                return;
            default:
                return;
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        super.onBackPressed();
//        getexitads();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        setadavnceTemplet();
        setclassic_temp();
    }
}