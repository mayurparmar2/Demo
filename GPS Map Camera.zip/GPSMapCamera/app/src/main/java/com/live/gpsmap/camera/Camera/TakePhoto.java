package com.live.gpsmap.camera.Camera;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class TakePhoto extends Activity {
    private static final String TAG = "TakePhoto";
    public static boolean TAKE_PHOTO;

    @Override
    protected void onCreate(Bundle bundle) {
        Log.d(TAG, "onCreate");
        super.onCreate(bundle);
        Intent intent = new Intent(this, CameraMainActivity.class);
        intent.setFlags(335544320);
        TAKE_PHOTO = true;
        startActivity(intent);
        Log.d(TAG, "finish");
        finish();
    }

    @Override
    protected void onResume() {
        Log.d(TAG, "onResume");
        super.onResume();
    }
}
