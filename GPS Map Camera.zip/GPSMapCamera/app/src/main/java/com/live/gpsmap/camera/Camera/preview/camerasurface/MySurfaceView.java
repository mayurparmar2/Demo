package com.live.gpsmap.camera.Camera.preview.camerasurface;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.media.MediaRecorder;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.View;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraController;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraControllerException;
import com.live.gpsmap.camera.Camera.preview.Preview;

/* loaded from: classes.dex */
public class MySurfaceView extends SurfaceView implements CameraSurface {
    private static final String TAG = "MySurfaceView";
    private final Handler handler;
    private final int[] measure_spec;
    private final Preview preview;
    private final Runnable tick;

    @Override
    public View getView() {
        return this;
    }

    public MySurfaceView(Context context, final Preview preview) {
        super(context);
        this.measure_spec = new int[2];
        this.handler = new Handler();
        this.preview = preview;
        Log.d(TAG, "new MySurfaceView");
        getHolder().addCallback(preview);
        this.tick = new Runnable() {
            @Override
            public void run() {
                preview.test_ticker_called = true;
                MySurfaceView.this.invalidate();
                MySurfaceView.this.handler.postDelayed(this, preview.getFrameRate());
            }
        };
    }

    @Override
    public void setPreviewDisplay(CameraController cameraController) {
        Log.d(TAG, "setPreviewDisplay");
        try {
            cameraController.setPreviewDisplay(getHolder());
        } catch (CameraControllerException e) {
            Log.e(TAG, "Failed to set preview display: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void setVideoRecorder(MediaRecorder mediaRecorder) {
        mediaRecorder.setPreviewDisplay(getHolder().getSurface());
    }

    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {
        return this.preview.touchEvent(motionEvent);
    }

    @Override
    public void onDraw(Canvas canvas) {
        this.preview.draw(canvas);
    }

    @Override
    protected void onMeasure(int i, int i2) {
        Log.d(TAG, "onMeasure: " + i + " x " + i2);
        this.preview.getMeasureSpec(this.measure_spec, i, i2);
        int[] iArr = this.measure_spec;
        super.onMeasure(iArr[0], iArr[1]);
    }

    @Override
    public void setTransform(Matrix matrix) {
        Log.d(TAG, "setting transforms not supported for MySurfaceView");
        throw new RuntimeException();
    }

    @Override
    public void onPause() {
        Log.d(TAG, "onPause()");
        this.handler.removeCallbacks(this.tick);
    }

    @Override // com.live.gpsmap.camera.Camera.preview.camerasurface.CameraSurface
    public void onResume() {
        Log.d(TAG, "onResume()");
        this.tick.run();
    }
}
