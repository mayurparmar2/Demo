package com.live.gpsmap.camera.Camera.ui;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.util.Log;
import android.util.Pair;
import android.view.View;

import androidx.exifinterface.media.ExifInterface;
import androidx.work.WorkRequest;

import com.live.gpsmap.camera.Camera.GyroSensor;
import com.live.gpsmap.camera.Camera.CameraMainActivity;
import com.live.gpsmap.camera.Camera.MyApplicationInterface;
import com.live.gpsmap.camera.Camera.PreferenceKeys;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraController;
import com.live.gpsmap.camera.Camera.preview.ApplicationInterface;
import com.live.gpsmap.camera.Camera.preview.Preview;
import com.live.gpsmap.camera.R;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;


@SuppressWarnings("All")
public class DrawPreview {
    private static final String TAG = "DrawPreview";
    private static final double close_level_angle = 1.0d;
    private static final DecimalFormat decimalFormat = new DecimalFormat("#0.0");
    private static final int histogram_height_dp = 60;
    private static final int histogram_width_dp = 100;
    private String OSDLine1;
    private String OSDLine2;
    private long ae_started_scanning_ms;
    private boolean allow_ghost_last_image;
    private int angle_highlight_color_pref;
    private String angle_string;
    private final MyApplicationInterface applicationInterface;
    private final int[] auto_stabilise_crop;
    private boolean auto_stabilise_pref;
    private float battery_frac;
    private final IntentFilter battery_ifilter;
    private double cached_angle;
    private Calendar calendar;
    private String camera_id_string;
    private float capture_rate_factor;
    private boolean capture_started;
    private boolean continuous_focus_moving;
    private long continuous_focus_moving_ms;
    private String current_time_string;
    private DateFormat dateFormatTimeInstance;
    private final RectF draw_rect;
    private boolean enable_gyro_target_spot;
    private int focus_peaking_color_pref;
    private int focus_seekbars_margin_left;
    private float free_memory_gb;
    private String free_memory_gb_string;
    private boolean front_screen_flash;
    private int ghost_image_alpha;
    private String ghost_image_pref;
    private Bitmap ghost_selected_image_bitmap;
    private String ghost_selected_image_pref = "";
    private final int[] gui_location;
    private final float[] gyro_direction_up;
    private final List<float[]> gyro_directions;
    private boolean has_battery_frac;
    private boolean has_settings;
    private boolean has_stamp_pref;
    private boolean has_video_max_amp;
    private Preview.HistogramType histogram_type;
    private final Rect icon_dest;
    private boolean image_queue_full;
    private boolean immersive_mode_everything_pref;
    private boolean is_audio_enabled_pref;
    private boolean is_face_detection_pref;
    private boolean is_high_speed;
    private boolean is_raw_only_pref;
    private boolean is_raw_pref;
    private boolean is_scanning;
    private String iso_exposure_string;
    private long last_angle_string_time;
    private long last_battery_time;
    private long last_camera_id_time;
    private long last_current_time_time;
    private long last_free_memory_time;
    private final RectF last_image_dst_rect;
    private final Matrix last_image_matrix;
    private final RectF last_image_src_rect;
    private long last_iso_exposure_time;
    private long last_need_flash_indicator_time;
    private long last_take_photo_top_time;
    private Bitmap last_thumbnail;
    private boolean last_thumbnail_is_video;
    private long last_top_icon_shift_time;
    private long last_video_max_amp_time;
    private long last_view_angles_time;
    private final CameraMainActivity main_activity;
    private boolean need_flash_indicator;
    private long needs_flash_time;
    private final Paint p;
    private final Path path;
    private MyApplicationInterface.PhotoMode photoMode;
    private String preference_grid_pref;
    private boolean preview_size_wysiwyg_pref;
    private final float scale;
    private final SharedPreferences sharedPreferences;
    private boolean show_angle_line_pref;
    private boolean show_angle_pref;
    private boolean show_battery_pref;
    private boolean show_camera_id_pref;
    private boolean show_free_memory_pref;
    private boolean show_geo_direction_lines_pref;
    private boolean show_geo_direction_pref;
    private boolean show_iso_pref;
    private boolean show_last_image;
    private boolean show_pitch_lines_pref;
    private boolean show_time_pref;
    private boolean show_video_max_amp_pref;
    private boolean show_zoom_pref;
    private boolean store_location_pref;
    private final float stroke_width;
    private boolean take_photo_border_pref;
    private int take_photo_top;
    private boolean taking_picture;
    private final int[] temp_histogram_channel;
    private Rect text_bounds_angle_double;
    private Rect text_bounds_angle_single;
    private Rect text_bounds_camera_id;
    private Rect text_bounds_free_memory;
    private Rect text_bounds_time;
    private volatile boolean thumbnail_anim;
    private final RectF thumbnail_anim_dst_rect;
    private final Matrix thumbnail_anim_matrix;
    private final RectF thumbnail_anim_src_rect;
    private long thumbnail_anim_start_ms;
    private int top_icon_shift;
    private final float[] transformed_gyro_direction;
    private final float[] transformed_gyro_direction_up;
    private int video_max_amp;
    private int video_max_amp_peak;
    private int video_max_amp_prev2;
    private float view_angle_x_preview;
    private float view_angle_y_preview;
    private boolean want_focus_peaking;
    private boolean want_histogram;
    private boolean want_zebra_stripes;
    private final String ybounds_text;
    private int zebra_stripes_color_background;
    private int zebra_stripes_color_foreground;
    private int zebra_stripes_threshold;

    public DrawPreview(CameraMainActivity mainActivity, MyApplicationInterface myApplicationInterface) {
        Paint paint = new Paint();
        this.p = paint;
        this.draw_rect = new RectF();
        this.gui_location = new int[2];
        this.temp_histogram_channel = new int[256];
        this.auto_stabilise_crop = new int[2];
        this.free_memory_gb = -1.0f;
        this.need_flash_indicator = false;
        this.battery_ifilter = new IntentFilter();
        this.icon_dest = new Rect();
        this.needs_flash_time = -1L;
        this.path = new Path();
        this.thumbnail_anim_start_ms = -1L;
        this.thumbnail_anim_src_rect = new RectF();
        this.thumbnail_anim_dst_rect = new RectF();
        this.thumbnail_anim_matrix = new Matrix();
        this.last_image_src_rect = new RectF();
        this.last_image_dst_rect = new RectF();
        this.last_image_matrix = new Matrix();
        this.ae_started_scanning_ms = -1L;
        this.gyro_directions = new ArrayList();
        this.transformed_gyro_direction = new float[3];
        this.gyro_direction_up = new float[3];
        this.transformed_gyro_direction_up = new float[3];
        this.focus_seekbars_margin_left = -1;
        Log.d(TAG, TAG);
        this.main_activity = mainActivity;
        this.sharedPreferences = PreferenceManager.getDefaultSharedPreferences(mainActivity);
        this.applicationInterface = myApplicationInterface;
        paint.setAntiAlias(true);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setStrokeCap(Paint.Cap.ROUND);
        float f = getContext().getResources().getDisplayMetrics().density;
        this.scale = f;
        float f2 = (f * 1.0f) + 0.5f;
        this.stroke_width = f2;
        paint.setStrokeWidth(f2);
        this.ybounds_text = getContext().getResources().getString(R.string.zoom) + getContext().getResources().getString(R.string.angle) + getContext().getResources().getString(R.string.direction);
    }

    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        Bitmap bitmap = this.ghost_selected_image_bitmap;
        if (bitmap != null) {
            bitmap.recycle();
            this.ghost_selected_image_bitmap = null;
        }
        this.ghost_selected_image_pref = "";
    }

    private Context getContext() {
        return this.main_activity;
    }

    private int getViewOnScreenX(View view) {
        view.getLocationOnScreen(this.gui_location);
        int i = this.gui_location[0];
        int round = ((Math.round(view.getRotation()) % 360) + 360) % 360;
        return (round == 180 || round == 90) ? i - view.getWidth() : i;
    }

    public void updateThumbnail(Bitmap bitmap, boolean z, boolean z2) {
        Log.d(TAG, "updateThumbnail");
        if (z2 && this.applicationInterface.getThumbnailAnimationPref()) {
            Log.d(TAG, "thumbnail_anim started");
            this.thumbnail_anim = true;
            this.thumbnail_anim_start_ms = System.currentTimeMillis();
        }
        Bitmap bitmap2 = this.last_thumbnail;
        this.last_thumbnail = bitmap;
        this.last_thumbnail_is_video = z;
        this.allow_ghost_last_image = true;
        if (bitmap2 != null) {
            bitmap2.recycle();
        }
    }

    public boolean hasThumbnailAnimation() {
        return this.thumbnail_anim;
    }

    public void showLastImage() {
        Log.d(TAG, "showLastImage");
        this.show_last_image = true;
    }

    public void clearLastImage() {
        Log.d(TAG, "clearLastImage");
        this.show_last_image = false;
    }

    public void clearGhostImage() {
        Log.d(TAG, "clearGhostImage");
        this.allow_ghost_last_image = false;
    }

    public void cameraInOperation(boolean z) {
        if (z && !this.main_activity.getPreview().isVideo()) {
            this.taking_picture = true;
            return;
        }
        this.taking_picture = false;
        this.front_screen_flash = false;
        this.capture_started = false;
    }

    public void setImageQueueFull(boolean z) {
        this.image_queue_full = z;
    }

    public void turnFrontScreenFlashOn() {
        Log.d(TAG, "turnFrontScreenFlashOn");
        this.front_screen_flash = true;
    }

    public void onCaptureStarted() {
        Log.d(TAG, "onCaptureStarted");
        this.capture_started = true;
    }

    public void onContinuousFocusMove(boolean z) {
        Log.d(TAG, "onContinuousFocusMove: " + z);
        if (!z || this.continuous_focus_moving) {
            return;
        }
        this.continuous_focus_moving = true;
        this.continuous_focus_moving_ms = System.currentTimeMillis();
    }

    public void clearContinuousFocusMove() {
        Log.d(TAG, "clearContinuousFocusMove");
        if (this.continuous_focus_moving) {
            this.continuous_focus_moving = false;
            this.continuous_focus_moving_ms = 0L;
        }
    }

    public void setGyroDirectionMarker(float f, float f2, float f3) {
        this.enable_gyro_target_spot = true;
        this.gyro_directions.clear();
        addGyroDirectionMarker(f, f2, f3);
        float[] fArr = this.gyro_direction_up;
        fArr[0] = 0.0f;
        fArr[1] = 1.0f;
        fArr[2] = 0.0f;
    }

    public void addGyroDirectionMarker(float f, float f2, float f3) {
        this.gyro_directions.add(new float[]{f, f2, f3});
    }

    public void clearGyroDirectionMarker() {
        this.enable_gyro_target_spot = false;
    }


    public void updateSettings() {
        char c;
        Log.d(TAG, "updateSettings");
        this.photoMode = this.applicationInterface.getPhotoMode();
        Log.d(TAG, "photoMode: " + this.photoMode);
        boolean z = false;
        this.show_time_pref = this.sharedPreferences.getBoolean(PreferenceKeys.ShowTimePreferenceKey, false);
        this.dateFormatTimeInstance = DateFormat.getTimeInstance();
        this.current_time_string = null;
        this.last_current_time_time = 0L;
        this.text_bounds_time = null;
        this.show_camera_id_pref = false;
        this.show_free_memory_pref = this.sharedPreferences.getBoolean(PreferenceKeys.ShowFreeMemoryPreferenceKey, false);
        this.show_iso_pref = false;
        this.show_video_max_amp_pref = this.sharedPreferences.getBoolean(PreferenceKeys.ShowVideoMaxAmpPreferenceKey, false);
        this.show_zoom_pref = this.sharedPreferences.getBoolean(PreferenceKeys.ShowZoomPreferenceKey, true);
        this.show_battery_pref = this.sharedPreferences.getBoolean(PreferenceKeys.ShowBatteryPreferenceKey, false);
        this.show_angle_pref = this.sharedPreferences.getBoolean(PreferenceKeys.ShowAnglePreferenceKey, false);
        this.angle_highlight_color_pref = Color.parseColor(this.sharedPreferences.getString(PreferenceKeys.ShowAngleHighlightColorPreferenceKey, "#14e715"));
        this.show_geo_direction_pref = this.sharedPreferences.getBoolean(PreferenceKeys.ShowGeoDirectionPreferenceKey, false);
        this.take_photo_border_pref = this.sharedPreferences.getBoolean(PreferenceKeys.TakePhotoBorderPreferenceKey, false);
        this.preview_size_wysiwyg_pref = this.sharedPreferences.getString(PreferenceKeys.PreviewSizePreferenceKey, "preference_preview_size_wysiwyg").equals("preference_preview_size_wysiwyg");
        this.store_location_pref = this.sharedPreferences.getBoolean(PreferenceKeys.LocationPreferenceKey, true);
        this.show_angle_line_pref = this.sharedPreferences.getBoolean(PreferenceKeys.ShowAngleLinePreferenceKey, false);
        this.show_pitch_lines_pref = this.sharedPreferences.getBoolean(PreferenceKeys.ShowPitchLinesPreferenceKey, false);
        this.show_geo_direction_lines_pref = this.sharedPreferences.getBoolean(PreferenceKeys.ShowGeoDirectionLinesPreferenceKey, false);
        this.immersive_mode_everything_pref = this.sharedPreferences.getString(PreferenceKeys.ImmersiveModePreferenceKey, "immersive_mode_low_profile").equals("immersive_mode_everything");
        this.has_stamp_pref = this.applicationInterface.getStampPref().equals("preference_stamp_yes");
        this.is_raw_pref = this.applicationInterface.getRawPref() != ApplicationInterface.RawPref.RAWPREF_JPEG_ONLY;
        this.is_raw_only_pref = this.applicationInterface.isRawOnly();
        this.is_face_detection_pref = this.applicationInterface.getFaceDetectionPref();
        this.is_audio_enabled_pref = this.applicationInterface.getRecordAudioPref();
        this.is_high_speed = this.applicationInterface.fpsIsHighSpeed();
        this.capture_rate_factor = this.applicationInterface.getVideoCaptureRateFactor();
        this.auto_stabilise_pref = this.applicationInterface.getAutoStabilisePref();
        this.preference_grid_pref = this.sharedPreferences.getString(PreferenceKeys.ShowGridPreferenceKey, "preference_grid_none");
        String string = this.sharedPreferences.getString(PreferenceKeys.GhostImagePreferenceKey, "preference_ghost_image_off");
        this.ghost_image_pref = string;
        if (string.equals("preference_ghost_image_selected")) {
            String string2 = this.sharedPreferences.getString(PreferenceKeys.GhostSelectedImageSAFPreferenceKey, "");
            Log.d(TAG, "new_ghost_selected_image_pref: " + string2);
            KeyguardManager keyguardManager = (KeyguardManager) this.main_activity.getSystemService(Context.KEYGUARD_SERVICE);
            boolean z2 = keyguardManager != null && keyguardManager.inKeyguardRestrictedInputMode();
            Log.d(TAG, "is_locked?: " + z2);
            if (z2) {
                Bitmap bitmap = this.ghost_selected_image_bitmap;
                if (bitmap != null) {
                    bitmap.recycle();
                    this.ghost_selected_image_bitmap = null;
                    this.ghost_selected_image_pref = "";
                }
            } else if (!string2.equals(this.ghost_selected_image_pref)) {
                Log.d(TAG, "ghost_selected_image_pref has changed");
                this.ghost_selected_image_pref = string2;
                Bitmap bitmap2 = this.ghost_selected_image_bitmap;
                if (bitmap2 != null) {
                    bitmap2.recycle();
                    this.ghost_selected_image_bitmap = null;
                }
                Uri parse = Uri.parse(this.ghost_selected_image_pref);
                try {
                    this.ghost_selected_image_bitmap = loadBitmap(parse);
                } catch (IOException e) {
                    Log.e(TAG, "failed to load ghost_selected_image uri: " + parse);
                    e.printStackTrace();
                    this.ghost_selected_image_bitmap = null;
                }
            }
        } else {
            Bitmap bitmap3 = this.ghost_selected_image_bitmap;
            if (bitmap3 != null) {
                bitmap3.recycle();
                this.ghost_selected_image_bitmap = null;
            }
            this.ghost_selected_image_pref = "";
        }
        this.ghost_image_alpha = this.applicationInterface.getGhostImageAlpha();
        String string3 = this.sharedPreferences.getString(PreferenceKeys.HistogramPreferenceKey, "preference_histogram_off");
        this.want_histogram = !string3.equals("preference_histogram_off") && this.main_activity.supportsPreviewBitmaps();
        this.histogram_type = Preview.HistogramType.HISTOGRAM_TYPE_VALUE;
        if (this.want_histogram) {
            string3.hashCode();
            switch (string3.hashCode()) {
                case -683780238:
                    if (string3.equals("preference_histogram_value")) {
                        c = 0;
                        break;
                    }
                    c = 65535;
                    break;
                case 43977486:
                    if (string3.equals("preference_histogram_rgb")) {
                        c = 1;
                        break;
                    }
                    c = 65535;
                    break;
                case 605025716:
                    if (string3.equals("preference_histogram_intensity")) {
                        c = 2;
                        break;
                    }
                    c = 65535;
                    break;
                case 792142318:
                    if (string3.equals("preference_histogram_lightness")) {
                        c = 3;
                        break;
                    }
                    c = 65535;
                    break;
                case 1283793529:
                    if (string3.equals("preference_histogram_luminance")) {
                        c = 4;
                        break;
                    }
                    c = 65535;
                    break;
                default:
                    c = 65535;
                    break;
            }
            switch (c) {
                case 0:
                    this.histogram_type = Preview.HistogramType.HISTOGRAM_TYPE_VALUE;
                    break;
                case 1:
                    this.histogram_type = Preview.HistogramType.HISTOGRAM_TYPE_RGB;
                    break;
                case 2:
                    this.histogram_type = Preview.HistogramType.HISTOGRAM_TYPE_INTENSITY;
                    break;
                case 3:
                    this.histogram_type = Preview.HistogramType.HISTOGRAM_TYPE_LIGHTNESS;
                    break;
                case 4:
                    this.histogram_type = Preview.HistogramType.HISTOGRAM_TYPE_LUMINANCE;
                    break;
            }
        }
        String string4 = this.sharedPreferences.getString(PreferenceKeys.ZebraStripesPreferenceKey, "0");
        try {
            this.zebra_stripes_threshold = Integer.parseInt(string4);
        } catch (NumberFormatException e2) {
            Log.e(TAG, "failed to parse zebra_stripes_value: " + string4);
            e2.printStackTrace();
            this.zebra_stripes_threshold = 0;
        }
        this.want_zebra_stripes = (this.zebra_stripes_threshold != 0) & this.main_activity.supportsPreviewBitmaps();
        this.zebra_stripes_color_foreground = Color.parseColor(this.sharedPreferences.getString(PreferenceKeys.ZebraStripesForegroundColorPreferenceKey, "#ff000000"));
        this.zebra_stripes_color_background = Color.parseColor(this.sharedPreferences.getString(PreferenceKeys.ZebraStripesBackgroundColorPreferenceKey, "#ffffffff"));
        if (!this.sharedPreferences.getString(PreferenceKeys.FocusPeakingPreferenceKey, "preference_focus_peaking_off").equals("preference_focus_peaking_off") && this.main_activity.supportsPreviewBitmaps()) {
            z = true;
        }
        this.want_focus_peaking = z;
        this.focus_peaking_color_pref = Color.parseColor(this.sharedPreferences.getString(PreferenceKeys.FocusPeakingColorPreferenceKey, "#ffffff"));
        this.last_camera_id_time = 0L;
        this.last_view_angles_time = 0L;
        this.last_take_photo_top_time = 0L;
        this.last_top_icon_shift_time = 0L;
        this.focus_seekbars_margin_left = -1;
        this.has_settings = true;
    }

    private void updateCachedViewAngles(long j) {
        long j2 = this.last_view_angles_time;
        if (j2 == 0 || j>j2 + WorkRequest.MIN_BACKOFF_MILLIS) {
            Log.d(TAG, "update cached view angles");
            Preview preview = this.main_activity.getPreview();
            this.view_angle_x_preview = preview.getViewAngleX(true);
            this.view_angle_y_preview = preview.getViewAngleY(true);
            this.last_view_angles_time = j;
        }
    }

//    private Bitmap loadBitmap(Uri uri0) throws IOException {
//        ExifInterface exifInterface0;
//        Bitmap bitmap0;
//        int v5;
//        int v4;
//        InputStream inputStream1;
//        int v;
//        Log.d("DrawPreview", "loadBitmap: " + uri0);
//        try {
//            BitmapFactory.Options bitmapFactory$Options0 = new BitmapFactory.Options();
//            v = 1;
//            bitmapFactory$Options0.inJustDecodeBounds = true;
//            InputStream inputStream0 = this.main_activity.getContentResolver().openInputStream(uri0);
//            inputStream1 = null;
//            BitmapFactory.decodeStream(inputStream0, null, bitmapFactory$Options0);
//            if (inputStream0 != null) {
//                inputStream0.close();
//            }
//
//            if (bitmapFactory$Options0.outWidth != -1 && bitmapFactory$Options0.outHeight != -1) {
//                int v1 = Math.max(bitmapFactory$Options0.outWidth, bitmapFactory$Options0.outHeight);
//                Point point0 = new Point();
//                this.main_activity.getWindowManager().getDefaultDisplay().getSize(point0);
//                int v2 = Math.max(point0.x, point0.y);
//                int v3 = (int) Math.ceil(((double) v1) / ((double) v2));
//                v4 = Integer.highestOneBit(v3);
//                Log.d("DrawPreview", "display_size: " + v2);
//                Log.d("DrawPreview", "image_size: " + v1);
//                Log.d("DrawPreview", "ratio: " + v3);
//                Log.d("DrawPreview", "sample_size: " + v4);
//            } else {
//                Log.e("DrawPreview", "failed to obtain width/height of bitmap");
//                v4 = 1;
//            }
//
//            BitmapFactory.Options bitmapFactory$Options1 = new BitmapFactory.Options();
//            v5 = 0;
//            bitmapFactory$Options1.inMutable = false;
//            bitmapFactory$Options1.inSampleSize = v4;
//            InputStream inputStream2 = this.main_activity.getContentResolver().openInputStream(uri0);
//            bitmap0 = BitmapFactory.decodeStream(inputStream2, null, bitmapFactory$Options1);
//            if (inputStream2 != null) {
//                inputStream2.close();
//            }
//
//            if (bitmap0 != null) {
//                Log.d("DrawPreview", "bitmap width: " + bitmap0.getWidth());
//                Log.d("DrawPreview", "bitmap height: " + bitmap0.getHeight());
//            }
//        } catch (Exception exception0) {
//            Log.e("DrawPreview", "MediaStore.Images.Media.getBitmap exception");
//            exception0.printStackTrace();
//            throw new IOException();
//        }
//
//        if (bitmap0 != null) {
//            try {
//                inputStream1 = this.main_activity.getContentResolver().openInputStream(uri0);
//                exifInterface0 = new ExifInterface(inputStream1);
//            } catch (Throwable throwable0) {
//                if (inputStream1 != null) {
//                    inputStream1.close();
//                }
//
//                throw throwable0;
//            }
//
//            if (inputStream1 != null) {
//                inputStream1.close();
//            }
//
//            int v6 = exifInterface0.getAttributeInt("Orientation", 0);
//            if (v6 != 0 && v6 != 1) {
//                switch (v6) {
//                    case 3: {
//                        v5 = 180;
//                        break;
//                    }
//                    case 6: {
//                        v5 = 90;
//                        break;
//                    }
//                    case 8: {
//                        v5 = 270;
//                        break;
//                    }
//                    default: {
//                        Log.e("DrawPreview", "    unsupported exif orientation: " + v6);
//                        v = 0;
//                    }
//                }
//            } else {
//                v = 0;
//            }
//
//            Log.d("DrawPreview", "    exif orientation: " + v5);
//            if (v != 0) {
//                Log.d("DrawPreview", "    need to rotate bitmap due to exif orientation tag");
//                Matrix matrix0 = new Matrix();
//                matrix0.setRotate(((float) v5), ((float) bitmap0.getWidth()) * 0.5f, ((float) bitmap0.getHeight()) * 0.5f);
//                Bitmap bitmap1 = Bitmap.createBitmap(bitmap0, 0, 0, bitmap0.getWidth(), bitmap0.getHeight(), matrix0, true);
//                if (bitmap1 == bitmap0) {
//                    return bitmap0;
//                }
//
//                bitmap0.recycle();
//                return bitmap1;
//            }
//
//            return bitmap0;
//        }
//
//        Log.e("DrawPreview", "MediaStore.Images.Media.getBitmap returned null");
//        throw new IOException();
//    }

    private Bitmap loadBitmap(Uri uri0) throws IOException {
        Bitmap bitmap0;
        try {
            bitmap0 = MediaStore.Images.Media.getBitmap(this.main_activity.getContentResolver(), uri0);
        }
        catch(Exception exception0) {
            Log.e("DrawPreview", "MediaStore.Images.Media.getBitmap exception");
            exception0.printStackTrace();
            throw new IOException();
        }

        if(bitmap0 != null) {
            ExifInterface exifInterface0 = null;
            if(Build.VERSION.SDK_INT >= 24) {
                InputStream inputStream0 = this.main_activity.getContentResolver().openInputStream(uri0);
                try {
                    exifInterface0 = new ExifInterface(inputStream0);
                }
                catch(Throwable throwable0) {
                    try {
                        throw throwable0;
                    }
                    catch(Throwable throwable1) {
                        if(inputStream0 != null) {
                            try {
                                inputStream0.close();
                            }
                            catch(Throwable throwable2) {
                                throwable0.addSuppressed(throwable2);
                            }
                        }

                        throw throwable1;
                    }
                }

                if(inputStream0 != null) {
                    inputStream0.close();
                }
            }
//            else if(file0 != null) {
//                exifInterface0 = new ExifInterface(file0.getAbsolutePath());
//            }

            if(exifInterface0 != null) {
                int v = 0;
                int v1 = exifInterface0.getAttributeInt("Orientation", 0);
                int v2 = 1;
                if(v1 != 0 && v1 != 1) {
                    switch(v1) {
                        case 3: {
                            v = 180;
                            break;
                        }
                        case 6: {
                            v = 90;
                            break;
                        }
                        case 8: {
                            v = 270;
                            break;
                        }
                        default: {
                            v2 = 0;
                        }
                    }
                }
                else {
                    v2 = 0;
                }

                if(v2 == 0) {
                    return bitmap0;
                }

                Matrix matrix0 = new Matrix();
                matrix0.setRotate(((float)v), ((float)bitmap0.getWidth()) * 0.5f, ((float)bitmap0.getHeight()) * 0.5f);
                Bitmap bitmap1 = Bitmap.createBitmap(bitmap0, 0, 0, bitmap0.getWidth(), bitmap0.getHeight(), matrix0, true);
                if(bitmap1 == bitmap0) {
                    return bitmap0;
                }

                bitmap0.recycle();
                return bitmap1;
            }

            return bitmap0;
        }

        Log.e("DrawPreview", "MediaStore.Images.Media.getBitmap returned null");
        throw new IOException();
    }

    private String getTimeStringFromSeconds(long j) {
        int i = (int) (j % 60);
        long j2 = j / 60;
        return (j2 / 60) + ":" + String.format(Locale.getDefault(), "%02d", Integer.valueOf((int) (j2 % 60))) + ":" + String.format(Locale.getDefault(), "%02d", Integer.valueOf(i));
    }
    private void drawGrids(Canvas canvas) {
        char c;
        char c2;
        if (this.main_activity.getPreview().getCameraController() == null) {
            return;
        }
        this.p.setStrokeWidth(this.stroke_width);
        String str = this.preference_grid_pref;
        int i = 0;
        switch (str.hashCode()) {
            case -2062044919:
                if (str.equals("preference_grid_diagonals")) {
                    c = '\n';
                    break;
                }
                c = 65535;
                break;
            case -1861951923:
                if (str.equals("preference_grid_crosshair")) {
                    c = 3;
                    break;
                }
                c = 65535;
                break;
            case -1499749228:
                if (str.equals("preference_grid_golden_spiral_left")) {
                    c = 5;
                    break;
                }
                c = 65535;
                break;
            case -1261883239:
                if (str.equals("preference_grid_3x3")) {
                    c = 0;
                    break;
                }
                c = 65535;
                break;
            case -1261882279:
                if (str.equals("preference_grid_4x2")) {
                    c = 2;
                    break;
                }
                c = 65535;
                break;
            case 305030335:
                if (str.equals("preference_grid_golden_spiral_upside_down_right")) {
                    c = 6;
                    break;
                }
                c = 65535;
                break;
            case 563846404:
                if (str.equals("preference_grid_golden_spiral_upside_down_left")) {
                    c = 7;
                    break;
                }
                c = 65535;
                break;
            case 758075183:
                if (str.equals("preference_grid_golden_spiral_right")) {
                    c = 4;
                    break;
                }
                c = 65535;
                break;
            case 1473299275:
                if (str.equals("preference_grid_phi_3x3")) {
                    c = 1;
                    break;
                }
                c = 65535;
                break;
            case 1925582811:
                if (str.equals("preference_grid_golden_triangle_1")) {
                    c = '\b';
                    break;
                }
                c = 65535;
                break;
            case 1925582812:
                if (str.equals("preference_grid_golden_triangle_2")) {
                    c = '\t';
                    break;
                }
                c = 65535;
                break;
            default:
                c = 65535;
                break;
        }
        switch (c) {
            case 0:
                this.p.setColor(-1);
                canvas.drawLine(canvas.getWidth() / 3.0f, 0.0f, canvas.getWidth() / 3.0f, canvas.getHeight() - 1.0f, this.p);
                canvas.drawLine((canvas.getWidth() * 2.0f) / 3.0f, 0.0f, (canvas.getWidth() * 2.0f) / 3.0f, canvas.getHeight() - 1.0f, this.p);
                canvas.drawLine(0.0f, canvas.getHeight() / 3.0f, canvas.getWidth() - 1.0f, canvas.getHeight() / 3.0f, this.p);
                canvas.drawLine(0.0f, (canvas.getHeight() * 2.0f) / 3.0f, canvas.getWidth() - 1.0f, (canvas.getHeight() * 2.0f) / 3.0f, this.p);
                return;
            case 1:
                this.p.setColor(-1);
                canvas.drawLine(canvas.getWidth() / 2.618f, 0.0f, canvas.getWidth() / 2.618f, canvas.getHeight() - 1.0f, this.p);
                canvas.drawLine((canvas.getWidth() * 1.618f) / 2.618f, 0.0f, (canvas.getWidth() * 1.618f) / 2.618f, canvas.getHeight() - 1.0f, this.p);
                canvas.drawLine(0.0f, canvas.getHeight() / 2.618f, canvas.getWidth() - 1.0f, canvas.getHeight() / 2.618f, this.p);
                canvas.drawLine(0.0f, (canvas.getHeight() * 1.618f) / 2.618f, canvas.getWidth() - 1.0f, (canvas.getHeight() * 1.618f) / 2.618f, this.p);
                return;
            case 2:
                this.p.setColor(-7829368);
                canvas.drawLine(canvas.getWidth() / 4.0f, 0.0f, canvas.getWidth() / 4.0f, canvas.getHeight() - 1.0f, this.p);
                canvas.drawLine(canvas.getWidth() / 2.0f, 0.0f, canvas.getWidth() / 2.0f, canvas.getHeight() - 1.0f, this.p);
                canvas.drawLine((canvas.getWidth() * 3.0f) / 4.0f, 0.0f, (canvas.getWidth() * 3.0f) / 4.0f, canvas.getHeight() - 1.0f, this.p);
                canvas.drawLine(0.0f, canvas.getHeight() / 2.0f, canvas.getWidth() - 1.0f, canvas.getHeight() / 2.0f, this.p);
                this.p.setColor(-1);
                float f = (int) ((this.scale * 20.0f) + 0.5f);
                canvas.drawLine(canvas.getWidth() / 2.0f, (canvas.getHeight() / 2.0f) - f, canvas.getWidth() / 2.0f, (canvas.getHeight() / 2.0f) + f, this.p);
                canvas.drawLine((canvas.getWidth() / 2.0f) - f, canvas.getHeight() / 2.0f, (canvas.getWidth() / 2.0f) + f, canvas.getHeight() / 2.0f, this.p);
                return;
            case 3:
                this.p.setColor(-1);
                canvas.drawLine(canvas.getWidth() / 2.0f, 0.0f, canvas.getWidth() / 2.0f, canvas.getHeight() - 1.0f, this.p);
                canvas.drawLine(0.0f, canvas.getHeight() / 2.0f, canvas.getWidth() - 1.0f, canvas.getHeight() / 2.0f, this.p);
                return;
            case 4:
            case 5:
            case 6:
            case 7:
                canvas.save();
                String str2 = this.preference_grid_pref;
                switch (str2.hashCode()) {
                    case -1499749228:
                        if (str2.equals("preference_grid_golden_spiral_left")) {
                            c2 = 0;
                            break;
                        }
                        c2 = 65535;
                        break;
                    case 305030335:
                        if (str2.equals("preference_grid_golden_spiral_upside_down_right")) {
                            c2 = 3;
                            break;
                        }
                        c2 = 65535;
                        break;
                    case 563846404:
                        if (str2.equals("preference_grid_golden_spiral_upside_down_left")) {
                            c2 = 2;
                            break;
                        }
                        c2 = 65535;
                        break;
                    case 758075183:
                        if (str2.equals("preference_grid_golden_spiral_right")) {
                            c2 = 1;
                            break;
                        }
                        c2 = 65535;
                        break;
                    default:
                        c2 = 65535;
                        break;
                }
                if (c2 == 0) {
                    canvas.scale(-1.0f, 1.0f, canvas.getWidth() * 0.5f, canvas.getHeight() * 0.5f);
                } else if (c2 != 1) {
                    if (c2 == 2) {
                        canvas.rotate(180.0f, canvas.getWidth() * 0.5f, canvas.getHeight() * 0.5f);
                    } else if (c2 == 3) {
                        canvas.scale(1.0f, -1.0f, canvas.getWidth() * 0.5f, canvas.getHeight() * 0.5f);
                    }
                }
                this.p.setColor(-1);
                this.p.setStyle(Paint.Style.STROKE);
                this.p.setStrokeWidth(this.stroke_width);
                int width = canvas.getWidth();
                int height = canvas.getHeight();
                int i2 = (int) ((width * 21) / 34);
                int i3 = width;
                int i4 = 0;
                int i5 = 0;
                int i6 = 34;
                int i7 = 21;
                for (int i8 = 2; i < i8; i8 = 2) {
                    canvas.save();
                    float f2 = i4;
                    float f3 = i5;
                    int i9 = i4 + i2;
                    float f4 = i9;
                    this.draw_rect.set(f2, f3, f4, i5 + height);
                    canvas.clipRect(this.draw_rect);
                    canvas.drawRect(this.draw_rect, this.p);
                    this.draw_rect.set(f2, f3, i4 + (i2 * 2), (height * 2) + i5);
                    canvas.drawOval(this.draw_rect, this.p);
                    canvas.restore();
                    int i10 = i6 - i7;
                    int i11 = i3 - i2;
                    double d = height;
                    int i12 = height;
                    double d2 = i10;
                    int i13 = (int) ((d * d2) / i7);
                    canvas.save();
                    float f5 = i9 + i11;
                    int i14 = i5 + i13;
                    float f6 = i14;
                    this.draw_rect.set(f4, f3, f5, f6);
                    canvas.clipRect(this.draw_rect);
                    canvas.drawRect(this.draw_rect, this.p);
                    this.draw_rect.set(i9 - i11, f3, f5, i5 + (i13 * 2));
                    canvas.drawOval(this.draw_rect, this.p);
                    canvas.restore();
                    int i15 = i7 - i10;
                    int i16 = i12 - i13;
                    int i17 = i;
                    double d3 = i15;
                    int i18 = (int) ((i11 * d3) / d2);
                    i3 = i11 - i18;
                    int i19 = i9 + i3;
                    canvas.save();
                    float f7 = i19 + i18;
                    float f8 = i14 + i16;
                    this.draw_rect.set(i19, f6, f7, f8);
                    canvas.clipRect(this.draw_rect);
                    canvas.drawRect(this.draw_rect, this.p);
                    this.draw_rect.set(i19 - i18, i14 - i16, f7, f8);
                    canvas.drawOval(this.draw_rect, this.p);
                    canvas.restore();
                    i6 = i10 - i15;
                    i4 = i19 - i3;
                    double d4 = i6;
                    int i20 = (int) ((i16 * d4) / d3);
                    height = i16 - i20;
                    int i21 = i14 + height;
                    canvas.save();
                    float f9 = i4;
                    float f10 = i21 + i20;
                    this.draw_rect.set(f9, i21, i4 + i3, f10);
                    canvas.clipRect(this.draw_rect);
                    canvas.drawRect(this.draw_rect, this.p);
                    this.draw_rect.set(f9, i21 - i20, (i3 * 2) + i4, f10);
                    canvas.drawOval(this.draw_rect, this.p);
                    canvas.restore();
                    i7 = i15 - i6;
                    i5 = i21 - height;
                    i2 = (int) ((i3 * i7) / d4);
                    i = i17 + 1;
                }
                canvas.restore();
                this.p.setStyle(Paint.Style.FILL);
                return;
            case '\b':
            case '\t':
                this.p.setColor(-1);
                double atan2 = Math.atan2(canvas.getWidth(), canvas.getHeight());
                double height2 = canvas.getHeight() * Math.cos(atan2);
                float sin = (float) (Math.sin(atan2) * height2);
                float cos = (float) (height2 * Math.cos(atan2));
                if (this.preference_grid_pref.equals("preference_grid_golden_triangle_1")) {
                    canvas.drawLine(0.0f, canvas.getHeight() - 1.0f, canvas.getWidth() - 1.0f, 0.0f, this.p);
                    canvas.drawLine(0.0f, 0.0f, sin, canvas.getHeight() - cos, this.p);
                    canvas.drawLine((canvas.getWidth() - 1.0f) - sin, cos - 1.0f, canvas.getWidth() - 1.0f, canvas.getHeight() - 1.0f, this.p);
                    return;
                }
                canvas.drawLine(0.0f, 0.0f, canvas.getWidth() - 1.0f, canvas.getHeight() - 1.0f, this.p);
                canvas.drawLine(canvas.getWidth() - 1.0f, 0.0f, (canvas.getWidth() - 1.0f) - sin, canvas.getHeight() - cos, this.p);
                canvas.drawLine(sin, cos - 1.0f, 0.0f, canvas.getHeight() - 1.0f, this.p);
                return;
            case '\n':
                this.p.setColor(-1);
                canvas.drawLine(0.0f, 0.0f, canvas.getHeight() - 1.0f, canvas.getHeight() - 1.0f, this.p);
                canvas.drawLine(canvas.getHeight() - 1.0f, 0.0f, 0.0f, canvas.getHeight() - 1.0f, this.p);
                int width2 = canvas.getWidth() - canvas.getHeight();
                if (width2 > 0) {
                    float f11 = width2;
                    canvas.drawLine(f11, 0.0f, (canvas.getHeight() + width2) - 1.0f, canvas.getHeight() - 1.0f, this.p);
                    canvas.drawLine((width2 + canvas.getHeight()) - 1.0f, 0.0f, f11, canvas.getHeight() - 1.0f, this.p);
                    return;
                }
                return;
            default:
                return;
        }
    }



//    private void drawGrids(Canvas canvas) {
//        Preview preview = main_activity.getPreview();
//        CameraController camera_controller = preview.getCameraController();
//        if (camera_controller == null) {
//            return;
//        }
//
//        p.setStrokeWidth(stroke_width);
//
//        switch (preference_grid_pref) {
//            case "preference_grid_3x3":
//                p.setColor(Color.WHITE);
//                canvas.drawLine(canvas.getWidth() / 3.0f, 0.0f, canvas.getWidth() / 3.0f, canvas.getHeight() - 1.0f, p);
//                canvas.drawLine(2.0f * canvas.getWidth() / 3.0f, 0.0f, 2.0f * canvas.getWidth() / 3.0f, canvas.getHeight() - 1.0f, p);
//                canvas.drawLine(0.0f, canvas.getHeight() / 3.0f, canvas.getWidth() - 1.0f, canvas.getHeight() / 3.0f, p);
//                canvas.drawLine(0.0f, 2.0f * canvas.getHeight() / 3.0f, canvas.getWidth() - 1.0f, 2.0f * canvas.getHeight() / 3.0f, p);
//                break;
//            case "preference_grid_phi_3x3":
//                p.setColor(Color.WHITE);
//                canvas.drawLine(canvas.getWidth() / 2.618f, 0.0f, canvas.getWidth() / 2.618f, canvas.getHeight() - 1.0f, p);
//                canvas.drawLine(1.618f * canvas.getWidth() / 2.618f, 0.0f, 1.618f * canvas.getWidth() / 2.618f, canvas.getHeight() - 1.0f, p);
//                canvas.drawLine(0.0f, canvas.getHeight() / 2.618f, canvas.getWidth() - 1.0f, canvas.getHeight() / 2.618f, p);
//                canvas.drawLine(0.0f, 1.618f * canvas.getHeight() / 2.618f, canvas.getWidth() - 1.0f, 1.618f * canvas.getHeight() / 2.618f, p);
//                break;
//            case "preference_grid_4x2":
//                p.setColor(Color.GRAY);
//                canvas.drawLine(canvas.getWidth() / 4.0f, 0.0f, canvas.getWidth() / 4.0f, canvas.getHeight() - 1.0f, p);
//                canvas.drawLine(canvas.getWidth() / 2.0f, 0.0f, canvas.getWidth() / 2.0f, canvas.getHeight() - 1.0f, p);
//                canvas.drawLine(3.0f * canvas.getWidth() / 4.0f, 0.0f, 3.0f * canvas.getWidth() / 4.0f, canvas.getHeight() - 1.0f, p);
//                canvas.drawLine(0.0f, canvas.getHeight() / 2.0f, canvas.getWidth() - 1.0f, canvas.getHeight() / 2.0f, p);
//                p.setColor(Color.WHITE);
//                int crosshairs_radius = (int) (20 * scale + 0.5f); // convert dps to pixels
//
//                canvas.drawLine(canvas.getWidth() / 2.0f, canvas.getHeight() / 2.0f - crosshairs_radius, canvas.getWidth() / 2.0f, canvas.getHeight() / 2.0f + crosshairs_radius, p);
//                canvas.drawLine(canvas.getWidth() / 2.0f - crosshairs_radius, canvas.getHeight() / 2.0f, canvas.getWidth() / 2.0f + crosshairs_radius, canvas.getHeight() / 2.0f, p);
//                break;
//            case "preference_grid_crosshair":
//                p.setColor(Color.WHITE);
//                canvas.drawLine(canvas.getWidth() / 2.0f, 0.0f, canvas.getWidth() / 2.0f, canvas.getHeight() - 1.0f, p);
//                canvas.drawLine(0.0f, canvas.getHeight() / 2.0f, canvas.getWidth() - 1.0f, canvas.getHeight() / 2.0f, p);
//                break;
//            case "preference_grid_golden_spiral_right":
//            case "preference_grid_golden_spiral_left":
//            case "preference_grid_golden_spiral_upside_down_right":
//            case "preference_grid_golden_spiral_upside_down_left":
//                canvas.save();
//                switch (preference_grid_pref) {
//                    case "preference_grid_golden_spiral_left":
//                        canvas.scale(-1.0f, 1.0f, canvas.getWidth() * 0.5f, canvas.getHeight() * 0.5f);
//                        break;
//                    case "preference_grid_golden_spiral_right":
//                        // no transformation needed
//                        break;
//                    case "preference_grid_golden_spiral_upside_down_left":
//                        canvas.rotate(180.0f, canvas.getWidth() * 0.5f, canvas.getHeight() * 0.5f);
//                        break;
//                    case "preference_grid_golden_spiral_upside_down_right":
//                        canvas.scale(1.0f, -1.0f, canvas.getWidth() * 0.5f, canvas.getHeight() * 0.5f);
//                        break;
//                }
//                p.setColor(Color.WHITE);
//                p.setStyle(Paint.Style.STROKE);
//                p.setStrokeWidth(stroke_width);
//                int fibb = 34;
//                int fibb_n = 21;
//                int left = 0, top = 0;
//                int full_width = canvas.getWidth();
//                int full_height = canvas.getHeight();
//                int width = (int) (full_width * ((double) fibb_n) / (double) (fibb));
//                int height = full_height;
//
//                for (int count = 0; count<2; count++) {
//                    canvas.save();
//                    draw_rect.set(left, top, left + width, top + height);
//                    canvas.clipRect(draw_rect);
//                    canvas.drawRect(draw_rect, p);
//                    draw_rect.set(left, top, left + 2 * width, top + 2 * height);
//                    canvas.drawOval(draw_rect, p);
//                    canvas.restore();
//
//                    int old_fibb = fibb;
//                    fibb = fibb_n;
//                    fibb_n = old_fibb - fibb;
//
//                    left += width;
//                    full_width = full_width - width;
//                    width = full_width;
//                    height = (int) (height * ((double) fibb_n) / (double) (fibb));
//
//                    canvas.save();
//                    draw_rect.set(left, top, left + width, top + height);
//                    canvas.clipRect(draw_rect);
//                    canvas.drawRect(draw_rect, p);
//                    draw_rect.set(left - width, top, left + width, top + 2 * height);
//                    canvas.drawOval(draw_rect, p);
//                    canvas.restore();
//
//                    old_fibb = fibb;
//                    fibb = fibb_n;
//                    fibb_n = old_fibb - fibb;
//
//                    top += height;
//                    full_height = full_height - height;
//                    height = full_height;
//                    width = (int) (width * ((double) fibb_n) / (double) (fibb));
//                    left += full_width - width;
//
//                    canvas.save();
//                    draw_rect.set(left, top, left + width, top + height);
//                    canvas.clipRect(draw_rect);
//                    canvas.drawRect(draw_rect, p);
//                    draw_rect.set(left - width, top - height, left + width, top + height);
//                    canvas.drawOval(draw_rect, p);
//                    canvas.restore();
//
//                    old_fibb = fibb;
//                    fibb = fibb_n;
//                    fibb_n = old_fibb - fibb;
//
//                    full_width = full_width - width;
//                    width = full_width;
//                    left -= width;
//                    height = (int) (height * ((double) fibb_n) / (double) (fibb));
//                    top += full_height - height;
//
//                    canvas.save();
//                    draw_rect.set(left, top, left + width, top + height);
//                    canvas.clipRect(draw_rect);
//                    canvas.drawRect(draw_rect, p);
//                    draw_rect.set(left, top - height, left + 2 * width, top + height);
//                    canvas.drawOval(draw_rect, p);
//                    canvas.restore();
//
//                    old_fibb = fibb;
//                    fibb = fibb_n;
//                    fibb_n = old_fibb - fibb;
//
//                    full_height = full_height - height;
//                    height = full_height;
//                    top -= height;
//                    width = (int) (width * ((double) fibb_n) / (double) (fibb));
//                }
//
//                canvas.restore();
//                p.setStyle(Paint.Style.FILL); // reset
//
//                break;
//            case "preference_grid_golden_triangle_1":
//            case "preference_grid_golden_triangle_2":
//                p.setColor(Color.WHITE);
//                double theta = Math.atan2(canvas.getWidth(), canvas.getHeight());
//                double dist = canvas.getHeight() * Math.cos(theta);
//                float dist_x = (float) (dist * Math.sin(theta));
//                float dist_y = (float) (dist * Math.cos(theta));
//                if (preference_grid_pref.equals("preference_grid_golden_triangle_1")) {
//                    canvas.drawLine(0.0f, canvas.getHeight() - 1.0f, canvas.getWidth() - 1.0f, 0.0f, p);
//                    canvas.drawLine(0.0f, 0.0f, dist_x, canvas.getHeight() - dist_y, p);
//                    canvas.drawLine(canvas.getWidth() - 1.0f - dist_x, dist_y - 1.0f, canvas.getWidth() - 1.0f, canvas.getHeight() - 1.0f, p);
//                } else {
//                    canvas.drawLine(0.0f, 0.0f, canvas.getWidth() - 1.0f, canvas.getHeight() - 1.0f, p);
//                    canvas.drawLine(canvas.getWidth() - 1.0f, 0.0f, canvas.getWidth() - 1.0f - dist_x, canvas.getHeight() - dist_y, p);
//                    canvas.drawLine(dist_x, dist_y - 1.0f, 0.0f, canvas.getHeight() - 1.0f, p);
//                }
//                break;
//            case "preference_grid_diagonals":
//                p.setColor(Color.WHITE);
//                canvas.drawLine(0.0f, 0.0f, canvas.getHeight() - 1.0f, canvas.getHeight() - 1.0f, p);
//                canvas.drawLine(canvas.getHeight() - 1.0f, 0.0f, 0.0f, canvas.getHeight() - 1.0f, p);
//                int diff = canvas.getWidth() - canvas.getHeight();
//                // n.b., diff is -ve in portrait orientation
//                canvas.drawLine(diff, 0.0f, diff + canvas.getHeight() - 1.0f, canvas.getHeight() - 1.0f, p);
//                canvas.drawLine(diff + canvas.getHeight() - 1.0f, 0.0f, diff, canvas.getHeight() - 1.0f, p);
//                break;
//        }
//    }

//    private void drawGrids(Canvas canvas0) {
//        int v2;
//        DrawPreview drawPreview0 = this;
//        Canvas canvas1 = canvas0;
//        if(drawPreview0.main_activity.getPreview().getCameraController() == null) {
//            return;
//        }
//
//        drawPreview0.p.setStrokeWidth(drawPreview0.stroke_width);
//        String s = drawPreview0.preference_grid_pref;
//        s.hashCode();
//        int v = 1;
//        int v1 = 0;
//        switch(s.hashCode()) {
//            case -2062044919: {
//                v2 = s.equals("preference_grid_none") ? 0 : -1;
//                break;
//            }
//            case 0x9104DE4D: {
//                v2 = s.equals("preference_grid_crosshair") ? 1 : -1;
//                break;
//            }
//            case 0xA69BA494: {
//                v2 = s.equals("preference_grid_golden_spiral_left") ? 2 : -1;
//                break;
//            }
//            case 0xB4C93099: {
//                v2 = s.equals("preference_grid_3x3") ? 3 : -1;
//                break;
//            }
//            case 0xB4C93459: {
//                v2 = s.equals("preference_grid_4x2") ? 4 : -1;
//                break;
//            }
//            case 305030335: {
//                v2 = s.equals("preference_grid_golden_spiral_upside_down_right") ? 5 : -1;
//                break;
//            }
//            case 0x219B9D04: {
//                v2 = s.equals("preference_grid_golden_spiral_upside_down_left") ? 6 : -1;
//                break;
//            }
//            case 0x2D2F4F2F: {
//                v2 = s.equals("preference_grid_golden_spiral_right") ? 7 : -1;
//                break;
//            }
//            case 0x57D0C34B: {
//                v2 = s.equals("preference_grid_phi_3x3") ? 8 : -1;
//                break;
//            }
//            case 0x72C60FDB: {
//                v2 = s.equals("preference_grid_golden_triangle_1") ? 9 : -1;
//                break;
//            }
//            case 0x72C60FDC: {
//                v2 = s.equals("preference_grid_golden_triangle_2") ? 10 : -1;
//                break;
//            }
//            default: {
//                v2 = -1;
//            }
//        }
//
//        switch(v2) {
//            case 0: {
//                drawPreview0.p.setColor(-1);
//                canvas0.drawLine(0.0f, 0.0f, ((float)canvas0.getHeight()) - 1.0f, ((float)canvas0.getHeight()) - 1.0f, drawPreview0.p);
//                canvas0.drawLine(((float)canvas0.getHeight()) - 1.0f, 0.0f, 0.0f, ((float)canvas0.getHeight()) - 1.0f, drawPreview0.p);
//                int v3 = canvas0.getWidth() - canvas0.getHeight();
//                if(v3 > 0) {
//                    float f = (float)v3;
//                    canvas0.drawLine(f, 0.0f, ((float)(canvas0.getHeight() + v3)) - 1.0f, ((float)canvas0.getHeight()) - 1.0f, drawPreview0.p);
//                    canvas0.drawLine(((float)(v3 + canvas0.getHeight())) - 1.0f, 0.0f, f, ((float)canvas0.getHeight()) - 1.0f, drawPreview0.p);
//                }
//
//                return;
//            }
//            case 1: {
//                drawPreview0.p.setColor(-1);
//                canvas0.drawLine(((float)canvas0.getWidth()) / 2.0f, 0.0f, ((float)canvas0.getWidth()) / 2.0f, ((float)canvas0.getHeight()) - 1.0f, drawPreview0.p);
//                canvas0.drawLine(0.0f, ((float)canvas0.getHeight()) / 2.0f, ((float)canvas0.getWidth()) - 1.0f, ((float)canvas0.getHeight()) / 2.0f, drawPreview0.p);
//                return;
//            }
//            case 3: {
//                drawPreview0.p.setColor(-1);
//                canvas0.drawLine(((float)canvas0.getWidth()) / 3.0f, 0.0f, ((float)canvas0.getWidth()) / 3.0f, ((float)canvas0.getHeight()) - 1.0f, drawPreview0.p);
//                canvas0.drawLine(((float)canvas0.getWidth()) * 2.0f / 3.0f, 0.0f, ((float)canvas0.getWidth()) * 2.0f / 3.0f, ((float)canvas0.getHeight()) - 1.0f, drawPreview0.p);
//                canvas0.drawLine(0.0f, ((float)canvas0.getHeight()) / 3.0f, ((float)canvas0.getWidth()) - 1.0f, ((float)canvas0.getHeight()) / 3.0f, drawPreview0.p);
//                canvas0.drawLine(0.0f, ((float)canvas0.getHeight()) * 2.0f / 3.0f, ((float)canvas0.getWidth()) - 1.0f, ((float)canvas0.getHeight()) * 2.0f / 3.0f, drawPreview0.p);
//                return;
//            }
//            case 4: {
//                drawPreview0.p.setColor(0xFF888888);
//                canvas0.drawLine(((float)canvas0.getWidth()) / 4.0f, 0.0f, ((float)canvas0.getWidth()) / 4.0f, ((float)canvas0.getHeight()) - 1.0f, drawPreview0.p);
//                canvas0.drawLine(((float)canvas0.getWidth()) / 2.0f, 0.0f, ((float)canvas0.getWidth()) / 2.0f, ((float)canvas0.getHeight()) - 1.0f, drawPreview0.p);
//                canvas0.drawLine(((float)canvas0.getWidth()) * 3.0f / 4.0f, 0.0f, ((float)canvas0.getWidth()) * 3.0f / 4.0f, ((float)canvas0.getHeight()) - 1.0f, drawPreview0.p);
//                canvas0.drawLine(0.0f, ((float)canvas0.getHeight()) / 2.0f, ((float)canvas0.getWidth()) - 1.0f, ((float)canvas0.getHeight()) / 2.0f, drawPreview0.p);
//                drawPreview0.p.setColor(-1);
//                float f13 = ((float)canvas0.getWidth()) / 2.0f;
//                float f14 = ((float)canvas0.getHeight()) / 2.0f;
//                float f15 = (float)(((int)(drawPreview0.scale * 20.0f + 0.5f)));
//                canvas0.drawLine(f13, f14 - f15, ((float)canvas0.getWidth()) / 2.0f, ((float)canvas0.getHeight()) / 2.0f + f15, drawPreview0.p);
//                canvas0.drawLine(((float)canvas0.getWidth()) / 2.0f - f15, ((float)canvas0.getHeight()) / 2.0f, ((float)canvas0.getWidth()) / 2.0f + f15, ((float)canvas0.getHeight()) / 2.0f, drawPreview0.p);
//                return;
//            }
//            case 2:
//            case 5:
//            case 6:
//            case 7: {
//                canvas0.save();
//                String s1 = drawPreview0.preference_grid_pref;
//                s1.hashCode();
//                switch(s1.hashCode()) {
//                    case 0xA69BA494: {
//                        v = s1.equals("preference_grid_golden_spiral_left") ? 0 : -1;
//                        break;
//                    }
//                    case 305030335: {
//                        if(!s1.equals("preference_grid_golden_spiral_upside_down_right")) {
//                            v = -1;
//                        }
//
//                        break;
//                    }
//                    case 0x219B9D04: {
//                        v = s1.equals("preference_grid_golden_spiral_upside_down_left") ? 2 : -1;
//                        break;
//                    }
//                    default: {
//                        v = -1;
//                    }
//                }
//
//                switch(v) {
//                    case 0: {
//                        canvas1.scale(-1.0f, 1.0f, ((float)canvas0.getWidth()) * 0.5f, ((float)canvas0.getHeight()) * 0.5f);
//                        break;
//                    }
//                    case 1: {
//                        canvas1.scale(1.0f, -1.0f, ((float)canvas0.getWidth()) * 0.5f, ((float)canvas0.getHeight()) * 0.5f);
//                        break;
//                    }
//                    case 2: {
//                        canvas1.rotate(180.0f, ((float)canvas0.getWidth()) * 0.5f, ((float)canvas0.getHeight()) * 0.5f);
//                    }
//                }
//
//                drawPreview0.p.setColor(-1);
//                drawPreview0.p.setStyle(Paint.Style.STROKE);
//                drawPreview0.p.setStrokeWidth(drawPreview0.stroke_width);
//                int v4 = 34;
//                int v5 = 21;
//                int v6 = canvas0.getWidth();
//                int v7 = canvas0.getHeight();
//                int v8 = (int)(((double)v6) * 1.040000E-322 / 1.700000E-322);
//                int v9 = 0;
//                int v10 = 0;
//                while(v1 < 2) {
//                    canvas0.save();
//                    float f1 = (float)v9;
//                    float f2 = (float)v10;
//                    int v11 = v9 + v8;
//                    float f3 = (float)v11;
//                    drawPreview0.draw_rect.set(f1, f2, f3, ((float)(v10 + v7)));
//                    canvas1.clipRect(drawPreview0.draw_rect);
//                    canvas1.drawRect(drawPreview0.draw_rect, drawPreview0.p);
//                    drawPreview0.draw_rect.set(f1, f2, ((float)(v9 + v8 * 2)), ((float)(v7 * 2 + v10)));
//                    canvas1.drawOval(drawPreview0.draw_rect, drawPreview0.p);
//                    canvas0.restore();
//                    int v12 = v4 - v5;
//                    int v13 = v6 - v8;
//                    double f4 = (double)v12;
//                    int v14 = (int)(((double)v7) * f4 / ((double)v5));
//                    canvas0.save();
//                    float f5 = (float)(v11 + v13);
//                    int v15 = v10 + v14;
//                    float f6 = (float)v15;
//                    drawPreview0.draw_rect.set(f3, f2, f5, f6);
//                    canvas1.clipRect(drawPreview0.draw_rect);
//                    canvas1.drawRect(drawPreview0.draw_rect, drawPreview0.p);
//                    drawPreview0.draw_rect.set(((float)(v11 - v13)), f2, f5, ((float)(v10 + v14 * 2)));
//                    canvas1.drawOval(drawPreview0.draw_rect, drawPreview0.p);
//                    canvas0.restore();
//                    int v16 = v5 - v12;
//                    int v17 = v7 - v14;
//                    double f7 = (double)v16;
//                    int v18 = (int)(((double)v13) * f7 / f4);
//                    v6 = v13 - v18;
//                    int v19 = v11 + v6;
//                    canvas0.save();
//                    float f8 = (float)(v19 + v18);
//                    float f9 = (float)(v15 + v17);
//                    drawPreview0.draw_rect.set(((float)v19), f6, f8, f9);
//                    canvas1.clipRect(drawPreview0.draw_rect);
//                    canvas1.drawRect(drawPreview0.draw_rect, drawPreview0.p);
//                    drawPreview0.draw_rect.set(((float)(v19 - v18)), ((float)(v15 - v17)), f8, f9);
//                    canvas1.drawOval(drawPreview0.draw_rect, drawPreview0.p);
//                    canvas0.restore();
//                    v4 = v12 - v16;
//                    v9 = v19 - v6;
//                    double f10 = (double)v4;
//                    int v20 = (int)(((double)v17) * f10 / f7);
//                    v7 = v17 - v20;
//                    int v21 = v15 + v7;
//                    canvas0.save();
//                    float f11 = (float)v9;
//                    float f12 = (float)(v21 + v20);
//                    drawPreview0.draw_rect.set(f11, ((float)v21), ((float)(v9 + v6)), f12);
//                    canvas1.clipRect(drawPreview0.draw_rect);
//                    canvas1.drawRect(drawPreview0.draw_rect, drawPreview0.p);
//                    drawPreview0.draw_rect.set(f11, ((float)(v21 - v20)), ((float)(v6 * 2 + v9)), f12);
//                    canvas1.drawOval(drawPreview0.draw_rect, drawPreview0.p);
//                    canvas0.restore();
//                    v5 = v16 - v4;
//                    v10 = v21 - v7;
//                    v8 = (int)(((double)v6) * ((double)v5) / f10);
//                    ++v1;
//                }
//
//                canvas0.restore();
//                drawPreview0.p.setStyle(Paint.Style.FILL);
//                return;
//            }
//            case 8: {
//                drawPreview0.p.setColor(-1);
//                canvas0.drawLine(((float)canvas0.getWidth()) / 2.618f, 0.0f, ((float)canvas0.getWidth()) / 2.618f, ((float)canvas0.getHeight()) - 1.0f, drawPreview0.p);
//                canvas0.drawLine(((float)canvas0.getWidth()) * 1.618f / 2.618f, 0.0f, ((float)canvas0.getWidth()) * 1.618f / 2.618f, ((float)canvas0.getHeight()) - 1.0f, drawPreview0.p);
//                canvas0.drawLine(0.0f, ((float)canvas0.getHeight()) / 2.618f, ((float)canvas0.getWidth()) - 1.0f, ((float)canvas0.getHeight()) / 2.618f, drawPreview0.p);
//                canvas0.drawLine(0.0f, ((float)canvas0.getHeight()) * 1.618f / 2.618f, ((float)canvas0.getWidth()) - 1.0f, ((float)canvas0.getHeight()) * 1.618f / 2.618f, drawPreview0.p);
//                return;
//            }
//            case 9:
//            case 10: {
//                break;
//            }
//            default: {
//                return;
//            }
//        }
//
//        drawPreview0.p.setColor(-1);
//        double f16 = Math.atan2(canvas0.getWidth(), canvas0.getHeight());
//        double f17 = ((double)canvas0.getHeight()) * Math.cos(f16);
//        float f18 = (float)(Math.sin(f16) * f17);
//        float f19 = (float)(f17 * Math.cos(f16));
//        if(drawPreview0.preference_grid_pref.equals("preference_grid_golden_triangle_1")) {
//            canvas0.drawLine(0.0f, ((float)canvas0.getHeight()) - 1.0f, ((float)canvas0.getWidth()) - 1.0f, 0.0f, drawPreview0.p);
//            canvas0.drawLine(0.0f, 0.0f, f18, ((float)canvas0.getHeight()) - f19, drawPreview0.p);
//            canvas0.drawLine(((float)canvas0.getWidth()) - 1.0f - f18, f19 - 1.0f, ((float)canvas0.getWidth()) - 1.0f, ((float)canvas0.getHeight()) - 1.0f, drawPreview0.p);
//            return;
//        }
//
//        canvas0.drawLine(0.0f, 0.0f, ((float)canvas0.getWidth()) - 1.0f, ((float)canvas0.getHeight()) - 1.0f, drawPreview0.p);
//        canvas0.drawLine(((float)canvas0.getWidth()) - 1.0f, 0.0f, ((float)canvas0.getWidth()) - 1.0f - f18, ((float)canvas0.getHeight()) - f19, drawPreview0.p);
//        canvas0.drawLine(f18, f19 - 1.0f, 0.0f, ((float)canvas0.getHeight()) - 1.0f, drawPreview0.p);
//    }

//    private void drawCropGuides(Canvas canvas) {
//        int i;
//        Preview preview = this.main_activity.getPreview();
//        CameraController cameraController = preview.getCameraController();
//        if (preview.isVideo() || this.preview_size_wysiwyg_pref) {
//            String string = this.sharedPreferences.getString(PreferenceKeys.ShowCropGuidePreferenceKey, "crop_guide_none");
//            if (cameraController == null || preview.getTargetRatio() <= 0.0d || string.equals("crop_guide_none")) {
//                return;
//            }
//            this.p.setStyle(Paint.Style.STROKE);
//            this.p.setStrokeWidth(this.stroke_width);
//            this.p.setColor(Color.rgb(255, 235, 59));
//            double d = -1.0d;
//            string.hashCode();
//            char c = 65535;
//            int i2 = 1;
//            switch (string.hashCode()) {
//                case -1272821505:
//                    if (string.equals("crop_guide_1")) {
//                        c = 0;
//                        break;
//                    }
//                    break;
//                case -1272821504:
//                    if (string.equals("crop_guide_2")) {
//                        c = 1;
//                        break;
//                    }
//                    break;
//                case 884214533:
//                    if (string.equals("crop_guide_1.4")) {
//                        c = 2;
//                        break;
//                    }
//                    break;
//                case 884214534:
//                    if (string.equals("crop_guide_1.5")) {
//                        c = 3;
//                        break;
//                    }
//                    break;
//                case 884215494:
//                    if (string.equals("crop_guide_2.4")) {
//                        c = 4;
//                        break;
//                    }
//                    break;
//                case 1640846738:
//                    if (string.equals("crop_guide_1.25")) {
//                        c = 5;
//                        break;
//                    }
//                    break;
//                case 1640846767:
//                    if (string.equals("crop_guide_1.33")) {
//                        c = 6;
//                        break;
//                    }
//                    break;
//                case 1640846896:
//                    if (string.equals("crop_guide_1.78")) {
//                        c = 7;
//                        break;
//                    }
//                    break;
//                case 1640846924:
//                    if (string.equals("crop_guide_1.85")) {
//                        c = '\b';
//                        break;
//                    }
//                    break;
//                case 1640876558:
//                    if (string.equals("crop_guide_2.33")) {
//                        c = '\t';
//                        break;
//                    }
//                    break;
//                case 1640876560:
//                    if (string.equals("crop_guide_2.35")) {
//                        c = '\n';
//                        break;
//                    }
//                    break;
//            }
//            switch (c) {
//                case 0:
//                    d = close_level_angle;
//                    break;
//                case 1:
//                    d = 2.0d;
//                    break;
//                case 2:
//                    d = 1.4d;
//                    break;
//                case 3:
//                    d = 1.5d;
//                    break;
//                case 4:
//                    d = 2.4d;
//                    break;
//                case 5:
//                    d = 1.25d;
//                    break;
//                case 6:
//                    d = 1.33333333d;
//                    break;
//                case 7:
//                    d = 1.77777778d;
//                    break;
//                case '\b':
//                    d = 1.85d;
//                    break;
//                case '\t':
//                    d = 2.33333333d;
//                    break;
//                case '\n':
//                    d = 2.3500612d;
//                    break;
//            }
//            if (d > 0.0d && Math.abs(preview.getCurrentPreviewAspectRatio() - d) > 1.0E-5d) {
//                int width = canvas.getWidth() - 1;
//                int height = canvas.getHeight() - 1;
//                if (d > preview.getTargetRatio()) {
//                    int width2 = (int) (canvas.getWidth() / (d * 2.0d));
//                    i = (canvas.getHeight() / 2) - width2;
//                    height = width2 + (canvas.getHeight() / 2);
//                } else {
//                    int height2 = (int) ((canvas.getHeight() * d) / 2.0d);
//                    width = (canvas.getWidth() / 2) + height2;
//                    i2 = (canvas.getWidth() / 2) - height2;
//                    i = 1;
//                }
//                canvas.drawRect(i2, i, width, height, this.p);
//            }
//            this.p.setStyle(Paint.Style.FILL);
//        }
//    }

//    private void drawCropGuides(Canvas canvas) {
//        Preview preview = main_activity.getPreview();
//        CameraController camera_controller = preview.getCameraController();
//        if (preview.isVideo() || preview_size_wysiwyg_pref) {
//            String preference_crop_guide = sharedPreferences.getString(PreferenceKeys.ShowCropGuidePreferenceKey, "crop_guide_none");
//            if (camera_controller != null && preview.getTargetRatio()>0.0 && !preference_crop_guide.equals("crop_guide_none")) {
//                double crop_ratio = -1.0;
//                switch (preference_crop_guide) {
//                    case "crop_guide_1":
//                        crop_ratio = 1.0;
//                        break;
//                    case "crop_guide_1.25":
//                        crop_ratio = 1.25;
//                        break;
//                    case "crop_guide_1.33":
//                        crop_ratio = 1.33333333;
//                        break;
//                    case "crop_guide_1.4":
//                        crop_ratio = 1.4;
//                        break;
//                    case "crop_guide_1.5":
//                        crop_ratio = 1.5;
//                        break;
//                    case "crop_guide_1.78":
//                        crop_ratio = 1.77777778;
//                        break;
//                    case "crop_guide_1.85":
//                        crop_ratio = 1.85;
//                        break;
//                    case "crop_guide_2":
//                        crop_ratio = 2.0;
//                        break;
//                    case "crop_guide_2.33":
//                        crop_ratio = 2.33333333;
//                        break;
//                    case "crop_guide_2.35":
//                        crop_ratio = 2.35006120; // actually 1920:817
//                        break;
//                    case "crop_guide_2.4":
//                        crop_ratio = 2.4;
//                        break;
//                }
//                if (crop_ratio>0.0) {
//                    // we should compare to getCurrentPreviewAspectRatio() not getTargetRatio(), as the actual preview
//                    // aspect ratio may differ to the requested photo/video resolution's aspect ratio, in which case it's still useful
//                    // to display the crop guide
//                    double preview_aspect_ratio = preview.getCurrentPreviewAspectRatio();
//                    MainActivity.SystemOrientation system_orientation = main_activity.getSystemOrientation();
//                    boolean system_orientation_portrait = system_orientation == MainActivity.SystemOrientation.PORTRAIT;
//                    if (system_orientation_portrait) {
//                        // crop ratios are always drawn as if in landscape
//                        crop_ratio = 1.0 / crop_ratio;
//                        preview_aspect_ratio = 1.0 / preview_aspect_ratio;
//                    }
//                    if (Math.abs(preview_aspect_ratio - crop_ratio)>1.0e-5) {
//                        /*if( MyDebug.LOG ) {
//                            Log.d(TAG, "crop_ratio: " + crop_ratio);
//                            Log.d(TAG, "preview_aspect_ratio: " + preview_aspect_ratio);
//                            Log.d(TAG, "canvas width: " + canvas.getWidth());
//                            Log.d(TAG, "canvas height: " + canvas.getHeight());
//                        }*/
//                        p.setStyle(Paint.Style.FILL);
//                        p.setColor(Color.rgb(0, 0, 0));
//                        p.setAlpha(160);
//                        int left = 1, top = 1, right = canvas.getWidth() - 1, bottom = canvas.getHeight() - 1;
//                        if (crop_ratio>preview_aspect_ratio) {
//                            // crop ratio is wider, so we have to crop top/bottom
//                            double new_hheight = ((double) canvas.getWidth()) / (2.0f * crop_ratio);
//                            top = (canvas.getHeight() / 2 - (int) new_hheight);
//                            bottom = (canvas.getHeight() / 2 + (int) new_hheight);
//                            // draw shaded area
//                            canvas.drawRect(0, 0, canvas.getWidth(), top, p);
//                            canvas.drawRect(0, bottom, canvas.getWidth(), canvas.getHeight(), p);
//                        } else {
//                            // crop ratio is taller, so we have to crop left/right
//                            double new_hwidth = (((double) canvas.getHeight()) * crop_ratio) / 2.0f;
//                            left = (canvas.getWidth() / 2 - (int) new_hwidth);
//                            right = (canvas.getWidth() / 2 + (int) new_hwidth);
//                            // draw shaded area
//                            canvas.drawRect(0, 0, left, canvas.getHeight(), p);
//                            canvas.drawRect(right, 0, canvas.getWidth(), canvas.getHeight(), p);
//                        }
//                        p.setStyle(Paint.Style.STROKE);
//                        p.setStrokeWidth(stroke_width);
//                        p.setColor(Color.rgb(255, 235, 59)); // Yellow 500
//                        canvas.drawRect(left, top, right, bottom, p);
//                        p.setStyle(Paint.Style.FILL); // reset
//                        p.setAlpha(255); // reset
//                    }
//                }
//            }
//        }
//    }

    private void drawCropGuides(Canvas canvas) {
        int width;
        int i;
        int width2;
        int i2;
        Preview preview = this.main_activity.getPreview();
        CameraController cameraController = preview.getCameraController();
        if (preview.isVideo() || this.preview_size_wysiwyg_pref) {
            String string = this.sharedPreferences.getString(PreferenceKeys.ShowCropGuidePreferenceKey, "crop_guide_none");
            if (cameraController == null || preview.getTargetRatio() <= 0.0d || string.equals("crop_guide_none")) {
                return;
            }
            this.p.setStyle(Paint.Style.STROKE);
            this.p.setStrokeWidth(this.stroke_width);
            this.p.setColor(Color.rgb(255, 235, 59));
            double d = -1.0d;
            char c = 65535;
            switch (string.hashCode()) {
                case -1272821505:
                    if (string.equals("crop_guide_1")) {
                        c = 0;
                        break;
                    }
                    break;
                case -1272821504:
                    if (string.equals("crop_guide_2")) {
                        c = 7;
                        break;
                    }
                    break;
                case 884214533:
                    if (string.equals("crop_guide_1.4")) {
                        c = 3;
                        break;
                    }
                    break;
                case 884214534:
                    if (string.equals("crop_guide_1.5")) {
                        c = 4;
                        break;
                    }
                    break;
                case 884215494:
                    if (string.equals("crop_guide_2.4")) {
                        c = '\n';
                        break;
                    }
                    break;
                case 1640846738:
                    if (string.equals("crop_guide_1.25")) {
                        c = 1;
                        break;
                    }
                    break;
                case 1640846767:
                    if (string.equals("crop_guide_1.33")) {
                        c = 2;
                        break;
                    }
                    break;
                case 1640846896:
                    if (string.equals("crop_guide_1.78")) {
                        c = 5;
                        break;
                    }
                    break;
                case 1640846924:
                    if (string.equals("crop_guide_1.85")) {
                        c = 6;
                        break;
                    }
                    break;
                case 1640876558:
                    if (string.equals("crop_guide_2.33")) {
                        c = '\b';
                        break;
                    }
                    break;
                case 1640876560:
                    if (string.equals("crop_guide_2.35")) {
                        c = '\t';
                        break;
                    }
                    break;
            }
            switch (c) {
                case 0:
                    d = close_level_angle;
                    break;
                case 1:
                    d = 1.25d;
                    break;
                case 2:
                    d = 1.33333333d;
                    break;
                case 3:
                    d = 1.4d;
                    break;
                case 4:
                    d = 1.5d;
                    break;
                case 5:
                    d = 1.77777778d;
                    break;
                case 6:
                    d = 1.85d;
                    break;
                case 7:
                    d = 2.0d;
                    break;
                case '\b':
                    d = 2.33333333d;
                    break;
                case '\t':
                    d = 2.3500612d;
                    break;
                case '\n':
                    d = 2.4d;
                    break;
            }
            if (d > 0.0d && Math.abs(preview.getCurrentPreviewAspectRatio() - d) > 1.0E-5d) {
                int width3 = canvas.getWidth() - 1;
                int height = canvas.getHeight() - 1;
                if (d > preview.getTargetRatio()) {
                    int width4 = (int) (canvas.getWidth() / (d * 2.0d));
                    i2 = (canvas.getHeight() / 2) - width4;
                    i = width4 + (canvas.getHeight() / 2);
                    width2 = width3;
                    width = 1;
                } else {
                    int height2 = (int) ((canvas.getHeight() * d) / 2.0d);
                    width = (canvas.getWidth() / 2) - height2;
                    i = height;
                    width2 = height2 + (canvas.getWidth() / 2);
                    i2 = 1;
                }
                canvas.drawRect(width, i2, width2, i, this.p);
            }
            this.p.setStyle(Paint.Style.FILL);
        }
    }

//    private void onDrawInfoLines(Canvas canvas0, int v, int v1, int v2, long v3) {
//        Preview preview3;
//        Preview preview2 = null;
//        long v27;
//        int v24;
//        int v20;
//        int v19;
//        int v18;
//        Preview preview1;
//        int v17;
//        int v16;
//        int v14;
//        int v13;
//        int v9;
//        int v8;
//        DrawPreview drawPreview0 = this;
//        Canvas canvas1 = canvas0;
//        long v4 = v3;
//        Preview preview0 = drawPreview0.main_activity.getPreview();
//        CameraController cameraController0 = preview0.getCameraController();
//        int v5 = preview0.getUIRotation();
//        boolean rotation = false;
//        drawPreview0.p.setTextSize(drawPreview0.scale * 16.0f + 0.5f);
//        drawPreview0.p.setTextAlign(Paint.Align.LEFT);
//        int v6 = (int) (8.0f * drawPreview0.scale + 0.5f);
//        int v7 = (int) (drawPreview0.scale * 2.0f + 0.5f);
//        if (v5 != 90 && v5 != 270) {
//            v8 = v;
//            v9 = v1;
//            rotation = true;
//        } else {
//            int v10 = (canvas0.getWidth() - canvas0.getHeight()) / 2;
//            v8 = v + v10;
//            v9 = v1 - v10;
//        }
//
//        if (v5 == 90) {
//            v9 = canvas0.getHeight() - v9 - ((int) (drawPreview0.scale * 20.0f + 0.5f));
//        }
//
//        int v11 = v9;
//        if (v5 == 180) {
//            int v12 = canvas0.getWidth() - v8;
//            drawPreview0.p.setTextAlign(Paint.Align.RIGHT);
//            v13 = v12;
//            v14 = 1;
//        } else {
//            v13 = v8;
//            v14 = 0;
//        }
//
//        drawPreview0.applicationInterface.drawStamp(canvas0, drawPreview0.p);
//        if (drawPreview0.show_time_pref) {
//            if (drawPreview0.current_time_string == null || v4 / 1000L>drawPreview0.last_current_time_time / 1000L) {
//                Calendar calendar0 = drawPreview0.calendar;
//                if (calendar0 == null) {
//                    drawPreview0.calendar = Calendar.getInstance();
//                } else {
//                    calendar0.setTimeInMillis(v4);
//                }
//
//                drawPreview0.current_time_string = drawPreview0.dateFormatTimeInstance.format(drawPreview0.calendar.getTime());
//                drawPreview0.last_current_time_time = v4;
//            }
//
//            if (drawPreview0.text_bounds_time == null) {
//                Log.d("DrawPreview", "compute text_bounds_time");
//                drawPreview0.text_bounds_time = new Rect();
//                Calendar calendar1 = Calendar.getInstance();
//                calendar1.set(100, 0, 1, 10, 59, 59);
//                String s = drawPreview0.dateFormatTimeInstance.format(calendar1.getTime());
//                Log.d("DrawPreview", "bounds_time_string:" + s);
//                Rect rect0 = drawPreview0.text_bounds_time;
//                drawPreview0.p.getTextBounds(s, 0, s.length(), rect0);
//            }
//
//            int v15 = drawPreview0.text_bounds_time.width() + v6;
//            v16 = v7;
//            v17 = v5;
//            preview1 = preview0;
//            v18 = Math.max(0, drawPreview0.applicationInterface.drawTextWithBackground(canvas0,         // canvas0:android.graphics.Canvas
//                    drawPreview0.p,  // paint0:android.graphics.Paint
//                    drawPreview0.current_time_string, // s:java.lang.String
//                    -1,              // v:int
//                    0xFF000000,      // v1:int
//                    v13,             // v2:int
//                    v11,             // v3:int
//                    MyApplicationInterface.Alignment.ALIGNMENT_TOP, // myApplicationInterface$Alignment0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Alignment
//                    null,            // s1:java.lang.String
//                    MyApplicationInterface.Shadow.SHADOW_OUTLINE, // myApplicationInterface$Shadow0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Shadow
//                    drawPreview0.text_bounds_time // rect0:android.graphics.Rect
//            ));
//            v19 = v15;
//        } else {
//            v16 = v7;
//            v17 = v5;
//            preview1 = preview0;
//            v19 = 0;
//            v18 = 0;
//        }
//
//        if ((drawPreview0.show_camera_id_pref) && cameraController0 != null) {
//            if (drawPreview0.camera_id_string == null || v4>drawPreview0.last_camera_id_time + 10000L) {
//                drawPreview0.camera_id_string = this.getContext().getResources().getString(R.string.camera_id) + ":" + preview1.getCameraId();  // string:camera_id "ID"
//                drawPreview0.last_camera_id_time = v4;
//            }
//
//            if (drawPreview0.text_bounds_camera_id == null) {
//                Log.d("DrawPreview", "compute text_bounds_camera_id");
//                drawPreview0.text_bounds_camera_id = new Rect();
//                Rect rect1 = drawPreview0.text_bounds_camera_id;
//                drawPreview0.p.getTextBounds(drawPreview0.camera_id_string, 0, drawPreview0.camera_id_string.length(), rect1);
//            }
//
//            v20 = Math.max(v18, drawPreview0.applicationInterface.drawTextWithBackground(canvas0,         // canvas0:android.graphics.Canvas
//                    drawPreview0.p,  // paint0:android.graphics.Paint
//                    drawPreview0.camera_id_string, // s:java.lang.String
//                    -1,              // v:int
//                    0xFF000000,      // v1:int
//                    (v14 == 0 ? v13 + v19 : v13 - v19), // v2:int
//                    v11,             // v3:int
//                    MyApplicationInterface.Alignment.ALIGNMENT_TOP, // myApplicationInterface$Alignment0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Alignment
//                    null,            // s1:java.lang.String
//                    MyApplicationInterface.Shadow.SHADOW_OUTLINE, // myApplicationInterface$Shadow0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Shadow
//                    drawPreview0.text_bounds_camera_id // rect0:android.graphics.Rect
//            ));
//        } else {
//            v20 = v18;
//        }
//
//        int v21 = v17;
//        int v22 = v21 == 90 ? v11 - v20 : v11 + v20;
//        if (cameraController0 != null && (drawPreview0.show_free_memory_pref)) {
//            if (drawPreview0.last_free_memory_time == 0L || v4>drawPreview0.last_free_memory_time + 10000L) {
//                long v23 = drawPreview0.main_activity.getStorageUtils().freeMemory();
//                if (v23>=0L) {
//                    float f = ((float) v23) / 1024.0f;
//                    Log.d("DrawPreview", "free_memory_gb: " + drawPreview0.free_memory_gb);
//                    Log.d("DrawPreview", "new_free_memory_gb: " + f);
//                    if (Math.abs(f - drawPreview0.free_memory_gb)>0.001f) {
//                        drawPreview0.free_memory_gb = f;
//                        drawPreview0.free_memory_gb_string = DrawPreview.decimalFormat.format(((double) drawPreview0.free_memory_gb)) + this.getContext().getResources().getString(R.string.gb_abbreviation);  // string:gb_abbreviation "GB"
//                    }
//                }
//
//                drawPreview0.last_free_memory_time = v4;
//            }
//
//            if (drawPreview0.free_memory_gb>=0.0f && drawPreview0.free_memory_gb_string != null) {
//                if (drawPreview0.text_bounds_free_memory == null) {
//                    Log.d("DrawPreview", "compute text_bounds_free_memory");
//                    drawPreview0.text_bounds_free_memory = new Rect();
//                    Rect rect2 = drawPreview0.text_bounds_free_memory;
//                    drawPreview0.p.getTextBounds(drawPreview0.free_memory_gb_string, 0, drawPreview0.free_memory_gb_string.length(), rect2);
//                }
//
//                v24 = v21;
//                int v25 = drawPreview0.applicationInterface.drawTextWithBackground(canvas0,         // canvas0:android.graphics.Canvas
//                        drawPreview0.p,  // paint0:android.graphics.Paint
//                        drawPreview0.free_memory_gb_string, // s:java.lang.String
//                        -1,              // v:int
//                        0xFF000000,      // v1:int
//                        v13,             // v2:int
//                        v22,             // v3:int
//                        MyApplicationInterface.Alignment.ALIGNMENT_TOP, // myApplicationInterface$Alignment0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Alignment
//                        null,            // s1:java.lang.String
//                        MyApplicationInterface.Shadow.SHADOW_OUTLINE, // myApplicationInterface$Shadow0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Shadow
//                        drawPreview0.text_bounds_free_memory // rect0:android.graphics.Rect
//                );
//                if (v24 == 90) {
//                    v22 -= v25;
//                } else {
//                    v22 += v25;
//                }
//            } else {
//                v24 = v21;
//            }
//        } else {
//            v24 = v21;
//        }
//
//        int v26 = (int) (27.0f * drawPreview0.scale + 0.5f);
//        drawPreview0.p.setTextSize(drawPreview0.scale * 24.0f + 0.5f);
//        if (drawPreview0.OSDLine1 != null && drawPreview0.OSDLine1.length()>0) {
//            drawPreview0.applicationInterface.drawTextWithBackground(canvas0,         // canvas0:android.graphics.Canvas
//                    drawPreview0.p,  // paint0:android.graphics.Paint
//                    drawPreview0.OSDLine1, // s:java.lang.String
//                    -1,              // v:int
//                    0xFF000000,      // v1:int
//                    v13,             // v2:int
//                    v2 - v26,        // v3:int
//                    MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM, // myApplicationInterface$Alignment0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Alignment
//                    null,            // s1:java.lang.String
//                    MyApplicationInterface.Shadow.SHADOW_OUTLINE // myApplicationInterface$Shadow0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Shadow
//            );
//        }
//
//        if (drawPreview0.OSDLine2 != null && drawPreview0.OSDLine2.length()>0) {
//            drawPreview0.applicationInterface.drawTextWithBackground(canvas0,         // canvas0:android.graphics.Canvas
//                    drawPreview0.p,  // paint0:android.graphics.Paint
//                    drawPreview0.OSDLine2, // s:java.lang.String
//                    -1,              // v:int
//                    0xFF000000,      // v1:int
//                    v13,             // v2:int
//                    v2,              // v3:int
//                    MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM, // myApplicationInterface$Alignment0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Alignment
//                    null,            // s1:java.lang.String
//                    MyApplicationInterface.Shadow.SHADOW_OUTLINE // myApplicationInterface$Shadow0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Shadow
//            );
//        }
//
//        drawPreview0.p.setTextSize(drawPreview0.scale * 16.0f + 0.5f);
//        if (cameraController0 != null && (drawPreview0.show_iso_pref)) {
//            if (drawPreview0.iso_exposure_string == null) {
//                v27 = v3;
//
//
//                if (cameraController0.captureResultHasExposureTime()) {
//                    long v29 = cameraController0.captureResultExposureTime();
//                    if (drawPreview0.iso_exposure_string.length()>0) {
//                        drawPreview0.iso_exposure_string = drawPreview0.iso_exposure_string + " ";
//                    }
//
//                    drawPreview0.iso_exposure_string = drawPreview0.iso_exposure_string + preview2.getExposureTimeString(v29);
//                }
//
//                if ((preview2.isVideoRecording()) && (cameraController0.captureResultHasFrameDuration())) {
//                    long v30 = cameraController0.captureResultFrameDuration();
//                    if (drawPreview0.iso_exposure_string.length()>0) {
//                        drawPreview0.iso_exposure_string = drawPreview0.iso_exposure_string + " ";
//                    }
//
//                    drawPreview0.iso_exposure_string = drawPreview0.iso_exposure_string + preview2.getFrameDurationString(v30);
//                }
//
//                drawPreview0.is_scanning = false;
//                if ((cameraController0.captureResultIsAEScanning()) && (drawPreview0.sharedPreferences.getString("preference_iso", "auto").equals("auto"))) {
//                    drawPreview0.is_scanning = true;
//                }
//
//                drawPreview0.last_iso_exposure_time = v27;
//            } else {
//                v27 = v3;
//                if (v27>drawPreview0.last_iso_exposure_time + 500L) {
////                    label_462:
//                    drawPreview0.iso_exposure_string = "";
//                    if (cameraController0.captureResultHasIso()) {
//                        int v28 = cameraController0.captureResultIso();
//                        if (drawPreview0.iso_exposure_string.length()>0) {
//                            drawPreview0.iso_exposure_string = drawPreview0.iso_exposure_string + " ";
//                        }
//
//                        preview2 = preview1;
//                        drawPreview0.iso_exposure_string = drawPreview0.iso_exposure_string + preview2.getISOString(v28);
//                    } else {
//                        preview2 = preview1;
//                    }
//                }
//
//                preview2 = preview1;
//            }
//
//            if (drawPreview0.iso_exposure_string.length()>0) {
//                int v31 = Color.rgb(0xFF, 0xEB, 59);
//                if (drawPreview0.is_scanning) {
//                    long v32 = drawPreview0.ae_started_scanning_ms;
//                    if (v32 == -1L) {
//                        drawPreview0.ae_started_scanning_ms = v27;
//                    } else if (v27 - v32>500L) {
//                        v31 = Color.rgb(0xF4, 67, 54);
//                    }
//                } else {
//                    drawPreview0.ae_started_scanning_ms = -1L;
//                }
//
//                preview3 = preview2;
//                int v33 = drawPreview0.applicationInterface.drawTextWithBackground(canvas0,         // canvas0:android.graphics.Canvas
//                        drawPreview0.p,  // paint0:android.graphics.Paint
//                        drawPreview0.iso_exposure_string, // s:java.lang.String
//                        v31,             // v:int
//                        0xFF000000,      // v1:int
//                        v13,             // v2:int
//                        v22,             // v3:int
//                        MyApplicationInterface.Alignment.ALIGNMENT_TOP, // myApplicationInterface$Alignment0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Alignment
//                        drawPreview0.ybounds_text, // s1:java.lang.String
//                        MyApplicationInterface.Shadow.SHADOW_OUTLINE // myApplicationInterface$Shadow0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Shadow
//                );
//                if (v24 == 90) {
//                    v22 -= v33;
//                } else {
//                    v22 += v33;
//                }
//            } else {
//                preview3 = preview2;
//            }
//        } else {
//            preview3 = preview1;
//        }
//
//        int v34 = v22;
//        float f1 = drawPreview0.scale;
//        int v35 = (int) (1.0f * f1 + 0.5f);
//        if (cameraController0 != null) {
//            int v36 = v13 - v35;
//            int v37 = (int) (f1 * 16.0f + 0.5f);
//            if (v24 == 180) {
//                v36 = v13 - v37 + v35;
//            }
//
//            long v38 = v3;
//            if (v38>drawPreview0.last_need_flash_indicator_time + 100L) {
//                drawPreview0.need_flash_indicator = false;
//                String s1 = preview3.getCurrentFlashValue();
//                if (s1 != null && ((s1.equals("flash_on")) || ((s1.equals("flash_auto")) || (s1.equals("flash_red_eye"))) && (cameraController0.needsFlash()) || (cameraController0.needsFrontScreenFlash())) && !drawPreview0.applicationInterface.isVideoPref()) {
//                    drawPreview0.need_flash_indicator = true;
//                }
//
//                drawPreview0.last_need_flash_indicator_time = v38;
//            }
//
//            if (!drawPreview0.need_flash_indicator) {
//                drawPreview0.needs_flash_time = -1L;
//            } else if (drawPreview0.needs_flash_time == -1L) {
//                drawPreview0.needs_flash_time = v38;
//            } else {
//                drawPreview0.icon_dest.set(v36, v34, v36 + v37, v34 + v37);
//            }
//
//            v34 = v24 == 90 ? v34 - v16 : v34 + (v37 + v16);
//        }
//
//        if (cameraController0 != null && (preview3.isPreviewBitmapEnabled())) {
//            int[] arr_v = preview3.getHistogram();
//            if (arr_v != null) {
//                int v39 = (int) (100.0f * drawPreview0.scale + 0.5f);
//                int v40 = (int) (drawPreview0.scale * 60.0f + 0.5f);
//                int v41 = (v24 == 180 ? v13 - v39 + v35 : v13 - v35) - v35;
//                drawPreview0.icon_dest.set(v41, v34, v39 + v41, v34 + v40);
//                if (v24 == 90) {
//                    drawPreview0.icon_dest.top -= v40;
//                    drawPreview0.icon_dest.bottom -= v40;
//                }
//
//                drawPreview0.p.setStyle(Paint.Style.FILL);
//                int v42 = Color.argb(0x40, 0, 0, 0);
//                drawPreview0.p.setColor(v42);
//                Canvas canvas2 = canvas0;
//                canvas2.drawRect(drawPreview0.icon_dest, drawPreview0.p);
//                int v43 = arr_v.length;
//                int v44 = 0;
//                int v45 = 0;
//                while (v44<v43) {
//                    v45 = Math.max(v45, arr_v[v44]);
//                    ++v44;
//                }
//
//                if (arr_v.length == 0x300) {
//                    int v46 = 0;
//                    int v47;
//                    for (v47 = 0; v46<0x100; ++v47) {
//                        drawPreview0.temp_histogram_channel[v46] = arr_v[v47];
//                        ++v46;
//                    }
//
//                    int v48 = Color.argb(0x97, 0xFF, 0, 0);
//                    drawPreview0.p.setColor(v48);
//                    drawPreview0.drawHistogramChannel(canvas2, drawPreview0.temp_histogram_channel, v45);
//                    int v49 = 0;
//                    while (v49<0x100) {
//                        drawPreview0.temp_histogram_channel[v49] = arr_v[v47];
//                        ++v49;
//                        ++v47;
//                    }
//
//                    int v50 = Color.argb(110, 0, 0xFF, 0);
//                    drawPreview0.p.setColor(v50);
//                    drawPreview0.drawHistogramChannel(canvas2, drawPreview0.temp_histogram_channel, v45);
//                    int v51 = 0;
//                    while (v51<0x100) {
//                        drawPreview0.temp_histogram_channel[v51] = arr_v[v47];
//                        ++v51;
//                        ++v47;
//                    }
//
//                    int v52 = Color.argb(94, 0, 0, 0xFF);
//                    drawPreview0.p.setColor(v52);
//                    drawPreview0.drawHistogramChannel(canvas2, drawPreview0.temp_histogram_channel, v45);
//                    return;
//                }
//
//                int v53 = Color.argb(0xC0, 0xFF, 0xFF, 0xFF);
//                drawPreview0.p.setColor(v53);
//                drawPreview0.drawHistogramChannel(canvas2, arr_v, v45);
//            }
//        }
//    }

    private void onDrawInfoLines(Canvas canvas, int i, int i2, int i3, long j) {
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int[] histogram;
        Preview preview = this.main_activity.getPreview();
        CameraController cameraController = preview.getCameraController();
        int uIRotation = preview.getUIRotation();
        this.p.setTextSize((this.scale * 16.0f) + 0.5f);
        this.p.setTextAlign(Paint.Align.LEFT);
        int i11 = (int) ((this.scale * 0.0f) + 0.5f);
        if (uIRotation == 90 || uIRotation == 270) {
            int width = (canvas.getWidth() - canvas.getHeight()) / 2;
            i4 = i + width;
            i5 = i2 - width;
        } else {
            i4 = i;
            i5 = i2;
        }
        int height = uIRotation == 90 ? (canvas.getHeight() - i5) - ((int) ((this.scale * 20.0f) + 0.5f)) : i5;
        if (uIRotation == 180) {
            int width2 = canvas.getWidth() - i4;
            this.p.setTextAlign(Paint.Align.RIGHT);
            i6 = width2;
        } else {
            i6 = i4;
        }
        this.applicationInterface.drawStamp(canvas, this.p);
        float f = this.scale;
        int i12 = (int) ((27.0f * f) + 0.5f);
        this.p.setTextSize((f * 24.0f) + 0.5f);
        String str = this.OSDLine1;
        if (str == null || str.length() <= 0) {
            i7 = i11;
            i8 = uIRotation;
        } else {
            i7 = i11;
            i8 = uIRotation;
            this.applicationInterface.drawTextWithBackground(canvas, this.p, this.OSDLine1, -1, -16777216, i6, i3 - i12, MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM, null, MyApplicationInterface.Shadow.SHADOW_OUTLINE);
        }
        String str2 = this.OSDLine2;
        if (str2 != null && str2.length() > 0) {
            this.applicationInterface.drawTextWithBackground(canvas, this.p, this.OSDLine2, -1, -16777216, i6, i3, MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM, null, MyApplicationInterface.Shadow.SHADOW_OUTLINE);
        }
        this.p.setTextSize((this.scale * 16.0f) + 0.5f);
        if (cameraController != null && this.show_iso_pref) {
            if (this.iso_exposure_string == null || j > this.last_iso_exposure_time + 500) {
                this.iso_exposure_string = "";
                if (cameraController.captureResultHasIso()) {
                    int captureResultIso = cameraController.captureResultIso();
                    if (this.iso_exposure_string.length() > 0) {
                        this.iso_exposure_string += " ";
                    }
                    this.iso_exposure_string += preview.getISOString(captureResultIso);
                }
                if (cameraController.captureResultHasExposureTime()) {
                    long captureResultExposureTime = cameraController.captureResultExposureTime();
                    if (this.iso_exposure_string.length() > 0) {
                        this.iso_exposure_string += " ";
                    }
                    this.iso_exposure_string += preview.getExposureTimeString(captureResultExposureTime);
                }
                if (preview.isVideoRecording() && cameraController.captureResultHasFrameDuration()) {
                    long captureResultFrameDuration = cameraController.captureResultFrameDuration();
                    if (this.iso_exposure_string.length() > 0) {
                        this.iso_exposure_string += " ";
                    }
                    this.iso_exposure_string += preview.getFrameDurationString(captureResultFrameDuration);
                }
                this.is_scanning = false;
                if (cameraController.captureResultIsAEScanning() && this.sharedPreferences.getString(PreferenceKeys.ShowISOPreferenceKey, "auto").equals("auto")) {
                    this.is_scanning = true;
                }
                this.last_iso_exposure_time = j;
            }
            if (this.iso_exposure_string.length() > 0) {
                int rgb = Color.rgb(255, 235, 59);
                if (this.is_scanning) {
                    long j2 = this.ae_started_scanning_ms;
                    if (j2 == -1) {
                        this.ae_started_scanning_ms = j;
                    } else if (j - j2 > 500) {
                        rgb = Color.rgb(244, 67, 54);
                    }
                } else {
                    this.ae_started_scanning_ms = -1L;
                }
                i10 = 255;
                int drawTextWithBackground = this.applicationInterface.drawTextWithBackground(canvas, this.p, this.iso_exposure_string, rgb, -16777216, i6, height, MyApplicationInterface.Alignment.ALIGNMENT_TOP, this.ybounds_text, MyApplicationInterface.Shadow.SHADOW_OUTLINE) + i7;
                i9 = 90;
                height = i8 == 90 ? height - drawTextWithBackground : height + drawTextWithBackground;
                int i13 = height;
                int i14 = (int) ((this.scale * 1.0f) + 0.5f);
                if (cameraController == null && preview.isPreviewBitmapEnabled() && (histogram = preview.getHistogram()) != null) {
                    float f2 = this.scale;
                    int i15 = (int) ((100.0f * f2) + 0.5f);
                    int i16 = (int) ((f2 * 60.0f) + 0.5f);
                    int i17 = i6 - i14;
                    if (i8 == 180) {
                        i17 = (i6 - i15) + i14;
                    }
                    int i18 = i17 - i14;
                    this.icon_dest.set(i18, i13, i15 + i18, i13 + i16);
                    if (i8 == i9) {
                        this.icon_dest.top -= i16;
                        this.icon_dest.bottom -= i16;
                    }
                    this.p.setStyle(Paint.Style.FILL);
                    this.p.setColor(Color.argb(64, 0, 0, 0));
                    canvas.drawRect(this.icon_dest, this.p);
                    int i19 = 0;
                    for (int i20 : histogram) {
                        i19 = Math.max(i19, i20);
                    }
                    if (histogram.length == 768) {
                        int i21 = 0;
                        int i22 = 0;
                        while (i21 < 256) {
                            this.temp_histogram_channel[i21] = histogram[i22];
                            i21++;
                            i22++;
                        }
                        this.p.setColor(Color.argb(151, i10, 0, 0));
                        drawHistogramChannel(canvas, this.temp_histogram_channel, i19);
                        int i23 = 0;
                        while (i23 < 256) {
                            this.temp_histogram_channel[i23] = histogram[i22];
                            i23++;
                            i22++;
                        }
                        this.p.setColor(Color.argb(110, 0, i10, 0));
                        drawHistogramChannel(canvas, this.temp_histogram_channel, i19);
                        int i24 = 0;
                        while (i24 < 256) {
                            this.temp_histogram_channel[i24] = histogram[i22];
                            i24++;
                            i22++;
                        }
                        this.p.setColor(Color.argb(94, 0, 0, i10));
                        drawHistogramChannel(canvas, this.temp_histogram_channel, i19);
                        return;
                    }
                    this.p.setColor(Color.argb(192, i10, i10, i10));
                    drawHistogramChannel(canvas, histogram, i19);
                    return;
                }
                return;
            }
        }
        i9 = 90;
        i10 = 255;
        int i132 = height;
        int i142 = (int) ((this.scale * 1.0f) + 0.5f);
        if (cameraController == null) {
        }
    }



    private void drawHistogramChannel(Canvas canvas, int[] iArr, int i) {
        this.path.reset();
        this.path.moveTo(this.icon_dest.left, this.icon_dest.bottom);
        for (int i2 = 0; i2<iArr.length; i2++) {
            this.path.lineTo(this.icon_dest.left + ((int) ((i2 / iArr.length) * this.icon_dest.width())), this.icon_dest.bottom - ((iArr[i2] * this.icon_dest.height()) / i));
        }
        this.path.lineTo(this.icon_dest.right, this.icon_dest.bottom);
        this.path.close();
        canvas.drawPath(this.path, this.p);
    }

    public static String formatLevelAngle(double d) {
        String format = decimalFormat.format(d);
        return Math.abs(d)<0.1d ? format.replaceAll("^-(?=0(.0*)?$)", "") : format;
    }



    private void drawUI(Canvas canvas0, long v) {
        int v64;
        long v51;
        int v38;
        long v25;
        int v19;
        int v18;
        int v16;
        int v8;
        int v7;
        boolean z2;
        double f2;
        int v6;
        int v5;
        int v12;
        int v13;
        DrawPreview drawPreview0 = this;
        long v1 = v;
        Preview preview0 = drawPreview0.main_activity.getPreview();
        CameraController cameraController0 = preview0.getCameraController();
        int v2 = preview0.getUIRotation();
        MainUI.UIPlacement mainUI$UIPlacement0 = drawPreview0.main_activity.getMainUI().getUIPlacement();
        boolean z = preview0.hasLevelAngle();
        double f = preview0.getLevelAngle();
        boolean z1 = preview0.hasGeoDirection();
        double f1 = preview0.getGeoDirection();
        canvas0.save();
        canvas0.rotate(((float)v2), ((float)canvas0.getWidth()) / 2.0f, ((float)canvas0.getHeight()) / 2.0f);
        if(cameraController0 != null && !preview0.isPreviewPaused()) {
            int v3 = (int)(20.0f * drawPreview0.scale + 0.5f);
            int v4 = (int)(drawPreview0.scale * 16.0f + 0.5f);
            if(mainUI$UIPlacement0 == MainUI.UIPlacement.UIPLACEMENT_TOP) {
                if(v2 != 0 && v2 != 180) {
                    v5 = v4;
//                    goto label_77;
                    if(v2 == (mainUI$UIPlacement0 == MainUI.UIPlacement.UIPLACEMENT_RIGHT ? 0 : 180)) {
                        v7 = canvas0.getHeight();
                        f2 = f;
                        v8 = (int)(((double)v3) * 0.1);
                        v6 = v7 - v8;
                        z2 = z;
                    }
                    else {
                        f2 = f;
                        if(v2 == (mainUI$UIPlacement0 == MainUI.UIPlacement.UIPLACEMENT_RIGHT ? 180 : 0)) {
                            v7 = canvas0.getHeight();
                            v8 = (int)(((double)v3) * 2.5);
                            v6 = v7 - v8;
                            z2 = z;
//                        label_179:
//                            v12 = !z2 || !drawPreview0.show_angle_pref ? 0 : 1;
//                            v13 = !z1 || !drawPreview0.show_geo_direction_pref ? 0 : 1;
//                            if(v12 == 0) {
//                                v19 = v3;
//                                v18 = v5;
//                            }
//                            else {
//                                drawPreview0.p.setTextSize(drawPreview0.scale * 14.0f + 0.5f);
//                                int v14 = v13 == 0 ? -((int)(((float)(f2 >= 0.0 ? 14 : 16)) * drawPreview0.scale + 0.5f)) : -((int)(drawPreview0.scale * 35.0f + 0.5f));
//                                drawPreview0.p.setTextAlign(Paint.Align.LEFT);
//                                if(Math.abs(f2) <= 1.0) {
//                                    int v15 = drawPreview0.angle_highlight_color_pref;
//                                    drawPreview0.p.setUnderlineText(true);
//                                    v16 = v15;
//                                }
//                                else {
//                                    v16 = -1;
//                                }
//
//                                if(drawPreview0.angle_string == null || v1 > drawPreview0.last_angle_string_time + 500L) {
//                                    drawPreview0.last_angle_string_time = v1;
//                                    drawPreview0.angle_string = DrawPreview.formatLevelAngle(f2) + '°';
//                                    drawPreview0.cached_angle = f2;
//                                }
//
//                                if(drawPreview0.text_bounds_angle_single == null) {
//                                    Log.d("DrawPreview", "compute text_bounds_angle_single");
//                                    Rect rect0 = new Rect();
//                                    drawPreview0.text_bounds_angle_single = rect0;
//                                    drawPreview0.p.getTextBounds("-9.0°", 0, 5, rect0);
//                                }
//
//                                if(drawPreview0.text_bounds_angle_double == null) {
//                                    Log.d("DrawPreview", "compute text_bounds_angle_double");
//                                    Rect rect1 = new Rect();
//                                    drawPreview0.text_bounds_angle_double = rect1;
//                                    drawPreview0.p.getTextBounds("-45.0°", 0, 6, rect1);
//                                }
//
//                                String s = drawPreview0.angle_string;
//                                int v17 = canvas0.getWidth() / 2 + v14;
//                                v18 = v5;
//                                v19 = v3;
//                                drawPreview0.applicationInterface.drawTextWithBackground(canvas0,         // canvas0:android.graphics.Canvas
//                                        drawPreview0.p,  // paint0:android.graphics.Paint
//                                        s,               // s:java.lang.String
//                                        v16,             // v:int
//                                        0xFF000000,      // v1:int
//                                        v17,             // v2:int
//                                        v6,              // v3:int
//                                        MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM, // myApplicationInterface$Alignment0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Alignment
//                                        null,            // s1:java.lang.String
//                                        MyApplicationInterface.Shadow.SHADOW_OUTLINE, // myApplicationInterface$Shadow0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Shadow
//                                        (Math.abs(drawPreview0.cached_angle) >= 10.0 ? drawPreview0.text_bounds_angle_double : drawPreview0.text_bounds_angle_single) // rect0:android.graphics.Rect
//                                );
//                                drawPreview0.p.setUnderlineText(false);
//                            }
//
//                            if(v13 != 0) {
//                                drawPreview0.p.setTextSize(drawPreview0.scale * 14.0f + 0.5f);
//                                int v20 = v12 == 0 ? -((int)(drawPreview0.scale * 14.0f + 0.5f)) : ((int)(drawPreview0.scale * 10.0f + 0.5f));
//                                drawPreview0.p.setTextAlign(Paint.Align.LEFT);
//                                float f3 = (float)Math.toDegrees(f1);
//                                int v21 = v20 + canvas0.getWidth() / 2;
//                                drawPreview0.applicationInterface.drawTextWithBackground(canvas0,         // canvas0:android.graphics.Canvas
//                                        drawPreview0.p,  // paint0:android.graphics.Paint
//                                        "" + Math.round((f3 >= 0.0f ? ((float)Math.toDegrees(f1)) : f3 + 360.0f)) + '°', // s:java.lang.String
//                                        -1,              // v:int
//                                        0xFF000000,      // v1:int
//                                        v21,             // v2:int
//                                        v6,              // v3:int
//                                        MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM, // myApplicationInterface$Alignment0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Alignment
//                                        drawPreview0.ybounds_text, // s1:java.lang.String
//                                        MyApplicationInterface.Shadow.SHADOW_OUTLINE // myApplicationInterface$Shadow0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Shadow
//                                );
//                            }


                        }

                        if(v2 != 90 && v2 != 270) {
                            z2 = z;
                            v6 = 0;
                        }
                        else {
                            if(drawPreview0.last_take_photo_top_time == 0L || v1 > drawPreview0.last_take_photo_top_time + 1000L) {
                                int v9 = drawPreview0.getViewOnScreenX(drawPreview0.main_activity.findViewById(R.id.take_photo));  // id:take_photo
                                preview0.getView().getLocationOnScreen(drawPreview0.gui_location);
                                drawPreview0.take_photo_top = v9 - drawPreview0.gui_location[0];
                                drawPreview0.last_take_photo_top_time = v1;
                            }

                            int v10 = drawPreview0.take_photo_top - canvas0.getWidth() / 2;
                            int v11 = canvas0.getWidth();
                            if(v2 == 90) {
                                v11 -= (int)(((double)v3) * 2.5);
                            }

                            if(canvas0.getWidth() / 2 + v10 > v11) {
                                v10 = v11 - canvas0.getWidth() / 2;
                            }

                            z2 = z;
                            v6 = canvas0.getHeight() / 2 + v10 - ((int)(((double)v3) * 0.5));
                        }
                    }
                }


                v5 = v4;
                v6 = canvas0.getHeight() - ((int)(((double)v3) * 0.1));
                f2 = f;
                z2 = z;
            }
            else {
                v5 = v4;
//                label_77:
                if(v2 == (mainUI$UIPlacement0 == MainUI.UIPlacement.UIPLACEMENT_RIGHT ? 0 : 180)) {
                    v7 = canvas0.getHeight();
                    f2 = f;
                    v8 = (int)(((double)v3) * 0.1);
                    v6 = v7 - v8;
                    z2 = z;
                }
                else {
                    f2 = f;
                    if(v2 == (mainUI$UIPlacement0 == MainUI.UIPlacement.UIPLACEMENT_RIGHT ? 180 : 0)) {
                        v7 = canvas0.getHeight();
                        v8 = (int)(((double)v3) * 2.5);
                        v6 = v7 - v8;
                        z2 = z;
//                        label_179:
//                        v12 = !z2 || !drawPreview0.show_angle_pref ? 0 : 1;
//                        v13 = !z1 || !drawPreview0.show_geo_direction_pref ? 0 : 1;
//                        if(v12 == 0) {
//                            v19 = v3;
//                            v18 = v5;
//                        }
//                        else {
//                            drawPreview0.p.setTextSize(drawPreview0.scale * 14.0f + 0.5f);
//                            int v14 = v13 == 0 ? -((int)(((float)(f2 >= 0.0 ? 14 : 16)) * drawPreview0.scale + 0.5f)) : -((int)(drawPreview0.scale * 35.0f + 0.5f));
//                            drawPreview0.p.setTextAlign(Paint.Align.LEFT);
//                            if(Math.abs(f2) <= 1.0) {
//                                int v15 = drawPreview0.angle_highlight_color_pref;
//                                drawPreview0.p.setUnderlineText(true);
//                                v16 = v15;
//                            }
//                            else {
//                                v16 = -1;
//                            }
//
//                            if(drawPreview0.angle_string == null || v1 > drawPreview0.last_angle_string_time + 500L) {
//                                drawPreview0.last_angle_string_time = v1;
//                                drawPreview0.angle_string = DrawPreview.formatLevelAngle(f2) + '°';
//                                drawPreview0.cached_angle = f2;
//                            }
//
//                            if(drawPreview0.text_bounds_angle_single == null) {
//                                Log.d("DrawPreview", "compute text_bounds_angle_single");
//                                Rect rect0 = new Rect();
//                                drawPreview0.text_bounds_angle_single = rect0;
//                                drawPreview0.p.getTextBounds("-9.0°", 0, 5, rect0);
//                            }
//
//                            if(drawPreview0.text_bounds_angle_double == null) {
//                                Log.d("DrawPreview", "compute text_bounds_angle_double");
//                                Rect rect1 = new Rect();
//                                drawPreview0.text_bounds_angle_double = rect1;
//                                drawPreview0.p.getTextBounds("-45.0°", 0, 6, rect1);
//                            }
//
//                            String s = drawPreview0.angle_string;
//                            int v17 = canvas0.getWidth() / 2 + v14;
//                            v18 = v5;
//                            v19 = v3;
//                            drawPreview0.applicationInterface.drawTextWithBackground(canvas0,         // canvas0:android.graphics.Canvas
//                                    drawPreview0.p,  // paint0:android.graphics.Paint
//                                    s,               // s:java.lang.String
//                                    v16,             // v:int
//                                    0xFF000000,      // v1:int
//                                    v17,             // v2:int
//                                    v6,              // v3:int
//                                    MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM, // myApplicationInterface$Alignment0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Alignment
//                                    null,            // s1:java.lang.String
//                                    MyApplicationInterface.Shadow.SHADOW_OUTLINE, // myApplicationInterface$Shadow0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Shadow
//                                    (Math.abs(drawPreview0.cached_angle) >= 10.0 ? drawPreview0.text_bounds_angle_double : drawPreview0.text_bounds_angle_single) // rect0:android.graphics.Rect
//                            );
//                            drawPreview0.p.setUnderlineText(false);
//                        }

//                        if(v13 != 0) {
//                            drawPreview0.p.setTextSize(drawPreview0.scale * 14.0f + 0.5f);
//                            int v20 = v12 == 0 ? -((int)(drawPreview0.scale * 14.0f + 0.5f)) : ((int)(drawPreview0.scale * 10.0f + 0.5f));
//                            drawPreview0.p.setTextAlign(Paint.Align.LEFT);
//                            float f3 = (float)Math.toDegrees(f1);
//                            int v21 = v20 + canvas0.getWidth() / 2;
//                            drawPreview0.applicationInterface.drawTextWithBackground(canvas0,         // canvas0:android.graphics.Canvas
//                                    drawPreview0.p,  // paint0:android.graphics.Paint
//                                    "" + Math.round((f3 >= 0.0f ? ((float)Math.toDegrees(f1)) : f3 + 360.0f)) + '°', // s:java.lang.String
//                                    -1,              // v:int
//                                    0xFF000000,      // v1:int
//                                    v21,             // v2:int
//                                    v6,              // v3:int
//                                    MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM, // myApplicationInterface$Alignment0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Alignment
//                                    drawPreview0.ybounds_text, // s1:java.lang.String
//                                    MyApplicationInterface.Shadow.SHADOW_OUTLINE // myApplicationInterface$Shadow0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Shadow
//                            );
//                        }


                    }

                    if(v2 != 90 && v2 != 270) {
                        z2 = z;
                        v6 = 0;
                    }
                    else {
                        if(drawPreview0.last_take_photo_top_time == 0L || v1 > drawPreview0.last_take_photo_top_time + 1000L) {
                            int v9 = drawPreview0.getViewOnScreenX(drawPreview0.main_activity.findViewById(R.id.take_photo));  // id:take_photo
                            preview0.getView().getLocationOnScreen(drawPreview0.gui_location);
                            drawPreview0.take_photo_top = v9 - drawPreview0.gui_location[0];
                            drawPreview0.last_take_photo_top_time = v1;
                        }

                        int v10 = drawPreview0.take_photo_top - canvas0.getWidth() / 2;
                        int v11 = canvas0.getWidth();
                        if(v2 == 90) {
                            v11 -= (int)(((double)v3) * 2.5);
                        }

                        if(canvas0.getWidth() / 2 + v10 > v11) {
                            v10 = v11 - canvas0.getWidth() / 2;
                        }

                        z2 = z;
                        v6 = canvas0.getHeight() / 2 + v10 - ((int)(((double)v3) * 0.5));
                    }
                }
            }

//            label_179:
            v12 = !z2 || !drawPreview0.show_angle_pref ? 0 : 1;
            v13 = !z1 || !drawPreview0.show_geo_direction_pref ? 0 : 1;
            if(v12 == 0) {
                v19 = v3;
                v18 = v5;
            }
            else {
                drawPreview0.p.setTextSize(drawPreview0.scale * 14.0f + 0.5f);
                int v14 = v13 == 0 ? -((int)(((float)(f2 >= 0.0 ? 14 : 16)) * drawPreview0.scale + 0.5f)) : -((int)(drawPreview0.scale * 35.0f + 0.5f));
                drawPreview0.p.setTextAlign(Paint.Align.LEFT);
                if(Math.abs(f2) <= 1.0) {
                    int v15 = drawPreview0.angle_highlight_color_pref;
                    drawPreview0.p.setUnderlineText(true);
                    v16 = v15;
                }
                else {
                    v16 = -1;
                }

                if(drawPreview0.angle_string == null || v1 > drawPreview0.last_angle_string_time + 500L) {
                    drawPreview0.last_angle_string_time = v1;
                    drawPreview0.angle_string = DrawPreview.formatLevelAngle(f2) + '°';
                    drawPreview0.cached_angle = f2;
                }

                if(drawPreview0.text_bounds_angle_single == null) {
                    Log.d("DrawPreview", "compute text_bounds_angle_single");
                    Rect rect0 = new Rect();
                    drawPreview0.text_bounds_angle_single = rect0;
                    drawPreview0.p.getTextBounds("-9.0°", 0, 5, rect0);
                }

                if(drawPreview0.text_bounds_angle_double == null) {
                    Log.d("DrawPreview", "compute text_bounds_angle_double");
                    Rect rect1 = new Rect();
                    drawPreview0.text_bounds_angle_double = rect1;
                    drawPreview0.p.getTextBounds("-45.0°", 0, 6, rect1);
                }

                String s = drawPreview0.angle_string;
                int v17 = canvas0.getWidth() / 2 + v14;
                v18 = v5;
                v19 = v3;
                drawPreview0.applicationInterface.drawTextWithBackground(canvas0,         // canvas0:android.graphics.Canvas
                        drawPreview0.p,  // paint0:android.graphics.Paint
                        s,               // s:java.lang.String
                        v16,             // v:int
                        0xFF000000,      // v1:int
                        v17,             // v2:int
                        v6,              // v3:int
                        MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM, // myApplicationInterface$Alignment0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Alignment
                        null,            // s1:java.lang.String
                        MyApplicationInterface.Shadow.SHADOW_OUTLINE, // myApplicationInterface$Shadow0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Shadow
                        (Math.abs(drawPreview0.cached_angle) >= 10.0 ? drawPreview0.text_bounds_angle_double : drawPreview0.text_bounds_angle_single) // rect0:android.graphics.Rect
                );
                drawPreview0.p.setUnderlineText(false);
            }

            if(v13 != 0) {
                drawPreview0.p.setTextSize(drawPreview0.scale * 14.0f + 0.5f);
                int v20 = v12 == 0 ? -((int)(drawPreview0.scale * 14.0f + 0.5f)) : ((int)(drawPreview0.scale * 10.0f + 0.5f));
                drawPreview0.p.setTextAlign(Paint.Align.LEFT);
                float f3 = (float)Math.toDegrees(f1);
                int v21 = v20 + canvas0.getWidth() / 2;
                drawPreview0.applicationInterface.drawTextWithBackground(canvas0,         // canvas0:android.graphics.Canvas
                        drawPreview0.p,  // paint0:android.graphics.Paint
                        "" + Math.round((f3 >= 0.0f ? ((float)Math.toDegrees(f1)) : f3 + 360.0f)) + '°', // s:java.lang.String
                        -1,              // v:int
                        0xFF000000,      // v1:int
                        v21,             // v2:int
                        v6,              // v3:int
                        MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM, // myApplicationInterface$Alignment0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Alignment
                        drawPreview0.ybounds_text, // s1:java.lang.String
                        MyApplicationInterface.Shadow.SHADOW_OUTLINE // myApplicationInterface$Shadow0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Shadow
                );
            }

            if(preview0.isOnTimer()) {
                long v22 = (preview0.getTimerEndTime() - v1 + 999L) / 1000L;
                Log.d("DrawPreview", "remaining_time: " + v22);
                if(v22 > 0L) {
                    float f4 = (float)this.getContext().getResources().getDimensionPixelSize(R.dimen.timer_font_size);  // dimen:timer_font_size
                    drawPreview0.p.setTextSize(f4);
                    Log.e("DrawPreview", "drawUI: " + drawPreview0.p.getTextSize());
                    drawPreview0.p.setTextAlign(Paint.Align.CENTER);
                    String s1 = v22 >= 60L ? drawPreview0.getTimeStringFromSeconds(v22) : "" + v22;
                    int v23 = canvas0.getWidth() / 2;
                    int v24 = canvas0.getHeight() / 2;
                    drawPreview0.applicationInterface.drawTextWithBackground(canvas0, drawPreview0.p, s1, -1, 0xFF000000, v23, v24);
                }

                v25 = v1;
            }
            else if(preview0.isVideoRecording()) {
                String s2 = drawPreview0.getTimeStringFromSeconds(preview0.getVideoTime() / 1000L);
                drawPreview0.p.setTextSize(drawPreview0.scale * 14.0f + 0.5f);
                drawPreview0.p.setTextAlign(Paint.Align.CENTER);
                int v26 = v18 * 2;
                int v27 = Color.rgb(0xF4, 67, 54);
                if(drawPreview0.main_activity.isScreenLocked()) {
                    String s3 = this.getContext().getResources().getString(R.string.screen_lock_message_2);  // string:screen_lock_message_2 "Swipe to unlock]"
                    int v28 = canvas0.getWidth() / 2;
                    drawPreview0.applicationInterface.drawTextWithBackground(canvas0, drawPreview0.p, s3, v27, 0xFF000000, v28, v6 - v26);
                    int v29 = v26 + v18;
                    String s4 = this.getContext().getResources().getString(R.string.screen_lock_message_1);  // string:screen_lock_message_1 "[LOCKED:"
                    int v30 = canvas0.getWidth() / 2;
                    drawPreview0.applicationInterface.drawTextWithBackground(canvas0, drawPreview0.p, s4, v27, 0xFF000000, v30, v6 - v29);
                    v26 = v29 + v18;
                }

                if(!preview0.isVideoRecordingPaused() || ((int)(v1 / 500L)) % 2 == 0) {
                    int v31 = canvas0.getWidth() / 2;
                    drawPreview0.applicationInterface.drawTextWithBackground(canvas0, drawPreview0.p, s2, v27, 0xFF000000, v31, v6 - v26);
                    v26 += v18;
                }

                if((drawPreview0.show_video_max_amp_pref) && !preview0.isVideoRecordingPaused()) {
                    if(!drawPreview0.has_video_max_amp || v1 > drawPreview0.last_video_max_amp_time + 50L) {
                        drawPreview0.has_video_max_amp = true;
                        int v32 = drawPreview0.video_max_amp_prev2;
                        drawPreview0.video_max_amp_prev2 = drawPreview0.video_max_amp;
                        int v33 = preview0.getMaxAmplitude();
                        drawPreview0.video_max_amp = v33;
                        drawPreview0.last_video_max_amp_time = v1;
                        if(v33 > 30000) {
                            Log.d("DrawPreview", "max_amp: " + drawPreview0.video_max_amp);
                        }

                        if(drawPreview0.video_max_amp > 0x7FFF) {
                            Log.e("DrawPreview", "video_max_amp greater than max: " + drawPreview0.video_max_amp);
                        }

                        int v34 = drawPreview0.video_max_amp_prev2;
                        if(v34 > v32 && v34 > drawPreview0.video_max_amp) {
                            drawPreview0.video_max_amp_peak = v34;
                        }
                    }

                    float f5 = Math.min(Math.max(((float)drawPreview0.video_max_amp) / 32767.0f, 0.0f), 1.0f);
                    int v35 = (int)(160.0f * drawPreview0.scale + 0.5f);
                    int v36 = (canvas0.getWidth() - v35) / 2;
                    drawPreview0.p.setColor(-1);
                    drawPreview0.p.setStyle(Paint.Style.STROKE);
                    drawPreview0.p.setStrokeWidth(drawPreview0.stroke_width);
                    float f6 = (float)v36;
                    int v37 = v6 - (v26 + v18);
                    float f7 = (float)v37;
                    float f8 = (float)(v36 + v35);
                    float f9 = (float)(v37 + ((int)(drawPreview0.scale * 10.0f + 0.5f)));
                    v38 = v2;
                    canvas0.drawRect(f6, f7, f8, f9, drawPreview0.p);
                    drawPreview0.p.setStyle(Paint.Style.FILL);
                    float f10 = (float)v35;
                    float f11 = f6 + f5 * f10;
                    canvas0.drawRect(f6, f7, f11, f9, drawPreview0.p);
                    if(f5 < 1.0f) {
                        drawPreview0.p.setColor(0xFF000000);
                        drawPreview0.p.setAlpha(0x40);
                        canvas0.drawRect(f11 + 1.0f, f7, f8, f9, drawPreview0.p);
                        drawPreview0.p.setAlpha(0xFF);
                    }

                    int v39 = drawPreview0.video_max_amp_peak;
                    if(v39 > drawPreview0.video_max_amp) {
                        drawPreview0.p.setColor(0xFFFFFF00);
                        drawPreview0.p.setStyle(Paint.Style.STROKE);
                        drawPreview0.p.setStrokeWidth(drawPreview0.stroke_width);
                        float f12 = f6 + Math.min(Math.max(((float)v39) / 32767.0f, 0.0f), 1.0f) * f10;
                        canvas0.drawLine(f12, f7, f12, f9, drawPreview0.p);
                        drawPreview0.p.setColor(-1);
                    }
                }
                else {
                    v38 = v2;
                }

                v25 = v;
                v2 = v38;
            }
            else {
                int v40 = v2;
                if(!drawPreview0.taking_picture || !drawPreview0.capture_started) {
                    v25 = v;
                    v2 = v40;
                    if((drawPreview0.image_queue_full) && ((int)(v25 / 500L)) % 2 == 0) {
                        drawPreview0.p.setTextSize(drawPreview0.scale * 14.0f + 0.5f);
                        drawPreview0.p.setTextAlign(Paint.Align.CENTER);
                        int v47 = drawPreview0.applicationInterface.getImageSaver().getNRealImagesToSave();
                        int v48 = canvas0.getWidth() / 2;
                        drawPreview0.applicationInterface.drawTextWithBackground(canvas0, drawPreview0.p, this.getContext().getResources().getString(0x7F1202CA) + " (" + v47 + " " + this.getContext().getResources().getString(0x7F1202DD) + ")", 0xFFCCCCCC, 0xFF000000, v48, v6 - v18 * 2);  // string:processing "Processing…"
                    }
                }
                else if(cameraController0.isCapturingBurst()) {
                    int v41 = cameraController0.getNBurstTaken() + 1;
                    int v42 = cameraController0.getBurstTotal();
                    drawPreview0.p.setTextSize(drawPreview0.scale * 14.0f + 0.5f);
                    drawPreview0.p.setTextAlign(Paint.Align.CENTER);
                    int v43 = v18 * 2;
                    v2 = v40;
                    if(v2 == 0 && drawPreview0.applicationInterface.getPhotoMode() == MyApplicationInterface.PhotoMode.FocusBracketing) {
                        v43 = v19 * 5;
                    }

                    String s5 = this.getContext().getResources().getString(R.string.capturing) + " " + v41;  // string:capturing "Capturing…"
                    int v44 = canvas0.getWidth() / 2;
                    drawPreview0.applicationInterface.drawTextWithBackground(canvas0, drawPreview0.p, (v42 <= 0 ? s5 : s5 + " / " + v42), -1, 0xFF000000, v44, v6 - v43);
                    v25 = v;
                }
                else {
                    v2 = v40;
                    if((cameraController0.isManualISO()) && cameraController0.getExposureTime() >= 500000000L) {
                        v25 = v;
                        if(((int)(v25 / 500L)) % 2 == 0) {
                            drawPreview0.p.setTextSize(drawPreview0.scale * 14.0f + 0.5f);
                            drawPreview0.p.setTextAlign(Paint.Align.CENTER);
                            int v45 = Color.rgb(0xF4, 67, 54);
                            String s6 = this.getContext().getResources().getString(R.string.capturing);  // string:capturing "Capturing…"
                            int v46 = canvas0.getWidth() / 2;
                            drawPreview0.applicationInterface.drawTextWithBackground(canvas0, drawPreview0.p, s6, v45, 0xFF000000, v46, v6 - v18 * 2);
                        }
                    }
                    else {
                        v25 = v;
                    }
                }
            }

            if((preview0.supportsZoom()) && (drawPreview0.show_zoom_pref)) {
                float f13 = preview0.getZoomRatio();
                if(f13 > 1.00001f) {
                    drawPreview0.p.setTextSize(drawPreview0.scale * 14.0f + 0.5f);
                    drawPreview0.p.setTextAlign(Paint.Align.CENTER);
                    int v49 = canvas0.getWidth() / 2;
                    int v50 = canvas0.getWidth() / 2;
                    drawPreview0.applicationInterface.drawTextWithBackground(canvas0,         // canvas0:android.graphics.Canvas
                            drawPreview0.p,  // paint0:android.graphics.Paint
                            this.getContext().getResources().getString(R.string.zoom) + ": " + f13 + "x", // s:java.lang.String  // string:zoom "Zoom"
                            -1,              // v:int
                            0xFF000000,      // v1:int
                            v49,             // v2:int
                            v50,             // v3:int
                            MyApplicationInterface.Alignment.ALIGNMENT_TOP, // myApplicationInterface$Alignment0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Alignment
                            drawPreview0.ybounds_text, // s1:java.lang.String
                            MyApplicationInterface.Shadow.SHADOW_OUTLINE // myApplicationInterface$Shadow0:com.gpsmapcamera.geotagginglocationonphoto.Camera.MyApplicationInterface$Shadow
                    );
                }
            }

            v51 = v25;
        }
        else {
            v51 = v1;
            if(cameraController0 == null) {
                drawPreview0.p.setColor(-1);
                drawPreview0.p.setTextSize(drawPreview0.scale * 14.0f + 0.5f);
                drawPreview0.p.setTextAlign(Paint.Align.CENTER);
                int v52 = (int)(drawPreview0.scale * 20.0f + 0.5f);
                if(!preview0.hasPermissions()) {
                    canvas0.drawText(this.getContext().getResources().getString(R.string.no_permission), ((float)canvas0.getWidth()) / 2.0f, ((float)canvas0.getHeight()) / 2.0f, drawPreview0.p);  // string:no_permission "PERMISSIONS NOT AVAILABLE"
                }
                else if(preview0.openCameraFailed()) {
                    canvas0.drawText(this.getContext().getResources().getString(R.string.failed_to_open_camera_1), ((float)canvas0.getWidth()) / 2.0f, ((float)canvas0.getHeight()) / 2.0f, drawPreview0.p);  // string:failed_to_open_camera_1 "FAILED TO OPEN CAMERA."
                    canvas0.drawText(this.getContext().getResources().getString(R.string.failed_to_open_camera_2), ((float)canvas0.getWidth()) / 2.0f, ((float)canvas0.getHeight()) / 2.0f + ((float)v52), drawPreview0.p);  // string:failed_to_open_camera_2 "CAMERA MAY BE IN USE"
                    canvas0.drawText(this.getContext().getResources().getString(R.string.failed_to_open_camera_3), ((float)canvas0.getWidth()) / 2.0f, ((float)canvas0.getHeight()) / 2.0f + ((float)(v52 * 2)), drawPreview0.p);  // string:failed_to_open_camera_3 "BY ANOTHER APPLICATION?"
                    float f14 = ((float)canvas0.getWidth()) / 2.0f;
                    float f15 = ((float)canvas0.getHeight()) / 2.0f + ((float)(v52 * 3));
                    canvas0.drawText(this.getContext().getResources().getString(0x7F12006E) + ":" + drawPreview0.applicationInterface.getCameraIdPref(), f14, f15, drawPreview0.p);  // string:camera_id "ID"
                }
            }

            v6 = 0;
        }

        int v53 = (int)(drawPreview0.scale * 5.0f + 0.5f);
        int v54 = (int)(drawPreview0.scale * 5.0f + 0.5f);
        View view0 = drawPreview0.main_activity.getMainUI().getTopIcon();
        if(view0 != null) {
            if(drawPreview0.last_top_icon_shift_time == 0L || v51 > drawPreview0.last_top_icon_shift_time + 1000L) {
                int v55 = drawPreview0.getViewOnScreenX(view0) + view0.getWidth();
                preview0.getView().getLocationOnScreen(drawPreview0.gui_location);
                drawPreview0.top_icon_shift = v55 - drawPreview0.gui_location[0];
                drawPreview0.last_top_icon_shift_time = v51;
            }

            int v56 = drawPreview0.top_icon_shift;
            if(v56 > 0) {
                if(v2 != 90 && v2 != 270) {
                    v53 += v56;
                }
                else {
                    v54 += v56;
                }
            }
        }

        int v57 = v53;
        int v58 = v54;
        int v59 = (int)(1.891753E-43f * drawPreview0.scale + 0.5f);
        int v60 = drawPreview0.top_icon_shift;
        if(v60 > 0) {
            v59 += v60;
        }

        if(drawPreview0.focus_seekbars_margin_left == -1 || v59 != drawPreview0.focus_seekbars_margin_left) {
            drawPreview0.focus_seekbars_margin_left = v59;
            Log.d("DrawPreview", "set focus_seekbars_margin_left to " + drawPreview0.focus_seekbars_margin_left);
        }

        int v61 = ((int)(drawPreview0.scale * 5.0f + 0.5f)) + v58;
        int v62 = (int)(drawPreview0.scale * 5.0f + 0.5f);
        int v63 = v62 * 4;
        if(v2 != 90 && v2 != 270) {
            v64 = v57;
        }
        else {
            int v65 = (canvas0.getWidth() - canvas0.getHeight()) / 2;
            v64 = v57 + v65;
            v61 -= v65;
        }

        if(v2 == 90) {
            v61 = canvas0.getHeight() - v61 - v63;
        }

        if(v2 == 180) {
            v64 = canvas0.getWidth() - v64 - v62;
        }

        int v66 = v64;
        if(drawPreview0.show_battery_pref) {
            if(!drawPreview0.has_battery_frac || v51 > drawPreview0.last_battery_time + 60000L) {
                Intent intent0 = drawPreview0.main_activity.registerReceiver(null, drawPreview0.battery_ifilter);
                int v67 = intent0.getIntExtra("level", -1);
                int v68 = intent0.getIntExtra("scale", -1);
                drawPreview0.has_battery_frac = true;
                drawPreview0.battery_frac = ((float)v67) / ((float)v68);
                drawPreview0.last_battery_time = v51;
                Log.d("DrawPreview", "Battery status is " + v67 + " / " + v68 + " : " + drawPreview0.battery_frac);
            }

            float f16 = drawPreview0.battery_frac;
            if(f16 > 0.05f || v51 / 1000L % 2L == 0L) {
                int v69 = f16 <= 0.15f ? Color.rgb(0xF4, 67, 54) : Color.rgb(37, 0x9B, 36);
                drawPreview0.p.setColor(v69);
                drawPreview0.p.setStyle(Paint.Style.FILL);
                float f17 = (float)v66;
                float f18 = (float)v61;
                float f19 = (float)(v63 - 2);
                float f20 = (float)(v66 + v62);
                canvas0.drawRect(f17, f18 + (1.0f - drawPreview0.battery_frac) * f19, f20, ((float)(v61 + v63)), drawPreview0.p);
                if(drawPreview0.battery_frac < 1.0f) {
                    drawPreview0.p.setColor(0xFF000000);
                    drawPreview0.p.setAlpha(0x40);
                    canvas0.drawRect(f17, f18, f20, f18 + (1.0f - drawPreview0.battery_frac) * f19, drawPreview0.p);
                    drawPreview0.p.setAlpha(0xFF);
                }
            }

            v57 += (int)(drawPreview0.scale * 10.0f + 0.5f);
        }

        this.onDrawInfoLines(canvas0, v57, v58, v6, v);
        canvas0.restore();
    }




    private void drawAngleLines(Canvas canvas, long j) {
        boolean z;
        int i;
        int i2;
        Preview preview;
        int i3;
        boolean z2;
        double d;
        float f;
        float f2;
        int i4;
        int i5;
        int i6;
        float f3;
        int i7;
        float f4;
        int i8;
        float f5;
        float f6;
        float f7;
        int i9;
        int i10;
        int i11;
        Preview preview2 = this.main_activity.getPreview();
        CameraController cameraController = preview2.getCameraController();
        boolean hasLevelAngle = preview2.hasLevelAngle();
        if (this.photoMode == MyApplicationInterface.PhotoMode.Panorama) {
            z = !this.main_activity.getApplicationInterface().getGyroSensor().isRecording();
        } else {
            z = this.show_angle_line_pref;
        }
        if (cameraController == null || preview2.isPreviewPaused() || !hasLevelAngle) {
            return;
        }
        if (z || this.show_pitch_lines_pref || this.show_geo_direction_lines_pref) {
            int uIRotation = preview2.getUIRotation();
            double levelAngle = preview2.getLevelAngle();
            boolean hasPitchAngle = preview2.hasPitchAngle();
            double pitchAngle = preview2.getPitchAngle();
            boolean hasGeoDirection = preview2.hasGeoDirection();
            double geoDirection = preview2.getGeoDirection();
            int i12 = (int) ((((uIRotation == 90 || uIRotation == 270) ? 60 : 80) * this.scale) + 0.5f);
            double d2 = -preview2.getOrigLevelAngle();
            int rotation = this.main_activity.getWindowManager().getDefaultDisplay().getRotation();
            if (rotation == 1 || rotation == 3) {
                d2 -= 90.0d;
            }
            int width = canvas.getWidth() / 2;
            int height = canvas.getHeight() / 2;
            boolean z3 = hasLevelAngle && Math.abs(levelAngle) <= close_level_angle;
            if (z3) {
                i12 = (int) (i12 * 1.2d);
            }
            canvas.save();
            float f8 = (float) d2;
            float f9 = width;
            float f10 = height;
            canvas.rotate(f8, f9, f10);
            float f11 = (this.scale * 0.5f) + 0.5f;
            this.p.setStyle(Paint.Style.FILL);
            if (z && preview2.hasLevelAngleStable()) {
                this.p.setColor(-16777216);
                this.p.setAlpha(64);
                float f12 = width - i12;
                float f13 = f12 - f11;
                i = height;
                float f14 = f11 * 2.0f;
                d = pitchAngle;
                float f15 = width + i12;
                i2 = width;
                float f16 = f15 + f11;
                i3 = uIRotation;
                this.draw_rect.set(f13, f10 - f14, f16, f10 + f14);
                canvas.drawRoundRect(this.draw_rect, f14, f14, this.p);
                float f17 = i12 / 2.0f;
                float f18 = f10 - f17;
                z2 = hasPitchAngle;
                preview = preview2;
                float f19 = f17 + f10;
                this.draw_rect.set(f9 - f14, f18 - f11, f9 + f14, f19 + f11);
                canvas.drawRoundRect(this.draw_rect, f11, f11, this.p);
                if (z3) {
                    this.p.setColor(this.angle_highlight_color_pref);
                } else {
                    this.p.setColor(-1);
                }
                this.p.setAlpha(160);
                this.draw_rect.set(f12, f10 - f11, f15, f10 + f11);
                canvas.drawRoundRect(this.draw_rect, f11, f11, this.p);
                this.draw_rect.set(f9 - f11, f18, f9 + f11, f19);
                canvas.drawRoundRect(this.draw_rect, f11, f11, this.p);
                if (z3) {
                    this.p.setColor(-16777216);
                    this.p.setAlpha(64);
                    this.draw_rect.set(f13, f10 - (7.0f * f11), f16, f10 - (3.0f * f11));
                    canvas.drawRoundRect(this.draw_rect, f14, f14, this.p);
                    this.p.setColor(this.angle_highlight_color_pref);
                    this.p.setAlpha(160);
                    this.draw_rect.set(f12, f10 - (6.0f * f11), f15, f10 - (f11 * 4.0f));
                    canvas.drawRoundRect(this.draw_rect, f11, f11, this.p);
                }
            } else {
                i = height;
                i2 = width;
                preview = preview2;
                i3 = uIRotation;
                z2 = hasPitchAngle;
                d = pitchAngle;
            }
            updateCachedViewAngles(j);
            float f20 = this.view_angle_x_preview;
            float f21 = this.view_angle_y_preview;
            float width2 = (float) (canvas.getWidth() / (Math.tan(Math.toRadians(f20 / 2.0d)) * 2.0d));
            float height2 = (float) (canvas.getHeight() / (Math.tan(Math.toRadians(f21 / 2.0d)) * 2.0d));
            float sqrt = ((float) Math.sqrt((width2 * width2) + (height2 * height2))) * preview.getZoomRatio();
            if (z2 && this.show_pitch_lines_pref) {
                i5 = i3;
                int i13 = (int) ((((i5 == 90 || i5 == 270) ? 100 : 80) * this.scale) + 0.5f);
                int i14 = preview.getZoomRatio() >= 2.0f ? 5 : 10;
                int i15 = 90;
                int i16 = -90;
                while (i16 <= i15) {
                    double d3 = d - i16;
                    if (Math.abs(d3) < 90.0d) {
                        this.p.setColor(-16777216);
                        this.p.setAlpha(64);
                        float f22 = i2 - i13;
                        float tan = (((float) Math.tan(Math.toRadians(d3))) * sqrt) + f10;
                        float f23 = f11 * 2.0f;
                        float f24 = tan - f23;
                        float f25 = i2 + i13;
                        float f26 = f10;
                        float f27 = f9;
                        this.draw_rect.set(f22 - f11, f24, f25 + f11, tan + f23);
                        canvas.drawRoundRect(this.draw_rect, f23, f23, this.p);
                        this.p.setColor(-1);
                        this.p.setTextAlign(Paint.Align.LEFT);
                        if (i16 == 0 && Math.abs(d) < close_level_angle) {
                            this.p.setAlpha(255);
                        } else if (i16 == 90 && Math.abs(d - 90.0d) < 3.0d) {
                            this.p.setAlpha(255);
                        } else if (i16 == -90 && Math.abs(d + 90.0d) < 3.0d) {
                            this.p.setAlpha(255);
                        } else {
                            this.p.setAlpha(160);
                        }
                        this.draw_rect.set(f22, tan - f11, f25, tan + f11);
                        canvas.drawRoundRect(this.draw_rect, f11, f11, this.p);
                        i9 = i;
                        i10 = i2;
                        i8 = i16;
                        i11 = i13;
                        f5 = f11;
                        f6 = f26;
                        f7 = f27;
                        this.applicationInterface.drawTextWithBackground(canvas, this.p, "" + i16 + "°", this.p.getColor(), -16777216, (int) (f25 + (f11 * 4.0f)), (int) f24, MyApplicationInterface.Alignment.ALIGNMENT_CENTRE);
                    } else {
                        i8 = i16;
                        f5 = f11;
                        f6 = f10;
                        f7 = f9;
                        i9 = i;
                        i10 = i2;
                        i11 = i13;
                    }
                    i16 = i8 + i14;
                    f10 = f6;
                    f9 = f7;
                    i2 = i10;
                    i13 = i11;
                    f11 = f5;
                    i15 = 90;
                    i = i9;
                }
                f = f11;
                f2 = f9;
                i4 = i;
            } else {
                f = f11;
                f2 = f9;
                i4 = i;
                i5 = i3;
            }
            if (hasGeoDirection && z2 && this.show_geo_direction_lines_pref) {
                int i17 = (int) ((((i5 == 90 || i5 == 270) ? 80 : 100) * this.scale) + 0.5f);
                float degrees = (float) Math.toDegrees(geoDirection);
                int i18 = preview.getZoomRatio() >= 2.0f ? 5 : 10;
                int i19 = 0;
                while (i19 < 360) {
                    double d4 = i19 - degrees;
                    while (d4 >= 360.0d) {
                        d4 -= 360.0d;
                    }
                    while (d4 < -360.0d) {
                        d4 += 360.0d;
                    }
                    if (d4 > 180.0d) {
                        d4 = -(360.0d - d4);
                    }
                    if (Math.abs(d4) < 90.0d) {
                        this.p.setColor(-16777216);
                        this.p.setAlpha(64);
                        float tan2 = (((float) Math.tan(Math.toRadians(d4))) * sqrt) + f2;
                        float f28 = f;
                        float f29 = f28 * 2.0f;
                        float f30 = i4 - i17;
                        f3 = sqrt;
                        float f31 = i4 + i17;
                        i7 = i17;
                        this.draw_rect.set(tan2 - f29, f30 - f28, tan2 + f29, f31 + f28);
                        canvas.drawRoundRect(this.draw_rect, f29, f29, this.p);
                        this.p.setColor(-1);
                        this.p.setTextAlign(Paint.Align.CENTER);
                        this.p.setAlpha(160);
                        this.draw_rect.set(tan2 - f28, f30, tan2 + f28, f31);
                        canvas.drawRoundRect(this.draw_rect, f28, f28, this.p);
                        f4 = f28;
                        i6 = i19;
                        this.applicationInterface.drawTextWithBackground(canvas, this.p, "" + i19 + "°", this.p.getColor(), -16777216, (int) tan2, (int) (f30 - (f28 * 4.0f)), MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM);
                    } else {
                        i6 = i19;
                        f3 = sqrt;
                        i7 = i17;
                        f4 = f;
                    }
                    i19 = i6 + i18;
                    sqrt = f3;
                    i17 = i7;
                    f = f4;
                }
            }
            this.p.setAlpha(255);
            this.p.setStyle(Paint.Style.FILL);
            canvas.restore();
        }
    }


    private int getAngleStep() {
        Preview preview = main_activity.getPreview();
        int angle_step = 10;
        float zoom_ratio = preview.getZoomRatio();
        if (zoom_ratio>=10.0f)
            angle_step = 1;
        else if (zoom_ratio>=5.0f)
            angle_step = 2;
        else if (zoom_ratio>=2.0f)
            angle_step = 5;
        return angle_step;
    }


    private void doThumbnailAnimation(Canvas canvas, long j) {
        Preview preview = this.main_activity.getPreview();
        if (preview.getCameraController() == null || !this.thumbnail_anim || this.last_thumbnail == null) {
            return;
        }
        int uIRotation = preview.getUIRotation();
        long j2 = j - this.thumbnail_anim_start_ms;
        if (j2>500) {
            Log.d(TAG, "thumbnail_anim finished");
            this.thumbnail_anim = false;
            return;
        }
        this.thumbnail_anim_src_rect.left = 0.0f;
        this.thumbnail_anim_src_rect.top = 0.0f;
        this.thumbnail_anim_src_rect.right = this.last_thumbnail.getWidth();
        this.thumbnail_anim_src_rect.bottom = this.last_thumbnail.getHeight();
        View findViewById = this.main_activity.findViewById(R.id.img_gallery);
        float f = ((float) j2) / 500.0f;
        int left = findViewById.getLeft() + (findViewById.getWidth() / 2);
        float f2 = 1.0f - f;
        float width = canvas.getWidth();
        float height = canvas.getHeight();
        float width2 = (int) (((canvas.getWidth() / 2) * f2) + (left * f));
        float width3 = ((int) (width / ((((width / findViewById.getWidth()) - 1.0f) * f) + 1.0f))) / 2.0f;
        this.thumbnail_anim_dst_rect.left = width2 - width3;
        float height2 = (int) ((f2 * (canvas.getHeight() / 2)) + ((findViewById.getTop() + (findViewById.getHeight() / 2)) * f));
        float height3 = ((int) (height / ((f * ((height / findViewById.getHeight()) - 1.0f)) + 1.0f))) / 2.0f;
        this.thumbnail_anim_dst_rect.top = height2 - height3;
        this.thumbnail_anim_dst_rect.right = width2 + width3;
        this.thumbnail_anim_dst_rect.bottom = height2 + height3;
        this.thumbnail_anim_matrix.setRectToRect(this.thumbnail_anim_src_rect, this.thumbnail_anim_dst_rect, Matrix.ScaleToFit.FILL);
        if (uIRotation == 90 || uIRotation == 270) {
            float width4 = this.last_thumbnail.getWidth() / this.last_thumbnail.getHeight();
            this.thumbnail_anim_matrix.preScale(width4, 1.0f / width4, this.last_thumbnail.getWidth() / 2.0f, this.last_thumbnail.getHeight() / 2.0f);
        }
        this.thumbnail_anim_matrix.preRotate(uIRotation, this.last_thumbnail.getWidth() / 2.0f, this.last_thumbnail.getHeight() / 2.0f);
        canvas.drawBitmap(this.last_thumbnail, this.thumbnail_anim_matrix, this.p);
    }

    private void doFocusAnimation(Canvas canvas, long j) {
        int width;
        int height;
        float f;
        float f2;
        float f3;
        float f4;
        Preview preview = this.main_activity.getPreview();
        if (preview.getCameraController() != null && this.continuous_focus_moving && !this.taking_picture) {
            long j2 = j - this.continuous_focus_moving_ms;
            if (j2<=1000) {
                float f5 = ((float) j2) / 1000.0f;
                float width2 = canvas.getWidth() / 2.0f;
                float height2 = canvas.getHeight() / 2.0f;
                float f6 = this.scale;
                float f7 = (f6 * 40.0f) + 0.5f;
                float f8 = (f6 * 60.0f) + 0.5f;
                if (f5<0.5f) {
                    float f9 = f5 * 2.0f;
                    f3 = (1.0f - f9) * f7;
                    f4 = f9 * f8;
                } else {
                    float f10 = (f5 - 0.5f) * 2.0f;
                    f3 = (1.0f - f10) * f8;
                    f4 = f10 * f7;
                }
                this.p.setColor(-1);
                this.p.setStyle(Paint.Style.STROKE);
                this.p.setStrokeWidth(this.stroke_width);
                canvas.drawCircle(width2, height2, f3 + f4, this.p);
                this.p.setStyle(Paint.Style.FILL);
            } else {
                clearContinuousFocusMove();
            }
        }
        if (preview.isFocusWaiting() || preview.isFocusRecentSuccess() || preview.isFocusRecentFailure()) {
            long timeSinceStartedAutoFocus = preview.timeSinceStartedAutoFocus();
            float f11 = this.scale;
            float f12 = (40.0f * f11) + 0.5f;
            float f13 = (f11 * 45.0f) + 0.5f;
            if (timeSinceStartedAutoFocus>0) {
                float f14 = ((float) timeSinceStartedAutoFocus) / 500.0f;
                if (f14>1.0f) {
                    f14 = 1.0f;
                }
                if (f14<0.5f) {
                    float f15 = f14 * 2.0f;
                    f = (1.0f - f15) * f12;
                    f2 = f15 * f13;
                } else {
                    float f16 = (f14 - 0.5f) * 2.0f;
                    f = (1.0f - f16) * f13;
                    f2 = f16 * f12;
                }
                f12 = f + f2;
            }
            int i = (int) f12;
            if (preview.isFocusRecentSuccess()) {
                this.p.setColor(Color.rgb(20, 231, 21));
            } else if (preview.isFocusRecentFailure()) {
                this.p.setColor(Color.rgb(244, 67, 54));
            } else {
                this.p.setColor(-1);
            }
            this.p.setStyle(Paint.Style.STROKE);
            this.p.setStrokeWidth(this.stroke_width);
            if (preview.hasFocusArea()) {
                Pair<Integer, Integer> focusPos = preview.getFocusPos();
                width = ((Integer) focusPos.first).intValue();
                height = ((Integer) focusPos.second).intValue();
            } else {
                width = canvas.getWidth() / 2;
                height = canvas.getHeight() / 2;
            }
            float f17 = width - i;
            float f18 = height - i;
            float f19 = width;
            float f20 = i * 0.5f;
            float f21 = f19 - f20;
            canvas.drawLine(f17, f18, f21, f18, this.p);
            float f22 = f19 + f20;
            float f23 = width + i;
            canvas.drawLine(f22, f18, f23, f18, this.p);
            float f24 = i + height;
            canvas.drawLine(f17, f24, f21, f24, this.p);
            canvas.drawLine(f22, f24, f23, f24, this.p);
            float f25 = height;
            float f26 = f25 - f20;
            canvas.drawLine(f17, f18, f17, f26, this.p);
            float f27 = f25 + f20;
            canvas.drawLine(f17, f27, f17, f24, this.p);
            canvas.drawLine(f23, f18, f23, f26, this.p);
            canvas.drawLine(f23, f27, f23, f24, this.p);
            this.p.setStyle(Paint.Style.FILL);
        }
    }

//    public void onDrawPreview(Canvas canvas) {
//        int i;
//        Bitmap bitmap;
//        float f;
//        GyroSensor gyroSensor;
//        if (!this.has_settings) {
//            Log.d(TAG, "onDrawPreview: need to update settings");
//            updateSettings();
//        }
//        Preview preview = this.main_activity.getPreview();
//        CameraController cameraController = preview.getCameraController();
//        int uIRotation = preview.getUIRotation();
//        long currentTimeMillis = System.currentTimeMillis();
//        char c = 0;
//        boolean z = this.want_histogram || this.want_zebra_stripes || this.want_focus_peaking;
//        if (z != preview.isPreviewBitmapEnabled()) {
//            if (z) {
//                preview.enablePreviewBitmap();
//            } else {
//                preview.disablePreviewBitmap();
//            }
//        }
//        if (z) {
//            if (this.want_histogram) {
//                preview.enableHistogram(this.histogram_type);
//            } else {
//                preview.disableHistogram();
//            }
//            if (this.want_zebra_stripes) {
//                preview.enableZebraStripes(this.zebra_stripes_threshold, this.zebra_stripes_color_foreground, this.zebra_stripes_color_background);
//            } else {
//                preview.disableZebraStripes();
//            }
//            if (this.want_focus_peaking) {
//                preview.enableFocusPeaking();
//            } else {
//                preview.disableFocusPeaking();
//            }
//        }
//        if (preview.usingCamera2API() && (cameraController == null || cameraController.shouldCoverPreview())) {
//            this.p.setColor(-16777216);
//            canvas.drawRect(0.0f, 0.0f, canvas.getWidth(), canvas.getHeight(), this.p);
//        }
//        if (cameraController != null && this.front_screen_flash) {
//            this.p.setColor(-1);
//            i = -1;
//            canvas.drawRect(0.0f, 0.0f, canvas.getWidth(), canvas.getHeight(), this.p);
//        } else {
//            i = -1;
//            if ("flash_frontscreen_torch".equals(preview.getCurrentFlashValue())) {
//                this.p.setColor(-1);
//                this.p.setAlpha(200);
//                canvas.drawRect(0.0f, 0.0f, canvas.getWidth(), canvas.getHeight(), this.p);
//                this.p.setAlpha(255);
//            }
//        }
//        if (this.main_activity.getMainUI().inImmersiveMode() && this.immersive_mode_everything_pref) {
//            return;
//        }
//        if (cameraController != null && this.taking_picture && !this.front_screen_flash && this.take_photo_border_pref) {
//            this.p.setColor(i);
//            this.p.setStyle(Paint.Style.STROKE);
//            this.p.setStrokeWidth(this.stroke_width);
//            this.p.setStrokeWidth((this.scale * 5.0f) + 0.5f);
//            canvas.drawRect(0.0f, 0.0f, canvas.getWidth(), canvas.getHeight(), this.p);
//            this.p.setStyle(Paint.Style.FILL);
//            this.p.setStrokeWidth(this.stroke_width);
//        }
//        drawGrids(canvas);
//        drawCropGuides(canvas);
//        if (this.last_thumbnail != null && !this.last_thumbnail_is_video && cameraController != null && (this.show_last_image || (this.allow_ghost_last_image && !this.front_screen_flash && this.ghost_image_pref.equals("preference_ghost_image_last")))) {
//            if (this.show_last_image) {
//                this.p.setColor(Color.rgb(0, 0, 0));
//                canvas.drawRect(0.0f, 0.0f, canvas.getWidth(), canvas.getHeight(), this.p);
//            }
//            setLastImageMatrix(canvas, this.last_thumbnail, uIRotation, !this.show_last_image);
//            if (!this.show_last_image) {
//                this.p.setAlpha(this.ghost_image_alpha);
//            }
//            canvas.drawBitmap(this.last_thumbnail, this.last_image_matrix, this.p);
//            if (!this.show_last_image) {
//                this.p.setAlpha(255);
//            }
//        } else if (cameraController != null && !this.front_screen_flash && (bitmap = this.ghost_selected_image_bitmap) != null) {
//            setLastImageMatrix(canvas, bitmap, uIRotation, true);
//            this.p.setAlpha(this.ghost_image_alpha);
//            canvas.drawBitmap(this.ghost_selected_image_bitmap, this.last_image_matrix, this.p);
//            this.p.setAlpha(255);
//        }
//        if (preview.isPreviewBitmapEnabled()) {
//            Bitmap zebraStripesBitmap = preview.getZebraStripesBitmap();
//            if (zebraStripesBitmap != null) {
//                setLastImageMatrix(canvas, zebraStripesBitmap, 0, false);
//                this.p.setAlpha(255);
//                canvas.drawBitmap(zebraStripesBitmap, this.last_image_matrix, this.p);
//            }
//            Bitmap focusPeakingBitmap = preview.getFocusPeakingBitmap();
//            if (focusPeakingBitmap != null) {
//                setLastImageMatrix(canvas, focusPeakingBitmap, 0, false);
//                this.p.setAlpha(127);
//                if (this.focus_peaking_color_pref != i) {
//                    this.p.setColorFilter(new PorterDuffColorFilter(this.focus_peaking_color_pref, PorterDuff.Mode.SRC_IN));
//                }
//                canvas.drawBitmap(focusPeakingBitmap, this.last_image_matrix, this.p);
//                if (this.focus_peaking_color_pref != i) {
//                    this.p.setColorFilter(null);
//                }
//                this.p.setAlpha(255);
//            }
//        }
//        doThumbnailAnimation(canvas, currentTimeMillis);
//        drawUI(canvas, /*uIRotation,*/ currentTimeMillis);
//        drawAngleLines(canvas, uIRotation, currentTimeMillis);
//        doFocusAnimation(canvas, currentTimeMillis);
//        CameraController.Face[] facesDetected = preview.getFacesDetected();
//        if (facesDetected != null) {
//            this.p.setColor(Color.rgb(255, 235, 59));
//            this.p.setStyle(Paint.Style.STROKE);
//            this.p.setStrokeWidth(this.stroke_width);
//            for (CameraController.Face face : facesDetected) {
//                if (face.score>=50) {
//                    canvas.drawRect(face.rect, this.p);
//                }
//            }
//            this.p.setStyle(Paint.Style.FILL);
//        }
//        if (!this.enable_gyro_target_spot || cameraController == null) {
//            return;
//        }
//        GyroSensor gyroSensor2 = this.main_activity.getApplicationInterface().getGyroSensor();
//        if (gyroSensor2.isRecording()) {
//            for (float[] fArr : this.gyro_directions) {
//                gyroSensor2.getRelativeInverseVector(this.transformed_gyro_direction, fArr);
//                gyroSensor2.getRelativeInverseVector(this.transformed_gyro_direction_up, this.gyro_direction_up);
//                float f2 = -((float) Math.asin(this.transformed_gyro_direction[1]));
//                float f3 = -((float) Math.asin(this.transformed_gyro_direction[c]));
//                if (Math.abs(f2)>=1.5707963267948966d || Math.abs(f3)>=1.5707963267948966d) {
//                    f = f2;
//                    gyroSensor = gyroSensor2;
//                } else {
//                    updateCachedViewAngles(currentTimeMillis);
//                    float f4 = this.view_angle_x_preview;
//                    float f5 = this.view_angle_y_preview;
//                    float width = (float) (canvas.getWidth() / (Math.tan(Math.toRadians(f4 / 2.0d)) * 2.0d));
//                    float height = (float) (canvas.getHeight() / (Math.tan(Math.toRadians(f5 / 2.0d)) * 2.0d));
//                    float zoomRatio = width * preview.getZoomRatio();
//                    float zoomRatio2 = height * preview.getZoomRatio() * ((float) Math.tan(f3));
//                    this.p.setColor(-1);
//                    f = f2;
//                    gyroSensor = gyroSensor2;
//                    drawGyroSpot(canvas, 0.0f, 0.0f, -1.0f, 0.0f, 48, true);
//                    this.p.setColor(-16776961);
//                    float[] fArr2 = this.transformed_gyro_direction_up;
//                    drawGyroSpot(canvas, zoomRatio * ((float) Math.tan(f2)), zoomRatio2, -fArr2[1], -fArr2[0], 45, false);
//                }
//                if (gyroSensor.isUpright() != 0 && Math.abs(f)<=0.34906584f) {
//                    canvas.save();
//                    canvas.rotate(uIRotation, canvas.getWidth() / 2.0f, canvas.getHeight() / 2.0f);
//                    float f6 = this.scale;
//                    int width2 = canvas.getWidth() / 2;
//                    int height2 = (canvas.getHeight() / 2) - ((int) ((f6 * 80.0f) + 0.5f));
//                    int i2 = ((int) ((64.0f * f6) + 0.5f)) / 2;
//                    this.icon_dest.set(width2 - i2, height2 - i2, width2 + i2, height2 + i2);
//                }
//                gyroSensor2 = gyroSensor;
//                c = 0;
//            }
//        }
//    }

    public void onDrawPreview(Canvas canvas) {
        int i;
        Bitmap bitmap;
        float f;
        GyroSensor gyroSensor;
        if (!this.has_settings) {
            Log.d(TAG, "onDrawPreview: need to update settings");
            updateSettings();
        }
        Preview preview = this.main_activity.getPreview();
        CameraController cameraController = preview.getCameraController();
        int uIRotation = preview.getUIRotation();
        long currentTimeMillis = System.currentTimeMillis();
        char c = 0;
        boolean z = this.want_histogram || this.want_zebra_stripes || this.want_focus_peaking;
        if (z != preview.isPreviewBitmapEnabled()) {
            if (z) {
                preview.enablePreviewBitmap();
            } else {
                preview.disablePreviewBitmap();
            }
        }
        if (z) {
            if (this.want_histogram) {
                preview.enableHistogram(this.histogram_type);
            } else {
                preview.disableHistogram();
            }
            if (this.want_zebra_stripes) {
                preview.enableZebraStripes(this.zebra_stripes_threshold, this.zebra_stripes_color_foreground, this.zebra_stripes_color_background);
            } else {
                preview.disableZebraStripes();
            }
            if (this.want_focus_peaking) {
                preview.enableFocusPeaking();
            } else {
                preview.disableFocusPeaking();
            }
        }
        if (preview.usingCamera2API() && (cameraController == null || cameraController.shouldCoverPreview())) {
            this.p.setColor(-16777216);
            canvas.drawRect(0.0f, 0.0f, canvas.getWidth(), canvas.getHeight(), this.p);
        }
        if (cameraController != null && this.front_screen_flash) {
            this.p.setColor(-1);
            i = -1;
            canvas.drawRect(0.0f, 0.0f, canvas.getWidth(), canvas.getHeight(), this.p);
        } else {
            i = -1;
            if ("flash_frontscreen_torch".equals(preview.getCurrentFlashValue())) {
                this.p.setColor(-1);
                this.p.setAlpha(200);
                canvas.drawRect(0.0f, 0.0f, canvas.getWidth(), canvas.getHeight(), this.p);
                this.p.setAlpha(255);
            }
        }
        if (this.main_activity.getMainUI().inImmersiveMode() && this.immersive_mode_everything_pref) {
            return;
        }
        if (cameraController != null && this.taking_picture && !this.front_screen_flash && this.take_photo_border_pref) {
            this.p.setColor(i);
            this.p.setStyle(Paint.Style.STROKE);
            this.p.setStrokeWidth(this.stroke_width);
            this.p.setStrokeWidth((this.scale * 5.0f) + 0.5f);
            canvas.drawRect(0.0f, 0.0f, canvas.getWidth(), canvas.getHeight(), this.p);
            this.p.setStyle(Paint.Style.FILL);
            this.p.setStrokeWidth(this.stroke_width);
        }
        drawGrids(canvas);
        drawCropGuides(canvas);
        if (this.last_thumbnail != null && !this.last_thumbnail_is_video && cameraController != null && (this.show_last_image || (this.allow_ghost_last_image && !this.front_screen_flash && this.ghost_image_pref.equals("preference_ghost_image_last")))) {
            if (this.show_last_image) {
                this.p.setColor(Color.rgb(0, 0, 0));
                canvas.drawRect(0.0f, 0.0f, canvas.getWidth(), canvas.getHeight(), this.p);
            }
            setLastImageMatrix(canvas, this.last_thumbnail, uIRotation, !this.show_last_image);
            if (!this.show_last_image) {
                this.p.setAlpha(this.ghost_image_alpha);
            }
            canvas.drawBitmap(this.last_thumbnail, this.last_image_matrix, this.p);
            if (!this.show_last_image) {
                this.p.setAlpha(255);
            }
        } else if (cameraController != null && !this.front_screen_flash && (bitmap = this.ghost_selected_image_bitmap) != null) {
            setLastImageMatrix(canvas, bitmap, uIRotation, true);
            this.p.setAlpha(this.ghost_image_alpha);
            canvas.drawBitmap(this.ghost_selected_image_bitmap, this.last_image_matrix, this.p);
            this.p.setAlpha(255);
        }
        if (preview.isPreviewBitmapEnabled()) {
            Bitmap zebraStripesBitmap = preview.getZebraStripesBitmap();
            if (zebraStripesBitmap != null) {
                setLastImageMatrix(canvas, zebraStripesBitmap, 0, false);
                this.p.setAlpha(255);
                canvas.drawBitmap(zebraStripesBitmap, this.last_image_matrix, this.p);
            }
            Bitmap focusPeakingBitmap = preview.getFocusPeakingBitmap();
            if (focusPeakingBitmap != null) {
                setLastImageMatrix(canvas, focusPeakingBitmap, 0, false);
                this.p.setAlpha(127);
                if (this.focus_peaking_color_pref != i) {
                    this.p.setColorFilter(new PorterDuffColorFilter(this.focus_peaking_color_pref, PorterDuff.Mode.SRC_IN));
                }
                canvas.drawBitmap(focusPeakingBitmap, this.last_image_matrix, this.p);
                if (this.focus_peaking_color_pref != i) {
                    this.p.setColorFilter(null);
                }
                this.p.setAlpha(255);
            }
        }
        doThumbnailAnimation(canvas, currentTimeMillis);
        drawUI(canvas, currentTimeMillis);
        drawAngleLines(canvas, currentTimeMillis);
        doFocusAnimation(canvas, currentTimeMillis);
        CameraController.Face[] facesDetected = preview.getFacesDetected();
        if (facesDetected != null) {
            this.p.setColor(Color.rgb(255, 235, 59));
            this.p.setStyle(Paint.Style.STROKE);
            this.p.setStrokeWidth(this.stroke_width);
            for (CameraController.Face face : facesDetected) {
                if (face.score >= 50) {
                    canvas.drawRect(face.rect, this.p);
                }
            }
            this.p.setStyle(Paint.Style.FILL);
        }
        if (!this.enable_gyro_target_spot || cameraController == null) {
            return;
        }
        GyroSensor gyroSensor2 = this.main_activity.getApplicationInterface().getGyroSensor();
        if (gyroSensor2.isRecording()) {
            for (float[] fArr : this.gyro_directions) {
                gyroSensor2.getRelativeInverseVector(this.transformed_gyro_direction, fArr);
                gyroSensor2.getRelativeInverseVector(this.transformed_gyro_direction_up, this.gyro_direction_up);
                float f2 = -((float) Math.asin(this.transformed_gyro_direction[1]));
                float f3 = -((float) Math.asin(this.transformed_gyro_direction[c]));
                if (Math.abs(f2) >= 1.5707963267948966d || Math.abs(f3) >= 1.5707963267948966d) {
                    f = f2;
                    gyroSensor = gyroSensor2;
                } else {
                    updateCachedViewAngles(currentTimeMillis);
                    float f4 = this.view_angle_x_preview;
                    float f5 = this.view_angle_y_preview;
                    float width = (float) (canvas.getWidth() / (Math.tan(Math.toRadians(f4 / 2.0d)) * 2.0d));
                    float height = (float) (canvas.getHeight() / (Math.tan(Math.toRadians(f5 / 2.0d)) * 2.0d));
                    float zoomRatio = width * preview.getZoomRatio();
                    float zoomRatio2 = height * preview.getZoomRatio() * ((float) Math.tan(f3));
                    this.p.setColor(-1);
                    f = f2;
                    gyroSensor = gyroSensor2;
                    drawGyroSpot(canvas, 0.0f, 0.0f, -1.0f, 0.0f, 48, true);
                    this.p.setColor(-16776961);
                    float[] fArr2 = this.transformed_gyro_direction_up;
                    drawGyroSpot(canvas, zoomRatio * ((float) Math.tan(f2)), zoomRatio2, -fArr2[1], -fArr2[0], 45, false);
                }
                if (gyroSensor.isUpright() != 0 && Math.abs(f) <= 0.34906584f) {
                    canvas.save();
                    canvas.rotate(uIRotation, canvas.getWidth() / 2.0f, canvas.getHeight() / 2.0f);
                    float f6 = this.scale;
                    int width2 = canvas.getWidth() / 2;
                    int height2 = (canvas.getHeight() / 2) - ((int) ((f6 * 80.0f) + 0.5f));
                    int i2 = ((int) ((64.0f * f6) + 0.5f)) / 2;
                    this.icon_dest.set(width2 - i2, height2 - i2, width2 + i2, height2 + i2);
                }
                gyroSensor2 = gyroSensor;
                c = 0;
            }
        }
    }

    private void setLastImageMatrix(Canvas canvas, Bitmap bitmap, int i, boolean z) {
        CameraController cameraController = this.main_activity.getPreview().getCameraController();
        this.last_image_src_rect.left = 0.0f;
        this.last_image_src_rect.top = 0.0f;
        this.last_image_src_rect.right = bitmap.getWidth();
        this.last_image_src_rect.bottom = bitmap.getHeight();
        if (i == 90 || i == 270) {
            this.last_image_src_rect.right = bitmap.getHeight();
            this.last_image_src_rect.bottom = bitmap.getWidth();
        }
        this.last_image_dst_rect.left = 0.0f;
        this.last_image_dst_rect.top = 0.0f;
        this.last_image_dst_rect.right = canvas.getWidth();
        this.last_image_dst_rect.bottom = canvas.getHeight();
        this.last_image_matrix.setRectToRect(this.last_image_src_rect, this.last_image_dst_rect, Matrix.ScaleToFit.CENTER);
        if (i == 90 || i == 270) {
            float height = bitmap.getHeight() - bitmap.getWidth();
            this.last_image_matrix.preTranslate(height / 2.0f, (-height) / 2.0f);
        }
        this.last_image_matrix.preRotate(i, bitmap.getWidth() / 2.0f, bitmap.getHeight() / 2.0f);
        if (z) {
            if (!(cameraController != null && cameraController.getFacing() == CameraController.Facing.FACING_FRONT) || this.sharedPreferences.getString(PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_no").equals("preference_front_camera_mirror_photo")) {
                return;
            }
            this.last_image_matrix.preScale(-1.0f, 1.0f, bitmap.getWidth() / 2.0f, 0.0f);
        }
    }

    private void drawGyroSpot(Canvas canvas, float f, float f2, float f3, float f4, int i, boolean z) {
        if (z) {
            this.p.setStyle(Paint.Style.STROKE);
            this.p.setStrokeWidth(this.stroke_width);
            this.p.setAlpha(255);
        } else {
            this.p.setAlpha(127);
        }
        canvas.drawCircle((canvas.getWidth() / 2.0f) + f, (canvas.getHeight() / 2.0f) + f2, (i * this.scale) + 0.5f, this.p);
        this.p.setAlpha(255);
        this.p.setStyle(Paint.Style.FILL);
    }

    public void onExtraOSDValuesChanged(String str, String str2) {
        this.OSDLine1 = str;
        this.OSDLine2 = str2;
    }

    public boolean getStoredHasStampPref() {
        return this.has_stamp_pref;
    }

    public boolean getStoredAutoStabilisePref() {
        return this.auto_stabilise_pref;
    }
}