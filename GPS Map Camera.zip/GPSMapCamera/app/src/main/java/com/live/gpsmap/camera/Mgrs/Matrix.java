package com.live.gpsmap.camera.Mgrs;

import java.util.Iterator;

/* loaded from: classes2.dex */
public class Matrix {
    protected static final double EPSILON = 1.0E-6d;
    private static final int NUM_ELEMENTS = 16;
    private int hashCode;
    private final boolean isOrthonormalTransform;
    public final double m11;
    public final double m12;
    public final double m13;
    public final double m14;
    public final double m21;
    public final double m22;
    public final double m23;
    public final double m24;
    public final double m31;
    public final double m32;
    public final double m33;
    public final double m34;
    public final double m41;
    public final double m42;
    public final double m43;
    public final double m44;
    private static final Double NEGATIVE_ZERO = Double.valueOf(-0.0d);
    private static final Double POSITIVE_ZERO = Double.valueOf((double) 0.0d);
    public static final Matrix IDENTITY = new Matrix(1.0d, 0.0d, 0.0d, 0.0d, 0.0d, 1.0d, 0.0d, 0.0d, 0.0d, 0.0d, 1.0d, 0.0d, 0.0d, 0.0d, 0.0d, 1.0d, true);

    public Matrix(double d) {
        this(d, 0.0d, 0.0d, 0.0d, 0.0d, d, 0.0d, 0.0d, 0.0d, 0.0d, d, 0.0d, 0.0d, 0.0d, 0.0d, d);
    }

    public Matrix(double d, double d2, double d3, double d4, double d5, double d6, double d7, double d8, double d9, double d10, double d11, double d12, double d13, double d14, double d15, double d16) {
        this(d, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12, d13, d14, d15, d16, false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Matrix(double d, double d2, double d3, double d4, double d5, double d6, double d7, double d8, double d9, double d10, double d11, double d12, double d13, double d14, double d15, double d16, boolean z) {
        this.m11 = d;
        this.m12 = d2;
        this.m13 = d3;
        this.m14 = d4;
        this.m21 = d5;
        this.m22 = d6;
        this.m23 = d7;
        this.m24 = d8;
        this.m31 = d9;
        this.m32 = d10;
        this.m33 = d11;
        this.m34 = d12;
        this.m41 = d13;
        this.m42 = d14;
        this.m43 = d15;
        this.m44 = d16;
        this.isOrthonormalTransform = z;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        Matrix matrix = (Matrix) obj;
        return this.m11 == matrix.m11 && this.m12 == matrix.m12 && this.m13 == matrix.m13 && this.m14 == matrix.m14 && this.m21 == matrix.m21 && this.m22 == matrix.m22 && this.m23 == matrix.m23 && this.m24 == matrix.m24 && this.m31 == matrix.m31 && this.m32 == matrix.m32 && this.m33 == matrix.m33 && this.m34 == matrix.m34 && this.m41 == matrix.m41 && this.m42 == matrix.m42 && this.m43 == matrix.m43 && this.m44 == matrix.m44;
    }

    public final int hashCode() {
        if (this.hashCode == 0) {
            long doubleToLongBits = Double.doubleToLongBits(this.m11);
            long doubleToLongBits2 = Double.doubleToLongBits(this.m12);
            long doubleToLongBits3 = Double.doubleToLongBits(this.m13);
            long doubleToLongBits4 = Double.doubleToLongBits(this.m14);
            long doubleToLongBits5 = Double.doubleToLongBits(this.m21);
            long doubleToLongBits6 = Double.doubleToLongBits(this.m22);
            long doubleToLongBits7 = Double.doubleToLongBits(this.m23);
            long doubleToLongBits8 = Double.doubleToLongBits(this.m24);
            long doubleToLongBits9 = Double.doubleToLongBits(this.m31);
            long doubleToLongBits10 = Double.doubleToLongBits(this.m32);
            long doubleToLongBits11 = Double.doubleToLongBits(this.m33);
            long doubleToLongBits12 = Double.doubleToLongBits(this.m34);
            long doubleToLongBits13 = Double.doubleToLongBits(this.m41);
            long doubleToLongBits14 = Double.doubleToLongBits(this.m42);
            long doubleToLongBits15 = Double.doubleToLongBits(this.m43);
            long doubleToLongBits16 = Double.doubleToLongBits(this.m44);
            this.hashCode = (((((((((((((((((((((((((((((((int) (doubleToLongBits ^ (doubleToLongBits >>> 32))) * 29) + ((int) (doubleToLongBits2 ^ (doubleToLongBits2 >>> 32)))) * 29) + ((int) (doubleToLongBits3 ^ (doubleToLongBits3 >>> 32)))) * 29) + ((int) (doubleToLongBits4 ^ (doubleToLongBits4 >>> 32)))) * 29) + ((int) (doubleToLongBits5 ^ (doubleToLongBits5 >>> 32)))) * 29) + ((int) (doubleToLongBits6 ^ (doubleToLongBits6 >>> 32)))) * 29) + ((int) (doubleToLongBits7 ^ (doubleToLongBits7 >>> 32)))) * 29) + ((int) (doubleToLongBits8 ^ (doubleToLongBits8 >>> 32)))) * 29) + ((int) (doubleToLongBits9 ^ (doubleToLongBits9 >>> 32)))) * 29) + ((int) (doubleToLongBits10 ^ (doubleToLongBits10 >>> 32)))) * 29) + ((int) (doubleToLongBits11 ^ (doubleToLongBits11 >>> 32)))) * 29) + ((int) (doubleToLongBits12 ^ (doubleToLongBits12 >>> 32)))) * 29) + ((int) (doubleToLongBits13 ^ (doubleToLongBits13 >>> 32)))) * 29) + ((int) (doubleToLongBits14 ^ (doubleToLongBits14 >>> 32)))) * 29) + ((int) (doubleToLongBits15 ^ (doubleToLongBits15 >>> 32)))) * 29) + ((int) ((doubleToLongBits16 >>> 32) ^ doubleToLongBits16));
        }
        return this.hashCode;
    }

    public static Matrix fromArray(double[] dArr, int i, boolean z) {
        if (dArr == null) {
            throw new IllegalArgumentException("Array Is Null");
        }
        if (dArr.length - i >= 16) {
            if (z) {
                return new Matrix(dArr[i + 0], dArr[i + 1], dArr[i + 2], dArr[i + 3], dArr[i + 4], dArr[i + 5], dArr[i + 6], dArr[i + 7], dArr[i + 8], dArr[i + 9], dArr[i + 10], dArr[i + 11], dArr[i + 12], dArr[i + 13], dArr[i + 14], dArr[i + 15]);
            }
            return new Matrix(dArr[i + 0], dArr[i + 4], dArr[i + 8], dArr[i + 12], dArr[i + 1], dArr[i + 5], dArr[i + 9], dArr[i + 13], dArr[i + 2], dArr[i + 6], dArr[i + 10], dArr[i + 14], dArr[i + 3], dArr[i + 7], dArr[i + 11], dArr[i + 15]);
        }
        throw new IllegalArgumentException("Array Invalid Length");
    }

    public final double[] toArray(double[] dArr, int i, boolean z) {
        if (dArr == null) {
            throw new IllegalArgumentException("Array Is Null");
        }
        if (dArr.length - i >= 16) {
            if (z) {
                dArr[i + 0] = this.m11;
                dArr[i + 1] = this.m12;
                dArr[i + 2] = this.m13;
                dArr[i + 3] = this.m14;
                dArr[i + 4] = this.m21;
                dArr[i + 5] = this.m22;
                dArr[i + 6] = this.m23;
                dArr[i + 7] = this.m24;
                dArr[i + 8] = this.m31;
                dArr[i + 9] = this.m32;
                dArr[i + 10] = this.m33;
                dArr[i + 11] = this.m34;
                dArr[i + 12] = this.m41;
                dArr[i + 13] = this.m42;
                dArr[i + 14] = this.m43;
                dArr[i + 15] = this.m44;
            } else {
                dArr[i + 0] = this.m11;
                dArr[i + 4] = this.m12;
                dArr[i + 8] = this.m13;
                dArr[i + 12] = this.m14;
                dArr[i + 1] = this.m21;
                dArr[i + 5] = this.m22;
                dArr[i + 9] = this.m23;
                dArr[i + 13] = this.m24;
                dArr[i + 2] = this.m31;
                dArr[i + 6] = this.m32;
                dArr[i + 10] = this.m33;
                dArr[i + 14] = this.m34;
                dArr[i + 3] = this.m41;
                dArr[i + 7] = this.m42;
                dArr[i + 11] = this.m43;
                dArr[i + 15] = this.m44;
            }
            return dArr;
        }
        throw new IllegalArgumentException("Array Invalid Length");
    }

    public final String toString() {
        return "(" + this.m11 + ", " + this.m12 + ", " + this.m13 + ", " + this.m14 + ", \r\n" + this.m21 + ", " + this.m22 + ", " + this.m23 + ", " + this.m24 + ", \r\n" + this.m31 + ", " + this.m32 + ", " + this.m33 + ", " + this.m34 + ", \r\n" + this.m41 + ", " + this.m42 + ", " + this.m43 + ", " + this.m44 + ")";
    }

    public final double getM11() {
        return this.m11;
    }

    public final double getM12() {
        return this.m12;
    }

    public final double getM13() {
        return this.m13;
    }

    public final double getM14() {
        return this.m14;
    }

    public final double getM21() {
        return this.m21;
    }

    public final double getM22() {
        return this.m22;
    }

    public final double getM23() {
        return this.m23;
    }

    public final double getM24() {
        return this.m24;
    }

    public final double getM31() {
        return this.m31;
    }

    public final double getM32() {
        return this.m32;
    }

    public final double getM33() {
        return this.m33;
    }

    public final double getM34() {
        return this.m34;
    }

    public final double getM41() {
        return this.m41;
    }

    public final double getM42() {
        return this.m42;
    }

    public final double getM43() {
        return this.m43;
    }

    public final double getM44() {
        return this.m44;
    }

    public final double m11() {
        return this.m11;
    }

    public final double m12() {
        return this.m12;
    }

    public final double m13() {
        return this.m13;
    }

    public final double m14() {
        return this.m14;
    }

    public final double m21() {
        return this.m21;
    }

    public final double m22() {
        return this.m22;
    }

    public final double m23() {
        return this.m23;
    }

    public final double m24() {
        return this.m24;
    }

    public final double m31() {
        return this.m31;
    }

    public final double m32() {
        return this.m32;
    }

    public final double m33() {
        return this.m33;
    }

    public final double m34() {
        return this.m34;
    }

    public final double m41() {
        return this.m41;
    }

    public final double m42() {
        return this.m42;
    }

    public final double m43() {
        return this.m43;
    }

    public final double m44() {
        return this.m44;
    }

    public static Matrix fromAxes(Vec4[] vec4Arr) {
        if (vec4Arr == null) {
            throw new IllegalArgumentException("Axes Is Null");
        }
        if (vec4Arr.length < 3) {
            throw new IllegalArgumentException("Array Invalid Length");
        }
        Vec4 vec4 = vec4Arr[0];
        if (vec4 == null || vec4Arr[1] == null || vec4Arr[2] == null) {
            throw new IllegalArgumentException("Axes Is Null");
        }
        Vec4 normalize3 = vec4.normalize3();
        Vec4 normalize32 = normalize3.cross3(vec4Arr[1]).normalize3();
        Vec4 normalize33 = normalize32.cross3(normalize3).normalize3();
        return new Matrix(normalize3.x, normalize33.x, normalize32.x, 0.0d, normalize3.y, normalize33.y, normalize32.y, 0.0d, normalize3.z, normalize33.z, normalize32.z, 0.0d, 0.0d, 0.0d, 0.0d, 1.0d, true);
    }

    public static Matrix fromAxisAngle(Angle angle, Vec4 vec4) {
        if (angle != null) {
            if (vec4 != null) {
                return fromAxisAngle(angle, vec4.x, vec4.y, vec4.z, true);
            }
            throw new IllegalArgumentException("Vec4 Is Null");
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public static Matrix fromAxisAngle(Angle angle, double d, double d2, double d3) {
        if (angle != null) {
            return fromAxisAngle(angle, d, d2, d3, true);
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    private static Matrix fromAxisAngle(Angle angle, double d, double d2, double d3, boolean z) {
        if (angle != null) {
            if (z) {
                double sqrt = Math.sqrt((d * d) + (d2 * d2) + (d3 * d3));
                if (!isZero(sqrt) && sqrt != 1.0d) {
                    double d4 = d / sqrt;
                    double d5 = d2 / sqrt;
                    double d6 = d3 / sqrt;
                    double cos = angle.cos();
                    double sin = angle.sin();
                    double d7 = 1.0d - cos;
                    double d8 = d7 * d4;
                    double d9 = d8 * d5;
                    double d10 = sin * d6;
                    double d11 = d8 * d6;
                    double d12 = sin * d5;
                    double d13 = d7 * d5;
                    double d14 = cos + (d5 * d13);
                    double d15 = d13 * d6;
                    double d16 = sin * d4;
                    return new Matrix((d8 * d4) + cos, d9 - d10, d11 + d12, 0.0d, d9 + d10, d14, d15 - d16, 0.0d, d11 - d12, d15 + d16, cos + (d7 * d6 * d6), 0.0d, 0.0d, 0.0d, 0.0d, 1.0d, true);
                }
            }
            double cos2 = angle.cos();
            double sin2 = angle.sin();
            double d17 = 1.0d - cos2;
            double d18 = d17 * d;
            double d19 = d18 * d2;
            double d20 = sin2 * d3;
            double d21 = d18 * d3;
            double d22 = sin2 * d2;
            double d23 = d17 * d2;
            double d24 = d23 * d3;
            double d25 = sin2 * d;
            return new Matrix((d18 * d) + cos2, d19 - d20, d21 + d22, 0.0d, d19 + d20, cos2 + (d2 * d23), d24 - d25, 0.0d, d21 - d22, d24 + d25, cos2 + (d17 * d3 * d3), 0.0d, 0.0d, 0.0d, 0.0d, 1.0d, true);
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public static Matrix fromQuaternion(Quaternion quaternion) {
        if (quaternion != null) {
            return fromQuaternion(quaternion.x, quaternion.y, quaternion.z, quaternion.w, true);
        }
        throw new IllegalArgumentException("Quaternion Is Null");
    }

    private static Matrix fromQuaternion(double d, double d2, double d3, double d4, boolean z) {
        if (z) {
            double sqrt = Math.sqrt((d * d) + (d2 * d2) + (d3 * d3) + (d4 * d4));
            if (!isZero(sqrt) && sqrt != 1.0d) {
                double d5 = d / sqrt;
                double d6 = d2 / sqrt;
                double d7 = d3 / sqrt;
                double d8 = d4 / sqrt;
                double d9 = d6 * 2.0d;
                double d10 = d9 * d6;
                double d11 = d7 * 2.0d;
                double d12 = d11 * d7;
                double d13 = 2.0d * d5;
                double d14 = d6 * d13;
                double d15 = d11 * d8;
                double d16 = d13 * d7;
                double d17 = d9 * d8;
                double d18 = 1.0d - (d5 * d13);
                double d19 = d9 * d7;
                double d20 = d13 * d8;
                return new Matrix((1.0d - d10) - d12, d14 - d15, d16 + d17, 0.0d, d14 + d15, d18 - d12, d19 - d20, 0.0d, d16 - d17, d19 + d20, d18 - d10, 0.0d, 0.0d, 0.0d, 0.0d, 1.0d, true);
            }
        }
        double d21 = d2 * 2.0d;
        double d22 = d21 * d2;
        double d23 = d3 * 2.0d;
        double d24 = d23 * d3;
        double d25 = 2.0d * d;
        double d26 = d2 * d25;
        double d27 = d23 * d4;
        double d28 = d25 * d3;
        double d29 = d21 * d4;
        double d30 = 1.0d - (d * d25);
        double d31 = d21 * d3;
        double d32 = d25 * d4;
        return new Matrix((1.0d - d22) - d24, d26 - d27, d28 + d29, 0.0d, d26 + d27, d30 - d24, d31 - d32, 0.0d, d28 - d29, d31 + d32, d30 - d22, 0.0d, 0.0d, 0.0d, 0.0d, 1.0d, true);
    }

    public static Matrix fromRotationXYZ(Angle angle, Angle angle2, Angle angle3) {
        if (angle == null || angle2 == null || angle3 == null) {
            throw new IllegalArgumentException("Angle Is Null");
        }
        double cos = angle.cos();
        double cos2 = angle2.cos();
        double cos3 = angle3.cos();
        double sin = angle.sin();
        double sin2 = angle2.sin();
        double sin3 = angle3.sin();
        double d = sin * sin2;
        double d2 = sin2 * cos;
        return new Matrix(cos2 * cos3, (-cos2) * sin3, sin2, 0.0d, (d * cos3) + (cos * sin3), (-(d * sin3)) + (cos * cos3), (-sin) * cos2, 0.0d, (-(d2 * cos3)) + (sin * sin3), (d2 * sin3) + (sin * cos3), cos * cos2, 0.0d, 0.0d, 0.0d, 0.0d, 1.0d, true);
    }

    public static Matrix fromRotationX(Angle angle) {
        if (angle != null) {
            double cos = angle.cos();
            double sin = angle.sin();
            return new Matrix(1.0d, 0.0d, 0.0d, 0.0d, 0.0d, cos, -sin, 0.0d, 0.0d, sin, cos, 0.0d, 0.0d, 0.0d, 0.0d, 1.0d, true);
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public static Matrix fromRotationY(Angle angle) {
        if (angle != null) {
            double cos = angle.cos();
            double sin = angle.sin();
            return new Matrix(cos, 0.0d, sin, 0.0d, 0.0d, 1.0d, 0.0d, 0.0d, -sin, 0.0d, cos, 0.0d, 0.0d, 0.0d, 0.0d, 1.0d, true);
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public static Matrix fromRotationZ(Angle angle) {
        if (angle != null) {
            double cos = angle.cos();
            double sin = angle.sin();
            return new Matrix(cos, -sin, 0.0d, 0.0d, sin, cos, 0.0d, 0.0d, 0.0d, 0.0d, 1.0d, 0.0d, 0.0d, 0.0d, 0.0d, 1.0d, true);
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public static Matrix fromScale(double d) {
        return fromScale(d, d, d);
    }

    public static Matrix fromScale(Vec4 vec4) {
        if (vec4 != null) {
            return fromScale(vec4.x, vec4.y, vec4.z);
        }
        throw new IllegalArgumentException("Vec4 Is Null");
    }

    public static Matrix fromScale(double d, double d2, double d3) {
        return new Matrix(d, 0.0d, 0.0d, 0.0d, 0.0d, d2, 0.0d, 0.0d, 0.0d, 0.0d, d3, 0.0d, 0.0d, 0.0d, 0.0d, 1.0d, false);
    }

    public static Matrix fromTranslation(Vec4 vec4) {
        if (vec4 != null) {
            return fromTranslation(vec4.x, vec4.y, vec4.z);
        }
        throw new IllegalArgumentException("Vec4 Is Null");
    }

    public static Matrix fromTranslation(double d, double d2, double d3) {
        return new Matrix(1.0d, 0.0d, 0.0d, d, 0.0d, 1.0d, 0.0d, d2, 0.0d, 0.0d, 1.0d, d3, 0.0d, 0.0d, 0.0d, 1.0d, true);
    }

    public static Matrix fromSkew(Angle angle, Angle angle2) {
        double tan;
        double radians = angle.getRadians();
        double d = 0.0d;
        if (radians >= 1.0E-6d || angle2.getRadians() >= 1.0E-6d) {
            double tan2 = Math.abs(Math.tan(angle.getRadians())) > 1.0E-6d ? 1.0d / Math.tan(angle.getRadians()) : 1000000.0d;
            tan = Math.abs(Math.tan(angle2.getRadians())) > 1.0E-6d ? 1.0d / Math.tan(angle2.getRadians()) : 1000000.0d;
            d = tan2;
        } else {
            tan = 0.0d;
        }
        return new Matrix(1.0d, 0.0d, -d, 0.0d, 0.0d, 1.0d, -tan, 0.0d, 0.0d, 0.0d, 1.0d, 0.0d, 0.0d, 0.0d, 0.0d, 1.0d, false);
    }

    public static Matrix fromLocalOrientation(Vec4 vec4, Vec4[] vec4Arr) {
        if (vec4 != null) {
            if (vec4Arr == null) {
                throw new IllegalArgumentException("Axes Is Null");
            }
            if (vec4Arr.length < 3) {
                throw new IllegalArgumentException("Array Invalid Length");
            }
            if (vec4Arr[0] != null && vec4Arr[1] != null && vec4Arr[2] != null) {
                return fromTranslation(vec4).multiply(fromAxes(vec4Arr));
            }
            throw new IllegalArgumentException("Axes Is Null");
        }
        throw new IllegalArgumentException("Origin Is Null");
    }

    public static Matrix fromPerspective(Angle angle, double d, double d2, double d3, double d4) {
        if (angle != null) {
            double d5 = angle.degrees;
            if (d5 <= 0.0d || d5 > 180.0d) {
                throw new IllegalArgumentException("Argument Out Of Range");
            }
            if (d > 0.0d) {
                if (d2 > 0.0d) {
                    if (d3 > 0.0d) {
                        if (d4 > 0.0d) {
                            if (d4 > d3) {
                                double tanHalfAngle = 1.0d / angle.tanHalfAngle();
                                double d6 = d4 - d3;
                                return new Matrix(tanHalfAngle, 0.0d, 0.0d, 0.0d, 0.0d, (tanHalfAngle * d) / d2, 0.0d, 0.0d, 0.0d, 0.0d, (-(d4 + d3)) / d6, (-((2.0d * d4) * d3)) / d6, 0.0d, 0.0d, -1.0d, 0.0d);
                            }
                            throw new IllegalArgumentException("Argument Out Of Range");
                        }
                        throw new IllegalArgumentException("Argument Out Of Range");
                    }
                    throw new IllegalArgumentException("Argument Out Of Range");
                }
                throw new IllegalArgumentException("Argument Out Of Range");
            }
            throw new IllegalArgumentException("Argument Out Of Range");
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public static Matrix fromPerspective(double d, double d2, double d3, double d4) {
        if (d > 0.0d) {
            if (d2 > 0.0d) {
                if (d3 > 0.0d) {
                    if (d4 > 0.0d) {
                        if (d4 > d3) {
                            double d5 = d4 - d3;
                            return new Matrix(2.0d / d, 0.0d, 0.0d, 0.0d, 0.0d, (d3 * 2.0d) / d2, 0.0d, 0.0d, 0.0d, 0.0d, (-(d4 + d3)) / d5, (-((d4 * 2.0d) * d3)) / d5, 0.0d, 0.0d, -1.0d, 0.0d);
                        }
                        throw new IllegalArgumentException("Argument Out Of Range");
                    }
                    throw new IllegalArgumentException("Argument Out Of Range");
                }
                throw new IllegalArgumentException("Argument Out Of Range");
            }
            throw new IllegalArgumentException("Argument Out Of Range");
        }
        throw new IllegalArgumentException("Argument Out Of Range");
    }

    public static Matrix fromOrthographic(double d, double d2, double d3, double d4) {
        if (d > 0.0d) {
            if (d2 > 0.0d) {
                if (d3 > 0.0d) {
                    if (d4 > 0.0d) {
                        if (d4 > d3) {
                            double d5 = d4 - d3;
                            return new Matrix(2.0d / d, 0.0d, 0.0d, 0.0d, 0.0d, 2.0d / d2, 0.0d, 0.0d, 0.0d, 0.0d, (-2.0d) / d5, (-(d4 + d3)) / d5, 0.0d, 0.0d, 0.0d, 1.0d);
                        }
                        throw new IllegalArgumentException("Argument Out Of Range");
                    }
                    throw new IllegalArgumentException("Argument Out Of Range");
                }
                throw new IllegalArgumentException("Argument Out Of Range");
            }
            throw new IllegalArgumentException("Argument Out Of Range");
        }
        throw new IllegalArgumentException("Argument Out Of Range");
    }

    public static Matrix fromOrthographic2D(double d, double d2) {
        if (d > 0.0d) {
            if (d2 > 0.0d) {
                return new Matrix(2.0d / d, 0.0d, 0.0d, 0.0d, 0.0d, 2.0d / d2, 0.0d, 0.0d, 0.0d, 0.0d, -1.0d, 0.0d, 0.0d, 0.0d, 0.0d, 1.0d);
            }
            throw new IllegalArgumentException("Argument Out Of Range");
        }
        throw new IllegalArgumentException("Argument Out Of Range");
    }

    public static Matrix fromCovarianceOfVertices(Iterable<? extends Vec4> iterable) {
        Iterator<? extends Vec4> it;
        if (iterable != null) {
            Vec4 computeAveragePoint = Vec4.computeAveragePoint(iterable);
            if (computeAveragePoint == null) {
                return null;
            }
            int i = 0;
            Iterator<? extends Vec4> it2 = iterable.iterator();
            double d = 0.0d;
            double d2 = 0.0d;
            double d3 = 0.0d;
            double d4 = 0.0d;
            double d5 = 0.0d;
            double d6 = 0.0d;
            while (it2.hasNext()) {
                Vec4 next = it2.next();
                if (next != null) {
                    it = it2;
                    d6 += (next.z - computeAveragePoint.z) * (next.z - computeAveragePoint.z);
                    double d7 = d + ((next.x - computeAveragePoint.x) * (next.y - computeAveragePoint.y));
                    d2 += (next.x - computeAveragePoint.x) * (next.z - computeAveragePoint.z);
                    d3 += (next.y - computeAveragePoint.y) * (next.z - computeAveragePoint.z);
                    d4 += (next.x - computeAveragePoint.x) * (next.x - computeAveragePoint.x);
                    d5 += (next.y - computeAveragePoint.y) * (next.y - computeAveragePoint.y);
                    i++;
                    d = d7;
                } else {
                    it = it2;
                }
                it2 = it;
            }
            int i2 = i;
            double d8 = d4;
            double d9 = d5;
            if (i2 == 0) {
                return null;
            }
            double d10 = i2;
            Double.isNaN(d10);
            Double.isNaN(d10);
            double d11 = d / d10;
            Double.isNaN(d10);
            double d12 = d2 / d10;
            Double.isNaN(d10);
            Double.isNaN(d10);
            double d13 = d3 / d10;
            Double.isNaN(d10);
            return new Matrix(d8 / d10, d11, d12, 0.0d, d11, d9 / d10, d13, 0.0d, d12, d13, d6 / d10, 0.0d, 0.0d, 0.0d, 0.0d, 0.0d);
        }
        throw new IllegalArgumentException("Iterable Is Null");
    }

    public final Matrix add(Matrix matrix) {
        if (matrix != null) {
            return new Matrix(this.m11 + matrix.m11, this.m12 + matrix.m12, this.m13 + matrix.m13, this.m14 + matrix.m14, this.m21 + matrix.m21, this.m22 + matrix.m22, this.m23 + matrix.m23, this.m24 + matrix.m24, this.m31 + matrix.m31, this.m32 + matrix.m32, this.m33 + matrix.m33, this.m34 + matrix.m34, this.m41 + matrix.m41, this.m42 + matrix.m42, this.m43 + matrix.m43, this.m44 + matrix.m44);
        }
        throw new IllegalArgumentException("Matrix Is Null");
    }

    public final Matrix subtract(Matrix matrix) {
        if (matrix != null) {
            return new Matrix(this.m11 - matrix.m11, this.m12 - matrix.m12, this.m13 - matrix.m13, this.m14 - matrix.m14, this.m21 - matrix.m21, this.m22 - matrix.m22, this.m23 - matrix.m23, this.m24 - matrix.m24, this.m31 - matrix.m31, this.m32 - matrix.m32, this.m33 - matrix.m33, this.m34 - matrix.m34, this.m41 - matrix.m41, this.m42 - matrix.m42, this.m43 - matrix.m43, this.m44 - matrix.m44);
        }
        throw new IllegalArgumentException("Matrix Is Null");
    }

    public final Matrix multiplyComponents(double d) {
        return new Matrix(this.m11 * d, this.m12 * d, this.m13 * d, this.m14 * d, this.m21 * d, this.m22 * d, this.m23 * d, this.m24 * d, this.m31 * d, this.m32 * d, this.m33 * d, this.m34 * d, this.m41 * d, this.m42 * d, this.m43 * d, this.m44 * d);
    }

    public final Matrix multiply(Matrix matrix) {
        if (matrix != null) {
            double d = this.m11;
            double d2 = matrix.m11;
            double d3 = this.m12;
            double d4 = matrix.m21;
            double d5 = (d * d2) + (d3 * d4);
            double d6 = this.m13;
            double d7 = matrix.m31;
            double d8 = this.m14;
            double d9 = matrix.m41;
            double d10 = d5 + (d6 * d7) + (d8 * d9);
            double d11 = matrix.m12;
            double d12 = d * d11;
            double d13 = matrix.m22;
            double d14 = matrix.m32;
            double d15 = matrix.m42;
            double d16 = d12 + (d3 * d13) + (d6 * d14) + (d8 * d15);
            double d17 = matrix.m13;
            double d18 = d * d17;
            double d19 = matrix.m23;
            double d20 = matrix.m33;
            double d21 = matrix.m43;
            double d22 = d18 + (d3 * d19) + (d6 * d20) + (d8 * d21);
            double d23 = matrix.m14;
            double d24 = d * d23;
            double d25 = matrix.m24;
            double d26 = d24 + (d3 * d25);
            double d27 = matrix.m34;
            double d28 = d26 + (d6 * d27);
            double d29 = matrix.m44;
            double d30 = (d8 * d29) + d28;
            double d31 = this.m21;
            double d32 = this.m22;
            double d33 = this.m23;
            double d34 = this.m24;
            double d35 = (d31 * d2) + (d32 * d4) + (d33 * d7) + (d34 * d9);
            double d36 = (d31 * d11) + (d32 * d13) + (d33 * d14) + (d34 * d15);
            double d37 = (d31 * d17) + (d32 * d19) + (d33 * d20) + (d34 * d21);
            double d38 = (d31 * d23) + (d32 * d25) + (d33 * d27) + (d34 * d29);
            double d39 = this.m31;
            double d40 = this.m32;
            double d41 = this.m33;
            double d42 = this.m34;
            double d43 = (d39 * d2) + (d40 * d4) + (d41 * d7) + (d42 * d9);
            double d44 = (d39 * d11) + (d40 * d13) + (d41 * d14) + (d42 * d15);
            double d45 = (d39 * d17) + (d40 * d19) + (d41 * d20) + (d42 * d21);
            double d46 = (d39 * d23) + (d40 * d25) + (d41 * d27) + (d42 * d29);
            double d47 = this.m41;
            double d48 = this.m42;
            double d49 = this.m43;
            double d50 = (d47 * d2) + (d48 * d4) + (d49 * d7);
            double d51 = this.m44;
            return new Matrix(d10, d16, d22, d30, d35, d36, d37, d38, d43, d44, d45, d46, d50 + (d9 * d51), (d47 * d11) + (d48 * d13) + (d49 * d14) + (d51 * d15), (d47 * d17) + (d48 * d19) + (d49 * d20) + (d51 * d21), (d47 * d23) + (d48 * d25) + (d49 * d27) + (d51 * d29), this.isOrthonormalTransform && matrix.isOrthonormalTransform);
        }
        throw new IllegalArgumentException("Matrix Is Null");
    }

    public final Matrix divideComponents(Matrix matrix) {
        if (matrix != null) {
            return new Matrix(this.m11 / matrix.m11, this.m12 / matrix.m12, this.m13 / matrix.m13, this.m14 / matrix.m14, this.m21 / matrix.m21, this.m22 / matrix.m22, this.m23 / matrix.m23, this.m24 / matrix.m24, this.m31 / matrix.m31, this.m32 / matrix.m32, this.m33 / matrix.m33, this.m34 / matrix.m34, this.m41 / matrix.m41, this.m42 / matrix.m42, this.m43 / matrix.m43, this.m44 / matrix.m44);
        }
        throw new IllegalArgumentException("Matrix Is Null");
    }

    public final Matrix negate() {
        return new Matrix(0.0d - this.m11, 0.0d - this.m12, 0.0d - this.m13, 0.0d - this.m14, 0.0d - this.m21, 0.0d - this.m22, 0.0d - this.m23, 0.0d - this.m24, 0.0d - this.m31, 0.0d - this.m32, 0.0d - this.m33, 0.0d - this.m34, 0.0d - this.m41, 0.0d - this.m42, 0.0d - this.m43, 0.0d - this.m44, this.isOrthonormalTransform);
    }

    public final Vec4 transformBy3(Matrix matrix, double d, double d2, double d3) {
        if (matrix != null) {
            return new Vec4((matrix.m11 * d) + (matrix.m12 * d2) + (matrix.m13 * d3), (matrix.m21 * d) + (matrix.m22 * d2) + (matrix.m23 * d3), (matrix.m31 * d) + (matrix.m32 * d2) + (matrix.m33 * d3));
        }
        throw new IllegalArgumentException("Matrix Is Null");
    }

    public final double getDeterminant() {
        double d = this.m11;
        double d2 = this.m22;
        double d3 = this.m33;
        double d4 = this.m44;
        double d5 = this.m43;
        double d6 = this.m34;
        double d7 = ((d3 * d4) - (d5 * d6)) * d2;
        double d8 = this.m23;
        double d9 = this.m32;
        double d10 = d9 * d4;
        double d11 = this.m42;
        double d12 = this.m24;
        double d13 = (((d7 - ((d10 - (d11 * d6)) * d8)) + (((d9 * d5) - (d11 * d3)) * d12)) * d) + 0.0d;
        double d14 = this.m12;
        double d15 = this.m21;
        double d16 = ((d3 * d4) - (d5 * d6)) * d15;
        double d17 = this.m31;
        double d18 = this.m41;
        return ((d13 - (d14 * ((d16 - (((d17 * d4) - (d18 * d6)) * d8)) + (((d17 * d5) - (d18 * d3)) * d12)))) + (this.m13 * (((((d9 * d4) - (d11 * d6)) * d15) - (d2 * ((d4 * d17) - (d6 * d18)))) + (d12 * ((d17 * d11) - (d18 * d9)))))) - (this.m14 * ((((((d9 * d5) - d11) - d3) * d15) - (((d5 * d17) - (d18 * d3)) * d2)) + (((d17 * d11) - (d18 * d9)) * d8)));
    }

    public final Matrix getTranspose() {
        return new Matrix(this.m11, this.m21, this.m31, this.m41, this.m12, this.m22, this.m32, this.m42, this.m13, this.m23, this.m33, this.m43, this.m14, this.m24, this.m34, this.m44, false);
    }

    public final double getTrace() {
        return this.m11 + this.m22 + this.m33 + this.m44;
    }

    public final Matrix getInverse() {
        if (this.isOrthonormalTransform) {
            return computeTransformInverse(this);
        }
        return computeGeneralInverse(this);
    }

    private static Matrix computeGeneralInverse(Matrix matrix) {
        double d = matrix.m22;
        double d2 = matrix.m33;
        double d3 = matrix.m44;
        double d4 = matrix.m43;
        double d5 = matrix.m34;
        double d6 = ((d2 * d3) - (d4 * d5)) * d;
        double d7 = matrix.m23;
        double d8 = matrix.m32;
        double d9 = d8 * d3;
        double d10 = matrix.m42;
        double d11 = matrix.m24;
        double d12 = (d6 - ((d9 - (d10 * d5)) * d7)) + (((d8 * d4) - (d10 * d2)) * d11);
        double d13 = matrix.m21;
        double d14 = ((d2 * d3) - (d4 * d5)) * d13;
        double d15 = matrix.m31;
        double d16 = d15 * d3;
        double d17 = matrix.m41;
        double d18 = -((d14 - ((d16 - (d17 * d5)) * d7)) + (((d15 * d4) - (d17 * d2)) * d11));
        double d19 = ((((d8 * d3) - (d10 * d5)) * d13) - (((d15 * d3) - (d17 * d5)) * d)) + (((d15 * d10) - (d17 * d8)) * d11);
        double d20 = -((((((d8 * d4) - d10) - d2) * d13) - (((d15 * d4) - (d17 * d2)) * d)) + (((d15 * d10) - (d17 * d8)) * d7));
        double d21 = matrix.m12;
        double d22 = matrix.m13;
        double d23 = matrix.m14;
        double d24 = (((((d2 * d3) - d4) - d5) * d21) - (((d8 * d3) - (d10 * d5)) * d22)) + (((d8 * d4) - (d10 * d2)) * d23);
        double d25 = matrix.m11;
        double d26 = -(((((d2 * d3) - (d4 * d5)) * d25) - (((d15 * d3) - (d17 * d5)) * d22)) + (((d15 * d4) - (d17 * d2)) * d23));
        double d27 = ((((d8 * d3) - (d10 * d5)) * d25) - (((d15 * d3) - (d17 * d5)) * d21)) + (((d15 * d10) - (d17 * d8)) * d23);
        double d28 = -(((((d8 * d4) - (d10 * d2)) * d25) - (((d15 * d4) - (d17 * d2)) * d21)) + (((d15 * d10) - (d17 * d8)) * d22));
        double d29 = ((((d7 * d3) - (d4 * d11)) * d21) - (((d * d3) - (d10 * d11)) * d22)) + (((d * d4) - (d10 * d7)) * d23);
        double d30 = -(((((d7 * d3) - (d4 * d11)) * d25) - (((d13 * d3) - (d17 * d11)) * d22)) + (((d4 * d11) - (d17 * d7)) * d23));
        double d31 = ((((d * d3) - (d10 * d11)) * d25) - (((d3 * d13) - (d17 * d11)) * d21)) + (((d13 * d10) - (d17 * d)) * d23);
        double d32 = -(((((d * d2) - (d8 * d7)) * d25) - (((d13 * d2) - (d15 * d7)) * d21)) + (((d13 * d8) - (d15 * d)) * d22));
        double d33 = ((((d7 * d5) - (d2 * d11)) * d21) - (((d * d5) - (d8 * d11)) * d22)) + (((d * d2) - (d8 * d7)) * d23);
        double d34 = -(((((d7 * d5) - (d2 * d11)) * d25) - (((d13 * d5) - (d15 * d11)) * d22)) + (((d13 * d2) - (d15 * d7)) * d23));
        double d35 = ((((d * d5) - (d8 * d11)) * d25) - (((d5 * d13) - (d11 * d15)) * d21)) + (((d13 * d8) - (d15 * d)) * d23);
        double d36 = -(((((d * d2) - (d8 * d7)) * d25) - (d21 * ((d2 * d13) - (d7 * d15)))) + (d22 * ((d13 * d8) - (d15 * d))));
        double d37 = (d25 * d12) + (d21 * d18) + (d22 * d19) + (d23 * d20);
        if (isZero(d37)) {
            return null;
        }
        return new Matrix(d12 / d37, d24 / d37, d29 / d37, d33 / d37, d18 / d37, d26 / d37, d30 / d37, d34 / d37, d19 / d37, d27 / d37, d31 / d37, d35 / d37, d20 / d37, d28 / d37, d32 / d37, d36 / d37);
    }

    private static Matrix computeTransformInverse(Matrix matrix) {
        double d = matrix.m11;
        double d2 = matrix.m21;
        double d3 = matrix.m31;
        double d4 = matrix.m14;
        double d5 = 0.0d - (d * d4);
        double d6 = matrix.m24;
        double d7 = d5 - (d2 * d6);
        double d8 = matrix.m34;
        double d9 = d7 - (d3 * d8);
        double d10 = matrix.m12;
        double d11 = matrix.m22;
        double d12 = matrix.m32;
        double d13 = ((0.0d - (d10 * d4)) - (d11 * d6)) - (d12 * d8);
        double d14 = matrix.m13;
        double d15 = matrix.m23;
        double d16 = matrix.m33;
        return new Matrix(d, d2, d3, d9, d10, d11, d12, d13, d14, d15, d16, ((0.0d - (d14 * d4)) - (d15 * d6)) - (d16 * d8), 0.0d, 0.0d, 0.0d, 1.0d, false);
    }

    public final Angle getRotationX() {
        double cos = Math.cos(Math.asin(this.m13));
        if (isZero(cos)) {
            return null;
        }
        double atan2 = Math.abs(cos) > 0.005d ? Math.atan2((-this.m23) / cos, this.m33 / cos) : 0.0d;
        if (Double.isNaN(atan2)) {
            return null;
        }
        return Angle.fromRadians(atan2);
    }

    public final Angle getRotationY() {
        double asin = Math.asin(this.m13);
        if (Double.isNaN(asin)) {
            return null;
        }
        return Angle.fromRadians(asin);
    }

    public final Angle getRotationZ() {
        double atan2;
        double cos = Math.cos(Math.asin(this.m13));
        if (isZero(cos)) {
            return null;
        }
        if (Math.abs(cos) > 0.005d) {
            atan2 = Math.atan2((-this.m12) / cos, this.m11 / cos);
        } else {
            atan2 = Math.atan2(this.m21, this.m22);
        }
        if (Double.isNaN(atan2)) {
            return null;
        }
        return Angle.fromRadians(atan2);
    }

    public final Vec4 getTranslation() {
        return new Vec4(this.m14, this.m24, this.m34);
    }

    private static boolean isZero(double d) {
        return POSITIVE_ZERO.compareTo(Double.valueOf(d)) == 0 || NEGATIVE_ZERO.compareTo(Double.valueOf(d)) == 0;
    }
}
