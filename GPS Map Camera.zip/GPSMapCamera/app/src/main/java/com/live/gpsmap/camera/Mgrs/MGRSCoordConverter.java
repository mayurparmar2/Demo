package com.live.gpsmap.camera.Mgrs;


/* loaded from: classes3.dex */
class MGRSCoordConverter {
    private static final String BESSEL_1841 = "BR";
    private static final String BESSEL_1841_NAMIBIA = "BN";
    private static final String CLARKE_1866 = "CC";
    private static final String CLARKE_1880 = "CD";
    public static final double DEG_TO_RAD = 0.017453292519943295d;
    private static final int LETTER_A = 0;
    private static final int LETTER_B = 1;
    private static final int LETTER_C = 2;
    private static final int LETTER_D = 3;
    private static final int LETTER_E = 4;
    private static final int LETTER_F = 5;
    private static final int LETTER_G = 6;
    private static final int LETTER_H = 7;
    private static final int LETTER_I = 8;
    private static final int LETTER_J = 9;
    private static final int LETTER_K = 10;
    private static final int LETTER_L = 11;
    private static final int LETTER_M = 12;
    private static final int LETTER_N = 13;
    private static final int LETTER_O = 14;
    private static final int LETTER_P = 15;
    private static final int LETTER_Q = 16;
    private static final int LETTER_R = 17;
    private static final int LETTER_S = 18;
    private static final int LETTER_T = 19;
    private static final int LETTER_U = 20;
    private static final int LETTER_V = 21;
    private static final int LETTER_W = 22;
    private static final int LETTER_X = 23;
    private static final int LETTER_Y = 24;
    private static final int LETTER_Z = 25;
    private static final int MAX_PRECISION = 5;
    private static final double MAX_UTM_LAT = 1.4660765716752369d;
    private static final int MGRS_A_ERROR = 16;
    private static final int MGRS_EASTING_ERROR = 64;
    private static final int MGRS_HEMISPHERE_ERROR = 512;
    private static final int MGRS_INV_F_ERROR = 32;
    private static final int MGRS_LAT_ERROR = 1;
    private static final int MGRS_LAT_WARNING = 1024;
    private static final int MGRS_LETTERS = 3;
    private static final int MGRS_LON_ERROR = 2;
    private static final int MGRS_NORTHING_ERROR = 128;
    private static final int MGRS_NOZONE_WARNING = 2048;
    public static final int MGRS_NO_ERROR = 0;
    private static final int MGRS_PRECISION_ERROR = 8;
    public static final int MGRS_STRING_ERROR = 4;
    private static final int MGRS_UPS_ERROR = 8192;
    private static final int MGRS_UTM_ERROR = 4096;
    private static final int MGRS_ZONE_ERROR = 256;
    private static final double MIN_EAST_NORTH = 0.0d;
    private static final double MIN_UTM_LAT = -1.3962634015954636d;
    private static final double ONEHT = 100000.0d;
    private static final double PI = 3.141592653589793d;
    private static final double PI_OVER_2 = 1.5707963267948966d;
    private static final double RAD_TO_DEG = 57.29577951308232d;
    private static final String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private double false_northing;
    private long lastLetter;
    private double latitude;
    private double longitude;
    private long ltr2_high_value;
    private long ltr2_low_value;
    private double min_northing;
    private double north;
    private double northing_offset;
    private double south;
    private static final long[][] upsConstants = {new long[]{0, 9, 25, 25, 800000, 800000}, new long[]{1, 0, 17, 25, 2000000, 800000}, new long[]{24, 9, 25, 15, 800000, 1300000}, new long[]{25, 0, 9, 15, 2000000, 1300000}};
    private static final double TWOMIL = 2000000.0d;
    private static final double MAX_EAST_NORTH = 4000000.0d;
    private static final double[][] latitudeBandConstants = {new double[]{2.0d, 1100000.0d, -72.0d, -80.5d, 0.0d}, new double[]{3.0d, TWOMIL, -64.0d, -72.0d, TWOMIL}, new double[]{4.0d, 2800000.0d, -56.0d, -64.0d, TWOMIL}, new double[]{5.0d, 3700000.0d, -48.0d, -56.0d, TWOMIL}, new double[]{6.0d, 4600000.0d, -40.0d, -48.0d, MAX_EAST_NORTH}, new double[]{7.0d, 5500000.0d, -32.0d, -40.0d, MAX_EAST_NORTH}, new double[]{9.0d, 6400000.0d, -24.0d, -32.0d, 6000000.0d}, new double[]{10.0d, 7300000.0d, -16.0d, -24.0d, 6000000.0d}, new double[]{11.0d, 8200000.0d, -8.0d, -16.0d, 8000000.0d}, new double[]{12.0d, 9100000.0d, 0.0d, -8.0d, 8000000.0d}, new double[]{13.0d, 0.0d, 8.0d, 0.0d, 0.0d}, new double[]{15.0d, 800000.0d, 16.0d, 8.0d, 0.0d}, new double[]{16.0d, 1700000.0d, 24.0d, 16.0d, 0.0d}, new double[]{17.0d, 2600000.0d, 32.0d, 24.0d, TWOMIL}, new double[]{18.0d, 3500000.0d, 40.0d, 32.0d, TWOMIL}, new double[]{19.0d, 4400000.0d, 48.0d, 40.0d, MAX_EAST_NORTH}, new double[]{20.0d, 5300000.0d, 56.0d, 48.0d, MAX_EAST_NORTH}, new double[]{21.0d, 6200000.0d, 64.0d, 56.0d, 6000000.0d}, new double[]{22.0d, 7000000.0d, 72.0d, 64.0d, 6000000.0d}, new double[]{23.0d, 7900000.0d, 84.5d, 72.0d, 6000000.0d}};
    private double MGRS_a = 6378137.0d;
    private double MGRS_f = 0.0033528106647474805d;
    private String MGRS_Ellipsoid_Code = "WE";
    private String MGRSString = "";
    private long last_error = 0;

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes2.dex */
    public class MGRSComponents {
        private final double easting;
        private final int latitudeBand;
        private final double northing;
        private final int precision;
        private final int squareLetter1;
        private final int squareLetter2;
        private final int zone;

        public MGRSComponents(int v, int i, int i2, int i3, int i4, double d, double d2, int i5) {
            this.zone = i;
            this.latitudeBand = i2;
            this.squareLetter1 = i3;
            this.squareLetter2 = i4;
            this.easting = d;
            this.northing = d2;
            this.precision = i5;
        }

        public String toString() {
            return "MGRS: " + this.zone + " " + MGRSCoordConverter.alphabet.charAt(this.latitudeBand) + " " + MGRSCoordConverter.alphabet.charAt(this.squareLetter1) + MGRSCoordConverter.alphabet.charAt(this.squareLetter2) + " " + this.easting + " " + this.northing + " (" + this.precision + ")";
        }
    }

    public long setMGRSParameters(double d, double d2, String str) {
        if (d <= 0.0d) {
            return 16L;
        }
        if (d2 == 0.0d) {
            return 32L;
        }
        double d3 = 1.0d / d2;
        if (d3 < 250.0d || d3 > 350.0d) {
            return 32L;
        }
        this.MGRS_a = d;
        this.MGRS_f = d2;
        this.MGRS_Ellipsoid_Code = str;
        return 0L;
    }

    public double getMGRS_f() {
        return this.MGRS_f;
    }

    public double getMGRS_a() {
        return this.MGRS_a;
    }

    private long getLastLetter() {
        return this.lastLetter;
    }

    public String getMGRS_Ellipsoid_Code() {
        return this.MGRS_Ellipsoid_Code;
    }

    public long convertMGRSToGeodetic(String str) {
        this.latitude = 0.0d;
        this.longitude = 0.0d;
        long checkZone = checkZone(str);
        if (checkZone == 0) {
            UTMCoord convertMGRSToUTM = convertMGRSToUTM(str);
            if (convertMGRSToUTM != null) {
                this.latitude = convertMGRSToUTM.getLatitude().radians;
                this.longitude = convertMGRSToUTM.getLongitude().radians;
                return checkZone;
            }
            return 4096;
        } else if (checkZone == 2048) {
            UPSCoord convertMGRSToUPS = convertMGRSToUPS(str);
            if (convertMGRSToUPS != null) {
                this.latitude = convertMGRSToUPS.getLatitude().radians;
                this.longitude = convertMGRSToUPS.getLongitude().radians;
                return checkZone;
            }
            return 8192;
        } else {
            return checkZone;
        }
    }

    public double getLatitude() {
        return this.latitude;
    }

    public double getLongitude() {
        return this.longitude;
    }

    private MGRSComponents breakMGRSString(String s) {
        long v18;
        int v17;
        MGRSCoordConverter mGRSCoordConverter0;
        long v16;
        long v15;
        long v14;
        long v5;
        int v4;
        int[] arr_v = new int[3];
        int v;
        for(v = 0; v < s.length() && s.charAt(v) == 0x20; ++v) {
        }

        int v1;
        for(v1 = v; v1 < s.length() && (Character.isDigit(((char)s.charAt(v1)))); ++v1) {
        }

        int v2 = v1 - v;
        if(v2 > 2) {
            v5 = 0L;
            v4 = 0;
        }
        else if(v2 > 0) {
            int v3 = Integer.parseInt(s.substring(v, v1));
            if(v3 >= 1 && v3 <= 60) {
                v4 = v3;
                v5 = 0L;
            }
            else {
                v4 = v3;
                v5 = 4L;
            }
        }
        else {
            v5 = 4L;
            v4 = 0;
        }

        int v6;
        for(v6 = v1; v6 < s.length() && (Character.isLetter(((char)s.charAt(v6)))); ++v6) {
        }

        if(v6 - v1 == 3) {
            int v7 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(Character.toUpperCase(((char)s.charAt(v1))));
            arr_v[0] = v7;
            if(v7 == 8 || v7 == 14) {
                v5 |= 4L;
            }

            int v8 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(Character.toUpperCase(((char)s.charAt(v1 + 1))));
            arr_v[1] = v8;
            if(v8 == 8 || v8 == 14) {
                v5 |= 4L;
            }

            int v9 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(Character.toUpperCase(((char)s.charAt(v1 + 2))));
            arr_v[2] = v9;
            if(v9 == 8 || v9 == 14) {
                v5 |= 4L;
            }
        }
        else {
            v5 |= 4L;
        }

        int v10;
        for(v10 = v6; v10 < s.length() && (Character.isDigit(((char)s.charAt(v10)))); ++v10) {
        }

        int v11 = v10 - v6;
        if(v11 <= 10 && v11 % 2 == 0) {
            int v12 = v11 / 2;
            if(v12 > 0) {
                int v13 = v6 + v12;
                v14 = v5;
                double f = Math.pow(10.0, 5 - v12);
                v15 = (long)(((double)(((long)Integer.parseInt(s.substring(v6, v13))))) * f);
                v16 = (long)(((double)(((long)Integer.parseInt(s.substring(v13, v13 + v12))))) * f);
            }
            else {
                v14 = v5;
                v15 = 0L;
                v16 = 0L;
            }

            mGRSCoordConverter0 = this;
            v17 = v12;
            v18 = v14;
        }
        else {
            v18 = v5 | 4L;
            v15 = 0L;
            v16 = 0L;
            v17 = 0;
            mGRSCoordConverter0 = this;
        }

        mGRSCoordConverter0.last_error = v18;
        return v18 == 0L ? new MGRSComponents(v, v4, arr_v[0], arr_v[1], arr_v[2], ((double)v15), ((double)v16), v17) : null;
    }

    private long checkZone(String str) {
        int i = 0;
        while (i < str.length() && str.charAt(i) == ' ') {
            i++;
        }
        int i2 = i;
        while (i2 < str.length() && Character.isDigit(str.charAt(i2))) {
            i2++;
        }
        int i3 = i2 - i;
        if (i3 > 2) {
            return 4L;
        }
        if (i3 <= 0) {
            return 2048;
        }
        return 0L;
    }

    private long getLatitudeBandMinNorthing(int i) {
        if (i >= 2 && i <= 7) {
            double[] dArr = latitudeBandConstants[i - 2];
            this.min_northing = dArr[1];
            this.northing_offset = dArr[4];
        } else if (i >= 9 && i <= 13) {
            double[] dArr2 = latitudeBandConstants[i - 3];
            this.min_northing = dArr2[1];
            this.northing_offset = dArr2[4];
        } else if (i < 15 || i > 23) {
            return 4L;
        } else {
            double[] dArr3 = latitudeBandConstants[i - 4];
            this.min_northing = dArr3[1];
            this.northing_offset = dArr3[4];
        }
        return 0L;
    }

    private long getLatitudeRange(int i) {
        if (i >= 2 && i <= 7) {
            double[] dArr = latitudeBandConstants[i - 2];
            this.north = dArr[2] * 0.017453292519943295d;
            this.south = dArr[3] * 0.017453292519943295d;
        } else if (i >= 9 && i <= 13) {
            double[] dArr2 = latitudeBandConstants[i - 3];
            this.north = dArr2[2] * 0.017453292519943295d;
            this.south = dArr2[3] * 0.017453292519943295d;
        } else if (i < 15 || i > 23) {
            return 4L;
        } else {
            double[] dArr3 = latitudeBandConstants[i - 4];
            this.north = dArr3[2] * 0.017453292519943295d;
            this.south = dArr3[3] * 0.017453292519943295d;
        }
        return 0L;
    }

    /* JADX WARN: Code restructure failed: missing block: B:58:0x0112, code lost:
        if (r5 > (r19.north + r15)) goto L65;
     */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0126  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private UTMCoord convertMGRSToUTM(String str) {
        UTMCoord uTMCoord;
        double d;
        double pow;
        long latitudeRange;
        MGRSComponents breakMGRSString = breakMGRSString(str);
        long j = 4;
        if (breakMGRSString != null && (breakMGRSString.latitudeBand != 23 || (breakMGRSString.zone != 32 && breakMGRSString.zone != 34 && breakMGRSString.zone != 36))) {
            String str2 = breakMGRSString.latitudeBand < 13 ? AVKey.SOUTH : AVKey.NORTH;
            getGridValues(breakMGRSString.zone);
            if (breakMGRSString.squareLetter1 >= this.ltr2_low_value && breakMGRSString.squareLetter1 <= this.ltr2_high_value && breakMGRSString.squareLetter2 <= 21) {
                j = 0;
            }
            if (j == 0) {
                double d2 = breakMGRSString.squareLetter2 * ONEHT;
                long j2 = this.ltr2_low_value;
                double d3 = ((breakMGRSString.squareLetter1 - j2) + 1) * ONEHT;
                if (j2 == 9 && breakMGRSString.squareLetter1 > 14) {
                    d3 -= ONEHT;
                }
                if (breakMGRSString.squareLetter2 > 14) {
                    d2 -= ONEHT;
                }
                if (breakMGRSString.squareLetter2 > 8) {
                    d2 -= ONEHT;
                }
                if (d2 >= TWOMIL) {
                    d2 -= TWOMIL;
                }
                long latitudeBandMinNorthing = getLatitudeBandMinNorthing(breakMGRSString.latitudeBand);
                if (latitudeBandMinNorthing == 0) {
                    double d4 = d2 - this.false_northing;
                    if (d4 < 0.0d) {
                        d4 += TWOMIL;
                    }
                    double d5 = d4 + this.northing_offset;
                    if (d5 < this.min_northing) {
                        d5 += TWOMIL;
                    }
                    try {
                        uTMCoord = UTMCoord.fromUTM(breakMGRSString.zone, str2, d3 + breakMGRSString.easting, d5 + breakMGRSString.northing);
                    } catch (Exception unused) {
                        uTMCoord = null;
                    }
                    try {
                        d = uTMCoord.getLatitude().radians;
                        pow = Math.pow(10.0d, breakMGRSString.precision);
                        latitudeRange = getLatitudeRange(breakMGRSString.latitudeBand);
                    } catch (Exception unused2) {
                        j = 4096;
                        this.last_error = j;
                        if (j != 0) {
                        }
                        return uTMCoord;
                    }
                    if (latitudeRange == 0) {
                        double d6 = 0.017453292519943295d / pow;
                        if (this.south - d6 <= d) {
                        }
                        j = latitudeRange | 1024;
                        this.last_error = j;
                        if (j != 0 || j == 1024) {
                            return uTMCoord;
                        }
                        return null;
                    }
                    j = latitudeRange;
                    this.last_error = j;
                    if (j != 0) {
                    }
                    return uTMCoord;
                }
                j = latitudeBandMinNorthing;
            }
        }
        uTMCoord = null;
        this.last_error = j;
        if (j != 0) {
        }
        return uTMCoord;
    }


    public long convertGeodeticToMGRS(double f, double f1, int v) {
        this.MGRSString = "";
        long v1 = f < -1.570796 || f > 1.570796 ? 1L : 0L;
        if(f1 < -3.141593 || f1 > 6.283185) {
            v1 = 2L;
        }

        if(v < 0 || v > 5) {
            v1 = 8L;
        }

        long v2 = v1;
        if(v2 == 0L) {
            if(f < -1.396263 || f > 1.466077) {
//                goto label_60;
                UPSCoord uPSCoord0 = UPSCoord.fromLatLon(Angle.fromRadians(f), Angle.fromRadians(f1));
                return v2 | this.convertUPSToMGRS(uPSCoord0.getHemisphere(), Double.valueOf(uPSCoord0.getEasting()), Double.valueOf(uPSCoord0.getNorthing()), ((long)v));
            }

            try {
                UTMCoord uTMCoord0 = UTMCoord.fromLatLon(Angle.fromRadians(f), Angle.fromRadians(f1));
                return v2 | this.convertUTMToMGRS(((long)uTMCoord0.getZone()), f, uTMCoord0.getEasting(), uTMCoord0.getNorthing(), ((long)v));
            }
            catch(Exception unused_ex) {
                return 0x1000L;
            }

//            try {
//                label_60:
//                UPSCoord uPSCoord0 = UPSCoord.fromLatLon(Angle.fromRadians(f), Angle.fromRadians(f1));
//                return v2 | this.convertUPSToMGRS(uPSCoord0.getHemisphere(), Double.valueOf(uPSCoord0.getEasting()), Double.valueOf(uPSCoord0.getNorthing()), ((long)v));
//            }
//            catch(Exception unused_ex) {
//                return 0x2000L;
//            }
        }

        return v2;
    }

//    public long convertGeodeticToMGRS(double d, double d2, int i) {
//        long convertUPSToMGRS;
//        this.MGRSString = "";
//        long j = (d < -1.5707963267948966d || d > 1.5707963267948966d) ? 1L : 0L;
//        j = (d2 < -3.141592653589793d || d2 > 6.283185307179586d) ? 2L : 2L;
//        long j2 = (i < 0 || i > 5) ? 8L : 8L;
//        if (j2 == 0) {
//            if (d < MIN_UTM_LAT || d > MAX_UTM_LAT) {
//                try {
//                    UPSCoord fromLatLon = UPSCoord.fromLatLon(Angle.fromRadians(d), Angle.fromRadians(d2));
//                    convertUPSToMGRS = convertUPSToMGRS(fromLatLon.getHemisphere(), Double.valueOf(fromLatLon.getEasting()), Double.valueOf(fromLatLon.getNorthing()), i);
//                } catch (Exception unused) {
//                    return 8192;
//                }
//            } else {
//                try {
//                    UTMCoord fromLatLon2 = UTMCoord.fromLatLon(Angle.fromRadians(d), Angle.fromRadians(d2));
//                    convertUPSToMGRS = convertUTMToMGRS(fromLatLon2.getZone(), d, fromLatLon2.getEasting(), fromLatLon2.getNorthing(), i);
//                } catch (Exception unused2) {
//                    return 4096;
//                }
//            }
//            return j2 | convertUPSToMGRS;
//        }
//        return j2;
//    }



    public String getMGRSString() {
        return this.MGRSString;
    }

    private long convertUPSToMGRS(String str, Double d, Double d2, long j) {
        double d3;
        double d4;
        int i;
        long[] jArr = new long[3];
        long j2 = (AVKey.NORTH.equals(str) || AVKey.SOUTH.equals(str)) ? 0L : 512L;
        if (d.doubleValue() < 0.0d || d.doubleValue() > MAX_EAST_NORTH) {
            j2 |= 64;
        }
        if (d2.doubleValue() < 0.0d || d2.doubleValue() > MAX_EAST_NORTH) {
            j2 |= 128;
        }
        if (j < 0 || j > 5) {
            j2 |= 8;
        }
        long j3 = j2;
        if (j3 == 0) {
            double pow = Math.pow(10.0d, 5 - j);
            Double valueOf = Double.valueOf(roundMGRS(d.doubleValue() / pow) * pow);
            Double valueOf2 = Double.valueOf(roundMGRS(d2.doubleValue() / pow) * pow);
            if (AVKey.NORTH.equals(str)) {
                if (valueOf.doubleValue() >= TWOMIL) {
                    jArr[0] = 25;
                } else {
                    jArr[0] = 24;
                }
                long[] jArr2 = upsConstants[((int) jArr[0]) - 22];
                i = (int) jArr2[1];
                d3 = jArr2[4];
                d4 = jArr2[5];
            } else {
                if (valueOf.doubleValue() >= TWOMIL) {
                    jArr[0] = 1;
                } else {
                    jArr[0] = 0;
                }
                long[][] jArr3 = upsConstants;
                long j4 = jArr[0];
                int i2 = (int) jArr3[(int) j4][1];
                d3 = jArr3[(int) j4][4];
                d4 = jArr3[(int) j4][5];
                i = i2;
            }
            long doubleValue = (int) ((valueOf2.doubleValue() - d4) / ONEHT);
            jArr[2] = doubleValue;
            if (doubleValue > 7) {
                jArr[2] = doubleValue + 1;
            }
            long j5 = jArr[2];
            if (j5 > 13) {
                jArr[2] = j5 + 1;
            }
            jArr[1] = i + ((int) ((valueOf.doubleValue() - d3) / ONEHT));
            if (valueOf.doubleValue() < TWOMIL) {
                long j6 = jArr[1];
                if (j6 > 11) {
                    jArr[1] = j6 + 3;
                }
                long j7 = jArr[1];
                if (j7 > 20) {
                    jArr[1] = j7 + 2;
                }
            } else {
                long j8 = jArr[1];
                if (j8 > 2) {
                    jArr[1] = j8 + 2;
                }
                long j9 = jArr[1];
                if (j9 > 7) {
                    jArr[1] = j9 + 1;
                }
                long j10 = jArr[1];
                if (j10 > 11) {
                    jArr[1] = j10 + 3;
                }
            }
            makeMGRSString(0L, jArr, valueOf.doubleValue(), valueOf2.doubleValue(), j);
        }
        return j3;
    }

    private long convertUTMToMGRS(long v, double f, double f1, double f2, long v1) {
        long[] arr_v = new long[3];
        double f3 = Math.pow(10.0, 5L - v1);
        double f4 = this.roundMGRS(f1 / f3) * f3;
        double f5 = this.roundMGRS(f2 / f3) * f3;
        this.getGridValues(v);
        long v2 = this.getLatitudeLetter(f);
        arr_v[0] = this.getLastLetter();
        if(v2 == 0L) {
            double f6;
            for(f6 = f5 == 10000000.0 ? f5 - 1.0 : f5; f6 >= 2000000.0; f6 -= 2000000.0) {
            }

            double f7 = f6 + this.false_northing;
            long v3 = (long)((f7 < 2000000.0 ? f6 + this.false_northing : f7 - 2000000.0) / 100000.0);
            arr_v[2] = v3;
            if(v3 > 7L) {
                arr_v[2] = v3 + 1L;
            }

            long v4 = arr_v[2];
            if(v4 > 13L) {
                arr_v[2] = v4 + 1L;
            }

            long v5 = ((long)((arr_v[0] != 21L || v != 0x1FL || f4 != 500000.0 ? f4 : f4 - 1.0) / 100000.0)) - 1L + this.ltr2_low_value;
            arr_v[1] = v5;
            if(this.ltr2_low_value == 9L && v5 > 13L) {
                arr_v[1] = v5 + 1L;
            }

            this.makeMGRSString(v, arr_v, f4, f5, v1);
        }

        return v2;
    }
//    private long convertUTMToMGRS(long j, double d, double d2, double d3, long j2) {
//        long[] jArr = new long[3];
//        double pow = Math.pow(10.0d, 5 - j2);
//        double roundMGRS = roundMGRS(d2 / pow) * pow;
//        double roundMGRS2 = roundMGRS(d3 / pow) * pow;
//        getGridValues(j);
//        long latitudeLetter = getLatitudeLetter(d);
//        jArr[0] = getLastLetter();
//        if (latitudeLetter == 0) {
//            double d4 = roundMGRS2 == 1.0E7d ? roundMGRS2 - 1.0d : roundMGRS2;
//            while (d4 >= TWOMIL) {
//                d4 -= TWOMIL;
//            }
//            double d5 = d4 + this.false_northing;
//            if (d5 >= TWOMIL) {
//                d5 -= TWOMIL;
//            }
//            long j3 = (long) (d5 / ONEHT);
//            jArr[2] = j3;
//            if (j3 > 7) {
//                jArr[2] = j3 + 1;
//            }
//            long j4 = jArr[2];
//            if (j4 > 13) {
//                jArr[2] = j4 + 1;
//            }
//            double d6 = (jArr[0] == 21 && j == 31 && roundMGRS == 500000.0d) ? roundMGRS - 1.0d : roundMGRS;
//            long j5 = this.ltr2_low_value;
//            long j6 = (((long) (d6 / ONEHT)) - 1) + j5;
//            jArr[1] = j6;
//            if (j5 == 9 && j6 > 13) {
//                jArr[1] = j6 + 1;
//            }
//            makeMGRSString(j, jArr, roundMGRS, roundMGRS2, j2);
//        }
//        return latitudeLetter;
//    }

    private void getGridValues(long j) {
        long j2 = j % 6;
        if (j2 == 0) {
            j2 = 6;
        }
        long j3 = (this.MGRS_Ellipsoid_Code.compareTo(CLARKE_1866) == 0 || this.MGRS_Ellipsoid_Code.compareTo(CLARKE_1880) == 0 || this.MGRS_Ellipsoid_Code.compareTo(BESSEL_1841) == 0 || this.MGRS_Ellipsoid_Code.compareTo(BESSEL_1841_NAMIBIA) == 0) ? 0L : 1L;
        if (j2 == 1 || j2 == 4) {
            this.ltr2_low_value = 0L;
            this.ltr2_high_value = 7L;
        } else if (j2 == 2 || j2 == 5) {
            this.ltr2_low_value = 9L;
            this.ltr2_high_value = 17L;
        } else if (j2 == 3 || j2 == 6) {
            this.ltr2_low_value = 18L;
            this.ltr2_high_value = 25L;
        }
        if (j3 == 1) {
            if (j2 % 2 == 0) {
                this.false_northing = 500000.0d;
            } else {
                this.false_northing = 0.0d;
            }
        } else if (j2 % 2 == 0) {
            this.false_northing = 1500000.0d;
        } else {
            this.false_northing = 1000000.0d;
        }
    }

    private long getLatitudeLetter(double d) {
        double d2 = RAD_TO_DEG * d;
        if (d2 >= 72.0d && d2 < 84.5d) {
            this.lastLetter = 23L;
        } else if (d2 <= -80.5d || d2 >= 72.0d) {
            return 1L;
        } else {
            this.lastLetter = (long) latitudeBandConstants[(int) (((d + 1.3962634015954636d) / 0.13962634015954636d) + 1.0E-12d)][0];
        }
        return 0L;
    }

    private double roundMGRS(double d) {
        double floor = Math.floor(d);
        double d2 = d - floor;
        long j = (long) floor;
        int i = (d2 > 0.5d ? 1 : (d2 == 0.5d ? 0 : -1));
        if (i > 0 || (i == 0 && j % 2 == 1)) {
            j++;
        }
        return j;
    }

    private long makeMGRSString(long j, long[] jArr, double d, double d2, long j2) {
        double d3 = 0;
        String str;
        if (j != 0) {
            this.MGRSString = String.format("%02d", Long.valueOf(j));
        } else {
            this.MGRSString = "  ";
        }
        for (int i = 0; i < 3; i++) {
            long j3 = jArr[i];
            if (j3 < 0 || j3 > 26) {
                return 256L;
            }
            this.MGRSString += alphabet.charAt((int) jArr[i]);
        }
        double pow = Math.pow(10.0d, 5 - j2);
        double d4 = d % ONEHT;
        if (d4 >= 99999.5d) {
            d4 = 99999.0d;
        }
        String num = Integer.valueOf((int) (d4 / pow)).toString();
        if (num.length() > j2) {
            num = num.substring(0, ((int) j2) - 1);
        } else {
            int length = num.length();
            for (int i2 = 0; i2 < j2 - length; i2++) {
                num = "0" + num;
            }
        }
        this.MGRSString += " " + num;
        String num2 = Integer.valueOf((int) ((d2 % ONEHT >= 99999.5d ? 99999.0d : d3) / pow)).toString();
        if (num2.length() > j2) {
            str = num2.substring(0, ((int) j2) - 1);
        } else {
            int length2 = num2.length();
            for (int i3 = 0; i3 < j2 - length2; i3++) {
                num2 = "0" + num2;
            }
            str = num2;
        }
        this.MGRSString += " " + str;
        return 0L;
    }

    public long getError() {
        return this.last_error;
    }

    private UPSCoord convertMGRSToUPS(String str) {
        long j;
        long j2;
        long j3;
        double d;
        String str2;
        double d2;
        long j4;
        long j5;
        MGRSComponents breakMGRSString = breakMGRSString(str);
        long j6 = breakMGRSString == null ? this.last_error : 0L;
        if (breakMGRSString != null && breakMGRSString.zone > 0) {
            j6 |= 4;
        }
        if (j6 == 0) {
            double d3 = breakMGRSString.easting;
            double d4 = breakMGRSString.northing;
            if (breakMGRSString.latitudeBand >= 24) {
                long[] jArr = upsConstants[breakMGRSString.latitudeBand - 22];
                j = jArr[1];
                j2 = jArr[2];
                j3 = jArr[3];
                d2 = jArr[4];
                d = jArr[5];
                str2 = AVKey.NORTH;
            } else {
                long[][] jArr2 = upsConstants;
                j = jArr2[breakMGRSString.latitudeBand][12];
                j2 = jArr2[breakMGRSString.latitudeBand][2];
                j3 = jArr2[breakMGRSString.latitudeBand][3];
                d = jArr2[breakMGRSString.latitudeBand][5];
                str2 = AVKey.SOUTH;
                d2 = jArr2[breakMGRSString.latitudeBand][4];
            }
            if (breakMGRSString.squareLetter1 < j || breakMGRSString.squareLetter1 > j2 || breakMGRSString.squareLetter1 == 3 || breakMGRSString.squareLetter1 == 4 || breakMGRSString.squareLetter1 == 12 || breakMGRSString.squareLetter1 == 13 || breakMGRSString.squareLetter1 == 21 || breakMGRSString.squareLetter1 == 22 || breakMGRSString.squareLetter2 > j3) {
                j4 = 0;
                j5 = 4;
            } else {
                j5 = j6;
                j4 = 0;
            }
            if (j5 == j4) {
                double d5 = (breakMGRSString.squareLetter2 * ONEHT) + d;
                if (breakMGRSString.squareLetter2 > 8) {
                    d5 -= ONEHT;
                }
                if (breakMGRSString.squareLetter2 > 14) {
                    d5 -= ONEHT;
                }
                String str3 = str2;
                double d6 = ((breakMGRSString.squareLetter1 - j) * ONEHT) + d2;
                if (j != 0) {
                    if (breakMGRSString.squareLetter1 > 11) {
                        d6 -= 300000.0d;
                    }
                    if (breakMGRSString.squareLetter1 > 20) {
                        d6 -= 200000.0d;
                    }
                } else {
                    if (breakMGRSString.squareLetter1 > 2) {
                        d6 -= 200000.0d;
                    }
                    if (breakMGRSString.squareLetter1 > 8) {
                        d6 -= ONEHT;
                    }
                    if (breakMGRSString.squareLetter1 > 11) {
                        d6 -= 300000.0d;
                    }
                }
                return UPSCoord.fromUPS(str3, d6 + d3, d5 + d4);
            }
            return null;
        }
        return null;
    }
}
