package com.live.gpsmap.camera.Model;

import com.android.billingclient.api.ProductDetails;

/* loaded from: classes.dex */
public class PurchaseModel {
    private int id;
    private String pakageid;
    private ProductDetails productDetail;
    private int selected;
    private String price = "Loading...";
    private int purchased = 0;

    public PurchaseModel() {
    }

    public PurchaseModel(int i, int i2) {
        this.id = i;
        this.selected = i2;
    }

    public int getPurchased() {
        return this.purchased;
    }

    public void setPurchased(int i) {
        this.purchased = i;
    }

    public String getPakageid() {
        return pakageid; //Changed
    }

    public void setPakageid(String str) {
        this.pakageid = str;
    }

    public void setId(int i) {
        this.id = i;
    }

    public void setPrice(String str) {
        this.price = str;
    }

    public void setProductDetails(ProductDetails productDetails) {
        this.productDetail = productDetails;
    }

    public void setSelected(int i) {
        this.selected = i;
    }

    public int getId() {
        return this.id;
    }

    public String getPrice() {
        return this.price;
    }

    public int getSelected() {
        return this.selected;
    }

    public ProductDetails getProductDetails() {
        return this.productDetail;
    }
}