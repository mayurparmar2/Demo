package com.live.gpsmap.camera.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.live.gpsmap.camera.Camera.preview.Preview;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Default;
import com.live.gpsmap.camera.Utils.SP;

import java.util.ArrayList;
import java.util.Locale;

public class Filter_Adapter extends RecyclerView.Adapter<Filter_Adapter.MyViewHolder> {
    boolean isfirsttime;
    private Context mContext;
    private ArrayList<String> mFilterlist;
    SP mSP;
    String mode;
    Preview preview;
    private int[] selectedItems;

    public Filter_Adapter(Context context, ArrayList<String> arrayList, Preview preview, String str) {
        new ArrayList();
        this.isfirsttime = true;
        this.mContext = context;
        this.mFilterlist = arrayList;
        this.selectedItems = new int[arrayList.size()];
        this.preview = preview;
        this.mode = str;
        this.mSP = new SP(this.mContext);
    }

    private void initializeSeledtedItems() {
        int[] iArr;
        for (int i : this.selectedItems) {
        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_filters, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(MyViewHolder myViewHolder, @SuppressLint("RecyclerView") final int i) {
        if (this.mode.equalsIgnoreCase(SP.SCENEMODE)) {
            setSelectedItem(Default.SCENEMODE);
        } else {
            setSelectedItem(Default.WHITEBALANCE);
        }
        char c = 65535;
        if (this.selectedItems[i] == 1) {
            myViewHolder.highlightcard.setVisibility(View.VISIBLE);
            myViewHolder.highlightcard_2.setVisibility(View.GONE);
            myViewHolder.filtername.setBackgroundColor(Color.parseColor("#FFCC00"));
            myViewHolder.filtername.setTextColor(-16777216);
        } else {
            myViewHolder.highlightcard.setVisibility(View.GONE);
            myViewHolder.highlightcard_2.setVisibility(View.VISIBLE);
            myViewHolder.filtername.setBackgroundColor(Color.parseColor("#3D3D3D"));
            myViewHolder.filtername.setTextColor(-1);
        }
        if (this.mode.equalsIgnoreCase(SP.SCENEMODE)) {
            setSelectedItem(Default.SCENEMODE);
        } else {
            setSelectedItem(Default.WHITEBALANCE);
        }
        String str = this.mFilterlist.get(i);
        if (str.equalsIgnoreCase("warm-fluorescent")) {
            str = "warm";
        } else if (str.equalsIgnoreCase("cloudy-daylight")) {
            str = "cloudy";
        }
        TextView textView = myViewHolder.filtername;
        textView.setText(str.substring(0, 1).toUpperCase(Locale.ROOT) + str.substring(1));
        myViewHolder.filter_img.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.adapter.Filter_Adapter.1
            @Override
            public void onClick(View view) {
                int i2 = i;
                if (i2 != -1) {
                    Filter_Adapter.this.setSelectedItem(i2);
                    Filter_Adapter.this.notifyItemChanged(i2);
                    if (Filter_Adapter.this.mode.equalsIgnoreCase(SP.SCENEMODE)) {
                        Filter_Adapter.this.preview.setSceneModes((String) Filter_Adapter.this.mFilterlist.get(i2));
                        Default.SCENEMODE = i2;
                        Filter_Adapter.this.notifyItemChanged(Default.SCENEMODE);
                        Filter_Adapter.this.mSP.setInteger(Filter_Adapter.this.mContext, SP.SCENEMODE, Default.SCENEMODE);
                    } else {
                        Filter_Adapter.this.preview.setWhiteBalance((String) Filter_Adapter.this.mFilterlist.get(i2));
                        Default.WHITEBALANCE = i2;
                        Filter_Adapter.this.notifyItemChanged(Default.WHITEBALANCE);
                        Filter_Adapter.this.mSP.setInteger(Filter_Adapter.this.mContext, SP.WHITEBALANCE, Default.WHITEBALANCE);
                    }
                    Filter_Adapter.this.notifyDataSetChanged();
                }
            }
        });
        String trim = this.mFilterlist.get(i).trim();
        trim.hashCode();
        switch (trim.hashCode()) {
            case -1422950858:
                if (trim.equals("action")) {
                    c = 0;
                    break;
                }
                break;
            case -1350043241:
                if (trim.equals("theatre")) {
                    c = 1;
                    break;
                }
                break;
            case -939299377:
                if (trim.equals("incandescent")) {
                    c = 2;
                    break;
                }
                break;
            case -895760513:
                if (trim.equals("sports")) {
                    c = 3;
                    break;
                }
                break;
            case -891172202:
                if (trim.equals("sunset")) {
                    c = 4;
                    break;
                }
                break;
            case -719316704:
                if (trim.equals("warm-fluorescent")) {
                    c = 5;
                    break;
                }
                break;
            case -300277408:
                if (trim.equals("steadyphoto")) {
                    c = 6;
                    break;
                }
                break;
            case -264202484:
                if (trim.equals("fireworks")) {
                    c = 7;
                    break;
                }
                break;
            case 103158:
                if (trim.equals("hdr")) {
                    c = '\b';
                    break;
                }
                break;
            case 3005871:
                if (trim.equals("auto")) {
                    c = '\t';
                    break;
                }
                break;
            case 3535235:
                if (trim.equals("snow")) {
                    c = '\n';
                    break;
                }
                break;
            case 93610339:
                if (trim.equals("beach")) {
                    c = 11;
                    break;
                }
                break;
            case 104817688:
                if (trim.equals("night")) {
                    c = '\f';
                    break;
                }
                break;
            case 106437350:
                if (trim.equals("party")) {
                    c = '\r';
                    break;
                }
                break;
            case 109399597:
                if (trim.equals("shade")) {
                    c = 14;
                    break;
                }
                break;
            case 474934723:
                if (trim.equals("cloudy-daylight")) {
                    c = 15;
                    break;
                }
                break;
            case 729267099:
                if (trim.equals("portrait")) {
                    c = 16;
                    break;
                }
                break;
            case 1430647483:
                if (trim.equals("landscape")) {
                    c = 17;
                    break;
                }
                break;
            case 1650323088:
                if (trim.equals("twilight")) {
                    c = 18;
                    break;
                }
                break;
            case 1664284080:
                if (trim.equals("night-portrait")) {
                    c = 19;
                    break;
                }
                break;
            case 1900012073:
                if (trim.equals("candlelight")) {
                    c = 20;
                    break;
                }
                break;
            case 1902580840:
                if (trim.equals(/*lPqICtEPVLEI.mlBPnCOMYOrKq*/"florescent")) {//Changed
                    c = 21;
                    break;
                }
                break;
            case 1942983418:
                if (trim.equals("daylight")) {
                    c = 22;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.s_action)).into(myViewHolder.filter_img);
                return;
            case 1:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.s_theatre)).into(myViewHolder.filter_img);
                return;
            case 2:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.w_incedense)).into(myViewHolder.filter_img);
                return;
            case 3:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.s_sports)).into(myViewHolder.filter_img);
                return;
            case 4:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.s_sunset)).into(myViewHolder.filter_img);
                return;
            case 5:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.w_warm)).into(myViewHolder.filter_img);
                return;
            case 6:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.s_stedy_photo)).into(myViewHolder.filter_img);
                return;
            case 7:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.s_fireworks)).into(myViewHolder.filter_img);
                return;
            case '\b':
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.s_hdr)).into(myViewHolder.filter_img);
                return;
            case '\t':
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.w_auto)).into(myViewHolder.filter_img);
                return;
            case '\n':
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.s_snow)).into(myViewHolder.filter_img);
                return;
            case 11:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.s_beach)).into(myViewHolder.filter_img);
                return;
            case '\f':
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.s_night)).into(myViewHolder.filter_img);
                return;
            case '\r':
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.s_party)).into(myViewHolder.filter_img);
                return;
            case 14:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.w_shade)).into(myViewHolder.filter_img);
                return;
            case 15:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.w_cloudy)).into(myViewHolder.filter_img);
                return;
            case 16:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.s_potrait)).into(myViewHolder.filter_img);
                return;
            case 17:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.s_landscape)).into(myViewHolder.filter_img);
                return;
            case 18:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.w_twilight)).into(myViewHolder.filter_img);
                return;
            case 19:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.s_night_potrait)).into(myViewHolder.filter_img);
                return;
            case 20:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.s_candaline)).into(myViewHolder.filter_img);
                return;
            case 21:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.w_florescent)).into(myViewHolder.filter_img);
                return;
            case 22:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.w_daylight)).into(myViewHolder.filter_img);
                return;
            default:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.w_auto)).into(myViewHolder.filter_img);
                return;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setSelectedItem(int i) {
        int i2 = 0;
        while (true) {
            int[] iArr = this.selectedItems;
            if (i2 >= iArr.length) {
                return;
            }
            if (i2 == i) {
                iArr[i2] = 1;
            } else {
                iArr[i2] = 0;
            }
            i2++;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.mFilterlist.size();
    }

    /* loaded from: classes.dex */
    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView filter_img;
        TextView filtername;
        CardView highlightcard;
        CardView highlightcard_2;

        public MyViewHolder(View view) {
            super(view);
            this.filter_img = (ImageView) view.findViewById(R.id.filter_img);
            this.filtername = (TextView) view.findViewById(R.id.txt_filter_name);
            this.highlightcard = (CardView) view.findViewById(R.id.highlightcard);
            this.highlightcard_2 = (CardView) view.findViewById(R.id.highlightcard_2);
        }
    }
}