package com.live.gpsmap.camera.Camera;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.os.Build;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RSInvalidStateException;
import android.renderscript.RenderScript;
import android.renderscript.Script;
import android.renderscript.Type;
import android.util.Log;

import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.ItemTouchHelper;
import com.live.gpsmap.camera.Camera.Script.ScriptC_align_mtb;
import com.live.gpsmap.camera.Camera.Script.ScriptC_avg_brighten;
import com.live.gpsmap.camera.Camera.Script.ScriptC_calculate_sharpness;
import com.live.gpsmap.camera.Camera.Script.ScriptC_create_mtb;
import com.live.gpsmap.camera.Camera.Script.ScriptC_histogram_adjust;
import com.live.gpsmap.camera.Camera.Script.ScriptC_histogram_compute;
import com.live.gpsmap.camera.Camera.Script.ScriptC_process_avg;
import com.live.gpsmap.camera.Camera.Script.ScriptC_process_hdr;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@SuppressWarnings("All")
public class HDRProcessor {
    private static final String TAG = "HDRProcessor";
    public static final TonemappingAlgorithm default_tonemapping_algorithm_c = TonemappingAlgorithm.TONEMAPALGORITHM_REINHARD;
    private ScriptC_align_mtb alignMTBScript;
    private final Context context;
    private ScriptC_create_mtb createMTBScript;
    private final boolean is_test;
    private ScriptC_process_avg processAvgScript;
    private RenderScript rs;
    public int[] offsets_x = null;
    public int[] offsets_y = null;
    public int sharp_index = 0;
    private int cached_avg_sample_size = 1;


    public enum DROTonemappingAlgorithm {
        DROALGORITHM_NONE,
        DROALGORITHM_GAINGAMMA
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public enum HDRAlgorithm {
        HDRALGORITHM_STANDARD,
        HDRALGORITHM_SINGLE_IMAGE
    }

    /* loaded from: classes.dex */
    public interface SortCallback {
        void sortOrder(List<Integer> list);
    }

    /* loaded from: classes.dex */
    public enum TonemappingAlgorithm {
        TONEMAPALGORITHM_CLAMP,
        TONEMAPALGORITHM_EXPONENTIAL,
        TONEMAPALGORITHM_REINHARD,
        TONEMAPALGORITHM_FU2,
        TONEMAPALGORITHM_ACES
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public Bitmap avgBrighten(AvgData avg_data, int width, int height, int iso, long exposure_time) {
        return avgBrightenRS(avg_data.allocation_out, width, height, iso, exposure_time);
    }

    private float computeBlackLevel(HistogramInfo histogramInfo, int [] histo, int iso) {
        float black_level = 0.0f;
        {
            // quick and dirty dehaze algorithm
            // helps (among others): testAvg1 to testAvg10, testAvg27, testAvg30, testAvg31, testAvg39, testAvg40
            int total = histogramInfo.total;
            int percentile = (int)(total*0.001f);
            int count = 0;
            int darkest_brightness = -1;
            for(int i = 0; i < histo.length; i++) {
                count += histo[i];
                if( count >= percentile && darkest_brightness == -1 ) {
                    darkest_brightness = i;
                }
            }
            black_level = Math.max(black_level, darkest_brightness);
            // don't allow black_level too high for "dark" images, as this can cause problems due to exaggerating noise (e.g.,
            // see testAvg38)
            black_level = Math.min(black_level, iso <= 700 ? 18 : 4);
            if( MyDebug.LOG ) {
                Log.d(TAG, "percentile: " + percentile);
                Log.d(TAG, "darkest_brightness: " + darkest_brightness);
                Log.d(TAG, "black_level is now: " + black_level);
            }
        }
        return black_level;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private int [] computeHistogram(Allocation allocation, int width, int height, boolean avg, boolean floating_point) {
        if( MyDebug.LOG ) {
            Log.d(TAG, "computeHistogram [allocation]");
            Log.d(TAG, "avg: " + avg);
            Log.d(TAG, "floating_point: " + floating_point);
        }
        long time_s = System.currentTimeMillis();
        int [] histogram = new int[256];
        Allocation histogramAllocation = computeHistogramAllocation(allocation, avg, floating_point, time_s);
        histogramAllocation.copyTo(histogram);
        histogramAllocation.destroy();
        if( MyDebug.LOG ) {
            Log.d(TAG, "allocation size: " + width + " x " + height);
            Log.d(TAG, "### time to compute histogram: " + (System.currentTimeMillis() - time_s));
        }
        return histogram;
    }
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private Bitmap avgBrightenRS(Allocation input, int width, int height, int iso, long exposure_time) {
        if( MyDebug.LOG ) {
            Log.d(TAG, "avgBrightenRS");
            Log.d(TAG, "iso: " + iso);
            Log.d(TAG, "exposure_time: " + exposure_time);
        }
        initRenderscript();

        long time_s = System.currentTimeMillis();

        int [] histo = computeHistogram(input, width, height, false, true);
        HistogramInfo histogramInfo = getHistogramInfo(histo);
        int brightness = histogramInfo.median_brightness;
        int max_brightness = histogramInfo.max_brightness;
        if( MyDebug.LOG )
            Log.d(TAG, "### time after computeHistogram: " + (System.currentTimeMillis() - time_s));

        if( MyDebug.LOG ) {
            Log.d(TAG, "median brightness: " + histogramInfo.median_brightness);
            Log.d(TAG, "mean brightness: " + histogramInfo.mean_brightness);
            Log.d(TAG, "max brightness: " + max_brightness);
            /*for(int i=0;i<256;i++) {
                Log.d(TAG, "histogram[" + i + "]: " + histo[i]);
            }*/
        }



        BrightenFactors brighten_factors = computeBrightenFactors(true, iso, exposure_time, brightness, max_brightness);
        float gain = brighten_factors.gain;
        float low_x = brighten_factors.low_x;
        float mid_x = brighten_factors.mid_x;
        float gamma = brighten_factors.gamma;

        //float gain = brightness_target / (float)brightness;
        /*float gamma = (float)(Math.log(max_target/(float)brightness_target) / Math.log(max_brightness/(float)brightness));
        float gain = brightness_target / ((float)Math.pow(brightness/255.0f, gamma) * 255.0f);
        if( MyDebug.LOG ) {
            Log.d(TAG, "gamma " + gamma);
            Log.d(TAG, "gain " + gain);
            Log.d(TAG, "gain2 " + max_target / ((float)Math.pow(max_brightness/255.0f, gamma) * 255.0f));
        }*/
        /*float gain = brightness_target / (float)brightness;
        if( MyDebug.LOG ) {
            Log.d(TAG, "gain: " + gain);
        }
        if( gain < 1.0f ) {
            gain = 1.0f;
            if( MyDebug.LOG ) {
                Log.d(TAG, "clamped gain to : " + gain);
            }
        }*/

        float black_level = computeBlackLevel(histogramInfo, histo, iso);

        // use a lower medial filter strength for pixel binned images, so that we don't blur testAvg46 so much (especially sign text)
        float median_filter_strength = (cached_avg_sample_size >= 2) ? 0.5f : 1.0f;
        if( MyDebug.LOG )
            Log.d(TAG, "median_filter_strength: " + median_filter_strength);

        /*if( avgBrightenScript == null ) {
            avgBrightenScript = new ScriptC_avg_brighten(rs);
        }*/
        net.sourceforge.opencamera.ScriptC_avg_brighten avgBrightenScript = new net.sourceforge.opencamera.ScriptC_avg_brighten(rs);
        avgBrightenScript.set_bitmap(input);
        avgBrightenScript.invoke_setBlackLevel(black_level);

        avgBrightenScript.set_median_filter_strength(median_filter_strength);
        avgBrightenScript.invoke_setBrightenParameters(gain, gamma, low_x, mid_x, max_brightness);

        Bitmap output_bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Allocation allocation_out = Allocation.createFromBitmap(rs, output_bitmap);
        if( MyDebug.LOG )
            Log.d(TAG, "### time after creating allocation_out: " + (System.currentTimeMillis() - time_s));

        avgBrightenScript.forEach_avg_brighten_f(input, allocation_out);
        if( MyDebug.LOG )
            Log.d(TAG, "### time after avg_brighten: " + (System.currentTimeMillis() - time_s));

        //if( iso <= 150 ) {
        if( iso < 1100 && exposure_time < 1000000000L/59 ) {
            // for bright scenes, contrast enhancement helps improve the quality of images (especially where we may have both
            // dark and bright regions, e.g., testAvg12); but for dark scenes, it just blows up the noise too much
            // keep n_tiles==1 - get too much contrast enhancement with n_tiles==4 e.g. for testAvg34
            // tests that are better at 25% (median brightness in brackets): testAvg16 (90), testAvg26 (117), testAvg30 (79),
            //     testAvg43 (55), testAvg44 (82)
            // tests that are better at 50%: testAvg12 (8), testAvg13 (38), testAvg15 (10), testAvg18 (39), testAvg19 (37)
            // other tests improved by doing contrast enhancement: testAvg32, testAvg40
            //adjustHistogram(allocation_out, allocation_out, width, height, 0.5f, 4, time_s);
            //adjustHistogram(allocation_out, allocation_out, width, height, 0.25f, 4, time_s);
            //adjustHistogram(allocation_out, allocation_out, width, height, 0.25f, 1, time_s);
            //adjustHistogram(allocation_out, allocation_out, width, height, 0.5f, 1, time_s);
            final int median_lo = 60, median_hi = 35;
            float alpha = (histogramInfo.median_brightness - median_lo) / (float)(median_hi - median_lo);
            alpha = Math.max(alpha, 0.0f);
            alpha = Math.min(alpha, 1.0f);
            float amount = (1.0f-alpha) * 0.25f + alpha * 0.5f;
            if( MyDebug.LOG ) {
                Log.d(TAG, "dro alpha: " + alpha);
                Log.d(TAG, "dro amount: " + amount);
            }
            adjustHistogramRS(allocation_out, allocation_out, width, height, amount, 1, true, time_s);
            if( MyDebug.LOG )
                Log.d(TAG, "### time after adjustHistogram: " + (System.currentTimeMillis() - time_s));
        }

        allocation_out.copyTo(output_bitmap);
        allocation_out.destroy();
        if( MyDebug.LOG )
            Log.d(TAG, "### time after copying to bitmap: " + (System.currentTimeMillis() - time_s));

        freeScripts();
        if( MyDebug.LOG )
            Log.d(TAG, "### total time for avgBrighten: " + (System.currentTimeMillis() - time_s));
        return output_bitmap;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    void adjustHistogramRS(Allocation allocation_in, Allocation allocation_out, int width, int height, float hdr_alpha, int n_tiles, boolean ce_preserve_blacks, long time_s) {
        if( MyDebug.LOG )
            Log.d(TAG, "adjustHistogram [renderscript]");

        //final boolean adjust_histogram_local = false;
        final boolean adjust_histogram_local = true;

        if( adjust_histogram_local ) {
            // Contrast Limited Adaptive Histogram Equalisation (CLAHE)
            // Note we don't fully equalise the histogram, rather the resultant image is the mid-point of the non-equalised and fully-equalised images
            // See https://en.wikipedia.org/wiki/Adaptive_histogram_equalization#Contrast_Limited_AHE
            // Also see "Adaptive Histogram Equalization and its Variations" ( http://www.cs.unc.edu/Research/MIDAG/pubs/papers/Adaptive%20Histogram%20Equalization%20and%20Its%20Variations.pdf ),
            // Pizer, Amburn, Austin, Cromartie, Geselowitz, Greer, ter Haar Romeny, Zimmerman, Zuiderveld (1987).
            // Also note that if ce_preserve_blacks is true, we apply a modification to this algorithm, see below.

            if( MyDebug.LOG )
                Log.d(TAG, "time before creating histograms: " + (System.currentTimeMillis() - time_s));
            // create histograms
            Allocation histogramAllocation = Allocation.createSized(rs, Element.I32(rs), 256);
            /*if( histogramScript == null ) {
                if( MyDebug.LOG )
                    Log.d(TAG, "create histogramScript");
                histogramScript = new ScriptC_histogram_compute(rs);
            }*/
            if( MyDebug.LOG )
                Log.d(TAG, "create histogramScript");
            net.sourceforge.opencamera.ScriptC_histogram_compute histogramScript = new net.sourceforge.opencamera.ScriptC_histogram_compute(rs);
            if( MyDebug.LOG )
                Log.d(TAG, "bind histogram allocation");
            histogramScript.bind_histogram(histogramAllocation);

            //final int n_tiles_c = 8;
            //final int n_tiles_c = 4;
            //final int n_tiles_c = 1;
            int [] c_histogram = new int[n_tiles*n_tiles*256];
            int [] temp_c_histogram = new int[256];
            for(int i=0;i<n_tiles;i++) {
                double a0 = ((double)i)/(double)n_tiles;
                double a1 = ((double)i+1.0)/(double)n_tiles;
                int start_x = (int)(a0 * width);
                int stop_x = (int)(a1 * width);
                if( stop_x == start_x )
                    continue;
                for(int j=0;j<n_tiles;j++) {
                    double b0 = ((double)j)/(double)n_tiles;
                    double b1 = ((double)j+1.0)/(double)n_tiles;
                    int start_y = (int)(b0 * height);
                    int stop_y = (int)(b1 * height);
                    if( stop_y == start_y )
                        continue;
                        /*if( MyDebug.LOG )
                            Log.d(TAG, i + " , " + j + " : " + start_x + " , " + start_y + " to " + stop_x + " , " + stop_y);*/
                    Script.LaunchOptions launch_options = new Script.LaunchOptions();
                    launch_options.setX(start_x, stop_x);
                    launch_options.setY(start_y, stop_y);

                        /*if( MyDebug.LOG )
                            Log.d(TAG, "call histogramScript");*/
                    histogramScript.invoke_init_histogram();
                    // We compute a histogram based on the max RGB value, so this matches with the scaling we do in histogram_adjust.rs.
                    // This improves the look of the grass in testHDR24, testHDR27.
                    histogramScript.forEach_histogram_compute_by_value(allocation_in, launch_options);

                    int [] histogram = new int[256];
                    histogramAllocation.copyTo(histogram);

                        /*if( MyDebug.LOG ) {
                            // compare/adjust
                            allocations[0].copyTo(bm);
                            int [] debug_histogram = new int[256];
                            for(int k=0;k<256;k++) {
                                debug_histogram[k] = 0;
                            }
                            int [] debug_buffer = new int[width];
                            for(int y=start_y;y<stop_y;y++) {
                                bm.getPixels(debug_buffer, 0, width, 0, y, width, 1);
                                for(int x=start_x;x<stop_x;x++) {
                                    int color = debug_buffer[x];
                                    float r = (float)((color & 0xFF0000) >> 16);
                                    float g = (float)((color & 0xFF00) >> 8);
                                    float b = (float)(color & 0xFF);
                                    //float value = 0.299f*r + 0.587f*g + 0.114f*b; // matches ScriptIntrinsicHistogram default behaviour
                                    float value = Math.max(r, g);
                                    value = Math.max(value, b);
                                    int i_value = (int)value;
                                    i_value = Math.min(255, i_value); // just in case
                                    debug_histogram[i_value]++;
                                }
                            }
                            for(int x=0;x<256;x++) {
                                Log.d(TAG, "histogram[" + x + "] = " + histogram[x] + " debug_histogram: " + debug_histogram[x]);
                                //histogram[x] = debug_histogram[x];
                            }
                        }*/

                    clipHistogram(histogram, temp_c_histogram, (stop_x - start_x), (stop_y - start_y), ce_preserve_blacks);

                    // compute cumulative histogram
                    int histogram_offset = 256*(i*n_tiles+j);
                    c_histogram[histogram_offset] = histogram[0];
                    for(int x=1;x<256;x++) {
                        c_histogram[histogram_offset+x] = c_histogram[histogram_offset+x-1] + histogram[x];
                    }
                    /*if( MyDebug.LOG ) {
                        for(int x=0;x<256;x++) {
                            Log.d(TAG, "histogram[" + x + "] = " + histogram[x] + " cumulative: " + c_histogram[histogram_offset+x]);
                        }
                    }*/
                }
            }

            if( MyDebug.LOG )
                Log.d(TAG, "adjustHistogram: time after creating histograms: " + (System.currentTimeMillis() - time_s));

            Allocation c_histogramAllocation = Allocation.createSized(rs, Element.I32(rs), n_tiles*n_tiles*256);
            c_histogramAllocation.copyFrom(c_histogram);
            /*if( histogramAdjustScript == null ) {
                histogramAdjustScript = new ScriptC_histogram_adjust(rs);
            }*/
            net.sourceforge.opencamera.ScriptC_histogram_adjust histogramAdjustScript = new net.sourceforge.opencamera.ScriptC_histogram_adjust(rs);
            histogramAdjustScript.set_c_histogram(c_histogramAllocation);
            histogramAdjustScript.set_hdr_alpha(hdr_alpha);
            histogramAdjustScript.set_n_tiles(n_tiles);
            histogramAdjustScript.set_width(width);
            histogramAdjustScript.set_height(height);

            if( MyDebug.LOG )
                Log.d(TAG, "time before histogramAdjustScript: " + (System.currentTimeMillis() - time_s));
            histogramAdjustScript.forEach_histogram_adjust(allocation_in, allocation_out);
            if( MyDebug.LOG )
                Log.d(TAG, "time after histogramAdjustScript: " + (System.currentTimeMillis() - time_s));

            histogramAllocation.destroy();
            c_histogramAllocation.destroy();
        }
    }
    void clipHistogram(int [] histogram, int [] temp_c_histogram, int sub_width, int sub_height, boolean ce_preserve_blacks) {
        int n_pixels = sub_width * sub_height;
        int clip_limit = (5 * n_pixels) / 256;
                    /*if( MyDebug.LOG ) {
                        Log.d(TAG, "clip_limit: " + clip_limit);
                        Log.d(TAG, "    relative clip limit: " + clip_limit*256.0f/n_pixels);
                    }*/
        {
            // find real clip limit
            int bottom = 0, top = clip_limit;
            while( top - bottom > 1 ) {
                int middle = (top + bottom)/2;
                int sum = 0;
                for(int x=0;x<256;x++) {
                    if( histogram[x] > middle ) {
                        sum += (histogram[x] - clip_limit);
                    }
                }
                if( sum > (clip_limit - middle) * 256 )
                    top = middle;
                else
                    bottom = middle;
            }
            clip_limit = (top + bottom)/2;
                        /*if( MyDebug.LOG ) {
                            Log.d(TAG, "updated clip_limit: " + clip_limit);
                            Log.d(TAG, "    relative updated clip limit: " + clip_limit*256.0f/n_pixels);
                        }*/
        }
        int n_clipped = 0;
        for(int x=0;x<256;x++) {
            if( histogram[x] > clip_limit ) {
                            /*if( MyDebug.LOG ) {
                                Log.d(TAG, "    " + x + " : " + histogram[x] + " : " + (histogram[x]*256.0f/n_pixels));
                            }*/
                n_clipped += (histogram[x] - clip_limit);
                histogram[x] = clip_limit;
            }
        }
        int n_clipped_per_bucket = n_clipped / 256;
                        /*if( MyDebug.LOG ) {
                            Log.d(TAG, "n_clipped: " + n_clipped);
                            Log.d(TAG, "n_clipped_per_bucket: " + n_clipped_per_bucket);
                        }*/
        for(int x=0;x<256;x++) {
            histogram[x] += n_clipped_per_bucket;
        }

        if( ce_preserve_blacks ) {
            // This helps tests such as testHDR52, testHDR57, testAvg26, testAvg30
            // The basic idea is that we want to avoid making darker pixels darker (by too
            // much). We do this by adjusting the histogram:
            // * We can set a minimum value of each histogram value. E.g., if we set all
            //   pixels up to a certain brightness to a value equal to n_pixels/256, then
            //   we prevent those pixels from being made darker. In practice, we choose
            //   a tapered minimum, starting at (n_pixels/256) for black pixels, linearly
            //   interpolating to no minimum at brightness 128 (dark_threshold_c).
            // * For any adjusted value of the histogram, we redistribute, by reducing
            //   the histogram values of brighter pixels with values larger than (n_pixels/256),
            //   reducing them to a minimum of (n_pixels/256).
            // * Lastly, we only modify a given histogram value if pixels of that brightness
            //   would be made darker by the CLAHE algorithm. We can do this by looking at
            //   the cumulative histogram (as computed before modifying any values).
                        /*if( MyDebug.LOG ) {
                            for(int x=0;x<256;x++) {
                                Log.d(TAG, "pre-brighten histogram[" + x + "] = " + histogram[x]);
                            }
                        }*/

            temp_c_histogram[0] = histogram[0];
            for(int x=1;x<256;x++) {
                temp_c_histogram[x] = temp_c_histogram[x-1] + histogram[x];
            }

            // avoid making pixels too dark
            int equal_limit = n_pixels / 256;
            if( MyDebug.LOG )
                Log.d(TAG, "equal_limit: " + equal_limit);
            //final int dark_threshold_c = 64;
            final int dark_threshold_c = 128;
            //final int dark_threshold_c = 256;
            for(int x=0;x<dark_threshold_c;x++) {
                int c_equal_limit = equal_limit * (x+1);
                if( temp_c_histogram[x] >= c_equal_limit ) {
                    continue;
                }
                float alpha = 1.0f - ((float)x)/((float)dark_threshold_c);
                //float alpha = 1.0f - ((float)x)/256.0f;
                int limit = (int)(alpha * equal_limit);
                //int limit = equal_limit;
                if( MyDebug.LOG )
                    Log.d(TAG, "x: " + x + " ; limit: " + limit);
                            /*histogram[x] = Math.max(histogram[x], limit);
                            if( MyDebug.LOG )
                                Log.d(TAG, "    histogram pulled up to: "  + histogram[x]);*/
                if( histogram[x] < limit ) {
                    // top up by redistributing later values
                    for(int y=x+1;y<256 && histogram[x] < limit;y++) {
                        if( histogram[y] > equal_limit ) {
                            int move = histogram[y] - equal_limit;
                            move = Math.min(move, limit - histogram[x]);
                            histogram[x] += move;
                            histogram[y] -= move;
                        }
                    }
                    /*if( MyDebug.LOG )
                        Log.d(TAG, "    histogram pulled up to: "  + histogram[x]);*/
                                /*if( temp_c_histogram[x] >= c_equal_limit )
                                    throw new RuntimeException(); // test*/
                }
            }
        }
    }

    private double averageRGB(int i) {
        return ((((16711680 & i) >> 16) + ((65280 & i) >> 8)) + (i & 255)) / 3.0d;
    }

    public static boolean sceneIsLowLight(int i, long j) {
        return (i >= 1100 && ((long) i) * j >= 69000000000L) || j >= 199990000;
    }

    public HDRProcessor(Context context, boolean z) {
        this.context = context;
        this.is_test = z;
    }

    private void freeScripts() {
        Log.d(TAG, "freeScripts");
        this.processAvgScript = null;
        this.createMTBScript = null;
        this.alignMTBScript = null;
    }

    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        freeScripts();
        RenderScript renderScript = this.rs;
        if (renderScript != null) {
            try {
                renderScript.destroy();
            } catch (RSInvalidStateException e) {
                e.printStackTrace();
            }
            this.rs = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class ResponseFunction {
        float parameter_A;
        float parameter_B;

        private ResponseFunction(float f, float f2) {
            this.parameter_A = f;
            this.parameter_B = f2;
        }

        static ResponseFunction createIdentity() {
            return new ResponseFunction(1.0f, 0.0f);
        }

        /* JADX WARN: Removed duplicated region for block: B:24:0x01b2  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        ResponseFunction(Context context, int i, List<Double> list, List<Double> list2, List<Double> list3) {
            String str;
            String str2;
            boolean z;
            List<Double> list4 = list2;
            List<Double> list5 = list3;
            Log.d(HDRProcessor.TAG, "ResponseFunction");
            int size = list.size();
            int size2 = list2.size();
            String str3 = "";
            if (size != size2) {
                Log.e(HDRProcessor.TAG, str3);
                throw new RuntimeException();
            } else if (list.size() != list3.size()) {
                Log.e(HDRProcessor.TAG, str3);
                throw new RuntimeException();
            } else if (list.size() <= 3) {
                Log.e(HDRProcessor.TAG, "not enough samples");
                throw new RuntimeException();
            } else {
                double d = 0.0d;
                int i2 = 0;
                double d2 = 0.0d;
                double d3 = 0.0d;
                double d4 = 0.0d;
                double d5 = 0.0d;
                while (i2 < list.size()) {
                    double doubleValue = list.get(i2).doubleValue();
                    double doubleValue2 = list4.get(i2).doubleValue();
                    double doubleValue3 = list5.get(i2).doubleValue();
                    double d6 = doubleValue3 * doubleValue;
                    d2 += d6;
                    d3 += doubleValue * d6;
                    d4 += d6 * doubleValue2;
                    d += doubleValue2 * doubleValue3;
                    d5 += doubleValue3;
                    i2++;
                    list4 = list2;
                    list5 = list3;
                }
                double d7 = d5;
                Log.d(HDRProcessor.TAG, "sum_wx = " + d2);
                Log.d(HDRProcessor.TAG, "sum_wx2 = " + d3);
                Log.d(HDRProcessor.TAG, "sum_wxy = " + d4);
                Log.d(HDRProcessor.TAG, "sum_wy = " + d);
                Log.d(HDRProcessor.TAG, "sum_w = " + d7);
                double d8 = (d * d2) - (d7 * d4);
                double d9 = (d2 * d2) - (d7 * d3);
                Log.d(HDRProcessor.TAG, "A_numer = " + d8);
                Log.d(HDRProcessor.TAG, "A_denom = " + d9);
                String str4 = "denom too small";
                if (Math.abs(d9) < 1.0E-5d) {
                    Log.e(HDRProcessor.TAG, "denom too small");
                    str2 = "parameter A too small or negative: ";
                    str = "parameter_B = ";
                } else {
                    float f = (float) (d8 / d9);
                    this.parameter_A = f;
                    this.parameter_B = (float) ((d - (f * d2)) / d7);
                    Log.d(HDRProcessor.TAG, "parameter_A = " + this.parameter_A);
                    StringBuilder sb = new StringBuilder();
                    str = "parameter_B = ";
                    sb.append(str);
                    sb.append(this.parameter_B);
                    Log.d(HDRProcessor.TAG, sb.toString());
                    if (this.parameter_A < 1.0E-5d) {
                        StringBuilder sb2 = new StringBuilder();
                        str2 = "parameter A too small or negative: ";
                        sb2.append(str2);
                        sb2.append(this.parameter_A);
                        Log.e(HDRProcessor.TAG, sb2.toString());
                    } else {
                        str2 = "parameter A too small or negative: ";
                        if (this.parameter_B < 1.0E-5d) {
                            Log.e(HDRProcessor.TAG, "parameter B too small or negative: " + this.parameter_B);
                        } else {
                            z = true;
                            if (!z) {
                                Log.e(HDRProcessor.TAG, "falling back to linear Y = AX");
                                int i3 = 0;
                                double d10 = 0.0d;
                                double d11 = 0.0d;
                                while (i3 < list.size()) {
                                    double doubleValue4 = list.get(i3).doubleValue();
                                    double doubleValue5 = list2.get(i3).doubleValue();
                                    double doubleValue6 = list3.get(i3).doubleValue() * doubleValue4;
                                    d10 += doubleValue5 * doubleValue6;
                                    d11 += doubleValue6 * doubleValue4;
                                    i3++;
                                    str4 = str4;
                                }
                                String str5 = str4;
                                Log.d(HDRProcessor.TAG, "numer = " + d10);
                                Log.d(HDRProcessor.TAG, "numbr = " + d11);
                                if (d11 < 1.0E-5d) {
                                    Log.e(HDRProcessor.TAG, str5);
                                    this.parameter_A = 1.0f;
                                } else {
                                    float f2 = (float) (d10 / d11);
                                    this.parameter_A = f2;
                                    if (f2 < 1.0E-5d) {
                                        Log.e(HDRProcessor.TAG, str2 + this.parameter_A);
                                        this.parameter_A = 1.0E-5f;
                                    }
                                }
                                this.parameter_B = 0.0f;
                            }
                            Log.d(HDRProcessor.TAG, "parameter_A = " + this.parameter_A);
                            Log.d(HDRProcessor.TAG, str + this.parameter_B);
                        }
                    }
                }
                z = false;
                if (!z) {
                }
                Log.d(HDRProcessor.TAG, "parameter_A = " + this.parameter_A);
                Log.d(HDRProcessor.TAG, str + this.parameter_B);
            }
        }
    }

    public void processHDR(List<Bitmap> list, boolean z, Bitmap bitmap, boolean z2, SortCallback sortCallback, float f, int i, boolean z3, TonemappingAlgorithm tonemappingAlgorithm, DROTonemappingAlgorithm dROTonemappingAlgorithm) throws HDRProcessorException {
        ArrayList<Bitmap> arrayList;
        Log.d(TAG, "processHDR");
        if (z2 || z) {
            arrayList = (ArrayList<Bitmap>) list;
        } else {
            Log.d(TAG, "take a copy of bitmaps array");
            arrayList = new ArrayList(list);
        }
        int size = arrayList.size();
        if (size < 1 || size > 7) {
            Log.e(TAG, "n_bitmaps not supported: " + size);
            throw new HDRProcessorException(0);
        }
        for (int i2 = 1; i2 < size; i2++) {
            if (arrayList.get(i2).getWidth() != arrayList.get(0).getWidth() || arrayList.get(i2).getHeight() != arrayList.get(0).getHeight()) {
                Log.e(TAG, "bitmaps not of same resolution");
                for (int i3 = 0; i3 < size; i3++) {
                    Log.e(TAG, "bitmaps " + i3 + " : " + arrayList.get(i3).getWidth() + " x " + arrayList.get(i3).getHeight());
                }
                throw new HDRProcessorException(1);
            }
        }
        HDRAlgorithm hDRAlgorithm = size == 1 ? HDRAlgorithm.HDRALGORITHM_SINGLE_IMAGE : HDRAlgorithm.HDRALGORITHM_STANDARD;
        int i4 = AnonymousClass2.$SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$HDRProcessor$HDRAlgorithm[hDRAlgorithm.ordinal()];
        if (i4 == 1) {
            if (!z2 && sortCallback != null) {
                ArrayList arrayList2 = new ArrayList();
                arrayList2.add(0);
                sortCallback.sortOrder(arrayList2);
            }
            processSingleImage(arrayList, z, bitmap, f, i, z3, dROTonemappingAlgorithm);
        } else if (i4 == 2) {
            processHDRCore(arrayList, z, bitmap, z2, sortCallback, f, i, z3, tonemappingAlgorithm);
        } else {
            Log.e(TAG, "unknown algorithm " + hDRAlgorithm);
            throw new RuntimeException();
        }
    }

    private ResponseFunction createFunctionFromBitmaps(int i, Bitmap bitmap, Bitmap bitmap2, int i2, int i3) {
        double d;
        double d2;
        double d3;
        ArrayList arrayList;
        int i4;
        Log.d(TAG, "createFunctionFromBitmaps");
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        ArrayList arrayList4 = new ArrayList();
        int sqrt = (int) Math.sqrt(100.0d);
        int i5 = 100 / sqrt;
        double d4 = 0.0d;
        double d5 = 0.0d;
        int i6 = 0;
        while (i6 < i5) {
            double d6 = 1.0d;
            int height = (int) (((i6 + 1.0d) / (i5 + 1.0d)) * bitmap.getHeight());
            d5 = d5;
            int i7 = 0;
            while (i7 < sqrt) {
                ArrayList arrayList5 = arrayList3;
                ArrayList arrayList6 = arrayList4;
                int i8 = i6;
                int i9 = i7;
                int width = (int) (((i7 + d6) / (sqrt + d6)) * bitmap.getWidth());
                int i10 = width + i2;
                if (i10 < 0 || i10 >= bitmap.getWidth() || (i4 = height + i3) < 0 || i4 >= bitmap.getHeight()) {
                    arrayList = arrayList5;
                } else {
                    int pixel = bitmap.getPixel(i10, i4);
                    int pixel2 = bitmap2.getPixel(width, height);
                    double averageRGB = averageRGB(pixel);
                    double averageRGB2 = averageRGB(pixel2);
                    d4 += averageRGB;
                    d5 += averageRGB2;
                    arrayList2.add(Double.valueOf(averageRGB));
                    arrayList = arrayList5;
                    arrayList.add(Double.valueOf(averageRGB2));
                }
                i7 = i9 + 1;
                arrayList3 = arrayList;
                arrayList4 = arrayList6;
                i6 = i8;
                d6 = 1.0d;
            }
            i6++;
            arrayList3 = arrayList3;
            arrayList4 = arrayList4;
        }
        ArrayList arrayList7 = arrayList4;
        double d7 = d5;
        ArrayList arrayList8 = arrayList3;
        if (arrayList2.size() == 0) {
            Log.e(TAG, "no samples for response function!");
            d4 += 255.0d;
            d = d7 + 255.0d;
            arrayList2.add(Double.valueOf(255.0d));
            arrayList8.add(Double.valueOf(255.0d));
        } else {
            d = d7;
        }
        double size = d4 / arrayList2.size();
        double size2 = d / arrayList2.size();
        boolean z = size < size2;
        Log.d(TAG, "avg_in: " + size);
        Log.d(TAG, "avg_out: " + size2);
        Log.d(TAG, "is_dark_exposure: " + z);
        double doubleValue = ((Double) arrayList2.get(0)).doubleValue();
        double doubleValue2 = ((Double) arrayList2.get(0)).doubleValue();
        for (int i11 = 1; i11 < arrayList2.size(); i11++) {
            double doubleValue3 = ((Double) arrayList2.get(i11)).doubleValue();
            if (doubleValue3 < doubleValue) {
                doubleValue = doubleValue3;
            }
            if (doubleValue3 > doubleValue2) {
                doubleValue2 = doubleValue3;
            }
        }
        double d8 = (doubleValue + doubleValue2) * 0.5d;
        Log.d(TAG, "min_value: " + doubleValue);
        Log.d(TAG, "max_value: " + doubleValue2);
        Log.d(TAG, "med_value: " + d8);
        double d9 = doubleValue2;
        double doubleValue4 = ((Double) arrayList8.get(0)).doubleValue();
        boolean z2 = z;
        double doubleValue5 = ((Double) arrayList8.get(0)).doubleValue();
        for (int i12 = 1; i12 < arrayList8.size(); i12++) {
            double doubleValue6 = ((Double) arrayList8.get(i12)).doubleValue();
            if (doubleValue6 < doubleValue4) {
                doubleValue4 = doubleValue6;
            }
            if (doubleValue6 > doubleValue5) {
                doubleValue5 = doubleValue6;
            }
        }
        double d10 = (doubleValue4 + doubleValue5) * 0.5d;
        Log.d(TAG, "min_value_y: " + doubleValue4);
        Log.d(TAG, "max_value_y: " + doubleValue5);
        Log.d(TAG, "med_value_y: " + d10);
        int i13 = 0;
        while (i13 < arrayList2.size()) {
            double doubleValue7 = ((Double) arrayList2.get(i13)).doubleValue();
            double doubleValue8 = ((Double) arrayList8.get(i13)).doubleValue();
            if (doubleValue7 <= d8) {
                d3 = doubleValue7 - doubleValue;
                d2 = d9;
            } else {
                d2 = d9;
                d3 = d2 - doubleValue7;
            }
            if (z2) {
                double d11 = doubleValue8 <= d10 ? doubleValue8 - doubleValue4 : doubleValue5 - doubleValue8;
                if (d11 < d3) {
                    d3 = d11;
                }
            }
            arrayList7.add(Double.valueOf(d3));
            i13++;
            d9 = d2;
        }
        return new ResponseFunction(this.context, i, arrayList2, arrayList8, arrayList7);
    }

    private void processHDRCore(List<Bitmap> list, boolean z, Bitmap bitmap, boolean z2, SortCallback sortCallback, float f, int i, boolean z3, TonemappingAlgorithm tonemappingAlgorithm) {
        Bitmap bitmap2;
        Allocation createFromBitmap;
        boolean z4;
        Allocation allocation;
        int i2 = 0;
        ResponseFunction createIdentity;
        Log.d(TAG, "processHDRCore");
        long currentTimeMillis = System.currentTimeMillis();
        int size = list.size();
        int width = list.get(0).getWidth();
        int height = list.get(0).getHeight();
        ResponseFunction[] responseFunctionArr = new ResponseFunction[size];
        this.offsets_x = new int[size];
        this.offsets_y = new int[size];
        initRenderscript();
        Log.d(TAG, "### time after creating renderscript: " + (System.currentTimeMillis() - currentTimeMillis));
        Allocation[] allocationArr = new Allocation[size];
        for (int i3 = 0; i3 < size; i3++) {
            allocationArr[i3] = Allocation.createFromBitmap(this.rs, list.get(i3));
        }
        Log.d(TAG, "### time after creating allocations from bitmaps: " + (System.currentTimeMillis() - currentTimeMillis));
        int i4 = size % 2;
        int i5 = i4 == 0 ? size / 2 : (size - 1) / 2;
        int i6 = autoAlignment(this.offsets_x, this.offsets_y, allocationArr, width, height, list, i5, z2, sortCallback, true, false, 1, true, 1, width, height, currentTimeMillis).median_brightness;
        Log.d(TAG, "### time after autoAlignment: " + (System.currentTimeMillis() - currentTimeMillis));
        Log.d(TAG, "median_brightness: " + i6);
        boolean z5 = size != 3;
        int i7 = 0;
        while (i7 < size) {
            int i8 = i5;
            if (i7 != i8) {
                createIdentity = createFunctionFromBitmaps(i7, list.get(i7), list.get(i8), this.offsets_x[i7], this.offsets_y[i7]);
            } else {
                createIdentity = z5 ? ResponseFunction.createIdentity() : null;
            }
            responseFunctionArr[i7] = createIdentity;
            i7++;
            i5 = i8;
        }
        int i9 = i5;
        Log.d(TAG, "### time after creating response functions: " + (System.currentTimeMillis() - currentTimeMillis));
        if (i4 == 0) {
            float sqrt = (float) Math.sqrt(responseFunctionArr[i2].parameter_A);
            float f2 = responseFunctionArr[i9 - 1].parameter_B / (sqrt + 1.0f);
            Log.d(TAG, "remap for even number of images");
            Log.d(TAG, "    a: " + sqrt);
            Log.d(TAG, "    b: " + f2);
            if (sqrt < 1.0E-5f) {
                Log.e(TAG, "    clamp a to: 1.0E-5");
                sqrt = 1.0E-5f;
            }
            for (int i10 = 0; i10 < size; i10++) {
                float f3 = responseFunctionArr[i10].parameter_A;
                float f4 = responseFunctionArr[i10].parameter_B;
                responseFunctionArr[i10].parameter_A = f3 / sqrt;
                responseFunctionArr[i10].parameter_B = f4 - ((f3 * f2) / sqrt);
                Log.d(TAG, "remapped: " + i10);
                Log.d(TAG, "    A: " + f3 + " -> " + responseFunctionArr[i10].parameter_A);
                Log.d(TAG, "    B: " + f4 + " -> " + responseFunctionArr[i10].parameter_B);
            }
        }
        ScriptC_process_hdr scriptC_process_hdr = new ScriptC_process_hdr(this.rs);
        scriptC_process_hdr.set_bitmap0(allocationArr[0]);
        if (size > 2) {
            scriptC_process_hdr.set_bitmap2(allocationArr[2]);
        }
        scriptC_process_hdr.set_offset_x0(this.offsets_x[0]);
        scriptC_process_hdr.set_offset_y0(this.offsets_y[0]);
        if (size > 2) {
            scriptC_process_hdr.set_offset_x2(this.offsets_x[2]);
            scriptC_process_hdr.set_offset_y2(this.offsets_y[2]);
        }
        scriptC_process_hdr.set_parameter_A0(responseFunctionArr[0].parameter_A);
        scriptC_process_hdr.set_parameter_B0(responseFunctionArr[0].parameter_B);
        if (size > 2) {
            scriptC_process_hdr.set_parameter_A2(responseFunctionArr[2].parameter_A);
            scriptC_process_hdr.set_parameter_B2(responseFunctionArr[2].parameter_B);
        }
        if (z5) {
            scriptC_process_hdr.set_bitmap1(allocationArr[1]);
            scriptC_process_hdr.set_offset_x1(this.offsets_x[1]);
            scriptC_process_hdr.set_offset_y1(this.offsets_y[1]);
            scriptC_process_hdr.set_parameter_A1(responseFunctionArr[1].parameter_A);
            scriptC_process_hdr.set_parameter_B1(responseFunctionArr[1].parameter_B);
        }
        if (size > 3) {
            scriptC_process_hdr.set_bitmap3(allocationArr[3]);
            scriptC_process_hdr.set_offset_x3(this.offsets_x[3]);
            scriptC_process_hdr.set_offset_y3(this.offsets_y[3]);
            scriptC_process_hdr.set_parameter_A3(responseFunctionArr[3].parameter_A);
            scriptC_process_hdr.set_parameter_B3(responseFunctionArr[3].parameter_B);
            if (size > 4) {
                scriptC_process_hdr.set_bitmap4(allocationArr[4]);
                scriptC_process_hdr.set_offset_x4(this.offsets_x[4]);
                scriptC_process_hdr.set_offset_y4(this.offsets_y[4]);
                scriptC_process_hdr.set_parameter_A4(responseFunctionArr[4].parameter_A);
                scriptC_process_hdr.set_parameter_B4(responseFunctionArr[4].parameter_B);
                if (size > 5) {
                    scriptC_process_hdr.set_bitmap5(allocationArr[5]);
                    scriptC_process_hdr.set_offset_x5(this.offsets_x[5]);
                    scriptC_process_hdr.set_offset_y5(this.offsets_y[5]);
                    scriptC_process_hdr.set_parameter_A5(responseFunctionArr[5].parameter_A);
                    scriptC_process_hdr.set_parameter_B5(responseFunctionArr[5].parameter_B);
                    if (size > 6) {
                        scriptC_process_hdr.set_bitmap6(allocationArr[6]);
                        scriptC_process_hdr.set_offset_x6(this.offsets_x[6]);
                        scriptC_process_hdr.set_offset_y6(this.offsets_y[6]);
                        scriptC_process_hdr.set_parameter_A6(responseFunctionArr[6].parameter_A);
                        scriptC_process_hdr.set_parameter_B6(responseFunctionArr[6].parameter_B);
                    }
                }
            }
        }
        int i11 = AnonymousClass2.$SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$HDRProcessor$TonemappingAlgorithm[tonemappingAlgorithm.ordinal()];
        if (i11 == 1) {
            Log.d(TAG, "tonemapping algorithm: clamp");
            scriptC_process_hdr.set_tonemap_algorithm(scriptC_process_hdr.get_tonemap_algorithm_clamp_c());
        } else if (i11 == 2) {
            Log.d(TAG, "tonemapping algorithm: exponential");
            scriptC_process_hdr.set_tonemap_algorithm(scriptC_process_hdr.get_tonemap_algorithm_exponential_c());
        } else if (i11 == 3) {
            Log.d(TAG, "tonemapping algorithm: reinhard");
            scriptC_process_hdr.set_tonemap_algorithm(scriptC_process_hdr.get_tonemap_algorithm_reinhard_c());
        } else if (i11 == 4) {
            Log.d(TAG, "tonemapping algorithm: fu2");
            scriptC_process_hdr.set_tonemap_algorithm(scriptC_process_hdr.get_tonemap_algorithm_fu2_c());
        } else if (i11 == 5) {
            Log.d(TAG, "tonemapping algorithm: aces");
            scriptC_process_hdr.set_tonemap_algorithm(scriptC_process_hdr.get_tonemap_algorithm_aces_c());
        }
        float f5 = 255.0f;
        float f6 = (responseFunctionArr[0].parameter_A * 255.0f) + responseFunctionArr[0].parameter_B;
        Log.d(TAG, "max_possible_value: " + f6);
        if (f6 < 255.0f) {
            Log.d(TAG, "clamp max_possible_value to: 255.0");
            f6 = 255.0f;
        }
        int brightnessTarget = getBrightnessTarget(i6, 2.0f, 119);
        Log.d(TAG, "median_target: " + brightnessTarget);
        StringBuilder sb = new StringBuilder();
        sb.append("compare: ");
        float f7 = 255.0f / f6;
        sb.append(f7);
        Log.d(TAG, sb.toString());
        StringBuilder sb2 = new StringBuilder();
        sb2.append("to: ");
        float f8 = brightnessTarget;
        float f9 = f8 / i6;
        float f10 = ((f8 / 255.0f) + f9) - 1.0f;
        sb2.append(f10);
        Log.d(TAG, sb2.toString());
        if (f7 < f10) {
            float f11 = f9 - f7;
            Log.d(TAG, "tonemap_denom: " + f11);
            if (f11 != 0.0f) {
                float f12 = (255.0f - f8) / f11;
                Log.d(TAG, "tonemap_scale_c (before setting min): " + f12);
                f5 = Math.max(f12, 127.5f);
            }
        }
        Log.d(TAG, "tonemap_scale_c: " + f5);
        scriptC_process_hdr.set_tonemap_scale(f5);
        int i12 = AnonymousClass2.$SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$HDRProcessor$TonemappingAlgorithm[tonemappingAlgorithm.ordinal()];
        if (i12 == 2) {
            float exp = (float) (1.0d / (1.0d - Math.exp(((-scriptC_process_hdr.get_exposure()) * f6) / 255.0d)));
            Log.d(TAG, "linear_scale: " + exp);
            scriptC_process_hdr.set_linear_scale(exp);
        } else if (i12 == 3) {
            float f13 = (f5 + f6) / f6;
            Log.d(TAG, "linear_scale: " + f13);
            scriptC_process_hdr.set_linear_scale(f13);
        } else if (i12 == 4) {
            float f14 = scriptC_process_hdr.get_fu2_exposure_bias() * f6;
            Log.d(TAG, "fu2 W: " + f14);
            scriptC_process_hdr.set_W(f14);
        }
        Log.d(TAG, "call processHDRScript");
        if (z) {
            bitmap2 = bitmap;
            createFromBitmap = allocationArr[i9];
            z4 = false;
        } else {
            bitmap2 = bitmap;
            createFromBitmap = Allocation.createFromBitmap(this.rs, bitmap2);
            z4 = true;
        }
        Log.d(TAG, "### time before processHDRScript: " + (System.currentTimeMillis() - currentTimeMillis));
        if (z5) {
            scriptC_process_hdr.set_n_bitmaps_g(size);
            scriptC_process_hdr.forEach_hdr_n(allocationArr[i9], createFromBitmap);
        } else {
            scriptC_process_hdr.forEach_hdr(allocationArr[i9], createFromBitmap);
        }
        Log.d(TAG, "### time after processHDRScript: " + (System.currentTimeMillis() - currentTimeMillis));
        if (z) {
            Log.d(TAG, "release bitmaps");
            for (int i13 = 0; i13 < list.size(); i13++) {
                if (i13 != i9) {
                    list.get(i13).recycle();
                }
            }
        }
        if (f != 0.0f) {
            allocation = createFromBitmap;
            adjustHistogram(createFromBitmap, createFromBitmap, width, height, f, i, z3, currentTimeMillis);
            Log.d(TAG, "### time after adjustHistogram: " + (System.currentTimeMillis() - currentTimeMillis));
        } else {
            allocation = createFromBitmap;
        }
        if (z) {
            allocationArr[i9].copyTo(list.get(i9));
            Log.d(TAG, "### time after copying to bitmap: " + (System.currentTimeMillis() - currentTimeMillis));
            list.set(0, list.get(i9));
            for (int i14 = 1; i14 < list.size(); i14++) {
                list.set(i14, null);
            }
        } else {
            allocation.copyTo(bitmap2);
            Log.d(TAG, "### time after copying to bitmap: " + (System.currentTimeMillis() - currentTimeMillis));
        }
        if (z4) {
            allocation.destroy();
        }
        for (int i15 = 0; i15 < size; i15++) {
            allocationArr[i15].destroy();
            allocationArr[i15] = null;
        }
        freeScripts();
        Log.d(TAG, "### time for processHDRCore: " + (System.currentTimeMillis() - currentTimeMillis));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.live.gpsmap.camera.Camera.HDRProcessor$2  reason: invalid class name */

    public static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$HDRProcessor$HDRAlgorithm;
        static final /* synthetic */ int[] $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$HDRProcessor$TonemappingAlgorithm;

        static {
            int[] iArr = new int[TonemappingAlgorithm.values().length];
            $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$HDRProcessor$TonemappingAlgorithm = iArr;
            try {
                iArr[TonemappingAlgorithm.TONEMAPALGORITHM_CLAMP.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$HDRProcessor$TonemappingAlgorithm[TonemappingAlgorithm.TONEMAPALGORITHM_EXPONENTIAL.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$HDRProcessor$TonemappingAlgorithm[TonemappingAlgorithm.TONEMAPALGORITHM_REINHARD.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$HDRProcessor$TonemappingAlgorithm[TonemappingAlgorithm.TONEMAPALGORITHM_FU2.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$HDRProcessor$TonemappingAlgorithm[TonemappingAlgorithm.TONEMAPALGORITHM_ACES.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            int[] iArr2 = new int[HDRAlgorithm.values().length];
            $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$HDRProcessor$HDRAlgorithm = iArr2;
            try {
                iArr2[HDRAlgorithm.HDRALGORITHM_SINGLE_IMAGE.ordinal()] = 1;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$HDRProcessor$HDRAlgorithm[HDRAlgorithm.HDRALGORITHM_STANDARD.ordinal()] = 2;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x0197  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x01a3  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x01c4  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private void processSingleImage(List<Bitmap> list, boolean z, Bitmap bitmap, float f, int i, boolean z2, DROTonemappingAlgorithm dROTonemappingAlgorithm) {
        boolean z3;
        Allocation createFromBitmap;
        Allocation allocation;
        boolean z4;
        Allocation allocation2;
        boolean z5;
        Log.d(TAG, "processSingleImage");
        long currentTimeMillis = System.currentTimeMillis();
        int width = list.get(0).getWidth();
        int height = list.get(0).getHeight();
        initRenderscript();
        Log.d(TAG, "### time after creating renderscript: " + (System.currentTimeMillis() - currentTimeMillis));
        Allocation createFromBitmap2 = Allocation.createFromBitmap(this.rs, list.get(0));
        if (z) {
            createFromBitmap = createFromBitmap2;
            z3 = false;
        } else {
            z3 = true;
            createFromBitmap = Allocation.createFromBitmap(this.rs, bitmap);
        }
        if (dROTonemappingAlgorithm == DROTonemappingAlgorithm.DROALGORITHM_GAINGAMMA) {
            HistogramInfo histogramInfo = getHistogramInfo(computeHistogram(createFromBitmap2, false, false));
            int i2 = histogramInfo.median_brightness;
            int i3 = histogramInfo.max_brightness;
            StringBuilder sb = new StringBuilder();
            sb.append("### time after computeHistogram: ");
            Allocation allocation3 = createFromBitmap;
            sb.append(System.currentTimeMillis() - currentTimeMillis);
            Log.d(TAG, sb.toString());
            Log.d(TAG, "median brightness: " + i2);
            Log.d(TAG, "max brightness: " + i3);
            BrightenFactors computeBrightenFactors = computeBrightenFactors(false, 0, 0L, i2, i3);
            float f2 = computeBrightenFactors.gain;
            float f3 = computeBrightenFactors.gamma;
            float f4 = computeBrightenFactors.low_x;
            float f5 = computeBrightenFactors.mid_x;
            Log.d(TAG, "gain: " + f2);
            Log.d(TAG, "gamma: " + f3);
            Log.d(TAG, "low_x: " + f4);
            Log.d(TAG, "mid_x: " + f5);
            if (Math.abs(f2 - 1.0d) > 1.0E-5d || i3 != 255 || Math.abs(f3 - 1.0d) > 1.0E-5d) {
                Log.d(TAG, "apply gain/gamma");
                ScriptC_avg_brighten scriptC_avg_brighten = new ScriptC_avg_brighten(this.rs);
                scriptC_avg_brighten.invoke_setBrightenParameters(f2, f3, f4, f5, i3);
                allocation = allocation3;
                scriptC_avg_brighten.forEach_dro_brighten(createFromBitmap2, allocation);
                if (z3) {
                    createFromBitmap2.destroy();
                    z3 = false;
                }
                Log.d(TAG, "### time after dro_brighten: " + (System.currentTimeMillis() - currentTimeMillis));
                z4 = z3;
                allocation2 = allocation;
                Allocation allocation4 = allocation;
                z5 = z4;
                adjustHistogram(allocation2, allocation, width, height, f, i, z2, currentTimeMillis);
                if (!z) {
                    allocation2.copyTo(list.get(0));
                } else {
                    allocation4.copyTo(bitmap);
                }
                Log.d(TAG, "time after copying to bitmap: " + (System.currentTimeMillis() - currentTimeMillis));
                if (z5) {
                    allocation2.destroy();
                }
                allocation4.destroy();
                freeScripts();
                Log.d(TAG, "time for processSingleImage: " + (System.currentTimeMillis() - currentTimeMillis));
            }
            allocation = allocation3;
        } else {
            allocation = createFromBitmap;
        }
        allocation2 = createFromBitmap2;
        z4 = z3;
        Allocation allocation42 = allocation;
        z5 = z4;
        adjustHistogram(allocation2, allocation, width, height, f, i, z2, currentTimeMillis);
        if (!z) {
        }
        Log.d(TAG, "time after copying to bitmap: " + (System.currentTimeMillis() - currentTimeMillis));
        if (z5) {
        }
        allocation42.destroy();
        freeScripts();
        Log.d(TAG, "time for processSingleImage: " + (System.currentTimeMillis() - currentTimeMillis));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void brightenImage(Bitmap bitmap, int i, int i2, int i3) {
        Log.d(TAG, "brightenImage");
        Log.d(TAG, "brightness: " + i);
        Log.d(TAG, "max_brightness: " + i2);
        Log.d(TAG, "brightness_target: " + i3);
        BrightenFactors computeBrightenFactors = computeBrightenFactors(false, 0, 0L, i, i2, i3, false);
        float f = computeBrightenFactors.gain;
        float f2 = computeBrightenFactors.gamma;
        float f3 = computeBrightenFactors.low_x;
        float f4 = computeBrightenFactors.mid_x;
        Log.d(TAG, "gain: " + f);
        Log.d(TAG, "gamma: " + f2);
        Log.d(TAG, "low_x: " + f3);
        Log.d(TAG, "mid_x: " + f4);
        if (Math.abs(f - 1.0d) > 1.0E-5d || i2 != 255 || Math.abs(f2 - 1.0d) > 1.0E-5d) {
            Log.d(TAG, "apply gain/gamma");
            initRenderscript();
            Allocation createFromBitmap = Allocation.createFromBitmap(this.rs, bitmap);
            ScriptC_avg_brighten scriptC_avg_brighten = new ScriptC_avg_brighten(this.rs);
            scriptC_avg_brighten.invoke_setBrightenParameters(f, f2, f3, f4, i2);
            scriptC_avg_brighten.forEach_dro_brighten(createFromBitmap, createFromBitmap);
            createFromBitmap.copyTo(bitmap);
            createFromBitmap.destroy();
            freeScripts();
        }
    }

    private void initRenderscript() {
        Log.d(TAG, "initRenderscript");
        if (this.rs == null) {
            this.rs = RenderScript.create(this.context);
            Log.d(TAG, "create renderscript object");
        }
    }

    public int getAvgSampleSize(int i, long j) {
        this.cached_avg_sample_size = sceneIsLowLight(i, j) ? 2 : 1;
        Log.d(TAG, "getAvgSampleSize: " + this.cached_avg_sample_size);
        return this.cached_avg_sample_size;
    }

    public int getAvgSampleSize() {
        return this.cached_avg_sample_size;
    }

    /* loaded from: classes3.dex */
    public static class AvgData {
        Allocation allocation_avg_align;
        Allocation allocation_orig;
        public Allocation allocation_out;
        Bitmap bitmap_avg_align;
        Bitmap bitmap_orig;

        AvgData(Allocation allocation, Bitmap bitmap, Allocation allocation2, Bitmap bitmap2, Allocation allocation3) {
            this.allocation_out = allocation;
            this.bitmap_avg_align = bitmap;
            this.allocation_avg_align = allocation2;
            this.bitmap_orig = bitmap2;
            this.allocation_orig = allocation3;
        }

        public void destroy() {
            Log.d(HDRProcessor.TAG, "AvgData.destroy()");
            Allocation allocation = this.allocation_out;
            if (allocation != null) {
                allocation.destroy();
                this.allocation_out = null;
            }
            Bitmap bitmap = this.bitmap_avg_align;
            if (bitmap != null) {
                bitmap.recycle();
                this.bitmap_avg_align = null;
            }
            Allocation allocation2 = this.allocation_avg_align;
            if (allocation2 != null) {
                allocation2.destroy();
                this.allocation_avg_align = null;
            }
            Bitmap bitmap2 = this.bitmap_orig;
            if (bitmap2 != null) {
                bitmap2.recycle();
                this.bitmap_orig = null;
            }
            Allocation allocation3 = this.allocation_orig;
            if (allocation3 != null) {
                allocation3.destroy();
                this.allocation_orig = null;
            }
        }
    }

    public AvgData processAvg(Bitmap bitmap, Bitmap bitmap2, float f, int i, long j, float f2) throws HDRProcessorException {
        Log.d(TAG, "processAvg");
        Log.d(TAG, "avg_factor: " + f);
        if (bitmap.getWidth() != bitmap2.getWidth() || bitmap.getHeight() != bitmap2.getHeight()) {
            Log.e(TAG, "bitmaps not of same resolution");
            throw new HDRProcessorException(1);
        }
        long currentTimeMillis = System.currentTimeMillis();
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        initRenderscript();
        Log.d(TAG, "### time after creating renderscript: " + (System.currentTimeMillis() - currentTimeMillis));
        AvgData processAvgCore = processAvgCore(null, null, bitmap, bitmap2, width, height, f, i, j, f2, null, null, null, currentTimeMillis);
        Log.d(TAG, "### time for processAvg: " + (System.currentTimeMillis() - currentTimeMillis));
        return processAvgCore;
    }

    public void updateAvg(AvgData avgData, int i, int i2, Bitmap bitmap, float f, int i3, long j, float f2) throws HDRProcessorException {
        Log.d(TAG, "updateAvg");
        Log.d(TAG, "avg_factor: " + f);
        if (i != bitmap.getWidth() || i2 != bitmap.getHeight()) {
            Log.e(TAG, "bitmaps not of same resolution");
            throw new HDRProcessorException(1);
        }
        long currentTimeMillis = System.currentTimeMillis();
        processAvgCore(avgData.allocation_out, avgData.allocation_out, null, bitmap, i, i2, f, i3, j, f2, avgData.allocation_avg_align, avgData.bitmap_avg_align, avgData.allocation_orig, currentTimeMillis);
        Log.d(TAG, "### time for updateAvg: " + (System.currentTimeMillis() - currentTimeMillis));
    }

    /* JADX WARN: Removed duplicated region for block: B:55:0x0363  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0369  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x038d  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x0392  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private AvgData processAvgCore(Allocation allocation, Allocation allocation2, Bitmap bitmap, Bitmap bitmap2, int i, int i2, float f, int i3, long j, float f2, Allocation allocation3, Bitmap bitmap3, Allocation allocation4, long j2) {
        int i4;
        Allocation[] allocationArr;
        ArrayList arrayList;
        char c;
        Allocation allocation5;
        Bitmap bitmap4;
        Allocation allocation6;
        Bitmap bitmap5;
        Allocation allocation7;
        Allocation allocation8;
        float f3;
        Log.d(TAG, "processAvgCore");
        Log.d(TAG, "iso: " + i3);
        Log.d(TAG, "zoom_factor: " + f2);
        this.offsets_x = new int[2];
        this.offsets_y = new int[2];
        boolean z = false;
        boolean z2 = bitmap == null;
        ArrayList arrayList2 = new ArrayList();
        Allocation[] allocationArr2 = new Allocation[2];
        int max = f2 > 3.9f ? 1 : Math.max(4 / getAvgSampleSize(i3, j), 1);
        Log.d(TAG, "scale_align_size: " + max);
        Log.d(TAG, "### time before creating allocations for autoalignment: " + (System.currentTimeMillis() - j2));
        Matrix matrix = new Matrix();
        float f4 = 1.0f / ((float) max);
        matrix.postScale(f4, f4);
        int i5 = i / max;
        int i6 = i2 / max;
        int i7 = i / 2;
        int i8 = i2 / 2;
        int i9 = (i - i7) / 2;
        int i10 = (i2 - i8) / 2;
        if (allocation3 == null) {
            i4 = max;
            allocationArr = allocationArr2;
            arrayList = arrayList2;
            c = 1;
            Bitmap createBitmap = Bitmap.createBitmap(bitmap, i9, i10, i7, i8, matrix, false);
            Allocation createFromBitmap = Allocation.createFromBitmap(this.rs, createBitmap);
            Log.d(TAG, "### time after creating avg allocation for autoalignment: " + (System.currentTimeMillis() - j2));
            bitmap4 = createBitmap;
            allocation5 = createFromBitmap;
        } else {
            i4 = max;
            allocationArr = allocationArr2;
            arrayList = arrayList2;
            c = 1;
            allocation5 = allocation3;
            bitmap4 = bitmap3;
        }
        Bitmap bitmap6 = bitmap4;
        Bitmap createBitmap2 = Bitmap.createBitmap(bitmap2, i9, i10, i7, i8, matrix, false);
        Allocation createFromBitmap2 = Allocation.createFromBitmap(this.rs, createBitmap2);
        int width = createBitmap2.getWidth();
        int height = createBitmap2.getHeight();
        arrayList.add(bitmap6);
        arrayList.add(createBitmap2);
        allocationArr[0] = allocation5;
        allocationArr[c] = createFromBitmap2;
        Log.d(TAG, "### time after creating allocations for autoalignment: " + (System.currentTimeMillis() - j2));
        autoAlignment(this.offsets_x, this.offsets_y, allocationArr, width, height, arrayList, 0, true, null, false, false, 1, false, sceneIsLowLight(i3, j) ? 2 : 1, i5, i6, j2);
        int i11 = 0;
        while (true) {
            int[] iArr = this.offsets_x;
            if (i11 >= iArr.length) {
                break;
            }
            iArr[i11] = iArr[i11] * i4;
            i11++;
        }
        int i12 = 0;
        while (true) {
            int[] iArr2 = this.offsets_y;
            if (i12 >= iArr2.length) {
                break;
            }
            iArr2[i12] = iArr2[i12] * i4;
            i12++;
        }
        if (createBitmap2 != null) {
            createBitmap2.recycle();
        }
        if (createFromBitmap2 != null) {
            createFromBitmap2.destroy();
        }
        Log.d(TAG, "### time after autoAlignment: " + (System.currentTimeMillis() - j2));
        if (allocation == null) {
            Log.d(TAG, "need to create allocation_out");
            RenderScript renderScript = this.rs;
            allocation6 = Allocation.createTyped(renderScript, Type.createXY(renderScript, Element.F32_3(renderScript), i, i2));
            Log.d(TAG, "### time after create allocation_out: " + (System.currentTimeMillis() - j2));
        } else {
            allocation6 = allocation;
        }
        if (allocation2 == null) {
            bitmap5 = bitmap;
            allocation7 = Allocation.createFromBitmap(this.rs, bitmap5);
            Log.d(TAG, "### time after creating allocation_avg from bitmap: " + (System.currentTimeMillis() - j2));
            z = true;
        } else {
            bitmap5 = bitmap;
            allocation7 = allocation2;
        }
        if (this.processAvgScript == null) {
            this.processAvgScript = new ScriptC_process_avg(this.rs);
        }
        Allocation createFromBitmap3 = Allocation.createFromBitmap(this.rs, bitmap2);
        Log.d(TAG, "### time after creating allocation_new from bitmap: " + (System.currentTimeMillis() - j2));
        if (allocation4 != null) {
            allocation8 = allocation4;
        } else if (z2) {
            throw new RuntimeException("is in floating point mode, but no allocation_orig supplied");
        } else {
            Log.d(TAG, "create allocation_avg");
            allocation8 = Allocation.createFromBitmap(this.rs, bitmap5);
        }
        Log.d(TAG, "allocation_orig: " + allocation8);
        this.processAvgScript.set_bitmap_orig(allocation8);
        this.processAvgScript.set_bitmap_new(createFromBitmap3);
        this.processAvgScript.set_offset_x_new(this.offsets_x[c]);
        this.processAvgScript.set_offset_y_new(this.offsets_y[c]);
        this.processAvgScript.set_avg_factor(f);
        float min = Math.min(i3, 400);
        if (i3 >= 700) {
            min = 800.0f;
            if (i3 >= 1100) {
                f3 = 8.0f;
                float pow = 1.0f - ((float) Math.pow(0.5d, f));
                Log.d(TAG, "avg_factor: " + f);
                Log.d(TAG, "tapered_wiener_scale: " + pow);
                float max2 = (Math.max(min, 100.0f) * 10.0f) / pow;
                Log.d(TAG, "wiener_C: " + max2);
                Log.d(TAG, "wiener_cutoff_factor: " + f3);
                this.processAvgScript.set_wiener_C(max2);
                this.processAvgScript.set_wiener_C_cutoff(f3 * max2);
                Log.d(TAG, "call processAvgScript");
                Log.d(TAG, "### time before processAvgScript: " + (System.currentTimeMillis() - j2));
                if (!z2) {
                    this.processAvgScript.forEach_avg_f(allocation7, allocation6);
                } else {
                    this.processAvgScript.forEach_avg(allocation7, allocation6);
                }
                Log.d(TAG, "### time after processAvgScript: " + (System.currentTimeMillis() - j2));
                createFromBitmap3.destroy();
                if (z) {
                    allocation7.destroy();
                }
                if (bitmap2 != null) {
                    Log.d(TAG, "release bitmap_new");
                    bitmap2.recycle();
                }
                Log.d(TAG, "### time for processAvgCore: " + (System.currentTimeMillis() - j2));
                return new AvgData(allocation6, bitmap6, allocation5, bitmap, allocation8);
            }
        }
        f3 = 1.0f;
        float pow2 = 1.0f - ((float) Math.pow(0.5d, f));
        Log.d(TAG, "avg_factor: " + f);
        Log.d(TAG, "tapered_wiener_scale: " + pow2);
        float max22 = (Math.max(min, 100.0f) * 10.0f) / pow2;
        Log.d(TAG, "wiener_C: " + max22);
        Log.d(TAG, "wiener_cutoff_factor: " + f3);
        this.processAvgScript.set_wiener_C(max22);
        this.processAvgScript.set_wiener_C_cutoff(f3 * max22);
        Log.d(TAG, "call processAvgScript");
        Log.d(TAG, "### time before processAvgScript: " + (System.currentTimeMillis() - j2));
        if (!z2) {
        }
        Log.d(TAG, "### time after processAvgScript: " + (System.currentTimeMillis() - j2));
        createFromBitmap3.destroy();
        if (z) {
        }
        if (bitmap2 != null) {
        }
        Log.d(TAG, "### time for processAvgCore: " + (System.currentTimeMillis() - j2));
        return new AvgData(allocation6, bitmap6, allocation5, bitmap, allocation8);
    }

    public void processAvgMulti(List<Bitmap> list, float f, int i, boolean z) throws HDRProcessorException {
        Allocation allocation;
        Log.d(TAG, "processAvgMulti");
        Log.d(TAG, "hdr_alpha: " + f);
        int size = list.size();
        if (size != 8) {
            Log.e(TAG, "n_bitmaps should be 8, not " + size);
            throw new HDRProcessorException(0);
        }
        for (int i2 = 1; i2 < size; i2++) {
            if (list.get(i2).getWidth() != list.get(0).getWidth() || list.get(i2).getHeight() != list.get(0).getHeight()) {
                Log.e(TAG, "bitmaps not of same resolution");
                for (int i3 = 0; i3 < size; i3++) {
                    Log.e(TAG, "bitmaps " + i3 + " : " + list.get(i3).getWidth() + " x " + list.get(i3).getHeight());
                }
                throw new HDRProcessorException(1);
            }
        }
        long currentTimeMillis = System.currentTimeMillis();
        int width = list.get(0).getWidth();
        int height = list.get(0).getHeight();
        initRenderscript();
        Log.d(TAG, "### time after creating renderscript: " + (System.currentTimeMillis() - currentTimeMillis));
        Allocation createFromBitmap = Allocation.createFromBitmap(this.rs, list.get(0));
        Allocation createFromBitmap2 = Allocation.createFromBitmap(this.rs, list.get(1));
        Allocation createFromBitmap3 = Allocation.createFromBitmap(this.rs, list.get(2));
        Allocation createFromBitmap4 = Allocation.createFromBitmap(this.rs, list.get(3));
        Allocation createFromBitmap5 = Allocation.createFromBitmap(this.rs, list.get(4));
        Allocation createFromBitmap6 = Allocation.createFromBitmap(this.rs, list.get(5));
        Allocation createFromBitmap7 = Allocation.createFromBitmap(this.rs, list.get(6));
        Allocation createFromBitmap8 = Allocation.createFromBitmap(this.rs, list.get(7));
        Log.d(TAG, "### time after creating allocations from bitmaps: " + (System.currentTimeMillis() - currentTimeMillis));
        ScriptC_process_avg scriptC_process_avg = new ScriptC_process_avg(this.rs);
        scriptC_process_avg.set_bitmap1(createFromBitmap2);
        scriptC_process_avg.set_bitmap2(createFromBitmap3);
        scriptC_process_avg.set_bitmap3(createFromBitmap4);
        scriptC_process_avg.set_bitmap4(createFromBitmap5);
        scriptC_process_avg.set_bitmap5(createFromBitmap6);
        scriptC_process_avg.set_bitmap6(createFromBitmap7);
        scriptC_process_avg.set_bitmap7(createFromBitmap8);
        Log.d(TAG, "call processAvgScript");
        Log.d(TAG, "### time before processAvgScript: " + (System.currentTimeMillis() - currentTimeMillis));
        scriptC_process_avg.forEach_avg_multi(createFromBitmap, createFromBitmap);
        Log.d(TAG, "### time after processAvgScript: " + (System.currentTimeMillis() - currentTimeMillis));
        Log.d(TAG, "release bitmaps");
        for (int i4 = 1; i4 < list.size(); i4++) {
            list.get(i4).recycle();
        }
        if (f != 0.0f) {
            allocation = createFromBitmap;
            adjustHistogram(createFromBitmap, createFromBitmap, width, height, f, i, z, currentTimeMillis);
            Log.d(TAG, "### time after adjustHistogram: " + (System.currentTimeMillis() - currentTimeMillis));
        } else {
            allocation = createFromBitmap;
        }
        allocation.copyTo(list.get(0));
        Log.d(TAG, "### time for processAvgMulti: " + (System.currentTimeMillis() - currentTimeMillis));
    }

    void autoAlignment(int[] iArr, int[] iArr2, int i, int i2, List<Bitmap> list, int i3, boolean z, int i4) {
        Log.d(TAG, "autoAlignment");
        initRenderscript();
        int size = list.size();
        Allocation[] allocationArr = new Allocation[size];
        for (int i5 = 0; i5 < list.size(); i5++) {
            allocationArr[i5] = Allocation.createFromBitmap(this.rs, list.get(i5));
        }
        autoAlignment(iArr, iArr2, allocationArr, i, i2, list, i3, true, null, z, false, 1, false, i4, i, i2, 0L);
        for (int i6 = 0; i6 < size; i6++) {
            Allocation allocation = allocationArr[i6];
            if (allocation != null) {
                allocation.destroy();
                allocationArr[i6] = null;
            }
        }
        freeScripts();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class BrightnessDetails {
        final int median_brightness;

        BrightnessDetails(int i) {
            this.median_brightness = i;
        }
    }

    private BrightnessDetails autoAlignment(int[] iArr, int[] iArr2, Allocation[] allocationArr, int i, int i2, List<Bitmap> list, int i3, boolean z, SortCallback sortCallback, boolean z2, boolean z3, int i4, boolean z4, int i5, int i6, int i7, long j) {
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        String str;
        LuminanceInfo[] luminanceInfoArr;
        int i18;
        int i19;
        int i20;
        int i21;
        int i22;
        int i23;
        int i24;
        int i25;
        int i26;
        Log.d(TAG, "autoAlignment");
        Log.d(TAG, "width: " + i);
        Log.d(TAG, "height: " + i2);
        Log.d(TAG, "use_mtb: " + z2);
        Log.d(TAG, "max_align_scale: " + i5);
        Log.d(TAG, "allocations: " + allocationArr.length);
        for (Allocation allocation : allocationArr) {
            Log.d(TAG, "    allocation:");
            Log.d(TAG, "    element: " + allocation.getElement());
            Log.d(TAG, "    type X: " + allocation.getType().getX());
            Log.d(TAG, "    type Y: " + allocation.getType().getY());
        }
        for (int i27 = 0; i27 < iArr.length; i27++) {
            iArr[i27] = 0;
            iArr2[i27] = 0;
        }
        int length = allocationArr.length;
        Allocation[] allocationArr2 = new Allocation[length];
        Log.d(TAG, "### time after creating mtb_allocations: " + (System.currentTimeMillis() - j));
        if (z4) {
            int i28 = i / 2;
            int i29 = i2 / 2;
            i8 = i28;
            i9 = i29;
            i10 = i29 / 2;
            i11 = i28 / 2;
        } else {
            i8 = i;
            i9 = i2;
            i10 = 0;
            i11 = 0;
        }
        Log.d(TAG, "mtb_x: " + i11);
        Log.d(TAG, "mtb_y: " + i10);
        Log.d(TAG, "mtb_width: " + i8);
        Log.d(TAG, "mtb_height: " + i9);
        if (this.createMTBScript == null) {
            i12 = i10;
            this.createMTBScript = new ScriptC_create_mtb(this.rs);
            StringBuilder sb = new StringBuilder();
            sb.append("### time after creating createMTBScript: ");
            i13 = i11;
            sb.append(System.currentTimeMillis() - j);
            Log.d(TAG, sb.toString());
        } else {
            i12 = i10;
            i13 = i11;
        }
        Log.d(TAG, "### time after creating createMTBScript: " + (System.currentTimeMillis() - j));
        String str2 = ": median_value: ";
        if (z2) {
            LuminanceInfo[] luminanceInfoArr2 = new LuminanceInfo[allocationArr.length];
            int i30 = 0;
            while (i30 < allocationArr.length) {
                int i31 = i12;
                int i32 = i30;
                LuminanceInfo[] luminanceInfoArr3 = luminanceInfoArr2;
                int i33 = i9;
                int i34 = length;
                String str3 = str2;
                luminanceInfoArr3[i32] = computeMedianLuminance(list.get(i30), i13, i31, i8, i33);
                Log.d(TAG, i32 + str3 + luminanceInfoArr3[i32].median_value);
                i30 = i32 + 1;
                i9 = i33;
                i12 = i31;
                str2 = str3;
                luminanceInfoArr2 = luminanceInfoArr3;
                length = i34;
            }
            i14 = i12;
            luminanceInfoArr = luminanceInfoArr2;
            i15 = i9;
            i16 = i8;
            i17 = length;
            str = str2;
            Log.d(TAG, "time after computeMedianLuminance: " + (System.currentTimeMillis() - j));
        } else {
            i14 = i12;
            i15 = i9;
            i16 = i8;
            i17 = length;
            str = ": median_value: ";
            luminanceInfoArr = null;
        }
        if (!z && z2) {
            Log.d(TAG, "sort bitmaps");
            ArrayList arrayList = new ArrayList(list.size());
            for (int i35 = 0; i35 < list.size(); i35++) {
                arrayList.add(new C1BitmapInfo(luminanceInfoArr[i35], list.get(i35), allocationArr[i35], i35));
            }
            Log.d(TAG, "before sorting:");
            for (int i36 = 0; i36 < allocationArr.length; i36++) {
                Log.d(TAG, "    " + i36 + ": " + luminanceInfoArr[i36]);
            }
            Collections.sort(arrayList, new Comparator<C1BitmapInfo>() { // from class: com.live.gpsmap.camera.Camera.HDRProcessor.1
                @Override // java.util.Comparator
                public int compare(C1BitmapInfo c1BitmapInfo, C1BitmapInfo c1BitmapInfo2) {
                    return c1BitmapInfo.luminanceInfo.compareTo(c1BitmapInfo2.luminanceInfo);
                }
            });
            list.clear();
            for (int i37 = 0; i37 < arrayList.size(); i37++) {
                list.add(((C1BitmapInfo) arrayList.get(i37)).bitmap);
                luminanceInfoArr[i37] = ((C1BitmapInfo) arrayList.get(i37)).luminanceInfo;
                allocationArr[i37] = ((C1BitmapInfo) arrayList.get(i37)).allocation;
            }
            Log.d(TAG, "after sorting:");
            for (int i38 = 0; i38 < allocationArr.length; i38++) {
                Log.d(TAG, "    " + i38 + ": " + luminanceInfoArr[i38]);
            }
            if (sortCallback != null) {
                ArrayList arrayList2 = new ArrayList();
                for (int i39 = 0; i39 < arrayList.size(); i39++) {
                    arrayList2.add(Integer.valueOf(((C1BitmapInfo) arrayList.get(i39)).index));
                }
                Log.d(TAG, "sort_order: " + arrayList2);
                sortCallback.sortOrder(arrayList2);
            }
        }
        if (z2) {
            i18 = luminanceInfoArr[i3].median_value;
            Log.d(TAG, "median_brightness: " + i18);
        } else {
            i18 = -1;
        }
        int i40 = 0;
        while (i40 < allocationArr.length) {
            if (z2) {
                i21 = luminanceInfoArr[i40].median_value;
                Log.d(TAG, i40 + str + i21);
            } else {
                i21 = -1;
            }
            if (z2 && luminanceInfoArr[i40].noisy) {
                Log.d(TAG, "unable to compute median luminance safely");
                allocationArr2[i40] = null;
                i22 = i15;
                i24 = i13;
                i25 = i14;
                i26 = i18;
                i23 = i16;
            } else {
                RenderScript renderScript = this.rs;
                i22 = i15;
                i23 = i16;
                allocationArr2[i40] = Allocation.createTyped(renderScript, Type.createXY(renderScript, Element.U8(renderScript), i23, i22));
                int min = Math.min(Math.max(i21, 5), (int) ItemTouchHelper.Callback.DEFAULT_SWIPE_ANIMATION_DURATION);
                Log.d(TAG, i40 + ": median_value is now: " + min);
                if (z2) {
                    this.createMTBScript.set_median_value(min);
                }
                i24 = i13;
                this.createMTBScript.set_start_x(i24);
                i25 = i14;
                this.createMTBScript.set_start_y(i25);
                this.createMTBScript.set_out_bitmap(allocationArr2[i40]);
                Log.d(TAG, "call createMTBScript");
                Script.LaunchOptions launchOptions = new Script.LaunchOptions();
                launchOptions.setX(i24, i24 + i23);
                launchOptions.setY(i25, i25 + i22);
                if (z2) {
                    this.createMTBScript.forEach_create_mtb(allocationArr[i40], launchOptions);
                } else if (z3 && i40 == 0) {
                    this.createMTBScript.forEach_create_greyscale_f(allocationArr[i40], launchOptions);
                } else {
                    this.createMTBScript.forEach_create_greyscale(allocationArr[i40], launchOptions);
                }
                StringBuilder sb2 = new StringBuilder();
                sb2.append("time after createMTBScript: ");
                i26 = i18;
                sb2.append(System.currentTimeMillis() - j);
                Log.d(TAG, sb2.toString());
            }
            i40++;
            i13 = i24;
            i14 = i25;
            i16 = i23;
            i15 = i22;
            i18 = i26;
        }
        int i41 = i15;
        int i42 = i18;
        int i43 = i16;
        Log.d(TAG, "### time after all createMTBScript: " + (System.currentTimeMillis() - j));
        int max = Math.max(i6, i7);
        int i44 = (i5 * max) / 150;
        int i45 = 1;
        while (i45 < i44) {
            i45 *= 2;
        }
        Log.d(TAG, "max_dim: " + max);
        Log.d(TAG, "max_ideal_size: " + i44);
        Log.d(TAG, "initial_step_size: " + i45);
        if (allocationArr2[i3] == null) {
            Log.d(TAG, "base image not suitable for image alignment");
            int i46 = i17;
            for (int i47 = 0; i47 < i46; i47++) {
                Allocation allocation2 = allocationArr2[i47];
                if (allocation2 != null) {
                    allocation2.destroy();
                    allocationArr2[i47] = null;
                }
            }
            return new BrightnessDetails(i42);
        }
        int i48 = i17;
        if (this.alignMTBScript == null) {
            this.alignMTBScript = new ScriptC_align_mtb(this.rs);
        }
        this.alignMTBScript.set_bitmap0(allocationArr2[i3]);
        int i49 = 0;
        while (i49 < allocationArr.length) {
            if (i49 != i3) {
                Allocation allocation3 = allocationArr2[i49];
                if (allocation3 == null) {
                    Log.d(TAG, "image " + i49 + ":::");
                } else {
                    this.alignMTBScript.set_bitmap1(allocation3);
                    int i50 = i4;
                    int i51 = i45;
                    while (i51 > i50) {
                        int i52 = i51 / 2;
                        int i53 = i52 * 1;
                        if (i53 > i43 || i53 > i41) {
                            i53 = i52;
                        }
                        Log.d(TAG, "call alignMTBScript for image: " + i49);
                        Log.d(TAG, "    versus base image: " + i3);
                        Log.d(TAG, "step_size: " + i52);
                        Log.d(TAG, "pixel_step_size: " + i53);
                        this.alignMTBScript.set_off_x(iArr[i49]);
                        this.alignMTBScript.set_off_y(iArr2[i49]);
                        this.alignMTBScript.set_step_size(i53);
                        RenderScript renderScript2 = this.rs;
                        int i54 = i45;
                        Allocation createSized = Allocation.createSized(renderScript2, Element.I32(renderScript2), 9);
                        this.alignMTBScript.bind_errors(createSized);
                        this.alignMTBScript.invoke_init_errors();
                        Script.LaunchOptions launchOptions2 = new Script.LaunchOptions();
                        int i55 = i43 / i53;
                        int i56 = i41 / i53;
                        StringBuilder sb3 = new StringBuilder();
                        int i57 = i43;
                        sb3.append("stop_x: ");
                        sb3.append(i55);
                        Log.d(TAG, sb3.toString());
                        Log.d(TAG, "stop_y: " + i56);
                        launchOptions2.setX(0, i55);
                        launchOptions2.setY(0, i56);
                        long currentTimeMillis = System.currentTimeMillis();
                        if (z2) {
                            this.alignMTBScript.forEach_align_mtb(allocationArr2[i3], launchOptions2);
                        } else {
                            this.alignMTBScript.forEach_align(allocationArr2[i3], launchOptions2);
                        }
                        Log.d(TAG, "time for alignMTBScript: " + (System.currentTimeMillis() - currentTimeMillis));
                        Log.d(TAG, "time for alignMTBScript2: " + (System.currentTimeMillis() - j));
                        int[] iArr3 = new int[9];
                        createSized.copyTo(iArr3);
                        createSized.destroy();
                        int i58 = 0;
                        int i59 = -1;
                        int i60 = -1;
                        for (int i61 = 9; i58 < i61; i61 = 9) {
                            int i62 = iArr3[i58];
                            Log.d(TAG, "    errors[" + i58 + "]: " + i62);
                            if (i59 == -1 || i62 < i60) {
                                i59 = i58;
                                i60 = i62;
                            }
                            i58++;
                        }
                        Log.d(TAG, "    best_id " + i59 + " error: " + i60);
                        if (i60 >= 2000000000) {
                            Log.e(TAG, "    auto-alignment failed due to overflow");
                            i59 = 4;
                            if (this.is_test) {
                                throw new RuntimeException();
                            }
                        }
                        if (i59 != -1) {
                            int i63 = (i59 % 3) - 1;
                            int i64 = (i59 / 3) - 1;
                            Log.d(TAG, "this_off_x" + i63);
                            Log.d(TAG, "this_off_y: " + i64);
                            iArr[i49] = iArr[i49] + (i63 * i52);
                            iArr2[i49] = iArr2[i49] + (i64 * i52);
                            Log.d(TAG, "offsets_x is now: " + iArr[i49]);
                            Log.d(TAG, "offsets_y is now: " + iArr2[i49]);
                        }
                        i51 = i52;
                        i50 = i4;
                        i45 = i54;
                        i43 = i57;
                    }
                    i19 = i45;
                    i20 = i43;
                    Log.d(TAG, "resultant offsets for image: " + i49);
                    Log.d(TAG, "resultant offsets_x: " + iArr[i49]);
                    Log.d(TAG, "resultant offsets_y: " + iArr2[i49]);
                    i49++;
                    i45 = i19;
                    i43 = i20;
                }
            }
            i19 = i45;
            i20 = i43;
            i49++;
            i45 = i19;
            i43 = i20;
        }
        for (int i65 = 0; i65 < i48; i65++) {
            Allocation allocation4 = allocationArr2[i65];
            if (allocation4 != null) {
                allocation4.destroy();
                allocationArr2[i65] = null;
            }
        }
        return new BrightnessDetails(i42);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.live.gpsmap.camera.Camera.HDRProcessor$1BitmapInfo  reason: invalid class name */
    /* loaded from: classes.dex */
    public class C1BitmapInfo {
        final Allocation allocation;
        final Bitmap bitmap;
        final int index;
        final LuminanceInfo luminanceInfo;

        C1BitmapInfo(LuminanceInfo luminanceInfo, Bitmap bitmap, Allocation allocation, int i) {
            this.luminanceInfo = luminanceInfo;
            this.bitmap = bitmap;
            this.allocation = allocation;
            this.index = i;
        }
    }

    /* loaded from: classes.dex */
    public static class LuminanceInfo implements Comparable<LuminanceInfo> {
        final int hi_value;
        final int median_value;
        final int min_value;
        final boolean noisy;

        public LuminanceInfo(int i, int i2, int i3, boolean z) {
            this.min_value = i;
            this.median_value = i2;
            this.hi_value = i3;
            this.noisy = z;
        }

        public String toString() {
            return "min: " + this.min_value + " , median: " + this.median_value + " , hi: " + this.hi_value + " , noisy: " + this.noisy;
        }

        @Override // java.lang.Comparable
        public int compareTo(LuminanceInfo luminanceInfo) {
            int i = this.median_value - luminanceInfo.median_value;
            if (i == 0) {
                i = this.min_value - luminanceInfo.min_value;
            }
            return i == 0 ? this.hi_value - luminanceInfo.hi_value : i;
        }
    }

    private LuminanceInfo computeMedianLuminance(Bitmap bitmap, int i, int i2, int i3, int i4) {
        int i5;
        String str;
        double d = 0;
        boolean z;
        int i6 = i4;
        String str2 = TAG;
        Log.d(TAG, "computeMedianLuminance");
        Log.d(TAG, "mtb_x: " + i);
        Log.d(TAG, "mtb_y: " + i2);
        Log.d(TAG, "mtb_width: " + i3);
        Log.d(TAG, "mtb_height: " + i6);
        int sqrt = (int) Math.sqrt(100.0d);
        int i7 = 100 / sqrt;
        int[] iArr = new int[256];
        for (int i8 = 0; i8 < 256; i8++) {
            iArr[i8] = 0;
        }
        int i9 = 0;
        int i10 = 0;
        while (true) {
            i5 = 255;
            if (i9 >= i7) {
                break;
            }
            int[] iArr2 = iArr;
            int i11 = i9;
            int i12 = ((int) (((i9 + 1.0d) / (i7 + 1.0d)) * i6)) + i2;
            int i13 = 0;
            while (i13 < sqrt) {
                int pixel = bitmap.getPixel(((int) (((i13 + 1.0d) / (sqrt + 1.0d)) * i3)) + i, i12);
                int max = Math.max(Math.max((16711680 & pixel) >> 16, (65280 & pixel) >> 8), pixel & 255);
                iArr2[max] = iArr2[max] + 1;
                i10++;
                i13++;
                str2 = str2;
            }
            i9 = i11 + 1;
            i6 = i4;
            iArr = iArr2;
            str2 = str2;
        }
        String str3 = str2;
        int[] iArr3 = iArr;
        int i14 = i10 / 2;
        int i15 = 0;
        while (true) {
            if (i5 < 0) {
                str = str3;
                i5 = -1;
                break;
            }
            i15 += iArr3[i5];
            if (i15 >= i10 / 10) {
                str = str3;
                Log.d(str, "hi luminance " + i5);
                break;
            }
            i5--;
        }
        int i16 = -1;
        int i17 = 0;
        for (int i18 = 0; i18 < 256; i18++) {
            int i19 = iArr3[i18];
            i17 += i19;
            if (i16 == -1 && i19 > 0) {
                Log.d(str, "min luminance " + i18);
                i16 = i18;
            }
            if (i17 >= i14) {
                Log.d(str, "median luminance " + i18);
                int i20 = 0;
                for (int i21 = 0; i21 <= i18 - 4; i21++) {
                    i20 += iArr3[i21];
                }
                int i22 = 0;
                for (int i23 = 0; i23 <= i18 + 4 && i23 < 256; i23++) {
                    i22 += iArr3[i23];
                }
                double d2 = i20 / i10;
                int i24 = i18;
                Log.d(str, "count: " + i17);
                Log.d(str, "n_below: " + i20);
                Log.d(str, "n_above: " + i22);
                Log.d(str, "frac_below: " + d2);
                Log.d(str, "frac_above: " + (1.0d - (((double) i22) / d)));
                if (d2 < 0.2d) {
                    Log.d(str, "too dark/noisy");
                    z = true;
                } else {
                    z = false;
                }
                return new LuminanceInfo(i16, i24, i5, z);
            }
        }
        Log.e(str, "computeMedianLuminance failed");
        return new LuminanceInfo(i16, 127, i5, true);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void adjustHistogram(Allocation allocation, Allocation allocation2, int i, int i2, float f, int i3, boolean z, long j) {
        int i4;
        ScriptC_histogram_compute scriptC_histogram_compute;
        int i5;
        int i6;
        int i7 = i;
        int i8 = i2;
        Log.d(TAG, "adjustHistogram");
        RenderScript renderScript = this.rs;
        Allocation createSized = Allocation.createSized(renderScript, Element.I32(renderScript), 256);
        Log.d(TAG, "create histogramScript");
        ScriptC_histogram_compute scriptC_histogram_compute2 = new ScriptC_histogram_compute(this.rs);
        Log.d(TAG, "bind histogram allocation");
        scriptC_histogram_compute2.bind_histogram(createSized);
        int i9 = i3 * i3 * 256;
        int[] iArr = new int[i9];
        int[] iArr2 = new int[256];
        int i10 = 0;
        while (i10 < i3) {
            double d = i10;
            int i11 = i10;
            double d2 = i3;
            int i12 = i9;
            double d3 = i7;
            int[] iArr3 = iArr;
            int[] iArr4 = iArr2;
            int i13 = (int) ((d / d2) * d3);
            int i14 = (int) (((d + 1.0d) / d2) * d3);
            if (i14 != i13) {
                int i15 = 0;
                while (i15 < i3) {
                    double d4 = i15;
                    double d5 = d2;
                    double d6 = i8;
                    int i16 = (int) ((d4 / d2) * d6);
                    int i17 = (int) (((d4 + 1.0d) / d2) * d6);
                    if (i17 == i16) {
                        scriptC_histogram_compute = scriptC_histogram_compute2;
                        i5 = i14;
                    } else {
                        Script.LaunchOptions launchOptions = new Script.LaunchOptions();
                        launchOptions.setX(i13, i14);
                        launchOptions.setY(i16, i17);
                        scriptC_histogram_compute2.invoke_init_histogram();
                        scriptC_histogram_compute2.forEach_histogram_compute_by_value(allocation, launchOptions);
                        int[] iArr5 = new int[256];
                        createSized.copyTo(iArr5);
                        int i18 = (i14 - i13) * (i17 - i16);
                        int i19 = (i18 * 5) / 256;
                        int i20 = i19;
                        int i21 = 0;
                        while (true) {
                            i4 = 1;
                            if (i20 - i21 <= 1) {
                                break;
                            }
                            int i22 = (i20 + i21) / 2;
                            ScriptC_histogram_compute scriptC_histogram_compute3 = scriptC_histogram_compute2;
                            int i23 = i14;
                            int i24 = 0;
                            int i25 = 0;
                            for (int i26 = 256; i25 < i26; i26 = 256) {
                                int i27 = iArr5[i25];
                                if (i27 > i22) {
                                    i24 += i27 - i19;
                                }
                                i25++;
                            }
                            if (i24 > (i19 - i22) * 256) {
                                i20 = i22;
                            } else {
                                i21 = i22;
                            }
                            scriptC_histogram_compute2 = scriptC_histogram_compute3;
                            i14 = i23;
                        }
                        scriptC_histogram_compute = scriptC_histogram_compute2;
                        i5 = i14;
                        int i28 = (i20 + i21) / 2;
                        int i29 = 0;
                        int i30 = 0;
                        for (int i31 = 256; i29 < i31; i31 = 256) {
                            int i32 = iArr5[i29];
                            if (i32 > i28) {
                                i30 += i32 - i28;
                                iArr5[i29] = i28;
                            }
                            i29++;
                        }
                        int i33 = i30 / 256;
                        for (int i34 = 0; i34 < 256; i34++) {
                            iArr5[i34] = iArr5[i34] + i33;
                        }
                        if (z) {
                            iArr4[0] = iArr5[0];
                            int i35 = 1;
                            for (int i36 = 256; i35 < i36; i36 = 256) {
                                iArr4[i35] = iArr4[i35 - 1] + iArr5[i35];
                                i35++;
                            }
                            int i37 = i18 / 256;
                            Log.d(TAG, "equal_limit: " + i37);
                            int i38 = 0;
                            while (i38 < 128) {
                                int i39 = i38 + 1;
                                if (iArr4[i38] < i37 * i39) {
                                    int i40 = (int) ((1.0f - (i38 / 128.0f)) * i37);
                                    Log.d(TAG, "x: " + i38 + " ; limit: " + i40);
                                    if (iArr5[i38] < i40) {
                                        for (int i41 = i39; i41 < 256 && (i6 = iArr5[i38]) < i40; i41++) {
                                            int i42 = iArr5[i41];
                                            if (i42 > i37) {
                                                int min = Math.min(i42 - i37, i40 - i6);
                                                iArr5[i38] = iArr5[i38] + min;
                                                iArr5[i41] = iArr5[i41] - min;
                                            }
                                        }
                                        Log.d(TAG, "    histogram pulled up to: " + iArr5[i38]);
                                    }
                                }
                                i38 = i39;
                            }
                        }
                        int i43 = ((i11 * i3) + i15) * 256;
                        iArr3[i43] = iArr5[0];
                        for (int i44 = 256; i4 < i44; i44 = 256) {
                            int i45 = i43 + i4;
                            iArr3[i45] = iArr3[i45 - 1] + iArr5[i4];
                            i4++;
                        }
                        for (int i46 = 0; i46 < 256; i46++) {
                            Log.d(TAG, "histogram[" + i46 + "] = " + iArr5[i46] + " cumulative: " + iArr3[i43 + i46]);
                        }
                    }
                    i15++;
                    i8 = i2;
                    scriptC_histogram_compute2 = scriptC_histogram_compute;
                    i14 = i5;
                    d2 = d5;
                }
            }
            i10 = i11 + 1;
            i7 = i;
            i8 = i2;
            scriptC_histogram_compute2 = scriptC_histogram_compute2;
            i9 = i12;
            iArr = iArr3;
            iArr2 = iArr4;
        }
        Log.d(TAG, "time after creating histograms: " + (System.currentTimeMillis() - j));
        RenderScript renderScript2 = this.rs;
        Allocation createSized2 = Allocation.createSized(renderScript2, Element.I32(renderScript2), i9);
        createSized2.copyFrom(iArr);
        ScriptC_histogram_adjust scriptC_histogram_adjust = new ScriptC_histogram_adjust(this.rs);
        scriptC_histogram_adjust.set_c_histogram(createSized2);
        scriptC_histogram_adjust.set_hdr_alpha(f);
        scriptC_histogram_adjust.set_n_tiles(i3);
        scriptC_histogram_adjust.set_width(i);
        scriptC_histogram_adjust.set_height(i2);
        Log.d(TAG, "time before histogramAdjustScript: " + (System.currentTimeMillis() - j));
        scriptC_histogram_adjust.forEach_histogram_adjust(allocation, allocation2);
        Log.d(TAG, "time after histogramAdjustScript: " + (System.currentTimeMillis() - j));
        createSized.destroy();
        createSized2.destroy();
    }

    private Allocation computeHistogramAllocation(Allocation allocation, boolean z, boolean z2, long j) {
        Log.d(TAG, "computeHistogramAllocation");
        RenderScript renderScript = this.rs;
        Allocation createSized = Allocation.createSized(renderScript, Element.I32(renderScript), 256);
        Log.d(TAG, "create histogramScript");
        ScriptC_histogram_compute scriptC_histogram_compute = new ScriptC_histogram_compute(this.rs);
        Log.d(TAG, "bind histogram allocation");
        scriptC_histogram_compute.bind_histogram(createSized);
        scriptC_histogram_compute.invoke_init_histogram();
        Log.d(TAG, "call histogramScript");
        Log.d(TAG, "time before histogramScript: " + (System.currentTimeMillis() - j));
        if (z) {
            if (z2) {
                scriptC_histogram_compute.forEach_histogram_compute_by_intensity_f(allocation);
            } else {
                scriptC_histogram_compute.forEach_histogram_compute_by_intensity(allocation);
            }
        } else if (z2) {
            scriptC_histogram_compute.forEach_histogram_compute_by_value_f(allocation);
        } else {
            scriptC_histogram_compute.forEach_histogram_compute_by_value(allocation);
        }
        Log.d(TAG, "time after histogramScript: " + (System.currentTimeMillis() - j));
        return createSized;
    }

    public int[] computeHistogram(Bitmap bitmap, boolean z) {
        Log.d(TAG, "computeHistogram");
        long currentTimeMillis = System.currentTimeMillis();
        initRenderscript();
        Allocation createFromBitmap = Allocation.createFromBitmap(this.rs, bitmap);
        Log.d(TAG, "time after createFromBitmap: " + (System.currentTimeMillis() - currentTimeMillis));
        int[] computeHistogram = computeHistogram(createFromBitmap, z, false);
        createFromBitmap.destroy();
        freeScripts();
        return computeHistogram;
    }

    private int[] computeHistogram(Allocation allocation, boolean z, boolean z2) {
        Log.d(TAG, "computeHistogram");
        int[] iArr = new int[256];
        Allocation computeHistogramAllocation = computeHistogramAllocation(allocation, z, z2, System.currentTimeMillis());
        computeHistogramAllocation.copyTo(iArr);
        computeHistogramAllocation.destroy();
        return iArr;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class HistogramInfo {
        final int max_brightness;
        final int mean_brightness;
        final int median_brightness;
        final int total;

        HistogramInfo(int i, int i2, int i3, int i4) {
            this.total = i;
            this.mean_brightness = i2;
            this.median_brightness = i3;
            this.max_brightness = i4;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public HistogramInfo getHistogramInfo(int[] iArr) {
        int i = 0;
        for (int i2 : iArr) {
            i += i2;
        }
        int i3 = i / 2;
        double d = 0.0d;
        int i4 = 0;
        int i5 = 0;
        int i6 = -1;
        for (int i7 = 0; i7 < iArr.length; i7++) {
            int i8 = iArr[i7];
            i4 += i8;
            d += i8 * i7;
            if (i4 >= i3 && i6 == -1) {
                i6 = i7;
            }
            if (i8 > 0) {
                i5 = i7;
            }
        }
        return new HistogramInfo(i, (int) ((d / i4) + 0.1d), i6, i5);
    }

    private static int getBrightnessTarget(int i, float f, int i2) {
        if (i > 0) {
            f = Math.min(Math.max(f, 42.0f / i), 15.0f);
        }
        if (i <= 0) {
            i = 1;
        }
        Log.d(TAG, "brightness: " + i);
        Log.d(TAG, "max_gain_factor: " + f);
        Log.d(TAG, "ideal_brightness: " + i2);
        return Math.max(i, Math.min(i2, (int) (f * i)));
    }

    /* loaded from: classes3.dex */
    public static class BrightenFactors {
        public final float gain;
        public final float gamma;
        public final float low_x;
        public final float mid_x;

        BrightenFactors(float f, float f2, float f3, float f4) {
            this.gain = f;
            this.low_x = f2;
            this.mid_x = f3;
            this.gamma = f4;
        }
    }

    public static BrightenFactors computeBrightenFactors(boolean z, int i, long j, int i2, int i3) {
        int i4 = (!z || i >= 1100 || j >= 16949152) ? 119 : 199;
        int brightnessTarget = getBrightnessTarget(i2, 1.5f, i4);
        Log.d(TAG, "brightness: " + i2);
        Log.d(TAG, "max_brightness: " + i3);
        Log.d(TAG, "ideal_brightness: " + i4);
        Log.d(TAG, "brightness target: " + brightnessTarget);
        return computeBrightenFactors(z, i, j, i2, i3, brightnessTarget, true);
    }

    private static BrightenFactors computeBrightenFactors(boolean z, int i, long j, int i2, int i3, int i4, boolean z2) {
        float f = 0;
        if (i2 <= 0) {
            i2 = 1;
        }
        float f2 = i4 / i2;
        Log.d(TAG, "gain " + f2);
        float f3 = 1.0f;
        if (f2 < 1.0f && z2) {
            Log.d(TAG, "clamped gain to: 1.0");
            f2 = 1.0f;
        }
        float f4 = i3;
        float f5 = f2 * f4;
        Log.d(TAG, "max_possible_value: " + f5);
        float f6 = 255.5f;
        if (f5 > 255.0f) {
            Log.d(TAG, "use piecewise gain/gamma");
            f6 = ((!z || i >= 1100 || j >= 16949152) ? 204.0f : 153.0f) / f2;
            f3 = (float) (Math.log(f / 255.0f) / Math.log(f6 / f4));
        } else if (z2 && f5 < 255.0f && i3 > 0) {
            float min = Math.min(255.0f / f4, 4.0f);
            Log.d(TAG, "alt_gain: " + min);
            if (min > f2) {
                Log.d(TAG, "increased gain to: " + min);
                f2 = min;
            }
        }
        float f7 = 0.0f;
        if (z && i >= 400) {
            f7 = Math.min(8.0f, (127.5f / f2) * 0.125f);
        }
        Log.d(TAG, "low_x " + f7);
        Log.d(TAG, "mid_x " + f6);
        Log.d(TAG, "gamma " + f3);
        return new BrightenFactors(f2, f7, f6, f3);
    }

    public Bitmap avgBrighten(Allocation allocation, int i, int i2, int i3, long j) {
        Log.d(TAG, "avgBrighten");
        Log.d(TAG, "iso: " + i3);
        Log.d(TAG, "exposure_time: " + j);
        initRenderscript();
        long currentTimeMillis = System.currentTimeMillis();
        int[] computeHistogram = computeHistogram(allocation, false, true);
        HistogramInfo histogramInfo = getHistogramInfo(computeHistogram);
        int i4 = histogramInfo.median_brightness;
        int i5 = histogramInfo.max_brightness;
        Log.d(TAG, "### time after computeHistogram: " + (System.currentTimeMillis() - currentTimeMillis));
        Log.d(TAG, "median brightness: " + histogramInfo.median_brightness);
        Log.d(TAG, "mean brightness: " + histogramInfo.mean_brightness);
        Log.d(TAG, "max brightness: " + i5);
        BrightenFactors computeBrightenFactors = computeBrightenFactors(true, i3, j, i4, i5);
        float f = computeBrightenFactors.gain;
        float f2 = computeBrightenFactors.low_x;
        float f3 = computeBrightenFactors.mid_x;
        float f4 = computeBrightenFactors.gamma;
        ScriptC_avg_brighten scriptC_avg_brighten = new ScriptC_avg_brighten(this.rs);
        scriptC_avg_brighten.set_bitmap(allocation);
        int i6 = (int) (histogramInfo.total * 0.001f);
        int i7 = -1;
        int i8 = 0;
        for (int i9 = 0; i9 < computeHistogram.length; i9++) {
            int i10 = i8 + computeHistogram[i9];
            i8 = i10;
            if (i10 >= i6 && i7 == -1) {
                i7 = i9;
            }
        }
        float min = Math.min(Math.max(0.0f, i7), i3 <= 700 ? 18.0f : 4.0f);
        Log.d(TAG, "percentile: " + i6);
        Log.d(TAG, "darkest_brightness: " + i7);
        Log.d(TAG, "black_level is now: " + min);
        scriptC_avg_brighten.invoke_setBlackLevel(min);
        float f5 = this.cached_avg_sample_size >= 2 ? 0.5f : 1.0f;
        Log.d(TAG, "median_filter_strength: " + f5);
        scriptC_avg_brighten.set_median_filter_strength(f5);
        scriptC_avg_brighten.invoke_setBrightenParameters(f, f4, f2, f3, (float) i5);
        Bitmap createBitmap = Bitmap.createBitmap(i, i2, Bitmap.Config.ARGB_8888);
        Allocation createFromBitmap = Allocation.createFromBitmap(this.rs, createBitmap);
        Log.d(TAG, "### time after creating allocation_out: " + (System.currentTimeMillis() - currentTimeMillis));
        scriptC_avg_brighten.forEach_avg_brighten_f(allocation, createFromBitmap);
        Log.d(TAG, "### time after avg_brighten: " + (System.currentTimeMillis() - currentTimeMillis));
        if (i3 < 1100 && j < 16949152) {
            float min2 = Math.min(Math.max((histogramInfo.median_brightness - 60) / (-25.0f), 0.0f), 1.0f);
            float f6 = ((1.0f - min2) * 0.25f) + (0.5f * min2);
            Log.d(TAG, "dro alpha: " + min2);
            Log.d(TAG, "dro amount: " + f6);
            adjustHistogram(createFromBitmap, createFromBitmap, i, i2, f6, 1, true, currentTimeMillis);
            Log.d(TAG, "### time after adjustHistogram: " + (System.currentTimeMillis() - currentTimeMillis));
        }
        createFromBitmap.copyTo(createBitmap);
        createFromBitmap.destroy();
        Log.d(TAG, "### time after copying to bitmap: " + (System.currentTimeMillis() - currentTimeMillis));
        freeScripts();
        Log.d(TAG, "### total time for avgBrighten: " + (System.currentTimeMillis() - currentTimeMillis));
        return createBitmap;
    }

    private float computeSharpness(Allocation allocation, int i, long j) {
        Log.d(TAG, "computeSharpness");
        Log.d(TAG, "### time: " + (System.currentTimeMillis() - j));
        RenderScript renderScript = this.rs;
        Allocation createSized = Allocation.createSized(renderScript, Element.I32(renderScript), i);
        Log.d(TAG, "### time after createSized: " + (System.currentTimeMillis() - j));
        ScriptC_calculate_sharpness scriptC_calculate_sharpness = new ScriptC_calculate_sharpness(this.rs);
        Log.d(TAG, "### time after create sharpnessScript: " + (System.currentTimeMillis() - j));
        Log.d(TAG, "bind sums allocation");
        scriptC_calculate_sharpness.bind_sums(createSized);
        scriptC_calculate_sharpness.set_bitmap(allocation);
        scriptC_calculate_sharpness.set_width(i);
        scriptC_calculate_sharpness.invoke_init_sums();
        Log.d(TAG, "call sharpnessScript");
        Log.d(TAG, "### time before sharpnessScript: " + (System.currentTimeMillis() - j));
        scriptC_calculate_sharpness.forEach_calculate_sharpness(allocation);
        Log.d(TAG, "### time after sharpnessScript: " + (System.currentTimeMillis() - j));
        int[] iArr = new int[i];
        createSized.copyTo(iArr);
        createSized.destroy();
        float f = 0.0f;
        for (int i2 = 0; i2 < i; i2++) {
            f += iArr[i2];
        }
        Log.d(TAG, "total_sum: " + f);
        return f;
    }
}
