package com.live.gpsmap.camera.Camera;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.preference.PreferenceManager;
import android.util.Log;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.live.gpsmap.camera.BuildConfig;
import com.live.gpsmap.camera.R;
import java.util.ArrayList;

@SuppressWarnings("All")
public class PermissionHandler {
    private static final int MY_PERMISSIONS_REQUEST_CAMERA = 0;
    private static final int MY_PERMISSIONS_REQUEST_LOCATION = 3;
    private static final int MY_PERMISSIONS_REQUEST_RECORD_AUDIO = 2;
    private static final int MY_PERMISSIONS_REQUEST_STORAGE = 1;
    public static final int PERMISSION_REQUEST_CODE = 16;
    private static final String TAG = "PermissionHandler";
    static int isCameraPermission;
    static int isLocationPermission;
    static int isStoragePermision;
    AlertDialog alertSimpleDialog;
    public int isStoragePermission = 0;
    int isactivityopen = 0;
    private boolean mRequestPermissions;
    private final CameraMainActivity main_activity;

    public PermissionHandler(CameraMainActivity mainActivity) {
        this.main_activity = mainActivity;
    }

    public void showSimpleDialog() {
        try {
            int i = this.isStoragePermission;
            if (i == 0) {
                this.isStoragePermission = i + 1;
                AlertDialog alertDialog = this.alertSimpleDialog;
                if (alertDialog != null) {
                    if (!alertDialog.isShowing()) {
                        this.alertSimpleDialog.show();
                    }
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this.main_activity);
                    builder.setTitle(this.main_activity.getResources().getString(R.string.permission_denied_title));
                    builder.setMessage(this.main_activity.getResources().getString(R.string.allow_for_smooth));
                    builder.setCancelable(false);
                    builder.setPositiveButton(this.main_activity.getResources().getString(R.string.action_settings), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i2) {
                            Intent intent = new Intent();
                            intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                            intent.setData(Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                            PermissionHandler.this.isactivityopen = 1;
                            PermissionHandler.this.main_activity.startActivity(intent);
                        }
                    });
                    AlertDialog create = builder.create();
                    this.alertSimpleDialog = create;
                    create.show();
                    this.alertSimpleDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialogInterface) {
                            PermissionHandler.this.isStoragePermission = 0;
                        }
                    });
                }
            }
        } catch (Exception unused) {
        }
    }

    private void isDontAskAgain(int i) {
        int i2;
        if (Build.VERSION.SDK_INT < 23) {
            Log.e(TAG, "shouldn't be requesting permissions for pre-Android M!");
            return;
        }
        if (i == 0) {
            i2 = isCameraPermission;
            isCameraPermission = i2 + 1;
        } else if (i == 1) {
            i2 = isStoragePermision;
            isStoragePermision = i2 + 1;
        } else if (i != 3) {
            i2 = -1;
        } else {
            i2 = isLocationPermission;
            isLocationPermission = i2 + 1;
        }
        if (i2 == 0) {
            this.main_activity.flag_prermission = 1;
            AlertDialog.Builder builder = new AlertDialog.Builder(this.main_activity);
            builder.setTitle(this.main_activity.getResources().getString(R.string.permission_denied_title));
            builder.setMessage(this.main_activity.getResources().getString(R.string.allow_for_smooth));
            builder.setPositiveButton(this.main_activity.getResources().getString(R.string.action_settings), new DialogInterface.OnClickListener() { // from class: com.live.gpsmap.camera.Camera.PermissionHandler.3
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i3) {
                    Intent intent = new Intent();
                    intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                    intent.setData(Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                    PermissionHandler.this.main_activity.startActivity(intent);
                }
            });
            builder.create().show();
        }
    }

    void requestCameraPermission() {
        if (checkPermissions() && this.isStoragePermission == 0) {
            Log.d(TAG, "requestCameraPermission");
            if (Build.VERSION.SDK_INT < 23) {
                Log.e(TAG, "shouldn't be requesting permissions for pre-Android M!");
            } else if (ActivityCompat.shouldShowRequestPermissionRationale(this.main_activity, "android.permission.CAMERA")) {
            } else {
                Log.d(TAG, "requesting camera permission...");
                ActivityCompat.requestPermissions(this.main_activity, new String[]{"android.permission.CAMERA", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.ACCESS_FINE_LOCATION"}, 0);
            }
        }
    }

    void requestStoragePermission() {
        if (checkPermissions() && this.isStoragePermission == 0) {
            Log.d(TAG, "requestStoragePermission");
            if (Build.VERSION.SDK_INT < 23) {
                Log.e(TAG, "shouldn't be requesting permissions for pre-Android M!");
            } else if (ActivityCompat.shouldShowRequestPermissionRationale(this.main_activity, "android.permission.WRITE_EXTERNAL_STORAGE")) {
            } else {
                Log.d(TAG, "requesting storage permission...");
                ActivityCompat.requestPermissions(this.main_activity, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 1);
            }
        }
    }

    void requestRecordAudioPermission() {
        if (checkPermissions() && this.isStoragePermission == 0) {
            Log.d(TAG, "requestRecordAudioPermission");
            if (Build.VERSION.SDK_INT < 23) {
                Log.e(TAG, "shouldn't be requesting permissions for pre-Android M!");
            } else if (ActivityCompat.shouldShowRequestPermissionRationale(this.main_activity, "android.permission.RECORD_AUDIO")) {
            } else {
                Log.d(TAG, "requesting record audio permission...");
                ActivityCompat.requestPermissions(this.main_activity, new String[]{"android.permission.RECORD_AUDIO"}, 2);
            }
        }
    }

    boolean checkStoragePermission() {
        boolean z = ContextCompat.checkSelfPermission(this.main_activity, "android.permission.READ_EXTERNAL_STORAGE") == 0;
        if (ContextCompat.checkSelfPermission(this.main_activity, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            z = false;
        }
        if (ContextCompat.checkSelfPermission(this.main_activity, "android.permission.CAMERA") != 0) {
            z = false;
        }
        if (ContextCompat.checkSelfPermission(this.main_activity, "android.permission.ACCESS_FINE_LOCATION") != 0) {
            return false;
        }
        return z;
    }

    void requestLocationPermission() {
        if (checkPermissions()) {
            Log.d(TAG, "requestLocationPermission");
            if (Build.VERSION.SDK_INT < 23) {
                Log.e(TAG, "shouldn't be requesting permissions for pre-Android M!");
            } else if (ActivityCompat.shouldShowRequestPermissionRationale(this.main_activity, "android.permission.ACCESS_FINE_LOCATION")) {
            } else {
                Log.d(TAG, "requesting location permissions...");
                ActivityCompat.requestPermissions(this.main_activity, new String[]{"android.permission.ACCESS_FINE_LOCATION"}, 3);
            }
        }
    }

    public void onRequestPermissionsResult(int i, int[] iArr) {
        Log.d(TAG, "onRequestPermissionsResult: requestCode " + i);
        if (Build.VERSION.SDK_INT < 23) {
            Log.e(TAG, "shouldn't be requesting permissions for pre-Android M!");
            return;
        }
        if (i == 16 && !checkStoragePermission()) {
            if (!ActivityCompat.shouldShowRequestPermissionRationale(this.main_activity, "android.permission.CAMERA")) {
                showSimpleDialog();
            } else if (!ActivityCompat.shouldShowRequestPermissionRationale(this.main_activity, "android.permission.ACCESS_FINE_LOCATION")) {
                showSimpleDialog();
            } else if (!ActivityCompat.shouldShowRequestPermissionRationale(this.main_activity, "android.permission.WRITE_EXTERNAL_STORAGE")) {
                showSimpleDialog();
            }
        }
        if (i == 0) {
            if (iArr.length > 0 && iArr[0] == 0) {
                Log.d(TAG, "camera permission granted");
                this.main_activity.getPreview().retryOpenCamera();
                return;
            }
            ActivityCompat.shouldShowRequestPermissionRationale(this.main_activity, "android.permission.CAMERA");
        } else if (i == 1) {
            if (iArr.length > 0 && iArr[0] == 0) {
                Log.d(TAG, "storage permission granted");
                this.main_activity.getPreview().retryOpenCamera();
                return;
            }
            ActivityCompat.shouldShowRequestPermissionRationale(this.main_activity, "android.permission.WRITE_EXTERNAL_STORAGE");
        } else if (i == 2) {
            if (iArr.length > 0 && iArr[0] == 0) {
                Log.d(TAG, "record audio permission granted");
            } else {
                Log.d(TAG, "record audio permission denied");
            }
        } else if (i == 3) {
            if (iArr.length > 0 && iArr[0] == 0) {
                Log.d(TAG, "location permission granted");
            } else if (ActivityCompat.shouldShowRequestPermissionRationale(this.main_activity, "android.permission.ACCESS_FINE_LOCATION")) {
                Log.d(TAG, "location permission denied");
                Log.d(TAG, "location permission not available, so switch location off");
                this.main_activity.getPreview().showToast((ToastBoxer) null, R.string.permission_location_not_available);
                SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(this.main_activity).edit();
                edit.putBoolean(PreferenceKeys.LocationPreferenceKey, true);
                edit.apply();
            } else {
                SharedPreferences.Editor edit2 = PreferenceManager.getDefaultSharedPreferences(this.main_activity).edit();
                edit2.putBoolean(PreferenceKeys.LocationPreferenceKey, true);
                edit2.apply();
            }
        } else {
            Log.e(TAG, "unknown requestCode " + i);
        }
    }

    protected boolean checkPermissions() {
        if (Build.VERSION.SDK_INT < 23) {
            return true;
        }
        CameraMainActivity mainActivity = this.main_activity;
        boolean z = mainActivity.checkSelfPermission("android.permission.CAMERA") != 0;
        boolean z2 = (mainActivity.checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != 0) && mainActivity.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != 0;
        if (z2) {
            mainActivity.checkSelfPermission("android.permission.ACCESS_FINE_LOCATION");
        }
        boolean z3 = z2 && mainActivity.checkSelfPermission("android.permission.ACCESS_COARSE_LOCATION") != 0;
        if (z || z2 || z3) {
            requestPermissions(z, z2, z3);
            return false;
        }
        return true;
    }

    private void requestPermissions(boolean z, boolean z2, boolean z3) {
        for (Context context = this.main_activity; context instanceof ContextWrapper; context = ((ContextWrapper) context).getBaseContext()) {
            if (context instanceof Activity) {
                Activity activity = (Activity) context;
            }
        }
        ArrayList arrayList = new ArrayList();
        if (z) {
            arrayList.add("android.permission.CAMERA");
        }
        if (z2) {
            arrayList.add("android.permission.READ_EXTERNAL_STORAGE");
            arrayList.add("android.permission.WRITE_EXTERNAL_STORAGE");
        }
        if (z3) {
            arrayList.add("android.permission.ACCESS_FINE_LOCATION");
            arrayList.add("android.permission.ACCESS_COARSE_LOCATION");
        }
        if (this.isactivityopen == 1 && this.isStoragePermission != 0) {
            this.isStoragePermission = 0;
            this.isactivityopen = 0;
        }
        CameraMainActivity mainActivity = this.main_activity;
        if (mainActivity == null || this.isStoragePermission != 0) {
            return;
        }
        mainActivity.requestPermissions((String[]) arrayList.toArray(new String[0]), 16);
    }
}
