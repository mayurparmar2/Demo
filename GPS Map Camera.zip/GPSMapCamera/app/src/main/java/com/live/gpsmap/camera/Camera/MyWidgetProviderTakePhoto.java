package com.live.gpsmap.camera.Camera;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

 class MyWidgetProviderTakePhoto extends AppWidgetProvider {
    private static final String TAG = "MyWidgetProviderTakePho";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] iArr) {
        Log.d(TAG, "onUpdate");
        Log.d(TAG, "length = " + iArr.length);
        for (int i : iArr) {
            Log.d(TAG, "appWidgetId: " + i);
            Intent intent = new Intent(context, TakePhoto.class);
            if (Build.VERSION.SDK_INT >= 31) {
                PendingIntent.getActivity(context, 0, intent, 67108864);
            } else {
                PendingIntent.getActivity(context, 0, intent, 0);
            }
        }
    }
}
