package com.live.gpsmap.camera.Mgrs;


/* loaded from: classes.dex */
public class Frustum {
    protected final Plane[] allPlanes;
    protected final Plane bottom;
    protected final Plane far;
    protected final Plane left;
    protected final Plane near;
    protected final Plane right;
    protected final Plane top;

    /* loaded from: classes2.dex */
    public static class Corners {
        public Vec4 fbl;
        public Vec4 fbr;
        public Vec4 ftl;
        public Vec4 ftr;
        public Vec4 nbl;
        public Vec4 nbr;
        public Vec4 ntl;
        public Vec4 ntr;
    }

    public Frustum() {
        this(new Plane(1.0d, 0.0d, 0.0d, 1.0d), new Plane(-1.0d, 0.0d, 0.0d, 1.0d), new Plane(0.0d, 1.0d, 0.0d, 1.0d), new Plane(0.0d, -1.0d, 0.0d, 1.0d), new Plane(0.0d, 0.0d, -1.0d, 1.0d), new Plane(0.0d, 0.0d, 1.0d, 1.0d));
    }

    public Frustum(Plane plane, Plane plane2, Plane plane3, Plane plane4, Plane plane5, Plane plane6) {
        if (plane == null || plane2 == null || plane3 == null || plane4 == null || plane5 == null || plane6 == null) {
            throw new IllegalArgumentException("Plane Is Null");
        }
        this.left = plane;
        this.right = plane2;
        this.bottom = plane3;
        this.top = plane4;
        this.near = plane5;
        this.far = plane6;
        this.allPlanes = new Plane[]{plane, plane2, plane3, plane4, plane5, plane6};
    }

    public final Plane getLeft() {
        return this.left;
    }

    public final Plane getRight() {
        return this.right;
    }

    public final Plane getBottom() {
        return this.bottom;
    }

    public final Plane getTop() {
        return this.top;
    }

    public final Plane getNear() {
        return this.near;
    }

    public final Plane getFar() {
        return this.far;
    }

    public Plane[] getAllPlanes() {
        return this.allPlanes;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Frustum frustum = (Frustum) obj;
        return this.left.equals(frustum.left) && this.right.equals(frustum.right) && this.bottom.equals(frustum.bottom) && this.top.equals(frustum.top) && this.near.equals(frustum.near) && this.far.equals(frustum.far);
    }

    public int hashCode() {
        return (((((((((this.left.hashCode() * 31) + this.right.hashCode()) * 19) + this.bottom.hashCode()) * 23) + this.top.hashCode()) * 17) + this.near.hashCode()) * 19) + this.far.hashCode();
    }

    public String toString() {
        return "(left=" + this.left + ", right=" + this.right + ", bottom=" + this.bottom + ", top=" + this.top + ", near=" + this.near + ", far=" + this.far + ")";
    }

    public static Frustum fromProjectionMatrix(Matrix matrix) {
        if (matrix == null) {
            throw new IllegalArgumentException("Matrix Is Null");
        }
        return new Frustum(new Plane(matrix.m41 + matrix.m11, matrix.m42 + matrix.m12, matrix.m43 + matrix.m13, matrix.m44 + matrix.m14).normalize(), new Plane(matrix.m41 - matrix.m11, matrix.m42 - matrix.m12, matrix.m43 - matrix.m13, matrix.m44 - matrix.m14).normalize(), new Plane(matrix.m41 + matrix.m21, matrix.m42 + matrix.m22, matrix.m43 + matrix.m23, matrix.m44 + matrix.m24).normalize(), new Plane(matrix.m41 - matrix.m21, matrix.m42 - matrix.m22, matrix.m43 - matrix.m23, matrix.m44 - matrix.m24).normalize(), new Plane(matrix.m41 + matrix.m31, matrix.m42 + matrix.m32, matrix.m43 + matrix.m33, matrix.m44 + matrix.m34).normalize(), new Plane(matrix.m41 - matrix.m31, matrix.m42 - matrix.m32, matrix.m43 - matrix.m33, matrix.m44 - matrix.m34).normalize());
    }

    public static Frustum fromPerspective(Angle angle, int i, int i2, double d, double d2) {
        if (angle == null) {
            throw new IllegalArgumentException("Field Of View Is Null");
        }
        double degrees = angle.getDegrees();
        double d3 = d2 - d;
        if (degrees <= 0.0d || degrees > 180.0d) {
            throw new IllegalArgumentException("Field Of View Out Of Range");
        }
        if (d <= 0.0d || d3 <= 0.0d) {
            throw new IllegalArgumentException("Clipping Distance Out Of Range");
        }
        double tanHalfAngle = 1.0d / angle.tanHalfAngle();
        double d4 = i2 / i;
        double d5 = tanHalfAngle * tanHalfAngle;
        double sqrt = Math.sqrt(d5 + 1.0d);
        double sqrt2 = Math.sqrt(d5 + (d4 * d4));
        double d6 = tanHalfAngle / sqrt;
        double d7 = 0.0d - (1.0d / sqrt);
        Plane plane = new Plane(d6, 0.0d, d7, 0.0d);
        Plane plane2 = new Plane(0.0d - d6, 0.0d, d7, 0.0d);
        double d8 = tanHalfAngle / sqrt2;
        double d9 = 0.0d - (d4 / sqrt2);
        return new Frustum(plane, plane2, new Plane(0.0d, d8, d9, 0.0d), new Plane(0.0d, 0.0d - d8, d9, 0.0d), new Plane(0.0d, 0.0d, -1.0d, 0.0d - d), new Plane(0.0d, 0.0d, 1.0d, d2));
    }

    public static Frustum fromPerspective(double d, double d2, double d3, double d4) {
        double d5 = d3;
        if (d4 - d5 <= 0.0d || d <= 0.0d || d2 <= 0.0d) {
            throw new IllegalArgumentException("Clipping Distance Out Of Range");
        }
        double d6 = d / 2.0d;
        double d7 = d2 / 2.0d;
        Plane plane = new Plane(1.0d, 0.0d, 0.0d, d6);
        Plane plane2 = new Plane(-1.0d, 0.0d, 0.0d, d6);
        Plane plane3 = new Plane(0.0d, 1.0d, 0.0d, d7);
        Plane plane4 = new Plane(0.0d, -1.0d, 0.0d, d7);
        if (d5 >= 0.0d) {
            d5 = -d5;
        }
        return new Frustum(plane, plane2, plane3, plane4, new Plane(0.0d, 0.0d, -1.0d, d5), new Plane(0.0d, 0.0d, 1.0d, d4 < 0.0d ? -d4 : d4));
    }

    public static Frustum fromPerspectiveVecs(Vec4 vec4, Vec4 vec42, Vec4 vec43, Vec4 vec44, double d, double d2) {
        if (vec4 == null || vec42 == null || vec43 == null || vec44 == null) {
            throw new IllegalArgumentException("Edge Vector Is Null");
        }
        double d3 = d2 - d;
        if (d <= 0.0d || d3 <= 0.0d) {
            throw new IllegalArgumentException("Clipping Distance Out Of Range");
        }
        Vec4 normalize3 = vec43.cross3(vec4).normalize3();
        Plane plane = new Plane(normalize3.x, normalize3.y, normalize3.z, 0.0d);
        Vec4 normalize32 = vec42.cross3(vec44).normalize3();
        Plane plane2 = new Plane(normalize32.x, normalize32.y, normalize32.z, 0.0d);
        Vec4 normalize33 = vec44.cross3(vec43).normalize3();
        Plane plane3 = new Plane(normalize33.x, normalize33.y, normalize33.z, 0.0d);
        Vec4 normalize34 = vec4.cross3(vec42).normalize3();
        return new Frustum(plane, plane2, plane3, new Plane(normalize34.x, normalize34.y, normalize34.z, 0.0d), new Plane(0.0d, 0.0d, -1.0d, 0.0d - d), new Plane(0.0d, 0.0d, 1.0d, d2));
    }

    public boolean intersectsSegment(Vec4 vec4, Vec4 vec42) {
        Plane[] allPlanes;
        if (vec4 == null || vec42 == null) {
            throw new IllegalArgumentException("Point Is Null");
        }
        if (contains(vec4) || contains(vec42)) {
            return true;
        }
        if (vec4.equals(vec42)) {
            return false;
        }
        for (Plane plane : getAllPlanes()) {
            if (plane.onSameSide(vec4, vec42) < 0) {
                return false;
            }
            if (plane.clip(vec4, vec42) != null) {
                return true;
            }
        }
        return false;
    }

    public final boolean contains(Vec4 vec4) {
        if (vec4 != null) {
            return this.far.dot(vec4) > 0.0d && this.left.dot(vec4) > 0.0d && this.right.dot(vec4) > 0.0d && this.top.dot(vec4) > 0.0d && this.bottom.dot(vec4) > 0.0d && this.near.dot(vec4) > 0.0d;
        }
        throw new IllegalArgumentException("Point Is Null");
    }

    public Frustum transformBy(Matrix matrix) {
        if (matrix == null) {
            throw new IllegalArgumentException("Matrix Is Null");
        }
        return new Frustum(new Plane(this.left.getVector().transformBy4(matrix)), new Plane(this.right.getVector().transformBy4(matrix)), new Plane(this.bottom.getVector().transformBy4(matrix)), new Plane(this.top.getVector().transformBy4(matrix)), new Plane(this.near.getVector().transformBy4(matrix)), new Plane(this.far.getVector().transformBy4(matrix)));
    }

    public Corners getCorners() {
        Corners corners = new Corners();
        corners.nbl = Plane.intersect(this.near, this.bottom, this.left);
        corners.nbr = Plane.intersect(this.near, this.bottom, this.right);
        corners.ntl = Plane.intersect(this.near, this.top, this.left);
        corners.ntr = Plane.intersect(this.near, this.top, this.right);
        corners.fbl = Plane.intersect(this.far, this.bottom, this.left);
        corners.fbr = Plane.intersect(this.far, this.bottom, this.right);
        corners.ftl = Plane.intersect(this.far, this.top, this.left);
        corners.ftr = Plane.intersect(this.far, this.top, this.right);
        return corners;
    }
}
