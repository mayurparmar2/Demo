package com.live.gpsmap.camera.Camera.cameracontroller;

import android.app.Activity;
import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraConstrainedHighSpeedCaptureSession;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraExtensionCharacteristics;
import android.hardware.camera2.CameraExtensionSession;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureFailure;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.DngCreator;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.Capability;
import android.hardware.camera2.params.ExtensionSessionConfiguration;
import android.hardware.camera2.params.Face;
import android.hardware.camera2.params.MeteringRectangle;
import android.hardware.camera2.params.OutputConfiguration;
import android.hardware.camera2.params.RggbChannelVector;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.hardware.camera2.params.TonemapCurve;
import android.location.Location;
import android.media.AudioManager;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaActionSound;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.util.Pair;
import android.util.Range;
import android.util.Rational;
import android.util.SizeF;
import android.util.Size;
import android.view.Display;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.TextureView;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationManagerCompat;
import androidx.exifinterface.media.ExifInterface;
import androidx.work.WorkRequest;

import com.live.gpsmap.camera.Camera.HDRProcessor;
import com.live.gpsmap.camera.Camera.MyDebug;
import com.live.gpsmap.camera.Camera.Script.Say.TccIv;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraController;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Queue;
import java.util.concurrent.Executor;

import kotlinx.coroutines.DebugKt;

@SuppressWarnings("All")
public class CameraController2 extends CameraController {
    private static final int STATE_NORMAL = 0;
    private static final int STATE_WAITING_AUTOFOCUS = 1;
    private static final int STATE_WAITING_FAKE_PRECAPTURE_DONE = 5;
    private static final int STATE_WAITING_FAKE_PRECAPTURE_START = 4;
    private static final int STATE_WAITING_PRECAPTURE_DONE = 3;
    private static final int STATE_WAITING_PRECAPTURE_START = 2;
    private static final String TAG = "CameraController2";
    private static final long autofocus_timeout_c = 1000;
    private static final boolean do_af_trigger_for_continuous = false;
    private static final int max_expo_bracketing_n_images = 5;
    private static final long max_preview_exposure_time_c = 200000000;
    private static final int max_white_balance_temperature_c = 15000;
    private static final int min_white_balance_temperature_c = 1000;
    private static final long precapture_done_timeout_c = 3000;
    private static final long precapture_start_timeout_c = 2000;
    private static final int tonemap_log_max_curve_points_c = 64;
    private List<int[]> ae_fps_ranges;
    private CameraController.AutoFocusCallback autofocus_cb;
    private long autofocus_time_ms;
    private final Object background_camera_lock;
    private boolean burst_for_noise_reduction;
    private int burst_requested_n_images;
    private boolean burst_single_request;
    private CameraController.BurstType burst_type;
    private final Object create_capture_session_lock = new Object();
    private CameraDevice camera;
    private final String cameraIdS;
    private final CameraController.ErrorCallback camera_error_cb;
    private int camera_extension;
    private final CameraSettings camera_settings;
    private CameraCaptureSession captureSession;
    private boolean capture_follows_autofocus_hint;
    private Integer capture_result_ae;
    private float capture_result_aperture;
    private long capture_result_exposure_time;
    private long capture_result_frame_duration;
    private boolean capture_result_has_aperture;
    private boolean capture_result_has_exposure_time;
    private boolean capture_result_has_frame_duration;
    private boolean capture_result_has_iso;
    private boolean capture_result_has_white_balance_rggb;
    private boolean capture_result_is_ae_scanning;
    private int capture_result_iso;
    private RggbChannelVector capture_result_white_balance_rggb;
    private CameraCharacteristics characteristics;
    private CameraController.Facing characteristics_facing;
    private int characteristics_sensor_orientation;
    private final Context context;
    private boolean continuous_burst_in_progress;
    private boolean continuous_burst_requested_last_capture;
    private CameraController.ContinuousFocusMoveCallback continuous_focus_move_callback;
    private int current_zoom_value;
    private boolean done_all_captures;
    private boolean dummy_capture_hack;
    private Executor executor;
    private int expo_bracketing_n_images;
    private double expo_bracketing_stops;
    private CameraExtensionSession extensionSession;
    private CameraExtensionCharacteristics extension_characteristics;
    private CameraController.FaceDetectionListener face_detection_listener;
    private boolean fake_precapture_torch_focus_performed;
    private boolean fake_precapture_torch_performed;
    private CaptureRequest fake_precapture_turn_on_torch_id;
    private boolean fake_precapture_use_flash;
    private long fake_precapture_use_flash_time_ms;
    private boolean focus_bracketing_add_infinity;
    private boolean focus_bracketing_in_progress;
    private int focus_bracketing_n_images;
    private float focus_bracketing_source_distance;
    private float focus_bracketing_target_distance;
    private Handler handler;
    private boolean has_received_frame;
    private List<int[]> hs_fps_ranges;
    private ImageReader imageReader;
    private ImageReader imageReaderRaw;
    private String initial_focus_mode;
    private boolean is_flash_required;
    private final boolean is_samsung;
    private final boolean is_samsung_galaxy_s;
    private final boolean is_samsung_s7;
    private boolean is_video_high_speed;
    private boolean jpeg_todo;
    private final float[] jtlog2_values;
    private final float[] jtlog_values;
    private final float[] jtvideo_values;
    private int last_faces_detected;
    private long max_exposure_time;
    private int max_raw_images;
    private final MediaActionSound media_action_sound;
    private long min_exposure_time;
    private boolean modified_from_camera_settings;
    private int n_burst;
    private int n_burst_raw;
    private int n_burst_taken;
    private int n_burst_total;
    private boolean noise_reduction_low_light;
    private OnImageAvailableListener onImageAvailableListener;
    private OnRawImageAvailableListener onRawImageAvailableListener;
    private final Object open_camera_lock;
    private boolean optimise_ae_for_dro;
    private final List<byte[]> pending_burst_images;
    private final List<RawImage> pending_burst_images_raw;
    private RawImage pending_raw_image;
    private CameraController.PictureCallback picture_cb;
    private int picture_height;
    private int picture_width;
    private long precapture_state_change_time_ms;
    private CaptureRequest.Builder previewBuilder;
    private final MyCaptureCallback previewCaptureCallback;
    private final CameraExtensionSession.ExtensionCaptureCallback previewExtensionCaptureCallback;
    private boolean previewIsVideoMode;
    private final CameraController.ErrorCallback preview_error_cb;
    private int preview_height;
    private int preview_width;
    private boolean push_repeating_request_when_torch_off;
    private CaptureRequest push_repeating_request_when_torch_off_id;
    private android.util.Size raw_size;
    private boolean raw_todo;
    private boolean ready_for_capture;
    private SessionType sessionType;
    private List<CaptureRequest> slow_burst_capture_requests;
    private long slow_burst_start_ms;
    private boolean sounds_enabled;
    private int state;
    private boolean supports_exposure_time;
    private boolean supports_face_detect_mode_full;
    private boolean supports_face_detect_mode_simple;
    private boolean supports_optical_stabilization;
    private boolean supports_photo_video_recording;
    private boolean supports_white_balance_temperature;
    private Surface surface_texture;
    private CameraController.ErrorCallback take_picture_error_cb;
    private SurfaceTexture texture;
    private HandlerThread thread;
    private boolean use_expo_fast_burst;
    private boolean use_fake_precapture;
    private boolean use_fake_precapture_mode;
    private Surface video_recorder_surface;
    private boolean want_raw;
    private boolean want_video_high_speed;
    private List<Integer> zoom_ratios;
    private int zoom_value_1x;
    private static final float[] jtvideo_values_base = {0.0f, 0.0f, 0.01f, 0.055f, 0.02f, 0.1f, 0.05f, 0.21f, 0.09f, 0.31f, 0.13f, 0.38f, 0.18f, 0.45f, 0.28f, 0.57f, 0.35f, 0.64f, 0.45f, 0.72f, 0.51f, 0.76f, 0.6f, 0.82f, 0.67f, 0.86f, 0.77f, 0.91f, 0.88f, 0.96f, 0.97f, 0.99f, 1.0f, 1.0f};
    private static final float[] jtlog_values_base = {0.0f, 0.0f, 0.01f, 0.07f, 0.03f, 0.17f, 0.05f, 0.25f, 0.07f, 0.31f, 0.09f, 0.36f, 0.13f, 0.44f, 0.18f, 0.51f, 0.24f, 0.57f, 0.31f, 0.64f, 0.38f, 0.7f, 0.46f, 0.76f, 0.58f, 0.83f, 0.7f, 0.89f, 0.86f, 0.95f, 0.99f, 0.99f, 1.0f, 1.0f};
    private static final float[] jtlog2_values_base = {0.0f, 0.0f, 0.01f, 0.09f, 0.03f, 0.23f, 0.07f, 0.37f, 0.12f, 0.48f, 0.17f, 0.56f, 0.25f, 0.64f, 0.32f, 0.7f, 0.39f, 0.75f, 0.5f, 0.81f, 0.59f, 0.85f, 0.66f, 0.88f, 0.72f, 0.9f, 0.78f, 0.92f, 0.88f, 0.95f, 0.92f, 0.96f, 0.99f, 0.98f, 1.0f, 1.0f};

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes3.dex */
    public enum RequestTagType {
        CAPTURE,
        CAPTURE_BURST_IN_PROGRESS
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public enum SessionType {
        SESSIONTYPE_NORMAL,
        SESSIONTYPE_EXTENSION
    }

    private static float GaintoRGB(float f) {
        if (f<=1.0f) {
            return 1.0f;
        }
        return 1.0f / f;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public String getAPI() {
        return "Camera2 (Android L)";
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public String getISOKey() {
        return "";
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public String getParametersString() {
        return null;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean sceneModeAffectsFunctionality() {
        return false;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setRecordingHint(boolean z) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void unlock() {
    }

    private void resetCaptureResultInfo() {
        this.capture_result_is_ae_scanning = false;
        this.capture_result_ae = null;
        this.is_flash_required = false;
        this.capture_result_has_white_balance_rggb = false;
        this.capture_result_has_iso = false;
        this.capture_result_has_exposure_time = false;
        this.capture_result_has_frame_duration = false;
        this.capture_result_has_aperture = false;
    }


    public static class RequestTagObject {
        private RequestTagType type;

        private RequestTagObject(RequestTagType requestTagType) {
            this.type = requestTagType;
        }

        public RequestTagType getType() {
            return this.type;
        }

        public void setType(RequestTagType requestTagType) {
            this.type = requestTagType;
        }
    }



    public class CameraSettings {
        private int ae_exposure_compensation;
        private boolean ae_lock;
        private MeteringRectangle[] ae_regions;
        private Range<Integer> ae_target_fps_range;
        private int af_mode;
        private MeteringRectangle[] af_regions;
        private int antibanding;
        private float aperture;
        private int color_effect;
        private float control_zoom_ratio;
        private Integer default_edge_mode;
        private Integer default_noise_reduction_mode;
        private Integer default_optical_stabilization;
        private Integer default_tonemap_mode;
        private int edge_mode;
        private long exposure_time;
        private int face_detect_mode;
        private String flash_value;
        private float focus_distance;
        private float focus_distance_manual;
        private float gamma_profile;
        private boolean has_ae_exposure_compensation;
        private boolean has_af_mode;
        private boolean has_antibanding;
        private boolean has_aperture;
        private boolean has_control_zoom_ratio;
        private boolean has_default_edge_mode;
        private boolean has_default_noise_reduction_mode;
        private boolean has_edge_mode;
        private boolean has_face_detect_mode;
        private boolean has_iso;
        private boolean has_noise_reduction_mode;
        private int iso;
        private byte jpeg_quality;
        private Location location;
        private float log_profile_strength;
        private int noise_reduction_mode;
        private int rotation;
        private Rect scalar_crop_region;
        private int scene_mode;
        private long sensor_frame_duration;
        private CameraController.TonemapProfile tonemap_profile;
        private boolean video_stabilization;
        private boolean wb_lock;
        private int white_balance;
        private int white_balance_temperature;

        private CameraSettings() {
            this.jpeg_quality = (byte) 90;
            this.scene_mode = 0;
            this.color_effect = 0;
            this.white_balance = 1;
            this.antibanding = 3;
            this.edge_mode = 1;
            this.noise_reduction_mode = 1;
            this.white_balance_temperature = 5000;
            this.flash_value = "flash_off";
            this.exposure_time = CameraController.EXPOSURE_TIME_DEFAULT;
            this.af_mode = 1;
            this.face_detect_mode = 0;
            this.tonemap_profile = CameraController.TonemapProfile.TONEMAPPROFILE_OFF;
        }

        private int getExifOrientation() {
            int exif_orientation = ExifInterface.ORIENTATION_NORMAL;
            switch( (rotation + 360) % 360 ) {
                case 0:
                    exif_orientation = ExifInterface.ORIENTATION_NORMAL;
                    break;
                case 90:
                    exif_orientation = (getFacing() == Facing.FACING_FRONT) ?
                            ExifInterface.ORIENTATION_ROTATE_270 :
                            ExifInterface.ORIENTATION_ROTATE_90;
                    break;
                case 180:
                    exif_orientation = ExifInterface.ORIENTATION_ROTATE_180;
                    break;
                case 270:
                    exif_orientation = (getFacing() == Facing.FACING_FRONT) ?
                            ExifInterface.ORIENTATION_ROTATE_90 :
                            ExifInterface.ORIENTATION_ROTATE_270;
                    break;
                default:
                    // leave exif_orientation unchanged
                    if( MyDebug.LOG )
                        Log.e(TAG, "unexpected rotation: " + rotation);
                    break;
            }
            if( MyDebug.LOG ) {
                Log.d(TAG, "rotation: " + rotation);
                Log.d(TAG, "exif_orientation: " + exif_orientation);
            }
            return exif_orientation;
        }


        public void setupBuilder(CaptureRequest.Builder builder, boolean z) {
            if (CameraController2.this.sessionType != SessionType.SESSIONTYPE_EXTENSION) {
                builder.set(CaptureRequest.CONTROL_AF_TRIGGER, 0);
            }
            setSceneMode(builder);
            setColorEffect(builder);
            setWhiteBalance(builder);
            setAntiBanding(builder);
            setAEMode(builder, z);
            setControlZoomRatio(builder);
            setCropRegion(builder);
            setExposureCompensation(builder);
            setFocusMode(builder);
            setFocusDistance(builder);
            setAutoExposureLock(builder);
            setAutoWhiteBalanceLock(builder);
            setAFRegions(builder);
            setAERegions(builder);
            setFaceDetectMode(builder);
            setRawMode(builder);
            setStabilization(builder);
            setTonemapProfile(builder);
            if (z) {
                if (this.location != null && CameraController2.this.sessionType != SessionType.SESSIONTYPE_EXTENSION) {
                    builder.set(CaptureRequest.JPEG_GPS_LOCATION, this.location);
                }
                builder.set(CaptureRequest.JPEG_ORIENTATION, Integer.valueOf(this.rotation));
                builder.set(CaptureRequest.JPEG_QUALITY, Byte.valueOf(this.jpeg_quality));
            }
            setEdgeMode(builder);
            setNoiseReductionMode(builder);
            if (z) {
                Integer num = (Integer) builder.get(CaptureRequest.NOISE_REDUCTION_MODE);
                StringBuilder sb = new StringBuilder();
                sb.append("nr_mode: ");
                if (num == null) {
                    num = 0;
                }
                sb.append(num);
                Log.d(CameraController2.TAG, sb.toString());
                Integer num2 = (Integer) builder.get(CaptureRequest.EDGE_MODE);
                StringBuilder sb2 = new StringBuilder();
                sb2.append("edge_mode: ");
                if (num2 == null) {
                    num2 = 0;
                }
                sb2.append(num2);
                Log.d(CameraController2.TAG, sb2.toString());
                Object obj = (Integer) builder.get(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE);
                StringBuilder sb3 = new StringBuilder();
                sb3.append(" ");
                sb3.append(obj != null ? obj : "null");
                Log.d(CameraController2.TAG, sb3.toString());
            }
        }


        /* JADX INFO: Access modifiers changed from: private */
        public boolean setSceneMode(CaptureRequest.Builder builder) {
            Log.d(CameraController2.TAG, "setSceneMode");
            Log.d(CameraController2.TAG, "builder: " + builder);
            if (CameraController2.this.sessionType == SessionType.SESSIONTYPE_EXTENSION) {
                return false;
            }
            Integer num = (Integer) builder.get(CaptureRequest.CONTROL_SCENE_MODE);
            if (this.has_face_detect_mode) {
                if (num == null || num.intValue() != 1) {
                    Log.d(CameraController2.TAG, "setting scene mode for face detection");
                    builder.set(CaptureRequest.CONTROL_MODE, 2);
                    builder.set(CaptureRequest.CONTROL_SCENE_MODE, 1);
                    return true;
                }
            } else if (num == null || num.intValue() != this.scene_mode) {
                Log.d(CameraController2.TAG, "setting scene mode: " + this.scene_mode);
                if (this.scene_mode == 0) {
                    builder.set(CaptureRequest.CONTROL_MODE, 1);
                } else {
                    builder.set(CaptureRequest.CONTROL_MODE, 2);
                }
                builder.set(CaptureRequest.CONTROL_SCENE_MODE, Integer.valueOf(this.scene_mode));
                return true;
            }
            return false;
        }

        public boolean setColorEffect(CaptureRequest.Builder builder) {
            if (CameraController2.this.sessionType == SessionType.SESSIONTYPE_EXTENSION) {
                return false;
            }
            if (builder.get(CaptureRequest.CONTROL_EFFECT_MODE) == null || ((Integer) builder.get(CaptureRequest.CONTROL_EFFECT_MODE)).intValue() != this.color_effect) {
                Log.d(CameraController2.TAG, "setting color effect: " + this.color_effect);
                builder.set(CaptureRequest.CONTROL_EFFECT_MODE, Integer.valueOf(this.color_effect));
                return true;
            }
            return false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public boolean setWhiteBalance(CaptureRequest.Builder builder) {
            boolean z;
            if (CameraController2.this.sessionType != SessionType.SESSIONTYPE_EXTENSION && (builder.get(CaptureRequest.CONTROL_AWB_MODE) == null || ((Integer) builder.get(CaptureRequest.CONTROL_AWB_MODE)).intValue() != this.white_balance)) {
                Log.d(CameraController2.TAG, "setting white balance: " + this.white_balance);
                builder.set(CaptureRequest.CONTROL_AWB_MODE, Integer.valueOf(this.white_balance));
                z = true;
            } else {
                z = false;
            }
            if (this.white_balance == 0) {
                Log.d(CameraController2.TAG, "setting white balance temperature: " + this.white_balance_temperature);
                RggbChannelVector convertTemperatureToRggbVector = CameraController2.convertTemperatureToRggbVector(this.white_balance_temperature);
                builder.set(CaptureRequest.COLOR_CORRECTION_MODE, 0);
                builder.set(CaptureRequest.COLOR_CORRECTION_GAINS, convertTemperatureToRggbVector);
                return true;
            }
            return z;
        }


        public boolean setAntiBanding(CaptureRequest.Builder builder) {
            if (CameraController2.this.sessionType != SessionType.SESSIONTYPE_EXTENSION && this.has_antibanding && (builder.get(CaptureRequest.CONTROL_AE_ANTIBANDING_MODE) == null || ((Integer) builder.get(CaptureRequest.CONTROL_AE_ANTIBANDING_MODE)).intValue() != this.antibanding)) {
                Log.d(CameraController2.TAG, "setting antibanding: " + this.antibanding);
                builder.set(CaptureRequest.CONTROL_AE_ANTIBANDING_MODE, Integer.valueOf(this.antibanding));
                return true;
            }
            return false;
        }


        public boolean setEdgeMode(CaptureRequest.Builder builder) {
            Log.d(CameraController2.TAG, "setEdgeMode");
            Log.d(CameraController2.TAG, "has_default_edge_mode: " + this.has_default_edge_mode);
            Log.d(CameraController2.TAG, "default_edge_mode: " + this.default_edge_mode);
            if (CameraController2.this.sessionType == SessionType.SESSIONTYPE_EXTENSION) {
                return false;
            }
            if (this.has_edge_mode) {
                if (!this.has_default_edge_mode) {
                    this.has_default_edge_mode = true;
                    this.default_edge_mode = (Integer) builder.get(CaptureRequest.EDGE_MODE);
                    Log.d(CameraController2.TAG, "default_edge_mode: " + this.default_edge_mode);
                }
                if (builder.get(CaptureRequest.EDGE_MODE) == null || ((Integer) builder.get(CaptureRequest.EDGE_MODE)).intValue() != this.edge_mode) {
                    Log.d(CameraController2.TAG, "setting edge_mode: " + this.edge_mode);
                    builder.set(CaptureRequest.EDGE_MODE, Integer.valueOf(this.edge_mode));
                } else {
                    Log.d(CameraController2.TAG, "edge_mode was already set: " + this.edge_mode);
                    return false;
                }
            } else if (CameraController2.this.is_samsung_s7) {
                Log.d(CameraController2.TAG, "set EDGE_MODE_OFF");
                builder.set(CaptureRequest.EDGE_MODE, 0);
                return false;
            } else if (!this.has_default_edge_mode || builder.get(CaptureRequest.EDGE_MODE) == null || ((Integer) builder.get(CaptureRequest.EDGE_MODE)).equals(this.default_edge_mode)) {
                return false;
            } else {
                builder.set(CaptureRequest.EDGE_MODE, this.default_edge_mode);
            }
            return true;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public boolean setNoiseReductionMode(CaptureRequest.Builder builder) {
            Log.d(CameraController2.TAG, "setNoiseReductionMode");
            Log.d(CameraController2.TAG, "has_default_noise_reduction_mode: " + this.has_default_noise_reduction_mode);
            Log.d(CameraController2.TAG, "default_noise_reduction_mode: " + this.default_noise_reduction_mode);
            if (CameraController2.this.sessionType == SessionType.SESSIONTYPE_EXTENSION) {
                return false;
            }
            if (this.has_noise_reduction_mode) {
                if (!this.has_default_noise_reduction_mode) {
                    this.has_default_noise_reduction_mode = true;
                    this.default_noise_reduction_mode = (Integer) builder.get(CaptureRequest.NOISE_REDUCTION_MODE);
                    Log.d(CameraController2.TAG, "default_noise_reduction_mode: " + this.default_noise_reduction_mode);
                }
                if (builder.get(CaptureRequest.NOISE_REDUCTION_MODE) == null || ((Integer) builder.get(CaptureRequest.NOISE_REDUCTION_MODE)).intValue() != this.noise_reduction_mode) {
                    Log.d(CameraController2.TAG, "setting noise_reduction_mode: " + this.noise_reduction_mode);
                    builder.set(CaptureRequest.NOISE_REDUCTION_MODE, Integer.valueOf(this.noise_reduction_mode));
                } else {
                    Log.d(CameraController2.TAG, "noise_reduction_mode was already set: " + this.noise_reduction_mode);
                    return false;
                }
            } else if (CameraController2.this.is_samsung_s7) {
                Log.d(CameraController2.TAG, "set NOISE_REDUCTION_MODE_OFF");
                builder.set(CaptureRequest.NOISE_REDUCTION_MODE, 0);
                return false;
            } else if (!this.has_default_noise_reduction_mode || builder.get(CaptureRequest.NOISE_REDUCTION_MODE) == null || ((Integer) builder.get(CaptureRequest.NOISE_REDUCTION_MODE)).equals(this.default_noise_reduction_mode)) {
                return false;
            } else {
                builder.set(CaptureRequest.NOISE_REDUCTION_MODE, this.default_noise_reduction_mode);
            }
            return true;
        }

        public boolean setAperture(CaptureRequest.Builder builder) {
            Log.d(CameraController2.TAG, "setAperture");
            if (CameraController2.this.sessionType != SessionType.SESSIONTYPE_EXTENSION && this.has_aperture) {
                Log.d(CameraController2.TAG, "    aperture: " + this.aperture);
                builder.set(CaptureRequest.LENS_APERTURE, Float.valueOf(this.aperture));
                return true;
            }
            return false;
        }

        private boolean setAEMode(CaptureRequest.Builder builder, boolean is_still) {
            if( MyDebug.LOG )
                Log.d(TAG, "setAEMode");
            if( has_iso ) {
                if( MyDebug.LOG ) {
                    Log.d(TAG, "manual mode");
                    Log.d(TAG, "iso: " + iso);
                    Log.d(TAG, "exposure_time: " + exposure_time);
                }
                builder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF);
                builder.set(CaptureRequest.SENSOR_SENSITIVITY, iso);
                long actual_exposure_time = exposure_time;
                if( !is_still ) {
                    // if this isn't for still capture, have a max exposure time of 1/12s
                    actual_exposure_time = Math.min(exposure_time, 1000000000L/12);
                    if( MyDebug.LOG )
                        Log.d(TAG, "actually using exposure_time of: " + actual_exposure_time);
                }
                builder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, actual_exposure_time);
                if (sensor_frame_duration > 0) {
                    builder.set(CaptureRequest.SENSOR_FRAME_DURATION, sensor_frame_duration);
                }
                //builder.set(CaptureRequest.SENSOR_FRAME_DURATION, 1000000000L);
                //builder.set(CaptureRequest.SENSOR_FRAME_DURATION, 0L);
                // for now, flash is disabled when using manual iso - it seems to cause ISO level to jump to 100 on Nexus 6 when flash is turned on!
                builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF);
                // set flash via CaptureRequest.FLASH
		    	/*if( flash_value.equals("flash_off") ) {
					builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF);
		    	}
		    	else if( flash_value.equals("flash_auto") ) {
					builder.set(CaptureRequest.FLASH_MODE, is_still ? CameraMetadata.FLASH_MODE_SINGLE : CameraMetadata.FLASH_MODE_OFF);
		    	}
		    	else if( flash_value.equals("flash_on") ) {
					builder.set(CaptureRequest.FLASH_MODE, is_still ? CameraMetadata.FLASH_MODE_SINGLE : CameraMetadata.FLASH_MODE_OFF);
		    	}
		    	else if( flash_value.equals("flash_torch") ) {
					builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_TORCH);
		    	}
		    	else if( flash_value.equals("flash_red_eye") ) {
					builder.set(CaptureRequest.FLASH_MODE, is_still ? CameraMetadata.FLASH_MODE_SINGLE : CameraMetadata.FLASH_MODE_OFF);
		    	}*/
            }
            else {
                if( MyDebug.LOG ) {
                    Log.d(TAG, "auto mode");
                    Log.d(TAG, "flash_value: " + flash_value);
                }
                if( ae_target_fps_range != null ) {
                    Log.d(TAG, "set ae_target_fps_range: " + ae_target_fps_range);
                    builder.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, ae_target_fps_range);
                }

                // prefer to set flash via the ae mode (otherwise get even worse results), except for torch which we can't
                switch(flash_value) {
                    case "flash_off":
                        builder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON);
                        builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF);
                        break;
                    case "flash_auto":
                        // note we set this even in fake flash mode (where we manually turn torch on and off to simulate flash) so we
                        // can read the FLASH_REQUIRED state to determine if flash is required
		    		/*if( use_fake_precapture || CameraController2.this.want_expo_bracketing )
			    		builder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON);
		    		else*/
                        builder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON_AUTO_FLASH);
                        builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF);
                        break;
                    case "flash_on":
                        // see note above for "flash_auto" for why we set this even fake flash mode - arguably we don't need to know
                        // about FLASH_REQUIRED in flash_on mode, but we set it for consistency...
		    		/*if( use_fake_precapture || CameraController2.this.want_expo_bracketing )
			    		builder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON);
		    		else*/
                        builder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON_ALWAYS_FLASH);
                        builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF);
                        break;
                    case "flash_torch":
                        builder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON);
                        builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_TORCH);
                        break;
                    case "flash_red_eye":
                        // not supported for expo bracketing or burst
                        if( CameraController2.this.burst_type != BurstType.BURSTTYPE_NONE )
                            builder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON);
                        else
                            builder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON_AUTO_FLASH_REDEYE);
                        builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF);
                        break;
                    case "flash_frontscreen_auto":
                    case "flash_frontscreen_on":
                    case "flash_frontscreen_torch":
                        builder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON);
                        builder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF);
                        break;
                }
            }
            return true;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setControlZoomRatio(CaptureRequest.Builder builder) {
            if (CameraController2.this.sessionType != SessionType.SESSIONTYPE_EXTENSION && Build.VERSION.SDK_INT>=30 && this.has_control_zoom_ratio) {
                builder.set(CaptureRequest.CONTROL_ZOOM_RATIO, Float.valueOf(this.control_zoom_ratio));
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setCropRegion(CaptureRequest.Builder builder) {
            if (CameraController2.this.sessionType == SessionType.SESSIONTYPE_EXTENSION || this.scalar_crop_region == null || Build.VERSION.SDK_INT>=30) {
                return;
            }
            builder.set(CaptureRequest.SCALER_CROP_REGION, this.scalar_crop_region);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public boolean setExposureCompensation(CaptureRequest.Builder builder) {
            if (this.has_ae_exposure_compensation) {
                if (this.has_iso) {
                    Log.d(CameraController2.TAG, "don't set exposure compensation in manual iso mode");
                    return false;
                } else if (CameraController2.this.sessionType == SessionType.SESSIONTYPE_EXTENSION) {
                    return false;
                } else {
                    if (builder.get(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION) == null || this.ae_exposure_compensation != ((Integer) builder.get(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION)).intValue()) {
                        Log.d(CameraController2.TAG, "change exposure to " + this.ae_exposure_compensation);
                        builder.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, Integer.valueOf(this.ae_exposure_compensation));
                        return true;
                    }
                    return false;
                }
            }
            return false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setFocusMode(CaptureRequest.Builder builder) {
            if (CameraController2.this.sessionType == SessionType.SESSIONTYPE_EXTENSION) {
                return;
            }
            if (this.has_af_mode) {
                Log.d(CameraController2.TAG, "change af mode to " + this.af_mode);
                builder.set(CaptureRequest.CONTROL_AF_MODE, Integer.valueOf(this.af_mode));
                return;
            }
            Log.d(CameraController2.TAG, "af mode left at " + builder.get(CaptureRequest.CONTROL_AF_MODE));
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setFocusDistance(CaptureRequest.Builder builder) {
            Log.d(CameraController2.TAG, "change focus distance to " + this.focus_distance);
            if (CameraController2.this.sessionType == SessionType.SESSIONTYPE_EXTENSION) {
                return;
            }
            builder.set(CaptureRequest.LENS_FOCUS_DISTANCE, Float.valueOf(this.focus_distance));
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setAutoExposureLock(CaptureRequest.Builder builder) {
            if (CameraController2.this.sessionType == SessionType.SESSIONTYPE_EXTENSION) {
                return;
            }
            builder.set(CaptureRequest.CONTROL_AE_LOCK, Boolean.valueOf(this.ae_lock));
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setAutoWhiteBalanceLock(CaptureRequest.Builder builder) {
            if (CameraController2.this.sessionType == SessionType.SESSIONTYPE_EXTENSION) {
                return;
            }
            builder.set(CaptureRequest.CONTROL_AWB_LOCK, Boolean.valueOf(this.wb_lock));
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setAFRegions(CaptureRequest.Builder builder) {
            if (CameraController2.this.sessionType == SessionType.SESSIONTYPE_EXTENSION || this.af_regions == null || ((Integer) CameraController2.this.characteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF)).intValue()<=0) {
                return;
            }
            builder.set(CaptureRequest.CONTROL_AF_REGIONS, this.af_regions);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setAERegions(CaptureRequest.Builder builder) {
            if (CameraController2.this.sessionType == SessionType.SESSIONTYPE_EXTENSION || this.ae_regions == null || ((Integer) CameraController2.this.characteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE)).intValue()<=0) {
                return;
            }
            builder.set(CaptureRequest.CONTROL_AE_REGIONS, this.ae_regions);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setFaceDetectMode(CaptureRequest.Builder builder) {
            if (CameraController2.this.sessionType == SessionType.SESSIONTYPE_EXTENSION) {
                return;
            }
            if (this.has_face_detect_mode) {
                builder.set(CaptureRequest.STATISTICS_FACE_DETECT_MODE, Integer.valueOf(this.face_detect_mode));
            } else {
                builder.set(CaptureRequest.STATISTICS_FACE_DETECT_MODE, 0);
            }
        }

        private void setRawMode(CaptureRequest.Builder builder) {
            if (!CameraController2.this.want_raw || CameraController2.this.previewIsVideoMode) {
                return;
            }
            builder.set(CaptureRequest.STATISTICS_LENS_SHADING_MAP_MODE, 1);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setStabilization(CaptureRequest.Builder builder) {
            Log.d(CameraController2.TAG, "setStabilization: " + this.video_stabilization);
            if (CameraController2.this.sessionType == SessionType.SESSIONTYPE_EXTENSION) {
                return;
            }
            builder.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, Integer.valueOf(this.video_stabilization ? 1 : 0));
            if (CameraController2.this.supports_optical_stabilization) {
                if (this.video_stabilization) {
                    if (this.default_optical_stabilization == null) {
                        this.default_optical_stabilization = (Integer) builder.get(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE);
                        Log.d(CameraController2.TAG, "default_optical_stabilization: " + this.default_optical_stabilization);
                    }
                    builder.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, 0);
                } else if (this.default_optical_stabilization == null || builder.get(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE) == null || ((Integer) builder.get(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE)).equals(this.default_optical_stabilization)) {
                } else {
                    Log.d(CameraController2.TAG, "set optical stabilization back to: " + this.default_optical_stabilization);
                    builder.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, this.default_optical_stabilization);
                }
            }
        }

        private float getLogProfile(float f) {
            float f2 = this.log_profile_strength;
            return (float) (Math.log1p(f * f2) / Math.log1p(f2));
        }

        private float getGammaProfile(float f) {
            return (float) Math.pow(f, 1.0f / this.gamma_profile);
        }

//        private void setTonemapProfile(CaptureRequest.Builder builder) {
//            if( MyDebug.LOG ) {
//                Log.d(TAG, "setTonemapProfile");
//                Log.d(TAG, "tonemap_profile: " + tonemap_profile);
//                Log.d(TAG, "log_profile_strength: " + log_profile_strength);
//                Log.d(TAG, "gamma_profile: " + gamma_profile);
//                Log.d(TAG, "default_tonemap_mode: " + default_tonemap_mode);
//            }
//            boolean have_tonemap_profile = tonemap_profile != TonemapProfile.TONEMAPPROFILE_OFF;
//            if( tonemap_profile == TonemapProfile.TONEMAPPROFILE_LOG && log_profile_strength == 0.0f )
//                have_tonemap_profile = false;
//            else if( tonemap_profile == TonemapProfile.TONEMAPPROFILE_GAMMA && gamma_profile == 0.0f )
//                have_tonemap_profile = false;
//
//            // to use test_new, also need to uncomment the test code in setFocusValue() to call setTonemapProfile()
//            //boolean test_new = this.af_mode == CaptureRequest.CONTROL_AF_MODE_AUTO; // testing
//
//            //if( test_new )
//            //    have_tonemap_profile = false;
//
//            if( sessionType == SessionType.SESSIONTYPE_EXTENSION ) {
//                // don't set for extensions
//            }
//            else if( have_tonemap_profile ) {
//                if( default_tonemap_mode == null ) {
//                    // save the default tonemap_mode
//                    default_tonemap_mode = builder.get(CaptureRequest.TONEMAP_MODE);
//                    if( MyDebug.LOG )
//                        Log.d(TAG, "default_tonemap_mode: " + default_tonemap_mode);
//                }
//
//                final boolean use_preset_curve = true;
//                //final boolean use_preset_curve = false; // test
//                //final boolean use_preset_curve = test_new; // test
//                if( use_preset_curve && tonemap_profile == TonemapProfile.TONEMAPPROFILE_REC709 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ) {
//                    if( MyDebug.LOG )
//                        Log.d(TAG, "set TONEMAP_PRESET_CURVE_REC709");
//                    builder.set(CaptureRequest.TONEMAP_MODE, CaptureRequest.TONEMAP_MODE_PRESET_CURVE);
//                    builder.set(CaptureRequest.TONEMAP_PRESET_CURVE, CaptureRequest.TONEMAP_PRESET_CURVE_REC709);
//                }
//                else if( use_preset_curve && tonemap_profile == TonemapProfile.TONEMAPPROFILE_SRGB && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ) {
//                    if( MyDebug.LOG )
//                        Log.d(TAG, "set TONEMAP_PRESET_CURVE_SRGB");
//                    builder.set(CaptureRequest.TONEMAP_MODE, CaptureRequest.TONEMAP_MODE_PRESET_CURVE);
//                    builder.set(CaptureRequest.TONEMAP_PRESET_CURVE, CaptureRequest.TONEMAP_PRESET_CURVE_SRGB);
//                }
//                else {
//                    if( MyDebug.LOG )
//                        Log.d(TAG, "handle via TONEMAP_MODE_CONTRAST_CURVE / TONEMAP_CURVE");
//                    float [] values = null;
//                    switch( tonemap_profile ) {
//                        case TONEMAPPROFILE_REC709:
//                            // y = 4.5x if x < 0.018, else y = 1.099*x^0.45 - 0.099
//                            float [] x_values = new float[] {
//                                    0.0000f, 0.0667f, 0.1333f, 0.2000f,
//                                    0.2667f, 0.3333f, 0.4000f, 0.4667f,
//                                    0.5333f, 0.6000f, 0.6667f, 0.7333f,
//                                    0.8000f, 0.8667f, 0.9333f, 1.0000f
//                            };
//                            values = new float[2*x_values.length];
//                            int c = 0;
//                            for(float x_value : x_values) {
//                                float out;
//                                if( x_value < 0.018f ) {
//                                    out = 4.5f * x_value;
//                                }
//                                else {
//                                    out = (float)(1.099*Math.pow(x_value, 0.45) - 0.099);
//                                }
//                                values[c++] = x_value;
//                                values[c++] = out;
//                            }
//                            break;
//                        case TONEMAPPROFILE_SRGB:
//                            values = new float [] {
//                                    0.0000f, 0.0000f, 0.0667f, 0.2864f, 0.1333f, 0.4007f, 0.2000f, 0.4845f,
//                                    0.2667f, 0.5532f, 0.3333f, 0.6125f, 0.4000f, 0.6652f, 0.4667f, 0.7130f,
//                                    0.5333f, 0.7569f, 0.6000f, 0.7977f, 0.6667f, 0.8360f, 0.7333f, 0.8721f,
//                                    0.8000f, 0.9063f, 0.8667f, 0.9389f, 0.9333f, 0.9701f, 1.0000f, 1.0000f
//                            };
//                            break;
//                        case TONEMAPPROFILE_LOG:
//                        case TONEMAPPROFILE_GAMMA:
//                        {
//                            // better to use uniformly spaced values, otherwise we get a weird looking effect - this can be
//                            // seen most prominently when using gamma 1.0f, which should look linear (and hence be independent
//                            // of the x values we use)
//                            // can be reproduced on at least OnePlus 3T and Galaxy S10e (although the exact behaviour of the
//                            // poor results is different on those devices)
//                            int n_values = tonemap_log_max_curve_points_c;
//                            if( is_samsung ) {
//                                // unfortunately odd bug on Samsung devices (at least S7 and S10e) where if more than 32 control points,
//                                // the maximum brightness value is reduced (can best be seen with 64 points, and using gamma==1.0)
//                                // note that Samsung devices also need at least 16 control points - or in some cases 32, see comments for
//                                // enforceMinTonemapCurvePoints().
//                                // 32 is better than 16 anyway, as better to have more points for finer curve where possible.
//                                n_values = 32;
//                            }
//                            //int n_values = test_new ? 32 : 128;
//                            //int n_values = 32;
//                            if( MyDebug.LOG )
//                                Log.d(TAG, "n_values: " + n_values);
//                            values = new float [2*n_values];
//                            for(int i=0;i<n_values;i++) {
//                                float in = ((float)i) / (n_values-1.0f);
//                                float out = (tonemap_profile==TonemapProfile.TONEMAPPROFILE_LOG) ? getLogProfile(in) : getGammaProfile(in);
//                                values[2*i] = in;
//                                values[2*i+1] = out;
//                            }
//                        }
//
//                        /*if( test_new ) {
//                            // if changing this, make sure we don't exceed tonemap_log_max_curve_points_c
//                            // we want:
//                            // 0-15: step 1 (16 values)
//                            // 16-47: step 2 (16 values)
//                            // 48-111: step 4 (16 values)
//                            // 112-231 : step 8 (15 values)
//                            // 232-255: step 24 (1 value)
//                            int step = 1, c = 0;
//                            //int step = 4, c = 0;
//                            //int step = test_new ? 4 : 1, c = 0;
//                            values = new float[2*tonemap_log_max_curve_points_c];
//                            for(int i=0;i<232;i+=step) {
//                                float in = ((float)i) / 255.0f;
//                                float out = (tonemap_profile==TonemapProfile.TONEMAPPROFILE_LOG) ? getLogProfile(in) : getGammaProfile(in);
//                                if( tonemap_profile==TonemapProfile.TONEMAPPROFILE_LOG )
//                                    out = (float)Math.pow(out, 1.0f/2.2f);
//                                values[c++] = in;
//                                values[c++] = out;
//                                if( (c/2) % 16 == 0 ) {
//                                    step *= 2;
//                                }
//                            }
//                            values[c++] = 1.0f;
//                            float last_out = (tonemap_profile==TonemapProfile.TONEMAPPROFILE_LOG) ? getLogProfile(1.0f) : getGammaProfile(1.0f);
//                            if( tonemap_profile==TonemapProfile.TONEMAPPROFILE_LOG )
//                                last_out = (float)Math.pow(last_out, 1.0f/2.2f);
//                            values[c++] = last_out;
//                            values = Arrays.copyOfRange(values,0,c);
//                        }*/
//                        /*if( test_new )
//                        {
//                            // x values are ranged 0 to 255
//                            float [] x_values = new float[] {
//                                    0.0f, 4.0f, 8.0f, 12.0f, 16.0f, 20.0f, 24.0f, 28.0f,
//                                    //0.0f, 8.0f, 16.0f, 24.0f,
//                                    32.0f, 40.0f, 48.0f, 56.0f,
//                                    64.0f, 72.0f, 80.0f, 88.0f,
//                                    96.0f, 104.0f, 112.0f, 120.0f,
//                                    128.0f, 136.0f, 144.0f, 152.0f,
//                                    160.0f, 168.0f, 176.0f, 184.0f,
//                                    192.0f, 200.0f, 208.0f, 216.0f,
//                                    224.0f, 232.0f, 240.0f, 248.0f,
//                                    255.0f
//                            };
//                            values = new float[2*x_values.length];
//                            c = 0;
//                            for(float x_value : x_values) {
//                                float in = x_value / 255.0f;
//                                float out = (tonemap_profile==TonemapProfile.TONEMAPPROFILE_LOG) ? getLogProfile(in) : getGammaProfile(in);
//                                values[c++] = in;
//                                values[c++] = out;
//                            }
//                        }*/
//                        /*if( test_new )
//                        {
//                            values = new float [2*256];
//                            step = 8;
//                            c = 0;
//                            for(int i=0;i<254;i+=step) {
//                                float in = ((float)i) / 255.0f;
//                                float out = (tonemap_profile==TonemapProfile.TONEMAPPROFILE_LOG) ? getLogProfile(in) : getGammaProfile(in);
//                                values[c++] = in;
//                                values[c++] = out;
//                            }
//                            values[c++] = 1.0f;
//                            values[c++] = (tonemap_profile==TonemapProfile.TONEMAPPROFILE_LOG) ? getLogProfile(1.0f) : getGammaProfile(1.0f);
//                            values = Arrays.copyOfRange(values,0,c);
//                        }*/
//                        if( MyDebug.LOG ) {
//                            int n_values = values.length/2;
//                            for(int i=0;i<n_values;i++) {
//                                float in = values[2*i];
//                                float out = values[2*i+1];
//                                Log.d(TAG, "i = " + i);
//                                //Log.d(TAG, "    in: " + (int)(in*255.0f+0.5f));
//                                //Log.d(TAG, "    out: " + (int)(out*255.0f+0.5f));
//                                Log.d(TAG, "    in: " + (in*255.0f));
//                                Log.d(TAG, "    out: " + (out*255.0f));
//                            }
//                        }
//                        break;
//                        case TONEMAPPROFILE_JTVIDEO:
//                            values = jtvideo_values;
//                            if( MyDebug.LOG )
//                                Log.d(TAG, "setting JTVideo profile");
//                            break;
//                        case TONEMAPPROFILE_JTLOG:
//                            values = jtlog_values;
//                            if( MyDebug.LOG )
//                                Log.d(TAG, "setting JTLog profile");
//                            break;
//                        case TONEMAPPROFILE_JTLOG2:
//                            values = jtlog2_values;
//                            if( MyDebug.LOG )
//                                Log.d(TAG, "setting JTLog2 profile");
//                            break;
//                    }
//
//                    // sRGB:
//                    /*values = new float []{0.0000f, 0.0000f, 0.0667f, 0.2864f, 0.1333f, 0.4007f, 0.2000f, 0.4845f,
//                            0.2667f, 0.5532f, 0.3333f, 0.6125f, 0.4000f, 0.6652f, 0.4667f, 0.7130f,
//                            0.5333f, 0.7569f, 0.6000f, 0.7977f, 0.6667f, 0.8360f, 0.7333f, 0.8721f,
//                            0.8000f, 0.9063f, 0.8667f, 0.9389f, 0.9333f, 0.9701f, 1.0000f, 1.0000f};*/
//                    /*values = new float []{0.0000f, 0.0000f, 0.05f, 0.3f, 0.1f, 0.4f, 0.2000f, 0.4845f,
//                            0.2667f, 0.5532f, 0.3333f, 0.6125f, 0.4000f, 0.6652f,
//                            0.5f, 0.78f, 1.0000f, 1.0000f};*/
//                    /*values = new float []{0.0f, 0.0f, 0.05f, 0.4f, 0.1f, 0.54f, 0.2f, 0.6f, 0.3f, 0.65f, 0.4f, 0.7f,
//                            0.5f, 0.78f, 1.0f, 1.0f};*/
//                    /*values = new float[]{0.0f, 0.0f, 0.0667f, 0.2864f, 0.1333f, 0.4007f, 0.2000f, 0.4845f,
//                            1.0f, 1.0f};*/
//                    //values = new float []{0.0f, 0.5f, 0.05f, 0.6f, 0.1f, 0.7f, 0.2f, 0.8f, 0.5f, 0.9f, 1.0f, 1.0f};
//                    /*values = new float []{0.0f, 0.0f,
//                            0.05f, 0.05f,
//                            0.1f, 0.1f,
//                            0.15f, 0.15f,
//                            0.2f, 0.2f,
//                            0.25f, 0.25f,
//                            0.3f, 0.3f,
//                            0.35f, 0.35f,
//                            0.4f, 0.4f,
//                            0.5f, 0.5f,
//                            0.6f, 0.6f,
//                            0.7f, 0.7f,
//                            0.8f, 0.8f,
//                            0.9f, 0.9f,
//                            0.95f, 0.95f,
//                            1.0f, 1.0f};*/
//                    //values = enforceMinTonemapCurvePoints(new float[]{0.0f, 0.0f, 1.0f, 1.0f});
//                    //values = enforceMinTonemapCurvePoints(values);
//
//                    if( MyDebug.LOG  )
//                        Log.d(TAG, "values: " + Arrays.toString(values));
//                    if( values != null ) {
//                        builder.set(CaptureRequest.TONEMAP_MODE, CaptureRequest.TONEMAP_MODE_CONTRAST_CURVE);
//                        TonemapCurve tonemap_curve = new TonemapCurve(values, values, values);
//                        builder.set(CaptureRequest.TONEMAP_CURVE, tonemap_curve);
//                        test_used_tonemap_curve = true;
//                    }
//                    else {
//                        Log.e(TAG, "unknown log type: " + tonemap_profile);
//                    }
//                }
//            }
//            else if( default_tonemap_mode != null ) {
//                builder.set(CaptureRequest.TONEMAP_MODE, default_tonemap_mode);
//            }
//        }
        public void setTonemapProfile(CaptureRequest.Builder builder) {
            float[] fArr;
            float pow;
            Log.d(CameraController2.TAG, "setTonemapProfile");
            Log.d(CameraController2.TAG, "tonemap_profile: " + this.tonemap_profile);
            Log.d(CameraController2.TAG, "log_profile_strength: " + this.log_profile_strength);
            Log.d(CameraController2.TAG, "gamma_profile: " + this.gamma_profile);
            Log.d(CameraController2.TAG, "default_tonemap_mode: " + this.default_tonemap_mode);
            int i = 0;
            boolean z = this.tonemap_profile != CameraController.TonemapProfile.TONEMAPPROFILE_OFF;
            if ((this.tonemap_profile == CameraController.TonemapProfile.TONEMAPPROFILE_LOG && this.log_profile_strength == 0.0f) || (this.tonemap_profile == CameraController.TonemapProfile.TONEMAPPROFILE_GAMMA && this.gamma_profile == 0.0f)) {
                z = false;
            }
            if (CameraController2.this.sessionType == SessionType.SESSIONTYPE_EXTENSION) {
                return;
            }
            if (z) {
                if (this.default_tonemap_mode == null) {
                    this.default_tonemap_mode = (Integer) builder.get(CaptureRequest.TONEMAP_MODE);
                    Log.d(CameraController2.TAG, "default_tonemap_mode: " + this.default_tonemap_mode);
                }
                if (this.tonemap_profile == CameraController.TonemapProfile.TONEMAPPROFILE_REC709 && Build.VERSION.SDK_INT>=23) {
                    Log.d(CameraController2.TAG, "set TONEMAP_PRESET_CURVE_REC709");
                    builder.set(CaptureRequest.TONEMAP_MODE, 4);
                    builder.set(CaptureRequest.TONEMAP_PRESET_CURVE, 1);
                } else if (this.tonemap_profile == CameraController.TonemapProfile.TONEMAPPROFILE_SRGB && Build.VERSION.SDK_INT>=23) {
                    Log.d(CameraController2.TAG, "set TONEMAP_PRESET_CURVE_SRGB");
                    builder.set(CaptureRequest.TONEMAP_MODE, 4);
                    builder.set(CaptureRequest.TONEMAP_PRESET_CURVE, 0);
                } else {
                    Log.d(CameraController2.TAG, "handle via TONEMAP_MODE_CONTRAST_CURVE / TONEMAP_CURVE");
                    float[] fArr2 = null;
                    switch (AnonymousClass7.$SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$TonemapProfile[this.tonemap_profile.ordinal()]) {
                        case 1:
                            float[] fArr3 = {0.0f, 0.0667f, 0.1333f, 0.2f, 0.2667f, 0.3333f, 0.4f, 0.4667f, 0.5333f, 0.6f, 0.6667f, 0.7333f, 0.8f, 0.8667f, 0.9333f, 1.0f};
                            float[] fArr4 = new float[32];
                            int i2 = 0;
                            for (int i3 = 16; i<i3; i3 = 16) {
                                float f = fArr3[i];
                                if (f<0.018f) {
                                    pow = 4.5f * f;
                                    fArr = fArr3;
                                } else {
                                    fArr = fArr3;
                                    pow = (float) ((Math.pow(f, 0.45d) * 1.099d) - 0.099d);
                                }
                                int i4 = i2 + 1;
                                fArr4[i2] = f;
                                i2 = i4 + 1;
                                fArr4[i4] = pow;
                                i++;
                                fArr3 = fArr;
                            }
                            fArr2 = fArr4;
                            break;
                        case 2:
                            fArr2 = new float[]{0.0f, 0.0f, 0.0667f, 0.2864f, 0.1333f, 0.4007f, 0.2f, 0.4845f, 0.2667f, 0.5532f, 0.3333f, 0.6125f, 0.4f, 0.6652f, 0.4667f, 0.713f, 0.5333f, 0.7569f, 0.6f, 0.7977f, 0.6667f, 0.836f, 0.7333f, 0.8721f, 0.8f, 0.9063f, 0.8667f, 0.9389f, 0.9333f, 0.9701f, 1.0f, 1.0f};
                            break;
                        case 3:
                        case 4:
                            int i5 = CameraController2.this.is_samsung ? 32 : 64;
                            Log.d(CameraController2.TAG, "n_values: " + i5);
                            int i6 = i5 * 2;
                            float[] fArr5 = new float[i6];
                            for (int i7 = 0; i7<i5; i7++) {
                                float f2 = i7 / (i5 - 1.0f);
                                float logProfile = this.tonemap_profile == CameraController.TonemapProfile.TONEMAPPROFILE_LOG ? getLogProfile(f2) : getGammaProfile(f2);
                                int i8 = i7 * 2;
                                fArr5[i8] = f2;
                                fArr5[i8 + 1] = logProfile;
                            }
                            int i9 = i6 / 2;
                            while (i<i9) {
                                int i10 = i * 2;
                                float f3 = fArr5[i10];
                                float f4 = fArr5[i10 + 1];
                                Log.d(CameraController2.TAG, "i = " + i);
                                Log.d(CameraController2.TAG, "    in: " + (f3 * 255.0f));
                                Log.d(CameraController2.TAG, "    out: " + (f4 * 255.0f));
                                i++;
                            }
                            fArr2 = fArr5;
                            break;
                        case 5:
                            fArr2 = CameraController2.this.jtvideo_values;
                            Log.d(CameraController2.TAG, "setting JTVideo profile");
                            break;
                        case 6:
                            fArr2 = CameraController2.this.jtlog_values;
                            Log.d(CameraController2.TAG, "setting JTLog profile");
                            break;
                        case 7:
                            fArr2 = CameraController2.this.jtlog2_values;
                            Log.d(CameraController2.TAG, "setting JTLog2 profile");
                            break;
                    }
                    Log.d(CameraController2.TAG, "values: " + Arrays.toString(fArr2));
                    if (fArr2 != null) {
                        builder.set(CaptureRequest.TONEMAP_MODE, 0);
                        builder.set(CaptureRequest.TONEMAP_CURVE, new TonemapCurve(fArr2, fArr2, fArr2));
                        CameraController2.this.test_used_tonemap_curve = true;
                        return;
                    }
                    Log.e(CameraController2.TAG, "unknown log type: " + this.tonemap_profile);
                }
            } else if (this.default_tonemap_mode != null) {
                builder.set(CaptureRequest.TONEMAP_MODE, this.default_tonemap_mode);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.live.gpsmap.camera.Camera.cameracontroller.CameraController2$7  reason: invalid class name */

    public static /* synthetic */ class AnonymousClass7 {
        static final /* synthetic */ int[] $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$TonemapProfile;

        static {
            int[] iArr = new int[CameraController.TonemapProfile.values().length];
            $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$TonemapProfile = iArr;
            try {
                iArr[CameraController.TonemapProfile.TONEMAPPROFILE_REC709.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$TonemapProfile[CameraController.TonemapProfile.TONEMAPPROFILE_SRGB.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$TonemapProfile[CameraController.TonemapProfile.TONEMAPPROFILE_LOG.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$TonemapProfile[CameraController.TonemapProfile.TONEMAPPROFILE_GAMMA.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$TonemapProfile[CameraController.TonemapProfile.TONEMAPPROFILE_JTVIDEO.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$TonemapProfile[CameraController.TonemapProfile.TONEMAPPROFILE_JTLOG.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$TonemapProfile[CameraController.TonemapProfile.TONEMAPPROFILE_JTLOG2.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean hasCaptureSession() {
        return this.sessionType == SessionType.SESSIONTYPE_EXTENSION ? this.extensionSession != null : this.captureSession != null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void BLOCK_FOR_EXTENSIONS() {
        if (this.sessionType == SessionType.SESSIONTYPE_EXTENSION) {
            throw new RuntimeException("not supported for extension session");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static RggbChannelVector convertTemperatureToRggbVector(int i) {
        RggbChannelVector rggbChannelVector = convertTemperatureToRggb(i);
        return rggbChannelVector;
    }


    private static RggbChannelVector convertTemperatureToRggb(int temperature_kelvin) {
        float temperature = temperature_kelvin / 100.0f;
        float red;
        float green;
        float blue;

        if (temperature<=66) {
            red = 255;
        } else {
            red = temperature - 60;
            red = (float) (329.698727446 * (Math.pow((double) red, -0.1332047592)));
            if (red<0)
                red = 0;
            if (red>255)
                red = 255;
        }

        if (temperature<=66) {
            green = temperature;
            green = (float) (99.4708025861 * Math.log(green) - 161.1195681661);
            if (green<0)
                green = 0;
            if (green>255)
                green = 255;
        } else {
            green = temperature - 60;
            green = (float) (288.1221695283 * (Math.pow((double) green, -0.0755148492)));
            if (green<0)
                green = 0;
            if (green>255)
                green = 255;
        }

        if (temperature>=66)
            blue = 255;
        else if (temperature<=19)
            blue = 0;
        else {
            blue = temperature - 10;
            blue = (float) (138.5177312231 * Math.log(blue) - 305.0447927307);
            if (blue<0)
                blue = 0;
            if (blue>255)
                blue = 255;
        }

        if (MyDebug.LOG) {
            Log.d(TAG, "red: " + red);
            Log.d(TAG, "green: " + green);
            Log.d(TAG, "blue: " + blue);
        }
        return new RggbChannelVector((red / 255) * 2, (green / 255), (green / 255), (blue / 255) * 2);
    }

    private static float RGBtoGain(float f) {
        if (f<1.0E-5f) {
            return 10.0f;
        }
        return Math.min(10.0f, 1.0f / f);
    }

    public static int convertRggbVectorToTemperature(RggbChannelVector rggbChannelVector) {
        return convertRggbToTemperature(new float[]{rggbChannelVector.getRed(), rggbChannelVector.getGreenEven(), rggbChannelVector.getGreenOdd(), rggbChannelVector.getBlue()});
    }

    public static int convertRggbToTemperature(float[] fArr) {
        int pow;
        Log.d(TAG, "temperature:");
        Log.d(TAG, "    red: " + fArr[0]);
        Log.d(TAG, "    green even: " + fArr[1]);
        Log.d(TAG, "    green odd: " + fArr[2]);
        Log.d(TAG, "    blue: " + fArr[3]);
        float f = fArr[0];
        float f2 = fArr[1];
        float f3 = fArr[2];
        float f4 = fArr[3];
        float GaintoRGB = GaintoRGB(f) * 255.0f;
        float GaintoRGB2 = GaintoRGB(f2 + f3) * 255.0f;
        float GaintoRGB3 = GaintoRGB(f4) * 255.0f;
        int i = (int) (GaintoRGB + 0.5f);
        int i2 = (int) (GaintoRGB2 + 0.5f);
        int i3 = (int) (GaintoRGB3 + 0.5f);
        if (i == i3) {
            pow = 6600;
        } else if (i>i3) {
            float exp = (float) (Math.exp((GaintoRGB2 + 161.1195681661d) / 99.4708025861d) * 100.0d);
            if (i3 != 0) {
                exp = (exp + ((float) ((Math.exp((GaintoRGB3 + 305.0447927307d) / 138.5177312231d) + 10.0d) * 100.0d))) / 2.0f;
            }
            pow = (int) (exp + 0.5f);
        } else {
            pow = (i<=1 || i2<=1) ? max_white_balance_temperature_c : (int) (((((float) ((Math.pow(GaintoRGB / 329.698727446d, -7.507239275877164d) + 60.0d) * 100.0d)) + ((float) ((Math.pow(GaintoRGB2 / 288.1221695283d, -13.24242861627803d) + 60.0d) * 100.0d))) / 2.0f) + 0.5f);
        }
        int min = Math.min(Math.max(pow, 1000), (int) max_white_balance_temperature_c);
        Log.d(TAG, "    temperature: " + min);
        return min;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes3.dex */
    public class OnImageAvailableListener implements ImageReader.OnImageAvailableListener {
        private boolean skip_next_image;

        private OnImageAvailableListener() {
            this.skip_next_image = false;
        }

        @Override // android.media.ImageReader.OnImageAvailableListener
        public void onImageAvailable(ImageReader imageReader) {
            boolean z;
            boolean z2;
            Log.d(CameraController2.TAG, "new still image available");
            if (CameraController2.this.picture_cb == null || !CameraController2.this.jpeg_todo) {
                Log.e(CameraController2.TAG, "no picture callback available");
                Image acquireNextImage = imageReader.acquireNextImage();
                if (acquireNextImage != null) {
                    acquireNextImage.close();
                    return;
                }
                return;
            }
            boolean z3 = false;
            if (this.skip_next_image) {
                Log.d(CameraController2.TAG, "skipping image");
                this.skip_next_image = false;
                Image acquireNextImage2 = imageReader.acquireNextImage();
                if (acquireNextImage2 != null) {
                    acquireNextImage2.close();
                    return;
                }
                return;
            }
            ArrayList arrayList = null;
            Image acquireNextImage3 = imageReader.acquireNextImage();
            if (acquireNextImage3 == null) {
                Log.e(CameraController2.TAG, "onImageAvailable: image is null");
                return;
            }
            Log.d(CameraController2.TAG, "image timestamp: " + acquireNextImage3.getTimestamp());
            ByteBuffer buffer = acquireNextImage3.getPlanes()[0].getBuffer();
            int remaining = buffer.remaining();
            byte[] bArr = new byte[remaining];
            Log.d(CameraController2.TAG, "read " + remaining + " bytes");
            buffer.get(bArr);
            acquireNextImage3.close();
            synchronized (CameraController2.this.background_camera_lock) {
                z = true;
                CameraController2.this.n_burst_taken++;
                Log.d(CameraController2.TAG, "n_burst_taken is now: " + CameraController2.this.n_burst_taken);
                Log.d(CameraController2.TAG, "n_burst: " + CameraController2.this.n_burst);
                Log.d(CameraController2.TAG, "burst_single_request: " + CameraController2.this.burst_single_request);
                if (CameraController2.this.burst_single_request) {
                    CameraController2.this.pending_burst_images.add(bArr);
                    Log.d(CameraController2.TAG, "pending_burst_images size is now: " + CameraController2.this.pending_burst_images.size());
                    if (CameraController2.this.pending_burst_images.size()>=CameraController2.this.n_burst) {
                        Log.d(CameraController2.TAG, "all burst images available");
                        if (CameraController2.this.pending_burst_images.size()>CameraController2.this.n_burst) {
                            Log.e(CameraController2.TAG, "pending_burst_images size " + CameraController2.this.pending_burst_images.size() + " is greater than n_burst " + CameraController2.this.n_burst);
                        }
                        arrayList = new ArrayList(CameraController2.this.pending_burst_images);
                    } else {
                        Log.d(CameraController2.TAG, "number of burst images is now: " + CameraController2.this.pending_burst_images.size());
                        z2 = true;
                    }
                }
                z2 = false;
            }
            if (arrayList != null) {
                CameraController2.this.picture_cb.onBurstPictureTaken(arrayList);
            } else if (!CameraController2.this.burst_single_request) {
                CameraController2.this.picture_cb.onPictureTaken(bArr);
            }
            synchronized (CameraController2.this.background_camera_lock) {
                if (arrayList != null) {
                    CameraController2.this.pending_burst_images.clear();
                } else if (CameraController2.this.burst_single_request) {
                    z = z2;
                } else {
                    CameraController2.this.n_burst--;
                    Log.d(CameraController2.TAG, "n_burst is now " + CameraController2.this.n_burst);
                    if (CameraController2.this.burst_type == CameraController.BurstType.BURSTTYPE_CONTINUOUS && !CameraController2.this.continuous_burst_requested_last_capture) {
                        Log.d(CameraController2.TAG, "continuous burst mode still in progress");
                    } else if (CameraController2.this.n_burst == 0) {
                    }
                }
                z = z2;
                z3 = true;
            }
            if (z) {
                takePhotoPartial();
            } else if (z3) {
                takePhotoCompleted();
            }
            Log.d(CameraController2.TAG, "done onImageAvailable");
        }

        private void takePhotoPartial() {
            CameraController.ErrorCallback errorCallback;
            Log.d(CameraController2.TAG, "takePhotoPartial");
            CameraController2.this.BLOCK_FOR_EXTENSIONS();
            synchronized (CameraController2.this.background_camera_lock) {
                errorCallback = null;
                if (CameraController2.this.slow_burst_capture_requests != null) {
                    Log.d(CameraController2.TAG, "need to execute the next capture");
                    Log.d(CameraController2.TAG, "time since start: " + (System.currentTimeMillis() - CameraController2.this.slow_burst_start_ms));
                    if (CameraController2.this.burst_type != CameraController.BurstType.BURSTTYPE_FOCUS) {
                        try {
                            if (CameraController2.this.camera != null && CameraController2.this.hasCaptureSession()) {
                                CameraController2.this.captureSession.capture((CaptureRequest) CameraController2.this.slow_burst_capture_requests.get(CameraController2.this.n_burst_taken), CameraController2.this.previewCaptureCallback, CameraController2.this.handler);
                            }
                        } catch (CameraAccessException e) {
                            Log.e(CameraController2.TAG, "failed to take next burst");
                            Log.e(CameraController2.TAG, "reason: " + e.getReason());
                            Log.e(CameraController2.TAG, "message: " + e.getMessage());
                            e.printStackTrace();
                            CameraController2.this.jpeg_todo = false;
                            CameraController2.this.raw_todo = false;
                            CameraController2.this.picture_cb = null;
                            errorCallback = CameraController2.this.take_picture_error_cb;
                        }
                    } else if (CameraController2.this.previewBuilder != null) {
                        Log.d(CameraController2.TAG, "focus bracketing");
                        if (!CameraController2.this.focus_bracketing_in_progress) {
                            Log.d(CameraController2.TAG, "focus bracketing was cancelled");
                            Log.d(CameraController2.TAG, "slow_burst_capture_requests size was: " + CameraController2.this.slow_burst_capture_requests.size());
                            Log.d(CameraController2.TAG, "n_burst size was: " + CameraController2.this.n_burst);
                            Log.d(CameraController2.TAG, "n_burst_taken: " + CameraController2.this.n_burst_taken);
                            CameraController2.this.slow_burst_capture_requests.subList(CameraController2.this.n_burst_taken + 1, CameraController2.this.slow_burst_capture_requests.size()).clear();
                            if (CameraController2.this.burst_single_request) {
                                CameraController2 cameraController2 = CameraController2.this;
                                cameraController2.n_burst = cameraController2.slow_burst_capture_requests.size();
                                if (CameraController2.this.n_burst_raw>0) {
                                    CameraController2 cameraController22 = CameraController2.this;
                                    cameraController22.n_burst_raw = cameraController22.slow_burst_capture_requests.size();
                                }
                            } else {
                                CameraController2.this.n_burst = 1;
                                if (CameraController2.this.n_burst_raw>0) {
                                    CameraController2.this.n_burst_raw = 1;
                                }
                            }
                            Log.d(CameraController2.TAG, "size is now: " + CameraController2.this.slow_burst_capture_requests.size());
                            Log.d(CameraController2.TAG, "n_burst is now: " + CameraController2.this.n_burst);
                            Log.d(CameraController2.TAG, "n_burst_raw is now: " + CameraController2.this.n_burst_raw);
                            ((RequestTagObject) ((CaptureRequest) CameraController2.this.slow_burst_capture_requests.get(CameraController2.this.slow_burst_capture_requests.size() - 1)).getTag()).setType(RequestTagType.CAPTURE);
                        }
                        try {
                            float floatValue = ((Float) ((CaptureRequest) CameraController2.this.slow_burst_capture_requests.get(CameraController2.this.n_burst_taken)).get(CaptureRequest.LENS_FOCUS_DISTANCE)).floatValue();
                            Log.d(CameraController2.TAG, "prepare preview for next focus_distance: " + floatValue);
                            CameraController2.this.previewBuilder.set(CaptureRequest.CONTROL_AF_MODE, 0);
                            CameraController2.this.previewBuilder.set(CaptureRequest.LENS_FOCUS_DISTANCE, Float.valueOf(floatValue));
                            CameraController2 cameraController23 = CameraController2.this;
                            cameraController23.setRepeatingRequest(cameraController23.previewBuilder.build());
                        } catch (CameraAccessException e2) {
                            Log.e(CameraController2.TAG, "failed to take set focus distance for next focus bracketing burst");
                            Log.e(CameraController2.TAG, "reason: " + e2.getReason());
                            Log.e(CameraController2.TAG, "message: " + e2.getMessage());
                            e2.printStackTrace();
                            CameraController2.this.jpeg_todo = false;
                            CameraController2.this.raw_todo = false;
                            CameraController2.this.picture_cb = null;
                            errorCallback = CameraController2.this.take_picture_error_cb;
                        }
                        CameraController2.this.handler.postDelayed(new Runnable() { // from class: com.live.gpsmap.camera.Camera.cameracontroller.CameraController2.OnImageAvailableListener.1
                            @Override // java.lang.Runnable
                            public void run() {
                                Log.d(CameraController2.TAG, "take picture after delay for next focus bracket");
                                if (CameraController2.this.camera == null || !CameraController2.this.hasCaptureSession()) {
                                    return;
                                }
                                if (CameraController2.this.picture_cb.imageQueueWouldBlock(CameraController2.this.imageReaderRaw != null ? 1 : 0, 1)) {
                                    Log.d(CameraController2.TAG, "...but wait for next focus bracket, as image queue would block");
                                    CameraController2.this.handler.postDelayed(this, 100L);
                                    return;
                                }
                                CameraController2.this.playSound(0);
                                try {
                                    CameraController2.this.captureSession.capture((CaptureRequest) CameraController2.this.slow_burst_capture_requests.get(CameraController2.this.n_burst_taken), CameraController2.this.previewCaptureCallback, CameraController2.this.handler);
                                } catch (CameraAccessException e3) {
                                    Log.e(CameraController2.TAG, "failed to take next focus bracket");
                                    Log.e(CameraController2.TAG, "reason: " + e3.getReason());
                                    Log.e(CameraController2.TAG, "message: " + e3.getMessage());
                                    e3.printStackTrace();
                                    CameraController2.this.jpeg_todo = false;
                                    CameraController2.this.raw_todo = false;
                                    CameraController2.this.picture_cb = null;
                                    if (CameraController2.this.take_picture_error_cb != null) {
                                        CameraController2.this.take_picture_error_cb.onError();
                                        CameraController2.this.take_picture_error_cb = null;
                                    }
                                }
                            }
                        }, 500L);
                    }
                }
            }
            if (errorCallback != null) {
                errorCallback.onError();
            }
        }

        private void takePhotoCompleted() {
            Log.d(CameraController2.TAG, "takePhotoCompleted");
            synchronized (CameraController2.this.background_camera_lock) {
                CameraController2.this.jpeg_todo = false;
            }
            CameraController2.this.checkImagesCompleted();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes3.dex */
    public class OnRawImageAvailableListener implements ImageReader.OnImageAvailableListener {
        private final Queue<CaptureResult> capture_results;
        private final Queue<Image> images;
        private boolean skip_next_image;

        private OnRawImageAvailableListener() {
            this.capture_results = new LinkedList();
            this.images = new LinkedList();
            this.skip_next_image = false;
        }

        void setCaptureResult(CaptureResult captureResult) {
            Log.d(CameraController2.TAG, "setCaptureResult()");
            synchronized (CameraController2.this.background_camera_lock) {
                this.capture_results.add(captureResult);
                if (this.images.size()>0) {
                    Log.d(CameraController2.TAG, "can now process the image");
                    ((Activity) CameraController2.this.context).runOnUiThread(new Runnable() { // from class: com.live.gpsmap.camera.Camera.cameracontroller.CameraController2.OnRawImageAvailableListener.1
                        @Override // java.lang.Runnable
                        public void run() {
                            Log.d(CameraController2.TAG, "setCaptureResult UI thread call processImage()");
                            OnRawImageAvailableListener.this.processImage();
                        }
                    });
                }
            }
        }

        void clear() {
            Log.d(CameraController2.TAG, "clear()");
            synchronized (CameraController2.this.background_camera_lock) {
                this.capture_results.clear();
                this.images.clear();
            }
        }


        private void processImage() {
            if( MyDebug.LOG )
                Log.d(TAG, "processImage()");
            if( capture_results == null ) {
                if( MyDebug.LOG )
                    Log.d(TAG, "don't yet have still_capture_result");
                return;
            }
            if( images == null ) {
                if( MyDebug.LOG )
                    Log.d(TAG, "don't have image?!");
                return;
            }
            if( MyDebug.LOG ) {
                Log.d(TAG, "now have all info to process raw image");
                Log.d(TAG, "image timestamp: " + images.element().getTimestamp());
            }
            DngCreator dngCreator = new DngCreator(characteristics, capture_results.element());
            // set fields
            dngCreator.setOrientation(camera_settings.getExifOrientation());
            if( camera_settings.location != null ) {
                dngCreator.setLocation(camera_settings.location);
            }

            pending_raw_image = new RawImage(dngCreator, images.element());

            PictureCallback cb = picture_cb;
            if( picture_cb == null ) {
                if( MyDebug.LOG )
                    Log.d(TAG, "jpeg callback already done, so can go ahead with raw callback");
                takePendingRaw();
                if( MyDebug.LOG )
                    Log.d(TAG, "all image callbacks now completed");
                cb.onCompleted();
            }
            else {
                if( MyDebug.LOG )
                    Log.d(TAG, "need to wait for jpeg callback");
            }
            if( MyDebug.LOG )
                Log.d(TAG, "done processImage");
        }


        @Override // android.media.ImageReader.OnImageAvailableListener
        public void onImageAvailable(ImageReader imageReader) {
            Log.d(CameraController2.TAG, "new still raw image available");
            if (CameraController2.this.picture_cb == null || !CameraController2.this.raw_todo) {
                Log.e(CameraController2.TAG, "no picture callback available");
                Image acquireNextImage = imageReader.acquireNextImage();
                if (acquireNextImage != null) {
                    acquireNextImage.close();
                }
            } else if (this.skip_next_image) {
                Log.d(CameraController2.TAG, "skipping image");
                this.skip_next_image = false;
                Image acquireNextImage2 = imageReader.acquireNextImage();
                if (acquireNextImage2 != null) {
                    acquireNextImage2.close();
                }
            } else {
                synchronized (CameraController2.this.background_camera_lock) {
                    Image acquireNextImage3 = imageReader.acquireNextImage();
                    if (acquireNextImage3 == null) {
                        Log.e(CameraController2.TAG, "RAW onImageAvailable: image is null");
                        return;
                    }
                    this.images.add(acquireNextImage3);
                    processImage();
                    Log.d(CameraController2.TAG, "done (RAW) onImageAvailable");
                }
            }
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void onError() {
        Log.e(TAG, "onError");
        CameraDevice cameraDevice = this.camera;
        if (cameraDevice != null) {
            onError(cameraDevice);
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setOptimiseAEForDRO(boolean z) {
        Log.d(TAG, "setOptimiseAEForDRO: " + z);
        if (Build.MANUFACTURER.toLowerCase(Locale.US).contains("oneplus")) {
            this.optimise_ae_for_dro = false;
            Log.d(TAG, "don't modify ae for OnePlus");
            return;
        }
        this.optimise_ae_for_dro = z;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onError(CameraDevice cameraDevice) {
        Log.e(TAG, "onError");
        boolean z = this.camera != null;
        this.camera = null;
        Log.d(TAG, "onError: camera is now set to null");
        cameraDevice.close();
        Log.d(TAG, "onError: camera is now closed");
        if (z) {
            Log.e(TAG, "error occurred after camera was opened");
            this.camera_error_cb.onError();
        }
    }

    public CameraController2(Context context, int i, CameraController.ErrorCallback errorCallback, CameraController.ErrorCallback errorCallback2) throws CameraControllerException {
        super(i);
        this.optimise_ae_for_dro = false;
        this.sessionType = SessionType.SESSIONTYPE_NORMAL;
        this.camera_extension = 0;
        this.autofocus_time_ms = -1L;
        this.last_faces_detected = -1;
        Object obj = new Object();
        this.open_camera_lock = obj;
        this.background_camera_lock = new Object();
        this.burst_type = CameraController.BurstType.BURSTTYPE_NONE;
        this.expo_bracketing_n_images = 3;
        this.expo_bracketing_stops = 2.0d;
        boolean z = true;
        this.use_expo_fast_burst = true;
        this.focus_bracketing_n_images = 3;
        this.focus_bracketing_source_distance = 0.0f;
        this.focus_bracketing_target_distance = 0.0f;
        this.focus_bracketing_add_infinity = false;
        this.dummy_capture_hack = false;
        this.pending_burst_images = new ArrayList();
        this.pending_burst_images_raw = new ArrayList();
        this.slow_burst_start_ms = 0L;
        this.state = 0;
        this.precapture_state_change_time_ms = -1L;
        this.fake_precapture_use_flash_time_ms = -1L;
        this.media_action_sound = new MediaActionSound();
        this.sounds_enabled = true;
        this.camera_settings = new CameraSettings();
        this.push_repeating_request_when_torch_off = false;
        this.push_repeating_request_when_torch_off_id = null;
        this.fake_precapture_turn_on_torch_id = null;
        this.previewCaptureCallback = new MyCaptureCallback();
        Log.d(TAG, "create new CameraController2: " + i);
        String str = TAG;
        Log.d(str, "this: " + this);
        if (Build.VERSION.SDK_INT>=31) {
            this.previewExtensionCaptureCallback = new MyExtensionCaptureCallback();
        } else {
            this.previewExtensionCaptureCallback = null;
        }
        this.context = context;
        this.preview_error_cb = errorCallback;
        this.camera_error_cb = errorCallback2;
        boolean contains = Build.MANUFACTURER.toLowerCase(Locale.US).contains("samsung");
        this.is_samsung = contains;
        boolean contains2 = Build.MODEL.toLowerCase(Locale.US).contains("sm-g93");
        this.is_samsung_s7 = contains2;
        z = (contains && Build.MODEL.toLowerCase(Locale.US).contains("sm-g")) ? false : false;
        this.is_samsung_galaxy_s = z;
        Log.d(TAG, "is_samsung: " + contains);
        Log.d(TAG, "is_samsung_s7: " + contains2);
        Log.d(TAG, "is_samsung_galaxy_s: " + z);
        HandlerThread handlerThread = new HandlerThread("CameraBackground");
        this.thread = handlerThread;
        handlerThread.start();
        this.handler = new Handler(this.thread.getLooper());
        this.executor = new Executor() { // from class: com.live.gpsmap.camera.Camera.cameracontroller.CameraController2.1
            @Override // java.util.concurrent.Executor
            public void execute(Runnable runnable) {
                CameraController2.this.handler.post(runnable);
            }
        };
        CameraManager cameraManager = (CameraManager) context.getSystemService("camera");
        final C1MyStateCallback c1MyStateCallback = new C1MyStateCallback(cameraManager);
        try {
            Log.d(TAG, "get camera id list");
            String str2 = cameraManager.getCameraIdList()[i];
            this.cameraIdS = str2;
            Log.d(TAG, "about to open camera: " + str2);
            cameraManager.openCamera(str2, c1MyStateCallback, this.handler);
            Log.d(TAG, "open camera request complete");
            this.handler.postDelayed(new Runnable() { // from class: com.live.gpsmap.camera.Camera.cameracontroller.CameraController2.2
                @Override // java.lang.Runnable
                public void run() {
                    Log.d(CameraController2.TAG, "check if camera has opened in reasonable time: " + this);
                    synchronized (CameraController2.this.open_camera_lock) {
                        Log.d(CameraController2.TAG, "synchronized on open_camera_lock");
                        Log.d(CameraController2.TAG, "callback_done: " + c1MyStateCallback.callback_done);
                        if (!c1MyStateCallback.callback_done) {
                            Log.e(CameraController2.TAG, "timeout waiting for camera callback");
                            c1MyStateCallback.first_callback = true;
                            c1MyStateCallback.callback_done = true;
                            CameraController2.this.open_camera_lock.notifyAll();
                        }
                    }
                }
            }, WorkRequest.MIN_BACKOFF_MILLIS);
            Log.d(TAG, "wait until camera opened...");
            synchronized (obj) {
                while (!c1MyStateCallback.callback_done) {
                    try {
                        this.open_camera_lock.wait();
                    } catch (InterruptedException e) {
                        Log.d(TAG, "interrupted while waiting until camera opened");
                        e.printStackTrace();
                    }
                }
            }
            if (this.camera == null) {
                Log.e(TAG, "camera failed to open");
                throw new CameraControllerException();
            }
            Log.d(TAG, "camera now opened: " + this.camera);
            this.media_action_sound.load(2);
            this.media_action_sound.load(3);
            this.media_action_sound.load(0);
            this.jtvideo_values = enforceMinTonemapCurvePoints(jtvideo_values_base);
            this.jtlog_values = enforceMinTonemapCurvePoints(jtlog_values_base);
            this.jtlog2_values = enforceMinTonemapCurvePoints(jtlog2_values_base);
        } catch (CameraAccessException e2) {
            Log.e(TAG, "failed to open camera: CameraAccessException");
            Log.e(TAG, "reason: " + e2.getReason());
            Log.e(TAG, "message: " + e2.getMessage());
            e2.printStackTrace();
            throw new CameraControllerException();
        } catch (ArrayIndexOutOfBoundsException e3) {
            Log.e(TAG, "failed to open camera: ArrayIndexOutOfBoundsException");
            Log.e(TAG, "message: " + e3.getMessage());
            e3.printStackTrace();
            throw new CameraControllerException();
        } catch (IllegalArgumentException e4) {
            Log.e(TAG, "failed to open camera: IllegalArgumentException");
            Log.e(TAG, "message: " + e4.getMessage());
            e4.printStackTrace();
            throw new CameraControllerException();
        } catch (SecurityException e5) {
            Log.e(TAG, "failed to open camera: SecurityException");
            Log.e(TAG, "message: " + e5.getMessage());
            e5.printStackTrace();
            throw new CameraControllerException();
        } catch (UnsupportedOperationException e6) {
            Log.e(TAG, "failed to open camera: UnsupportedOperationException");
            Log.e(TAG, "message: " + e6.getMessage());
            e6.printStackTrace();
            throw new CameraControllerException();
        }
    }

    /* renamed from: com.live.gpsmap.camera.Camera.cameracontroller.CameraController2$1MyStateCallback  reason: invalid class name */
    /* loaded from: classes.dex */
    class C1MyStateCallback extends CameraDevice.StateCallback {
        boolean callback_done;
        boolean first_callback = true;
        final /* synthetic */ CameraManager val$manager;

        C1MyStateCallback(CameraManager cameraManager) {
            this.val$manager = cameraManager;
        }

        @Override // android.hardware.camera2.CameraDevice.StateCallback
        public void onOpened(CameraDevice cameraDevice) {
            Log.d(CameraController2.TAG, "camera opened, first_callback? " + this.first_callback);
            if (this.first_callback) {
                this.first_callback = false;
                try {
                    Log.d(CameraController2.TAG, "try to get camera characteristics");
                    CameraController2 cameraController2 = CameraController2.this;
                    cameraController2.characteristics = this.val$manager.getCameraCharacteristics(cameraController2.cameraIdS);
                    Log.d(CameraController2.TAG, "successfully obtained camera characteristics");
                    CameraController2 cameraController22 = CameraController2.this;
                    cameraController22.characteristics_sensor_orientation = ((Integer) cameraController22.characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION)).intValue();
                    int intValue = ((Integer) CameraController2.this.characteristics.get(CameraCharacteristics.LENS_FACING)).intValue();
                    if (intValue == 0) {
                        CameraController2.this.characteristics_facing = CameraController.Facing.FACING_FRONT;
                    } else if (intValue == 1) {
                        CameraController2.this.characteristics_facing = CameraController.Facing.FACING_BACK;
                    } else if (intValue == 2) {
                        CameraController2.this.characteristics_facing = CameraController.Facing.FACING_EXTERNAL;
                    } else {
                        Log.e(CameraController2.TAG, "unknown camera_facing: " + CameraController2.this.characteristics.get(CameraCharacteristics.LENS_FACING));
                        CameraController2.this.characteristics_facing = CameraController.Facing.FACING_UNKNOWN;
                    }
                    Log.d(CameraController2.TAG, "characteristics_sensor_orientation: " + CameraController2.this.characteristics_sensor_orientation);
                    Log.d(CameraController2.TAG, "characteristics_facing: " + CameraController2.this.characteristics_facing);
                    if (Build.VERSION.SDK_INT>=31) {
                        CameraController2 cameraController23 = CameraController2.this;
                        cameraController23.extension_characteristics = this.val$manager.getCameraExtensionCharacteristics(cameraController23.cameraIdS);
                        Log.d(CameraController2.TAG, "successfully obtained camera characteristics");
                    }
                    CameraController2.this.camera = cameraDevice;
                    CameraController2.this.createPreviewRequest();
                } catch (CameraAccessException e) {
                    Log.e(CameraController2.TAG, "failed to get camera characteristics");
                    Log.e(CameraController2.TAG, "reason: " + e.getReason());
                    Log.e(CameraController2.TAG, "message: " + e.getMessage());
                    e.printStackTrace();
                }
                Log.d(CameraController2.TAG, "about to synchronize to say callback done");
                synchronized (CameraController2.this.open_camera_lock) {
                    this.callback_done = true;
                    Log.d(CameraController2.TAG, "callback done, about to notify");
                    CameraController2.this.open_camera_lock.notifyAll();
                    Log.d(CameraController2.TAG, "callback done, notification done");
                }
            }
        }

        @Override // android.hardware.camera2.CameraDevice.StateCallback
        public void onClosed(CameraDevice cameraDevice) {
            Log.d(CameraController2.TAG, "camera closed, first_callback? " + this.first_callback);
            if (this.first_callback) {
                this.first_callback = false;
            }
        }

        @Override // android.hardware.camera2.CameraDevice.StateCallback
        public void onDisconnected(CameraDevice cameraDevice) {
            Log.d(CameraController2.TAG, "camera disconnected, first_callback? " + this.first_callback);
            if (this.first_callback) {
                this.first_callback = false;
                CameraController2.this.camera = null;
                Log.d(CameraController2.TAG, "onDisconnected: camera is now set to null");
                cameraDevice.close();
                Log.d(CameraController2.TAG, "onDisconnected: camera is now closed");
                Log.d(CameraController2.TAG, "about to synchronize to say callback done");
                synchronized (CameraController2.this.open_camera_lock) {
                    this.callback_done = true;
                    Log.d(CameraController2.TAG, "callback done, about to notify");
                    CameraController2.this.open_camera_lock.notifyAll();
                    Log.d(CameraController2.TAG, "callback done, notification done");
                }
            }
        }

        @Override // android.hardware.camera2.CameraDevice.StateCallback
        public void onError(CameraDevice cameraDevice, int i) {
            Log.e(CameraController2.TAG, "camera error: " + i);
            Log.d(CameraController2.TAG, "received camera: " + cameraDevice);
            Log.d(CameraController2.TAG, "actual camera: " + CameraController2.this.camera);
            Log.d(CameraController2.TAG, "first_callback? " + this.first_callback);
            if (this.first_callback) {
                this.first_callback = false;
            }
            CameraController2.this.onError(cameraDevice);
            Log.d(CameraController2.TAG, "about to synchronize to say callback done");
            synchronized (CameraController2.this.open_camera_lock) {
                this.callback_done = true;
                Log.d(CameraController2.TAG, "callback done, about to notify");
                CameraController2.this.open_camera_lock.notifyAll();
                Log.d(CameraController2.TAG, "callback done, notification done");
            }
        }
    }

    private void closeCaptureSession() {
        synchronized (this.background_camera_lock) {
            if (this.captureSession != null) {
                Log.d(TAG, "close capture session");
                this.captureSession.close();
                this.captureSession = null;
            }
            if (this.extensionSession != null) {
                Log.d(TAG, "close extension session");
                if (Build.VERSION.SDK_INT>=31) {
                    try {
                        this.extensionSession.close();
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                }
                this.extensionSession = null;
            }
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void release() {
        Log.d(TAG, "release: " + this);
        closeCaptureSession();
        this.previewBuilder = null;
        this.previewIsVideoMode = false;
        CameraDevice cameraDevice = this.camera;
        if (cameraDevice != null) {
            cameraDevice.close();
            this.camera = null;
        }
        closePictureImageReader();
        HandlerThread handlerThread = this.thread;
        if (handlerThread != null) {
            handlerThread.quitSafely();
            try {
                this.thread.join();
                this.thread = null;
                this.handler = null;
                this.executor = null;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private float[] enforceMinTonemapCurvePoints(float[] fArr) {
        Log.d(TAG, "enforceMinTonemapCurvePoints: " + Arrays.toString(fArr));
        Log.d(TAG, "length: " + (fArr.length / 2));
        int i = this.is_samsung ? 32 : 64;
        Log.d(TAG, "min_points_c: " + i);
        if (fArr.length>=i * 2) {
            Log.d(TAG, "already enough points");
            return fArr;
        }
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2<fArr.length / 2; i2++) {
            int i3 = i2 * 2;
            arrayList.add(new Pair(Float.valueOf(fArr[i3]), Float.valueOf(fArr[i3 + 1])));
        }
        if (arrayList.size()<2) {
            Log.e(TAG, "less than 2 points?!");
            return fArr;
        }
        while (arrayList.size()<i) {
            float f = 0.0f;
            int i4 = 0;
            int i5 = 0;
            while (i4<arrayList.size() - 1) {
                int i6 = i4 + 1;
                float floatValue = ((Float) ((Pair) arrayList.get(i6)).first).floatValue() - ((Float) ((Pair) arrayList.get(i4)).first).floatValue();
                if (floatValue>f) {
                    i5 = i4;
                    f = floatValue;
                }
                i4 = i6;
            }
            Pair pair = (Pair) arrayList.get(i5);
            int i7 = i5 + 1;
            Pair pair2 = (Pair) arrayList.get(i7);
            arrayList.add(i7, new Pair(Float.valueOf((((Float) pair.first).floatValue() + ((Float) pair2.first).floatValue()) * 0.5f), Float.valueOf((((Float) pair.second).floatValue() + ((Float) pair2.second).floatValue()) * 0.5f)));
        }
        float[] fArr2 = new float[arrayList.size() * 2];
        for (int i8 = 0; i8<arrayList.size(); i8++) {
            Pair pair3 = (Pair) arrayList.get(i8);
            int i9 = i8 * 2;
            fArr2[i9] = ((Float) pair3.first).floatValue();
            fArr2[i9 + 1] = ((Float) pair3.second).floatValue();
        }
        return fArr2;
    }

    private void closePictureImageReader() {
        Log.d(TAG, "closePictureImageReader()");
        ImageReader imageReader = this.imageReader;
        if (imageReader != null) {
            imageReader.close();
            this.imageReader = null;
            this.onImageAvailableListener = null;
        }
        ImageReader imageReader2 = this.imageReaderRaw;
        if (imageReader2 != null) {
            imageReader2.close();
            this.imageReaderRaw = null;
            this.onRawImageAvailableListener = null;
        }
    }

    private List<String> convertFocusModesToValues(int[] supported_focus_modes_arr, float minimum_focus_distance) {
        if (MyDebug.LOG)
            Log.d(TAG, "convertFocusModesToValues()");
        if (supported_focus_modes_arr.length == 0)
            return null;
        List<Integer> supported_focus_modes = new ArrayList<>();
        for (Integer supported_focus_mode : supported_focus_modes_arr)
            supported_focus_modes.add(supported_focus_mode);
        List<String> output_modes = new ArrayList<>();
        // also resort as well as converting
        if (supported_focus_modes.contains(CaptureRequest.CONTROL_AF_MODE_AUTO)) {
            output_modes.add("focus_mode_auto");
            if (MyDebug.LOG) {
                Log.d(TAG, " supports focus_mode_auto");
            }
        }
        if (supported_focus_modes.contains(CaptureRequest.CONTROL_AF_MODE_MACRO)) {
            output_modes.add("focus_mode_macro");
            if (MyDebug.LOG)
                Log.d(TAG, " supports focus_mode_macro");
        }
        if (supported_focus_modes.contains(CaptureRequest.CONTROL_AF_MODE_AUTO)) {
            output_modes.add("focus_mode_locked");
            if (MyDebug.LOG) {
                Log.d(TAG, " supports focus_mode_locked");
            }
        }
        if (supported_focus_modes.contains(CaptureRequest.CONTROL_AF_MODE_OFF)) {
            output_modes.add("focus_mode_infinity");
            if (minimum_focus_distance>0.0f) {
                output_modes.add("focus_mode_manual2");
                if (MyDebug.LOG) {
                    Log.d(TAG, " supports focus_mode_manual2");
                }
            }
        }
        if (supported_focus_modes.contains(CaptureRequest.CONTROL_AF_MODE_EDOF)) {
            output_modes.add("focus_mode_edof");
            if (MyDebug.LOG)
                Log.d(TAG, " supports focus_mode_edof");
        }
        if (supported_focus_modes.contains(CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)) {
            output_modes.add("focus_mode_continuous_picture");
            if (MyDebug.LOG)
                Log.d(TAG, " supports focus_mode_continuous_picture");
        }
        if (supported_focus_modes.contains(CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)) {
            output_modes.add("focus_mode_continuous_video");
            if (MyDebug.LOG)
                Log.d(TAG, " supports focus_mode_continuous_video");
        }
        return output_modes;
    }

    public static int computeZoomRatios(List<Integer> list, float f, float f2) {
        String str;
        int i;
        int i2;
        ArrayList<Integer> arrayList = new ArrayList();
        for (double d = 1.0352649238413776d; d<f2 - 1.0E-5f; d *= 1.0352649238413776d) {
            arrayList.add(Integer.valueOf((int) (100.0d * d)));
        }
        int i3 = (int) (f2 * 100.0f);
        if (arrayList.size() == 0 || ((Integer) arrayList.get(arrayList.size() - 1)).intValue() != i3) {
            arrayList.add(Integer.valueOf(i3));
        }
        int size = arrayList.size();
        String str2 = TAG;
        Log.d(TAG, "n_steps_above_one: " + size);
        list.add(Integer.valueOf((int) (f * 100.0f)));
        if (list.get(0).intValue() / 100.0f<f) {
            list.set(0, Integer.valueOf(list.get(0).intValue() + 1));
        }
        if (list.get(0).intValue()<100) {
            int max = Math.max(1, size / 5);
            int max2 = Math.max(1, size / 10);
            Log.d(TAG, "n_steps_below_one: " + max);
            Log.d(TAG, "n_steps_one: " + max2);
            double d2 = (double) f;
            double pow = Math.pow((double) (1.0f / f), 1.0d / ((double) max));
            Log.d(TAG, "scale_factor for below 1.0x: " + pow);
            int i4 = 0;
            while (i4<max - 1) {
                d2 *= pow;
                String str3 = str2;
                int i5 = (int) (d2 * 100.0d);
                if (i5>list.get(0).intValue()) {
                    list.add(Integer.valueOf(i5));
                }
                i4++;
                str2 = str3;
            }
            str = str2;
            i = list.size();
            for (int i6 = 0; i6<max2; i6++) {
                list.add(100);
            }
        } else {
            str = TAG;
            i = 0;
        }
        int max3 = Math.max(1, (int) ((size / 15.0f) + 0.5f));
        Log.d(str, "n_steps_power_two: " + max3);
        for (Integer num : arrayList) {
            int intValue = num.intValue();
            list.add(Integer.valueOf(intValue));
            if (intValue != ((Integer) arrayList.get(arrayList.size() - 1)).intValue() && intValue % 100 == 0 && (i2 = intValue / 100) != 0 && (i2 & (i2 - 1)) == 0) {
                for (int i7 = 0; i7<max3 - 1; i7++) {
                    list.add(Integer.valueOf(intValue));
                }
            }
        }
        return i;
    }

//    @Override
//    public CameraFeatures getCameraFeatures() throws CameraControllerException {
//        if (MyDebug.LOG)
//            Log.d(TAG, "getCameraFeatures()");
//        CameraFeatures camera_features = new CameraFeatures();
//		/*if( true )
//			throw new CameraControllerException();*/
//        if (MyDebug.LOG) {
//            int hardware_level = characteristics.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL);
//            switch (hardware_level) {
//                case CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY:
//                    Log.d(TAG, "Hardware Level: LEGACY");
//                    break;
//                case CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED:
//                    Log.d(TAG, "Hardware Level: LIMITED");
//                    break;
//                case CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL:
//                    Log.d(TAG, "Hardware Level: FULL");
//                    break;
//                case CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_3:
//                    Log.d(TAG, "Hardware Level: Level 3");
//                    break;
//                default:
//                    Log.e(TAG, "Unknown Hardware Level: " + hardware_level);
//                    break;
//            }
//
//            int[] nr_modes = characteristics.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES);
//            Log.d(TAG, "nr_modes:");
//            if (nr_modes == null) {
//                Log.d(TAG, "    none");
//            } else {
//                for (int i = 0; i<nr_modes.length; i++) {
//                    Log.d(TAG, "    " + i + ": " + nr_modes[i]);
//                }
//            }
//        }
//
//        float max_zoom = characteristics.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
//        camera_features.is_zoom_supported = max_zoom>0.0f;
//        if (MyDebug.LOG)
//            Log.d(TAG, "max_zoom: " + max_zoom);
//        if (camera_features.is_zoom_supported) {
//            // set 20 steps per 2x factor
//            final int steps_per_2x_factor = 20;
//            //final double scale_factor = Math.pow(2.0, 1.0/(double)steps_per_2x_factor);
//            int n_steps = (int) ((steps_per_2x_factor * Math.log(max_zoom + 1.0e-11)) / Math.log(2.0));
//            final double scale_factor = Math.pow(max_zoom, 1.0 / (double) n_steps);
//            if (MyDebug.LOG) {
//                Log.d(TAG, "n_steps: " + n_steps);
//                Log.d(TAG, "scale_factor: " + scale_factor);
//            }
//            camera_features.zoom_ratios = new ArrayList<>();
//            camera_features.zoom_ratios.add(100);
//            double zoom = 1.0;
//            for (int i = 0; i<n_steps - 1; i++) {
//                zoom *= scale_factor;
//                camera_features.zoom_ratios.add((int) (zoom * 100));
//            }
//            camera_features.zoom_ratios.add((int) (max_zoom * 100));
//            camera_features.max_zoom = camera_features.zoom_ratios.size() - 1;
//            this.zoom_ratios = camera_features.zoom_ratios;
//        } else {
//            this.zoom_ratios = null;
//        }
//
//        int[] face_modes = characteristics.get(CameraCharacteristics.STATISTICS_INFO_AVAILABLE_FACE_DETECT_MODES);
//        camera_features.supports_face_detection = false;
//        supports_face_detect_mode_simple = false;
//        supports_face_detect_mode_full = false;
//        for (int face_mode : face_modes) {
//            if (MyDebug.LOG)
//                Log.d(TAG, "face detection mode: " + face_mode);
//            // we currently only make use of the "SIMPLE" features, documented as:
//            // "Return face rectangle and confidence values only."
//            // note that devices that support STATISTICS_FACE_DETECT_MODE_FULL (e.g., Nexus 6) don't return
//            // STATISTICS_FACE_DETECT_MODE_SIMPLE in the list, so we have check for either
//            if (face_mode == CameraCharacteristics.STATISTICS_FACE_DETECT_MODE_SIMPLE) {
//                camera_features.supports_face_detection = true;
//                supports_face_detect_mode_simple = true;
//                if (MyDebug.LOG)
//                    Log.d(TAG, "supports simple face detection mode");
//            } else if (face_mode == CameraCharacteristics.STATISTICS_FACE_DETECT_MODE_FULL) {
//                camera_features.supports_face_detection = true;
//                supports_face_detect_mode_full = true;
//                if (MyDebug.LOG)
//                    Log.d(TAG, "supports full face detection mode");
//            }
//        }
//        if (camera_features.supports_face_detection) {
//            int face_count = characteristics.get(CameraCharacteristics.STATISTICS_INFO_MAX_FACE_COUNT);
//            if (face_count<=0) {
//                if (MyDebug.LOG)
//                    Log.d(TAG, "can't support face detection, as zero max face count");
//                camera_features.supports_face_detection = false;
//                supports_face_detect_mode_simple = false;
//                supports_face_detect_mode_full = false;
//            }
//        }
//        if (camera_features.supports_face_detection) {
//            // check we have scene mode CONTROL_SCENE_MODE_FACE_PRIORITY
//            int[] values2 = characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES);
//            boolean has_face_priority = false;
//            for (int value2 : values2) {
//                if (value2 == CameraMetadata.CONTROL_SCENE_MODE_FACE_PRIORITY) {
//                    has_face_priority = true;
//                    break;
//                }
//            }
//            if (MyDebug.LOG)
//                Log.d(TAG, "has_face_priority: " + has_face_priority);
//            if (!has_face_priority) {
//                if (MyDebug.LOG)
//                    Log.d(TAG, "can't support face detection, as no CONTROL_SCENE_MODE_FACE_PRIORITY");
//                camera_features.supports_face_detection = false;
//                supports_face_detect_mode_simple = false;
//                supports_face_detect_mode_full = false;
//            }
//        }
//
//        if (MyDebug.LOG) {
//            int[] ois_modes = characteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION); // may be null on some devices
//            if (ois_modes != null) {
//                for (int ois_mode : ois_modes) {
//                    if (MyDebug.LOG)
//                        Log.d(TAG, "ois mode: " + ois_mode);
//                    if (ois_mode == CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_ON) {
//                        if (MyDebug.LOG)
//                            Log.d(TAG, "supports ois");
//                    }
//                }
//            }
//        }
//
//        int[] capabilities = characteristics.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
//        boolean capabilities_raw = false;
//        boolean capabilities_high_speed_video = false;
//        for (int capability : capabilities) {
//            if (capability == CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW) {
//                capabilities_raw = true;
//            } else if (capability == CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_CONSTRAINED_HIGH_SPEED_VIDEO && Build.VERSION.SDK_INT>=Build.VERSION_CODES.M) {
//                // we test for at least Android M just to be safe (this is needed for createConstrainedHighSpeedCaptureSession())
//                capabilities_high_speed_video = true;
//            }
//        }
//        if (MyDebug.LOG) {
//            Log.d(TAG, "capabilities_raw?: " + capabilities_raw);
//            Log.d(TAG, "capabilities_high_speed_video?: " + capabilities_high_speed_video);
//        }
//
//        StreamConfigurationMap configs;
//        try {
//            configs = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
//        } catch (IllegalArgumentException e) {
//            // have had crashes from Google Play - unclear what the cause is, but at least fail gracefully
//            e.printStackTrace();
//            throw new CameraControllerException();
//        }
//
//        android.util.Size[] camera_picture_sizes = configs.getOutputSizes(ImageFormat.JPEG);
//        camera_features.picture_sizes = new ArrayList<>();
//        if (android.os.Build.VERSION.SDK_INT>=android.os.Build.VERSION_CODES.M) {
//            // we add the high resolutions first, so that the camera_features.picture_sizes is sorted from high to low
//            android.util.Size[] camera_picture_sizes_hires = configs.getHighResolutionOutputSizes(ImageFormat.JPEG);
//            if (camera_picture_sizes_hires != null) {
//                for (android.util.Size camera_size : camera_picture_sizes_hires) {
//                    if (MyDebug.LOG)
//                        Log.d(TAG, "high resolution picture size: " + camera_size.getWidth() + " x " + camera_size.getHeight());
//                    // Check not already listed? If it's listed in both, we'll add it later on when scanning camera_picture_sizes
//                    // (and we don't want to set supports_burst to false for such a resolution).
//                    boolean found = false;
//                    for (android.util.Size sz : camera_picture_sizes) {
//                        if (sz.equals(camera_size))
//                            found = true;
//                    }
//                    if (!found) {
//                        CameraController.Size size = new CameraController.Size(camera_size.getWidth(), camera_size.getHeight());
//                        size.supports_burst = false;
//                        camera_features.picture_sizes.add(size);
//                    }
//                }
//            }
//        }
//        for (android.util.Size camera_size : camera_picture_sizes) {
//            if (MyDebug.LOG)
//                Log.d(TAG, "picture size: " + camera_size.getWidth() + " x " + camera_size.getHeight());
//            camera_features.picture_sizes.add(new CameraController.Size(camera_size.getWidth(), camera_size.getHeight()));
//        }
//        // test high resolution modes not supporting burst:
//        //camera_features.picture_sizes.get(0).supports_burst = false;
//
//        raw_size = null;
//        if (capabilities_raw) {
//            android.util.Size[] raw_camera_picture_sizes = configs.getOutputSizes(ImageFormat.RAW_SENSOR);
//            if (raw_camera_picture_sizes == null) {
//                if (MyDebug.LOG)
//                    Log.d(TAG, "RAW not supported, failed to get RAW_SENSOR sizes");
//                want_raw = false; // just in case it got set to true somehow
//            } else {
//                for (android.util.Size size : raw_camera_picture_sizes) {
//                    if (raw_size == null || size.getWidth() * size.getHeight()>raw_size.getWidth() * raw_size.getHeight()) {
//                        raw_size = size;
//                    }
//                }
//                if (raw_size == null) {
//                    if (MyDebug.LOG)
//                        Log.d(TAG, "RAW not supported, failed to find a raw size");
//                    want_raw = false; // just in case it got set to true somehow
//                } else {
//                    if (MyDebug.LOG)
//                        Log.d(TAG, "raw supported, raw size: " + raw_size.getWidth() + " x " + raw_size.getHeight());
//                    camera_features.supports_raw = true;
//                }
//            }
//        } else {
//            if (MyDebug.LOG)
//                Log.d(TAG, "RAW capability not supported");
//            want_raw = false; // just in case it got set to true somehow
//        }
//
//        camera_features.supports_burst = true;
//
//        ae_fps_ranges = new ArrayList<>();
//        for (Range<Integer> r : characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)) {
//            ae_fps_ranges.add(new int[]{r.getLower(), r.getUpper()});
//        }
//        Collections.sort(ae_fps_ranges, new CameraController.RangeSorter());
//        if (MyDebug.LOG) {
//            Log.d(TAG, "Supported AE video fps ranges: ");
//            for (int[] f : ae_fps_ranges) {
//                Log.d(TAG, "   ae range: [" + f[0] + "-" + f[1] + "]");
//            }
//        }
//
//        android.util.Size[] camera_video_sizes = configs.getOutputSizes(MediaRecorder.class);
//        camera_features.video_sizes = new ArrayList<>();
//        int min_fps = 9999;
//        for (int[] r : this.ae_fps_ranges) {
//            min_fps = Math.min(min_fps, r[0]);
//        }
//        for (android.util.Size camera_size : camera_video_sizes) {
//            if (camera_size.getWidth()>4096 || camera_size.getHeight()>2160)
//                continue; // Nexus 6 returns these, even though not supported?!
//            long mfd = configs.getOutputMinFrameDuration(MediaRecorder.class, camera_size);
//            int max_fps = (int) ((1.0 / mfd) * 1000000000L);
//            ArrayList<int[]> fr = new ArrayList<>();
//            fr.add(new int[]{min_fps, max_fps});
//            CameraController.Size normal_video_size = new CameraController.Size(camera_size.getWidth(), camera_size.getHeight(), fr, false);
//            camera_features.video_sizes.add(normal_video_size);
//            if (MyDebug.LOG) {
//                Log.d(TAG, "normal video size: " + normal_video_size);
//            }
//        }
//        Collections.sort(camera_features.video_sizes, new CameraController.SizeSorter());
//
//        if (capabilities_high_speed_video) {
//            hs_fps_ranges = new ArrayList<>();
//            camera_features.video_sizes_high_speed = new ArrayList<>();
//
//            for (Range<Integer> r : configs.getHighSpeedVideoFpsRanges()) {
//                hs_fps_ranges.add(new int[]{r.getLower(), r.getUpper()});
//            }
//            Collections.sort(hs_fps_ranges, new CameraController.RangeSorter());
//            if (MyDebug.LOG) {
//                Log.d(TAG, "Supported high speed video fps ranges: ");
//                for (int[] f : hs_fps_ranges) {
//                    Log.d(TAG, "   hs range: [" + f[0] + "-" + f[1] + "]");
//                }
//            }
//
//
//            android.util.Size[] camera_video_sizes_high_speed = configs.getHighSpeedVideoSizes();
//            for (android.util.Size camera_size : camera_video_sizes_high_speed) {
//                ArrayList<int[]> fr = new ArrayList<>();
//                for (Range<Integer> r : configs.getHighSpeedVideoFpsRangesFor(camera_size)) {
//                    fr.add(new int[]{r.getLower(), r.getUpper()});
//                }
//                if (camera_size.getWidth()>4096 || camera_size.getHeight()>2160)
//                    continue; // just in case? see above
//                CameraController.Size hs_video_size = new CameraController.Size(camera_size.getWidth(), camera_size.getHeight(), fr, true);
//                if (MyDebug.LOG) {
//                    Log.d(TAG, "high speed video size: " + hs_video_size);
//                }
//                camera_features.video_sizes_high_speed.add(hs_video_size);
//            }
//            Collections.sort(camera_features.video_sizes_high_speed, new CameraController.SizeSorter());
//        }
//
//        android.util.Size[] camera_preview_sizes = configs.getOutputSizes(SurfaceTexture.class);
//        camera_features.preview_sizes = new ArrayList<>();
//        Point display_size = new Point();
//        Activity activity = (Activity) context;
//        {
//            Display display = activity.getWindowManager().getDefaultDisplay();
//            display.getRealSize(display_size);
//            // getRealSize() is adjusted based on the current rotation, so should already be landscape format, but it
//            // would be good to not assume Open Camera runs in landscape mode (if we ever ran in portrait mode,
//            // we'd still want display_size.x > display_size.y as preview resolutions also have width > height)
//            if (display_size.x<display_size.y) {
//                display_size.set(display_size.y, display_size.x);
//            }
//            if (MyDebug.LOG)
//                Log.d(TAG, "display_size: " + display_size.x + " x " + display_size.y);
//        }
//        for (android.util.Size camera_size : camera_preview_sizes) {
//            if (MyDebug.LOG)
//                Log.d(TAG, "preview size: " + camera_size.getWidth() + " x " + camera_size.getHeight());
//            if (camera_size.getWidth()>display_size.x || camera_size.getHeight()>display_size.y) {
//                // Nexus 6 returns these, even though not supported?! (get green corruption lines if we allow these)
//                // Google Camera filters anything larger than height 1080, with a todo saying to use device's measurements
//                continue;
//            }
//            camera_features.preview_sizes.add(new CameraController.Size(camera_size.getWidth(), camera_size.getHeight()));
//        }
//
//        if (characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE)) {
//            camera_features.supported_flash_values = new ArrayList<>();
//            camera_features.supported_flash_values.add("flash_off");
//            camera_features.supported_flash_values.add("flash_auto");
//            camera_features.supported_flash_values.add("flash_on");
//            camera_features.supported_flash_values.add("flash_torch");
//            if (!use_fake_precapture) {
//                camera_features.supported_flash_values.add("flash_red_eye");
//            }
//        } else if (getFacing() == CameraController.Facing.FACING_FRONT) {
//            camera_features.supported_flash_values = new ArrayList<>();
//            camera_features.supported_flash_values.add("flash_off");
//            camera_features.supported_flash_values.add("flash_frontscreen_auto");
//            camera_features.supported_flash_values.add("flash_frontscreen_on");
//            camera_features.supported_flash_values.add("flash_frontscreen_torch");
//        }
//
//        Float minimum_focus_distance = characteristics.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE); // may be null on some devices
//        if (minimum_focus_distance != null) {
//            camera_features.minimum_focus_distance = minimum_focus_distance;
//            if (MyDebug.LOG)
//                Log.d(TAG, "minimum_focus_distance: " + camera_features.minimum_focus_distance);
//        } else {
//            camera_features.minimum_focus_distance = 0.0f;
//        }
//
//        int[] supported_focus_modes = characteristics.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES); // Android format
//        camera_features.supported_focus_values = convertFocusModesToValues(supported_focus_modes, camera_features.minimum_focus_distance); // convert to our format (also resorts)
//        if (camera_features.supported_focus_values != null && camera_features.supported_focus_values.contains("focus_mode_manual2")) {
//            camera_features.supports_focus_bracketing = true;
//        }
//        camera_features.max_num_focus_areas = characteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF);
//
//        camera_features.is_exposure_lock_supported = true;
//
//        camera_features.is_video_stabilization_supported = false;
//        int[] supported_video_stabilization_modes = characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES);
//        if (supported_video_stabilization_modes != null) {
//            for (int supported_video_stabilization_mode : supported_video_stabilization_modes) {
//                if (supported_video_stabilization_mode == CameraCharacteristics.CONTROL_VIDEO_STABILIZATION_MODE_ON) {
//                    camera_features.is_video_stabilization_supported = true;
//                }
//            }
//        }
//        if (MyDebug.LOG)
//            Log.d(TAG, "is_video_stabilization_supported: " + camera_features.is_video_stabilization_supported);
//
//        // although we currently require at least LIMITED to offer Camera2, we explicitly check here in case we do ever support
//        // LEGACY devices
//        camera_features.is_photo_video_recording_supported = CameraControllerManager2.isHardwareLevelSupported(characteristics, CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED);
//        supports_photo_video_recording = camera_features.is_photo_video_recording_supported;
//
//        int[] white_balance_modes = characteristics.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES);
//        if (white_balance_modes != null) {
//            for (int value : white_balance_modes) {
//                if (value == CameraMetadata.CONTROL_AWB_MODE_OFF && allowManualWB()) {
//                    camera_features.supports_white_balance_temperature = true;
//                    camera_features.min_temperature = min_white_balance_temperature_c;
//                    camera_features.max_temperature = max_white_balance_temperature_c;
//                }
//            }
//        }
//
//        Range<Integer> iso_range = characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE); // may be null on some devices
//        if (iso_range != null) {
//            camera_features.supports_iso_range = true;
//            camera_features.min_iso = iso_range.getLower();
//            camera_features.max_iso = iso_range.getUpper();
//            // we only expose exposure_time if iso_range is supported
//            Range<Long> exposure_time_range = characteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE); // may be null on some devices
//            if (exposure_time_range != null) {
//                camera_features.supports_exposure_time = true;
//                camera_features.supports_expo_bracketing = true;
//                camera_features.max_expo_bracketing_n_images = max_expo_bracketing_n_images;
//                camera_features.min_exposure_time = exposure_time_range.getLower();
//                camera_features.max_exposure_time = exposure_time_range.getUpper();
//            }
//        }
//
//        Range<Integer> exposure_range = characteristics.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
//        camera_features.min_exposure = exposure_range.getLower();
//        camera_features.max_exposure = exposure_range.getUpper();
//        camera_features.exposure_step = characteristics.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP).floatValue();
//
//        camera_features.can_disable_shutter_sound = true;
//
//        Integer tonemap_max_curve_points = characteristics.get(CameraCharacteristics.TONEMAP_MAX_CURVE_POINTS);
//        if (tonemap_max_curve_points != null) {
//            if (MyDebug.LOG)
//                Log.d(TAG, "tonemap_max_curve_points: " + tonemap_max_curve_points);
//            camera_features.tonemap_max_curve_points = tonemap_max_curve_points;
//            camera_features.supports_tonemap_curve = tonemap_max_curve_points>=64;
//        } else {
//            if (MyDebug.LOG)
//                Log.d(TAG, "tonemap_max_curve_points is null");
//        }
//        if (MyDebug.LOG)
//            Log.d(TAG, "supports_tonemap_curve?: " + camera_features.supports_tonemap_curve);
//
//        {
//            // Calculate view angles
//            // Note this is an approximation (see http://stackoverflow.com/questions/39965408/what-is-the-android-camera2-api-equivalent-of-camera-parameters-gethorizontalvie ).
//            // Potentially we could do better, taking into account the aspect ratio of the current resolution.
//            // Note that we'd want to distinguish between the field of view of the preview versus the photo (or view) (for example,
//            // DrawPreview would want the preview's field of view).
//            // Also if we wanted to do this, we'd need to make sure that this was done after the caller had set the desired preview
//            // and photo/video resolutions.
//            SizeF physical_size = characteristics.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
//            float[] focal_lengths = characteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
//            camera_features.view_angle_x = (float) Math.toDegrees(2.0 * Math.atan2(physical_size.getWidth(), (2.0 * focal_lengths[0])));
//            camera_features.view_angle_y = (float) Math.toDegrees(2.0 * Math.atan2(physical_size.getHeight(), (2.0 * focal_lengths[0])));
//            if (MyDebug.LOG) {
//                Log.d(TAG, "view_angle_x: " + camera_features.view_angle_x);
//                Log.d(TAG, "view_angle_y: " + camera_features.view_angle_y);
//            }
//        }
//
//        return camera_features;
//    }


    @Override  // com.gpsmapcamera.geotagginglocationonphoto.Camera.cameracontroller.CameraController
    public CameraFeatures getCameraFeatures() throws CameraControllerException {
        android.util.Size[] arr_size4;
        int v29;
        int v19;
        StreamConfigurationMap streamConfigurationMap0;
        boolean v8;
        float f1;
        float f;
        CameraController2 cameraController20 = this;
        Log.d("CameraController2", "getCameraFeatures()");
        CameraFeatures cameraController$CameraFeatures0 = new CameraFeatures();
        int v = (int)(((Integer)cameraController20.characteristics.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)));
        if(v == 0) {
            Log.d("CameraController2", "Hardware Level: LIMITED");
        }
        else if(v == 1) {
            Log.d("CameraController2", "Hardware Level: FULL");
        }
        else if(v == 2) {
            Log.d("CameraController2", "Hardware Level: LEGACY");
        }
        else if(v == 3) {
            Log.d("CameraController2", "Hardware Level: Level 3");
        }
        else {
            Log.e("CameraController2", "Unknown Hardware Level: " + v);
        }

        int[] arr_v = (int[])cameraController20.characteristics.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES);
        Log.d("CameraController2", "nr_modes:");
        if(arr_v == null) {
            Log.d("CameraController2", "    none");
        }
        else {
            int v1;
            for(v1 = 0; v1 < arr_v.length; ++v1) {
                Log.d("CameraController2", "    " + v1 + ": " + arr_v[v1]);
            }
        }

        if(Build.VERSION.SDK_INT >= 30) {
            Capability[] arr_capability = (Capability[])cameraController20.characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_EXTENDED_SCENE_MODE_CAPABILITIES);
            Log.d("CameraController2", "capabilities:");
            if(arr_capability == null) {
                Log.d("CameraController2", "    none");
            }
            else {
                int v2;
                for(v2 = 0; v2 < arr_capability.length; ++v2) {
                    Log.d("CameraController2", "    " + v2 + ": " + arr_capability[v2].getMode());
                }
            }
        }

        if(Build.VERSION.SDK_INT >= 30) {
            Range range0 = (Range)cameraController20.characteristics.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);
            if(range0 == null) {
                Log.d("CameraController2", "zoom_ratio_range not supported");
                f1 = 0.0f;
                f = 0.0f;
            }
            else {
                f = (float)(((Float)range0.getLower()));
                f1 = (float)(((Float)range0.getUpper()));
            }
        }
        else {
            f = 1.0f;
            f1 = (float)(((Float)cameraController20.characteristics.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM)));
        }

        cameraController$CameraFeatures0.is_zoom_supported = f1 > 0.0f && f > 0.0f;
        Log.d("CameraController2", "zYeRbhLwe.CtGFV" + f);
        Log.d("CameraController2", "max_zoom: " + f1);
        if(cameraController$CameraFeatures0.is_zoom_supported) {
            ArrayList arrayList0 = new ArrayList();
            cameraController20.zoom_value_1x = CameraController2.computeZoomRatios(arrayList0, f, f1);
            cameraController$CameraFeatures0.zoom_ratios = arrayList0;
            cameraController$CameraFeatures0.max_zoom = cameraController$CameraFeatures0.zoom_ratios.size() - 1;
            cameraController20.zoom_ratios = cameraController$CameraFeatures0.zoom_ratios;
            Log.d("CameraController2", "zoom_ratios: " + cameraController20.zoom_ratios);
        }
        else {
            cameraController20.zoom_ratios = null;
        }

        int[] arr_v1 = (int[])cameraController20.characteristics.get(CameraCharacteristics.STATISTICS_INFO_AVAILABLE_FACE_DETECT_MODES);
        cameraController$CameraFeatures0.supports_face_detection = false;
        cameraController20.supports_face_detect_mode_simple = false;
        cameraController20.supports_face_detect_mode_full = false;
        int v3 = arr_v1.length;
        int v4;
        for(v4 = 0; v4 < v3; ++v4) {
            int v5 = arr_v1[v4];
            Log.d("CameraController2", "face detection mode: " + v5);
            if(v5 == 1) {
                cameraController$CameraFeatures0.supports_face_detection = true;
                cameraController20.supports_face_detect_mode_simple = true;
                Log.d("CameraController2", "supports simple face detection mode");
            }
            else if(v5 == 2) {
                cameraController$CameraFeatures0.supports_face_detection = true;
                cameraController20.supports_face_detect_mode_full = true;
                Log.d("CameraController2", "supports full face detection mode");
            }
        }

        if((cameraController$CameraFeatures0.supports_face_detection) && ((int)(((Integer)cameraController20.characteristics.get(CameraCharacteristics.STATISTICS_INFO_MAX_FACE_COUNT)))) <= 0) {
            Log.d("CameraController2", "can\'t support face detection, as zero max face count");
            cameraController$CameraFeatures0.supports_face_detection = false;
            cameraController20.supports_face_detect_mode_simple = false;
            cameraController20.supports_face_detect_mode_full = false;
        }

        if(cameraController$CameraFeatures0.supports_face_detection) {
            int[] arr_v2 = (int[])cameraController20.characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES);
            int v6 = arr_v2.length;
            int v7 = 0;
            while(v7 < v6) {
                if(arr_v2[v7] == 1) {
                    v8 = true;
//                    label_249:
                    Log.d("CameraController2", "has_face_priority: " + ((boolean)v8));
                    if(!v8) {
                        Log.d("CameraController2", "can\'t support face detection, as no CONTROL_SCENE_MODE_FACE_PRIORITY");
                        cameraController$CameraFeatures0.supports_face_detection = false;
                        cameraController20.supports_face_detect_mode_simple = false;
                        cameraController20.supports_face_detect_mode_full = false;
                    }
                }

                ++v7;
            }

            v8 = false;

        }

        int[] arr_v3 = (int[])cameraController20.characteristics.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
        int v9 = arr_v3.length;
        int v10 = 0;
        int v11 = 0;
        int v12 = 0;
        int v13 = 0;
        while(v10 < v9) {
            int v14 = arr_v3[v10];
            if(v14 == 2) {
                v11 = 1;
            }
            else if(v14 == 3) {
                v12 = 1;
            }
            else if(v14 == 9 && Build.VERSION.SDK_INT >= 23) {
                v13 = 1;
            }
            else if(v14 == 11) {
                Log.d("CameraController2", "camera is a logical multi-camera");
            }

            ++v10;
        }

        cameraController$CameraFeatures0.supports_burst = CameraControllerManager2.isHardwareLevelSupported(cameraController20.characteristics, 0);
//        Log.d("CameraController2", "capabilities_manual_post_processing?: " + ((boolean)v11));
//        Log.d("CameraController2", "eosnTyAJZiNdb.Kfnvi" + ((boolean)v12));
//        Log.d("CameraController2", "supports_burst?: " + cameraController$CameraFeatures0.supports_burst);
//        Log.d("CameraController2", "capabilities_high_speed_video?: " + ((boolean)v13));
        try {
            streamConfigurationMap0 = (StreamConfigurationMap)cameraController20.characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        }
        catch(IllegalArgumentException | NullPointerException nullPointerException0) {
            nullPointerException0.printStackTrace();
            throw new CameraControllerException();
        }

        android.util.Size[] arr_size = streamConfigurationMap0.getOutputSizes(0x100);
        cameraController$CameraFeatures0.picture_sizes = new ArrayList();
        if(Build.VERSION.SDK_INT >= 23) {
            android.util.Size[] arr_size1 = streamConfigurationMap0.getHighResolutionOutputSizes(0x100);
            if(arr_size1 != null) {
                int v15 = arr_size1.length;
                int v16 = 0;
                while(v16 < v15) {
                    android.util.Size size0 = arr_size1[v16];
                    Log.d("CameraController2", "high resolution picture size: " + size0.getWidth() + " x " + size0.getHeight());
                    int v17 = arr_size.length;
                    int v18 = 0;
                    while(v18 < v17) {
                        if(arr_size[v18].equals(size0)) {
                            v19 = 1;
//                            label_390:
                            if(v19 == 0) {
                                Log.d("CameraController2", "high resolution [non-burst] picture size: " + size0.getWidth() + " x " + size0.getHeight());
                                CameraController.Size cameraController$Size0 = new CameraController.Size(size0.getWidth(), size0.getHeight());
                                cameraController$Size0.supports_burst = false;
                                cameraController$CameraFeatures0.picture_sizes.add(cameraController$Size0);
                            }
                        }

                        ++v18;
                    }

                    v19 = 0;
//                    label_390:
//                    if(v19 == 0) {
//                        Log.d("CameraController2", "high resolution [non-burst] picture size: " + size0.getWidth() + " x " + size0.getHeight());
//                        com.gpsmapcamera.geotagginglocationonphoto.Camera.cameracontroller.CameraController.Size cameraController$Size0 = new com.gpsmapcamera.geotagginglocationonphoto.Camera.cameracontroller.CameraController.Size(size0.getWidth(), size0.getHeight());
//                        cameraController$Size0.supports_burst = false;
//                        cameraController$CameraFeatures0.picture_sizes.add(cameraController$Size0);
//                    }

                    ++v16;
                }
            }
        }

        if(arr_size != null) {
            int v20 = arr_size.length;
            int v21;
            for(v21 = 0; v21 < v20; ++v21) {
                android.util.Size size1 = arr_size[v21];
                Log.d("CameraController2", "picture size: " + size1.getWidth() + " x " + size1.getHeight());
                cameraController$CameraFeatures0.picture_sizes.add(new CameraController.Size(size1.getWidth(), size1.getHeight()));
            }

            Collections.sort(cameraController$CameraFeatures0.picture_sizes, new SizeSorter());
            cameraController20.raw_size = null;
            if(v12 == 0) {
                Log.d("CameraController2", "RAW capability not supported");
                cameraController20.want_raw = false;
            }
            else {
                android.util.Size[] arr_size2 = streamConfigurationMap0.getOutputSizes(0x20);
                if(arr_size2 == null) {
                    Log.d("CameraController2", "RAW not supported, failed to get RAW_SENSOR sizes");
                    cameraController20.want_raw = false;
                }
                else {
                    int v22 = arr_size2.length;
                    int v23;
                    for(v23 = 0; v23 < v22; ++v23) {
                        android.util.Size size2 = arr_size2[v23];
                        if(cameraController20.raw_size == null || size2.getWidth() * size2.getHeight() > cameraController20.raw_size.getWidth() * cameraController20.raw_size.getHeight()) {
                            cameraController20.raw_size = size2;
                        }
                    }

                    if(cameraController20.raw_size == null) {
                        Log.d("CameraController2", "RAW not supported, failed to find a raw size");
                        cameraController20.want_raw = false;
                    }
                    else {
                        Log.d("CameraController2", "raw supported, raw size: " + cameraController20.raw_size.getWidth() + " x " + cameraController20.raw_size.getHeight());
                        cameraController$CameraFeatures0.supports_raw = true;
                    }
                }
            }

            cameraController20.ae_fps_ranges = new ArrayList();
            Range[] arr_range = (Range[])cameraController20.characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
            int v24 = arr_range.length;
            int v25;
            for(v25 = 0; v25 < v24; ++v25) {
                Range range1 = arr_range[v25];
                cameraController20.ae_fps_ranges.add(new int[]{((int)(((Integer)range1.getLower()))), ((int)(((Integer)range1.getUpper())))});
            }

            Collections.sort(cameraController20.ae_fps_ranges, new RangeSorter());
            Log.d("CameraController2", "Supported AE video fps ranges: ");
            for(Object object0: cameraController20.ae_fps_ranges) {
                int[] arr_v4 = (int[])object0;
                Log.d("CameraController2", "   ae range: [" + arr_v4[0] + "-" + arr_v4[1] + "]");
            }

            android.util.Size[] arr_size3 = streamConfigurationMap0.getOutputSizes(MediaRecorder.class);
            cameraController$CameraFeatures0.video_sizes = new ArrayList();
            int v26 = 0x270F;
            for(Object object1: cameraController20.ae_fps_ranges) {
                v26 = Math.min(v26, ((int[])object1)[0]);
            }

            if(arr_size3 != null) {
                int v27 = arr_size3.length;
                int v28 = 0;
                while(v28 < v27) {
                    android.util.Size size3 = arr_size3[v28];
                    if(size3.getWidth() <= 0x1000 && size3.getHeight() <= 0x870) {
                        v29 = v11;
                        int v30 = (int)(1000000000.0 * (1.0 / ((double)streamConfigurationMap0.getOutputMinFrameDuration(MediaRecorder.class, size3))));
                        ArrayList arrayList1 = new ArrayList();
                        arr_size4 = arr_size3;
                        arrayList1.add(new int[]{v26, v30});
                        CameraController.Size cameraController$Size1 = new CameraController.Size(size3.getWidth(), size3.getHeight(), arrayList1, false);
                        cameraController$CameraFeatures0.video_sizes.add(cameraController$Size1);
                        Log.d("CameraController2", "normal video size: " + cameraController$Size1);
                    }
                    else {
                        arr_size4 = arr_size3;
                        v29 = v11;
                    }

                    ++v28;
                    v11 = v29;
                    arr_size3 = arr_size4;
                }

                int v31 = v11;
                Collections.sort(cameraController$CameraFeatures0.video_sizes, new SizeSorter());
                if(v13 != 0) {
                    cameraController20.hs_fps_ranges = new ArrayList();
                    cameraController$CameraFeatures0.video_sizes_high_speed = new ArrayList();
                    Range[] arr_range1 = streamConfigurationMap0.getHighSpeedVideoFpsRanges();
                    int v32 = arr_range1.length;
                    int v33;
                    for(v33 = 0; v33 < v32; ++v33) {
                        Range range2 = arr_range1[v33];
                        cameraController20.hs_fps_ranges.add(new int[]{((int)(((Integer)range2.getLower()))), ((int)(((Integer)range2.getUpper())))});
                    }

                    Collections.sort(cameraController20.hs_fps_ranges, new RangeSorter());
                    Log.d("CameraController2", "Supported high speed video fps ranges: ");
                    for(Object object2: cameraController20.hs_fps_ranges) {
                        int[] arr_v5 = (int[])object2;
                        Log.d("CameraController2", "   hs range: [" + arr_v5[0] + "-" + arr_v5[1] + "]");
                    }

                    android.util.Size[] arr_size5 = streamConfigurationMap0.getHighSpeedVideoSizes();
                    int v34 = arr_size5.length;
                    int v35;
                    for(v35 = 0; v35 < v34; ++v35) {
                        android.util.Size size4 = arr_size5[v35];
                        ArrayList arrayList2 = new ArrayList();
                        Range[] arr_range2 = streamConfigurationMap0.getHighSpeedVideoFpsRangesFor(size4);
                        int v36 = arr_range2.length;
                        int v37;
                        for(v37 = 0; v37 < v36; ++v37) {
                            Range range3 = arr_range2[v37];
                            arrayList2.add(new int[]{((int)(((Integer)range3.getLower()))), ((int)(((Integer)range3.getUpper())))});
                        }

                        if(size4.getWidth() <= 0x1000 && size4.getHeight() <= 0x870) {
                           CameraController.Size cameraController$Size2 = new CameraController.Size(size4.getWidth(), size4.getHeight(), arrayList2, true);
                            Log.d("CameraController2", "high speed video size: " + cameraController$Size2);
                            cameraController$CameraFeatures0.video_sizes_high_speed.add(cameraController$Size2);
                        }
                    }

                    Collections.sort(cameraController$CameraFeatures0.video_sizes_high_speed, new SizeSorter());
                }

                android.util.Size[] arr_size6 = streamConfigurationMap0.getOutputSizes(SurfaceTexture.class);
                cameraController$CameraFeatures0.preview_sizes = new ArrayList();
                Point point0 = new Point();
                ((Activity)cameraController20.context).getWindowManager().getDefaultDisplay().getRealSize(point0);
                if(point0.x < point0.y) {
                    point0.set(point0.y, point0.x);
                }

                Log.d("CameraController2", "display_size: " + point0.x + " x " + point0.y);
                if(arr_size6 != null) {
                    int v38 = arr_size6.length;
                    int v39;
                    for(v39 = 0; v39 < v38; ++v39) {
                        android.util.Size size5 = arr_size6[v39];
                        Log.d("CameraController2", "preview size: " + size5.getWidth() + " x " + size5.getHeight());
                        if(size5.getWidth() <= point0.x && size5.getHeight() <= point0.y) {
                            cameraController$CameraFeatures0.preview_sizes.add(new CameraController.Size(size5.getWidth(), size5.getHeight()));
                        }
                    }

                    if(Build.VERSION.SDK_INT >= 0x1F) {
                        List list0 = cameraController20.extension_characteristics.getSupportedExtensions();
                        if(list0 != null) {
                            cameraController$CameraFeatures0.supported_extensions = new ArrayList();
                            for(Object object3: list0) {
                                int v40 = (int)(((Integer)object3));
                                Log.d("CameraController2", "vendor extension: " + v40);
                                List list1 = cameraController20.extension_characteristics.getExtensionSupportedSizes(v40, 0x100);
                                Log.d("CameraController2", "    extension_picture_sizes: " + list1);
                                Iterator iterator4 = cameraController$CameraFeatures0.picture_sizes.iterator();
                                int v41 = 0;
                                while(iterator4.hasNext()) {
                                    Object object4 = iterator4.next();
                                    CameraController.Size cameraController$Size3 = (CameraController.Size)object4;
                                    if(list1.contains(new Size(cameraController$Size3.width, cameraController$Size3.height))) {
                                        Log.d("CameraController2", "    picture size supports extension: " + cameraController$Size3.width + " , " + cameraController$Size3.height);
                                        if(cameraController$Size3.supported_extensions == null) {
                                            cameraController$Size3.supported_extensions = new ArrayList();
                                        }

                                        cameraController$Size3.supported_extensions.add(Integer.valueOf(v40));
                                        v41 = 1;
                                        continue;
                                    }

                                    Log.d("CameraController2", "    picture size does NOT support extension: " + cameraController$Size3.width + " , " + cameraController$Size3.height);
                                }

                                List list2 = cameraController20.extension_characteristics.getExtensionSupportedSizes(v40, SurfaceTexture.class);
                                Log.d("CameraController2", "    extension_preview_sizes: " + list2);
                                Iterator iterator5 = cameraController$CameraFeatures0.preview_sizes.iterator();
                                int v42 = 0;
                                while(iterator5.hasNext()) {
                                    Object object5 = iterator5.next();
                                    CameraController.Size cameraController$Size4 = (CameraController.Size)object5;
                                    if(list2.contains(new Size(cameraController$Size4.width, cameraController$Size4.height))) {
                                        Log.d("CameraController2", "    preview size supports extension: " + cameraController$Size4.width + " , " + cameraController$Size4.height);
                                        if(cameraController$Size4.supported_extensions == null) {
                                            cameraController$Size4.supported_extensions = new ArrayList();
                                        }

                                        cameraController$Size4.supported_extensions.add(Integer.valueOf(v40));
                                        v42 = 1;
                                        continue;
                                    }

                                    Log.d("CameraController2", "    preview size does NOT support extension: " + cameraController$Size4.width + " , " + cameraController$Size4.height);
                                }

                                if(v41 == 0 || v42 == 0) {
                                    continue;
                                }

                                Log.d("CameraController2", "    extension is supported: " + v40);
                                cameraController$CameraFeatures0.supported_extensions.add(Integer.valueOf(v40));
                            }
                        }
                    }

                    if(((Boolean)cameraController20.characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE)).booleanValue()) {
                        int[] arr_v6 = (int[])cameraController20.characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES);
                        ArrayList arrayList3 = new ArrayList();
                        int v43 = arr_v6.length;
                        int v44;
                        for(v44 = 0; v44 < v43; ++v44) {
                            arrayList3.add(Integer.valueOf(arr_v6[v44]));
                        }

                        cameraController$CameraFeatures0.supported_flash_values = new ArrayList();
                        cameraController$CameraFeatures0.supported_flash_values.add("flash_off");
                        cameraController$CameraFeatures0.supported_flash_values.add("flash_auto");
                        cameraController$CameraFeatures0.supported_flash_values.add("flash_on");
                        cameraController$CameraFeatures0.supported_flash_values.add("flash_torch");
                        if(!cameraController20.use_fake_precapture && (arrayList3.contains(Integer.valueOf(4)))) {
                            cameraController$CameraFeatures0.supported_flash_values.add("flash_red_eye");
                            Log.d("CameraController2", " supports flash_red_eye");
                        }
                    }
                    else if(this.getFacing() == Facing.FACING_FRONT) {
                        cameraController$CameraFeatures0.supported_flash_values = new ArrayList();
                        cameraController$CameraFeatures0.supported_flash_values.add("flash_off");
                        cameraController$CameraFeatures0.supported_flash_values.add("flash_frontscreen_auto");
                        cameraController$CameraFeatures0.supported_flash_values.add("flash_frontscreen_on");
                        cameraController$CameraFeatures0.supported_flash_values.add("flash_frontscreen_torch");
                    }

                    Float float0 = (Float)cameraController20.characteristics.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE);
                    if(float0 == null) {
                        cameraController$CameraFeatures0.minimum_focus_distance = 0.0f;
                    }
                    else {
                        cameraController$CameraFeatures0.minimum_focus_distance = (float)float0;
                        Log.d("CameraController2", "minimum_focus_distance: " + cameraController$CameraFeatures0.minimum_focus_distance);
                    }

                    cameraController$CameraFeatures0.supported_focus_values = cameraController20.convertFocusModesToValues(((int[])cameraController20.characteristics.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)), cameraController$CameraFeatures0.minimum_focus_distance);
                    if(cameraController$CameraFeatures0.supported_focus_values != null && (cameraController$CameraFeatures0.supported_focus_values.contains("focus_mode_manual2"))) {
                        cameraController$CameraFeatures0.supports_focus_bracketing = true;
                    }

                    if(cameraController$CameraFeatures0.supported_focus_values == null) {
                        cameraController20.initial_focus_mode = null;
                    }
                    else {
                        cameraController20.initial_focus_mode = cameraController$CameraFeatures0.supported_focus_values.contains("focus_mode_continuous_picture") ? "focus_mode_continuous_picture" : ((String)cameraController$CameraFeatures0.supported_focus_values.get(0));
                        Log.d("CameraController2", "initial_focus_mode: " + cameraController20.initial_focus_mode);
                    }

                    cameraController$CameraFeatures0.max_num_focus_areas = (int)(((Integer)cameraController20.characteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF)));
                    cameraController$CameraFeatures0.is_exposure_lock_supported = true;
                    cameraController$CameraFeatures0.is_white_balance_lock_supported = true;
                    cameraController$CameraFeatures0.is_optical_stabilization_supported = false;
                    int[] arr_v7 = (int[])cameraController20.characteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION);
                    if(arr_v7 != null) {
                        int v45 = arr_v7.length;
                        int v46;
                        for(v46 = 0; v46 < v45; ++v46) {
                            if(arr_v7[v46] == 1) {
                                cameraController$CameraFeatures0.is_optical_stabilization_supported = true;
                                break;
                            }
                        }
                    }

                    Log.d("CameraController2", "is_optical_stabilization_supported: " + cameraController$CameraFeatures0.is_optical_stabilization_supported);
                    cameraController20.supports_optical_stabilization = cameraController$CameraFeatures0.is_optical_stabilization_supported;
                    cameraController$CameraFeatures0.is_video_stabilization_supported = false;
                    int[] arr_v8 = (int[])cameraController20.characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES);
                    if(arr_v8 != null) {
                        int v47 = arr_v8.length;
                        int v48;
                        for(v48 = 0; v48 < v47; ++v48) {
                            if(arr_v8[v48] == 1) {
                                cameraController$CameraFeatures0.is_video_stabilization_supported = true;
                                break;
                            }
                        }
                    }

                    Log.d("CameraController2", "is_video_stabilization_supported: " + cameraController$CameraFeatures0.is_video_stabilization_supported);
                    cameraController$CameraFeatures0.is_photo_video_recording_supported = CameraControllerManager2.isHardwareLevelSupported(cameraController20.characteristics, 0);
                    cameraController20.supports_photo_video_recording = cameraController$CameraFeatures0.is_photo_video_recording_supported;
                    int[] arr_v9 = (int[])cameraController20.characteristics.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES);
                    if(arr_v9 != null) {
                        int v49 = arr_v9.length;
                        int v50;
                        for(v50 = 0; v50 < v49; ++v50) {
                            if(arr_v9[v50] == 0 && v31 != 0 && (this.allowManualWB())) {
                                cameraController$CameraFeatures0.supports_white_balance_temperature = true;
                                cameraController$CameraFeatures0.min_temperature = 1000;
                                cameraController$CameraFeatures0.max_temperature = 15000;
                            }
                        }
                    }

                    cameraController20.supports_white_balance_temperature = cameraController$CameraFeatures0.supports_white_balance_temperature;
                    if(CameraControllerManager2.isHardwareLevelSupported(cameraController20.characteristics, 0)) {
                        Range range4 = (Range)cameraController20.characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
                        if(range4 != null) {
                            cameraController$CameraFeatures0.supports_iso_range = true;
                            cameraController$CameraFeatures0.min_iso = (int)(((Integer)range4.getLower()));
                            cameraController$CameraFeatures0.max_iso = (int)(((Integer)range4.getUpper()));
                            Range range5 = (Range)cameraController20.characteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
                            if(range5 != null) {
                                cameraController$CameraFeatures0.supports_exposure_time = true;
                                cameraController$CameraFeatures0.supports_expo_bracketing = true;
                                cameraController$CameraFeatures0.max_expo_bracketing_n_images = 5;
                                cameraController$CameraFeatures0.min_exposure_time = (long)(((Long)range5.getLower()));
                                cameraController$CameraFeatures0.max_exposure_time = (long)(((Long)range5.getUpper()));
                                if((cameraController20.is_samsung_galaxy_s) && Build.VERSION.SDK_INT >= 29) {
                                    Log.d("CameraController2", "boost max_exposure_time, was: " + cameraController20.max_exposure_time);
                                    cameraController$CameraFeatures0.max_exposure_time = Math.max(cameraController$CameraFeatures0.max_exposure_time, 200000000L);
                                }
                            }
                        }
                    }

                    cameraController20.supports_exposure_time = cameraController$CameraFeatures0.supports_exposure_time;
                    cameraController20.min_exposure_time = cameraController$CameraFeatures0.min_exposure_time;
                    cameraController20.max_exposure_time = cameraController$CameraFeatures0.max_exposure_time;
                    Range range6 = (Range)cameraController20.characteristics.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
                    cameraController$CameraFeatures0.min_exposure = (int)(((Integer)range6.getLower()));
                    cameraController$CameraFeatures0.max_exposure = (int)(((Integer)range6.getUpper()));
                    cameraController$CameraFeatures0.exposure_step = ((Rational)cameraController20.characteristics.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)).floatValue();
                    cameraController$CameraFeatures0.can_disable_shutter_sound = true;
                    if(v31 != 0) {
                        Integer integer0 = (Integer)cameraController20.characteristics.get(CameraCharacteristics.TONEMAP_MAX_CURVE_POINTS);
                        if(integer0 == null) {
                            Log.d("CameraController2", "tonemap_max_curve_points is null");
                        }
                        else {
                            Log.d("CameraController2", "tonemap_max_curve_points: " + integer0);
                            cameraController$CameraFeatures0.tonemap_max_curve_points = (int)integer0;
                            cameraController$CameraFeatures0.supports_tonemap_curve = ((int)integer0) >= 0x40 && ((int)integer0) >= cameraController20.jtvideo_values.length / 2 && ((int)integer0) >= cameraController20.jtlog_values.length / 2 && ((int)integer0) >= cameraController20.jtlog2_values.length / 2;
                        }
                    }

                    Log.d("CameraController2", "supports_tonemap_curve?: " + cameraController$CameraFeatures0.supports_tonemap_curve);
                    float[] arr_f = (float[])cameraController20.characteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES);
                    Log.d("CameraController2", "apertures: " + Arrays.toString(arr_f));
                    if(arr_f != null && arr_f.length > 1) {
                        cameraController$CameraFeatures0.apertures = arr_f;
                    }

                    SizeF sizeF0 = CameraControllerManager2.computeViewAngles(cameraController20.characteristics);
                    cameraController$CameraFeatures0.view_angle_x = sizeF0.getWidth();
                    cameraController$CameraFeatures0.view_angle_y = sizeF0.getHeight();
                    return cameraController$CameraFeatures0;
                }

                Log.e("CameraController2", "no preview sizes returned by getOutputSizes");
                throw new CameraControllerException();
            }

            Log.e("CameraController2", "no video sizes returned by getOutputSizes");
            throw new CameraControllerException();
        }

        Log.e("CameraController2", "no picture sizes returned by getOutputSizes");
        throw new CameraControllerException();
    }






    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean shouldCoverPreview() {
        return !this.has_received_frame;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void resetCoverPreview() {
        this.has_received_frame = false;
    }

    private String convertSceneMode(int value2) {
        String value;
        switch (value2) {
            case CameraMetadata.CONTROL_SCENE_MODE_ACTION:
                value = "action";
                break;
            case CameraMetadata.CONTROL_SCENE_MODE_BARCODE:
                value = "barcode";
                break;
            case CameraMetadata.CONTROL_SCENE_MODE_BEACH:
                value = "beach";
                break;
            case CameraMetadata.CONTROL_SCENE_MODE_CANDLELIGHT:
                value = "candlelight";
                break;
            case CameraMetadata.CONTROL_SCENE_MODE_DISABLED:
                value = SCENE_MODE_DEFAULT;
                break;
            case CameraMetadata.CONTROL_SCENE_MODE_FIREWORKS:
                value = "fireworks";
                break;
            // "hdr" no longer available in Camera2
		/*case CameraMetadata.CONTROL_SCENE_MODE_HIGH_SPEED_VIDEO:
			// new for Camera2
			value = "high-speed-video";
			break;*/
            case CameraMetadata.CONTROL_SCENE_MODE_LANDSCAPE:
                value = "landscape";
                break;
            case CameraMetadata.CONTROL_SCENE_MODE_NIGHT:
                value = "night";
                break;
            case CameraMetadata.CONTROL_SCENE_MODE_NIGHT_PORTRAIT:
                value = "night-portrait";
                break;
            case CameraMetadata.CONTROL_SCENE_MODE_PARTY:
                value = "party";
                break;
            case CameraMetadata.CONTROL_SCENE_MODE_PORTRAIT:
                value = "portrait";
                break;
            case CameraMetadata.CONTROL_SCENE_MODE_SNOW:
                value = "snow";
                break;
            case CameraMetadata.CONTROL_SCENE_MODE_SPORTS:
                value = "sports";
                break;
            case CameraMetadata.CONTROL_SCENE_MODE_STEADYPHOTO:
                value = "steadyphoto";
                break;
            case CameraMetadata.CONTROL_SCENE_MODE_SUNSET:
                value = "sunset";
                break;
            case CameraMetadata.CONTROL_SCENE_MODE_THEATRE:
                value = "theatre";
                break;
            default:
                if (MyDebug.LOG)
                    Log.d(TAG, "unknown scene mode: " + value2);
                value = null;
                break;
        }
        return value;
    }


    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:79:0x012f, code lost:
        if (r0.equals("theatre") == false) goto L22;
     */
//    @Override
//    public SupportedValues setSceneMode(String value) {
//        if (MyDebug.LOG)
//            Log.d(TAG, "setSceneMode: " + value);
//        // we convert to/from strings to be compatible with original Android Camera API
//        int[] values2 = characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES);
//        boolean has_disabled = false;
//        List<String> values = new ArrayList<>();
//        if (values2 != null) {
//            // CONTROL_AVAILABLE_SCENE_MODES is supposed to always be available, but have had some (rare) crashes from Google Play due to being null
//            for (int value2 : values2) {
//                if (value2 == CameraMetadata.CONTROL_SCENE_MODE_DISABLED)
//                    has_disabled = true;
//                String this_value = convertSceneMode(value2);
//                if (this_value != null) {
//                    values.add(this_value);
//                }
//            }
//        }
//        if (!has_disabled) {
//            values.add(0, SCENE_MODE_DEFAULT);
//        }
//        SupportedValues supported_values = checkModeIsSupported(values, value, SCENE_MODE_DEFAULT);
//        if (supported_values != null) {
//            int selected_value2 = CameraMetadata.CONTROL_SCENE_MODE_DISABLED;
//            switch (supported_values.selected_value) {
//                case "action":
//                    selected_value2 = CameraMetadata.CONTROL_SCENE_MODE_ACTION;
//                    break;
//                case "barcode":
//                    selected_value2 = CameraMetadata.CONTROL_SCENE_MODE_BARCODE;
//                    break;
//                case "beach":
//                    selected_value2 = CameraMetadata.CONTROL_SCENE_MODE_BEACH;
//                    break;
//                case "candlelight":
//                    selected_value2 = CameraMetadata.CONTROL_SCENE_MODE_CANDLELIGHT;
//                    break;
//                case SCENE_MODE_DEFAULT:
//                    selected_value2 = CameraMetadata.CONTROL_SCENE_MODE_DISABLED;
//                    break;
//                case "fireworks":
//                    selected_value2 = CameraMetadata.CONTROL_SCENE_MODE_FIREWORKS;
//                    break;
//                // "hdr" no longer available in Camera2
//                case "landscape":
//                    selected_value2 = CameraMetadata.CONTROL_SCENE_MODE_LANDSCAPE;
//                    break;
//                case "night":
//                    selected_value2 = CameraMetadata.CONTROL_SCENE_MODE_NIGHT;
//                    break;
//                case "night-portrait":
//                    selected_value2 = CameraMetadata.CONTROL_SCENE_MODE_NIGHT_PORTRAIT;
//                    break;
//                case "party":
//                    selected_value2 = CameraMetadata.CONTROL_SCENE_MODE_PARTY;
//                    break;
//                case "portrait":
//                    selected_value2 = CameraMetadata.CONTROL_SCENE_MODE_PORTRAIT;
//                    break;
//                case "snow":
//                    selected_value2 = CameraMetadata.CONTROL_SCENE_MODE_SNOW;
//                    break;
//                case "sports":
//                    selected_value2 = CameraMetadata.CONTROL_SCENE_MODE_SPORTS;
//                    break;
//                case "steadyphoto":
//                    selected_value2 = CameraMetadata.CONTROL_SCENE_MODE_STEADYPHOTO;
//                    break;
//                case "sunset":
//                    selected_value2 = CameraMetadata.CONTROL_SCENE_MODE_SUNSET;
//                    break;
//                case "theatre":
//                    selected_value2 = CameraMetadata.CONTROL_SCENE_MODE_THEATRE;
//                    break;
//                default:
//                    if (MyDebug.LOG)
//                        Log.d(TAG, "unknown selected_value: " + supported_values.selected_value);
//                    break;
//            }
//
//            camera_settings.scene_mode = selected_value2;
//            if (camera_settings.setSceneMode(previewBuilder)) {
//                try {
//                    setRepeatingRequest();
//                } catch (CameraAccessException e) {
//                    if (MyDebug.LOG) {
//                        Log.e(TAG, "failed to set scene mode");
//                        Log.e(TAG, "reason: " + e.getReason());
//                        Log.e(TAG, "message: " + e.getMessage());
//                    }
//                    e.printStackTrace();
//                }
//            }
//        }
//        return supported_values;
//    }
    @Override  // com.gpsmapcamera.geotagginglocationonphoto.Camera.cameracontroller.CameraController
    public SupportedValues setSceneMode(String s) {
        int v4;
        CameraController2 cameraController20 = this;
        String s1 = s;
        Log.d("CameraController2", "setSceneMode: " + s1);
        int[] arr_v = (int[])cameraController20.characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES);
        ArrayList arrayList0 = new ArrayList();
        int v = 1;
        int v1 = 0;
        if(arr_v == null) {
            v4 = 0;
        }
        else {
            int v2 = arr_v.length;
            int v3 = 0;
            v4 = 0;
            while(v3 < v2) {
                int v5 = arr_v[v3];
                if(v5 == 0) {
                    v4 = 1;
                }

                String s2 = cameraController20.convertSceneMode(v5);
                if(s2 != null) {
                    arrayList0.add(s2);
                }

                ++v3;
            }
        }

        if(v4 == 0) {
            arrayList0.add(0, "auto");
        }

        SupportedValues cameraController$SupportedValues0 = cameraController20.checkModeIsSupported(arrayList0, s1, "auto");
        if(cameraController$SupportedValues0 != null) {
            String s3 = cameraController$SupportedValues0.selected_value;
            s3.hashCode();
            switch(s3.hashCode()) {
                case 0xAB2F7E36: {
                    v = s3.equals("action") ? 0 : -1;
                    break;
                }
                case 0xAF87F997: {
                    if(!s3.equals("theatre")) {
                        v = -1;
                    }

                    break;
                }
                case -895760513: {
                    v = s3.equals("sports") ? 2 : -1;
                    break;
                }
                case -891172202: {
                    v = s3.equals("sunset") ? 3 : -1;
                    break;
                }
                case 0xEC1DE880: {
                    v = s3.equals("barcode") ? 4 : -1;
                    break;
                }
                case -300277408: {
                    v = s3.equals("steadyphoto") ? 5 : -1;
                    break;
                }
                case 0xF040970C: {
                    v = s3.equals("fireworks") ? 6 : -1;
                    break;
                }
                case 3005871: {
                    v = s3.equals("auto") ? 7 : -1;
                    break;
                }
                case 0x35F183: {
                    v = s3.equals("snow") ? 8 : -1;
                    break;
                }
                case 93610339: {
                    v = s3.equals("beach") ? 9 : -1;
                    break;
                }
                case 0x63F6418: {
                    v = s3.equals("night") ? 10 : -1;
                    break;
                }
                case 106437350: {
                    v = s3.equals("party") ? 11 : -1;
                    break;
                }
                case 729267099: {
                    v = s3.equals("portrait") ? 12 : -1;
                    break;
                }
                case 0x5545F2BB: {
                    v = s3.equals("landscape") ? 13 : -1;
                    break;
                }
                case 0x6332F5B0: {
                    v = s3.equals("night-portrait") ? 14 : -1;
                    break;
                }
                case 1900012073: {
                    v = s3.equals("candlelight") ? 15 : -1;
                    break;
                }
                default: {
                    v = -1;
                }
            }

            switch(v) {
                case 0: {
                    v1 = 2;
                    break;
                }
                case 1: {
                    v1 = 7;
                    break;
                }
                case 2: {
                    v1 = 13;
                    break;
                }
                case 3: {
                    v1 = 10;
                    break;
                }
                case 4: {
                    v1 = 16;
                    break;
                }
                case 5: {
                    v1 = 11;
                    break;
                }
                case 6: {
                    v1 = 12;
                }
                case 7: {
                    break;
                }
                case 8: {
                    v1 = 9;
                    break;
                }
                case 9: {
                    v1 = 8;
                    break;
                }
                case 10: {
                    v1 = 5;
                    break;
                }
                case 11: {
                    v1 = 14;
                    break;
                }
                case 12: {
                    v1 = 3;
                    break;
                }
                case 13: {
                    v1 = 4;
                    break;
                }
                case 14: {
                    v1 = 6;
                    break;
                }
                case 15: {
                    v1 = 15;
                    break;
                }
                default: {
                    Log.d("CameraController2", "unknown selected_value: " + cameraController$SupportedValues0.selected_value);
                }
            }

            cameraController20.camera_settings.scene_mode = v1;
            if(cameraController20.camera_settings.setSceneMode(cameraController20.previewBuilder)) {
                try {
                    this.setRepeatingRequest();
                }
                catch(CameraAccessException cameraAccessException0) {
                    Log.e("CameraController2", "failed to set scene mode");
                    Log.e("CameraController2", "reason: " + cameraAccessException0.getReason());
                    Log.e("CameraController2", "message: " + cameraAccessException0.getMessage());
                    cameraAccessException0.printStackTrace();
                }

                return cameraController$SupportedValues0;
            }
        }

        return cameraController$SupportedValues0;
    }
    @Override
    public String getSceneMode() {
        if (this.previewBuilder.get(CaptureRequest.CONTROL_SCENE_MODE) == null) {
            return null;
        }
        return convertSceneMode(((Integer) this.previewBuilder.get(CaptureRequest.CONTROL_SCENE_MODE)).intValue());
    }

    private String convertColorEffect(int i) {
        switch (i) {
            case 0:
                return "none";
            case 1:
                return "mono";
            case 2:
                return "negative";
            case 3:
                return "solarize";
            case 4:
                return "sepia";
            case 5:
                return "posterize";
            case 6:
                return "whiteboard";
            case 7:
                return "blackboard";
            case 8:
                return "aqua";
            default:
                Log.d(TAG, "unknown effect mode: " + i);
                return null;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.SupportedValues setColorEffect(String str) {
        Log.d(TAG, "setColorEffect: " + str);
        int[] iArr = (int[]) this.characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_EFFECTS);
        if (iArr == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        int i = 0;
        for (int i2 : iArr) {
            String convertColorEffect = convertColorEffect(i2);
            if (convertColorEffect != null) {
                arrayList.add(convertColorEffect);
            }
        }
        CameraController.SupportedValues checkModeIsSupported = checkModeIsSupported(arrayList, str, "none");
        if (checkModeIsSupported != null) {
            String str2 = checkModeIsSupported.selected_value;
            str2.hashCode();
            char c = 65535;
            switch (str2.hashCode()) {
                case -1635350969:
                    if (str2.equals("blackboard")) {
                        c = 0;
                        break;
                    }
                    break;
                case 3002044:
                    if (str2.equals("aqua")) {
                        c = 1;
                        break;
                    }
                    break;
                case 3357411:
                    if (str2.equals("mono")) {
                        c = 2;
                        break;
                    }
                    break;
                case 3387192:
                    if (str2.equals("none")) {
                        c = 3;
                        break;
                    }
                    break;
                case 109324790:
                    if (str2.equals("sepia")) {
                        c = 4;
                        break;
                    }
                    break;
                case 261182557:
                    if (str2.equals("whiteboard")) {
                        c = 5;
                        break;
                    }
                    break;
                case 921111605:
                    if (str2.equals("negative")) {
                        c = 6;
                        break;
                    }
                    break;
                case 1473417203:
                    if (str2.equals("solarize")) {
                        c = 7;
                        break;
                    }
                    break;
                case 2008448231:
                    if (str2.equals("posterize")) {
                        c = '\b';
                        break;
                    }
                    break;
            }
            switch (c) {
                case 0:
                    i = 7;
                    break;
                case 1:
                    i = 8;
                    break;
                case 2:
                    i = 1;
                    break;
                case 3:
                    break;
                case 4:
                    i = 4;
                    break;
                case 5:
                    i = 6;
                    break;
                case 6:
                    i = 2;
                    break;
                case 7:
                    i = 3;
                    break;
                case '\b':
                    i = 5;
                    break;
                default:
                    Log.d(TAG, "unknown selected_value: " + checkModeIsSupported.selected_value);
                    break;
            }
            this.camera_settings.color_effect = i;
            if (this.camera_settings.setColorEffect(this.previewBuilder)) {
                try {
                    setRepeatingRequest();
                } catch (CameraAccessException e) {
                    Log.e(TAG, "failed to set color effect");
                    Log.e(TAG, "reason: " + e.getReason());
                    Log.e(TAG, "message: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }
        return checkModeIsSupported;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public String getColorEffect() {
        if (this.previewBuilder.get(CaptureRequest.CONTROL_EFFECT_MODE) == null) {
            return null;
        }
        return convertColorEffect(((Integer) this.previewBuilder.get(CaptureRequest.CONTROL_EFFECT_MODE)).intValue());
    }

    private String convertWhiteBalance(int i) {
        switch (i) {
            case 0:
                return "manual";
            case 1:
                return "auto";
            case 2:
                return "incandescent";
            case 3:
                return "fluorescent";
            case 4:
                return "warm-fluorescent";
            case 5:
                return "daylight";
            case 6:
                return "cloudy-daylight";
            case 7:
                return "twilight";
            case 8:
                return "shade";
            default:
                Log.d(TAG, "unknown white balance: " + i);
                return null;
        }
    }

    private boolean allowManualWB() {
        return !Build.MODEL.toLowerCase(Locale.US).contains("nexus 6");
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.SupportedValues setWhiteBalance(String str) {
        Log.d(TAG, "setWhiteBalance: " + str);
        int[] iArr = (int[]) this.characteristics.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES);
        if (iArr == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        int i = 0;
        for (int i2 : iArr) {
            String convertWhiteBalance = convertWhiteBalance(i2);
            if (convertWhiteBalance != null && (i2 != 0 || this.supports_white_balance_temperature)) {
                arrayList.add(convertWhiteBalance);
            }
        }
        boolean remove = arrayList.remove("auto");
        if (arrayList.remove("manual")) {
            arrayList.add(0, "manual");
        }
        if (remove) {
            arrayList.add(0, "auto");
        }
        CameraController.SupportedValues checkModeIsSupported = checkModeIsSupported(arrayList, str, "auto");
        if (checkModeIsSupported != null) {
            String str2 = checkModeIsSupported.selected_value;
            str2.hashCode();
            char c = 65535;
            switch (str2.hashCode()) {
                case -1081415738:
                    if (str2.equals("manual")) {
                        c = 0;
                        break;
                    }
                    break;
                case -939299377:
                    if (str2.equals("incandescent")) {
                        c = 1;
                        break;
                    }
                    break;
                case -719316704:
                    if (str2.equals("warm-fluorescent")) {
                        c = 2;
                        break;
                    }
                    break;
                case 3005871:
                    if (str2.equals("auto")) {
                        c = 3;
                        break;
                    }
                    break;
                case 109399597:
                    if (str2.equals("shade")) {
                        c = 4;
                        break;
                    }
                    break;
                case 474934723:
                    if (str2.equals("cloudy-daylight")) {
                        c = 5;
                        break;
                    }
                    break;
                case 1650323088:
                    if (str2.equals("twilight")) {
                        c = 6;
                        break;
                    }
                    break;
                case 1902580840:
                    if (str2.equals("fluorescent")) {
                        c = 7;
                        break;
                    }
                    break;
                case 1942983418:
                    if (str2.equals("daylight")) {
                        c = '\b';
                        break;
                    }
                    break;
            }
            switch (c) {
                case 0:
                    break;
                case 1:
                    i = 2;
                    break;
                case 2:
                    i = 4;
                    break;
                case 3:
                    i = 1;
                    break;
                case 4:
                    i = 8;
                    break;
                case 5:
                    i = 6;
                    break;
                case 6:
                    i = 7;
                    break;
                case 7:
                    i = 3;
                    break;
                case '\b':
                    i = 5;
                    break;
                default:
                    Log.d(TAG, "unknown selected_value: " + checkModeIsSupported.selected_value);
                    i = 1;
                    break;
            }
            this.camera_settings.white_balance = i;
            if (this.camera_settings.setWhiteBalance(this.previewBuilder)) {
                try {
                    setRepeatingRequest();
                } catch (CameraAccessException e) {
                    Log.e(TAG, "failed to set white balance");
                    Log.e(TAG, "reason: " + e.getReason());
                    Log.e(TAG, "message: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }
        return checkModeIsSupported;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public String getWhiteBalance() {
        if (this.previewBuilder.get(CaptureRequest.CONTROL_AWB_MODE) == null) {
            return null;
        }
        return convertWhiteBalance(((Integer) this.previewBuilder.get(CaptureRequest.CONTROL_AWB_MODE)).intValue());
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean setWhiteBalanceTemperature(int i) {
        Log.d(TAG, "setWhiteBalanceTemperature: " + i);
        if (this.camera_settings.white_balance == i) {
            Log.d(TAG, "already set");
            return false;
        }
        try {
            this.camera_settings.white_balance_temperature = Math.min(Math.max(i, 1000), (int) max_white_balance_temperature_c);
            if (this.camera_settings.setWhiteBalance(this.previewBuilder)) {
                setRepeatingRequest();
                return true;
            }
            return true;
        } catch (CameraAccessException e) {
            Log.e(TAG, "failed to set white balance temperature");
            Log.e(TAG, "reason: " + e.getReason());
            Log.e(TAG, "message: " + e.getMessage());
            e.printStackTrace();
            return true;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getWhiteBalanceTemperature() {
        return this.camera_settings.white_balance_temperature;
    }

    private String convertAntiBanding(int i) {
        if (i != 0) {
            if (i != 1) {
                if (i != 2) {
                    if (i != 3) {
                        Log.d(TAG, "unknown antibanding: " + i);
                        return null;
                    }
                    return "auto";
                }
                return "60hz";
            }
            return "50hz";
        }
        return DebugKt.DEBUG_PROPERTY_VALUE_OFF;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.SupportedValues setAntiBanding(String str) {
        Log.d(TAG, "setAntiBanding: " + str);
        int[] iArr = (int[]) this.characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_ANTIBANDING_MODES);
        if (iArr == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        int i = 0;
        for (int i2 : iArr) {
            String convertAntiBanding = convertAntiBanding(i2);
            if (convertAntiBanding != null) {
                arrayList.add(convertAntiBanding);
            }
        }
        CameraController.SupportedValues checkModeIsSupported = checkModeIsSupported(arrayList, str, "auto");
        if (checkModeIsSupported != null && checkModeIsSupported.selected_value.equals(str)) {
            String str2 = checkModeIsSupported.selected_value;
            str2.hashCode();
            char c = 65535;
            switch (str2.hashCode()) {
                case 109935:
                    if (str2.equals(DebugKt.DEBUG_PROPERTY_VALUE_OFF)) {
                        c = 0;
                        break;
                    }
                    break;
                case 1628397:
                    if (str2.equals("50hz")) {
                        c = 1;
                        break;
                    }
                    break;
                case 1658188:
                    if (str2.equals("60hz")) {
                        c = 2;
                        break;
                    }
                    break;
                case 3005871:
                    if (str2.equals("auto")) {
                        c = 3;
                        break;
                    }
                    break;
            }
            switch (c) {
                case 0:
                    break;
                case 1:
                    i = 1;
                    break;
                case 2:
                    i = 2;
                    break;
                default:
                    Log.d(TAG, "unknown selected_value: " + checkModeIsSupported.selected_value);
                case 3:
                    i = 3;
                    break;
            }
            this.camera_settings.has_antibanding = true;
            this.camera_settings.antibanding = i;
            if (this.camera_settings.setAntiBanding(this.previewBuilder)) {
                try {
                    setRepeatingRequest();
                } catch (CameraAccessException e) {
                    Log.e(TAG, "failed to set antibanding");
                    Log.e(TAG, "reason: " + e.getReason());
                    Log.e(TAG, "message: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }
        return checkModeIsSupported;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public String getAntiBanding() {
        if (this.previewBuilder.get(CaptureRequest.CONTROL_AE_ANTIBANDING_MODE) == null) {
            return null;
        }
        return convertAntiBanding(((Integer) this.previewBuilder.get(CaptureRequest.CONTROL_AE_ANTIBANDING_MODE)).intValue());
    }

    private String convertEdgeMode(int i) {
        if (i != 0) {
            if (i != 1) {
                if (i != 2) {
                    if (i != 3) {
                        Log.d(TAG, "unknown edge_mode: " + i);
                        return null;
                    }
                    return null;
                }
                return "high_quality";
            }
            return "fast";
        }
        return DebugKt.DEBUG_PROPERTY_VALUE_OFF;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.SupportedValues setEdgeMode(String str) {
        Log.d(TAG, "setEdgeMode: " + str);
        int[] iArr = (int[]) this.characteristics.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES);
        if (iArr == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        arrayList.add("default");
        boolean z = false;
        for (int i : iArr) {
            String convertEdgeMode = convertEdgeMode(i);
            if (convertEdgeMode != null) {
                arrayList.add(convertEdgeMode);
            }
        }
        CameraController.SupportedValues checkModeIsSupported = checkModeIsSupported(arrayList, str, "default");
        if (checkModeIsSupported != null && checkModeIsSupported.selected_value.equals(str)) {
            int i2 = 1;
            if (!str.equals("default")) {
                String str2 = checkModeIsSupported.selected_value;
                str2.hashCode();
                char c = 65535;
                switch (str2.hashCode()) {
                    case 109935:
                        if (str2.equals(DebugKt.DEBUG_PROPERTY_VALUE_OFF)) {
                            c = 0;
                            break;
                        }
                        break;
                    case 3135580:
                        if (str2.equals("fast")) {
                            c = 1;
                            break;
                        }
                        break;
                    case 1790083938:
                        if (str2.equals("high_quality")) {
                            c = 2;
                            break;
                        }
                        break;
                }
                switch (c) {
                    case 0:
                        i2 = 0;
                        z = true;
                        break;
                    case 1:
                        z = true;
                        break;
                    case 2:
                        i2 = 2;
                        z = true;
                        break;
                    default:
                        Log.d(TAG, "unknown selected_value: " + checkModeIsSupported.selected_value);
                        break;
                }
            }
            if (this.camera_settings.has_edge_mode != z || this.camera_settings.edge_mode != i2) {
                this.camera_settings.has_edge_mode = z;
                this.camera_settings.edge_mode = i2;
                if (this.camera_settings.setEdgeMode(this.previewBuilder)) {
                    try {
                        setRepeatingRequest();
                    } catch (CameraAccessException e) {
                        Log.e(TAG, "failed to set edge_mode");
                        Log.e(TAG, "reason: " + e.getReason());
                        Log.e(TAG, "message: " + e.getMessage());
                        e.printStackTrace();
                    }
                }
            }
        }
        return checkModeIsSupported;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public String getEdgeMode() {
        if (this.previewBuilder.get(CaptureRequest.EDGE_MODE) == null) {
            return null;
        }
        return convertEdgeMode(((Integer) this.previewBuilder.get(CaptureRequest.EDGE_MODE)).intValue());
    }

    private String convertNoiseReductionMode(int i) {
        if (i != 0) {
            if (i != 1) {
                if (i != 2) {
                    if (i != 3) {
                        if (i != 4) {
                            Log.d(TAG, "unknown noise_reduction_mode: " + i);
                            return null;
                        }
                        return null;
                    }
                    return "minimal";
                }
                return "high_quality";
            }
            return "fast";
        }
        return DebugKt.DEBUG_PROPERTY_VALUE_OFF;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.SupportedValues setNoiseReductionMode(String str) {
        Log.d(TAG, "setNoiseReductionMode: " + str);
        int[] iArr = (int[]) this.characteristics.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES);
        if (iArr == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        arrayList.add("default");
        boolean z = false;
        for (int i : iArr) {
            String convertNoiseReductionMode = convertNoiseReductionMode(i);
            if (convertNoiseReductionMode != null) {
                arrayList.add(convertNoiseReductionMode);
            }
        }
        CameraController.SupportedValues checkModeIsSupported = checkModeIsSupported(arrayList, str, "default");
        if (checkModeIsSupported != null && checkModeIsSupported.selected_value.equals(str)) {
            int i2 = 1;
            if (!str.equals("default")) {
                String str2 = checkModeIsSupported.selected_value;
                str2.hashCode();
                char c = 65535;
                switch (str2.hashCode()) {
                    case 109935:
                        if (str2.equals(DebugKt.DEBUG_PROPERTY_VALUE_OFF)) {
                            c = 0;
                            break;
                        }
                        break;
                    case 3135580:
                        if (str2.equals("fast")) {
                            c = 1;
                            break;
                        }
                        break;
                    case 1064537505:
                        if (str2.equals("minimal")) {
                            c = 2;
                            break;
                        }
                        break;
                    case 1790083938:
                        if (str2.equals("high_quality")) {
                            c = 3;
                            break;
                        }
                        break;
                }
                switch (c) {
                    case 0:
                        i2 = 0;
                        z = true;
                        break;
                    case 1:
                        z = true;
                        break;
                    case 2:
                        if (Build.VERSION.SDK_INT>=23) {
                            i2 = 3;
                        } else {
                            Log.e(TAG, "grsdnahmfghlCc.oStMr");
                        }
                        z = true;
                        break;
                    case 3:
                        i2 = 2;
                        z = true;
                        break;
                    default:
                        Log.d(TAG, "unknown selected_value: " + checkModeIsSupported.selected_value);
                        break;
                }
            }
            if (this.camera_settings.has_noise_reduction_mode != z || this.camera_settings.noise_reduction_mode != i2) {
                this.camera_settings.has_noise_reduction_mode = z;
                this.camera_settings.noise_reduction_mode = i2;
                if (this.camera_settings.setNoiseReductionMode(this.previewBuilder)) {
                    try {
                        setRepeatingRequest();
                    } catch (CameraAccessException e) {
                        Log.e(TAG, "failed to set noise_reduction_mode");
                        Log.e(TAG, "reason: " + e.getReason());
                        Log.e(TAG, "message: " + e.getMessage());
                        e.printStackTrace();
                    }
                }
            }
        }
        return checkModeIsSupported;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public String getNoiseReductionMode() {
        if (this.previewBuilder.get(CaptureRequest.NOISE_REDUCTION_MODE) == null) {
            return null;
        }
        return convertNoiseReductionMode(((Integer) this.previewBuilder.get(CaptureRequest.NOISE_REDUCTION_MODE)).intValue());
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.SupportedValues setISO(String str) {
        setManualISO(false, 0);
        return null;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setManualISO(boolean z, int i) {
        Log.d(TAG, "setManualISO: " + z);
        try {
            if (z) {
                Log.d(TAG, "switch to iso: " + i);
                Range range = (Range) this.characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
                if (range == null) {
                    Log.d(TAG, "iso not supported");
                    return;
                }
                Log.d(TAG, "iso range from " + range.getLower() + " to " + range.getUpper());
                this.camera_settings.has_iso = true;
                this.camera_settings.iso = Math.min(Math.max(i, ((Integer) range.getLower()).intValue()), ((Integer) range.getUpper()).intValue());
            } else {
                this.camera_settings.has_iso = false;
                this.camera_settings.iso = 0;
            }
            updateUseFakePrecaptureMode(this.camera_settings.flash_value);
            if (this.camera_settings.setAEMode(this.previewBuilder, false)) {
                setRepeatingRequest();
            }
        } catch (CameraAccessException e) {
            Log.e(TAG, "failed to set ISO");
            Log.e(TAG, "reason: " + e.getReason());
            Log.e(TAG, "message: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean isManualISO() {
        return this.camera_settings.has_iso;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean setISO(int i) {
        Log.d(TAG, "setISO: " + i);
        if (this.camera_settings.iso == i) {
            Log.d(TAG, "already set");
            return false;
        }
        try {
            this.camera_settings.iso = i;
            if (this.camera_settings.setAEMode(this.previewBuilder, false)) {
                setRepeatingRequest();
                return true;
            }
            return true;
        } catch (CameraAccessException e) {
            Log.e(TAG, "failed to set ISO");
            Log.e(TAG, "reason: " + e.getReason());
            Log.e(TAG, "message: " + e.getMessage());
            e.printStackTrace();
            return true;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getISO() {
        return this.camera_settings.iso;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public long getExposureTime() {
        return this.camera_settings.exposure_time;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean setExposureTime(long j) {
        Log.d(TAG, "setExposureTime: " + j);
        Log.d(TAG, "current exposure time: " + this.camera_settings.exposure_time);
        if (this.camera_settings.exposure_time == j) {
            Log.d(TAG, "already set");
            return false;
        }
        try {
            this.camera_settings.exposure_time = j;
            if (this.camera_settings.setAEMode(this.previewBuilder, false)) {
                setRepeatingRequest();
                return true;
            }
            return true;
        } catch (CameraAccessException e) {
            Log.e(TAG, "failed to set exposure time");
            Log.e(TAG, "reason: " + e.getReason());
            Log.e(TAG, "message: " + e.getMessage());
            e.printStackTrace();
            return true;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setAperture(float f) {
        Log.d(TAG, "setAperture: " + f);
        Log.d(TAG, "current aperture: " + this.camera_settings.aperture);
        if (this.camera_settings.has_aperture && this.camera_settings.aperture == f) {
            Log.d(TAG, "already set");
        }
        try {
            this.camera_settings.has_aperture = true;
            this.camera_settings.aperture = f;
            if (this.camera_settings.setAperture(this.previewBuilder)) {
                setRepeatingRequest();
            }
        } catch (CameraAccessException e) {
            Log.e(TAG, "failed to set aperture");
            Log.e(TAG, "reason: " + e.getReason());
            Log.e(TAG, "message: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.Size getPictureSize() {
        return new CameraController.Size(this.picture_width, this.picture_height);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setPictureSize(int i, int i2) {
        Log.d(TAG, "setPictureSize: " + i + " x " + i2);
        if (this.camera == null) {
            Log.e(TAG, "no camera");
        } else if (hasCaptureSession()) {
            Log.e(TAG, "can't set picture size when captureSession running!");
            throw new RuntimeException();
        } else {
            this.picture_width = i;
            this.picture_height = i2;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setRaw(boolean z, int i) {
        Log.d(TAG, "setRaw: " + z);
        Log.d(TAG, "max_raw_images: " + i);
        if (this.camera == null) {
            Log.e(TAG, "no camera");
        } else if (this.want_raw == z && this.max_raw_images == i) {
        } else {
            if (z && this.raw_size == null) {
                Log.e(TAG, "can't set raw when raw not supported");
            } else if (hasCaptureSession()) {
                Log.e(TAG, "can't set raw when captureSession running!");
                throw new RuntimeException();
            } else {
                this.want_raw = z;
                this.max_raw_images = i;
            }
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setVideoHighSpeed(boolean z) {
        Log.d(TAG, "setVideoHighSpeed: " + z);
        if (this.camera == null) {
            Log.e(TAG, "no camera");
        } else if (this.want_video_high_speed == z) {
        } else {
            if (hasCaptureSession()) {
                Log.e(TAG, "can't set high speed when captureSession running!");
                throw new RuntimeException();
            }
            this.want_video_high_speed = z;
            this.is_video_high_speed = false;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setCameraExtension(boolean z, int i) {
        Log.d(TAG, "setCameraExtension?: " + z);
        Log.d(TAG, "extension: " + i);
        if (this.camera == null) {
            Log.e(TAG, "no camera");
            return;
        }
        if (this.sessionType == (z ? SessionType.SESSIONTYPE_EXTENSION : SessionType.SESSIONTYPE_NORMAL)) {
            if (this.camera_extension == (z ? i : 0)) {
                Log.d(TAG, "    no change");
                return;
            }
        }
        if (hasCaptureSession()) {
            Log.e(TAG, "can't set extension when captureSession running!");
            throw new RuntimeException();
        }
        if (z != (this.sessionType == SessionType.SESSIONTYPE_EXTENSION)) {
            Log.d(TAG, "turning extension session on or off");
            this.previewBuilder = null;
            createPreviewRequest();
        }
        if (z) {
            this.sessionType = SessionType.SESSIONTYPE_EXTENSION;
            this.camera_extension = i;
            return;
        }
        this.sessionType = SessionType.SESSIONTYPE_NORMAL;
        this.camera_extension = 0;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean isCameraExtension() {
        return this.sessionType == SessionType.SESSIONTYPE_EXTENSION;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getCameraExtension() {
        if (isCameraExtension()) {
            return this.camera_extension;
        }
        return -1;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setBurstType(CameraController.BurstType burstType) {
        Log.d(TAG, "setBurstType: " + burstType);
        if (this.camera == null) {
            Log.e(TAG, TccIv.zAzGiEz);
        } else if (this.burst_type == burstType) {
        } else {
            this.burst_type = burstType;
            updateUseFakePrecaptureMode(this.camera_settings.flash_value);
            this.camera_settings.setAEMode(this.previewBuilder, false);
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.BurstType getBurstType() {
        return this.burst_type;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setExpoBracketingNImages(int i) {
        Log.d(TAG, "setExpoBracketingNImages: " + i);
        if (i<=1 || i % 2 == 0) {
            Log.e(TAG, "n_images should be an odd number greater than 1");
            throw new RuntimeException("n_images should be an odd number greater than 1");
        }
        if (i>5) {
            Log.e(TAG, "limiting n_images to max of 5");
            i = 5;
        }
        this.expo_bracketing_n_images = i;
    }

    @Override
    public void setExpoBracketingStops(double stops) {
        if( MyDebug.LOG )
            Log.d(TAG, "setExpoBracketingStops: " + stops);
        if( stops <= 0.0 ) {
            if( MyDebug.LOG )
                Log.e(TAG, "stops should be positive");
            throw new RuntimeException(); // throw as RuntimeException, as this is a programming error
        }
        this.expo_bracketing_stops = stops;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setDummyCaptureHack(boolean z) {
        Log.d(TAG, "setDummyCaptureHack: " + z);
        this.dummy_capture_hack = z;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setUseExpoFastBurst(boolean z) {
        Log.d(TAG, "setUseExpoFastBurst: " + z);
        this.use_expo_fast_burst = z;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean isBurstOrExpo() {
        return this.burst_type != CameraController.BurstType.BURSTTYPE_NONE;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean isCapturingBurst() {
        if (isBurstOrExpo()) {
            return this.burst_type == CameraController.BurstType.BURSTTYPE_CONTINUOUS ? this.continuous_burst_in_progress || this.n_burst>0 || this.n_burst_raw>0 : getBurstTotal()>1 && getNBurstTaken()<getBurstTotal();
        }
        return false;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getNBurstTaken() {
        return this.n_burst_taken;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getBurstTotal() {
        if (this.burst_type == CameraController.BurstType.BURSTTYPE_CONTINUOUS) {
            return 0;
        }
        return this.n_burst_total;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setBurstNImages(int i) {
        Log.d(TAG, "setBurstNImages: " + i);
        this.burst_requested_n_images = i;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setBurstForNoiseReduction(boolean z, boolean z2) {
        Log.d(TAG, "setBurstForNoiseReduction: " + z);
        Log.d(TAG, "noise_reduction_low_light: " + z2);
        this.burst_for_noise_reduction = z;
        this.noise_reduction_low_light = z2;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean isContinuousBurstInProgress() {
        return this.continuous_burst_in_progress;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void stopContinuousBurst() {
        Log.d(TAG, "stopContinuousBurst");
        this.continuous_burst_in_progress = false;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void stopFocusBracketingBurst() {
        Log.d(TAG, "stopFocusBracketingBurst");
        if (this.burst_type == CameraController.BurstType.BURSTTYPE_FOCUS) {
            this.focus_bracketing_in_progress = false;
            return;
        }
        Log.e(TAG, "stopFocusBracketingBurst burst_type is: " + this.burst_type);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setUseCamera2FakeFlash(boolean z) {
        Log.d(TAG, "setUseCamera2FakeFlash: " + z);
        if (this.camera == null) {
            Log.e(TAG, "no camera");
        } else if (this.use_fake_precapture == z) {
        } else {
            this.use_fake_precapture = z;
            this.use_fake_precapture_mode = z;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean getUseCamera2FakeFlash() {
        return this.use_fake_precapture;
    }

    private void createPictureImageReader() {
        if( MyDebug.LOG )
            Log.d(TAG, "createPictureImageReader");
        if( captureSession != null ) {
            // can only call this when captureSession not created - as the surface of the imageReader we create has to match the surface we pass to the captureSession
            if( MyDebug.LOG )
                Log.e(TAG, "can't create picture image reader when captureSession running!");
            throw new RuntimeException(); // throw as RuntimeException, as this is a programming error
        }
        closePictureImageReader();
        if( picture_width == 0 || picture_height == 0 ) {
            if( MyDebug.LOG )
                Log.e(TAG, "application needs to call setPictureSize()");
            throw new RuntimeException(); // throw as RuntimeException, as this is a programming error
        }
        // maxImages only needs to be 2, as we always read the JPEG data and close the image straight away in the imageReader
        imageReader = ImageReader.newInstance(picture_width, picture_height, ImageFormat.JPEG, 2);
        //imageReader = ImageReader.newInstance(picture_width, picture_height, ImageFormat.YUV_420_888, 2);
        if( MyDebug.LOG ) {
            Log.d(TAG, "created new imageReader: " + imageReader.toString());
            Log.d(TAG, "imageReader surface: " + imageReader.getSurface().toString());
        }
        imageReader.setOnImageAvailableListener(new OnImageAvailableListener(), null);
        if( want_raw && raw_size != null&& !previewIsVideoMode  ) {
            // unlike the JPEG imageReader, we can't read the data and close the image straight away, so we need to allow a larger
            // value for maxImages
            imageReaderRaw = ImageReader.newInstance(raw_size.getWidth(), raw_size.getHeight(), ImageFormat.RAW_SENSOR, max_raw_images);
            if( MyDebug.LOG ) {
                Log.d(TAG, "created new imageReaderRaw: " + imageReaderRaw.toString());
                Log.d(TAG, "imageReaderRaw surface: " + imageReaderRaw.getSurface().toString());
            }
            imageReaderRaw.setOnImageAvailableListener(onRawImageAvailableListener = new OnRawImageAvailableListener(), null);
        }
    }

    private void clearPending() {
        Log.d(TAG, "clearPending");
        this.pending_burst_images.clear();
        this.pending_burst_images_raw.clear();
        this.pending_raw_image = null;
        OnImageAvailableListener onImageAvailableListener = this.onImageAvailableListener;
        if (onImageAvailableListener != null) {
            onImageAvailableListener.skip_next_image = false;
        }
        OnRawImageAvailableListener onRawImageAvailableListener = this.onRawImageAvailableListener;
        if (onRawImageAvailableListener != null) {
            onRawImageAvailableListener.clear();
            this.onRawImageAvailableListener.skip_next_image = false;
        }
        this.slow_burst_capture_requests = null;
        this.n_burst = 0;
        this.n_burst_taken = 0;
        this.n_burst_total = 0;
        this.n_burst_raw = 0;
        this.burst_single_request = false;
        this.slow_burst_start_ms = 0L;
    }

    private void takePendingRaw() {
        Log.d(TAG, "takePendingRaw");
        if (this.pending_raw_image != null) {
            synchronized (this.background_camera_lock) {
                this.raw_todo = false;
            }
            this.picture_cb.onRawPictureTaken(this.pending_raw_image);
            this.pending_raw_image = null;
            OnRawImageAvailableListener onRawImageAvailableListener = this.onRawImageAvailableListener;
            if (onRawImageAvailableListener != null) {
                onRawImageAvailableListener.clear();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void checkImagesCompleted() {
        boolean z;
        boolean z2;
        Log.d(TAG, "checkImagesCompleted");
        synchronized (this.background_camera_lock) {
            z = true;
            if (!this.done_all_captures) {
                Log.d(TAG, "still waiting for captures");
            } else if (this.picture_cb == null) {
                Log.d(TAG, "no picture_cb");
            } else {
                boolean z3 = this.jpeg_todo;
                if (!z3 && !this.raw_todo) {
                    Log.d(TAG, "all image callbacks now completed");
                    z2 = true;
                    z = false;
                } else if (!z3 && this.pending_raw_image != null) {
                    Log.d(TAG, "jpeg callback already done, can now call pending raw callback");
                    z2 = true;
                } else {
                    Log.d(TAG, "need to wait for jpeg and/or raw callback");
                }
            }
            z2 = false;
            z = false;
        }
        if (z) {
            takePendingRaw();
            Log.d(TAG, "all image callbacks now completed");
        }
        if (z2) {
            CameraController.PictureCallback pictureCallback = this.picture_cb;
            this.picture_cb = null;
            pictureCallback.onCompleted();
            synchronized (this.background_camera_lock) {
                if (this.burst_type == CameraController.BurstType.BURSTTYPE_FOCUS) {
                    this.focus_bracketing_in_progress = false;
                }
            }
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.Size getPreviewSize() {
        return new CameraController.Size(this.preview_width, this.preview_height);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setPreviewSize(int i, int i2) {
        Log.d(TAG, "setPreviewSize: " + i + " , " + i2);
        this.preview_width = i;
        this.preview_height = i2;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setVideoStabilization(boolean z) {
        Log.d(TAG, "setVideoStabilization: " + z);
        this.camera_settings.video_stabilization = z;
        this.camera_settings.setStabilization(this.previewBuilder);
        try {
            setRepeatingRequest();
        } catch (CameraAccessException e) {
            Log.e(TAG, "failed to set video stabilization");
            Log.e(TAG, "reason: " + e.getReason());
            Log.e(TAG, "message: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean getOpticalStabilization() {
        Integer num = (Integer) this.previewBuilder.get(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE);
        return num != null && num.intValue() == 1;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean getVideoStabilization() {
        return this.camera_settings.video_stabilization;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setTonemapProfile(CameraController.TonemapProfile tonemapProfile, float f, float f2) {
        Log.d(TAG, "setTonemapProfile: " + tonemapProfile);
        Log.d(TAG, "log_profile_strength: " + f);
        Log.d(TAG, "gamma: " + f2);
        if (this.camera_settings.tonemap_profile == tonemapProfile && this.camera_settings.log_profile_strength == f && this.camera_settings.gamma_profile == f2) {
            return;
        }
        this.camera_settings.tonemap_profile = tonemapProfile;
        if (tonemapProfile == CameraController.TonemapProfile.TONEMAPPROFILE_LOG) {
            this.camera_settings.log_profile_strength = f;
        } else {
            this.camera_settings.log_profile_strength = 0.0f;
        }
        if (tonemapProfile == CameraController.TonemapProfile.TONEMAPPROFILE_GAMMA) {
            this.camera_settings.gamma_profile = f2;
        } else {
            this.camera_settings.gamma_profile = 0.0f;
        }
        this.camera_settings.setTonemapProfile(this.previewBuilder);
        try {
            setRepeatingRequest();
        } catch (CameraAccessException e) {
            Log.e(TAG, "failed to set log profile");
            Log.e(TAG, "reason: " + e.getReason());
            Log.e(TAG, "message: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.TonemapProfile getTonemapProfile() {
        return this.camera_settings.tonemap_profile;
    }

    public CaptureRequest.Builder testGetPreviewBuilder() {
        return this.previewBuilder;
    }

    public TonemapCurve testGetTonemapCurve() {
        return (TonemapCurve) this.previewBuilder.get(CaptureRequest.TONEMAP_CURVE);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getJpegQuality() {
        return this.camera_settings.jpeg_quality;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setJpegQuality(int i) {
        if (i<0 || i>100) {
            Log.e(TAG, "invalid jpeg quality" + i);
            throw new RuntimeException();
        }
        this.camera_settings.jpeg_quality = (byte) i;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getZoom() {
        return this.current_zoom_value;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setZoom(int i) {
        List<Integer> list = this.zoom_ratios;
        if (list == null) {
            Log.d(TAG, "zoom not supported");
        } else if (i<0 || i>list.size()) {
            Log.e(TAG, "invalid zoom value" + i);
            throw new RuntimeException();
        } else {
            float intValue = this.zoom_ratios.get(i).intValue() / 100.0f;
            if (Build.VERSION.SDK_INT>=30) {
                this.camera_settings.has_control_zoom_ratio = true;
                this.camera_settings.control_zoom_ratio = intValue;
                this.camera_settings.setControlZoomRatio(this.previewBuilder);
            } else {
                Rect rect = (Rect) this.characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
                int width = rect.width() / 2;
                int height = rect.height() / 2;
                double d = intValue * 2.0d;
                int width2 = (int) (rect.width() / d);
                int height2 = (int) (rect.height() / d);
                int i2 = width - width2;
                int i3 = width + width2;
                int i4 = height - height2;
                int i5 = height + height2;
                Log.d(TAG, "zoom: " + intValue);
                Log.d(TAG, "hwidth: " + width2);
                Log.d(TAG, "hheight: " + height2);
                Log.d(TAG, "sensor_rect left: " + rect.left);
                Log.d(TAG, "sensor_rect top: " + rect.top);
                Log.d(TAG, "sensor_rect right: " + rect.right);
                Log.d(TAG, "sensor_rect bottom: " + rect.bottom);
                Log.d(TAG, "left: " + i2);
                Log.d(TAG, "top: " + i4);
                Log.d(TAG, "right: " + i3);
                Log.d(TAG, "bottom: " + i5);
                this.camera_settings.scalar_crop_region = new Rect(i2, i4, i3, i5);
                this.camera_settings.setCropRegion(this.previewBuilder);
            }
            this.current_zoom_value = i;
            try {
                setRepeatingRequest();
            } catch (CameraAccessException e) {
                Log.e(TAG, "failed to set zoom");
                Log.e(TAG, "reason: " + e.getReason());
                Log.e(TAG, "message: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void resetZoom() {
        setZoom(this.zoom_value_1x);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getExposureCompensation() {
        if (this.previewBuilder.get(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION) == null) {
            return 0;
        }
        return ((Integer) this.previewBuilder.get(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION)).intValue();
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean setExposureCompensation(int i) {
        this.camera_settings.has_ae_exposure_compensation = true;
        this.camera_settings.ae_exposure_compensation = i;
        if (this.camera_settings.setExposureCompensation(this.previewBuilder)) {
            try {
                setRepeatingRequest();
            } catch (CameraAccessException e) {
                Log.e(TAG, "failed to set exposure compensation");
                Log.e(TAG, "reason: " + e.getReason());
                Log.e(TAG, "message: " + e.getMessage());
                e.printStackTrace();
            }
            return true;
        }
        return false;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setPreviewFpsRange(int i, int i2) {
        Log.d(TAG, "setPreviewFpsRange: " + i + "-" + i2);
        this.camera_settings.ae_target_fps_range = new Range(Integer.valueOf(i / 1000), Integer.valueOf(i2 / 1000));
        this.camera_settings.sensor_frame_duration = (long) ((1.0d / (((double) i) / 1000.0d)) * 1.0E9d);
        try {
            if (this.camera_settings.setAEMode(this.previewBuilder, false)) {
                setRepeatingRequest();
            }
        } catch (CameraAccessException e) {
            Log.e(TAG, "failed to set preview fps range to " + i + "-" + i2);
            StringBuilder sb = new StringBuilder();
            sb.append("reason: ");
            sb.append(e.getReason());
            Log.e(TAG, sb.toString());
            Log.e(TAG, "message: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void clearPreviewFpsRange() {
        if( MyDebug.LOG )
            Log.d(TAG, "clearPreviewFpsRange");
        // needed e.g. on Nokia 8 when switching back from slow motion to regular speed, in order to reset to the regular
        // frame rate
        if( camera_settings.ae_target_fps_range != null || camera_settings.sensor_frame_duration != 0 ) {
            // set back to default
            camera_settings.ae_target_fps_range = null;
            camera_settings.sensor_frame_duration = 0;
            createPreviewRequest();
            // createPreviewRequest() needed so that the values in the previewBuilder reset to default values, for
            // CONTROL_AE_TARGET_FPS_RANGE and SENSOR_FRAME_DURATION

            try {
                if( camera_settings.setAEMode(previewBuilder, false) ) {
                    setRepeatingRequest();
                }
            }
            catch(CameraAccessException e) {
                if( MyDebug.LOG ) {
                    Log.e(TAG, "failed to clear preview fps range");
                    Log.e(TAG, "reason: " + e.getReason());
                    Log.e(TAG, "message: " + e.getMessage());
                }
                e.printStackTrace();
            }
        }
    }

    @Override
    public List<int[]> getSupportedPreviewFpsRange() {
        List<int[]> l = new ArrayList<>();

        List<int[]> rr = want_video_high_speed ? hs_fps_ranges : ae_fps_ranges;
        for (int[] r : rr) {
            int[] ir = { r[0] * 1000, r[1] * 1000 };
            l.add( ir );
        }
        if( MyDebug.LOG )
            Log.d(TAG, "   using " + (want_video_high_speed ? "high speed" : "ae")  + " preview fps ranges");

        return l;
    }

    @Override
    public void setFocusValue(String focus_value) {
        if (MyDebug.LOG)
            Log.d(TAG, "setFocusValue: " + focus_value);
        int focus_mode;
        switch (focus_value) {
            case "focus_mode_auto":
            case "focus_mode_locked":
                focus_mode = CaptureRequest.CONTROL_AF_MODE_AUTO;
                break;
            case "focus_mode_infinity":
                focus_mode = CaptureRequest.CONTROL_AF_MODE_OFF;
                camera_settings.focus_distance = 0.0f;
                break;
            case "focus_mode_manual2":
                focus_mode = CaptureRequest.CONTROL_AF_MODE_OFF;
                camera_settings.focus_distance = camera_settings.focus_distance_manual;
                break;
            case "focus_mode_macro":
                focus_mode = CaptureRequest.CONTROL_AF_MODE_MACRO;
                break;
            case "focus_mode_edof":
                focus_mode = CaptureRequest.CONTROL_AF_MODE_EDOF;
                break;
            case "focus_mode_continuous_picture":
                focus_mode = CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE;
                break;
            case "focus_mode_continuous_video":
                focus_mode = CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO;
                break;
            default:
                if (MyDebug.LOG)
                    Log.d(TAG, "setFocusValue() received unknown focus value " + focus_value);
                return;
        }
        camera_settings.has_af_mode = true;
        camera_settings.af_mode = focus_mode;
        camera_settings.setFocusMode(previewBuilder);
        camera_settings.setFocusDistance(previewBuilder); // also need to set distance, in case changed between infinity, manual or other modes
        try {
            setRepeatingRequest();
        } catch (CameraAccessException e) {
            if (MyDebug.LOG) {
                Log.e(TAG, "failed to set focus mode");
                Log.e(TAG, "reason: " + e.getReason());
                Log.e(TAG, "message: " + e.getMessage());
            }
            e.printStackTrace();
        }
    }

    private String convertFocusModeToValue(int i) {
        Log.d(TAG, "convertFocusModeToValue: " + i);
        return i != 0 ? i != 1 ? i != 2 ? i != 3 ? i != 4 ? i != 5 ? "" : "focus_mode_edof" : "focus_mode_continuous_picture" : "focus_mode_continuous_video" : "focus_mode_macro" : "focus_mode_auto" : "focus_mode_manual2";
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public String getFocusValue() {
        Integer num = (Integer) this.previewBuilder.get(CaptureRequest.CONTROL_AF_MODE);
        if (num == null) {
            num = 1;
        }
        return convertFocusModeToValue(num.intValue());
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public float getFocusDistance() {
        return this.camera_settings.focus_distance;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean setFocusDistance(float f) {
        Log.d(TAG, "setFocusDistance: " + f);
        if (this.camera_settings.focus_distance == f) {
            Log.d(TAG, "already set");
            return false;
        }
        this.camera_settings.focus_distance = f;
        this.camera_settings.focus_distance_manual = f;
        this.camera_settings.setFocusDistance(this.previewBuilder);
        try {
            setRepeatingRequest();
            return true;
        } catch (CameraAccessException e) {
            Log.e(TAG, "failed to set focus distance");
            Log.e(TAG, "reason: " + e.getReason());
            Log.e(TAG, "message: " + e.getMessage());
            e.printStackTrace();
            return true;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setFocusBracketingNImages(int i) {
        Log.d(TAG, "setFocusBracketingNImages: " + i);
        this.focus_bracketing_n_images = i;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setFocusBracketingAddInfinity(boolean z) {
        Log.d(TAG, "setFocusBracketingAddInfinity: " + z);
        this.focus_bracketing_add_infinity = z;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setFocusBracketingSourceDistance(float f) {
        Log.d(TAG, "setFocusBracketingSourceDistance: " + f);
        this.focus_bracketing_source_distance = f;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public float getFocusBracketingSourceDistance() {
        return this.focus_bracketing_source_distance;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setFocusBracketingTargetDistance(float f) {
        Log.d(TAG, "setFocusBracketingTargetDistance: " + f);
        this.focus_bracketing_target_distance = f;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public float getFocusBracketingTargetDistance() {
        return this.focus_bracketing_target_distance;
    }

    private void updateUseFakePrecaptureMode(String str) {
        Log.d(TAG, "useFakePrecaptureMode: " + str);
        if (str.equals("flash_frontscreen_auto") || str.equals("flash_frontscreen_on")) {
            this.use_fake_precapture_mode = true;
        } else if (this.burst_type != CameraController.BurstType.BURSTTYPE_NONE) {
            this.use_fake_precapture_mode = true;
        } else if (this.camera_settings.has_iso) {
            this.use_fake_precapture_mode = true;
        } else {
            this.use_fake_precapture_mode = this.use_fake_precapture;
        }
        Log.d(TAG, "use_fake_precapture_mode set to: " + this.use_fake_precapture_mode);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setFlashValue(String str) {
        Log.d(TAG, "setFlashValue: " + str);
        if (this.camera_settings.flash_value.equals(str)) {
            Log.d(TAG, "flash value already set");
            return;
        }
        try {
            updateUseFakePrecaptureMode(str);
            if (this.camera_settings.flash_value.equals("flash_torch") && !str.equals("flash_off")) {
                this.camera_settings.flash_value = "flash_off";
                this.camera_settings.setAEMode(this.previewBuilder, false);
                CaptureRequest build = this.previewBuilder.build();
                this.camera_settings.flash_value = str;
                this.camera_settings.setAEMode(this.previewBuilder, false);
                this.push_repeating_request_when_torch_off = true;
                this.push_repeating_request_when_torch_off_id = build;
                setRepeatingRequest(build);
            } else {
                this.camera_settings.flash_value = str;
                if (this.camera_settings.setAEMode(this.previewBuilder, false)) {
                    setRepeatingRequest();
                }
            }
        } catch (CameraAccessException e) {
            Log.e(TAG, "failed to set flash mode");
            Log.e(TAG, "reason: " + e.getReason());
            Log.e(TAG, "message: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public String getFlashValue() {
        return !((Boolean) this.characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE)).booleanValue() ? "" : this.camera_settings.flash_value;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setAutoExposureLock(boolean z) {
        if (z) {
            BLOCK_FOR_EXTENSIONS();
        }
        this.camera_settings.ae_lock = z;
        this.camera_settings.setAutoExposureLock(this.previewBuilder);
        try {
            setRepeatingRequest();
        } catch (CameraAccessException e) {
            Log.e(TAG, "failed to set auto exposure lock");
            Log.e(TAG, "reason: " + e.getReason());
            Log.e(TAG, "message: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean getAutoExposureLock() {
        if (this.previewBuilder.get(CaptureRequest.CONTROL_AE_LOCK) == null) {
            return false;
        }
        return ((Boolean) this.previewBuilder.get(CaptureRequest.CONTROL_AE_LOCK)).booleanValue();
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setAutoWhiteBalanceLock(boolean z) {
        if (z) {
            BLOCK_FOR_EXTENSIONS();
        }
        this.camera_settings.wb_lock = z;
        this.camera_settings.setAutoWhiteBalanceLock(this.previewBuilder);
        try {
            setRepeatingRequest();
        } catch (CameraAccessException e) {
            Log.e(TAG, "failed to set auto white balance lock");
            Log.e(TAG, "reason: " + e.getReason());
            Log.e(TAG, "message: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean getAutoWhiteBalanceLock() {
        if (this.previewBuilder.get(CaptureRequest.CONTROL_AWB_LOCK) == null) {
            return false;
        }
        return ((Boolean) this.previewBuilder.get(CaptureRequest.CONTROL_AWB_LOCK)).booleanValue();
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setRotation(int i) {
        this.camera_settings.rotation = i;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setLocationInfo(Location location) {
        Log.d(TAG, "setLocationInfo");
        this.camera_settings.location = location;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void removeLocationInfo() {
        this.camera_settings.location = null;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void enableShutterSound(boolean z) {
        this.sounds_enabled = z;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void playSound(int i) {
        if (this.sounds_enabled && ((AudioManager) this.context.getSystemService("audio")).getRingerMode() == 2) {
            this.media_action_sound.play(i);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Rect getViewableRect() {
        Rect rect;
        CaptureRequest.Builder builder = this.previewBuilder;
        if (builder == null || (rect = (Rect) builder.get(CaptureRequest.SCALER_CROP_REGION)) == null) {
            Rect rect2 = (Rect) this.characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            rect2.right -= rect2.left;
            rect2.left = 0;
            rect2.bottom -= rect2.top;
            rect2.top = 0;
            return rect2;
        }
        return rect;
    }

    private Rect convertRectToCamera2(Rect rect, Rect rect2) {
        int max = Math.max((int) (rect.left + (((rect2.left + 1000) / 2000.0d) * (rect.width() - 1))), rect.left);
        int max2 = Math.max((int) (rect.left + (((rect2.right + 1000) / 2000.0d) * (rect.width() - 1))), rect.left);
        int max3 = Math.max((int) (rect.top + (((rect2.top + 1000) / 2000.0d) * (rect.height() - 1))), rect.top);
        int max4 = Math.max((int) (rect.top + (((rect2.bottom + 1000) / 2000.0d) * (rect.height() - 1))), rect.top);
        return new Rect(Math.min(max, rect.right), Math.min(max3, rect.bottom), Math.min(max2, rect.right), Math.min(max4, rect.bottom));
    }

    private MeteringRectangle convertAreaToMeteringRectangle(Rect rect, CameraController.Area area) {
        return new MeteringRectangle(convertRectToCamera2(rect, area.rect), area.weight);
    }

    private Rect convertRectFromCamera2(Rect rect, Rect rect2) {
        double width = (rect2.left - rect.left) / (rect.width() - 1);
        double height = (rect2.top - rect.top) / (rect.height() - 1);
        double width2 = (rect2.right - rect.left) / (rect.width() - 1);
        int max = Math.max(((int) (width * 2000.0d)) - 1000, (int) NotificationManagerCompat.IMPORTANCE_UNSPECIFIED);
        int max2 = Math.max(((int) (width2 * 2000.0d)) - 1000, (int) NotificationManagerCompat.IMPORTANCE_UNSPECIFIED);
        int max3 = Math.max(((int) (height * 2000.0d)) - 1000, (int) NotificationManagerCompat.IMPORTANCE_UNSPECIFIED);
        int max4 = Math.max(((int) (((rect2.bottom - rect.top) / (rect.height() - 1)) * 2000.0d)) - 1000, (int) NotificationManagerCompat.IMPORTANCE_UNSPECIFIED);
        return new Rect(Math.min(max, 1000), Math.min(max3, 1000), Math.min(max2, 1000), Math.min(max4, 1000));
    }

    private CameraController.Area convertMeteringRectangleToArea(Rect rect, MeteringRectangle meteringRectangle) {
        return new CameraController.Area(convertRectFromCamera2(rect, meteringRectangle.getRect()), meteringRectangle.getMeteringWeight());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public CameraController.Face convertFromCameraFace(Rect rect, android.hardware.camera2.params.Face face) {
        return new CameraController.Face(face.getScore(), convertRectFromCamera2(rect, face.getBounds()));
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean setFocusAndMeteringArea(List<Area> list) {
        boolean z;
        Log.d(TAG, "setFocusAndMeteringArea");
        BLOCK_FOR_EXTENSIONS();
        Rect viewableRect = getViewableRect();
        Log.d(TAG, "sensor_rect: " + viewableRect.left + " , " + viewableRect.top + " x " + viewableRect.right + " , " + viewableRect.bottom);
        boolean z2 = true;
        int i = 0;
        if (((Integer) this.characteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF)).intValue()>0) {
            this.camera_settings.af_regions = new MeteringRectangle[list.size()];
            int i2 = 0;
            for (CameraController.Area area : list) {
                this.camera_settings.af_regions[i2] = convertAreaToMeteringRectangle(viewableRect, area);
                i2++;
            }
            this.camera_settings.setAFRegions(this.previewBuilder);
            z = true;
        } else {
            this.camera_settings.af_regions = null;
            z = false;
        }
        if (((Integer) this.characteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE)).intValue()>0) {
            this.camera_settings.ae_regions = new MeteringRectangle[list.size()];
            for (CameraController.Area area2 : list) {
                this.camera_settings.ae_regions[i] = convertAreaToMeteringRectangle(viewableRect, area2);
                i++;
            }
            this.camera_settings.setAERegions(this.previewBuilder);
        } else {
            this.camera_settings.ae_regions = null;
            z2 = false;
        }
        if (z || z2) {
            try {
                setRepeatingRequest();
            } catch (CameraAccessException e) {
                Log.e(TAG, "failed to set focus and/or metering regions");
                Log.e(TAG, "reason: " + e.getReason());
                Log.e(TAG, "message: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return z;
    }


    @Override
    public void clearFocusAndMetering() {
        Rect sensor_rect = getViewableRect();
        boolean has_focus = false;
        boolean has_metering = false;
        if( sensor_rect.width() <= 0 || sensor_rect.height() <= 0 ) {
            // had a crash on Google Play due to creating a MeteringRectangle with -ve width/height ?!
            camera_settings.af_regions = null;
            camera_settings.ae_regions = null;
        }
        else {
            if( characteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF) > 0 ) {
                has_focus = true;
                camera_settings.af_regions = new MeteringRectangle[1];
                camera_settings.af_regions[0] = new MeteringRectangle(0, 0, sensor_rect.width()-1, sensor_rect.height()-1, 0);
                camera_settings.setAFRegions(previewBuilder);
            }
            else
                camera_settings.af_regions = null;
            if( characteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE) > 0 ) {
                has_metering = true;
                camera_settings.ae_regions = new MeteringRectangle[1];
                camera_settings.ae_regions[0] = new MeteringRectangle(0, 0, sensor_rect.width()-1, sensor_rect.height()-1, 0);
                camera_settings.setAERegions(previewBuilder);
            }
            else
                camera_settings.ae_regions = null;
        }
        if( has_focus || has_metering ) {
            try {
                setRepeatingRequest();
            }
            catch(CameraAccessException e) {
                if( MyDebug.LOG ) {
                    Log.e(TAG, "failed to clear focus and metering regions");
                    Log.e(TAG, "reason: " + e.getReason());
                    Log.e(TAG, "message: " + e.getMessage());
                }
                e.printStackTrace();
            }
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public List<Area> getFocusAreas() {
        MeteringRectangle[] meteringRectangleArr;
        if (((Integer) this.characteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF)).intValue() == 0 || this.camera_settings.af_regions == null || (meteringRectangleArr = (MeteringRectangle[]) this.previewBuilder.get(CaptureRequest.CONTROL_AF_REGIONS)) == null) {
            return null;
        }
        Rect viewableRect = getViewableRect();
        if (meteringRectangleArr.length == 1 && meteringRectangleArr[0].getRect().left == 0 && meteringRectangleArr[0].getRect().top == 0 && meteringRectangleArr[0].getRect().right == viewableRect.width() - 1 && meteringRectangleArr[0].getRect().bottom == viewableRect.height() - 1) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (MeteringRectangle meteringRectangle : meteringRectangleArr) {
            arrayList.add(convertMeteringRectangleToArea(viewableRect, meteringRectangle));
        }
        return arrayList;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public List<Area> getMeteringAreas() {
        MeteringRectangle[] meteringRectangleArr;
        if (((Integer) this.characteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE)).intValue() == 0 || this.camera_settings.ae_regions == null || (meteringRectangleArr = (MeteringRectangle[]) this.previewBuilder.get(CaptureRequest.CONTROL_AE_REGIONS)) == null) {
            return null;
        }
        Rect viewableRect = getViewableRect();
        if (meteringRectangleArr.length == 1 && meteringRectangleArr[0].getRect().left == 0 && meteringRectangleArr[0].getRect().top == 0 && meteringRectangleArr[0].getRect().right == viewableRect.width() - 1 && meteringRectangleArr[0].getRect().bottom == viewableRect.height() - 1) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (MeteringRectangle meteringRectangle : meteringRectangleArr) {
            arrayList.add(convertMeteringRectangleToArea(viewableRect, meteringRectangle));
        }
        return arrayList;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean supportsAutoFocus() {
        Integer num;
        if (this.previewBuilder == null || this.sessionType == SessionType.SESSIONTYPE_EXTENSION || (num = (Integer) this.previewBuilder.get(CaptureRequest.CONTROL_AF_MODE)) == null) {
            return false;
        }
        return num.intValue() == 1 || num.intValue() == 2;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean supportsMetering() {
        return ((Integer) this.characteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE)).intValue()>0;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean focusIsContinuous() {
        Integer num;
        if (this.previewBuilder == null || this.sessionType == SessionType.SESSIONTYPE_EXTENSION || (num = (Integer) this.previewBuilder.get(CaptureRequest.CONTROL_AF_MODE)) == null) {
            return false;
        }
        return num.intValue() == 4 || num.intValue() == 3;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean focusIsVideo() {
        Integer num;
        return (this.previewBuilder == null || this.sessionType == SessionType.SESSIONTYPE_EXTENSION || (num = (Integer) this.previewBuilder.get(CaptureRequest.CONTROL_AF_MODE)) == null || num.intValue() != 3) ? false : true;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setPreviewDisplay(SurfaceHolder surfaceHolder) {
        Log.d(TAG, "setPreviewDisplay");
        Log.e(TAG, "SurfaceHolder not supported for CameraController2!");
        Log.e(TAG, "Should use setPreviewTexture() instead");
        throw new RuntimeException();
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setPreviewTexture(TextureView textureView) {
        Log.d(TAG, "setPreviewTexture: " + textureView);
        Log.d(TAG, "surface: " + textureView.getSurfaceTexture());
        if (this.texture != null) {
            Log.d(TAG, "preview texture already set");
            throw new RuntimeException();
        } else {
            this.texture = textureView.getSurfaceTexture();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setRepeatingRequest() throws CameraAccessException {
        setRepeatingRequest(this.previewBuilder.build());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setRepeatingRequest(CaptureRequest captureRequest) throws CameraAccessException {
        Log.d(TAG, "setRepeatingRequest");
        synchronized (this.background_camera_lock) {
            if (this.camera == null || !hasCaptureSession()) {
                Log.d(TAG, "no camera or capture session");
                return;
            }
            try {
                if (this.sessionType == SessionType.SESSIONTYPE_EXTENSION) {
                    if (Build.VERSION.SDK_INT>=31) {
                        this.extensionSession.setRepeatingRequest(captureRequest, this.executor, this.previewExtensionCaptureCallback);
                    }
                } else if (this.is_video_high_speed && Build.VERSION.SDK_INT>=23) {
                    CameraConstrainedHighSpeedCaptureSession cameraConstrainedHighSpeedCaptureSession = (CameraConstrainedHighSpeedCaptureSession) this.captureSession;
                    cameraConstrainedHighSpeedCaptureSession.setRepeatingBurst(cameraConstrainedHighSpeedCaptureSession.createHighSpeedRequestList(captureRequest), this.previewCaptureCallback, this.handler);
                } else {
                    this.captureSession.setRepeatingRequest(captureRequest, this.previewCaptureCallback, this.handler);
                }
                Log.d(TAG, "setRepeatingRequest done");
            } catch (IllegalStateException e) {
                Log.d(TAG, "captureSession already closed!");
                e.printStackTrace();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void capture() throws CameraAccessException {
        capture(this.previewBuilder.build());
    }

    private void capture(CaptureRequest captureRequest) {
        Log.d(TAG, "capture");
        synchronized (this.background_camera_lock) {
            if (this.camera != null && hasCaptureSession()) {
                BLOCK_FOR_EXTENSIONS();
                try {
                    this.captureSession.capture(captureRequest, this.previewCaptureCallback, this.handler);
                    return;
                } catch (CameraAccessException unused) {
                    return;
                }
            }
            Log.d(TAG, "no camera or capture session");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void createPreviewRequest() {
        Log.d(TAG, "createPreviewRequest");
        if (this.camera == null) {
            Log.d(TAG, "camera not available!");
            return;
        }
        Log.d(TAG, "camera: " + this.camera);
        try {
            CaptureRequest.Builder createCaptureRequest = this.camera.createCaptureRequest(1);
            this.previewBuilder = createCaptureRequest;
            createCaptureRequest.set(CaptureRequest.CONTROL_CAPTURE_INTENT, 1);
            this.previewIsVideoMode = false;
            this.camera_settings.setupBuilder(this.previewBuilder, false);
            Log.d(TAG, "successfully created preview request");
        } catch (CameraAccessException e) {
            Log.e(TAG, "failed to create capture request");
            Log.e(TAG, "reason: " + e.getReason());
            Log.e(TAG, "message: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private Surface getPreviewSurface() {
        return this.surface_texture;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void updatePreviewTexture() {
        Log.d(TAG, "updatePreviewTexture");
        if (this.texture != null) {
            if (this.preview_width == 0 || this.preview_height == 0) {
                Log.d(TAG, "preview size not yet set");
                return;
            }
            Log.d(TAG, "preview size: " + this.preview_width + " x " + this.preview_height);
            this.test_texture_view_buffer_w = this.preview_width;
            this.test_texture_view_buffer_h = this.preview_height;
            this.texture.setDefaultBufferSize(this.preview_width, this.preview_height);
        }
    }

    private void createCaptureSession(final MediaRecorder video_recorder, boolean want_photo_video_recording) throws CameraControllerException {
        if (MyDebug.LOG)
            Log.d(TAG, "create capture session");

        if (previewBuilder == null) {
            if (MyDebug.LOG)
                Log.d(TAG, "previewBuilder not present!");
            throw new RuntimeException(); // throw as RuntimeException, as this is a programming error
        }
        if (camera == null) {
            if (MyDebug.LOG)
                Log.e(TAG, "no camera");
            return;
        }

        if (captureSession != null) {
            if (MyDebug.LOG)
                Log.d(TAG, "close old capture session");
            captureSession.close();
            captureSession = null;
            //pending_request_when_ready = null;
        }

        try {
            if (video_recorder != null) {
                if (supports_photo_video_recording && !want_video_high_speed && want_photo_video_recording) {
                    createPictureImageReader();
                } else {
                    closePictureImageReader();
                }
            } else {
                // in some cases need to recreate picture imageReader and the texture default buffer size (e.g., see test testTakePhotoPreviewPaused())
                createPictureImageReader();
            }
            if (texture != null) {
                // need to set the texture size
                if (MyDebug.LOG)
                    Log.d(TAG, "set size of preview texture");
                if (preview_width == 0 || preview_height == 0) {
                    if (MyDebug.LOG)
                        Log.e(TAG, "application needs to call setPreviewSize()");
                    throw new RuntimeException(); // throw as RuntimeException, as this is a programming error
                }
                texture.setDefaultBufferSize(preview_width, preview_height);
                // also need to create a new surface for the texture, in case the size has changed - but make sure we remove the old one first!
                if (surface_texture != null) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "remove old target: " + surface_texture);
                    previewBuilder.removeTarget(surface_texture);
                }
                this.surface_texture = new Surface(texture);
                if (MyDebug.LOG)
                    Log.d(TAG, "created new target: " + surface_texture);
            }
            if (video_recorder != null) {
                if (MyDebug.LOG)
                    Log.d(TAG, "creating capture session for video recording");
            } else {
                if (MyDebug.LOG)
                    Log.d(TAG, "picture size: " + imageReader.getWidth() + " x " + imageReader.getHeight());
            }
			/*if( MyDebug.LOG )
			Log.d(TAG, "preview size: " + previewImageReader.getWidth() + " x " + previewImageReader.getHeight());*/
            if (MyDebug.LOG)
                Log.d(TAG, "preview size: " + this.preview_width + " x " + this.preview_height);

            if (video_recorder != null)
                video_recorder_surface = video_recorder.getSurface();
            else
                video_recorder_surface = null;
            if (MyDebug.LOG)
                Log.d(TAG, "video_recorder_surface: " + video_recorder_surface);

            class MyStateCallback extends CameraCaptureSession.StateCallback {
                private boolean callback_done; // must sychronize on this and notifyAll when setting to true

                @Override
                public void onConfigured(@NonNull CameraCaptureSession session) {
                    if (MyDebug.LOG) {
                        Log.d(TAG, "onConfigured: " + session);
                        Log.d(TAG, "captureSession was: " + captureSession);
                    }
                    if (camera == null) {
                        if (MyDebug.LOG) {
                            Log.d(TAG, "camera is closed");
                        }
                        synchronized (create_capture_session_lock) {
                            callback_done = true;
                            create_capture_session_lock.notifyAll();
                        }
                        return;
                    }
                    captureSession = session;
                    Surface surface = getPreviewSurface();
                    previewBuilder.addTarget(surface);
                    if (video_recorder != null)
                        previewBuilder.addTarget(video_recorder_surface);
                    try {
                        setRepeatingRequest();
                    } catch (CameraAccessException e) {
                        if (MyDebug.LOG) {
                            Log.e(TAG, "failed to start preview");
                            Log.e(TAG, "reason: " + e.getReason());
                            Log.e(TAG, "message: " + e.getMessage());
                        }
                        e.printStackTrace();
                        // we indicate that we failed to start the preview by setting captureSession back to null
                        // this will cause a CameraControllerException to be thrown below
                        captureSession = null;
                    }
                    synchronized (create_capture_session_lock) {
                        callback_done = true;
                        create_capture_session_lock.notifyAll();
                    }
                }

                @Override
                public void onConfigureFailed(@NonNull CameraCaptureSession session) {
                    if (MyDebug.LOG) {
                        Log.d(TAG, "onConfigureFailed: " + session);
                        Log.d(TAG, "captureSession was: " + captureSession);
                    }
                    synchronized (create_capture_session_lock) {
                        callback_done = true;
                        create_capture_session_lock.notifyAll();
                    }
                    // don't throw CameraControllerException here, as won't be caught - instead we throw CameraControllerException below
                }

				/*@Override
				public void onReady(CameraCaptureSession session) {
					if( MyDebug.LOG )
						Log.d(TAG, "onReady: " + session);
					if( pending_request_when_ready != null ) {
						if( MyDebug.LOG )
							Log.d(TAG, "have pending_request_when_ready: " + pending_request_when_ready);
						CaptureRequest request = pending_request_when_ready;
						pending_request_when_ready = null;
						try {
							captureSession.capture(request, previewCaptureCallback, handler);
						}
						catch(CameraAccessException e) {
							if( MyDebug.LOG ) {
								Log.e(TAG, "failed to take picture");
								Log.e(TAG, "reason: " + e.getReason());
								Log.e(TAG, "message: " + e.getMessage());
							}
							e.printStackTrace();
							jpeg_cb = null;
							if( take_picture_error_cb != null ) {
								take_picture_error_cb.onError();
								take_picture_error_cb = null;
							}
						}
					}
				}*/
            }
            final MyStateCallback myStateCallback = new MyStateCallback();

            Surface preview_surface = getPreviewSurface();
            List<Surface> surfaces;
            if (video_recorder != null) {
                if (supports_photo_video_recording && !want_video_high_speed && want_photo_video_recording) {
                    surfaces = Arrays.asList(preview_surface, video_recorder_surface, imageReader.getSurface());
                } else {
                    surfaces = Arrays.asList(preview_surface, video_recorder_surface);
                }
                // n.b., raw not supported for photo snapshots while video recording
            } else if (imageReaderRaw != null) {
                surfaces = Arrays.asList(preview_surface, imageReader.getSurface(), imageReaderRaw.getSurface());
            } else {
                surfaces = Arrays.asList(preview_surface, imageReader.getSurface());
            }
            if (MyDebug.LOG) {
                Log.d(TAG, "texture: " + texture);
                Log.d(TAG, "preview_surface: " + preview_surface);
                if (video_recorder == null) {
                    if (imageReaderRaw != null) {
                        Log.d(TAG, "imageReaderRaw: " + imageReaderRaw);
                        Log.d(TAG, "imageReaderRaw: " + imageReaderRaw.getWidth());
                        Log.d(TAG, "imageReaderRaw: " + imageReaderRaw.getHeight());
                        Log.d(TAG, "imageReaderRaw: " + imageReaderRaw.getImageFormat());
                    } else {
                        Log.d(TAG, "imageReader: " + imageReader);
                        Log.d(TAG, "imageReader width: " + imageReader.getWidth());
                        Log.d(TAG, "imageReader height: " + imageReader.getHeight());
                        Log.d(TAG, "imageReader format: " + imageReader.getImageFormat());
                    }
                }
            }
            if (video_recorder != null && want_video_high_speed && Build.VERSION.SDK_INT>=Build.VERSION_CODES.M) {
                camera.createConstrainedHighSpeedCaptureSession(surfaces,
                        myStateCallback,
                        handler);
                is_video_high_speed = true;
            } else {
                try {
                    camera.createCaptureSession(surfaces,
                            myStateCallback,
                            handler);
                    is_video_high_speed = false;
                } catch (NullPointerException e) {
                    // have had this from some devices on Google Play, from deep within createCaptureSession
                    // note, we put the catch here rather than below, so as to not mask nullpointerexceptions
                    // from my code
                    if (MyDebug.LOG) {
                        Log.e(TAG, "NullPointerException trying to create capture session");
                        Log.e(TAG, "message: " + e.getMessage());
                    }
                    e.printStackTrace();
                    throw new CameraControllerException();
                }
            }
            if (MyDebug.LOG)
                Log.d(TAG, "wait until session created...");
            synchronized (create_capture_session_lock) {
                while (!myStateCallback.callback_done) {
                    try {
                        // release the lock, and wait until myStateCallback calls notifyAll()
                        create_capture_session_lock.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
            if (MyDebug.LOG) {
                Log.d(TAG, "created captureSession: " + captureSession);
            }
            if (captureSession == null) {
                if (MyDebug.LOG)
                    Log.e(TAG, " ");
                throw new CameraControllerException();
            }
        } catch (CameraAccessException e) {
            if (MyDebug.LOG) {
                Log.e(TAG, "CameraAccessException trying to create capture session");
                Log.e(TAG, "reason: " + e.getReason());
                Log.e(TAG, "message: " + e.getMessage());
            }
            e.printStackTrace();
            throw new CameraControllerException();
        } catch (IllegalArgumentException e) {
            // have had crashes from Google Play, from both createConstrainedHighSpeedCaptureSession and
            // createCaptureSession
            if (MyDebug.LOG) {
                Log.e(TAG, "IllegalArgumentException trying to create capture session");
                Log.e(TAG, "message: " + e.getMessage());
            }
            e.printStackTrace();
            throw new CameraControllerException();
        }
    }


    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.live.gpsmap.camera.Camera.cameracontroller.CameraController2$2MyStateCallback  reason: invalid class name */
    /* loaded from: classes3.dex */
    public class C2MyStateCallback extends CameraCaptureSession.StateCallback {
        private boolean callback_done;
        final /* synthetic */ MediaRecorder val$video_recorder;

        C2MyStateCallback(MediaRecorder mediaRecorder) {
            this.val$video_recorder = mediaRecorder;
        }

        void onConfigured(CameraCaptureSession cameraCaptureSession, CameraExtensionSession cameraExtensionSession) {
            if (CameraController2.this.camera == null) {
                Log.d(CameraController2.TAG, "camera is closed");
                synchronized (CameraController2.this.background_camera_lock) {
                    this.callback_done = true;
                    CameraController2.this.background_camera_lock.notifyAll();
                }
                return;
            }
            synchronized (CameraController2.this.background_camera_lock) {
                CameraController2.this.captureSession = cameraCaptureSession;
                CameraController2.this.extensionSession = cameraExtensionSession;
                CameraController2.this.previewBuilder.addTarget(CameraController2.this.surface_texture);
                if (this.val$video_recorder != null) {
                    Log.d(CameraController2.TAG, "add video recorder surface to previewBuilder: " + CameraController2.this.video_recorder_surface);
                    CameraController2.this.previewBuilder.addTarget(CameraController2.this.video_recorder_surface);
                }
                try {
                    CameraController2.this.setRepeatingRequest();
                } catch (CameraAccessException e) {
                    Log.e(CameraController2.TAG, "failed to start preview");
                    Log.e(CameraController2.TAG, "reason: " + e.getReason());
                    Log.e(CameraController2.TAG, "message: " + e.getMessage());
                    e.printStackTrace();
                    CameraController2.this.captureSession = null;
                    CameraController2.this.extensionSession = null;
                }
            }
            synchronized (CameraController2.this.background_camera_lock) {
                this.callback_done = true;
                CameraController2.this.background_camera_lock.notifyAll();
            }
        }

        @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
        public void onConfigured(CameraCaptureSession cameraCaptureSession) {
            Log.d(CameraController2.TAG, "onConfigured: " + cameraCaptureSession);
            onConfigured(cameraCaptureSession, null);
        }

        void onConfigureFailed() {
            synchronized (CameraController2.this.background_camera_lock) {
                this.callback_done = true;
                CameraController2.this.background_camera_lock.notifyAll();
            }
        }

        @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
        public void onConfigureFailed(CameraCaptureSession cameraCaptureSession) {
            Log.d(CameraController2.TAG, "onConfigureFailed: " + cameraCaptureSession);
            onConfigureFailed();
        }
    }

    @Override
    public void startPreview() throws CameraControllerException {
        Log.d(TAG, "startPreview");
        if (!this.camera_settings.has_af_mode && this.initial_focus_mode != null && this.sessionType != SessionType.SESSIONTYPE_EXTENSION) {
            Log.d(TAG, "user didn't specify focus, so set to: " + this.initial_focus_mode);
            setFocusValue(this.initial_focus_mode);
        }
        synchronized (this.background_camera_lock) {
            if (hasCaptureSession()) {
                try {
                    setRepeatingRequest();
                    return;
                } catch (CameraAccessException e) {
                    Log.e(TAG, "failed to start preview");
                    Log.e(TAG, "reason: " + e.getReason());
                    Log.e(TAG, "message: " + e.getMessage());
                    e.printStackTrace();
                    throw new CameraControllerException();
                }
            }
            createCaptureSession(null, false);
        }
    }

    @Override
    public void stopPreview() {
        Log.d(TAG, "stopPreview: " + this);
        synchronized (this.background_camera_lock) {
            if (this.camera == null || !hasCaptureSession()) {
                Log.d(TAG, "no camera or capture session");
                return;
            }
            try {
                try {
                    if (this.sessionType == SessionType.SESSIONTYPE_EXTENSION) {
                        if (Build.VERSION.SDK_INT>=31) {
                            this.extensionSession.stopRepeating();
                        }
                    } else {
                        this.captureSession.stopRepeating();
                    }
                } catch (CameraAccessException e) {
                    Log.e(TAG, "failed to stop repeating");
                    Log.e(TAG, "reason: " + e.getReason());
                    Log.e(TAG, "message: " + e.getMessage());
                    e.printStackTrace();
                }
            } catch (IllegalStateException e2) {
                Log.d(TAG, "captureSession already closed!");
                e2.printStackTrace();
            }
            closeCaptureSession();
            if (this.camera_settings.has_face_detect_mode) {
                Log.d(TAG, "cancel face detection");
                this.camera_settings.has_face_detect_mode = false;
                this.camera_settings.setFaceDetectMode(this.previewBuilder);
            }
        }
    }

    @Override
    public boolean startFaceDetection() {
        if (MyDebug.LOG)
            Log.d(TAG, "startFaceDetection");
        if (previewBuilder.get(CaptureRequest.STATISTICS_FACE_DETECT_MODE) != null && previewBuilder.get(CaptureRequest.STATISTICS_FACE_DETECT_MODE) != CaptureRequest.STATISTICS_FACE_DETECT_MODE_OFF) {
            if (MyDebug.LOG)
                Log.d(TAG, "face detection already enabled");
            return false;
        }
        if (supports_face_detect_mode_full) {
            if (MyDebug.LOG)
                Log.d(TAG, "use full face detection");
            camera_settings.has_face_detect_mode = true;
            camera_settings.face_detect_mode = CaptureRequest.STATISTICS_FACE_DETECT_MODE_FULL;
        } else if (supports_face_detect_mode_simple) {
            if (MyDebug.LOG)
                Log.d(TAG, "use simple face detection");
            camera_settings.has_face_detect_mode = true;
            camera_settings.face_detect_mode = CaptureRequest.STATISTICS_FACE_DETECT_MODE_SIMPLE;
        } else {
            Log.e(TAG, "startFaceDetection() called but face detection not available");
            return false;
        }
        camera_settings.setFaceDetectMode(previewBuilder);
        camera_settings.setSceneMode(previewBuilder); // also need to set the scene mode
        try {
            setRepeatingRequest();
            return false;
        } catch (CameraAccessException e) {
            if (MyDebug.LOG) {
                Log.e(TAG, "failed to start face detection");
                Log.e(TAG, "reason: " + e.getReason());
                Log.e(TAG, "message: " + e.getMessage());
            }
            e.printStackTrace();
        }
        return true;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setFaceDetectionListener(CameraController.FaceDetectionListener faceDetectionListener) {
        if (faceDetectionListener != null) {
            BLOCK_FOR_EXTENSIONS();
        }
        this.face_detection_listener = faceDetectionListener;
        this.last_faces_detected = -1;
    }

    @Override
    public void autoFocus(final AutoFocusCallback cb, boolean capture_follows_autofocus_hint) {
        if (MyDebug.LOG) {
            Log.d(TAG, "autoFocus");
            Log.d(TAG, "capture_follows_autofocus_hint? " + capture_follows_autofocus_hint);
        }
        fake_precapture_torch_focus_performed = false;
        if (camera == null || captureSession == null) {
            if (MyDebug.LOG)
                Log.d(TAG, "no camera or capture session");
            // should call the callback, so the application isn't left waiting (e.g., when we autofocus before trying to take a photo)
            cb.onAutoFocus(false);
            return;
        }
        Integer focus_mode = previewBuilder.get(CaptureRequest.CONTROL_AF_MODE);
        if (focus_mode == null) {
            // we preserve the old Camera API where calling autoFocus() on a device without autofocus immediately calls the callback
            // (unclear if Open Camera needs this, but just to be safe and consistent between camera APIs)
            cb.onAutoFocus(true);
            return;
        } else if ((!do_af_trigger_for_continuous || use_fake_precapture_mode) && focus_mode == CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE) {
            // See note above for do_af_trigger_for_continuous
            this.capture_follows_autofocus_hint = capture_follows_autofocus_hint;
            this.autofocus_cb = cb;
            return;
        } else if (is_video_high_speed) {
            // CONTROL_AF_TRIGGER_IDLE/CONTROL_AF_TRIGGER_START not supported for high speed video
            cb.onAutoFocus(true);
            return;
        }
		/*if( state == STATE_WAITING_AUTOFOCUS ) {
			if( MyDebug.LOG )
				Log.d(TAG, "already waiting for an autofocus");
			// need to update the callback!
			this.capture_follows_autofocus_hint = capture_follows_autofocus_hint;
			this.autofocus_cb = cb;
			return;
		}*/
        CaptureRequest.Builder afBuilder = previewBuilder;
        if (MyDebug.LOG) {
            {
                MeteringRectangle[] areas = afBuilder.get(CaptureRequest.CONTROL_AF_REGIONS);
                for (int i = 0; areas != null && i<areas.length; i++) {
                    Log.d(TAG, i + " focus area: " + areas[i].getX() + " , " + areas[i].getY() + " : " + areas[i].getWidth() + " x " + areas[i].getHeight() + " weight " + areas[i].getMeteringWeight());
                }
            }
            {
                MeteringRectangle[] areas = afBuilder.get(CaptureRequest.CONTROL_AE_REGIONS);
                for (int i = 0; areas != null && i<areas.length; i++) {
                    Log.d(TAG, i + " metering area: " + areas[i].getX() + " , " + areas[i].getY() + " : " + areas[i].getWidth() + " x " + areas[i].getHeight() + " weight " + areas[i].getMeteringWeight());
                }
            }
        }
        state = STATE_WAITING_AUTOFOCUS;
        precapture_state_change_time_ms = -1;
        this.capture_follows_autofocus_hint = capture_follows_autofocus_hint;
        this.autofocus_cb = cb;
        try {
            if (use_fake_precapture_mode && !camera_settings.has_iso) {
                boolean want_flash = false;
                if (camera_settings.flash_value.equals("flash_auto") || camera_settings.flash_value.equals("flash_frontscreen_auto")) {
                    // calling fireAutoFlash() also caches the decision on whether to flash - otherwise if the flash fires now, we'll then think the scene is bright enough to not need the flash!
                    if (fireAutoFlash())
                        want_flash = true;
                } else if (camera_settings.flash_value.equals("flash_on")) {
                    want_flash = true;
                }
                if (want_flash) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "turn on torch for fake flash");
                    afBuilder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON);
                    afBuilder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_TORCH);
                    test_fake_flash_focus++;
                    fake_precapture_torch_focus_performed = true;
                    setRepeatingRequest(afBuilder.build());
                    // We sleep for a short time as on some devices (e.g., OnePlus 3T), the torch will turn off when autofocus
                    // completes even if we don't want that (because we'll be taking a photo).
                    // Note that on other devices such as Nexus 6, this problem doesn't occur even if we don't have a separate
                    // setRepeatingRequest.
                    // Update for 1.37: now we do need this for Nexus 6 too, after switching to setting CONTROL_AE_MODE_ON_AUTO_FLASH
                    // or CONTROL_AE_MODE_ON_ALWAYS_FLASH even for fake flash (see note in CameraSettings.setAEMode()) - and we
                    // needed to increase to 200ms! Otherwise photos come out too dark for flash on if doing touch to focus then
                    // quickly taking a photo. (It also work to previously switch to CONTROL_AE_MODE_ON/FLASH_MODE_OFF first,
                    // but then the same problem shows up on OnePlus 3T again!)
                    try {
                        Thread.sleep(200);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }

            // Camera2Basic sets a trigger with capture
            // Google Camera sets to idle with a repeating request, then sets af trigger to start with a capture
            afBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_IDLE);
            setRepeatingRequest(afBuilder.build());
            afBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START);
            capture(afBuilder.build());
        } catch (CameraAccessException e) {
            if (MyDebug.LOG) {
                Log.e(TAG, "failed to autofocus");
                Log.e(TAG, "reason: " + e.getReason());
                Log.e(TAG, "message: " + e.getMessage());
            }
            e.printStackTrace();
            state = STATE_NORMAL;
            precapture_state_change_time_ms = -1;
            autofocus_cb.onAutoFocus(false);
            autofocus_cb = null;
            this.capture_follows_autofocus_hint = false;
        }
        afBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_IDLE); // ensure set back to idle
    }


    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setCaptureFollowAutofocusHint(boolean z) {
        Log.d(TAG, "setCaptureFollowAutofocusHint");
        Log.d(TAG, "capture_follows_autofocus_hint? " + z);
        BLOCK_FOR_EXTENSIONS();
        synchronized (this.background_camera_lock) {
            this.capture_follows_autofocus_hint = z;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void cancelAutoFocus() {
        Log.d(TAG, "cancelAutoFocus");
        synchronized (this.background_camera_lock) {
            if (this.camera != null && hasCaptureSession()) {
                if (this.is_video_high_speed) {
                    Log.d(TAG, "video is high speed");
                    return;
                } else if (this.sessionType == SessionType.SESSIONTYPE_EXTENSION) {
                    Log.d(TAG, "session type extension");
                    return;
                } else {
                    this.previewBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, 2);
                    try {
                        capture();
                    } catch (CameraAccessException e) {
                        Log.e(TAG, "failed to cancel autofocus [capture]");
                        Log.e(TAG, "reason: " + e.getReason());
                        Log.e(TAG, "message: " + e.getMessage());
                        e.printStackTrace();
                    }
                    this.previewBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, 0);
                    this.autofocus_cb = null;
                    this.autofocus_time_ms = -1L;
                    this.capture_follows_autofocus_hint = false;
                    this.state = 0;
                    this.precapture_state_change_time_ms = -1L;
                    try {
                        setRepeatingRequest();
                    } catch (CameraAccessException e2) {
                        Log.e(TAG, "failed to set repeating request after cancelling autofocus");
                        Log.e(TAG, "reason: " + e2.getReason());
                        Log.e(TAG, "message: " + e2.getMessage());
                        e2.printStackTrace();
                    }
                    return;
                }
            }
            Log.d(TAG, "no camera or capture session");
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setContinuousFocusMoveCallback(CameraController.ContinuousFocusMoveCallback continuousFocusMoveCallback) {
        Log.d(TAG, "setContinuousFocusMoveCallback");
        if (continuousFocusMoveCallback != null) {
            BLOCK_FOR_EXTENSIONS();
        }
        this.continuous_focus_move_callback = continuousFocusMoveCallback;
    }

    private void takePictureAfterPrecapture() {
        if (MyDebug.LOG)
            Log.d(TAG, "takePictureAfterPrecapture");
        if (!previewIsVideoMode) {
            // special burst modes not supported for photo snapshots when recording video
            if (burst_type == BurstType.BURSTTYPE_EXPO || burst_type == BurstType.BURSTTYPE_FOCUS) {
                takePictureBurstBracketing();
                return;
            } else if (burst_type == BurstType.BURSTTYPE_NORMAL) {
                takePictureBurst();
                return;
            }
        }
        if (camera == null || captureSession == null) {
            if (MyDebug.LOG)
                Log.d(TAG, "no camera or capture session");
            return;
        }
        try {
            if (MyDebug.LOG) {
                if (imageReaderRaw != null) {
                    Log.d(TAG, "imageReaderRaw: " + imageReaderRaw.toString());
                    Log.d(TAG, "imageReaderRaw surface: " + imageReaderRaw.getSurface().toString());
                } else {
                    Log.d(TAG, "imageReader: " + imageReader.toString());
                    Log.d(TAG, "imageReader surface: " + imageReader.getSurface().toString());
                }
            }
            CaptureRequest.Builder stillBuilder = camera.createCaptureRequest(previewIsVideoMode ? CameraDevice.TEMPLATE_VIDEO_SNAPSHOT : CameraDevice.TEMPLATE_STILL_CAPTURE);
            stillBuilder.set(CaptureRequest.CONTROL_CAPTURE_INTENT, CaptureRequest.CONTROL_CAPTURE_INTENT_STILL_CAPTURE);
//            stillBuilder.setTag(RequestTag.CAPTURE);
            camera_settings.setupBuilder(stillBuilder, true);
            if (use_fake_precapture_mode && fake_precapture_torch_performed) {
                if (MyDebug.LOG)
                    Log.d(TAG, "setting torch for capture");
                if (!camera_settings.has_iso)
                    stillBuilder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON);
                stillBuilder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_TORCH);
                test_fake_flash_photo++;
            }
            if (!camera_settings.has_iso && this.optimise_ae_for_dro && capture_result_has_exposure_time && (camera_settings.flash_value.equals("flash_off") || camera_settings.flash_value.equals("flash_auto") || camera_settings.flash_value.equals("flash_frontscreen_auto"))) {
                final double full_exposure_time_scale = Math.pow(2.0, -0.5);
                final long fixed_exposure_time = 1000000000L / 60; // we only scale the exposure time at all if it's less than this value
                final long scaled_exposure_time = 1000000000L / 120; // we only scale the exposure time by the full_exposure_time_scale if the exposure time is less than this value
                long exposure_time = capture_result_exposure_time;
                if (exposure_time<=fixed_exposure_time) {
                    double exposure_time_scale = getScaleForExposureTime(exposure_time, fixed_exposure_time, scaled_exposure_time, full_exposure_time_scale);
                    exposure_time *= exposure_time_scale;
                    if (MyDebug.LOG) {
                        Log.d(TAG, "reduce exposure shutter speed further, was: " + exposure_time);
                        Log.d(TAG, "exposure_time_scale: " + exposure_time_scale);
                    }
                    modified_from_camera_settings = true;
                    setManualExposureTime(stillBuilder, exposure_time);
                }
            }
            //stillBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            //stillBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH);
            if (Build.VERSION.SDK_INT>=android.os.Build.VERSION_CODES.O) {
                // unclear why we wouldn't want to request ZSL
                // this is also required to enable HDR+ on Google Pixel devices when using Camera2: https://opensource.google.com/projects/pixelvisualcorecamera
                stillBuilder.set(CaptureRequest.CONTROL_ENABLE_ZSL, true);
                if (MyDebug.LOG) {
                    Boolean zsl = stillBuilder.get(CaptureRequest.CONTROL_ENABLE_ZSL);
                    Log.d(TAG, "CONTROL_ENABLE_ZSL: " + (zsl == null ? "null" : zsl));
                }
            }
            clearPending();
            // shouldn't add preview surface as a target - no known benefit to doing so
            stillBuilder.addTarget(imageReader.getSurface());
            if (imageReaderRaw != null)
                stillBuilder.addTarget(imageReaderRaw.getSurface());

            n_burst = 1;
            burst_single_request = false;
            if (!previewIsVideoMode) {
                // need to stop preview before capture (as done in Camera2Basic; otherwise we get bugs such as flash remaining on after taking a photo with flash)
                // but don't do this in video mode - if we're taking photo snapshots while video recording, we don't want to pause video!
                captureSession.stopRepeating();
            }
            if (picture_cb != null) {
                if (MyDebug.LOG)
                    Log.d(TAG, "call onStarted() in callback");
                picture_cb.onStarted();
            }
            if (MyDebug.LOG)
                Log.d(TAG, "capture with stillBuilder");
            //pending_request_when_ready = stillBuilder.build();
            captureSession.capture(stillBuilder.build(), previewCaptureCallback, handler);
            //captureSession.capture(stillBuilder.build(), new CameraCaptureSession.CaptureCallback() {
            //}, handler);
            if (sounds_enabled) // play shutter sound asap, otherwise user has the illusion of being slow to take photos
                media_action_sound.play(MediaActionSound.SHUTTER_CLICK);
        } catch (CameraAccessException e) {
            if (MyDebug.LOG) {
                Log.e(TAG, "failed to take picture");
                Log.e(TAG, "reason: " + e.getReason());
                Log.e(TAG, "message: " + e.getMessage());
            }
            e.printStackTrace();
            picture_cb = null;
            if (take_picture_error_cb != null) {
                take_picture_error_cb.onError();
                take_picture_error_cb = null;
            }
        }
    }


    public static List<Float> setupFocusBracketingDistances(float f, float f2, int i) {
        String str;
        float f3;
        ArrayList arrayList = new ArrayList();
        float max = Math.max(f, 0.1f);
        float max2 = Math.max(f2, 0.1f);
        String str2 = TAG;
        Log.d(TAG, "focus_distance_s: " + max);
        Log.d(TAG, "focus_distance_e: " + max2);
        float f4 = 1.0f / max;
        float f5 = 1.0f / max2;
        Log.d(TAG, "real_focus_distance_s: " + f4);
        Log.d(TAG, "real_focus_distance_e: " + f5);
        int i2 = 0;
        while (i2<i) {
            Log.d(str2, "i: " + i2);
            if (i2 == 0) {
                str = str2;
                f3 = f;
            } else {
                int i3 = i - 1;
                if (i2 == i3) {
                    str = str2;
                    f3 = f2;
                } else {
                    int i4 = (f4>f5 ? 1 : (f4 == f5 ? 0 : -1));
                    int i5 = i4>0 ? i3 - i2 : i2;
                    str = str2;
                    float log = (float) (1.0d - (Math.log(i - i5) / Math.log(i)));
                    if (i4>0) {
                        log = 1.0f - log;
                    }
                    float f6 = ((1.0f - log) * f4) + (log * f5);
                    Log.d(str, "    alpha: " + log);
                    Log.d(str, "    real_distance: " + f6);
                    f3 = 1.0f / f6;
                }
            }
            Log.d(str, "    distance: " + f3);
            arrayList.add(Float.valueOf(f3));
            i2++;
            str2 = str;
        }
        return arrayList;
    }


    private void takePictureBurstBracketing() {
        if( MyDebug.LOG )
            Log.d(TAG, "takePictureBurstBracketing");
        if( burst_type != BurstType.BURSTTYPE_EXPO && burst_type != BurstType.BURSTTYPE_FOCUS ) {
            Log.e(TAG, "takePictureBurstBracketing called but unexpected burst_type: " + burst_type);
        }
        if( camera == null || captureSession == null ) {
            if( MyDebug.LOG )
                Log.d(TAG, "no camera or capture session");
            return;
        }
        try {
            if( MyDebug.LOG ) {
                Log.d(TAG, "imageReader: " + imageReader.toString());
                Log.d(TAG, "imageReader surface: " + imageReader.getSurface().toString());
            }

            CaptureRequest.Builder stillBuilder = camera.createCaptureRequest(previewIsVideoMode ? CameraDevice.TEMPLATE_VIDEO_SNAPSHOT : CameraDevice.TEMPLATE_STILL_CAPTURE);
            stillBuilder.set(CaptureRequest.CONTROL_CAPTURE_INTENT, CaptureRequest.CONTROL_CAPTURE_INTENT_STILL_CAPTURE);
            // n.b., don't set RequestTag.CAPTURE here - we only do it for the last of the burst captures (see below)
            camera_settings.setupBuilder(stillBuilder, true);
            clearPending();
            // shouldn't add preview surface as a target - see note in takePictureAfterPrecapture()
            // but also, adding the preview surface causes the dark/light exposures to be visible, which we don't want
            stillBuilder.addTarget(imageReader.getSurface());
            // don't add target imageReaderRaw, as Raw not supported for burst
            picture_cb = null; // raw not supported for burst

            List<CaptureRequest> requests = new ArrayList<>();

            if( burst_type == BurstType.BURSTTYPE_EXPO ) {

                if( MyDebug.LOG )
                    Log.d(TAG, "expo bracketing");

			/*stillBuilder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON);
			stillBuilder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF);

			stillBuilder.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, -6);
			requests.add( stillBuilder.build() );
			stillBuilder.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, 0);
			requests.add( stillBuilder.build() );
			stillBuilder.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, 6);
			requests.add( stillBuilder.build() );*/

                stillBuilder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF);
                if( use_fake_precapture_mode && fake_precapture_torch_performed ) {
                    if( MyDebug.LOG )
                        Log.d(TAG, "setting torch for capture");
                    stillBuilder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_TORCH);
                    test_fake_flash_photo++;
                }
                // else don't turn torch off, as user may be in torch on mode

                Range<Integer> iso_range = characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE); // may be null on some devices
                if( iso_range == null ) {
                    Log.e(TAG, "takePictureBurstBracketing called but null iso_range");
                }
                else {
                    // set ISO
                    int iso = 800;
                    // obtain current ISO/etc settings from the capture result - but if we're in manual ISO mode,
                    // might as well use the settings the user has actually requested (also useful for workaround for
                    // OnePlus 3T bug where the reported ISO and exposure_time are wrong in dark scenes)
                    if( camera_settings.has_iso )
                        iso = camera_settings.iso;
                    else if( capture_result_has_iso )
                        iso = capture_result_iso;
                    // see https://sourceforge.net/p/opencamera/tickets/321/ - some devices may have auto ISO that's
                    // outside of the allowed manual iso range!
                    iso = Math.max(iso, iso_range.getLower());
                    iso = Math.min(iso, iso_range.getUpper());
                    stillBuilder.set(CaptureRequest.SENSOR_SENSITIVITY, iso );
                }
                if( capture_result_has_frame_duration  )
                    stillBuilder.set(CaptureRequest.SENSOR_FRAME_DURATION, capture_result_frame_duration);
                else
                    stillBuilder.set(CaptureRequest.SENSOR_FRAME_DURATION, 1000000000L/30);

                long base_exposure_time = 1000000000L/30;
                if( camera_settings.has_iso )
                    base_exposure_time = camera_settings.exposure_time;
                else if( capture_result_has_exposure_time )
                    base_exposure_time = capture_result_exposure_time;

                int n_half_images = expo_bracketing_n_images/2;
                long min_exposure_time = base_exposure_time;
                long max_exposure_time = base_exposure_time;
                final double scale = Math.pow(2.0, expo_bracketing_stops/(double)n_half_images);
                Range<Long> exposure_time_range = characteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE); // may be null on some devices
                if( exposure_time_range != null ) {
                    min_exposure_time = exposure_time_range.getLower();
                    max_exposure_time = exposure_time_range.getUpper();
                }

                if( MyDebug.LOG ) {
                    Log.d(TAG, "taking expo bracketing with n_images: " + expo_bracketing_n_images);
                    Log.d(TAG, "ISO: " + stillBuilder.get(CaptureRequest.SENSOR_SENSITIVITY));
                    Log.d(TAG, "Frame duration: " + stillBuilder.get(CaptureRequest.SENSOR_FRAME_DURATION));
                    Log.d(TAG, "Base exposure time: " + base_exposure_time);
                    Log.d(TAG, "Min exposure time: " + min_exposure_time);
                    Log.d(TAG, "Max exposure time: " + max_exposure_time);
                }

                // darker images
                for(int i=0;i<n_half_images;i++) {
                    long exposure_time = base_exposure_time;
                    if( exposure_time_range != null ) {
                        double this_scale = scale;
                        for(int j=i;j<n_half_images-1;j++)
                            this_scale *= scale;
                        exposure_time /= this_scale;
                        if( exposure_time < min_exposure_time )
                            exposure_time = min_exposure_time;
                        if( MyDebug.LOG ) {
                            Log.d(TAG, "add burst request for " + i + "th dark image:");
                            Log.d(TAG, "    this_scale: " + this_scale);
                            Log.d(TAG, "    exposure_time: " + exposure_time);
                        }
                        stillBuilder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exposure_time);
                        requests.add( stillBuilder.build() );
                    }
                }

                // base image
                if( MyDebug.LOG )
                    Log.d(TAG, "add burst request for base image");
                stillBuilder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, base_exposure_time);
                requests.add( stillBuilder.build() );

                // lighter images
                for(int i=0;i<n_half_images;i++) {
                    long exposure_time = base_exposure_time;
                    if( exposure_time_range != null ) {
                        double this_scale = scale;
                        for(int j=0;j<i;j++)
                            this_scale *= scale;
                        exposure_time *= this_scale;
                        if( exposure_time > max_exposure_time )
                            exposure_time = max_exposure_time;
                        if( MyDebug.LOG ) {
                            Log.d(TAG, "add burst request for " + i + "th light image:");
                            Log.d(TAG, "    this_scale: " + this_scale);
                            Log.d(TAG, "    exposure_time: " + exposure_time);
                        }
                        stillBuilder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exposure_time);
                        if( i == n_half_images - 1 ) {
                            // RequestTag.CAPTURE should only be set for the last request, otherwise we'll may do things like turning
                            // off torch (for fake flash) before all images are received
                            // More generally, doesn't seem a good idea to be doing the post-capture commands (resetting ae state etc)
                            // multiple times, and before all captures are complete!
                            if( MyDebug.LOG )
                                Log.d(TAG, "set RequestTag.CAPTURE for last burst request");
                            stillBuilder.setTag(RequestTagType.CAPTURE);
                        }
                        requests.add( stillBuilder.build() );
                    }
                }

            }
            else {
                // BURSTTYPE_FOCUS
                if( MyDebug.LOG )
                    Log.d(TAG, "focus bracketing");

                if( use_fake_precapture_mode && fake_precapture_torch_performed ) {
                    if( MyDebug.LOG )
                        Log.d(TAG, "setting torch for capture");
                    if( !camera_settings.has_iso )
                        stillBuilder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON);
                    stillBuilder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_TORCH);
                    test_fake_flash_photo++;
                }

                stillBuilder.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF); // just in case

                if( Math.abs(camera_settings.focus_distance - focus_bracketing_source_distance) < 1.0e-5 ) {
                    if( MyDebug.LOG )
                        Log.d(TAG, "current focus matches source");
                }
                else if( Math.abs(camera_settings.focus_distance - focus_bracketing_target_distance) < 1.0e-5 ) {
                    if( MyDebug.LOG )
                        Log.d(TAG, "current focus matches target");
                }
                else {
                    Log.d(TAG, "current focus matches neither source nor target");
                }

                List<Float> focus_distances = setupFocusBracketingDistances(focus_bracketing_source_distance, focus_bracketing_target_distance, focus_bracketing_n_images);
                if( focus_bracketing_add_infinity ) {
                    focus_distances.add(0.0f);
                }
                for(int i=0;i<focus_distances.size();i++) {
                    stillBuilder.set(CaptureRequest.LENS_FOCUS_DISTANCE, focus_distances.get(i));
                    if( i == focus_distances.size()-1 ) {
                        stillBuilder.setTag(RequestTagType.CAPTURE); // set capture tag for last only
                    }
                    requests.add( stillBuilder.build() );
                }
            }

			/*
			// testing:
			requests.add( stillBuilder.build() );
			requests.add( stillBuilder.build() );
			requests.add( stillBuilder.build() );
			requests.add( stillBuilder.build() );
			if( MyDebug.LOG )
				Log.d(TAG, "set RequestTag.CAPTURE for last burst request");
			stillBuilder.setTag(RequestTag.CAPTURE);
			requests.add( stillBuilder.build() );
			*/

            n_burst = requests.size();
            burst_single_request = true;
            if( MyDebug.LOG )
                Log.d(TAG, "n_burst: " + n_burst);

            if( !previewIsVideoMode ) {
                captureSession.stopRepeating(); // see note under takePictureAfterPrecapture()
            }

            if( picture_cb != null ) {
                if( MyDebug.LOG )
                    Log.d(TAG, "call onStarted() in callback");
                picture_cb.onStarted();
            }

            modified_from_camera_settings = true;
            if( use_expo_fast_burst && burst_type == BurstType.BURSTTYPE_EXPO ) { // alway use slow burst for focus bracketing
                if( MyDebug.LOG )
                    Log.d(TAG, "using fast burst");
                int sequenceId = captureSession.captureBurst(requests, previewCaptureCallback, handler);
                if( MyDebug.LOG )
                    Log.d(TAG, "sequenceId: " + sequenceId);
            }
            else {
                if( MyDebug.LOG )
                    Log.d(TAG, "using slow burst");
                slow_burst_capture_requests = requests;
                slow_burst_start_ms = System.currentTimeMillis();
                captureSession.capture(requests.get(0), previewCaptureCallback, handler);
            }

            if( sounds_enabled ) // play shutter sound asap, otherwise user has the illusion of being slow to take photos
                media_action_sound.play(MediaActionSound.SHUTTER_CLICK);
        }
        catch(CameraAccessException e) {
            if( MyDebug.LOG ) {
                Log.e(TAG, "failed to take picture expo burst");
                Log.e(TAG, "reason: " + e.getReason());
                Log.e(TAG, "message: " + e.getMessage());
            }
            e.printStackTrace();
            picture_cb = null;
            if( take_picture_error_cb != null ) {
                take_picture_error_cb.onError();
                take_picture_error_cb = null;
            }
        }
    }

    private void takePictureBurst() {
        if (MyDebug.LOG)
            Log.d(TAG, "takePictureBurst");
        if (burst_type != BurstType.BURSTTYPE_NORMAL) {
            Log.e(TAG, "takePictureBurstBracketing called but unexpected burst_type: " + burst_type);
        }
        if (camera == null || captureSession == null) {
            if (MyDebug.LOG)
                Log.d(TAG, "no camera or capture session");
            return;
        }
        try {
            if (MyDebug.LOG) {
                Log.d(TAG, "imageReader: " + imageReader.toString());
                Log.d(TAG, "imageReader surface: " + imageReader.getSurface().toString());
            }

            CaptureRequest.Builder stillBuilder = camera.createCaptureRequest(previewIsVideoMode ? CameraDevice.TEMPLATE_VIDEO_SNAPSHOT : CameraDevice.TEMPLATE_STILL_CAPTURE);
            stillBuilder.set(CaptureRequest.CONTROL_CAPTURE_INTENT, CaptureRequest.CONTROL_CAPTURE_INTENT_STILL_CAPTURE);
            // n.b., don't set RequestTag.CAPTURE here - we only do it for the last of the burst captures (see below)
            camera_settings.setupBuilder(stillBuilder, true);
            if (use_fake_precapture_mode && fake_precapture_torch_performed) {
                if (MyDebug.LOG)
                    Log.d(TAG, "setting torch for capture");
                if (!camera_settings.has_iso)
                    stillBuilder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON);
                stillBuilder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_TORCH);
                test_fake_flash_photo++;
            }

            if (burst_for_noise_reduction) {
                if (MyDebug.LOG)
                    Log.d(TAG, "optimise settings for burst_for_noise_reduction");
                stillBuilder.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_OFF);
                stillBuilder.set(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE, CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_OFF);
                stillBuilder.set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_OFF);
            }

            clearPending();
            // shouldn't add preview surface as a target - see note in takePictureAfterPrecapture()
            stillBuilder.addTarget(imageReader.getSurface());
            // don't add target imageReaderRaw, as Raw not supported for burst
            picture_cb = null; // raw not supported for burst

            if (use_fake_precapture_mode && fake_precapture_torch_performed) {
                stillBuilder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_TORCH);
                test_fake_flash_photo++;
            }
            // else don't turn torch off, as user may be in torch on mode

            if (burst_for_noise_reduction) {
                if (MyDebug.LOG)
                    Log.d(TAG, "choose n_burst for burst_for_noise_reduction");
                n_burst = 4;

                if (capture_result_has_iso) {
                    // For Nexus 6, max reported ISO is 1196, so the limit for dark scenes shouldn't be more than this
                    // Nokia 8's max reported ISO is 1551
                    // Note that OnePlus 3T has max reported ISO of 800, but this is a device bug
                    if (capture_result_iso>=1100) {
                        if (MyDebug.LOG)
                            Log.d(TAG, "optimise for dark scene");
                        n_burst = 8;
                        boolean is_oneplus = Build.MANUFACTURER.toLowerCase(Locale.US).contains("oneplus");
                        // OnePlus 3T at least has bug where manual ISO can't be set to about 800, so dark images end up too dark -
                        // so no point enabling this code, which is meant to brighten the scene, not make it darker!
                        if (!camera_settings.has_iso && !is_oneplus) {
                            long exposure_time = 1000000000L / 10;
                            if (MyDebug.LOG)
                                Log.d(TAG, "also set 100ms exposure time");
                            modified_from_camera_settings = true;
                            setManualExposureTime(stillBuilder, exposure_time);
                        }
                    } else if (capture_result_has_exposure_time) {
                        //final double full_exposure_time_scale = 0.5;
                        final double full_exposure_time_scale = Math.pow(2.0, -0.5);
                        final long fixed_exposure_time = 1000000000L / 60; // we only scale the exposure time at all if it's less than this value
                        final long scaled_exposure_time = 1000000000L / 120; // we only scale the exposure time by the full_exposure_time_scale if the exposure time is less than this value
                        long exposure_time = capture_result_exposure_time;
                        if (exposure_time<=fixed_exposure_time) {
                            if (MyDebug.LOG)
                                Log.d(TAG, "optimise for bright scene");
                            //n_burst = 2;
                            n_burst = 3;
                            if (!camera_settings.has_iso) {
                                double exposure_time_scale = getScaleForExposureTime(exposure_time, fixed_exposure_time, scaled_exposure_time, full_exposure_time_scale);
                                exposure_time *= exposure_time_scale;
                                if (MyDebug.LOG) {
                                    Log.d(TAG, "reduce exposure shutter speed further, was: " + exposure_time);
                                    Log.d(TAG, "exposure_time_scale: " + exposure_time_scale);
                                }
                                modified_from_camera_settings = true;
                                setManualExposureTime(stillBuilder, exposure_time);
                            }
                        }
                    }
                }
            } else {
                if (MyDebug.LOG)
                    Log.d(TAG, "user requested n_burst");
                n_burst = burst_requested_n_images;
            }
            burst_single_request = false;

            if (MyDebug.LOG)
                Log.d(TAG, "n_burst: " + n_burst);

            final CaptureRequest request = stillBuilder.build();
//            stillBuilder.setTag(RequestTag.CAPTURE);
            final CaptureRequest last_request = stillBuilder.build();

            if (!previewIsVideoMode) {
                captureSession.stopRepeating(); // see note under takePictureAfterPrecapture()
            }

            if (picture_cb != null) {
                if (MyDebug.LOG)
                    Log.d(TAG, "call onStarted() in callback");
                picture_cb.onStarted();
            }

            final boolean use_burst = true;
            //final boolean use_burst = false;

            if (use_burst) {
                List<CaptureRequest> requests = new ArrayList<>();
                for (int i = 0; i<n_burst - 1; i++)
                    requests.add(request);
                requests.add(last_request);
                if (MyDebug.LOG)
                    Log.d(TAG, "captureBurst");
                int sequenceId = captureSession.captureBurst(requests, previewCaptureCallback, handler);
                if (MyDebug.LOG)
                    Log.d(TAG, "sequenceId: " + sequenceId);
            } else {
                final int burst_delay = 100;
                new Runnable() {
                    int n_remaining = n_burst;

                    @Override
                    public void run() {
                        if (MyDebug.LOG) {
                            Log.d(TAG, "takePictureBurst runnable");
                            if (n_remaining == 1) {
                                Log.d(TAG, "    is last request");
                            }
                        }
                        try {
                            captureSession.capture(n_remaining == 1 ? last_request : request, previewCaptureCallback, handler);
                            n_remaining--;
                            if (MyDebug.LOG)
                                Log.d(TAG, "takePictureBurst n_remaining: " + n_remaining);
                            if (n_remaining>0) {
                                handler.postDelayed(this, burst_delay);
                            }
                        } catch (CameraAccessException e) {
                            if (MyDebug.LOG) {
                                Log.e(TAG, "failed to take picture burst");
                                Log.e(TAG, "reason: " + e.getReason());
                                Log.e(TAG, "message: " + e.getMessage());
                            }
                            e.printStackTrace();
                            picture_cb = null;
                            if (take_picture_error_cb != null) {
                                take_picture_error_cb.onError();
                                take_picture_error_cb = null;
                            }
                        }
                    }
                }.run();
            }

            if (sounds_enabled) // play shutter sound asap, otherwise user has the illusion of being slow to take photos
                media_action_sound.play(MediaActionSound.SHUTTER_CLICK);
        } catch (CameraAccessException e) {
            if (MyDebug.LOG) {
                Log.e(TAG, "failed to take picture burst");
                Log.e(TAG, "reason: " + e.getReason());
                Log.e(TAG, "message: " + e.getMessage());
            }
            e.printStackTrace();
            picture_cb = null;
            if (take_picture_error_cb != null) {
                take_picture_error_cb.onError();
                take_picture_error_cb = null;
            }
        }
    }

    private void setManualExposureTime(CaptureRequest.Builder stillBuilder, long exposure_time) {
        if (MyDebug.LOG)
            Log.d(TAG, "setManualExposureTime: " + exposure_time);
        Range<Long> exposure_time_range = characteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE); // may be null on some devices
        Range<Integer> iso_range = characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE); // may be null on some devices
        if (exposure_time_range != null && iso_range != null) {
            long min_exposure_time = exposure_time_range.getLower();
            long max_exposure_time = exposure_time_range.getUpper();
            if (exposure_time<min_exposure_time)
                exposure_time = min_exposure_time;
            if (exposure_time>max_exposure_time)
                exposure_time = max_exposure_time;
            if (MyDebug.LOG) {
                Log.d(TAG, "exposure_time: " + exposure_time);
            }
            stillBuilder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF);
            {
                // set ISO
                int iso = 800;
                if (capture_result_has_iso)
                    iso = capture_result_iso;
                // see https://sourceforge.net/p/opencamera/tickets/321/ - some devices may have auto ISO that's
                // outside of the allowed manual iso range!
                iso = Math.max(iso, iso_range.getLower());
                iso = Math.min(iso, iso_range.getUpper());
                stillBuilder.set(CaptureRequest.SENSOR_SENSITIVITY, iso);
            }
            if (capture_result_has_frame_duration)
                stillBuilder.set(CaptureRequest.SENSOR_FRAME_DURATION, capture_result_frame_duration);
            else
                stillBuilder.set(CaptureRequest.SENSOR_FRAME_DURATION, 1000000000L / 30);
            stillBuilder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exposure_time);
        }
    }

    static public double getScaleForExposureTime(long exposure_time, long fixed_exposure_time, long scaled_exposure_time, double full_exposure_time_scale) {
        if (MyDebug.LOG)
            Log.d(TAG, "getScaleForExposureTime");
        double alpha = (exposure_time - fixed_exposure_time) / (double) (scaled_exposure_time - fixed_exposure_time);
        if (alpha<0.0)
            alpha = 0.0;
        else if (alpha>1.0)
            alpha = 1.0;
        if (MyDebug.LOG) {
            Log.d(TAG, "exposure_time: " + exposure_time);
            Log.d(TAG, "alpha: " + alpha);
        }
        // alpha==0 means exposure_time_scale==1; alpha==1 means exposure_time_scale==full_exposure_time_scale
        return (1.0 - alpha) + alpha * full_exposure_time_scale;
    }

    private void runPrecapture() {
        CameraController.ErrorCallback errorCallback;
        Log.d(TAG, "runPrecapture");
        BLOCK_FOR_EXTENSIONS();
        long currentTimeMillis = System.currentTimeMillis();
        synchronized (this.background_camera_lock) {
            if (this.use_fake_precapture_mode) {
                Log.e(TAG, "shouldn't be doing standard precapture when use_fake_precapture_mode is true!");
            } else if (this.burst_type != CameraController.BurstType.BURSTTYPE_NONE) {
                Log.e(TAG, "shouldn't be doing precapture for burst - should be using fake precapture!");
            }
            errorCallback = null;
            try {
                CaptureRequest.Builder createCaptureRequest = this.camera.createCaptureRequest(1);
                this.camera_settings.setupBuilder(createCaptureRequest, false);
                createCaptureRequest.set(CaptureRequest.CONTROL_AF_TRIGGER, 0);
                createCaptureRequest.set(CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER, 0);
                createCaptureRequest.addTarget(getPreviewSurface());
                this.state = 2;
                this.precapture_state_change_time_ms = System.currentTimeMillis();
                Log.d(TAG, "capture with precaptureBuilder");
                this.captureSession.capture(createCaptureRequest.build(), this.previewCaptureCallback, this.handler);
                this.captureSession.setRepeatingRequest(createCaptureRequest.build(), this.previewCaptureCallback, this.handler);
                createCaptureRequest.set(CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER, 1);
                this.captureSession.capture(createCaptureRequest.build(), this.previewCaptureCallback, this.handler);
            } catch (CameraAccessException e) {
                Log.e(TAG, "failed to precapture");
                Log.e(TAG, "reason: " + e.getReason());
                Log.e(TAG, "message: " + e.getMessage());
                e.printStackTrace();
                this.jpeg_todo = false;
                this.raw_todo = false;
                this.picture_cb = null;
                errorCallback = this.take_picture_error_cb;
            }
        }
        if (errorCallback != null) {
            errorCallback.onError();
        }
        Log.d(TAG, "runPrecapture() took: " + (System.currentTimeMillis() - currentTimeMillis));
    }

    private void runFakePrecapture() {
        boolean z;
        CameraController.ErrorCallback errorCallback;
        Log.d(TAG, "runFakePrecapture");
        BLOCK_FOR_EXTENSIONS();
        long currentTimeMillis = System.currentTimeMillis();
        synchronized (this.background_camera_lock) {
            String str = this.camera_settings.flash_value;
            char c = 65535;
            z = true;
            switch (str.hashCode()) {
                case -1524012984:
                    if (str.equals("flash_frontscreen_auto")) {
                        c = 2;
                        break;
                    }
                    break;
                case -1195303778:
                    if (str.equals("flash_auto")) {
                        c = 0;
                        break;
                    }
                    break;
                case -10523976:
                    if (str.equals("flash_frontscreen_on")) {
                        c = 3;
                        break;
                    }
                    break;
                case 1625570446:
                    if (str.equals("flash_on")) {
                        c = 1;
                        break;
                    }
                    break;
            }
            if (c == 0 || c == 1) {
                Log.d(TAG, "turn on torch");
                if (!this.camera_settings.has_iso) {
                    this.previewBuilder.set(CaptureRequest.CONTROL_AE_MODE, 1);
                }
                this.previewBuilder.set(CaptureRequest.FLASH_MODE, 2);
                this.test_fake_flash_precapture++;
                this.fake_precapture_torch_performed = true;
            } else if (c != 2 && c != 3) {
                Log.e(TAG, "runFakePrecapture called with unexpected flash value: " + this.camera_settings.flash_value);
            }
            z = false;
        }
        if (z) {
            if (this.picture_cb != null) {
                Log.d(TAG, "request screen turn on for frontscreen flash");
                this.picture_cb.onFrontScreenTurnOn();
            } else {
                Log.e(TAG, "can't request screen turn on for frontscreen flash, as no picture_cb");
            }
        }
        synchronized (this.background_camera_lock) {
            this.state = 4;
            this.precapture_state_change_time_ms = System.currentTimeMillis();
            errorCallback = null;
            this.fake_precapture_turn_on_torch_id = null;
            try {
                CaptureRequest build = this.previewBuilder.build();
                if (this.fake_precapture_torch_performed) {
                    this.fake_precapture_turn_on_torch_id = build;
                    Log.d(TAG, "fake_precapture_turn_on_torch_id: " + build);
                }
                setRepeatingRequest(build);
            } catch (CameraAccessException e) {
                Log.e(TAG, "failed to start fake precapture");
                Log.e(TAG, "reason: " + e.getReason());
                Log.e(TAG, "message: " + e.getMessage());
                e.printStackTrace();
                this.jpeg_todo = false;
                this.raw_todo = false;
                this.picture_cb = null;
                errorCallback = this.take_picture_error_cb;
            }
        }
        if (errorCallback != null) {
            errorCallback.onError();
        }
        Log.d(TAG, "runFakePrecapture() took: " + (System.currentTimeMillis() - currentTimeMillis));
    }

    private boolean fireAutoFlashFrontScreen() {
        return this.capture_result_has_iso && this.capture_result_iso>=750;
    }

    private boolean fireAutoFlash() {
        Log.d(TAG, "fireAutoFlash");
        long currentTimeMillis = System.currentTimeMillis();
        if (this.fake_precapture_use_flash_time_ms != -1) {
            Log.d(TAG, "fake_precapture_use_flash_time_ms: " + this.fake_precapture_use_flash_time_ms);
            Log.d(TAG, "time_now: " + currentTimeMillis);
            Log.d(TAG, "time since last flash auto decision: " + (currentTimeMillis - this.fake_precapture_use_flash_time_ms));
        }
        long j = this.fake_precapture_use_flash_time_ms;
        if (j != -1 && currentTimeMillis - j<precapture_done_timeout_c) {
            Log.d(TAG, "use recent decision: " + this.fake_precapture_use_flash);
            this.fake_precapture_use_flash_time_ms = currentTimeMillis;
            return this.fake_precapture_use_flash;
        }
        String str = this.camera_settings.flash_value;
        str.hashCode();
        if (str.equals("flash_frontscreen_auto")) {
            this.fake_precapture_use_flash = fireAutoFlashFrontScreen();
            Log.d(TAG, "    ISO was: " + this.capture_result_iso);
        } else if (str.equals("flash_auto")) {
            this.fake_precapture_use_flash = this.is_flash_required;
        } else {
            this.fake_precapture_use_flash = false;
        }
        Log.d(TAG, "fake_precapture_use_flash: " + this.fake_precapture_use_flash);
        boolean z = this.fake_precapture_use_flash;
        if (z) {
            this.fake_precapture_use_flash_time_ms = currentTimeMillis;
        } else {
            this.fake_precapture_use_flash_time_ms = -1L;
        }
        return z;
    }

    @Override
    public void takePicture(CameraController.PictureCallback cameraController$PictureCallback0, CameraController.ErrorCallback cameraController$ErrorCallback0) {
        int v4;
        Log.d("CameraController2", "takePicture");
        long v = System.currentTimeMillis();
        Object object0 = this.background_camera_lock;
        synchronized(object0) {
            if(this.camera != null && (this.hasCaptureSession())) {
                this.picture_cb = cameraController$PictureCallback0;
                int v1 = 1;
                this.jpeg_todo = true;
                int v2 = 0;
                this.raw_todo = this.imageReaderRaw != null;
                this.done_all_captures = false;
                this.take_picture_error_cb = cameraController$ErrorCallback0;
                this.fake_precapture_torch_performed = false;
                if(this.sessionType == SessionType.SESSIONTYPE_NORMAL && !this.ready_for_capture) {
                    Log.e("CameraController2", "takePicture: not ready for capture!");
                }

                Log.d("CameraController2", "current flash value: " + this.camera_settings.flash_value);
                Log.d("CameraController2", "use_fake_precapture_mode: " + this.use_fake_precapture_mode);
                if(this.sessionType != SessionType.SESSIONTYPE_EXTENSION && (!this.camera_settings.flash_value.equals("flash_off") && !this.camera_settings.flash_value.equals("flash_torch") && !this.camera_settings.flash_value.equals("flash_frontscreen_torch"))) {
                    if(this.use_fake_precapture_mode) {
                        int v3 = (this.camera_settings.flash_value.equals("flash_auto")) || (this.camera_settings.flash_value.equals("flash_frontscreen_auto")) ? 1 : 0;
                        Integer integer0 = (Integer)this.previewBuilder.get(CaptureRequest.FLASH_MODE);
                        Log.d("CameraController2", "flash_mode: " + integer0);
                        if(v3 != 0 && !this.fireAutoFlash()) {
                            Log.d("CameraController2", "fake precapture flash auto: seems bright enough to not need flash");
                            v4 = 0;
                        }

                        if(integer0 != null && ((int)integer0) == 2) {
                            Log.d("CameraController2", "fake precapture flash: torch already on (presumably from autofocus)");
                            this.fake_precapture_torch_performed = true;
                            ++this.test_fake_flash_precapture;
                            this.state = 5;
                            this.precapture_state_change_time_ms = System.currentTimeMillis();
                            v1 = 0;
                            v4 = 0;
                        }

                        v1 = 0;
                        v4 = 1;
//                        label_173:
                        if(v1 != 0) {
                            this.takePictureAfterPrecapture();
                        }
                        else if(v4 != 0) {
                            this.runFakePrecapture();
                        }
                        else if(v2 != 0) {
                            this.runPrecapture();
                        }
                    }

                    int v5 = this.capture_result_ae == null || ((int)this.capture_result_ae) == 2 ? 0 : 1;
                    if((this.camera_settings.flash_value.equals("flash_auto")) && v5 == 0) {
                        Log.d("flash_auto", "flash auto, but we don\'t need flash");
                        v4 = 0;
                    }

                    v1 = 0;
                    v4 = 0;
                    v2 = 1;
                }
                else {
                    v4 = 0;
                }

                Log.d("CameraController2", "takePicture() took: " + (System.currentTimeMillis() - v));
                return;
            }

            Log.d("CameraController2", "no camera or capture session");
            cameraController$ErrorCallback0.onError();
            return;
        }
    }

    @Override
    public void setDisplayOrientation(int i) {
        Log.d(TAG, "setDisplayOrientation not supported by this API");
        throw new RuntimeException();
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getDisplayOrientation() {
        Log.d(TAG, "getDisplayOrientation not supported by this API");
        throw new RuntimeException();
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getCameraOrientation() {
        return this.characteristics_sensor_orientation;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.Facing getFacing() {
        return this.characteristics_facing;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void initVideoRecorderPrePrepare(MediaRecorder mediaRecorder) {
        BLOCK_FOR_EXTENSIONS();
        playSound(2);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void initVideoRecorderPostPrepare(MediaRecorder mediaRecorder, boolean z) throws CameraControllerException {
        Log.d(TAG, "initVideoRecorderPostPrepare");
        if (this.camera == null) {
            Log.e(TAG, "no camera");
            throw new CameraControllerException();
        }
        BLOCK_FOR_EXTENSIONS();
        try {
            Log.d(TAG, "obtain video_recorder surface");
            this.previewBuilder = this.camera.createCaptureRequest(3);
            Log.d(TAG, "done");
            this.previewIsVideoMode = true;
            this.previewBuilder.set(CaptureRequest.CONTROL_CAPTURE_INTENT, 3);
            this.camera_settings.setupBuilder(this.previewBuilder, false);
            createCaptureSession(mediaRecorder, z);
        } catch (CameraAccessException e) {
            Log.e(TAG, "failed to create capture request for video");
            Log.e(TAG, "reason: " + e.getReason());
            Log.e(TAG, "message: " + e.getMessage());
            e.printStackTrace();
            throw new CameraControllerException();
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void reconnect() throws CameraControllerException {
        Log.d(TAG, "reconnect");
        playSound(3);
        createPreviewRequest();
        createCaptureSession(null, false);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean captureResultIsAEScanning() {
        return this.capture_result_is_ae_scanning;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean needsFlash() {
        return this.is_flash_required;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean needsFrontScreenFlash() {
        return this.camera_settings.flash_value.equals("flash_frontscreen_on") || (this.camera_settings.flash_value.equals("flash_frontscreen_auto") && fireAutoFlashFrontScreen());
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean captureResultHasWhiteBalanceTemperature() {
        return this.capture_result_has_white_balance_rggb;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int captureResultWhiteBalanceTemperature() {
        return convertRggbVectorToTemperature(this.capture_result_white_balance_rggb);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean captureResultHasIso() {
        return this.capture_result_has_iso;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int captureResultIso() {
        return this.capture_result_iso;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean captureResultHasExposureTime() {
        return this.capture_result_has_exposure_time;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public long captureResultExposureTime() {
        return this.capture_result_exposure_time;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean captureResultHasFrameDuration() {
        return this.capture_result_has_frame_duration;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public long captureResultFrameDuration() {
        return this.capture_result_frame_duration;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean captureResultHasAperture() {
        return this.capture_result_has_aperture;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public float captureResultAperture() {
        return this.capture_result_aperture;
    }


    private class MyExtensionCaptureCallback extends CameraExtensionSession.ExtensionCaptureCallback {
        private MyExtensionCaptureCallback() {
        }

        @Override // android.hardware.camera2.CameraExtensionSession.ExtensionCaptureCallback
        public void onCaptureStarted(CameraExtensionSession cameraExtensionSession, CaptureRequest captureRequest, long j) {
            if (CameraController2.this.previewCaptureCallback.getRequestTagType(captureRequest) == RequestTagType.CAPTURE) {
                Log.d(CameraController2.TAG, "onCaptureStarted: capture");
            } else if (CameraController2.this.previewCaptureCallback.getRequestTagType(captureRequest) == RequestTagType.CAPTURE_BURST_IN_PROGRESS) {
                Log.d(CameraController2.TAG, "onCaptureStarted: capture burst in progress");
            }
            if (!CameraController2.this.has_received_frame) {
                CameraController2.this.has_received_frame = true;
                Log.d(CameraController2.TAG, "has_received_frame now set to true");
            }
            super.onCaptureStarted(cameraExtensionSession, captureRequest, j);
        }

        @Override // android.hardware.camera2.CameraExtensionSession.ExtensionCaptureCallback
        public void onCaptureProcessStarted(CameraExtensionSession cameraExtensionSession, CaptureRequest captureRequest) {
            super.onCaptureProcessStarted(cameraExtensionSession, captureRequest);
        }

        @Override // android.hardware.camera2.CameraExtensionSession.ExtensionCaptureCallback
        public void onCaptureFailed(CameraExtensionSession cameraExtensionSession, CaptureRequest captureRequest) {
            Log.e(CameraController2.TAG, "onCaptureFailed");
            super.onCaptureFailed(cameraExtensionSession, captureRequest);
        }

        @Override // android.hardware.camera2.CameraExtensionSession.ExtensionCaptureCallback
        public void onCaptureSequenceCompleted(CameraExtensionSession cameraExtensionSession, int i) {
            Log.d(CameraController2.TAG, "onCaptureSequenceCompleted");
            Log.d(CameraController2.TAG, "sequenceId: " + i);
            CameraController2 cameraController2 = CameraController2.this;
            cameraController2.test_capture_results = cameraController2.test_capture_results + 1;
            CameraController2.this.modified_from_camera_settings = false;
            CameraController2.this.previewCaptureCallback.callCheckImagesCompleted();
            super.onCaptureSequenceCompleted(cameraExtensionSession, i);
        }

        @Override // android.hardware.camera2.CameraExtensionSession.ExtensionCaptureCallback
        public void onCaptureSequenceAborted(CameraExtensionSession cameraExtensionSession, int i) {
            Log.d(CameraController2.TAG, "onCaptureSequenceAborted");
            Log.d(CameraController2.TAG, "sequenceId: " + i);
            super.onCaptureSequenceAborted(cameraExtensionSession, i);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes3.dex */
    public class MyCaptureCallback extends CameraCaptureSession.CaptureCallback {
        private int last_af_state;
        private long last_process_frame_number;

        private MyCaptureCallback() {
            this.last_process_frame_number = 0L;
            this.last_af_state = -1;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public RequestTagType getRequestTagType(CaptureRequest captureRequest) {
            Object tag = captureRequest.getTag();
            if (tag == null) {
                return null;
            }
            return ((RequestTagObject) tag).getType();
        }

        @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
        public void onCaptureBufferLost(CameraCaptureSession cameraCaptureSession, CaptureRequest captureRequest, Surface surface, long j) {
            Log.d(CameraController2.TAG, "onCaptureBufferLost: " + j);
            super.onCaptureBufferLost(cameraCaptureSession, captureRequest, surface, j);
        }

        @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
        public void onCaptureFailed(CameraCaptureSession cameraCaptureSession, CaptureRequest captureRequest, CaptureFailure captureFailure) {
            Log.e(CameraController2.TAG, "onCaptureFailed: " + captureFailure);
            Log.d(CameraController2.TAG, "reason: " + captureFailure.getReason());
            Log.d(CameraController2.TAG, "was image captured?: " + captureFailure.wasImageCaptured());
            Log.d(CameraController2.TAG, "sequenceId: " + captureFailure.getSequenceId());
            super.onCaptureFailed(cameraCaptureSession, captureRequest, captureFailure);
        }

        @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
        public void onCaptureSequenceAborted(CameraCaptureSession cameraCaptureSession, int i) {
            Log.d(CameraController2.TAG, "onCaptureSequenceAborted");
            Log.d(CameraController2.TAG, "sequenceId: " + i);
            super.onCaptureSequenceAborted(cameraCaptureSession, i);
        }

        @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
        public void onCaptureSequenceCompleted(CameraCaptureSession cameraCaptureSession, int i, long j) {
            Log.d(CameraController2.TAG, "onCaptureSequenceCompleted");
            Log.d(CameraController2.TAG, "sequenceId: " + i);
            Log.d(CameraController2.TAG, "frameNumber: " + j);
            super.onCaptureSequenceCompleted(cameraCaptureSession, i, j);
        }

        @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
        public void onCaptureStarted(CameraCaptureSession cameraCaptureSession, CaptureRequest captureRequest, long j, long j2) {
            if (getRequestTagType(captureRequest) == RequestTagType.CAPTURE) {
                Log.d(CameraController2.TAG, "onCaptureStarted: capture");
                Log.d(CameraController2.TAG, "frameNumber: " + j2);
                Log.d(CameraController2.TAG, "exposure time: " + captureRequest.get(CaptureRequest.SENSOR_EXPOSURE_TIME));
            } else if (getRequestTagType(captureRequest) == RequestTagType.CAPTURE_BURST_IN_PROGRESS) {
                Log.d(CameraController2.TAG, "onCaptureStarted: capture burst in progress");
                Log.d(CameraController2.TAG, "frameNumber: " + j2);
                Log.d(CameraController2.TAG, "exposure time: " + captureRequest.get(CaptureRequest.SENSOR_EXPOSURE_TIME));
            }
            super.onCaptureStarted(cameraCaptureSession, captureRequest, j, j2);
        }

        @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
        public void onCaptureProgressed(CameraCaptureSession cameraCaptureSession, CaptureRequest captureRequest, CaptureResult captureResult) {
            super.onCaptureProgressed(cameraCaptureSession, captureRequest, captureResult);
        }

        @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
        public void onCaptureCompleted(CameraCaptureSession cameraCaptureSession, CaptureRequest captureRequest, TotalCaptureResult totalCaptureResult) {
            if (getRequestTagType(captureRequest) == RequestTagType.CAPTURE) {
                Log.d(CameraController2.TAG, "onCaptureCompleted: capture");
                Log.d(CameraController2.TAG, "sequenceId: " + totalCaptureResult.getSequenceId());
                Log.d(CameraController2.TAG, "frameNumber: " + totalCaptureResult.getFrameNumber());
                Log.d(CameraController2.TAG, "exposure time: " + captureRequest.get(CaptureRequest.SENSOR_EXPOSURE_TIME));
                Log.d(CameraController2.TAG, "frame duration: " + captureRequest.get(CaptureRequest.SENSOR_FRAME_DURATION));
            } else if (getRequestTagType(captureRequest) == RequestTagType.CAPTURE_BURST_IN_PROGRESS) {
                Log.d(CameraController2.TAG, "onCaptureCompleted: capture burst in progress");
                Log.d(CameraController2.TAG, "sequenceId: " + totalCaptureResult.getSequenceId());
                Log.d(CameraController2.TAG, "frameNumber: " + totalCaptureResult.getFrameNumber());
                Log.d(CameraController2.TAG, "exposure time: " + captureRequest.get(CaptureRequest.SENSOR_EXPOSURE_TIME));
                Log.d(CameraController2.TAG, "frame duration: " + captureRequest.get(CaptureRequest.SENSOR_FRAME_DURATION));
            }
            process(captureRequest, totalCaptureResult);
            processCompleted(captureRequest, totalCaptureResult);
            super.onCaptureCompleted(cameraCaptureSession, captureRequest, totalCaptureResult);
        }

        private void updateCachedAECaptureStatus(CaptureResult captureResult) {
            Integer num = (Integer) captureResult.get(CaptureResult.CONTROL_AE_STATE);
            Integer num2 = (Integer) captureResult.get(CaptureResult.FLASH_MODE);
            if (!CameraController2.this.use_fake_precapture_mode || ((!CameraController2.this.fake_precapture_torch_focus_performed && !CameraController2.this.fake_precapture_torch_performed) || num2 == null || num2.intValue() != 2)) {
                if (num == null) {
                    CameraController2.this.capture_result_ae = null;
                    CameraController2.this.is_flash_required = false;
                } else if (!num.equals(CameraController2.this.capture_result_ae)) {
                    Log.d(CameraController2.TAG, "CONTROL_AE_STATE changed from " + CameraController2.this.capture_result_ae + " to " + num);
                    CameraController2.this.capture_result_ae = num;
                    if (CameraController2.this.capture_result_ae.intValue() == 4 && !CameraController2.this.is_flash_required) {
                        CameraController2.this.is_flash_required = true;
                        Log.d(CameraController2.TAG, "flash now required");
                    } else if (CameraController2.this.capture_result_ae.intValue() == 2 && CameraController2.this.is_flash_required) {
                        CameraController2.this.is_flash_required = false;
                        Log.d(CameraController2.TAG, "flash no longer required");
                    }
                }
            }
            if (num != null && num.intValue() == 1) {
                CameraController2.this.capture_result_is_ae_scanning = true;
            } else {
                CameraController2.this.capture_result_is_ae_scanning = false;
            }
        }

        private void handleStateChange(CaptureRequest captureRequest, CaptureResult captureResult) {
            Integer num;
            Integer num2 = (Integer) captureResult.get(CaptureResult.CONTROL_AF_STATE);
            Integer num3 = (Integer) captureResult.get(CaptureResult.CONTROL_AE_STATE);
            boolean z = true;
            boolean z2 = CameraController2.this.autofocus_time_ms != -1 && System.currentTimeMillis()>CameraController2.this.autofocus_time_ms + CameraController2.autofocus_timeout_c;
            if (z2) {
                Log.d(CameraController2.TAG, "autofocus timeout!");
            }
            if (num2 != null && num2.intValue() == 1 && !z2) {
                CameraController2.this.ready_for_capture = false;
            } else {
                CameraController2.this.ready_for_capture = true;
                if (CameraController2.this.autofocus_cb != null && CameraController2.this.focusIsContinuous() && (num = (Integer) CameraController2.this.previewBuilder.get(CaptureRequest.CONTROL_AF_MODE)) != null && num.intValue() == 4) {
                    Log.d(CameraController2.TAG, "call autofocus callback, as continuous mode and not focusing: " + num2);
                    boolean z3 = num2 != null && (num2.intValue() == 4 || num2.intValue() == 2);
                    if (z3) {
                        Log.d(CameraController2.TAG, "autofocus success");
                    } else {
                        Log.d(CameraController2.TAG, "autofocus failed");
                    }
                    if (num2 == null) {
                        Log.e(CameraController2.TAG, "continuous focus mode but af_state is null");
                    } else {
                        Log.d(CameraController2.TAG, "af_state: " + num2);
                    }
                    if (num2 == null) {
                        CameraController2.this.test_af_state_null_focus++;
                    }
                    CameraController2.this.autofocus_cb.onAutoFocus(z3);
                    CameraController2.this.autofocus_cb = null;
                    CameraController2.this.autofocus_time_ms = -1L;
                    CameraController2.this.capture_follows_autofocus_hint = false;
                }
            }
            if (CameraController2.this.fake_precapture_turn_on_torch_id != null && CameraController2.this.fake_precapture_turn_on_torch_id == captureRequest) {
                Log.d(CameraController2.TAG, "torch turned on for fake precapture");
                CameraController2.this.fake_precapture_turn_on_torch_id = null;
            }
            if (CameraController2.this.state == 0) {
                return;
            }
            if (CameraController2.this.state == 1) {
                if (num2 == null) {
                    Log.e(CameraController2.TAG, "waiting for autofocus but af_state is null");
                    CameraController2.this.test_af_state_null_focus++;
                    CameraController2.this.state = 0;
                    CameraController2.this.precapture_state_change_time_ms = -1L;
                    if (CameraController2.this.autofocus_cb != null) {
                        CameraController2.this.autofocus_cb.onAutoFocus(false);
                        CameraController2.this.autofocus_cb = null;
                    }
                    CameraController2.this.autofocus_time_ms = -1L;
                    CameraController2.this.capture_follows_autofocus_hint = false;
                } else if (num2.intValue() != this.last_af_state || z2) {
                    if (z2 || num2.intValue() == 4 || num2.intValue() == 5) {
                        if (num2.intValue() != 4 && num2.intValue() != 2) {
                            z = false;
                        }
                        if (z) {
                            Log.d(CameraController2.TAG, "onCaptureCompleted: autofocus success");
                        } else {
                            Log.d(CameraController2.TAG, "onCaptureCompleted: autofocus failed");
                        }
                        Log.d(CameraController2.TAG, "af_state: " + num2);
                        CameraController2.this.state = 0;
                        CameraController2.this.precapture_state_change_time_ms = -1L;
                        if (CameraController2.this.use_fake_precapture_mode && CameraController2.this.fake_precapture_torch_focus_performed) {
                            CameraController2.this.fake_precapture_torch_focus_performed = false;
                            if (!CameraController2.this.capture_follows_autofocus_hint) {
                                Log.d(CameraController2.TAG, "turn off torch after focus (fake precapture code)");
                                String str = CameraController2.this.camera_settings.flash_value;
                                CameraController2.this.camera_settings.flash_value = "flash_off";
                                CameraController2.this.camera_settings.setAEMode(CameraController2.this.previewBuilder, false);
                                try {
                                    CameraController2.this.capture();
                                } catch (CameraAccessException e) {
                                    Log.e(CameraController2.TAG, "failed to do capture to turn off torch after autofocus");
                                    Log.e(CameraController2.TAG, "reason: " + e.getReason());
                                    Log.e(CameraController2.TAG, "message: " + e.getMessage());
                                    e.printStackTrace();
                                }
                                CameraController2.this.camera_settings.flash_value = str;
                                CameraController2.this.camera_settings.setAEMode(CameraController2.this.previewBuilder, false);
                                try {
                                    CameraController2.this.setRepeatingRequest();
                                } catch (CameraAccessException e2) {
                                    Log.e(CameraController2.TAG, "failed to set repeating request to turn off torch after autofocus");
                                    Log.e(CameraController2.TAG, "reason: " + e2.getReason());
                                    Log.e(CameraController2.TAG, "message: " + e2.getMessage());
                                    e2.printStackTrace();
                                }
                            } else {
                                Log.d(CameraController2.TAG, "torch was enabled for autofocus, leave it on for capture (fake precapture code)");
                            }
                        }
                        if (CameraController2.this.autofocus_cb != null) {
                            CameraController2.this.autofocus_cb.onAutoFocus(z);
                            CameraController2.this.autofocus_cb = null;
                        }
                        CameraController2.this.autofocus_time_ms = -1L;
                        CameraController2.this.capture_follows_autofocus_hint = false;
                    }
                }
            } else if (CameraController2.this.state == 2) {
                Log.d(CameraController2.TAG, "waiting for precapture start...");
                if (num3 != null) {
                    Log.d(CameraController2.TAG, "CONTROL_AE_STATE = " + num3);
                } else {
                    Log.d(CameraController2.TAG, "CONTROL_AE_STATE is null");
                }
                if (num3 == null || num3.intValue() == 5) {
                    Log.d(CameraController2.TAG, "precapture started after: " + (System.currentTimeMillis() - CameraController2.this.precapture_state_change_time_ms));
                    CameraController2.this.state = 3;
                    CameraController2.this.precapture_state_change_time_ms = System.currentTimeMillis();
                } else if (CameraController2.this.precapture_state_change_time_ms == -1 || System.currentTimeMillis() - CameraController2.this.precapture_state_change_time_ms<=CameraController2.precapture_start_timeout_c) {
                } else {
                    Log.e(CameraController2.TAG, "precapture start timeout");
                    CameraController2.this.count_precapture_timeout++;
                    CameraController2.this.state = 3;
                    CameraController2.this.precapture_state_change_time_ms = System.currentTimeMillis();
                }
            } else if (CameraController2.this.state == 3) {
                Log.d(CameraController2.TAG, "waiting for precapture done...");
                if (num3 != null) {
                    Log.d(CameraController2.TAG, "CONTROL_AE_STATE = " + num3);
                } else {
                    Log.d(CameraController2.TAG, "CONTROL_AE_STATE is null");
                }
                if (num3 == null || num3.intValue() != 5) {
                    Log.d(CameraController2.TAG, "precapture completed after: " + (System.currentTimeMillis() - CameraController2.this.precapture_state_change_time_ms));
                    CameraController2.this.state = 0;
                    CameraController2.this.precapture_state_change_time_ms = -1L;
                    CameraController2.this.takePictureAfterPrecapture();
                } else if (CameraController2.this.precapture_state_change_time_ms == -1 || System.currentTimeMillis() - CameraController2.this.precapture_state_change_time_ms<=CameraController2.precapture_done_timeout_c) {
                } else {
                    Log.e(CameraController2.TAG, "precapture done timeout");
                    CameraController2.this.count_precapture_timeout++;
                    CameraController2.this.state = 0;
                    CameraController2.this.precapture_state_change_time_ms = -1L;
                    CameraController2.this.takePictureAfterPrecapture();
                }
            } else if (CameraController2.this.state == 4) {
                Log.d(CameraController2.TAG, "waiting for fake precapture start...");
                if (num3 != null) {
                    Log.d(CameraController2.TAG, "CONTROL_AE_STATE = " + num3);
                } else {
                    Log.d(CameraController2.TAG, "CONTROL_AE_STATE is null");
                }
                if (CameraController2.this.fake_precapture_turn_on_torch_id != null) {
                    Log.d(CameraController2.TAG, "still waiting for torch to come on for fake precapture");
                }
                if (CameraController2.this.fake_precapture_turn_on_torch_id == null && (num3 == null || num3.intValue() == 1)) {
                    Log.d(CameraController2.TAG, "fake precapture started after: " + (System.currentTimeMillis() - CameraController2.this.precapture_state_change_time_ms));
                    CameraController2.this.state = 5;
                    CameraController2.this.precapture_state_change_time_ms = System.currentTimeMillis();
                } else if (CameraController2.this.fake_precapture_turn_on_torch_id == null && CameraController2.this.camera_settings.has_iso && CameraController2.this.precapture_state_change_time_ms != -1 && System.currentTimeMillis() - CameraController2.this.precapture_state_change_time_ms>100) {
                    Log.d(CameraController2.TAG, "fake precapture started after: " + (System.currentTimeMillis() - CameraController2.this.precapture_state_change_time_ms));
                    CameraController2.this.state = 5;
                    CameraController2.this.precapture_state_change_time_ms = System.currentTimeMillis();
                } else if (CameraController2.this.precapture_state_change_time_ms == -1 || System.currentTimeMillis() - CameraController2.this.precapture_state_change_time_ms<=CameraController2.precapture_start_timeout_c) {
                } else {
                    Log.e(CameraController2.TAG, "fake precapture start timeout");
                    CameraController2.this.count_precapture_timeout++;
                    CameraController2.this.state = 5;
                    CameraController2.this.precapture_state_change_time_ms = System.currentTimeMillis();
                    CameraController2.this.fake_precapture_turn_on_torch_id = null;
                }
            } else if (CameraController2.this.state == 5) {
                Log.d(CameraController2.TAG, "waiting for fake precapture done...");
                if (num3 != null) {
                    Log.d(CameraController2.TAG, "CONTROL_AE_STATE = " + num3);
                } else {
                    Log.d(CameraController2.TAG, "CONTROL_AE_STATE is null");
                }
                Log.d(CameraController2.TAG, "ready_for_capture? " + CameraController2.this.ready_for_capture);
                if (CameraController2.this.ready_for_capture && (num3 == null || num3.intValue() != 1)) {
                    Log.d(CameraController2.TAG, "fake precapture completed after: " + (System.currentTimeMillis() - CameraController2.this.precapture_state_change_time_ms));
                    CameraController2.this.state = 0;
                    CameraController2.this.precapture_state_change_time_ms = -1L;
                    CameraController2.this.takePictureAfterPrecapture();
                } else if (CameraController2.this.precapture_state_change_time_ms == -1 || System.currentTimeMillis() - CameraController2.this.precapture_state_change_time_ms<=CameraController2.precapture_done_timeout_c) {
                } else {
                    Log.e(CameraController2.TAG, "fake precapture done timeout");
                    CameraController2.this.count_precapture_timeout++;
                    CameraController2.this.state = 0;
                    CameraController2.this.precapture_state_change_time_ms = -1L;
                    CameraController2.this.takePictureAfterPrecapture();
                }
            }
        }

        private void handleContinuousFocusMove(CaptureResult captureResult) {
            Integer num = (Integer) captureResult.get(CaptureResult.CONTROL_AF_STATE);
            if (num != null && num.intValue() == 1 && num.intValue() != this.last_af_state) {
                if (CameraController2.this.continuous_focus_move_callback != null) {
                    CameraController2.this.continuous_focus_move_callback.onContinuousFocusMove(true);
                }
            } else if (num == null || this.last_af_state != 1 || num.intValue() == this.last_af_state || CameraController2.this.continuous_focus_move_callback == null) {
            } else {
                CameraController2.this.continuous_focus_move_callback.onContinuousFocusMove(false);
            }
        }

        private void process(CaptureRequest captureRequest, CaptureResult captureResult) {
            if (captureResult.getFrameNumber()<this.last_process_frame_number) {
                return;
            }
            this.last_process_frame_number = captureResult.getFrameNumber();
            updateCachedAECaptureStatus(captureResult);
            handleStateChange(captureRequest, captureResult);
            handleContinuousFocusMove(captureResult);
            Integer num = (Integer) captureResult.get(CaptureResult.CONTROL_AF_STATE);
            if (num == null || num.intValue() == this.last_af_state) {
                return;
            }
            this.last_af_state = num.intValue();
        }

        private void updateCachedCaptureResult(CaptureResult captureResult) {
            if (!CameraController2.this.modified_from_camera_settings) {
                if (captureResult.get(CaptureResult.SENSOR_SENSITIVITY) != null) {
                    CameraController2.this.capture_result_has_iso = true;
                    CameraController2.this.capture_result_iso = ((Integer) captureResult.get(CaptureResult.SENSOR_SENSITIVITY)).intValue();
                } else {
                    CameraController2.this.capture_result_has_iso = false;
                }
            }
            if (!CameraController2.this.modified_from_camera_settings) {
                if (captureResult.get(CaptureResult.SENSOR_EXPOSURE_TIME) != null) {
                    CameraController2.this.capture_result_has_exposure_time = true;
                    CameraController2.this.capture_result_exposure_time = ((Long) captureResult.get(CaptureResult.SENSOR_EXPOSURE_TIME)).longValue();
                    if (CameraController2.this.camera_settings.has_iso && CameraController2.this.camera_settings.exposure_time>Math.min((long) CameraController2.max_preview_exposure_time_c, 83333333L)) {
                        CameraController2 cameraController2 = CameraController2.this;
                        cameraController2.capture_result_exposure_time = cameraController2.camera_settings.exposure_time;
                    }
                    if (CameraController2.this.capture_result_exposure_time<=0) {
                        CameraController2.this.capture_result_has_exposure_time = false;
                    }
                } else {
                    CameraController2.this.capture_result_has_exposure_time = false;
                }
            }
            if (!CameraController2.this.modified_from_camera_settings) {
                if (captureResult.get(CaptureResult.SENSOR_FRAME_DURATION) != null) {
                    CameraController2.this.capture_result_has_frame_duration = true;
                    CameraController2.this.capture_result_frame_duration = ((Long) captureResult.get(CaptureResult.SENSOR_FRAME_DURATION)).longValue();
                } else {
                    CameraController2.this.capture_result_has_frame_duration = false;
                }
            }
            if (!CameraController2.this.modified_from_camera_settings) {
                if (captureResult.get(CaptureResult.LENS_APERTURE) != null) {
                    CameraController2.this.capture_result_has_aperture = true;
                    CameraController2.this.capture_result_aperture = ((Float) captureResult.get(CaptureResult.LENS_APERTURE)).floatValue();
                } else {
                    CameraController2.this.capture_result_has_aperture = false;
                }
            }
            RggbChannelVector rggbChannelVector = (RggbChannelVector) captureResult.get(CaptureResult.COLOR_CORRECTION_GAINS);
            if (CameraController2.this.modified_from_camera_settings || rggbChannelVector == null) {
                return;
            }
            CameraController2.this.capture_result_has_white_balance_rggb = true;
            CameraController2.this.capture_result_white_balance_rggb = rggbChannelVector;
        }

        private void handleFaceDetection(CaptureResult captureResult) {
            Integer num;
            if (CameraController2.this.face_detection_listener == null || CameraController2.this.previewBuilder == null || (num = (Integer) CameraController2.this.previewBuilder.get(CaptureRequest.STATISTICS_FACE_DETECT_MODE)) == null || num.intValue() == 0) {
                return;
            }
            Rect viewableRect = CameraController2.this.getViewableRect();
            android.hardware.camera2.params.Face[] faceArr = (android.hardware.camera2.params.Face[]) captureResult.get(CaptureResult.STATISTICS_FACES);
            if (faceArr != null) {
                if (faceArr.length == 0 && CameraController2.this.last_faces_detected == 0) {
                    return;
                }
                CameraController2.this.last_faces_detected = faceArr.length;
                CameraController.Face[] faceArr2 = new CameraController.Face[faceArr.length];
                for (int i = 0; i<faceArr.length; i++) {
                    faceArr2[i] = CameraController2.this.convertFromCameraFace(viewableRect, faceArr[i]);
                }
                CameraController2.this.face_detection_listener.onFaceDetection(faceArr2);
            }
        }

        private void handleRawCaptureResult(CaptureResult captureResult) {
            if (CameraController2.this.test_wait_capture_result) {
                try {
                    Log.d(CameraController2.TAG, "test_wait_capture_result: waiting...");
                    Thread.sleep(500L);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if (CameraController2.this.onRawImageAvailableListener != null) {
                CameraController2.this.onRawImageAvailableListener.setCaptureResult(captureResult);
            }
        }

        private void handleCaptureBurstInProgress(CaptureResult captureResult) {
            Log.d(CameraController2.TAG, "handleCaptureBurstInProgress");
            handleRawCaptureResult(captureResult);
        }

        private void handleCaptureCompleted(CaptureResult captureResult) {
            Log.d(CameraController2.TAG, "capture request completed");
            CameraController2.this.test_capture_results++;
            CameraController2.this.modified_from_camera_settings = false;
            handleRawCaptureResult(captureResult);
            if (CameraController2.this.previewBuilder != null) {
                CameraController2.this.previewBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, 2);
                Log.d(CameraController2.TAG, "### reset ae mode");
                String str = CameraController2.this.camera_settings.flash_value;
                if (CameraController2.this.use_fake_precapture_mode && CameraController2.this.fake_precapture_torch_performed) {
                    CameraController2.this.camera_settings.flash_value = "flash_off";
                }
                CameraController2.this.camera_settings.setAEMode(CameraController2.this.previewBuilder, false);
                try {
                    CameraController2.this.capture();
                } catch (CameraAccessException e) {
                    Log.e(CameraController2.TAG, "failed to cancel autofocus after taking photo");
                    Log.e(CameraController2.TAG, "reason: " + e.getReason());
                    Log.e(CameraController2.TAG, "message: " + e.getMessage());
                    e.printStackTrace();
                }
                if (CameraController2.this.use_fake_precapture_mode && CameraController2.this.fake_precapture_torch_performed) {
                    CameraController2.this.camera_settings.flash_value = str;
                    CameraController2.this.camera_settings.setAEMode(CameraController2.this.previewBuilder, false);
                }
                CameraController2.this.previewBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, 0);
                try {
                    CameraController2.this.setRepeatingRequest();
                } catch (CameraAccessException e2) {
                    Log.e(CameraController2.TAG, "failed to start preview after taking photo");
                    Log.e(CameraController2.TAG, "reason: " + e2.getReason());
                    Log.e(CameraController2.TAG, "message: " + e2.getMessage());
                    e2.printStackTrace();
                    CameraController2.this.preview_error_cb.onError();
                }
            }
            CameraController2.this.fake_precapture_torch_performed = false;
            if (CameraController2.this.burst_type == CameraController.BurstType.BURSTTYPE_FOCUS && CameraController2.this.previewBuilder != null) {
                Log.d(CameraController2.TAG, "focus bracketing complete, reset manual focus");
                CameraController2.this.camera_settings.setFocusDistance(CameraController2.this.previewBuilder);
                try {
                    CameraController2.this.setRepeatingRequest();
                } catch (CameraAccessException e3) {
                    Log.e(CameraController2.TAG, "failed to set focus distance");
                    Log.e(CameraController2.TAG, "reason: " + e3.getReason());
                    Log.e(CameraController2.TAG, "message: " + e3.getMessage());
                    e3.printStackTrace();
                }
            }
            callCheckImagesCompleted();
        }

        public void callCheckImagesCompleted() {
            ((Activity) CameraController2.this.context).runOnUiThread(new Runnable() {
                @Override // java.lang.Runnable
                public void run() {
                    Log.d(CameraController2.TAG, "processCompleted UI thread call checkImagesCompleted()");
                    synchronized (CameraController2.this.background_camera_lock) {
                        CameraController2.this.done_all_captures = true;
                        Log.d(CameraController2.TAG, "done all captures");
                    }
                    CameraController2.this.checkImagesCompleted();
                }
            });
        }

        private void processCompleted(CaptureRequest captureRequest, CaptureResult captureResult) {
            if (!CameraController2.this.has_received_frame) {
                CameraController2.this.has_received_frame = true;
                Log.d(CameraController2.TAG, "has_received_frame now set to true");
            }
            updateCachedCaptureResult(captureResult);
            handleFaceDetection(captureResult);
            if (CameraController2.this.push_repeating_request_when_torch_off && CameraController2.this.push_repeating_request_when_torch_off_id == captureRequest && CameraController2.this.previewBuilder != null) {
                Log.d(CameraController2.TAG, "received push_repeating_request_when_torch_off");
                Integer num = (Integer) captureResult.get(CaptureResult.FLASH_STATE);
                if (num != null) {
                    Log.d(CameraController2.TAG, "flash_state: " + num);
                } else {
                    Log.d(CameraController2.TAG, "flash_state is null");
                }
                if (num != null && num.intValue() == 2) {
                    CameraController2.this.push_repeating_request_when_torch_off = false;
                    CameraController2.this.push_repeating_request_when_torch_off_id = null;
                    try {
                        CameraController2.this.setRepeatingRequest();
                    } catch (CameraAccessException e) {
                        Log.e(CameraController2.TAG, "failed to set flash [from torch/flash off hack]");
                        Log.e(CameraController2.TAG, "reason: " + e.getReason());
                        Log.e(CameraController2.TAG, "message: " + e.getMessage());
                        e.printStackTrace();
                    }
                }
            }
            RequestTagType requestTagType = getRequestTagType(captureRequest);
            if (requestTagType == RequestTagType.CAPTURE) {
                handleCaptureCompleted(captureResult);
            } else if (requestTagType == RequestTagType.CAPTURE_BURST_IN_PROGRESS) {
                handleCaptureBurstInProgress(captureResult);
            }
        }
    }
}
