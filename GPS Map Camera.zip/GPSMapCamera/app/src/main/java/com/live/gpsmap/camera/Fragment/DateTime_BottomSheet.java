package com.live.gpsmap.camera.Fragment;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.live.gpsmap.camera.Adapter.DateTimeAdapter;
import com.live.gpsmap.camera.Database.DateTimeDB;
import com.live.gpsmap.camera.Interface.OnRecyclerItemClickListener;
import com.live.gpsmap.camera.Model.DateTime;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Default;
import com.live.gpsmap.camera.Utils.Helper.SingleClickListener;
import com.live.gpsmap.camera.Utils.HorizontalCustomDate;
import com.live.gpsmap.camera.Utils.SP;

import java.util.ArrayList;

public class DateTime_BottomSheet extends BottomSheetDialogFragment {
    public static final String TAG = "DateTime_BottomSheet";
    public static ArrayList<DateTime> dateTimes_horizontal = new ArrayList<>();
    public static String selected_pos = Default.DEFAULT_DATE_FORMAT;
    DateTimeFragment.OnDateSelectedListener callBack;
    Context context;
    DateTimeDB dateTimeDB;
    LinearLayout lin_adddatetime;
    private DateTimeAdapter mAdapter;
    String[] mDateArray;
    private SP mSP;
    RecyclerView rv_maptype;
    TextView txt_title;

    /* loaded from: classes.dex */
    interface OnDateSelectedListener {
        void onDateSelected();
    }

    public void setOnDate_SelectedListener(DateTimeFragment.OnDateSelectedListener onDateSelectedListener) {
        this.callBack = onDateSelectedListener;
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.dateTimeDB = new DateTimeDB(getActivity());
        dateTimes_horizontal.clear();
        dateTimes_horizontal = this.dateTimeDB.getHorozontalNormal();
    }

    @SuppressLint("RestrictedApi")
    @Override
    public void setupDialog(Dialog dialog, int i) {
        super.setupDialog(dialog, i);
        View inflate = View.inflate(getContext(), R.layout.datetime_bottom_sheet_fragment, null);
        this.rv_maptype = (RecyclerView) inflate.findViewById(R.id.rv_maptype);
        this.txt_title = (TextView) inflate.findViewById(R.id.txt_title);
        this.lin_adddatetime = (LinearLayout) inflate.findViewById(R.id.lin_adddatetime);
        this.context = inflate.getContext();
        dialog.setContentView(inflate);
        init();
    }

    private void init() {
        this.mSP = new SP(getContext());
        this.txt_title.setText(getString(R.string.date_and_time));
        this.mDateArray = getActivity().getResources().getStringArray(R.array.datetime_format_arry);
        setAdapter();
        this.lin_adddatetime.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View view) {
                DateTime_BottomSheet.this.getActivity().startActivity(new Intent(DateTime_BottomSheet.this.getActivity(), HorizontalCustomDate.class));
            }
        });
    }

    public void refrecedata() {
        dateTimes_horizontal.clear();
        ArrayList<DateTime> horozontalNormal = this.dateTimeDB.getHorozontalNormal();
        dateTimes_horizontal = horozontalNormal;
        this.mAdapter.refAdapter(horozontalNormal, selected_pos);
    }

    private void setAdapter() {
        this.rv_maptype.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        this.rv_maptype.setHasFixedSize(true);
        DateTimeAdapter dateTimeAdapter = new DateTimeAdapter(getContext(), dateTimes_horizontal, new OnRecyclerItemClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.DateTime_BottomSheet.2
            @Override // com.gpsmapcamera.geotagginglocationonphoto.interfaces.OnRecyclerItemClickListener
            public void OnClick_(int i, View view) {
                DateTime_BottomSheet.this.mSP.setString(DateTime_BottomSheet.this.getContext(), "date_format_temp", DateTime_BottomSheet.dateTimes_horizontal.get(i).getDate_format());
                new Handler().postDelayed(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.DateTime_BottomSheet.2.1
                    @Override // java.lang.Runnable
                    public void run() {
                        if (DateTime_BottomSheet.this.mAdapter == null || DateTime_BottomSheet.this.callBack == null) {
                            return;
                        }
                        DateTime_BottomSheet.this.callBack.onDateSelected();
                        DateTime_BottomSheet.this.dismiss();
                    }
                }, 50L);
            }

            @Override // com.gpsmapcamera.geotagginglocationonphoto.interfaces.OnRecyclerItemClickListener
            public void OnLongClick_(final int i, View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(DateTime_BottomSheet.this.getActivity());
                builder.setTitle(DateTime_BottomSheet.this.getString(R.string.delete));
                builder.setMessage(DateTime_BottomSheet.this.getString(R.string.delete_date_msg));
                builder.setPositiveButton(DateTime_BottomSheet.this.getString(R.string.yes), new DialogInterface.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.DateTime_BottomSheet.2.2
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        DateTime_BottomSheet.this.dateTimeDB.deleteDate(DateTime_BottomSheet.dateTimes_horizontal.get(i).getDate_id());
                        DateTime_BottomSheet.this.refrecedata();
                        dialogInterface.dismiss();
                    }
                });
                builder.setNegativeButton(DateTime_BottomSheet.this.getString(R.string.no), new DialogInterface.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.DateTime_BottomSheet.2.3
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        dialogInterface.dismiss();
                    }
                });
                builder.create().show();
            }
        });
        this.mAdapter = dateTimeAdapter;
        this.rv_maptype.setAdapter(dateTimeAdapter);
    }

    @Override // androidx.fragment.app.DialogFragment, android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        super.onDismiss(dialogInterface);
        DateTimeFragment.OnDateSelectedListener onDateSelectedListener = this.callBack;
        if (onDateSelectedListener != null) {
            onDateSelectedListener.onDateSelected();
        }
    }
}