package com.live.gpsmap.camera.Fragment;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Helper.SingleClickListener;
import com.live.gpsmap.camera.Utils.SP;

/* loaded from: classes2.dex */
public class Numbering_BottomSheet extends BottomSheetDialogFragment {
    public static final String TAG = "Numbering_BottomSheet";
    Button btn_reset;
    EditText et_prefixtext;
    EditText et_sequencenumber;
    EditText et_suffixtext;
    ImageView img_decrement;
    ImageView img_increment;
    boolean isIncrement;
    LinearLayout lin_decrement;
    LinearLayout lin_increment;
    SP mSP;
    OnSelectNumbering onSelectNumbering;
    String prefix;
    String suffix;
    int temptype = 0;
    int sequence = 1;

    /* loaded from: classes.dex */
    public interface OnSelectNumbering {
        void Onselect();
    }

    public Numbering_BottomSheet() {
        String str = "";
        this.suffix = str;
        this.prefix = str;
    }

    public void setOnSelectNumbering(OnSelectNumbering onSelectNumbering) {
        this.onSelectNumbering = onSelectNumbering;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_numbering_, viewGroup, false);
        this.lin_increment = (LinearLayout) inflate.findViewById(R.id.ll_increment);
        this.lin_decrement = (LinearLayout) inflate.findViewById(R.id.ll_decrement);
        this.img_increment = (ImageView) inflate.findViewById(R.id.chk_increment);
        this.img_decrement = (ImageView) inflate.findViewById(R.id.chk_decrement);
        this.et_prefixtext = (EditText) inflate.findViewById(R.id.et_prefix);
        this.et_suffixtext = (EditText) inflate.findViewById(R.id.et_suffix);
        this.et_sequencenumber = (EditText) inflate.findViewById(R.id.et_sequence);
        this.btn_reset = (Button) inflate.findViewById(R.id.btn_reset);
        this.mSP = new SP(requireActivity());
        if (getArguments() != null) {
            this.temptype = getArguments().getInt("type", 0);
        }
        this.isIncrement = this.mSP.getBoolean(requireActivity(), "isincrement", true);
        this.sequence = this.mSP.getInteger(requireActivity(), "sequence value", 1);
        this.prefix = this.mSP.getString(requireActivity(), "prefix", "");
        this.suffix = this.mSP.getString(requireActivity(), "suffix", "");
        if (this.isIncrement) {
            this.img_increment.setImageResource(R.drawable.ic_select_btn);
            this.img_decrement.setImageResource(R.drawable.ic_uncheck_box_tple);
        } else {
            this.img_increment.setImageResource(R.drawable.ic_uncheck_box_tple);
            this.img_decrement.setImageResource(R.drawable.ic_select_btn);
        }
        this.et_prefixtext.setText(this.prefix.trim());
        this.et_suffixtext.setText(this.suffix.trim());
        this.et_sequencenumber.setText(String.valueOf(this.sequence).trim());
        onClickListener();
        return inflate;
    }

    private void onClickListener() {
        this.lin_increment.setOnClickListener(new SingleClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.Numbering_BottomSheet.1
            @Override // com.gpsmapcamera.geotagginglocationonphoto.helper.SingleClickListener
            public void performClick(View view) {
                Numbering_BottomSheet.this.isIncrement = true;
                Numbering_BottomSheet.this.img_increment.setImageResource(R.drawable.ic_select_btn);
                Numbering_BottomSheet.this.img_decrement.setImageResource(R.drawable.ic_uncheck_box_tple);
            }
        });
        this.lin_decrement.setOnClickListener(new SingleClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.Numbering_BottomSheet.2
            @Override // com.gpsmapcamera.geotagginglocationonphoto.helper.SingleClickListener
            public void performClick(View view) {
                Numbering_BottomSheet.this.isIncrement = false;
                Numbering_BottomSheet.this.img_increment.setImageResource(R.drawable.ic_uncheck_box_tple);
                Numbering_BottomSheet.this.img_decrement.setImageResource(R.drawable.ic_select_btn);
            }
        });
        this.btn_reset.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.Numbering_BottomSheet.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Numbering_BottomSheet.this.et_prefixtext.getText().clear();
                Numbering_BottomSheet.this.et_suffixtext.getText().clear();
                Numbering_BottomSheet.this.et_sequencenumber.setText("1");
                Numbering_BottomSheet.this.img_increment.setImageResource(R.drawable.ic_select_btn);
                Numbering_BottomSheet.this.img_decrement.setImageResource(R.drawable.ic_uncheck_box_tple);
                Numbering_BottomSheet.this.isIncrement = true;
                Numbering_BottomSheet.this.mSP.setBoolean(Numbering_BottomSheet.this.requireActivity(), "isincrement", Numbering_BottomSheet.this.isIncrement);
                Numbering_BottomSheet.this.mSP.setInteger(Numbering_BottomSheet.this.requireActivity(), "sequence value", 1);
                Numbering_BottomSheet.this.mSP.setString(Numbering_BottomSheet.this.requireActivity(), "prefix", "");
                Numbering_BottomSheet.this.mSP.setString(Numbering_BottomSheet.this.requireActivity(), "suffix", "");
            }
        });
    }

    @Override // androidx.fragment.app.DialogFragment, android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        super.onDismiss(dialogInterface);
        if (this.et_sequencenumber.getText().toString().isEmpty()) {
            this.et_sequencenumber.setText("1");
        }
        this.suffix = this.et_suffixtext.getText().toString().trim();
        this.prefix = this.et_prefixtext.getText().toString().trim();
        this.sequence = Integer.parseInt(this.et_sequencenumber.getText().toString().trim());
        this.mSP.setBoolean(requireActivity(), "isincrement", this.isIncrement);
        this.mSP.setInteger(requireActivity(), "sequence value", this.sequence);
        this.mSP.setString(requireActivity(), "prefix", this.prefix);
        this.mSP.setString(requireActivity(), "suffix", this.suffix);
        this.onSelectNumbering.Onselect();
        dismiss();
    }
}