package com.live.gpsmap.camera.Camera.fragments;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.live.gpsmap.camera.Camera.CameraMainActivity;
import com.live.gpsmap.camera.Camera.PreferenceKeys;
import com.live.gpsmap.camera.Camera.adapter.RatioAdapter;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraController;
import com.live.gpsmap.camera.Camera.onRecyclerClickListener;
import com.live.gpsmap.camera.Camera.preview.Preview;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.SP;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes3.dex */
public class RatioFragment extends Fragment implements View.OnClickListener {
    public RatioAdapter mRatioAdapter;
    RecyclerView mRatioRecycler;
    SP mSp;
    private RelativeLayout mToolbar_back;
    CameraMainActivity mainActivity;
    private TextView mtv_toolbar_title;
    private Preview preview;
    int ratioPos;
    List<CameraController.Size> ratio_entries = new ArrayList();
    String resolution_string;

    public RatioFragment(CameraMainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_ratio, viewGroup, false);
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.mToolbar_back = (RelativeLayout) view.findViewById(R.id.toolbar_back);
        TextView textView = (TextView) view.findViewById(R.id.tv_toolbar_title);
        this.mtv_toolbar_title = textView;
        textView.setText(getString(R.string.ratio));
        this.preview = this.mainActivity.getPreview();
        this.mSp = new SP(getActivity());
        this.ratioPos = getRatioPos();
        this.ratio_entries = this.preview.getSupportedPictureSizes(true);
        this.mRatioRecycler = (RecyclerView) view.findViewById(R.id.grid_recyclerView);
        setAdapter();
        loadAds(view);
        onCliks();
    }

    private void onCliks() {
        this.mToolbar_back.setOnClickListener(new View.OnClickListener() { // from class: com.live.gpsmap.camera.Camera.fragments.RatioFragment$$ExternalSyntheticLambda0
            @Override
            public final void onClick(View view) {
                RatioFragment.this.onClick(view);
            }
        });
    }

    private void loadAds(View view) {
//        new Admob().loadAdaptive_banner(getActivity(), (RelativeLayout) view.findViewById(R.id.rel_adaptive_banner), getString(R.string.GMC_Banner_Details));
    }

    private int getRatioPos() {
        return this.mSp.getInteger(getActivity(), PreferenceKeys.getRatioPos_PrefrenceKey(this.preview.getCameraId()), 0);
    }

    private void setAdapter() {
        this.mRatioRecycler.setLayoutManager(new LinearLayoutManager(getActivity(), RecyclerView.VERTICAL, false));
        RatioAdapter ratioAdapter = new RatioAdapter(getActivity(), this.preview, this.ratio_entries, new onRecyclerClickListener() { // from class: com.live.gpsmap.camera.Camera.fragments.RatioFragment.1
            @Override // com.live.gpsmap.camera.Camera.onRecyclerClickListener
            public void setOnItemClickListener(int i, View view) {
                if (i < 0 || i >= RatioFragment.this.ratio_entries.size()) {
                    return;
                }
                RatioFragment.this.ratioPos = i;
                CameraController.Size size = RatioFragment.this.ratio_entries.get(i);
                RatioFragment ratioFragment = RatioFragment.this;
                ratioFragment.resolution_string = size.width + " " + size.height;
            }
        });
        this.mRatioAdapter = ratioAdapter;
        this.mRatioRecycler.setAdapter(ratioAdapter);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.toolbar_back /* 2131362806 */:
                doBack();
                return;
            case R.id.toolbar_done /* 2131362807 */:
                saveData();
                return;
            default:
                return;
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        super.onAttach(context);
        if (getActivity() != null) {
            ((CameraMainActivity) getActivity()).hideUi();
            ((CameraMainActivity) getActivity()).lockDrawer();
            ((CameraMainActivity) getActivity()).setOnBackPressedListener(new CameraMainActivity.OnBackPressedListener() { // from class: com.live.gpsmap.camera.Camera.fragments.RatioFragment.2
                @Override // com.live.gpsmap.camera.Camera.MainActivity.OnBackPressedListener
                public void onBackPressed() {
                    RatioFragment.this.doBack();
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doBack() {
        if (isChanges()) {
            saveData();
        } else {
            getActivity().getSupportFragmentManager().popBackStack();
        }
    }

    private boolean isChanges() {
        return this.ratioPos != getRatioPos();
    }

    @Override // androidx.fragment.app.Fragment
    public void onDetach() {
        super.onDetach();
        if (getActivity() != null) {
            ((CameraMainActivity) getActivity()).showUI();
            ((CameraMainActivity) getActivity()).unLockDrawer();
            ((CameraMainActivity) getActivity()).updateForSettings("", true);
            ((CameraMainActivity) getActivity()).setOnBackPressedListener(null);
        }
    }

    private void confirmDialog() {
        if (isRemoving()) {
            return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(getString(R.string.discard_message));
        builder.setPositiveButton(getString(R.string.save), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                RatioFragment.this.saveData();
            }
        });
        builder.setNegativeButton(getString(R.string.discard), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                RatioFragment.this.getActivity().getSupportFragmentManager().popBackStack();
            }
        });
        builder.create().show();
    }


    public void saveData() {
        this.mSp.setString(getActivity(), PreferenceKeys.getResolutionPreferenceKey(this.preview.getCameraId()), this.resolution_string);
        this.mSp.setInteger(getActivity(), PreferenceKeys.getRatioPos_PrefrenceKey(this.preview.getCameraId()), this.ratioPos);
        getActivity().getSupportFragmentManager().popBackStack();
    }
}
