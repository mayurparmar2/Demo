package com.live.gpsmap.camera.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import com.live.gpsmap.camera.Interface.OnRecyclerItemClickListener;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Default;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.Utils.Util;

/* loaded from: classes2.dex */
public class FontstyleAdapter extends RecyclerView.Adapter<FontstyleAdapter.Holder> {
    String[] fontstyle;
    Context mContext;
    String[] mList;
    OnRecyclerItemClickListener mOnRecyclerItemClickListener;
    SP mSP;
    String selected_pos;

    public FontstyleAdapter(Context context, int i, String[] strArr, String[] strArr2, OnRecyclerItemClickListener onRecyclerItemClickListener) {
        this.mContext = context;
        SP sp = new SP(context);
        this.mSP = sp;
        this.mList = strArr;
        this.fontstyle = strArr2;
        this.mOnRecyclerItemClickListener = onRecyclerItemClickListener;
        if (i == 0) {
            this.selected_pos = sp.getString(this.mContext, SP.STAMP_FONT_STYLE, Default.DEFAULT_FONT_STYLE);
        } else {
            this.selected_pos = sp.getString(this.mContext, SP.STAMP_FONT_STYLE_CLASSIC, Default.DEFAULT_FONT_STYLE);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_date_time_adapter, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(Holder holder, int i) {
        holder.tv_dateFormat.setText(this.mList[i]);
        holder.tv_dateFormat.setTypeface(Util.getFontStyle(this.mContext, this.fontstyle[i]));
        if (this.fontstyle[i].equals(this.selected_pos)) {
            holder.img_selection.setVisibility(View.VISIBLE);
        } else {
            holder.img_selection.setVisibility(View.GONE);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.mList.length;
    }

    /* loaded from: classes2.dex */
    public class Holder extends RecyclerView.ViewHolder {
        LinearLayout date_main_lay;
        ImageView img_selection;
        TextView tv_dateFormat;

        public Holder(View view) {
            super(view);
            this.tv_dateFormat = (TextView) view.findViewById(R.id.tv_temp_name);
            this.date_main_lay = (LinearLayout) view.findViewById(R.id.dt_main_lay);
            this.img_selection = (ImageView) view.findViewById(R.id.img_selection);
            this.date_main_lay.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.adapter.FontstyleAdapter.Holder.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    if (Holder.this.getAdapterPosition() < 0 || FontstyleAdapter.this.mOnRecyclerItemClickListener == null) {
                        return;
                    }
                    FontstyleAdapter.this.mOnRecyclerItemClickListener.OnClick_(Holder.this.getAdapterPosition(), view2);
                }
            });
        }
    }
}