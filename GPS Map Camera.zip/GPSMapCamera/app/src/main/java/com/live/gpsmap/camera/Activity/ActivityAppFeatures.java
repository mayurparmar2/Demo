package com.live.gpsmap.camera.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.RelativeLayout;

import com.live.gpsmap.camera.Camera.CameraMainActivity;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.databinding.ActivityAppFeaturesBinding;

public class ActivityAppFeatures extends AppCompatActivity {
    ActivityAppFeaturesBinding binding;
    Handler handler;
    Runnable runnable_mapdata;
    Runnable runnable_camsetting;
    Runnable runnable_filefolder;
    SP mSP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAppFeaturesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        this.mSP = new SP(this);

        binding.btnnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ActivityAppFeatures.this, CameraMainActivity.class));
                finish();
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finishAffinity();
    }

    @Override
    public void onResume() {
        super.onResume();
        binding.btnnext.setVisibility(View.GONE);
        this.handler = new Handler();
        this.runnable_mapdata = new Runnable() {
            @Override
            public void run() {
                binding.mapdata.setVisibility(View.VISIBLE);
                handler.postDelayed(runnable_filefolder, 1500L);
            }
        };
        this.runnable_filefolder = new Runnable() {
            @Override
            public void run() {
                binding.filefolder.setVisibility(View.VISIBLE);
                handler.postDelayed(runnable_camsetting, 1500L);
            }
        };
        this.runnable_camsetting = new Runnable() {
            @Override
            public void run() {
               binding.camSetting.setVisibility(View.VISIBLE);
               binding.animationAppfeature.setVisibility(View.GONE);
               binding.btnnext.setVisibility(View.VISIBLE);
               binding.btnnext.setEnabled(true);
               binding.btnnext.setBackgroundColor(getResources().getColor(R.color._ffcc00));
                ((RelativeLayout.LayoutParams) binding.scrMain.getLayoutParams()).addRule(10, 1);
                mSP.setBoolean(ActivityAppFeatures.this, SP.INAPP_FEATURES, true);
            }
        };
        this.handler.postDelayed(this.runnable_mapdata, 1500L);
    }

}