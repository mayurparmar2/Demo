package com.live.gpsmap.camera.Camera;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.StatFs;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.renderscript.RenderScript;
import android.speech.tts.TextToSpeech;
import android.text.Html;
import android.text.util.Linkify;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Patterns;
import android.util.TypedValue;
import android.view.Display;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.OrientationEventListener;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.RotateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ZoomControls;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.exifinterface.media.ExifInterface;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchaseHistoryRecord;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.google.android.play.core.tasks.OnCompleteListener;
import com.google.android.play.core.tasks.Task;
import com.google.zxing.Result;
import com.gpfreetech.awesomescanner.ui.GpCodeScanner;
import com.gpfreetech.awesomescanner.ui.ScannerView;
import com.gpfreetech.awesomescanner.util.BarcodeUtils;
import com.gpfreetech.awesomescanner.util.DecodeCallback;
import com.gpsvideocamera.videotimestamp.VideoCameraActivity;
import com.gpsvideocamera.videotimestamp.Utils.HelperClass;
import com.live.gpsmap.camera.Activity.ActivityLanguageSelection;
import com.live.gpsmap.camera.Activity.ActivityPermission;
import com.live.gpsmap.camera.Activity.FileName_Activity;
import com.live.gpsmap.camera.Activity.FolderActivity;
import com.live.gpsmap.camera.Activity.InAppPurchaseActivity;
import com.live.gpsmap.camera.Activity.Location_Activity;
import com.live.gpsmap.camera.Activity.TempletSelectionActivity;
import com.live.gpsmap.camera.Adapter.Filter_Adapter;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraController;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraControllerManager;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraControllerManager2;
import com.live.gpsmap.camera.Camera.preview.Preview;
import com.live.gpsmap.camera.Camera.remotecontrol.BluetoothRemoteControl;
import com.live.gpsmap.camera.Camera.ui.MainUI;
import com.live.gpsmap.camera.Camera.ui.ManualSeekbars;
import com.live.gpsmap.camera.Camera.utils.EnvironmentSDCard;
import com.live.gpsmap.camera.Camera.utils.NetworkState;
import com.live.gpsmap.camera.Camera.utils.OpenLocationCode;
import com.live.gpsmap.camera.Compass.Compass;
import com.live.gpsmap.camera.Compass.RoundCorners;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Receiver.AlarmReceiver;
import com.live.gpsmap.camera.Utils.Default;
import com.live.gpsmap.camera.Utils.Helper.EGM96;
import com.live.gpsmap.camera.Utils.Helper.PurchaseHelper;
import com.live.gpsmap.camera.Utils.Helper.SearchHelper;
import com.live.gpsmap.camera.Utils.Helper.SingleClickListener;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.Utils.Util;
import com.live.gpsmap.camera.Widget.RoundImageView;
import com.live.gpsmap.camera.Widget.VerticalSeekBar;

import com.live.gpsmap.camera.databinding.DialogExitNativeBinding;

import com.live.gpsmap.camera.os_notifications.LinkDialogBtnClickListener;
import com.live.gpsmap.camera.os_notifications.MessageDialogBtnClickListener;
import com.live.gpsmap.camera.os_notifications.OSNotificationHelper;
import com.live.gpsmap.camera.os_notifications.OfferDialogBtnClickListener;
import com.live.gpsmap.camera.os_notifications.RateDialogBtnClickListener;
import com.live.gpsmap.camera.os_notifications.ShareDialogBtnClickListener;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@SuppressWarnings("All")
public class CameraMainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, OnMapReadyCallback, View.OnClickListener {

    private ActivityResultLauncher<Intent> resultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
        Log.e(TAG, " resultLauncher 111111111: " );

        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
            String resultData = result.getData().getStringExtra("result_key");
            if(resultData.equals("code_photo")){
                setModePhoto();
            }else if(resultData.equals("code_qrcode")){
                setModeQRCode();
            }
        }
    });

    private static final String ACTION_SHORTCUT_GALLERY = "net.sourceforge.opencamera.SHORTCUT_GALLERY";
    private static final String ACTION_SHORTCUT_SELFIE = "net.sourceforge.opencamera.SHORTCUT_SELFIE";
    private static final String ACTION_SHORTCUT_SETTINGS = "net.sourceforge.opencamera.SHORTCUT_SETTINGS";
    private static final int CHOOSE_GHOST_IMAGE_SAF_CODE = 43;
    private static final int CHOOSE_LOAD_SETTINGS_SAF_CODE = 44;
    private static final int CHOOSE_SAVE_FOLDER_SAF_CODE = 42;
    private static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = 5000;
    private static final long MAX_WAIT_TIME = 2000;
    private static boolean PROMOTION_BANNER = true;
    private static final String TAG = "com.gpsvideocamera.videotimestamp.CameraActivity";
    private static final long UPDATE_INTERVAL_IN_MILLISECONDS = 1000;
    public static final String URL_REGEX = "^((https?|ftp)://|(www|ftp)\\.)?[a-z0-9-]+(\\.[a-z0-9-]+)+([/?].*)?$";
    private static final double WGS84_A = 6378137.0d;
    private static final double WGS84_E2 = 0.00669437999014d;
    private static int activity_count;
    public static boolean test_force_supports_camera2;
    public static Window window;
    private boolean IS_ADS;
    private int Notes_color;
    private int accurcy_color;
    private int address_color;
    String address_line_1;
    AlertDialog alertNoIntentDialog;
    private int altitude_color;
    public MyApplicationInterface applicationInterface;
    private AudioListener audio_listener;
    private List<Integer> back_camera_ids;
    CardView back_layout;
    LinearLayout banner_data;
    RelativeLayout banner_native_layout;
    private BluetoothRemoteControl bluetoothRemoteControl;
    private boolean camera_in_background;
    String city;
    private Compass compass;
    String country;
    public float currentAzimuth;
    DecimalFormat dFormat;
    private int date_time_color;
    DialogExitNativeBinding exitDialogBinding;
    Animation fadeIn;
    Animation fadeOut;
    private List<Integer> front_camera_ids;
    FusedLocationProviderClient fusedLocationClient;
    public volatile Bitmap gallery_bitmap;
    private ValueAnimator gallery_save_anim;
    String[] grid_values;
    private boolean has_notification;
    public float heading;
    private int humidity_color;
    ImageView imgCompass;
    ImageView imgLogo;
    RoundCorners imgMap;
    ImageView imgWeather;
    private ImageView img_app_promasion;
    private ImageView img_grid;
    ImageView img_humidity_stamp;
    ImageView img_magnetic_field;
    private ImageView img_mirror;
    ImageView img_pressure_stamp;
    ImageView img_scenemode;
    private ImageView img_sound;
    ImageView img_tamplate;
    ImageView img_timer;
    ImageView img_watermark;
    ImageView img_whitebalance;
    ImageView img_wind_stamp;
    ImageView imgstamp_1;
    ImageView imgstamp_2;
    Intent intent;
    boolean isAccuracy;
    boolean isAddress;
    boolean isAltitude;
    boolean isCompass;
    boolean isCompassFound;
    boolean isDateTime;
    boolean isHumidity;
    boolean isIncrement;
    boolean isLatLng;
    boolean isLogo;
    boolean isMagneticField;
    boolean isMap;
    boolean isNotes;
    boolean isNumbering;
    boolean isPlusCode;
    boolean isPressure;
    boolean isPurchaseQueryPending;
    private boolean isSDCardPermission;
    private boolean isSDCardStorageEnabled;
    boolean isWeather;
    boolean isWind;
    private boolean is_multi_cam;
    public boolean is_test;
    private boolean is_watermark;
    boolean istimezone;
    private int large_heap_memory;
    private boolean last_continuous_fast_burst;
    private int lat_lng_color;
    private LinearLayout li_Multi_Camera;
    LinearLayout li_address;
    LinearLayout li_compass;
    LinearLayout li_logo;
    LinearLayout li_magnetic_field;
    LinearLayout li_main_stamp_lay;
    LinearLayout li_rightView;
    private LinearLayout li_sound;
    LinearLayout li_stamp;
    View li_stamp_lay;
    private LinearLayout li_switch_camera;
    private LinearLayout li_timer;
    LinearLayout li_weather;
    LinearLayout lin_bottom_wether;
    LinearLayout lin_humity_stamp;
    private LinearLayout lin_notification_badge;
    LinearLayout lin_pressure_stamp;
    LinearLayout lin_waterma;
    LinearLayout lin_waterma_2;
    LinearLayout lin_wind_stamp;
    LinearLayout ll_filterview;
    LinearLayout ll_scenemode;
    LinearLayout ll_whitebalance;
    private int mAccurcytype;
    private int mAltitudetype;
    private RelativeLayout mBottomScreenPannel;
    private GpCodeScanner mCodeScanner;
    private String mDateFormat;
    private DrawerLayout mDrawerLayout;
    private GoogleMap mGMap;
    Handler mHandler;
    private int mIconValue;
    RoundImageView mImgGalleryButton;
    ImageView mImgTakePhoto;
    private ImageView mImg_camera_settings;
    ImageView mImg_flash;
    private ImageView mImg_focus;
    private int mLatLngType;
    private LinearLayout mLi_app_setting;
    private LinearLayout mLi_camera_setting;
    private LinearLayout mLi_filename;
    private LinearLayout mLi_flash;
    private LinearLayout mLi_focus;
    private LinearLayout mLi_grid;
    private LinearLayout mLi_mirror;
    private LinearLayout mLi_premium;
    private LinearLayout mLi_ratio;
    LinearLayout mLinear_Flash;
    Location mLocation;
    private LocationCallback mLocationCallback;
    private LocationRequest mLocationRequest;
    private LocationSettingsRequest mLocationSettingsRequest;
    private SupportMapFragment mMapView;
    private NavigationView mNavigationView;
    private int mPressuretype;
    private RelativeLayout mRel_folder;
    private RelativeLayout mRel_gallery;
    private RelativeLayout mRel_gps;
    private RelativeLayout mRel_template;
    SP mSP;
    public int mScreenH;
    private int mScreenW;
    private Sensor mSensorAccelerometer;
    private SensorManager mSensorManager;
    private SettingsClient mSettingsClient;
    private LinearLayout mTopScreenPannel;
    private TextView mTvMirror;
    private TextView mTv_folder_name;
    RequestQueue mVolleyQueue;
    TypedArray mWeatherIcon;
    private int mWindtype;
    private MagneticSensor magneticSensor;
    private MainUI mainUI;
    private ManualSeekbars manualSeekbars;
    Bitmap mapBitmap;
    RelativeLayout mapfragmentlay;
    private float mfTemprature_value;
    int miLayHeight;
    private LinearLayout moLi_Header;
    private LinearLayout moLi_Settings;
    private RelativeLayout moMainLayout;
    private String msTemprature_type;
    private int numbering_color;
    OnBackPressedListener onBackPressedListener;
    private OrientationEventListener orientationEventListener;
    private List<Integer> other_camera_ids;
    private int plus_code_color;
    String pluscode_type;
    private String prefix;
    private int pressure_color;
    public Preview preview;
    FrameLayout previewlay;
    private String push_info_toast_text;
    String[] ratio;
    LinearLayout ratio_linear;
    RelativeLayout relAdsLay;
    RelativeLayout rel_camera_mode;
    RelativeLayout rel_premium;
    AlertDialog resultDialog;
    RelativeLayout rlCaptureBlink;
    RelativeLayout rl_btn_layout;
    RecyclerView rv_filterview;
    private boolean saf_dialog_from_preferences;
    private SaveLocationHistory save_location_history;
    private SaveLocationHistory save_location_history_saf;
    ScannerView scannerView;
    private boolean screen_is_locked;
    private String selectedLan;
    private int sequence;
    private SettingsManager settingsManager;
    SharedPreferences sharedPreferences;
    private SoundPoolManager soundPoolManager;
    private SpeechControl speechControl;
    String stamp_size;
    String state;
    String str_compass;
    String str_magnaticField;
    private String suffix;
    private boolean supports_auto_stabilise;
    private boolean supports_camera2;
    private boolean supports_force_video_4k;
    ImageView switchCameraButton;
    private SwitchCompat switchNav_SDCard;
    private SwitchCompat switchNav_Watermark;
    public volatile float test_angle;
    public volatile boolean test_have_angle;
    public volatile String test_last_saved_image;
    public volatile Uri test_last_saved_imageuri;
    public volatile boolean test_low_memory;
    public volatile String test_save_settings_file;
    private TextFormatter textFormatter;
    private TextToSpeech textToSpeech;
    private boolean textToSpeechSuccess;
    private int timezone;
    TextView tv_address;
    TextView tv_address_line_1;
    TextView tv_compass;
    TextView tv_magnetic_field;
    TextView tv_photo;
    TextView tv_qrcode;
    TextView tv_video;
    TextView tv_weather;
    private TextView tvsound;
    private TextView txt_focus;
    TextView txt_grid;
    TextView txt_humidity;
    TextView txt_pressure;
    private TextView txt_ration;
    private TextView txt_timer;
    TextView txt_watermark_1;
    TextView txt_watermark_2;
    TextView txt_wind;
    private int wind_color;
    final int REQUEST_CHECK_SETTINGS = 1;
    private final ToastBoxer changed_auto_stabilise_toast = new ToastBoxer();
    private final ToastBoxer audio_control_toast = new ToastBoxer();
    private final String CHANNEL_ID = "open_camera_channel";
    private final int image_saving_notification_id = 1;
    private final int upDateReq = 103;

    PurchaseHelper purchaseInAppHelper;
    List<PurchaseHistoryRecord> purchaseHistory;

    private final SensorEventListener accelerometerListener = new SensorEventListener() {
        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {
        }

        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            CameraMainActivity.this.preview.onAccelerometerSensorChanged(sensorEvent);
        }
    };
    public int degree = 0;
    public float bearing = 0.0f;
    public int flag_prermission = 0;
    int isPermission = 0;
    String mLocationType = Default.AUTOMATIC;
    double oldlate = 0.0d;
    double oldlong = 0.0d;
    List<CameraController.Size> ratio_entries = new ArrayList();
    Bitmap bitmap = null;
    long TIME = UPDATE_INTERVAL_IN_MILLISECONDS;
    boolean share_flag = true;
    boolean rate_appflag = true;
    boolean watermark_flag = true;
    AlertDialog alertSDPermissionDialog = null;
    AlertDialog alertHintDialog = null;
    boolean doubleBackToExitPressedOnce = false;
    private boolean app_is_paused = false;
    private float mWaterDensity = 1.0f;
    private int AppCount = 0;
    private final BroadcastReceiver cameraReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d(CameraMainActivity.TAG, "cameraReceiver.onReceive");
            CameraMainActivity.this.takePicture(false);
        }
    };
    private boolean compassFound = false;
    private Marker marker = null;
    private int isInternetDialog = 0;
    private boolean isTablet = false;
    private Handler immersive_timer_handler = null;
    private Runnable immersive_timer_runnable = null;
    AlertDialog exitDialog = null;
    boolean doExit = false;
    boolean scannerMode = false;
    ActivityResultLauncher<Intent> languageLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
        @Override
        public void onActivityResult(ActivityResult activityResult) {
            activityResult.getResultCode();
        }
    });
    Handler exposureHandler = new Handler();
    ExecutorService executor = Executors.newSingleThreadExecutor();
    Handler handler = new Handler(Looper.getMainLooper());
    Animation.AnimationListener fadeOutListener = new Animation.AnimationListener() {
        @Override
        public void onAnimationRepeat(Animation animation) {
        }

        @Override
        public void onAnimationStart(Animation animation) {
        }

        @Override
        public void onAnimationEnd(Animation animation) {
            CameraMainActivity.this.rlCaptureBlink.setAlpha(0.0f);
        }
    };
    Animation.AnimationListener fadeInListener = new Animation.AnimationListener() {
        @Override
        public void onAnimationRepeat(Animation animation) {
        }

        @Override
        public void onAnimationStart(Animation animation) {
            CameraMainActivity.this.rlCaptureBlink.setAlpha(0.0f);
        }

        @Override
        public void onAnimationEnd(Animation animation) {
            CameraMainActivity.this.rlCaptureBlink.setAlpha(0.5f);
            CameraMainActivity.this.rlCaptureBlink.startAnimation(CameraMainActivity.this.fadeOut);
        }
    };

    public interface OnBackPressedListener {
        void onBackPressed();
    }

    private void cancelImageSavingNotification() {
    }

    public void changeExposure(int i) {
    }

    public void changeFocusDistance(int i, boolean z) {
    }

    public void changeISO(int i) {
    }

    public void clickedFaceDetection(View view) {
    }

    public void clickedSwitchVideo(View view) {
    }

    public int getNavigationGap() {
        return 0;
    }


    public static boolean isPackageInstalled(Context context, String str) {
        PackageManager packageManager = context.getPackageManager();
        Intent launchIntentForPackage = packageManager.getLaunchIntentForPackage(str);
        if (launchIntentForPackage == null) {
            return false;
        }
        return !packageManager.queryIntentActivities(launchIntentForPackage, 65536).isEmpty();
    }

    public static double round(double f, int v) {
        if (v>=0) {
            double f1 = (double) (((long) Math.pow(10.0, v)));
            return ((double) Math.round(f * f1)) / f1;
        }

        throw new IllegalArgumentException();
    }

    private static String getOnlineHelpUrl(String str) {
        Log.d(TAG, "getOnlineHelpUrl: " + str);
        return "https://opencamera.sourceforge.io/" + str;
    }

    private static void putBundleExtra(Bundle bundle, String str, List<String> list) {
        if (list != null) {
            String[] strArr = new String[list.size()];
            int i = 0;
            for (String str2 : list) {
                strArr[i] = str2;
                i++;
            }
            bundle.putStringArray(str, strArr);
        }
    }

    public static boolean useScopedStorage() {
        return Build.VERSION.SDK_INT>=29;
    }

    public static CheckSaveLocationResult checkSaveLocation(String str) {
        return checkSaveLocation(str, null);
    }

    public static CheckSaveLocationResult checkSaveLocation(String str, String str2) {
        String str3 = null;
        if (StorageUtils.saveFolderIsFull(str)) {
            Log.d(TAG, "" + str);
            if (str2 == null) {
                str2 = StorageUtils.getBaseFolder().getAbsolutePath();
            }
            if (str2.length()>=1 && str2.charAt(str2.length() - 1) == '/') {
                str2 = str2.substring(0, str2.length() - 1);
            }
            Log.d(TAG, "    compare to base_folder: " + str2);
            if (str.startsWith(str2)) {
                str3 = str.substring(str2.length());
                if (str3.length()>=1 && str3.charAt(0) == '/') {
                    str3 = str3.substring(1);
                }
            }
            return new CheckSaveLocationResult(false, str3);
        }
        return new CheckSaveLocationResult(true, null);
    }


    public void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(5894);
    }

    public void showSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(0);
        getWindow().addFlags(1024);
    }

    @Override
    public void onCreate(Bundle bundle) {
        int i;
//        LicenseClientV3.onActivityCreate(this);
        super.onCreate(null);
        Util.SetLanguage(this);
        setContentView(R.layout.activity_main_camera);
        window = getWindow();
        this.intent = getIntent();
        if (!new SP(this).getBoolean(this, "enableAutostart", false)) {
            enableAutoStart();
        }
        if (Build.VERSION.SDK_INT>=18) {
            WindowManager.LayoutParams attributes = getWindow().getAttributes();
            attributes.rotationAnimation = 1;
            getWindow().setAttributes(attributes);
        }
        if (getIntent() != null && getIntent().getExtras() != null) {
            this.is_test = getIntent().getExtras().getBoolean("test_project");
            Log.d(TAG, "is_test: " + this.is_test);
        }
        if (getIntent() != null) {
            getIntent().getExtras();
        }
        if (getIntent() != null && getIntent().getAction() != null) {
            Log.d(TAG, "shortcut: " + getIntent().getAction());
        }
        if (Build.VERSION.SDK_INT>32 && !checkNotiPermission()) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.POST_NOTIFICATIONS"}, 100);
        }
        this.sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        Log.d(TAG, "standard max memory = " + activityManager.getMemoryClass() + "MB");
        Log.d(TAG, "large max memory = " + activityManager.getLargeMemoryClass() + "MB");
        int largeMemoryClass = activityManager.getLargeMemoryClass();
        this.large_heap_memory = largeMemoryClass;
        if (largeMemoryClass>=128) {
            this.supports_auto_stabilise = true;
        }
        Log.d(TAG, "supports_auto_stabilise? " + this.supports_auto_stabilise);
        if (activityManager.getMemoryClass()>=128 || activityManager.getLargeMemoryClass()>=512) {
            this.supports_force_video_4k = true;
        }
        Log.d(TAG, "supports_force_video_4k? " + this.supports_force_video_4k);
        this.applicationInterface = new MyApplicationInterface(this, bundle);
        init();
        checkInApp();
        initCamera2Support();
        setWindowFlagsForCamera();
        this.save_location_history = new SaveLocationHistory(this, "save_location_history", getStorageUtils().getSaveLocation());
        checkSaveLocations();
        if (this.applicationInterface.getStorageUtils().isUsingSAF()) {
            Log.d(TAG, "create new SaveLocationHistory for SAF");
            this.save_location_history_saf = new SaveLocationHistory(this, "", getStorageUtils().getSaveLocationSAF());
        }
        SensorManager sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        this.mSensorManager = sensorManager;
        if (sensorManager.getDefaultSensor(1) != null) {
            Log.d(TAG, "found accelerometer");
            this.mSensorAccelerometer = this.mSensorManager.getDefaultSensor(1);
        } else {
            Log.d(TAG, "no support for accelerometer");
        }
        this.magneticSensor.initSensor(this.mSensorManager);
        Preview preview = new Preview(this.applicationInterface, (ViewGroup) findViewById(R.id.preview), this);
        this.preview = preview;
        int numberOfCameras = preview.getCameraControllerManager().getNumberOfCameras();
        if (numberOfCameras>2) {
            this.back_camera_ids = new ArrayList();
            this.front_camera_ids = new ArrayList();
            this.other_camera_ids = new ArrayList();
            for (int i2 = 0; i2<numberOfCameras; i2++) {
                int i3 = AnonymousClass91.$SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$Facing[this.preview.getCameraControllerManager().getFacing(i2).ordinal()];
                if (i3 == 1) {
                    this.back_camera_ids.add(Integer.valueOf(i2));
                } else if (i3 == 2) {
                    this.front_camera_ids.add(Integer.valueOf(i2));
                } else {
                    this.other_camera_ids.add(Integer.valueOf(i2));
                }
            }
            boolean z = this.back_camera_ids.size()>=2 || this.front_camera_ids.size()>=2 || this.other_camera_ids.size()>=2;
            int i4 = this.back_camera_ids.size()>0 ? 1 : 0;
            if (this.front_camera_ids.size()>0) {
                i4++;
            }
            if (this.other_camera_ids.size()>0) {
                i4++;
            }
            this.is_multi_cam = z && i4>=2;
            Log.d(TAG, "multi_same_facing: " + z);
            Log.d(TAG, "n_facing: " + i4);
            Log.d(TAG, "is_multi_cam: " + this.is_multi_cam);
            if (!this.is_multi_cam) {
                this.back_camera_ids = null;
                this.front_camera_ids = null;
                this.other_camera_ids = null;
            }
        }
        this.li_switch_camera.setVisibility(this.preview.getCameraControllerManager().getNumberOfCameras()>1 ? View.VISIBLE : View.GONE);
        ((ZoomControls) findViewById(R.id.zoom)).setVisibility(View.GONE);
        this.mainUI.updateOnScreenIcons();
        this.orientationEventListener = new OrientationEventListener(this) {
            @Override
            public void onOrientationChanged(int i5) {
                CameraMainActivity.this.mainUI.onOrientationChanged(i5);
            }
        };
        boolean contains = this.sharedPreferences.contains(PreferenceKeys.FirstTimePreferenceKey);
        Log.d(TAG, "has_done_first_time: " + contains);
        if (!contains) {
            setDeviceDefaults();
        }
        try {
            i = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            Log.d(TAG, "NameNotFoundException exception trying to get version number");
            e.printStackTrace();
            i = -1;
        }
        if (i != -1) {
            int i5 = this.sharedPreferences.getInt(PreferenceKeys.LatestVersionPreferenceKey, 0);
            Log.d(TAG, "version_code: " + i);
            Log.d(TAG, "latest_version: " + i5);
            int min = Math.min(74, i);
            Log.d(TAG, "whats_new_version: " + min);
            boolean z2 = this.sharedPreferences.getBoolean(PreferenceKeys.ShowWhatsNewPreferenceKey, true);
            Log.d(TAG, "allow_show_whats_new: " + z2);
            SharedPreferences.Editor edit = this.sharedPreferences.edit();
            edit.putInt(PreferenceKeys.LatestVersionPreferenceKey, i);
            edit.apply();
        }
        setModeFromIntents(bundle);
        this.textToSpeechSuccess = false;
        new Thread(new Runnable() {
            @Override
            public void run() {
                CameraMainActivity.this.textToSpeech = new TextToSpeech(CameraMainActivity.this, new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int i6) {
                        Log.d(CameraMainActivity.TAG, "TextToSpeech initialised");
                        if (i6 == 0) {
                            CameraMainActivity.this.textToSpeechSuccess = true;
                            Log.d(CameraMainActivity.TAG, "TextToSpeech succeeded");
                            return;
                        }
                        Log.d(CameraMainActivity.TAG, "TextToSpeech failed");
                    }
                });
            }
        }).start();
        openShareRateDialog();
        new Thread(new Runnable() {
            @Override
            public void run() {
                CameraMainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (NetworkState.Companion.isOnline(CameraMainActivity.this)) {
//                            MainActivity.this.getBannerData();
                        }
                    }
                });
            }
        }).start();
//        checkFlexibleUpdate();
        isNotification();
        createSaveFolder();
        setTimer();
        setMirror();
        loadAds();
        Display defaultDisplay = getWindowManager().getDefaultDisplay();
        Point point = new Point();
        defaultDisplay.getSize(point);
        this.mScreenH = point.y;
        this.mScreenW = point.x;
        this.isTablet = getResources().getBoolean(R.bool.isTablet);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                CameraMainActivity mainActivity = CameraMainActivity.this;
                mainActivity.IS_ADS = mainActivity.mSP.getBoolean(CameraMainActivity.this, "isPurcheshOrNot", false);
                if (CameraMainActivity.this.IS_ADS) {
                    OSNotificationHelper.sendTag("user_type", "Paid");
                } else {
                    OSNotificationHelper.sendTag("user_type", "Free");
                }
            }
        }, 300L);
        this.mVolleyQueue = Volley.newRequestQueue(this);
        View inflate = ((LayoutInflater) getSystemService("layout_inflater")).inflate(R.layout.stamp_layout, (ViewGroup) null);
        this.li_stamp_lay = inflate;
        this.tv_address_line_1 = (TextView) inflate.findViewById(R.id.tv_address_line_1);
        this.tv_address = (TextView) this.li_stamp_lay.findViewById(R.id.tv_address);
        this.tv_weather = (TextView) this.li_stamp_lay.findViewById(R.id.tv_weather);
        this.txt_wind = (TextView) this.li_stamp_lay.findViewById(R.id.txt_wind);
        this.txt_humidity = (TextView) this.li_stamp_lay.findViewById(R.id.txt_humidity);
        this.txt_pressure = (TextView) this.li_stamp_lay.findViewById(R.id.txt_pressure);
        this.tv_compass = (TextView) this.li_stamp_lay.findViewById(R.id.tv_compass);
        this.tv_magnetic_field = (TextView) this.li_stamp_lay.findViewById(R.id.tv_magnetic_field);
        this.imgMap = (RoundCorners) this.li_stamp_lay.findViewById(R.id.imgMap);
        this.imgLogo = (ImageView) this.li_stamp_lay.findViewById(R.id.imgLogo);
        this.li_stamp = (LinearLayout) this.li_stamp_lay.findViewById(R.id.li_stamp);
        this.li_main_stamp_lay = (LinearLayout) this.li_stamp_lay.findViewById(R.id.li_main_stamp_lay);
        this.lin_waterma = (LinearLayout) this.li_stamp_lay.findViewById(R.id.lin_waterma);
        this.lin_waterma_2 = (LinearLayout) this.li_stamp_lay.findViewById(R.id.lin_waterma_2);
        this.li_compass = (LinearLayout) this.li_stamp_lay.findViewById(R.id.li_compass);
        this.imgCompass = (ImageView) this.li_stamp_lay.findViewById(R.id.imgCompass);
        this.imgWeather = (ImageView) this.li_stamp_lay.findViewById(R.id.imgWeather);
        this.img_wind_stamp = (ImageView) this.li_stamp_lay.findViewById(R.id.img_wind_stamp);
        this.img_humidity_stamp = (ImageView) this.li_stamp_lay.findViewById(R.id.img_humidity_stamp);
        this.img_pressure_stamp = (ImageView) this.li_stamp_lay.findViewById(R.id.img_pressure_stamp);
        this.img_magnetic_field = (ImageView) this.li_stamp_lay.findViewById(R.id.imgMagneticField);
        this.li_rightView = (LinearLayout) this.li_stamp_lay.findViewById(R.id.li_rightView);
        this.li_magnetic_field = (LinearLayout) this.li_stamp_lay.findViewById(R.id.li_magnetic_field);
        this.li_weather = (LinearLayout) this.li_stamp_lay.findViewById(R.id.li_weather);
        this.lin_bottom_wether = (LinearLayout) this.li_stamp_lay.findViewById(R.id.lin_bottom_wather);
        this.lin_humity_stamp = (LinearLayout) this.li_stamp_lay.findViewById(R.id.lin_humidity_stamp);
        this.lin_wind_stamp = (LinearLayout) this.li_stamp_lay.findViewById(R.id.lin_wind_stamp);
        this.lin_pressure_stamp = (LinearLayout) this.li_stamp_lay.findViewById(R.id.lin_pressure_stamp);
        this.li_logo = (LinearLayout) this.li_stamp_lay.findViewById(R.id.li_logo);
        this.li_address = (LinearLayout) this.li_stamp_lay.findViewById(R.id.li_address);
        this.imgstamp_1 = (ImageView) this.li_stamp_lay.findViewById(R.id.img_stamp);
        this.imgstamp_2 = (ImageView) this.li_stamp_lay.findViewById(R.id.img_stamp_2);
        this.txt_watermark_1 = (TextView) this.li_stamp_lay.findViewById(R.id.txt_watermark);
        this.txt_watermark_2 = (TextView) this.li_stamp_lay.findViewById(R.id.txt_watermark_2);
        setupCompass();
        setUpStampLayout();
        this.dFormat = new DecimalFormat("#.######");
        initLocation();
        callWeatherApi();
        initmap();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                CameraMainActivity.this.setcamersetting();
            }
        }, MAX_WAIT_TIME);
    }

    public static class AnonymousClass91 {
        static final int[] $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$Facing;

        static {
            int[] iArr = new int[CameraController.Facing.values().length];
            $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$Facing = iArr;
            try {
                iArr[CameraController.Facing.FACING_BACK.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$Facing[CameraController.Facing.FACING_FRONT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }


    public void initLocation() {
        this.mSP.setBoolean(this, SP.IS_CALL_WEATHER_API, true);
        this.fusedLocationClient = LocationServices.getFusedLocationProviderClient((Activity) this);
        this.mLocationRequest = LocationRequest.create()
                .setInterval(UPDATE_INTERVAL_IN_MILLISECONDS)
                .setFastestInterval(5000L).
                setPriority(100)
                .setMaxWaitTime(MAX_WAIT_TIME);
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        builder.addLocationRequest(this.mLocationRequest);
        this.mLocationSettingsRequest = builder.build();
        this.mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);
                for (Location location : locationResult.getLocations()) {
                    if (location != null) {
                        CameraMainActivity.this.mLocation = location;
                        CameraMainActivity.this.getLocationSupplier().setLocation(CameraMainActivity.this.mLocation);
                        CameraMainActivity mainActivity = CameraMainActivity.this;
                        mainActivity.doWorkWithNewLocation(mainActivity.mLocation);
                    }
                }
            }
        };
        if (ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0 || ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
            this.fusedLocationClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    if (location != null) {
                        CameraMainActivity.this.mLocation = location;
                        CameraMainActivity.this.getLocationSupplier().setLocation(CameraMainActivity.this.mLocation);
                        CameraMainActivity mainActivity = CameraMainActivity.this;
                        mainActivity.doWorkWithNewLocation(mainActivity.mLocation);
                    }
                }
            });
        }
    }

    protected void createLocationRequest() {
        try {
            if (this.isPermission == 0) {
                SettingsClient settingsClient = LocationServices.getSettingsClient((Activity) this);
                this.mSettingsClient = settingsClient;
                settingsClient.checkLocationSettings(this.mLocationSettingsRequest).addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() { // from class: com.live.gpsmap.camera.Camera.MainActivity.11
                    @Override
                    public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                        if (CameraMainActivity.this.fusedLocationClient != null) {
                            fusedLocationClient.requestLocationUpdates(CameraMainActivity.this.mLocationRequest, CameraMainActivity.this.mLocationCallback, Looper.myLooper());
                        }
                    }
                }).addOnFailureListener(this, new OnFailureListener() {
                    @Override
                    public void onFailure(Exception exc) {
                        int statusCode = ((ApiException) exc).getStatusCode();
                        if (statusCode == 6) {
                            CameraMainActivity.this.createLocationRequest();
                        } else if (statusCode != 8502) {
                        } else {
                            Toast.makeText(CameraMainActivity.this, "Location settings are inadequate, and cannot be fixed here. Fix in Settings.", 1).show();
                        }
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setMirror() {
        if (this.mSP.getString(this, PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_no").equals("preference_front_camera_mirror_photo")) {
            this.mTvMirror.setText(getString(R.string.yes));
        } else {
            this.mTvMirror.setText(getString(R.string.no));
        }
    }

    private void initmap() {

        this.mMapView = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapView);
        if (mMapView != null) {
            mMapView.getMapAsync(this);
        }
        this.address_line_1 = this.mSP.getString(this, SP.LOC_LINE_1_ADDRESS, "").trim();
        this.city = this.mSP.getString(this, SP.LOC_LINE_2_CITY, "").trim();
        this.state = this.mSP.getString(this, SP.LOC_LINE_3_STATE, "").trim();
        this.country = this.mSP.getString(this, SP.LOC_LINE_4_COUNTRY, "").trim();
    }

    private void callElevationApi(double d, double d2) {
        StringRequest stringRequest = new StringRequest(0, "https://api.open-meteo.com/v1/elevation?latitude=" + d + "&longitude=" + d2, new Response.Listener<String>() {
            @Override
            public void onResponse(String str) {
                try {
                    JSONArray jSONArray = new JSONObject(str).getJSONArray("elevation");
                    for (int i = 0; i<jSONArray.length(); i++) {
                        CameraMainActivity.this.mSP.setFloat(CameraMainActivity.this, SP.ALTITUDE_VALUE, Float.parseFloat(String.valueOf(jSONArray.get(i))));
                    }
                } catch (JSONException e) {
                    Log.e("JSONException", "" + e.getMessage());
                } catch (Exception e2) {
                    Log.e("Exception", "" + e2.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                if (CameraMainActivity.this.mSP.getFloat(CameraMainActivity.this, SP.ALTITUDE_VALUE) == 0.0f) {
                    EGM96.getInstance().loadGrid(CameraMainActivity.this.mLocation, CameraMainActivity.this);
                }
                Log.e("VolleyError", "" + volleyError.getMessage());
            }
        });
        stringRequest.setShouldCache(false);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(30000, 0, 1.0f));
        this.mVolleyQueue.add(stringRequest);
    }

    private void loadAds() {
//        this.ads = new Admob();
        this.banner_native_layout = (RelativeLayout) findViewById(R.id.rel_adaptive_banner);
//        this.ads.loadAdaptive_banner(this, relativeLayout, getString(R.string.GMC_Banner_Home));
        if (this.mSP.getBoolean(this, "isPurcheshOrNot", false)) {
            this.rel_premium.setVisibility(View.GONE);
        }
    }

    public Bitmap getMapBitmap() {
        return this.mapBitmap;
    }

    public String getCompassStr() {
        return this.mSP.getString(this, SP.COMPASS_VALUE, this.str_compass);
    }

    public String getMagnaticFieldStr() {
        return this.mSP.getString(this, SP.MAGNETIC_FIELD_VALUE, this.str_magnaticField);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.liMultiCamera /* 2131362340 */:
                clickedSwitchMultiCamera(view);
                return;
            case R.id.li_app_setting /* 2131362342 */:
                setUpFlash();
                closePopup();
                this.mDrawerLayout.openDrawer(Gravity.LEFT);
                this.mSP.setInteger(this, SP.BADGE_COUNT, 1);
                this.lin_notification_badge.setVisibility(View.GONE);
                return;
            case R.id.li_filename /* 2131362359 */:
                closePopup();
                setUpFlash();

                startActivity(new Intent(this, FileName_Activity.class));
                return;
            case R.id.li_flash /* 2131362360 */:
                this.preview.cycleFlash(true, true);
                this.mainUI.updateCycleFlashIcon();
                return;
            case R.id.li_focus /* 2131362361 */:
                MyApplicationInterface myApplicationInterface = this.applicationInterface;
                String focusPref = myApplicationInterface != null ? myApplicationInterface.getFocusPref(false) : "";
                if (this.preview != null) {
                    if (!focusPref.equals("focus_mode_auto")) {
                        this.preview.updateFocus("focus_mode_auto", false, true);
                        this.txt_focus.setText(getResources().getString(R.string.focus_manual));
                        this.mImg_focus.setColorFilter(getResources().getColor(R.color.white));
                        return;
                    }
                    this.preview.updateFocus("focus_mode_continuous_picture", false, true);
                    this.mImg_focus.setColorFilter(getResources().getColor(R.color._ffcc00));
                    this.txt_focus.setText(getResources().getString(R.string.focus_auto));
                    return;
                }
                return;
            case R.id.li_grid /* 2131362362 */:
                int integer = this.mSP.getInteger(this, PreferenceKeys.GRID_POS, 0);
                if (integer == 0) {
                    this.mSP.setInteger(this, PreferenceKeys.GRID_POS, 1);
                    this.mSP.setString(this, PreferenceKeys.ShowGridPreferenceKey, this.grid_values[1]);
                    this.txt_grid.setText("3x3");
                    this.img_grid.setColorFilter(getResources().getColor(R.color._ffcc00));
                } else if (integer == 1) {
                    this.mSP.setInteger(this, PreferenceKeys.GRID_POS, 2);
                    this.mSP.setString(this, PreferenceKeys.ShowGridPreferenceKey, this.grid_values[2]);
                    this.txt_grid.setText("Phi 3x3");
                    this.img_grid.setColorFilter(getResources().getColor(R.color._ffcc00));
                } else if (integer == 2) {
                    this.mSP.setInteger(this, PreferenceKeys.GRID_POS, 3);
                    this.mSP.setString(this, PreferenceKeys.ShowGridPreferenceKey, this.grid_values[3]);
                    this.txt_grid.setText("Crosshair");
                    this.img_grid.setColorFilter(getResources().getColor(R.color._ffcc00));
                } else if (integer == 3) {
                    this.mSP.setInteger(this, PreferenceKeys.GRID_POS, 0);
                    this.mSP.setString(this, PreferenceKeys.ShowGridPreferenceKey, this.grid_values[0]);
                    this.txt_grid.setText("");
                    this.img_grid.setColorFilter(getResources().getColor(R.color.white));
                }
                this.applicationInterface.getDrawPreview().updateSettings();
                return;
            case R.id.li_mirror /* 2131362368 */:
                if (this.mSP.getString(this, PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_no").equals("preference_front_camera_mirror_no")) {
                    this.mSP.setString(this, PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_photo");
                    TextView textView = this.mTvMirror;
                    textView.setText(getString(R.string.mirror) + " " + getString(R.string.on));
                    this.img_mirror.setColorFilter(getResources().getColor(R.color._ffcc00));
                    return;
                }
                this.mSP.setString(this, PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_no");
                TextView textView2 = this.mTvMirror;
                textView2.setText(getString(R.string.mirror) + " " + getString(R.string.off));
                this.img_mirror.setColorFilter(getResources().getColor(R.color.white));
                return;
            case R.id.li_sound /* 2131362375 */:
                if (this.applicationInterface.getShutterSoundPref()) {
                    this.applicationInterface.setShutterSoundPref(false);
                    TextView textView3 = this.tvsound;
                    textView3.setText(getString(R.string.sound) + " " + getString(R.string.off));
                    this.img_sound.setImageResource(R.drawable.ic_sound_off);
                    this.img_sound.setColorFilter(getResources().getColor(R.color.white));
                    return;
                }
                this.applicationInterface.setShutterSoundPref(true);
                TextView textView4 = this.tvsound;
                textView4.setText(getString(R.string.sound) + " " + getString(R.string.on));
                this.img_sound.setImageResource(R.drawable.ic_sound_on);
                this.img_sound.setColorFilter(getResources().getColor(R.color._ffcc00));
                return;
            case R.id.li_switch_camera /* 2131362377 */:
                setUpFlash();
                new Handler().postDelayed(new Runnable() { // from class: com.live.gpsmap.camera.Camera.MainActivity.14
                    @Override
                    public void run() {
                        CameraMainActivity.this.setcamersetting();
                    }
                }, 1500L);
                Log.d(TAG, "clickedSwitchCamera");
                if (this.preview.isOpeningCamera()) {
                    Log.d(TAG, "already opening camera in background thread");
                    return;
                } else if (this.preview.canSwitchCamera()) {
                    userSwitchToCamera(getNextCameraId());
                    return;
                } else {
                    return;
                }
            case R.id.li_timer /* 2131362379 */:
                String string = this.mSP.getString(this, PreferenceKeys.TimerPreferenceKey, "No");
                if (string.equals("No")) {
                    this.mSP.setString(this, PreferenceKeys.TimerPreferenceKey, ExifInterface.GPS_MEASUREMENT_3D);
                    this.img_timer.setImageResource(R.drawable.ic_3_sec);
                    this.img_timer.setColorFilter(getResources().getColor(R.color._ffcc00));
                    TextView textView5 = this.txt_timer;
                    textView5.setText(getString(R.string.timer) + " 3sec");
                    return;
                } else if (string.equals(ExifInterface.GPS_MEASUREMENT_3D)) {
                    this.img_timer.setImageResource(R.drawable.ic_5_sec);
                    this.img_timer.setColorFilter(getResources().getColor(R.color._ffcc00));
                    TextView textView6 = this.txt_timer;
                    textView6.setText(getString(R.string.timer) + " 5sec");
                    this.mSP.setString(this, PreferenceKeys.TimerPreferenceKey, "5");
                    return;
                } else if (string.equals("5")) {
                    this.img_timer.setImageResource(R.drawable.ic_timer);
                    this.img_timer.setColorFilter(getResources().getColor(R.color.white));
                    TextView textView7 = this.txt_timer;
                    textView7.setText(getString(R.string.timer) + " " + getString(R.string.off));
                    this.mSP.setString(this, PreferenceKeys.TimerPreferenceKey, "No");
                    return;
                } else {
                    return;
                }
            case R.id.rel_folder:
                closePopup();
                setUpFlash();

                startActivity(new Intent(this, FolderActivity.class));
                return;
            case R.id.rel_gps:
                setUpFlash();
                closePopup();
                startActivity(new Intent(this, Location_Activity.class));
                return;
            case R.id.rel_template:
                setUpFlash();
                closePopup();

                startActivity(new Intent(this, TempletSelectionActivity.class));
                return;
            case R.id.take_photo:
                takePicture(false);
                closePopup();
                return;
            default:
                return;
        }
    }


    public void callFragment(Fragment fragment, String str) {
        FragmentTransaction beginTransaction = getSupportFragmentManager().beginTransaction();
        beginTransaction.replace(R.id.camera_layout, fragment, str);
        beginTransaction.addToBackStack(str);
        beginTransaction.commit();
    }

    public void onInAppClicked() {
        closeDrawer();
        if (NetworkState.Companion.isOnline(this)) {

            startActivity(new Intent(this, InAppPurchaseActivity.class));
            return;
        }
        RelativeLayout relativeLayout = this.moMainLayout;
        Snackbar.make(relativeLayout, "" + getString(R.string.no_internet_msg), -1).show();
    }

    private void setTimer() {
        String string = this.mSP.getString(this, PreferenceKeys.TimerPreferenceKey, "No");
        if (string.equals("No")) {
            this.img_timer.setImageResource(R.drawable.ic_timer);
        } else if (string.equals(ExifInterface.GPS_MEASUREMENT_3D)) {
            this.img_timer.setImageResource(R.drawable.ic_3_sec);
        } else if (string.equals("5")) {
            this.img_timer.setImageResource(R.drawable.ic_5_sec);
        }
    }

    public void createSaveFolder() {
        File file = new File(Default.PARENT_FOLDER_PATH);
        if (!file.exists()) {
            file.mkdir();
        }
        if (file.exists()) {
            File file2 = new File(file.getAbsolutePath() + "/" + Default.SITE_1);
            if (!file2.exists()) {
                file2.mkdir();
            }
            File file3 = new File(file.getAbsolutePath() + "/" + Default.SITE_2);
            if (file3.exists()) {
                return;
            }
            file3.mkdir();
        }
    }

    public void setUpFlash() {
        if (this.preview != null) {
            if (this.applicationInterface.getFlashPref().equals("flash_torch") || this.applicationInterface.getFlashPref().equals("flash_frontscreen_torch")) {
                this.preview.updateFlash("flash_off", true);
                this.mSP.setInteger(this, PreferenceKeys.FLASH_POS, 0);
                this.mainUI.updateCycleFlashIcon();
            }
        }
    }

    public void closePopup() {
        if (this.moLi_Settings.getVisibility() == 0) {
            this.moLi_Settings.setVisibility(View.GONE);
            this.mImg_camera_settings.setColorFilter(-1);
        }
    }

    public void hideUi() {
        if (this.mTopScreenPannel.getVisibility() == 0) {
            this.mTopScreenPannel.setVisibility(4);
        }
        if (this.mBottomScreenPannel.getVisibility() == 0) {
            this.mBottomScreenPannel.setVisibility(4);
        }
        this.relAdsLay.setVisibility(View.GONE);
    }

    public void showUI() {
        if (this.mTopScreenPannel.getVisibility() == 4) {
            this.mTopScreenPannel.setVisibility(View.VISIBLE);
        }
        if (this.mBottomScreenPannel.getVisibility() == 4) {
            this.mBottomScreenPannel.setVisibility(View.VISIBLE);
        }
        this.relAdsLay.setVisibility(View.VISIBLE);
    }

    private void openShareRateDialog() {
        this.AppCount = this.mSP.getInteger(this, "appCount", 0) + 1;
        this.mSP.setInteger(this, "appCount", this.AppCount);
        if (this.AppCount % 5 == 0 && !this.mSP.getBoolean(this, "share")) {
            Util.showShareDialog(this);
        }
        if (this.AppCount % 9 != 0 || this.mSP.getBoolean(this, "rate")) {
            return;
        }
//        Util.showSayThanksDialog(this);
    }

    public void updateGrid() {
        this.applicationInterface.getDrawPreview().updateSettings();
    }

    private void init() {
        SP sp = new SP(this);
        this.mSP = sp;
        Default.WHITEBALANCE = sp.getInteger(this, SP.WHITEBALANCE, 0);
        Default.SCENEMODE = this.mSP.getInteger(this, SP.SCENEMODE, 0);
        this.selectedLan = this.mSP.getString(this, SP.SELECTED_LANGUAGE, Default.LANGUAGE);
        this.grid_values = getResources().getStringArray(R.array.preference_grid_values);
        this.bluetoothRemoteControl = new BluetoothRemoteControl(this);
        this.settingsManager = new SettingsManager(this);
        this.mainUI = new MainUI(this);
        this.manualSeekbars = new ManualSeekbars();
        this.textFormatter = new TextFormatter(this);
        this.soundPoolManager = new SoundPoolManager(this);
        this.magneticSensor = new MagneticSensor(this);
        this.speechControl = new SpeechControl(this);
        this.switchCameraButton = (ImageView) findViewById(R.id.switch_camera);
        this.li_switch_camera = (LinearLayout) findViewById(R.id.li_switch_camera);
        this.li_Multi_Camera = (LinearLayout) findViewById(R.id.liMultiCamera);
        this.img_timer = (ImageView) findViewById(R.id.img_timer);
        this.li_timer = (LinearLayout) findViewById(R.id.li_timer);
        this.img_tamplate = (ImageView) findViewById(R.id.img_tamplate);
        this.moLi_Header = (LinearLayout) findViewById(R.id.topscreenpannel);
        this.moLi_Settings = (LinearLayout) findViewById(R.id.li_settings);
        this.mImg_flash = (ImageView) findViewById(R.id.img_flash);
        this.moMainLayout = (RelativeLayout) findViewById(R.id.camera_layout);
        this.mLinear_Flash = (LinearLayout) findViewById(R.id.li_flash);
        this.ratio_linear = (LinearLayout) findViewById(R.id.li_ratio);
        this.ll_whitebalance = (LinearLayout) findViewById(R.id.li_whitebalance);
        this.ll_scenemode = (LinearLayout) findViewById(R.id.li_scenemode);
        this.ll_filterview = (LinearLayout) findViewById(R.id.filterview);
        this.rv_filterview = (RecyclerView) findViewById(R.id.filter_recyclerview);
        this.rl_btn_layout = (RelativeLayout) findViewById(R.id.rl_btn_layout);
        this.img_whitebalance = (ImageView) findViewById(R.id.img_whitebalance);
        this.img_scenemode = (ImageView) findViewById(R.id.img_scenemode);
        this.back_layout = (CardView) findViewById(R.id.back_layout);
        this.mImg_camera_settings = (ImageView) findViewById(R.id.img_camera_settings);
        this.rlCaptureBlink = (RelativeLayout) findViewById(R.id.rlCaptureBlink);
        this.mTopScreenPannel = (LinearLayout) findViewById(R.id.topscreenpannel);
        this.mBottomScreenPannel = (RelativeLayout) findViewById(R.id.bottomscreenpannel);
        this.mImg_focus = (ImageView) findViewById(R.id.img_focus);
        this.img_mirror = (ImageView) findViewById(R.id.img_mirror);
        this.img_sound = (ImageView) findViewById(R.id.img_sound);
        this.img_grid = (ImageView) findViewById(R.id.img_grid);
        this.txt_grid = (TextView) findViewById(R.id.txt_grid);
        this.tv_qrcode = (TextView) findViewById(R.id.tv_qrcode);
        this.tv_video = (TextView) findViewById(R.id.tv_video);
        this.tv_photo = (TextView) findViewById(R.id.tv_photo);
        this.mapfragmentlay = (RelativeLayout) findViewById(R.id.mapfragmentlay);
        this.previewlay = (FrameLayout) findViewById(R.id.preview);
        this.scannerView = (ScannerView) findViewById(R.id.scanner_view);
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_lay);
        mDrawerLayout.addDrawerListener(new DrawerLayout.SimpleDrawerListener() {
            @Override
            public void onDrawerSlide(View view, float f) {
                super.onDrawerSlide(view, f);
            }

            @Override
            public void onDrawerOpened(View view) {
                super.onDrawerOpened(view);
                CameraMainActivity.this.showSystemUI();
            }

            @Override
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
                CameraMainActivity.this.hideSystemUI();
            }
        });
        this.mNavigationView = (NavigationView) findViewById(R.id.nav_view);
        this.banner_data = (LinearLayout) findViewById(R.id.banner_data);
        this.mLi_app_setting = (LinearLayout) findViewById(R.id.li_app_setting);
        this.lin_notification_badge = (LinearLayout) findViewById(R.id.lin_notification_badge);
        this.mLi_grid = (LinearLayout) findViewById(R.id.li_grid);
        this.li_sound = (LinearLayout) findViewById(R.id.li_sound);
        this.mLi_flash = (LinearLayout) findViewById(R.id.li_flash);
        this.mLi_ratio = (LinearLayout) findViewById(R.id.li_ratio);
        this.mLi_focus = (LinearLayout) findViewById(R.id.li_focus);
        this.mLi_camera_setting = (LinearLayout) findViewById(R.id.li_camera_setting);
        this.mRel_gps = (RelativeLayout) findViewById(R.id.rel_gps);
        this.mLi_filename = (LinearLayout) findViewById(R.id.li_filename);
        this.mRel_folder = (RelativeLayout) findViewById(R.id.rel_folder);
        this.mImgGalleryButton = (RoundImageView) findViewById(R.id.img_gallery);
        this.mImgTakePhoto = (ImageView) findViewById(R.id.take_photo);
        this.mLi_mirror = (LinearLayout) findViewById(R.id.li_mirror);
        this.rel_camera_mode = (RelativeLayout) findViewById(R.id.rel_camera_mode);
        this.img_app_promasion = (ImageView) this.mNavigationView.getHeaderView(0).findViewById(R.id.img_app_promotion);
        this.mNavigationView.setNavigationItemSelectedListener(this);
        if (appInstalledOrNot("com.gpsvideocamera.videotimestamp")) {
            if (appInstalledOrNot("com.gpsfieldsareameasure.landareacalculator")) {
                this.img_app_promasion.setVisibility(View.GONE);
                this.lin_notification_badge.setVisibility(View.GONE);
            }
        } else {
            this.img_app_promasion.setVisibility(View.VISIBLE);
            if (this.mSP.getInteger(this, SP.BADGE_COUNT, 0) == 0) {
                this.lin_notification_badge.setVisibility(View.VISIBLE);
            } else {
                this.lin_notification_badge.setVisibility(View.GONE);
            }
        }
        this.switchNav_Watermark = (SwitchCompat) this.mNavigationView.getMenu().findItem(R.id.nav_whatermark).getActionView().findViewById(R.id.sdCardSwitch);
        boolean z = this.mSP.getBoolean(this, SP.IS_WATER_MARK, true);
        this.is_watermark = z;
        this.switchNav_Watermark.setChecked(z);
        this.img_watermark = (ImageView) this.mNavigationView.getMenu().findItem(R.id.nav_whatermark).getActionView().findViewById(R.id.img_pro);
        if (EnvironmentSDCard.isSDCardAvailable(this)) {
            this.switchNav_SDCard = (SwitchCompat) this.mNavigationView.getMenu().findItem(R.id.nav_sd_card).getActionView().findViewById(R.id.sdCardSwitch);
            this.isSDCardStorageEnabled = this.mSP.getBoolean(this, PreferenceKeys.UsingSAFPreferenceKey);
            switchSDChecked();
        } else {
            this.mNavigationView.getMenu().findItem(R.id.nav_sd_card).setVisible(false);
            this.mSP.setBoolean(this, PreferenceKeys.UsingSAFPreferenceKey, false);
            this.mSP.setBoolean(this, PreferenceKeys.IS_SDCARD_PERMISSION, false);
        }
        this.rel_premium = (RelativeLayout) findViewById(R.id.rel_premium);
        ((TextView) this.mNavigationView.getMenu().findItem(R.id.nav_version).getActionView().findViewById(R.id.tv_menu_text)).setText(" 1.4.26");
        ((TextView) this.mNavigationView.getMenu().findItem(R.id.nav_language).getActionView().findViewById(R.id.tv_menu_text)).setText(this.selectedLan);
        this.relAdsLay = (RelativeLayout) findViewById(R.id.rel_adaptive_banner);
        this.mRel_template = (RelativeLayout) findViewById(R.id.rel_template);
        this.mRel_gallery = (RelativeLayout) findViewById(R.id.rel_gallery);
        this.mTv_folder_name = (TextView) findViewById(R.id.tv_folder_name);
        this.mTvMirror = (TextView) findViewById(R.id.tvMirror);
        this.tvsound = (TextView) findViewById(R.id.tvsound);
        this.txt_focus = (TextView) findViewById(R.id.txt_focus);
        this.txt_timer = (TextView) findViewById(R.id.txt_timer);
        this.txt_ration = (TextView) findViewById(R.id.txt_ration);
        this.img_app_promasion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (CameraMainActivity.PROMOTION_BANNER) {
                    if (CameraMainActivity.this.appInstalledOrNot("com.gpsvideocamera.videotimestamp")) {
                        if (CameraMainActivity.this.appInstalledOrNot("com.gpsfieldsareameasure.landareacalculator")) {
                            return;
                        }

                        CameraMainActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://bit.ly/3Bz5Lgg")));
                        CameraMainActivity.this.closeDrawer();
                        return;
                    }

                    CameraMainActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://bit.ly/3sDzDBi")));
                    CameraMainActivity.this.closeDrawer();
                } else if (CameraMainActivity.this.appInstalledOrNot("com.gpsfieldsareameasure.landareacalculator")) {
                    if (CameraMainActivity.this.appInstalledOrNot("com.gpsvideocamera.videotimestamp")) {
                        return;
                    }

                    CameraMainActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://bit.ly/3sDzDBi")));
                    CameraMainActivity.this.closeDrawer();
                } else {

                    CameraMainActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://bit.ly/3Bz5Lgg")));
                    CameraMainActivity.this.closeDrawer();
                }
            }
        });
        this.mDrawerLayout.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(View view, float f) {
            }

            @Override
            public void onDrawerStateChanged(int i) {
            }

            @Override
            public void onDrawerOpened(View view) {
                if (CameraMainActivity.PROMOTION_BANNER) {
                    if (CameraMainActivity.this.appInstalledOrNot("com.gpsvideocamera.videotimestamp")) {
                        if (CameraMainActivity.this.appInstalledOrNot("com.gpsfieldsareameasure.landareacalculator")) {
                            CameraMainActivity.this.img_app_promasion.setVisibility(View.GONE);
                            return;
                        } else {
                            CameraMainActivity.this.img_app_promasion.setImageResource(R.drawable.ads_banner_new);
                            return;
                        }
                    }
                    CameraMainActivity.this.img_app_promasion.setImageResource(R.drawable.app_promotion);
                } else if (CameraMainActivity.this.appInstalledOrNot("com.gpsfieldsareameasure.landareacalculator")) {
                    if (CameraMainActivity.this.appInstalledOrNot("com.gpsvideocamera.videotimestamp")) {
                        CameraMainActivity.this.img_app_promasion.setVisibility(View.GONE);
                    } else {
                        CameraMainActivity.this.img_app_promasion.setImageResource(R.drawable.app_promotion);
                    }
                } else {
                    CameraMainActivity.this.img_app_promasion.setImageResource(R.drawable.ads_banner_new);
                }
            }

            @Override
            public void onDrawerClosed(View view) {
                if (CameraMainActivity.PROMOTION_BANNER) {
                    CameraMainActivity.PROMOTION_BANNER = false;
                } else {
                    CameraMainActivity.PROMOTION_BANNER = true;
                }
            }
        });
        onCliks();
        setScanner();
    }


    public void setcamersetting() {
        Preview preview = this.preview;
        if (preview != null) {
            this.ratio_entries = preview.getSupportedPictureSizes(true);
        }
        int integer = this.mSP.getInteger(this, PreferenceKeys.getRatioPos_PrefrenceKey(this.preview.getCameraId()), 0);
        List<CameraController.Size> list = this.ratio_entries;
        if (list != null && list.size()>0 && this.ratio_entries.size() - 1>=integer) {
            TextView textView = this.txt_ration;
            textView.setText(getString(R.string.ratio) + " " + (Preview.getAspectRatioMPString(getResources(), this.ratio_entries.get(integer).width, this.ratio_entries.get(integer).height, true) + " "));
        }
        int integer2 = this.mSP.getInteger(this, PreferenceKeys.GRID_POS, 0);
        if (integer2 == 0) {
            this.mSP.setInteger(this, PreferenceKeys.GRID_POS, 0);
            this.mSP.setString(this, PreferenceKeys.ShowGridPreferenceKey, this.grid_values[0]);
            this.txt_grid.setText("None");
            this.img_grid.setColorFilter(getResources().getColor(R.color.white));
        } else if (integer2 == 1) {
            this.mSP.setInteger(this, PreferenceKeys.GRID_POS, 1);
            this.mSP.setString(this, PreferenceKeys.ShowGridPreferenceKey, this.grid_values[1]);
            this.txt_grid.setText("3x3");
            this.img_grid.setColorFilter(getResources().getColor(R.color._ffcc00));
        } else if (integer2 == 2) {
            this.mSP.setInteger(this, PreferenceKeys.GRID_POS, 2);
            this.mSP.setString(this, PreferenceKeys.ShowGridPreferenceKey, this.grid_values[2]);
            this.txt_grid.setText("Phi 3x3");
            this.img_grid.setColorFilter(getResources().getColor(R.color._ffcc00));
        } else if (integer2 == 3) {
            this.mSP.setInteger(this, PreferenceKeys.GRID_POS, 3);
            this.mSP.setString(this, PreferenceKeys.ShowGridPreferenceKey, this.grid_values[3]);
            this.txt_grid.setText("Crosshair");
            this.img_grid.setColorFilter(getResources().getColor(R.color._ffcc00));
        }
        String string = this.mSP.getString(this, PreferenceKeys.TimerPreferenceKey, "No");
        if (string.equals(ExifInterface.GPS_MEASUREMENT_3D)) {
            this.mSP.setString(this, PreferenceKeys.TimerPreferenceKey, ExifInterface.GPS_MEASUREMENT_3D);
            this.img_timer.setImageResource(R.drawable.ic_3_sec);
            this.img_timer.setColorFilter(getResources().getColor(R.color._ffcc00));
        } else if (string.equals("5")) {
            this.img_timer.setImageResource(R.drawable.ic_5_sec);
            this.img_timer.setColorFilter(getResources().getColor(R.color._ffcc00));
            this.txt_timer.setText(getString(R.string.timer) + " 5sec");
        } else if (string.equals("No")) {
            this.img_timer.setImageResource(R.drawable.ic_timer);
            this.img_timer.setColorFilter(getResources().getColor(R.color.white));
            this.txt_timer.setText(getString(R.string.timer) + " " + getString(R.string.off));
        }
        String focusPref = this.applicationInterface.getFocusPref(false);
        if (this.preview != null) {
            if (!focusPref.equals("focus_mode_auto")) {
                this.mImg_focus.setColorFilter(getResources().getColor(R.color._ffcc00));
                this.txt_focus.setText(getResources().getString(R.string.focus_auto));
            } else {
                this.mImg_focus.setColorFilter(getResources().getColor(R.color.white));
                this.txt_focus.setText(getResources().getString(R.string.focus_manual));
            }
        }
        if (this.mSP.getString(this, PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_no").equals("preference_front_camera_mirror_no")) {
            this.mTvMirror.setText(getString(R.string.mirror) + " " + getString(R.string.off));
            this.img_mirror.setColorFilter(getResources().getColor(R.color.white));
        } else {
            this.mTvMirror.setText(getString(R.string.mirror) + " " + getString(R.string.on));
            this.img_mirror.setColorFilter(getResources().getColor(R.color._ffcc00));
        }
        if (this.applicationInterface.getShutterSoundPref()) {
            this.tvsound.setText(getString(R.string.sound) + " " + getString(R.string.on));
            this.img_sound.setImageResource(R.drawable.ic_sound_on);
            this.img_sound.setColorFilter(getResources().getColor(R.color._ffcc00));
            return;
        }
        this.tvsound.setText(getString(R.string.sound) + " " + getString(R.string.off));
        this.img_sound.setImageResource(R.drawable.ic_sound_off);
        this.img_sound.setColorFilter(getResources().getColor(R.color.white));
    }

    private void dialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getResources().getString(R.string.watermark_inapp_msg));
        builder.setPositiveButton(getResources().getString(R.string.pro), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (NetworkState.Companion.isOnline(CameraMainActivity.this)) {

                    CameraMainActivity.this.startActivity(new Intent(CameraMainActivity.this, InAppPurchaseActivity.class));
                    return;
                }
                RelativeLayout relativeLayout = CameraMainActivity.this.moMainLayout;
                Snackbar.make(relativeLayout, "" + CameraMainActivity.this.getString(R.string.no_internet_msg), -1).show();
            }
        });
        builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        final AlertDialog create = builder.create();
        create.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                create.getButton(-1).setBackgroundResource(R.drawable.my_ripple);
                create.getButton(-2).setBackgroundResource(R.drawable.my_ripple);
            }
        });
        create.show();
    }

    boolean isAppInstalled(String str) {
        try {
            return getPackageManager().getPackageInfo(str, 16384).activities.length>0;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean appInstalledOrNot(String str) {
        try {
            getPackageManager().getPackageInfo(str, 1);
            return true;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }

    private void onCliks() {
        this.mLi_app_setting.setOnClickListener(this);
        this.mLi_ratio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (CameraMainActivity.this.preview != null) {
                    CameraMainActivity mainActivity = CameraMainActivity.this;
                    mainActivity.ratio_entries = mainActivity.preview.getSupportedPictureSizes(true);
                    if (CameraMainActivity.this.ratio_entries != null) {
                        SP sp = CameraMainActivity.this.mSP;
                        CameraMainActivity mainActivity2 = CameraMainActivity.this;
                        int integer = sp.getInteger(mainActivity2, PreferenceKeys.getRatioPos_PrefrenceKey(mainActivity2.preview.getCameraId()), 0);
                        int i = integer< CameraMainActivity.this.ratio_entries.size() - 1 ? integer + 1 : 0;
                        TextView textView = CameraMainActivity.this.txt_ration;
                        textView.setText(CameraMainActivity.this.getString(R.string.ratio) + " " + (Preview.getAspectRatioMPString(CameraMainActivity.this.getResources(), CameraMainActivity.this.ratio_entries.get(i).width, CameraMainActivity.this.ratio_entries.get(i).height, true) + " "));
                        SP sp2 = CameraMainActivity.this.mSP;
                        CameraMainActivity mainActivity3 = CameraMainActivity.this;
                        sp2.setString(mainActivity3, PreferenceKeys.getResolutionPreferenceKey(mainActivity3.preview.getCameraId()), CameraMainActivity.this.ratio_entries.get(i).width + " " + CameraMainActivity.this.ratio_entries.get(i).height);
                        SP sp3 = CameraMainActivity.this.mSP;
                        CameraMainActivity mainActivity4 = CameraMainActivity.this;
                        sp3.setInteger(mainActivity4, PreferenceKeys.getRatioPos_PrefrenceKey(mainActivity4.preview.getCameraId()), i);
                        CameraMainActivity.this.applicationInterface.setCameraResolutionPref(CameraMainActivity.this.ratio_entries.get(i).width, CameraMainActivity.this.ratio_entries.get(i).height);
                        CameraMainActivity.this.updateForSettings("", true);
                    }
                }
            }
        });
        this.mLi_grid.setOnClickListener(this);
        this.li_sound.setOnClickListener(this);
        this.mLi_flash.setOnClickListener(this);
        this.mLi_focus.setOnClickListener(this);
        this.mRel_template.setOnClickListener(this);
        this.mImgTakePhoto.setOnClickListener(this);
        this.mLi_camera_setting.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View view) {
                ArrayList arrayList = (ArrayList) CameraMainActivity.this.preview.getSupportedWhiteBalances();
                ArrayList arrayList2 = (ArrayList) CameraMainActivity.this.preview.getSupportedSceneModes();
                if (arrayList == null) {
                    CameraMainActivity.this.ll_whitebalance.setVisibility(4);
                } else if (Default.WHITEBALANCE == 0) {
                    CameraMainActivity.this.img_whitebalance.setImageResource(R.drawable.fl_whitebalance_unselect);
                } else {
                    CameraMainActivity.this.img_whitebalance.setImageResource(R.drawable.fl_whitebalance_select);
                }
                if (arrayList2 == null) {
                    CameraMainActivity.this.ll_scenemode.setVisibility(4);
                } else if (Default.SCENEMODE == 0) {
                    CameraMainActivity.this.img_scenemode.setImageResource(R.drawable.ic_scene_mode);
                } else {
                    CameraMainActivity.this.img_scenemode.setImageResource(R.drawable.ic_scene_mode_select);
                }
                if (CameraMainActivity.this.ll_filterview.getVisibility() == 0) {
                    CameraMainActivity mainActivity = CameraMainActivity.this;
                    mainActivity.slideright(mainActivity.ll_filterview);
                    CameraMainActivity mainActivity2 = CameraMainActivity.this;
                    mainActivity2.slideleft(mainActivity2.rl_btn_layout);
                    CameraMainActivity mainActivity3 = CameraMainActivity.this;
                    mainActivity3.slideleft(mainActivity3.rel_camera_mode);
                }
                CameraMainActivity.this.setUpFlash();
                CameraMainActivity.this.closePopup();
                CameraMainActivity.this.setcamersetting();
                CameraMainActivity.this.moLi_Settings.setVisibility(View.VISIBLE);
                CameraMainActivity.this.mSP.setInteger(CameraMainActivity.this, "CAM_SET_OPEN_TIME", CameraMainActivity.this.mSP.getInteger(CameraMainActivity.this, "CAM_SET_OPEN_TIME", 0) + 1);
            }
        });
        this.mRel_gps.setOnClickListener(this);
        this.mLi_filename.setOnClickListener(this);
        this.mRel_folder.setOnClickListener(this);
        this.li_timer.setOnClickListener(this);
        this.li_switch_camera.setOnClickListener(this);
        this.li_Multi_Camera.setOnClickListener(this);
        this.mRel_template.setOnClickListener(this);
        this.mRel_gallery.setOnClickListener(new SingleClickListener() { // from class: com.live.gpsmap.camera.Camera.MainActivity.23
            @Override // com.live.gpsmap.camera.helper.SingleClickListener
            public void performClick(View view) {
                CameraMainActivity.this.setUpFlash();
                CameraMainActivity.this.openGallery();
                CameraMainActivity.this.closePopup();
            }
        });
        this.rel_premium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CameraMainActivity.this.onInAppClicked();
            }
        });
        this.mLi_mirror.setOnClickListener(this);
        this.ll_whitebalance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CameraMainActivity.this.rl_btn_layout.setVisibility(View.GONE);
                CameraMainActivity.this.rel_camera_mode.setVisibility(View.GONE);
                CameraMainActivity.this.closePopup();
                CameraMainActivity.this.setWhiteBalance();
                CameraMainActivity mainActivity = CameraMainActivity.this;
                mainActivity.slideleft(mainActivity.ll_filterview);
            }
        });
        this.ll_scenemode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CameraMainActivity.this.rl_btn_layout.setVisibility(View.GONE);
                CameraMainActivity.this.rel_camera_mode.setVisibility(View.GONE);
                CameraMainActivity.this.closePopup();
                CameraMainActivity.this.setSceneMode();
                CameraMainActivity mainActivity = CameraMainActivity.this;
                mainActivity.slideleft(mainActivity.ll_filterview);
            }
        });
        this.back_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CameraMainActivity mainActivity = CameraMainActivity.this;
                mainActivity.slideright(mainActivity.ll_filterview);
                CameraMainActivity mainActivity2 = CameraMainActivity.this;
                mainActivity2.slideleft(mainActivity2.rl_btn_layout);
                CameraMainActivity mainActivity3 = CameraMainActivity.this;
                mainActivity3.slideleft(mainActivity3.rel_camera_mode);
            }
        });
        this.tv_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CameraMainActivity.this.setModePhoto();
//                MainActivity.this.onClick(li_switch_camera);

//                MainActivity.this.tv_qrcode.setEnabled(false);
//                MainActivity.this.tv_photo.setEnabled(false);
//                MainActivity.this.tv_video.setEnabled(false);
//                new Handler().postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        MainActivity.this.tv_qrcode.setEnabled(true);
//                        MainActivity.this.tv_photo.setEnabled(true);
//                        MainActivity.this.tv_video.setEnabled(true);
//                    }
//                }, MainActivity.MAX_WAIT_TIME);
            }
        });
        this.tv_qrcode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CameraMainActivity.this.setModeQRCode();

//                MainActivity.this.tv_qrcode.setEnabled(false);
//                MainActivity.this.tv_photo.setEnabled(false);
//                MainActivity.this.tv_video.setEnabled(false);
//                new Handler().postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        MainActivity.this.tv_qrcode.setEnabled(true);
//                        MainActivity.this.tv_photo.setEnabled(true);
//                        MainActivity.this.tv_video.setEnabled(true);
//                    }
//                }, MainActivity.MAX_WAIT_TIME);
            }
        });
        this.tv_video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(CameraMainActivity.this, VideoCameraActivity.class);
                resultLauncher.launch(intent);

//                MainActivity.this.setModeVideo();
//                MainActivity.this.tv_qrcode.setEnabled(false);
//                MainActivity.this.tv_video.setEnabled(false);
//                MainActivity.this.tv_photo.setEnabled(false);
//                new Handler().postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        MainActivity.this.tv_qrcode.setEnabled(true);
//                        MainActivity.this.tv_photo.setEnabled(true);
//                        MainActivity.this.tv_video.setEnabled(true);
//                    }
//                }, MainActivity.MAX_WAIT_TIME);
            }
        });
    }

    public void setSceneMode() {
        ArrayList arrayList = (ArrayList) this.preview.getSupportedSceneModes();
        if (arrayList != null) {
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
            linearLayoutManager.setOrientation(0);
            linearLayoutManager.scrollToPosition(Default.SCENEMODE);
            this.rv_filterview.setLayoutManager(linearLayoutManager);
            Filter_Adapter filter_Adapter = new Filter_Adapter(this, arrayList, this.preview, SP.SCENEMODE);
            this.rv_filterview.setAdapter(filter_Adapter);
            filter_Adapter.notifyItemChanged(Default.SCENEMODE);
        }
    }


    public void setWhiteBalance() {
        ArrayList arrayList = (ArrayList) this.preview.getSupportedWhiteBalances();
        if (arrayList != null) {
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
            linearLayoutManager.setOrientation(0);
            linearLayoutManager.scrollToPosition(Default.WHITEBALANCE);
            this.rv_filterview.setLayoutManager(linearLayoutManager);
            Filter_Adapter filter_Adapter = new Filter_Adapter(this, arrayList, this.preview, SP.WHITEBALANCE);
            this.rv_filterview.setAdapter(filter_Adapter);
            filter_Adapter.notifyItemChanged(Default.WHITEBALANCE);
        }
    }

    public void slideleft(final View view) {
        view.setAlpha(0.0f);
        view.animate().translationX(0.0f).alpha(1.0f).setListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                super.onAnimationStart(animator);
                view.setVisibility(View.VISIBLE);
            }
        });
    }

    public void slideright(final View view) {
        view.animate().translationX(1000.0f).alpha(0.2f).setListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animator) {
                view.setVisibility(View.GONE);
                super.onAnimationEnd(animator);
            }
        });
    }


    public void closeDrawer() {
        this.mDrawerLayout.closeDrawer(3);
    }

    public void lockDrawer() {
        this.mDrawerLayout.setDrawerLockMode(1);
    }

    public void unLockDrawer() {
        this.mDrawerLayout.setDrawerLockMode(0);
    }

    public void setUpStampLayout() {
        String s5;
        int v5;
        int v4;
        int v3;
        int v2;
        CameraMainActivity mainActivity0 = this;
        this.setMapType();
        mainActivity0.mWeatherIcon = this.getResources().obtainTypedArray(R.array.wI);  // array:wI
        int v = mainActivity0.mSP.getInteger(mainActivity0, "template_type", 0);
        int v1 = v == 0 ? mainActivity0.mSP.getInteger(mainActivity0, "BACKGROUND_COLOR", Color.parseColor("#9c000000")) : mainActivity0.mSP.getInteger(mainActivity0, "BACKGROUND_COLOR_CLASSIC", Color.parseColor("#9c000000"));
        boolean z = this.getResources().getBoolean(R.bool.isTablet);  // bool:isTablet
        if (v == 0) {
            mainActivity0.isMap = mainActivity0.mSP.getBoolean(mainActivity0, "is_map", true);
            mainActivity0.isAddress = mainActivity0.mSP.getBoolean(mainActivity0, "is_address", true);
            mainActivity0.isLatLng = mainActivity0.mSP.getBoolean(mainActivity0, "is_lat_lng_template", true);
            mainActivity0.isPlusCode = mainActivity0.mSP.getBoolean(mainActivity0, "is_plus_code", false);
            mainActivity0.isWeather = mainActivity0.mSP.getBoolean(mainActivity0, "is_weather", false);
            mainActivity0.isDateTime = mainActivity0.mSP.getBoolean(mainActivity0, "is_date_time", true);
            mainActivity0.istimezone = mainActivity0.mSP.getBoolean(mainActivity0, "is_timezone", true);
            mainActivity0.isNumbering = mainActivity0.mSP.getBoolean(mainActivity0, "is_numbering", false);
            mainActivity0.isIncrement = mainActivity0.mSP.getBoolean(mainActivity0, "is_increment", true);
            mainActivity0.isMagneticField = mainActivity0.mSP.getBoolean(mainActivity0, "is_magnetic_field", false);
            mainActivity0.isCompass = mainActivity0.mSP.getBoolean(mainActivity0, "is_compass", false);
            mainActivity0.isCompassFound = mainActivity0.mSP.getBoolean(mainActivity0, "compass_found", false);
            mainActivity0.isLogo = mainActivity0.mSP.getBoolean(mainActivity0, "is_logo", false);
            mainActivity0.isNotes = mainActivity0.mSP.getBoolean(mainActivity0, "is_notes", false);
            mainActivity0.isHumidity = mainActivity0.mSP.getBoolean(mainActivity0, "is_humidity", false);
            mainActivity0.isAccuracy = mainActivity0.mSP.getBoolean(mainActivity0, "is_accuracy", false);
            mainActivity0.isAltitude = mainActivity0.mSP.getBoolean(mainActivity0, "is_altitude", false);
            mainActivity0.isWind = mainActivity0.mSP.getBoolean(mainActivity0, "is_wind", false);
            mainActivity0.isPressure = mainActivity0.mSP.getBoolean(mainActivity0, "is_pressure", false);
            mainActivity0.stamp_size = mainActivity0.mSP.getString(mainActivity0, "stamp_size", "Medium");
            mainActivity0.pluscode_type = mainActivity0.mSP.getString(mainActivity0, "plusCodeType", "accurate");
            mainActivity0.address_color = mainActivity0.mSP.getInteger(mainActivity0, "ADDRESS_COLOR", -1);
            mainActivity0.altitude_color = mainActivity0.mSP.getInteger(mainActivity0, "ALTITUDE_COLOR", -1);
            mainActivity0.accurcy_color = mainActivity0.mSP.getInteger(mainActivity0, "ACCURACY_COLOR", -1);
            mainActivity0.wind_color = mainActivity0.mSP.getInteger(mainActivity0, "WIND_COLOR", -1);
            mainActivity0.pressure_color = mainActivity0.mSP.getInteger(mainActivity0, "PRESSURE_COLOR", -1);
            mainActivity0.humidity_color = mainActivity0.mSP.getInteger(mainActivity0, "HUMIDITY_COLOR", -1);
            mainActivity0.date_time_color = mainActivity0.mSP.getInteger(mainActivity0, "DATE_TIME_COLOR", -1);
            mainActivity0.plus_code_color = mainActivity0.mSP.getInteger(mainActivity0, "PLUS_CODE_COLOR", -1);
            mainActivity0.numbering_color = mainActivity0.mSP.getInteger(mainActivity0, "NUMBERING_COLOR", -1);
            mainActivity0.sequence = mainActivity0.mSP.getInteger(mainActivity0, "SEQUENCE", 1);
            mainActivity0.prefix = mainActivity0.mSP.getString(mainActivity0, "PREFIX", "");
            mainActivity0.suffix = mainActivity0.mSP.getString(mainActivity0, "SUFFIX", "");
            mainActivity0.Notes_color = mainActivity0.mSP.getInteger(mainActivity0, "NOTES_HASHTAG_COLOR", -1);
            mainActivity0.lat_lng_color = mainActivity0.mSP.getInteger(mainActivity0, "LAT_LNG_COLOR", -1);
            v2 = mainActivity0.mSP.getInteger(mainActivity0, "WEATHER_COLOR", -1);
            v3 = mainActivity0.mSP.getInteger(mainActivity0, "MAGNETIC_FIELD_COLOR", -1);
            v4 = mainActivity0.mSP.getInteger(mainActivity0, "COMPASS_COLOR", -1);
            mainActivity0.mDateFormat = mainActivity0.mSP.getString(mainActivity0, "date_format", "dd/MM/yy hh:mm a");
            mainActivity0.mLatLngType = mainActivity0.mSP.getInteger(mainActivity0, "lat_lng_type_1", 1);
            mainActivity0.mWindtype = mainActivity0.mSP.getInteger(mainActivity0, "wind_select", 0);
            mainActivity0.mPressuretype = mainActivity0.mSP.getInteger(mainActivity0, "pressure_select", 0);
            mainActivity0.mAltitudetype = mainActivity0.mSP.getInteger(mainActivity0, "altitude_select", 0);
            mainActivity0.mAccurcytype = mainActivity0.mSP.getInteger(mainActivity0, "accuracy_select", 0);
            mainActivity0.msTemprature_type = mainActivity0.mSP.getString(mainActivity0, "temprature_type", "Celsius");
            mainActivity0.mfTemprature_value = mainActivity0.mSP.getFloat(mainActivity0, "temprature_value");
            mainActivity0.mIconValue = mainActivity0.mSP.getInteger(mainActivity0, "weather_icon", 0);
            mainActivity0.timezone = mainActivity0.mSP.getInteger(mainActivity0, "TIME_ZONE", 6);
            mainActivity0.imgMap.setCornerRadius(this.getResources().getDimension(R.dimen._4dp));  // dimen:_4dp
        } else {
            mainActivity0.isMap = mainActivity0.mSP.getBoolean(mainActivity0, "is_map_classic", true);
            mainActivity0.isAddress = mainActivity0.mSP.getBoolean(mainActivity0, "is_address_classic", true);
            mainActivity0.isLatLng = mainActivity0.mSP.getBoolean(mainActivity0, "is_lat_lng_template_classic", true);
            mainActivity0.isPlusCode = mainActivity0.mSP.getBoolean(mainActivity0, SP.IS_PLUS_CODE, false);
            mainActivity0.isWeather = mainActivity0.mSP.getBoolean(mainActivity0, "is_weather_classic", false);
            mainActivity0.isDateTime = mainActivity0.mSP.getBoolean(mainActivity0, "is_date_time_classic", true);
            mainActivity0.istimezone = mainActivity0.mSP.getBoolean(mainActivity0, "is_timezone_classic", true);
            mainActivity0.isNumbering = mainActivity0.mSP.getBoolean(mainActivity0, "is_numbering_classic", false);
            mainActivity0.isIncrement = mainActivity0.mSP.getBoolean(mainActivity0, "is_increment_classic", true);
            mainActivity0.isMagneticField = mainActivity0.mSP.getBoolean(mainActivity0, "is_magnetic_field_classic", false);
            mainActivity0.isCompass = mainActivity0.mSP.getBoolean(mainActivity0, "is_compass_classic", false);
            mainActivity0.isCompassFound = mainActivity0.mSP.getBoolean(mainActivity0, "compass_found", false);
            mainActivity0.isLogo = mainActivity0.mSP.getBoolean(mainActivity0, "is_logo_classic", false);
            mainActivity0.isNotes = mainActivity0.mSP.getBoolean(mainActivity0, "is_notes_classic", false);
            mainActivity0.isHumidity = mainActivity0.mSP.getBoolean(mainActivity0, "is_humidity_classic", false);
            mainActivity0.isAccuracy = mainActivity0.mSP.getBoolean(mainActivity0, "is_accuracy_classic", false);
            mainActivity0.isAltitude = mainActivity0.mSP.getBoolean(mainActivity0, "is_altitude_classic", false);
            mainActivity0.isWind = mainActivity0.mSP.getBoolean(mainActivity0, "is_wind_classic", false);
            mainActivity0.isPressure = mainActivity0.mSP.getBoolean(mainActivity0, "is_pressure_classic", false);
            mainActivity0.stamp_size = mainActivity0.mSP.getString(mainActivity0, "stamp_size_classic", "Medium");
            mainActivity0.pluscode_type = mainActivity0.mSP.getString(mainActivity0, "plusCodeType_classic", "accurate");
            mainActivity0.address_color = mainActivity0.mSP.getInteger(mainActivity0, "ADDRESS_COLOR_CLASSIC", -1);
            mainActivity0.altitude_color = mainActivity0.mSP.getInteger(mainActivity0, "ALTITUDE_COLOR_CLASSIC", -1);
            mainActivity0.numbering_color = mainActivity0.mSP.getInteger(mainActivity0, "NUMBERING_COLOR_CLASSIC", -1);
            mainActivity0.sequence = mainActivity0.mSP.getInteger(mainActivity0, "SEQUENCE_CLASSIC", 1);
            mainActivity0.prefix = mainActivity0.mSP.getString(mainActivity0, "PREFIX_CLASSIC", "");
            mainActivity0.suffix = mainActivity0.mSP.getString(mainActivity0, "SUFFIX_CLASSIC", "");
            mainActivity0.accurcy_color = mainActivity0.mSP.getInteger(mainActivity0, "ACCURACY_COLOR_CLASSIC", -1);
            mainActivity0.wind_color = mainActivity0.mSP.getInteger(mainActivity0, "WIND_COLOR_CLASSIC", -1);
            mainActivity0.pressure_color = mainActivity0.mSP.getInteger(mainActivity0, "PRESSURE_COLOR_CLASSIC", -1);
            mainActivity0.humidity_color = mainActivity0.mSP.getInteger(mainActivity0, "HUMIDITY_COLOR_CLASSIC", -1);
            mainActivity0.date_time_color = mainActivity0.mSP.getInteger(mainActivity0, "DATE_TIME_COLOR_CLASSIC", -1);
            mainActivity0.plus_code_color = mainActivity0.mSP.getInteger(mainActivity0, "PLUS_CODE_COLOR_CLASSIC", -1);
            mainActivity0.Notes_color = mainActivity0.mSP.getInteger(mainActivity0, "NOTES_HASHTAG_COLOR_CLASSIC", -1);
            mainActivity0.lat_lng_color = mainActivity0.mSP.getInteger(mainActivity0, "LAT_LNG_COLOR_CLASSIC", -1);
            v2 = mainActivity0.mSP.getInteger(mainActivity0, "WEATHER_COLOR_CLASSIC", -1);
            v3 = mainActivity0.mSP.getInteger(mainActivity0, "MAGNETIC_FIELD_COLOR_CLASSIC", -1);
            v4 = mainActivity0.mSP.getInteger(mainActivity0, "COMPASS_COLOR_CLASSIC", -1);
            mainActivity0.mDateFormat = mainActivity0.mSP.getString(mainActivity0, "date_format_classic", "dd/MM/yy hh:mm a");
            mainActivity0.mLatLngType = mainActivity0.mSP.getInteger(mainActivity0, "lat_lng_type_1_classic", 1);
            mainActivity0.mWindtype = mainActivity0.mSP.getInteger(mainActivity0, "wind_select_classic", 0);
            mainActivity0.mPressuretype = mainActivity0.mSP.getInteger(mainActivity0, "pressure_select_classic", 0);
            mainActivity0.mAltitudetype = mainActivity0.mSP.getInteger(mainActivity0, "altitude_select_classic", 0);
            mainActivity0.mAccurcytype = mainActivity0.mSP.getInteger(mainActivity0, "accuracy_select_classic", 0);
            mainActivity0.msTemprature_type = mainActivity0.mSP.getString(mainActivity0, "temprature_type_classic", "Celsius");
            mainActivity0.mfTemprature_value = mainActivity0.mSP.getFloat(mainActivity0, "temprature_value");
            mainActivity0.mIconValue = mainActivity0.mSP.getInteger(mainActivity0, "weather_icon", 0);
            mainActivity0.timezone = mainActivity0.mSP.getInteger(mainActivity0, "TIME_ZONE_CLASSIC", 6);
            mainActivity0.imgMap.setCornerRadius(0.0f);
        }

        LinearLayout.LayoutParams linearLayout$LayoutParams0 = new LinearLayout.LayoutParams(-1, -2);
        new LinearLayout.LayoutParams(((int) this.getResources().getDimension(R.dimen.stamp_icon_size_110)), ((int) this.getResources().getDimension(R.dimen.stamp_icon_size_110)));  // dimen:stamp_icon_size_110
        LinearLayout.LayoutParams linearLayout$LayoutParams1 = mainActivity0.stamp_size.equals("Large") ? new LinearLayout.LayoutParams(((int) this.getResources().getDimension(R.dimen.stamp_icon_size_110)), ((int) this.getResources().getDimension(R.dimen.stamp_icon_size_110))) : new LinearLayout.LayoutParams(((int) this.getResources().getDimension(R.dimen.stamp_icon_size_110)), ((int) this.getResources().getDimension(R.dimen.stamp_80dp)));  // dimen:stamp_icon_size_110
        if (mainActivity0.isMap) {
            mainActivity0.imgMap.setVisibility(View.VISIBLE);
            if (v == 0) {
                linearLayout$LayoutParams0.setMargins(((int) this.getResources().getDimension(R.dimen._8dp)), 0, 0, 0);  // dimen:_8dp
                linearLayout$LayoutParams1.setMargins(((int) this.getResources().getDimension(R.dimen._8dp)), 0, 0, 0);  // dimen:_8dp
                if (mainActivity0.stamp_size.equals("Large")) {
                    v5 = v4;
                    mainActivity0.li_main_stamp_lay.setPadding(((int) this.getResources().getDimension(R.dimen._8dp)), ((int) this.getResources().getDimension(R.dimen._8dp)), ((int) this.getResources().getDimension(R.dimen._8dp)), ((int) this.getResources().getDimension(R.dimen._8dp)));  // dimen:_8dp
                } else {
                    v5 = v4;
                    mainActivity0.li_main_stamp_lay.setPadding(((int) this.getResources().getDimension(R.dimen._16dp)), ((int) this.getResources().getDimension(R.dimen._8dp)), ((int) this.getResources().getDimension(R.dimen._16dp)), ((int) this.getResources().getDimension(R.dimen._8dp)));  // dimen:_16dp
                }

                linearLayout$LayoutParams1.gravity = 80;
            } else {
                v5 = v4;
                linearLayout$LayoutParams0.setMargins(0, 0, 0, 0);
                linearLayout$LayoutParams1.setMargins(0, 0, 0, 0);
                linearLayout$LayoutParams1.gravity = 80;
                mainActivity0.li_main_stamp_lay.setPadding(((int) this.getResources().getDimension(R.dimen._8dp)), ((int) this.getResources().getDimension(R.dimen._8dp)),
                        ((int) this.getResources().getDimension(R.dimen._12dp)), ((int) this.getResources().getDimension(R.dimen._8dp)));  // dimen:_8dp
                mainActivity0.imgMap.setLayoutParams(linearLayout$LayoutParams1);
            }
        } else {
            v5 = v4;
            mainActivity0.imgMap.setVisibility(View.GONE);
            if (v == 0) {
                linearLayout$LayoutParams0.setMargins(((int) this.getResources().getDimension(R.dimen._8dp)), 0, 0, 0);  // dimen:_8dp
            } else {
                linearLayout$LayoutParams0.setMargins(0, 0, 0, 0);
            }
        }

        mainActivity0.li_stamp.setLayoutParams(linearLayout$LayoutParams0);
        if (mainActivity0.isWeather) {
            mainActivity0.li_weather.setVisibility(View.VISIBLE);
        } else {
            mainActivity0.li_weather.setVisibility(View.GONE);
        }

        if (!mainActivity0.isHumidity && !mainActivity0.isAccuracy && !mainActivity0.isAltitude && !mainActivity0.isWind && !mainActivity0.isPressure) {
            mainActivity0.lin_bottom_wether.setVisibility(View.GONE);
        } else {
            mainActivity0.lin_bottom_wether.setVisibility(View.VISIBLE);
            if (z) {
                LinearLayout.LayoutParams linearLayout$LayoutParams2 = (LinearLayout.LayoutParams) mainActivity0.lin_bottom_wether.getLayoutParams();
                linearLayout$LayoutParams2.height += 3;
            }
        }

        if (mainActivity0.isHumidity) {
            mainActivity0.lin_humity_stamp.setVisibility(View.VISIBLE);
        } else {
            mainActivity0.lin_humity_stamp.setVisibility(View.GONE);
        }

        if (mainActivity0.isWind) {
            mainActivity0.lin_wind_stamp.setVisibility(View.VISIBLE);
        } else {
            mainActivity0.lin_wind_stamp.setVisibility(View.GONE);
        }

        if (mainActivity0.isPressure) {
            mainActivity0.lin_pressure_stamp.setVisibility(View.VISIBLE);
        } else {
            mainActivity0.lin_pressure_stamp.setVisibility(View.GONE);
        }

        if (mainActivity0.isAltitude) {
            String s = Util.getAltitudeconvert(mainActivity0, (v == 0 ? mainActivity0.mSP.getInteger(mainActivity0, "altitude_select", 0) : mainActivity0.mSP.getInteger(mainActivity0, "altitude_select_classic", 0)));
            if (mainActivity0.lin_pressure_stamp.getVisibility() == 8) {
                mainActivity0.lin_pressure_stamp.setVisibility(View.VISIBLE);
                mainActivity0.img_pressure_stamp.setImageResource(R.drawable.ic_altitiude);  // drawable:ic_altitiude
                mainActivity0.txt_pressure.setText(s);
                mainActivity0.txt_pressure.setTextColor(mainActivity0.altitude_color);
            } else if (mainActivity0.lin_wind_stamp.getVisibility() == 8) {
                mainActivity0.lin_wind_stamp.setVisibility(View.VISIBLE);
                mainActivity0.img_wind_stamp.setImageResource(R.drawable.ic_altitiude);  // drawable:ic_altitiude
                mainActivity0.txt_wind.setText(s);
                mainActivity0.txt_wind.setTextColor(mainActivity0.altitude_color);
            } else if (mainActivity0.lin_humity_stamp.getVisibility() == 8) {
                mainActivity0.lin_humity_stamp.setVisibility(View.VISIBLE);
                mainActivity0.img_humidity_stamp.setImageResource(R.drawable.ic_altitiude);  // drawable:ic_altitiude
                mainActivity0.txt_humidity.setText(s);
                mainActivity0.txt_humidity.setTextColor(mainActivity0.altitude_color);
            }
        }

        if (mainActivity0.isAccuracy) {
            String s1 = Util.getAccuracy(mainActivity0, (v == 0 ? mainActivity0.mSP.getInteger(mainActivity0, "accuracy_select", 0) : mainActivity0.mSP.getInteger(mainActivity0, "accuracy_select_classic", 0)));
            if (mainActivity0.lin_pressure_stamp.getVisibility() == 8) {
                mainActivity0.lin_pressure_stamp.setVisibility(View.VISIBLE);
                mainActivity0.img_pressure_stamp.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
                mainActivity0.txt_pressure.setText(s1);
                mainActivity0.txt_pressure.setTextColor(mainActivity0.accurcy_color);
            } else if (mainActivity0.lin_wind_stamp.getVisibility() == 8) {
                mainActivity0.lin_wind_stamp.setVisibility(View.VISIBLE);
                mainActivity0.img_wind_stamp.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
                mainActivity0.txt_wind.setText(s1);
                mainActivity0.txt_wind.setTextColor(mainActivity0.accurcy_color);
            } else if (mainActivity0.lin_humity_stamp.getVisibility() == 8) {
                mainActivity0.lin_humity_stamp.setVisibility(View.VISIBLE);
                mainActivity0.img_humidity_stamp.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
                mainActivity0.txt_humidity.setText(s1);
                mainActivity0.txt_humidity.setTextColor(mainActivity0.accurcy_color);
            }
        }

        if (mainActivity0.isCompassFound) {
            if (mainActivity0.isMagneticField) {
                mainActivity0.li_magnetic_field.setVisibility(View.VISIBLE);
            } else {
                mainActivity0.li_magnetic_field.setVisibility(View.GONE);
            }

            if (mainActivity0.isCompass) {
                mainActivity0.li_compass.setVisibility(View.VISIBLE);
            } else {
                mainActivity0.li_compass.setVisibility(View.GONE);
            }
        } else {
            mainActivity0.li_magnetic_field.setVisibility(View.GONE);
            mainActivity0.li_compass.setVisibility(View.GONE);
        }

        if (mainActivity0.isLogo) {
            mainActivity0.li_logo.setVisibility(View.VISIBLE);
        } else {
            mainActivity0.li_logo.setVisibility(View.GONE);
        }

        if (!mainActivity0.isWeather && !mainActivity0.isMagneticField && !mainActivity0.isCompass && !mainActivity0.isLogo) {
            mainActivity0.li_rightView.setVisibility(View.GONE);
        } else {
            mainActivity0.li_rightView.setVisibility(View.VISIBLE);
        }

        if (mainActivity0.stamp_size.equals("Medium")) {
            ViewGroup.LayoutParams viewGroup$LayoutParams0 = mainActivity0.imgLogo.getLayoutParams();
            viewGroup$LayoutParams0.height = Util.dpToPx(mainActivity0, 30);
            ViewGroup.LayoutParams viewGroup$LayoutParams1 = mainActivity0.imgLogo.getLayoutParams();
            viewGroup$LayoutParams1.width = Util.dpToPx(mainActivity0, 58);
            ViewGroup.LayoutParams viewGroup$LayoutParams2 = mainActivity0.imgWeather.getLayoutParams();
            viewGroup$LayoutParams2.height = Util.dpToPx(mainActivity0, 16);
            ViewGroup.LayoutParams viewGroup$LayoutParams3 = mainActivity0.imgWeather.getLayoutParams();
            viewGroup$LayoutParams3.width = Util.dpToPx(mainActivity0, 16);
            ViewGroup.LayoutParams viewGroup$LayoutParams4 = mainActivity0.imgCompass.getLayoutParams();
            viewGroup$LayoutParams4.height = Util.dpToPx(mainActivity0, 16);
            ViewGroup.LayoutParams viewGroup$LayoutParams5 = mainActivity0.imgCompass.getLayoutParams();
            viewGroup$LayoutParams5.width = Util.dpToPx(mainActivity0, 16);
            ViewGroup.LayoutParams viewGroup$LayoutParams6 = mainActivity0.img_humidity_stamp.getLayoutParams();
            viewGroup$LayoutParams6.height = Util.dpToPx(mainActivity0, 16);
            ViewGroup.LayoutParams viewGroup$LayoutParams7 = mainActivity0.img_humidity_stamp.getLayoutParams();
            viewGroup$LayoutParams7.width = Util.dpToPx(mainActivity0, 16);
            ViewGroup.LayoutParams viewGroup$LayoutParams8 = mainActivity0.img_pressure_stamp.getLayoutParams();
            viewGroup$LayoutParams8.height = Util.dpToPx(mainActivity0, 16);
            ViewGroup.LayoutParams viewGroup$LayoutParams9 = mainActivity0.img_pressure_stamp.getLayoutParams();
            viewGroup$LayoutParams9.width = Util.dpToPx(mainActivity0, 16);
            ViewGroup.LayoutParams viewGroup$LayoutParams10 = mainActivity0.img_wind_stamp.getLayoutParams();
            viewGroup$LayoutParams10.height = Util.dpToPx(mainActivity0, 16);
            ViewGroup.LayoutParams viewGroup$LayoutParams11 = mainActivity0.img_wind_stamp.getLayoutParams();
            viewGroup$LayoutParams11.width = Util.dpToPx(mainActivity0, 16);
            ViewGroup.LayoutParams viewGroup$LayoutParams12 = mainActivity0.img_magnetic_field.getLayoutParams();
            viewGroup$LayoutParams12.height = Util.dpToPx(mainActivity0, 16);
            ViewGroup.LayoutParams viewGroup$LayoutParams13 = mainActivity0.img_magnetic_field.getLayoutParams();
            viewGroup$LayoutParams13.width = Util.dpToPx(mainActivity0, 16);
            mainActivity0.txt_wind.setTextSize(10.0f);
            mainActivity0.txt_pressure.setTextSize(10.0f);
            mainActivity0.txt_humidity.setTextSize(10.0f);
            mainActivity0.tv_weather.setTextSize(10.0f);
            mainActivity0.tv_compass.setTextSize(10.0f);
            mainActivity0.tv_magnetic_field.setTextSize(10.0f);
        } else if (mainActivity0.stamp_size.equals("Small")) {
            ViewGroup.LayoutParams viewGroup$LayoutParams14 = mainActivity0.imgLogo.getLayoutParams();
            viewGroup$LayoutParams14.height = Util.dpToPx(mainActivity0, 28);
            ViewGroup.LayoutParams viewGroup$LayoutParams15 = mainActivity0.imgLogo.getLayoutParams();
            viewGroup$LayoutParams15.width = Util.dpToPx(mainActivity0, 54);
            ViewGroup.LayoutParams viewGroup$LayoutParams16 = mainActivity0.imgWeather.getLayoutParams();
            viewGroup$LayoutParams16.height = Util.dpToPx(mainActivity0, 14);
            ViewGroup.LayoutParams viewGroup$LayoutParams17 = mainActivity0.imgWeather.getLayoutParams();
            viewGroup$LayoutParams17.width = Util.dpToPx(mainActivity0, 14);
            ViewGroup.LayoutParams viewGroup$LayoutParams18 = mainActivity0.imgCompass.getLayoutParams();
            viewGroup$LayoutParams18.height = Util.dpToPx(mainActivity0, 14);
            ViewGroup.LayoutParams viewGroup$LayoutParams19 = mainActivity0.imgCompass.getLayoutParams();
            viewGroup$LayoutParams19.width = Util.dpToPx(mainActivity0, 14);
            ViewGroup.LayoutParams viewGroup$LayoutParams20 = mainActivity0.img_humidity_stamp.getLayoutParams();
            viewGroup$LayoutParams20.height = Util.dpToPx(mainActivity0, 14);
            ViewGroup.LayoutParams viewGroup$LayoutParams21 = mainActivity0.img_humidity_stamp.getLayoutParams();
            viewGroup$LayoutParams21.width = Util.dpToPx(mainActivity0, 14);
            ViewGroup.LayoutParams viewGroup$LayoutParams22 = mainActivity0.img_pressure_stamp.getLayoutParams();
            viewGroup$LayoutParams22.height = Util.dpToPx(mainActivity0, 14);
            ViewGroup.LayoutParams viewGroup$LayoutParams23 = mainActivity0.img_pressure_stamp.getLayoutParams();
            viewGroup$LayoutParams23.width = Util.dpToPx(mainActivity0, 14);
            ViewGroup.LayoutParams viewGroup$LayoutParams24 = mainActivity0.img_wind_stamp.getLayoutParams();
            viewGroup$LayoutParams24.height = Util.dpToPx(mainActivity0, 14);
            ViewGroup.LayoutParams viewGroup$LayoutParams25 = mainActivity0.img_wind_stamp.getLayoutParams();
            viewGroup$LayoutParams25.width = Util.dpToPx(mainActivity0, 14);
            ViewGroup.LayoutParams viewGroup$LayoutParams26 = mainActivity0.img_magnetic_field.getLayoutParams();
            viewGroup$LayoutParams26.height = Util.dpToPx(mainActivity0, 14);
            ViewGroup.LayoutParams viewGroup$LayoutParams27 = mainActivity0.img_magnetic_field.getLayoutParams();
            viewGroup$LayoutParams27.width = Util.dpToPx(mainActivity0, 14);
            mainActivity0.txt_wind.setTextSize(8.0f);
            mainActivity0.txt_pressure.setTextSize(8.0f);
            mainActivity0.txt_humidity.setTextSize(8.0f);
            mainActivity0.tv_weather.setTextSize(8.0f);
            mainActivity0.tv_compass.setTextSize(8.0f);
            mainActivity0.tv_magnetic_field.setTextSize(8.0f);
        } else if (mainActivity0.stamp_size.equals("Extra Small")) {
            ViewGroup.LayoutParams viewGroup$LayoutParams28 = mainActivity0.imgLogo.getLayoutParams();
            viewGroup$LayoutParams28.height = Util.dpToPx(mainActivity0, 26);
            ViewGroup.LayoutParams viewGroup$LayoutParams29 = mainActivity0.imgLogo.getLayoutParams();
            viewGroup$LayoutParams29.width = Util.dpToPx(mainActivity0, 50);
            ViewGroup.LayoutParams viewGroup$LayoutParams30 = mainActivity0.imgWeather.getLayoutParams();
            viewGroup$LayoutParams30.height = Util.dpToPx(mainActivity0, 12);
            ViewGroup.LayoutParams viewGroup$LayoutParams31 = mainActivity0.imgWeather.getLayoutParams();
            viewGroup$LayoutParams31.width = Util.dpToPx(mainActivity0, 12);
            ViewGroup.LayoutParams viewGroup$LayoutParams32 = mainActivity0.imgCompass.getLayoutParams();
            viewGroup$LayoutParams32.height = Util.dpToPx(mainActivity0, 12);
            ViewGroup.LayoutParams viewGroup$LayoutParams33 = mainActivity0.imgCompass.getLayoutParams();
            viewGroup$LayoutParams33.width = Util.dpToPx(mainActivity0, 12);
            ViewGroup.LayoutParams viewGroup$LayoutParams34 = mainActivity0.img_humidity_stamp.getLayoutParams();
            viewGroup$LayoutParams34.height = Util.dpToPx(mainActivity0, 12);
            ViewGroup.LayoutParams viewGroup$LayoutParams35 = mainActivity0.img_humidity_stamp.getLayoutParams();
            viewGroup$LayoutParams35.width = Util.dpToPx(mainActivity0, 12);
            ViewGroup.LayoutParams viewGroup$LayoutParams36 = mainActivity0.img_pressure_stamp.getLayoutParams();
            viewGroup$LayoutParams36.height = Util.dpToPx(mainActivity0, 12);
            ViewGroup.LayoutParams viewGroup$LayoutParams37 = mainActivity0.img_pressure_stamp.getLayoutParams();
            viewGroup$LayoutParams37.width = Util.dpToPx(mainActivity0, 12);
            ViewGroup.LayoutParams viewGroup$LayoutParams38 = mainActivity0.img_wind_stamp.getLayoutParams();
            viewGroup$LayoutParams38.height = Util.dpToPx(mainActivity0, 12);
            ViewGroup.LayoutParams viewGroup$LayoutParams39 = mainActivity0.img_wind_stamp.getLayoutParams();
            viewGroup$LayoutParams39.width = Util.dpToPx(mainActivity0, 12);
            ViewGroup.LayoutParams viewGroup$LayoutParams40 = mainActivity0.img_magnetic_field.getLayoutParams();
            viewGroup$LayoutParams40.height = Util.dpToPx(mainActivity0, 12);
            ViewGroup.LayoutParams viewGroup$LayoutParams41 = mainActivity0.img_magnetic_field.getLayoutParams();
            viewGroup$LayoutParams41.width = Util.dpToPx(mainActivity0, 12);
            mainActivity0.txt_wind.setTextSize(6.0f);
            mainActivity0.txt_pressure.setTextSize(6.0f);
            mainActivity0.txt_humidity.setTextSize(6.0f);
            mainActivity0.tv_weather.setTextSize(6.0f);
            mainActivity0.tv_compass.setTextSize(6.0f);
            mainActivity0.tv_magnetic_field.setTextSize(6.0f);
        } else {
            ViewGroup.LayoutParams viewGroup$LayoutParams42 = mainActivity0.imgLogo.getLayoutParams();
            viewGroup$LayoutParams42.height = Util.dpToPx(mainActivity0, 0x20);
            ViewGroup.LayoutParams viewGroup$LayoutParams43 = mainActivity0.imgLogo.getLayoutParams();
            viewGroup$LayoutParams43.width = Util.dpToPx(mainActivity0, 62);
            ViewGroup.LayoutParams viewGroup$LayoutParams44 = mainActivity0.imgWeather.getLayoutParams();
            viewGroup$LayoutParams44.height = Util.dpToPx(mainActivity0, 18);
            ViewGroup.LayoutParams viewGroup$LayoutParams45 = mainActivity0.imgWeather.getLayoutParams();
            viewGroup$LayoutParams45.width = Util.dpToPx(mainActivity0, 18);
            ViewGroup.LayoutParams viewGroup$LayoutParams46 = mainActivity0.imgCompass.getLayoutParams();
            viewGroup$LayoutParams46.height = Util.dpToPx(mainActivity0, 18);
            ViewGroup.LayoutParams viewGroup$LayoutParams47 = mainActivity0.imgCompass.getLayoutParams();
            viewGroup$LayoutParams47.width = Util.dpToPx(mainActivity0, 18);
            ViewGroup.LayoutParams viewGroup$LayoutParams48 = mainActivity0.img_humidity_stamp.getLayoutParams();
            viewGroup$LayoutParams48.height = Util.dpToPx(mainActivity0, 18);
            ViewGroup.LayoutParams viewGroup$LayoutParams49 = mainActivity0.img_humidity_stamp.getLayoutParams();
            viewGroup$LayoutParams49.width = Util.dpToPx(mainActivity0, 18);
            ViewGroup.LayoutParams viewGroup$LayoutParams50 = mainActivity0.img_pressure_stamp.getLayoutParams();
            viewGroup$LayoutParams50.height = Util.dpToPx(mainActivity0, 18);
            ViewGroup.LayoutParams viewGroup$LayoutParams51 = mainActivity0.img_pressure_stamp.getLayoutParams();
            viewGroup$LayoutParams51.width = Util.dpToPx(mainActivity0, 18);
            ViewGroup.LayoutParams viewGroup$LayoutParams52 = mainActivity0.img_wind_stamp.getLayoutParams();
            viewGroup$LayoutParams52.height = Util.dpToPx(mainActivity0, 18);
            ViewGroup.LayoutParams viewGroup$LayoutParams53 = mainActivity0.img_wind_stamp.getLayoutParams();
            viewGroup$LayoutParams53.width = Util.dpToPx(mainActivity0, 18);
            ViewGroup.LayoutParams viewGroup$LayoutParams54 = mainActivity0.img_magnetic_field.getLayoutParams();
            viewGroup$LayoutParams54.height = Util.dpToPx(mainActivity0, 18);
            ViewGroup.LayoutParams viewGroup$LayoutParams55 = mainActivity0.img_magnetic_field.getLayoutParams();
            viewGroup$LayoutParams55.width = Util.dpToPx(mainActivity0, 18);
            mainActivity0.txt_wind.setTextSize(12.0f);
            mainActivity0.txt_pressure.setTextSize(12.0f);
            mainActivity0.txt_humidity.setTextSize(12.0f);
            mainActivity0.tv_weather.setTextSize(12.0f);
            mainActivity0.tv_compass.setTextSize(12.0f);
            mainActivity0.tv_magnetic_field.setTextSize(12.0f);
        }

        if (mainActivity0.isAddress) {
            if (!mainActivity0.isNumbering && !mainActivity0.isPlusCode) {
                mainActivity0.tv_address_line_1.setMaxLines(10);
            } else {
                mainActivity0.tv_address_line_1.setMaxLines(12);
            }
        } else if (!mainActivity0.isMap && (!mainActivity0.isWeather && !mainActivity0.isMagneticField && !mainActivity0.isCompass && !mainActivity0.isLatLng && (mainActivity0.isDateTime) || !mainActivity0.isWeather && !mainActivity0.isMagneticField && !mainActivity0.isCompass && !mainActivity0.isDateTime && (mainActivity0.isLatLng) || ((mainActivity0.isWeather) || (mainActivity0.isCompass) || (mainActivity0.isMagneticField)) && (mainActivity0.isDateTime) && !mainActivity0.isLatLng || ((mainActivity0.isWeather) || (mainActivity0.isCompass) || (mainActivity0.isMagneticField)) && !mainActivity0.isDateTime && (mainActivity0.isLatLng))) {
            if (((mainActivity0.isDateTime) || (mainActivity0.isLatLng)) && (mainActivity0.isNotes)) {
                if (!mainActivity0.isNumbering && !mainActivity0.isPlusCode) {
                    mainActivity0.tv_address_line_1.setMaxLines(3);
                } else {
                    mainActivity0.tv_address_line_1.setMaxLines(5);
                }
            } else if (!mainActivity0.isNumbering && !mainActivity0.istimezone && !mainActivity0.isPlusCode) {
                mainActivity0.tv_address_line_1.setMaxLines(1);
            } else {
                mainActivity0.tv_address_line_1.setMaxLines(3);
            }
        } else if (!mainActivity0.isNumbering && !mainActivity0.isPlusCode) {
            mainActivity0.tv_address_line_1.setMaxLines(10);
        } else {
            mainActivity0.tv_address_line_1.setMaxLines(12);
        }

        if (mainActivity0.isMap) {
            boolean z1 = mainActivity0.isAddress;
            if ((z1) && (mainActivity0.isLatLng)) {
                mainActivity0.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 0.0f, this.getResources().getDisplayMetrics()), 1.0f);
            } else if ((z1) && ((mainActivity0.isWeather) || (mainActivity0.isMagneticField) || (mainActivity0.isCompass))) {
                mainActivity0.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, this.getResources().getDisplayMetrics()), 1.0f);
            } else if (!mainActivity0.isWeather && !mainActivity0.isMagneticField && !mainActivity0.isCompass) {
                mainActivity0.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, this.getResources().getDisplayMetrics()), 1.2f);
            } else {
                mainActivity0.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 5.0f, this.getResources().getDisplayMetrics()), 1.0f);
            }

            String s2 = mainActivity0.prefix + " " + mainActivity0.sequence + " " + mainActivity0.suffix;
            String s3 = v == 0 ? mainActivity0.mSP.getString(mainActivity0, "notes_hashtag", "Note : Captured by GPS Map Camera") : mainActivity0.mSP.getString(mainActivity0, "notes_hashtag_classic", "Note : Captured by GPS Map Camera");
            String s4 = mainActivity0.address_line_1 == null ? "" : mainActivity0.address_line_1;
            if (!mainActivity0.isLogo) {
                mainActivity0.li_stamp.setPadding(((int) this.getResources().getDimension(R.dimen._4dp)), 0, ((int) this.getResources().getDimension(R.dimen._4dp)), 0);  // dimen:_4dp
                if (!mainActivity0.isNumbering && !mainActivity0.isPlusCode) {
                    if ((mainActivity0.isNotes) && s3.length()>35) {
                        if ((mainActivity0.isAddress) && s4.length()>70) {
                            if (mainActivity0.stamp_size.equals("Large")) {
                                System.out.println("Called           25L");
                                ViewGroup.LayoutParams viewGroup$LayoutParams170 = mainActivity0.li_stamp.getLayoutParams();
                                viewGroup$LayoutParams170.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_136);  // dimen:stamp_icon_size_136
                                ViewGroup.LayoutParams viewGroup$LayoutParams171 = mainActivity0.imgMap.getLayoutParams();
                                viewGroup$LayoutParams171.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_136);  // dimen:stamp_icon_size_136
                            } else if (mainActivity0.stamp_size.equals("Medium")) {
                                System.out.println("Called           25M");
                                ViewGroup.LayoutParams viewGroup$LayoutParams172 = mainActivity0.li_stamp.getLayoutParams();
                                viewGroup$LayoutParams172.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                                ViewGroup.LayoutParams viewGroup$LayoutParams173 = mainActivity0.imgMap.getLayoutParams();
                                viewGroup$LayoutParams173.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                            } else if (mainActivity0.stamp_size.equals("Small")) {
                                System.out.println("Called           25S");
                                ViewGroup.LayoutParams viewGroup$LayoutParams174 = mainActivity0.li_stamp.getLayoutParams();
                                viewGroup$LayoutParams174.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                                ViewGroup.LayoutParams viewGroup$LayoutParams175 = mainActivity0.imgMap.getLayoutParams();
                                viewGroup$LayoutParams175.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                            } else {
                                System.out.println("Called           25");
                                ViewGroup.LayoutParams viewGroup$LayoutParams176 = mainActivity0.li_stamp.getLayoutParams();
                                viewGroup$LayoutParams176.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                                ViewGroup.LayoutParams viewGroup$LayoutParams177 = mainActivity0.imgMap.getLayoutParams();
                                viewGroup$LayoutParams177.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                            }
                        } else if (mainActivity0.stamp_size.equals("Large")) {
                            System.out.println("Called           26L");
                            ViewGroup.LayoutParams viewGroup$LayoutParams178 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams178.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                            ViewGroup.LayoutParams viewGroup$LayoutParams179 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams179.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                        } else if (mainActivity0.stamp_size.equals("Medium")) {
                            System.out.println("Called           26M");
                            ViewGroup.LayoutParams viewGroup$LayoutParams180 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams180.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                            ViewGroup.LayoutParams viewGroup$LayoutParams181 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams181.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                        } else if (mainActivity0.stamp_size.equals("Small")) {
                            System.out.println("Called           26S");
                            ViewGroup.LayoutParams viewGroup$LayoutParams182 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams182.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                            ViewGroup.LayoutParams viewGroup$LayoutParams183 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams183.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                        } else {
                            System.out.println("Called           26");
                            ViewGroup.LayoutParams viewGroup$LayoutParams184 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams184.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_75);  // dimen:stamp_icon_size_75
                            ViewGroup.LayoutParams viewGroup$LayoutParams185 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams185.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_75);  // dimen:stamp_icon_size_75
                        }
                    } else if ((mainActivity0.isAddress) && s4.length()>70) {
                        if (mainActivity0.stamp_size.equals("Large")) {
                            System.out.println("Called           27L");
                            ViewGroup.LayoutParams viewGroup$LayoutParams186 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams186.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                            ViewGroup.LayoutParams viewGroup$LayoutParams187 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams187.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                        } else if (mainActivity0.stamp_size.equals("Medium")) {
                            System.out.println("Called           27M");
                            ViewGroup.LayoutParams viewGroup$LayoutParams188 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams188.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                            ViewGroup.LayoutParams viewGroup$LayoutParams189 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams189.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                        } else if (mainActivity0.stamp_size.equals("Small")) {
                            System.out.println("Called           27S");
                            ViewGroup.LayoutParams viewGroup$LayoutParams190 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams190.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                            ViewGroup.LayoutParams viewGroup$LayoutParams191 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams191.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                        } else {
                            System.out.println("Called           27");
                            ViewGroup.LayoutParams viewGroup$LayoutParams192 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams192.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_75);  // dimen:stamp_icon_size_75
                            ViewGroup.LayoutParams viewGroup$LayoutParams193 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams193.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_75);  // dimen:stamp_icon_size_75
                        }
                    } else if (mainActivity0.stamp_size.equals("Large")) {
                        System.out.println("Called           28L");
                        ViewGroup.LayoutParams viewGroup$LayoutParams194 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams194.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                        ViewGroup.LayoutParams viewGroup$LayoutParams195 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams195.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                    } else if (mainActivity0.stamp_size.equals("Medium")) {
                        System.out.println("Called           28M");
                        ViewGroup.LayoutParams viewGroup$LayoutParams196 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams196.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                        ViewGroup.LayoutParams viewGroup$LayoutParams197 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams197.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                    } else if (mainActivity0.stamp_size.equals("Small")) {
                        System.out.println("Called           28S");
                        ViewGroup.LayoutParams viewGroup$LayoutParams198 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams198.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                        ViewGroup.LayoutParams viewGroup$LayoutParams199 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams199.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                    } else {
                        System.out.println("Called           28");
                        ViewGroup.LayoutParams viewGroup$LayoutParams200 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams200.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_65);  // dimen:stamp_icon_size_65
                        ViewGroup.LayoutParams viewGroup$LayoutParams201 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams201.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_65);  // dimen:stamp_icon_size_65
                    }
                } else if (!mainActivity0.isAccuracy && !mainActivity0.isAltitude && !mainActivity0.isPressure && !mainActivity0.isHumidity && !mainActivity0.isWind) {
                    if ((mainActivity0.isAddress) && s4.length()>70) {
                        if (mainActivity0.stamp_size.equals("Large")) {
                            System.out.println("Called           23L");
                            ViewGroup.LayoutParams viewGroup$LayoutParams202 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams202.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                            ViewGroup.LayoutParams viewGroup$LayoutParams203 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams203.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                        } else if (mainActivity0.stamp_size.equals("Medium")) {
                            System.out.println("Called           23M");
                            ViewGroup.LayoutParams viewGroup$LayoutParams204 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams204.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                            ViewGroup.LayoutParams viewGroup$LayoutParams205 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams205.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                        } else if (mainActivity0.stamp_size.equals("Small")) {
                            System.out.println("Called           23S");
                            ViewGroup.LayoutParams viewGroup$LayoutParams206 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams206.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                            ViewGroup.LayoutParams viewGroup$LayoutParams207 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams207.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                        } else {
                            System.out.println("Called           23");
                            ViewGroup.LayoutParams viewGroup$LayoutParams208 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams208.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_75);  // dimen:stamp_icon_size_75
                            ViewGroup.LayoutParams viewGroup$LayoutParams209 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams209.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_75);  // dimen:stamp_icon_size_75
                        }
                    } else if (mainActivity0.stamp_size.equals("Large")) {
                        System.out.println("Called           24L");
                        ViewGroup.LayoutParams viewGroup$LayoutParams210 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams210.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                        ViewGroup.LayoutParams viewGroup$LayoutParams211 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams211.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                    } else if (mainActivity0.stamp_size.equals("Medium")) {
                        System.out.println("Called           24M");
                        ViewGroup.LayoutParams viewGroup$LayoutParams212 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams212.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                        ViewGroup.LayoutParams viewGroup$LayoutParams213 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams213.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                    } else if (mainActivity0.stamp_size.equals("Small")) {
                        System.out.println("Called           24S");
                        ViewGroup.LayoutParams viewGroup$LayoutParams214 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams214.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                        ViewGroup.LayoutParams viewGroup$LayoutParams215 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams215.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                    } else {
                        System.out.println("Called           24");
                        ViewGroup.LayoutParams viewGroup$LayoutParams216 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams216.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_65);  // dimen:stamp_icon_size_65
                        ViewGroup.LayoutParams viewGroup$LayoutParams217 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams217.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_65);  // dimen:stamp_icon_size_65
                    }
                } else if ((mainActivity0.isNotes) && s3.length()>35) {
                    if ((mainActivity0.isAddress) && s4.length()>70) {
                        if (mainActivity0.stamp_size.equals("Large")) {
                            System.out.println("Called           15L");
                            ViewGroup.LayoutParams viewGroup$LayoutParams218 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams218.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_136);  // dimen:stamp_icon_size_136
                            ViewGroup.LayoutParams viewGroup$LayoutParams219 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams219.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_136);  // dimen:stamp_icon_size_136
                        } else if (mainActivity0.stamp_size.equals("Medium")) {
                            System.out.println("Called           15M");
                            ViewGroup.LayoutParams viewGroup$LayoutParams220 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams220.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                            ViewGroup.LayoutParams viewGroup$LayoutParams221 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams221.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                        } else if (mainActivity0.stamp_size.equals("Small")) {
                            System.out.println("Called           15S");
                            ViewGroup.LayoutParams viewGroup$LayoutParams222 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams222.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                            ViewGroup.LayoutParams viewGroup$LayoutParams223 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams223.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                        } else {
                            System.out.println("Called           15");
                            ViewGroup.LayoutParams viewGroup$LayoutParams224 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams224.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                            ViewGroup.LayoutParams viewGroup$LayoutParams225 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams225.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                        }
                    } else if (mainActivity0.stamp_size.equals("Large")) {
                        System.out.println("Called           16L");
                        ViewGroup.LayoutParams viewGroup$LayoutParams226 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams226.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_126);  // dimen:stamp_icon_size_126
                        ViewGroup.LayoutParams viewGroup$LayoutParams227 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams227.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_126);  // dimen:stamp_icon_size_126
                    } else if (mainActivity0.stamp_size.equals("Medium")) {
                        System.out.println("Called           16M");
                        ViewGroup.LayoutParams viewGroup$LayoutParams228 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams228.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                        ViewGroup.LayoutParams viewGroup$LayoutParams229 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams229.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                    } else if (mainActivity0.stamp_size.equals("Small")) {
                        System.out.println("Called           16S");
                        ViewGroup.LayoutParams viewGroup$LayoutParams230 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams230.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                        ViewGroup.LayoutParams viewGroup$LayoutParams231 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams231.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                    } else {
                        System.out.println("Called           16");
                        ViewGroup.LayoutParams viewGroup$LayoutParams232 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams232.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                        ViewGroup.LayoutParams viewGroup$LayoutParams233 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams233.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                    }
                } else if (s2.length()>35) {
                    if (mainActivity0.isNotes) {
                        if ((mainActivity0.isAddress) && s4.length()>70) {
                            if (mainActivity0.stamp_size.equals("Large")) {
                                System.out.println("Called           17L");
                                ViewGroup.LayoutParams viewGroup$LayoutParams234 = mainActivity0.li_stamp.getLayoutParams();
                                viewGroup$LayoutParams234.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_136);  // dimen:stamp_icon_size_136
                                ViewGroup.LayoutParams viewGroup$LayoutParams235 = mainActivity0.imgMap.getLayoutParams();
                                viewGroup$LayoutParams235.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_136);  // dimen:stamp_icon_size_136
                            } else if (mainActivity0.stamp_size.equals("Medium")) {
                                System.out.println("Called           17M");
                                ViewGroup.LayoutParams viewGroup$LayoutParams236 = mainActivity0.li_stamp.getLayoutParams();
                                viewGroup$LayoutParams236.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                                ViewGroup.LayoutParams viewGroup$LayoutParams237 = mainActivity0.imgMap.getLayoutParams();
                                viewGroup$LayoutParams237.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                            } else if (mainActivity0.stamp_size.equals("Small")) {
                                System.out.println("Called           17S");
                                ViewGroup.LayoutParams viewGroup$LayoutParams238 = mainActivity0.li_stamp.getLayoutParams();
                                viewGroup$LayoutParams238.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                                ViewGroup.LayoutParams viewGroup$LayoutParams239 = mainActivity0.imgMap.getLayoutParams();
                                viewGroup$LayoutParams239.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                            } else {
                                System.out.println("Called           17");
                                ViewGroup.LayoutParams viewGroup$LayoutParams240 = mainActivity0.li_stamp.getLayoutParams();
                                viewGroup$LayoutParams240.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                                ViewGroup.LayoutParams viewGroup$LayoutParams241 = mainActivity0.imgMap.getLayoutParams();
                                viewGroup$LayoutParams241.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                            }
                        } else if (mainActivity0.stamp_size.equals("Large")) {
                            System.out.println("Called           18L");
                            ViewGroup.LayoutParams viewGroup$LayoutParams242 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams242.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_126);  // dimen:stamp_icon_size_126
                            ViewGroup.LayoutParams viewGroup$LayoutParams243 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams243.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_126);  // dimen:stamp_icon_size_126
                        } else if (mainActivity0.stamp_size.equals("Medium")) {
                            System.out.println("Called           18M");
                            ViewGroup.LayoutParams viewGroup$LayoutParams244 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams244.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                            ViewGroup.LayoutParams viewGroup$LayoutParams245 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams245.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                        } else if (mainActivity0.stamp_size.equals("Small")) {
                            System.out.println("Called           18S");
                            ViewGroup.LayoutParams viewGroup$LayoutParams246 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams246.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                            ViewGroup.LayoutParams viewGroup$LayoutParams247 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams247.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                        } else {
                            System.out.println("Called           18");
                            ViewGroup.LayoutParams viewGroup$LayoutParams248 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams248.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                            ViewGroup.LayoutParams viewGroup$LayoutParams249 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams249.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                        }
                    } else if ((mainActivity0.isAddress) && s4.length()>70) {
                        if (mainActivity0.stamp_size.equals("Large")) {
                            System.out.println("Called           17L");
                            ViewGroup.LayoutParams viewGroup$LayoutParams250 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams250.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_126);  // dimen:stamp_icon_size_126
                            ViewGroup.LayoutParams viewGroup$LayoutParams251 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams251.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_126);  // dimen:stamp_icon_size_126
                        } else if (mainActivity0.stamp_size.equals("Medium")) {
                            System.out.println("Called           17M");
                            ViewGroup.LayoutParams viewGroup$LayoutParams252 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams252.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_115);  // dimen:stamp_icon_size_115
                            ViewGroup.LayoutParams viewGroup$LayoutParams253 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams253.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_115);  // dimen:stamp_icon_size_115
                        } else if (mainActivity0.stamp_size.equals("Small")) {
                            System.out.println("Called           17S");
                            ViewGroup.LayoutParams viewGroup$LayoutParams254 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams254.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_100);  // dimen:stamp_icon_size_100
                            ViewGroup.LayoutParams viewGroup$LayoutParams255 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams255.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_100);  // dimen:stamp_icon_size_100
                        } else {
                            System.out.println("Called           17");
                            ViewGroup.LayoutParams viewGroup$LayoutParams256 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams256.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                            ViewGroup.LayoutParams viewGroup$LayoutParams257 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams257.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                        }
                    } else if (mainActivity0.stamp_size.equals("Large")) {
                        System.out.println("Called           18L");
                        ViewGroup.LayoutParams viewGroup$LayoutParams258 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams258.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                        ViewGroup.LayoutParams viewGroup$LayoutParams259 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams259.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                    } else if (mainActivity0.stamp_size.equals("Medium")) {
                        System.out.println("Called           18M");
                        ViewGroup.LayoutParams viewGroup$LayoutParams260 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams260.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                        ViewGroup.LayoutParams viewGroup$LayoutParams261 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams261.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                    } else if (mainActivity0.stamp_size.equals("Small")) {
                        System.out.println("Called           18S");
                        ViewGroup.LayoutParams viewGroup$LayoutParams262 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams262.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                        ViewGroup.LayoutParams viewGroup$LayoutParams263 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams263.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                    } else {
                        System.out.println("Called           18");
                        ViewGroup.LayoutParams viewGroup$LayoutParams264 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams264.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                        ViewGroup.LayoutParams viewGroup$LayoutParams265 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams265.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                    }
                } else if (mainActivity0.isNotes) {
                    if ((mainActivity0.isAddress) && s4.length()>70) {
                        if (mainActivity0.stamp_size.equals("Large")) {
                            System.out.println("Called           19L");
                            ViewGroup.LayoutParams viewGroup$LayoutParams266 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams266.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_136);  // dimen:stamp_icon_size_136
                            ViewGroup.LayoutParams viewGroup$LayoutParams267 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams267.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_136);  // dimen:stamp_icon_size_136
                        } else if (mainActivity0.stamp_size.equals("Medium")) {
                            System.out.println("Called           19M");
                            ViewGroup.LayoutParams viewGroup$LayoutParams268 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams268.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                            ViewGroup.LayoutParams viewGroup$LayoutParams269 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams269.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                        } else if (mainActivity0.stamp_size.equals("Small")) {
                            System.out.println("Called           19S");
                            ViewGroup.LayoutParams viewGroup$LayoutParams270 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams270.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                            ViewGroup.LayoutParams viewGroup$LayoutParams271 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams271.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                        } else {
                            System.out.println("Called           19");
                            ViewGroup.LayoutParams viewGroup$LayoutParams272 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams272.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                            ViewGroup.LayoutParams viewGroup$LayoutParams273 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams273.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                        }
                    } else if (mainActivity0.stamp_size.equals("Large")) {
                        System.out.println("Called           20L");
                        ViewGroup.LayoutParams viewGroup$LayoutParams274 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams274.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                        ViewGroup.LayoutParams viewGroup$LayoutParams275 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams275.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                    } else if (mainActivity0.stamp_size.equals("Medium")) {
                        System.out.println("Called           20M");
                        ViewGroup.LayoutParams viewGroup$LayoutParams276 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams276.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                        ViewGroup.LayoutParams viewGroup$LayoutParams277 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams277.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                    } else if (mainActivity0.stamp_size.equals("Small")) {
                        System.out.println("Called           20S");
                        ViewGroup.LayoutParams viewGroup$LayoutParams278 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams278.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                        ViewGroup.LayoutParams viewGroup$LayoutParams279 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams279.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                    } else {
                        System.out.println("Called           20");
                        ViewGroup.LayoutParams viewGroup$LayoutParams280 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams280.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_75);  // dimen:stamp_icon_size_75
                        ViewGroup.LayoutParams viewGroup$LayoutParams281 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams281.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_75);  // dimen:stamp_icon_size_75
                    }
                } else if ((mainActivity0.isAddress) && s4.length()>70) {
                    if (mainActivity0.stamp_size.equals("Large")) {
                        System.out.println("Called           21L");
                        ViewGroup.LayoutParams viewGroup$LayoutParams282 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams282.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_126);  // dimen:stamp_icon_size_126
                        ViewGroup.LayoutParams viewGroup$LayoutParams283 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams283.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_126);  // dimen:stamp_icon_size_126
                    } else if (mainActivity0.stamp_size.equals("Medium")) {
                        System.out.println("Called           21M");
                        ViewGroup.LayoutParams viewGroup$LayoutParams284 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams284.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                        ViewGroup.LayoutParams viewGroup$LayoutParams285 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams285.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                    } else if (mainActivity0.stamp_size.equals("Small")) {
                        System.out.println("Called           21S");
                        ViewGroup.LayoutParams viewGroup$LayoutParams286 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams286.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                        ViewGroup.LayoutParams viewGroup$LayoutParams287 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams287.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                    } else {
                        System.out.println("Called           21");
                        ViewGroup.LayoutParams viewGroup$LayoutParams288 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams288.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                        ViewGroup.LayoutParams viewGroup$LayoutParams289 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams289.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                    }
                } else if (mainActivity0.stamp_size.equals("Large")) {
                    System.out.println("Called           22L");
                    ViewGroup.LayoutParams viewGroup$LayoutParams290 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams290.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                    ViewGroup.LayoutParams viewGroup$LayoutParams291 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams291.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                } else if (mainActivity0.stamp_size.equals("Medium")) {
                    System.out.println("Called           22M");
                    ViewGroup.LayoutParams viewGroup$LayoutParams292 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams292.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                    ViewGroup.LayoutParams viewGroup$LayoutParams293 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams293.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                } else if (mainActivity0.stamp_size.equals("Small")) {
                    System.out.println("Called           22S");
                    ViewGroup.LayoutParams viewGroup$LayoutParams294 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams294.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                    ViewGroup.LayoutParams viewGroup$LayoutParams295 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams295.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                } else {
                    System.out.println("Called           22");
                    ViewGroup.LayoutParams viewGroup$LayoutParams296 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams296.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_65);  // dimen:stamp_icon_size_65
                    ViewGroup.LayoutParams viewGroup$LayoutParams297 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams297.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_65);  // dimen:stamp_icon_size_65
                }
            } else if (!mainActivity0.isNumbering && !mainActivity0.isPlusCode) {
                if ((mainActivity0.isNotes) && s3.length()>35) {
                    if ((mainActivity0.isAddress) && s4.length()>70) {
                        if (mainActivity0.stamp_size.equals("Large")) {
                            System.out.println("Called           11L");
                            ViewGroup.LayoutParams viewGroup$LayoutParams56 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams56.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_126);  // dimen:stamp_icon_size_126
                            ViewGroup.LayoutParams viewGroup$LayoutParams57 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams57.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_126);  // dimen:stamp_icon_size_126
                        } else if (mainActivity0.stamp_size.equals("Medium")) {
                            System.out.println("Called           11M");
                            ViewGroup.LayoutParams viewGroup$LayoutParams58 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams58.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                            ViewGroup.LayoutParams viewGroup$LayoutParams59 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams59.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                        } else if (mainActivity0.stamp_size.equals("Small")) {
                            System.out.println("Called           11S");
                            ViewGroup.LayoutParams viewGroup$LayoutParams60 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams60.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                            ViewGroup.LayoutParams viewGroup$LayoutParams61 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams61.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                        } else {
                            System.out.println("Called           11");
                            ViewGroup.LayoutParams viewGroup$LayoutParams62 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams62.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                            ViewGroup.LayoutParams viewGroup$LayoutParams63 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams63.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                        }
                    } else if (mainActivity0.stamp_size.equals("Large")) {
                        System.out.println("Called           12L");
                        ViewGroup.LayoutParams viewGroup$LayoutParams64 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams64.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                        ViewGroup.LayoutParams viewGroup$LayoutParams65 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams65.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                    } else if (mainActivity0.stamp_size.equals("Medium")) {
                        System.out.println("Called           12M");
                        ViewGroup.LayoutParams viewGroup$LayoutParams66 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams66.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                        ViewGroup.LayoutParams viewGroup$LayoutParams67 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams67.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                    } else if (mainActivity0.stamp_size.equals("Small")) {
                        System.out.println("Called           12S");
                        ViewGroup.LayoutParams viewGroup$LayoutParams68 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams68.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                        ViewGroup.LayoutParams viewGroup$LayoutParams69 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams69.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                    } else {
                        System.out.println("Called           12");
                        ViewGroup.LayoutParams viewGroup$LayoutParams70 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams70.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_75);  // dimen:stamp_icon_size_75
                        ViewGroup.LayoutParams viewGroup$LayoutParams71 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams71.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_75);  // dimen:stamp_icon_size_75
                    }
                } else if ((mainActivity0.isAddress) && s4.length()>70) {
                    if (mainActivity0.stamp_size.equals("Large")) {
                        System.out.println("Called           13L");
                        ViewGroup.LayoutParams viewGroup$LayoutParams72 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams72.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                        ViewGroup.LayoutParams viewGroup$LayoutParams73 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams73.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                    } else if (mainActivity0.stamp_size.equals("Medium")) {
                        System.out.println("Called           13M");
                        ViewGroup.LayoutParams viewGroup$LayoutParams74 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams74.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                        ViewGroup.LayoutParams viewGroup$LayoutParams75 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams75.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                    } else if (mainActivity0.stamp_size.equals("Small")) {
                        System.out.println("Called           13S");
                        ViewGroup.LayoutParams viewGroup$LayoutParams76 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams76.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                        ViewGroup.LayoutParams viewGroup$LayoutParams77 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams77.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                    } else {
                        System.out.println("Called           13");
                        ViewGroup.LayoutParams viewGroup$LayoutParams78 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams78.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_75);  // dimen:stamp_icon_size_75
                        ViewGroup.LayoutParams viewGroup$LayoutParams79 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams79.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_75);  // dimen:stamp_icon_size_75
                    }
                } else if (mainActivity0.stamp_size.equals("Large")) {
                    System.out.println("Called           14L");
                    ViewGroup.LayoutParams viewGroup$LayoutParams80 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams80.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                    ViewGroup.LayoutParams viewGroup$LayoutParams81 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams81.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                } else if (mainActivity0.stamp_size.equals("Medium")) {
                    System.out.println("Called           14M");
                    ViewGroup.LayoutParams viewGroup$LayoutParams82 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams82.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                    ViewGroup.LayoutParams viewGroup$LayoutParams83 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams83.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                } else if (mainActivity0.stamp_size.equals("Small")) {
                    System.out.println("Called           14S");
                    ViewGroup.LayoutParams viewGroup$LayoutParams84 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams84.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                    ViewGroup.LayoutParams viewGroup$LayoutParams85 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams85.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                } else {
                    System.out.println("Called           14");
                    ViewGroup.LayoutParams viewGroup$LayoutParams86 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams86.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_65);  // dimen:stamp_icon_size_65
                    ViewGroup.LayoutParams viewGroup$LayoutParams87 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams87.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_65);  // dimen:stamp_icon_size_65
                }
            } else if (!mainActivity0.isAccuracy && !mainActivity0.isAltitude && !mainActivity0.isPressure && !mainActivity0.isHumidity && !mainActivity0.isWind) {
                if ((mainActivity0.isNotes) && s3.length()>35) {
                    if ((mainActivity0.isAddress) && s4.length()>70) {
                        if (mainActivity0.stamp_size.equals("Large")) {
                            System.out.println("Called           7L");
                            ViewGroup.LayoutParams viewGroup$LayoutParams88 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams88.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_136);  // dimen:stamp_icon_size_136
                            ViewGroup.LayoutParams viewGroup$LayoutParams89 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams89.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_136);  // dimen:stamp_icon_size_136
                        } else if (mainActivity0.stamp_size.equals("Medium")) {
                            System.out.println("Called           7M");
                            ViewGroup.LayoutParams viewGroup$LayoutParams90 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams90.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                            ViewGroup.LayoutParams viewGroup$LayoutParams91 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams91.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                        } else if (mainActivity0.stamp_size.equals("Small")) {
                            System.out.println("Called           7S");
                            ViewGroup.LayoutParams viewGroup$LayoutParams92 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams92.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                            ViewGroup.LayoutParams viewGroup$LayoutParams93 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams93.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                        } else {
                            System.out.println("Called           7");
                            ViewGroup.LayoutParams viewGroup$LayoutParams94 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams94.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                            ViewGroup.LayoutParams viewGroup$LayoutParams95 = mainActivity0.imgMap.getLayoutParams();
                            viewGroup$LayoutParams95.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                        }
                    } else if (mainActivity0.stamp_size.equals("Large")) {
                        System.out.println("Called           8L");
                        ViewGroup.LayoutParams viewGroup$LayoutParams96 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams96.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_126);  // dimen:stamp_icon_size_126
                        ViewGroup.LayoutParams viewGroup$LayoutParams97 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams97.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_126);  // dimen:stamp_icon_size_126
                    } else if (mainActivity0.stamp_size.equals("Medium")) {
                        System.out.println("Called           8M");
                        ViewGroup.LayoutParams viewGroup$LayoutParams98 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams98.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                        ViewGroup.LayoutParams viewGroup$LayoutParams99 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams99.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                    } else if (mainActivity0.stamp_size.equals("Small")) {
                        System.out.println("Called           8S");
                        ViewGroup.LayoutParams viewGroup$LayoutParams100 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams100.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                        ViewGroup.LayoutParams viewGroup$LayoutParams101 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams101.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                    } else {
                        System.out.println("Called           8");
                        ViewGroup.LayoutParams viewGroup$LayoutParams102 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams102.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                        ViewGroup.LayoutParams viewGroup$LayoutParams103 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams103.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                    }
                } else if ((mainActivity0.isAddress) && s4.length()>70) {
                    if (mainActivity0.stamp_size.equals("Large")) {
                        System.out.println("Called           9L");
                        ViewGroup.LayoutParams viewGroup$LayoutParams104 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams104.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_126);  // dimen:stamp_icon_size_126
                        ViewGroup.LayoutParams viewGroup$LayoutParams105 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams105.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_126);  // dimen:stamp_icon_size_126
                    } else if (mainActivity0.stamp_size.equals("Medium")) {
                        System.out.println("Called           9M");
                        ViewGroup.LayoutParams viewGroup$LayoutParams106 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams106.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                        ViewGroup.LayoutParams viewGroup$LayoutParams107 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams107.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                    } else if (mainActivity0.stamp_size.equals("Small")) {
                        System.out.println("Called           9S");
                        ViewGroup.LayoutParams viewGroup$LayoutParams108 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams108.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                        ViewGroup.LayoutParams viewGroup$LayoutParams109 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams109.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                    } else {
                        System.out.println("Called           9");
                        ViewGroup.LayoutParams viewGroup$LayoutParams110 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams110.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                        ViewGroup.LayoutParams viewGroup$LayoutParams111 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams111.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                    }
                } else if (mainActivity0.stamp_size.equals("Large")) {
                    System.out.println("Called           10L");
                    ViewGroup.LayoutParams viewGroup$LayoutParams112 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams112.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                    ViewGroup.LayoutParams viewGroup$LayoutParams113 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams113.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                } else if (mainActivity0.stamp_size.equals("Medium")) {
                    System.out.println("Called           10M");
                    ViewGroup.LayoutParams viewGroup$LayoutParams114 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams114.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                    ViewGroup.LayoutParams viewGroup$LayoutParams115 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams115.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                } else if (mainActivity0.stamp_size.equals("Small")) {
                    System.out.println("Called           10S");
                    ViewGroup.LayoutParams viewGroup$LayoutParams116 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams116.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                    ViewGroup.LayoutParams viewGroup$LayoutParams117 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams117.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                } else {
                    System.out.println("Called           10");
                    ViewGroup.LayoutParams viewGroup$LayoutParams118 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams118.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_75);  // dimen:stamp_icon_size_75
                    ViewGroup.LayoutParams viewGroup$LayoutParams119 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams119.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_75);  // dimen:stamp_icon_size_75
                }
            } else if ((mainActivity0.isNotes) && s3.length()>35) {
                if ((mainActivity0.isAddress) && s4.length()>70) {
                    if (mainActivity0.stamp_size.equals("Large")) {
                        System.out.println("Called           1L");
                        ViewGroup.LayoutParams viewGroup$LayoutParams120 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams120.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_146);  // dimen:stamp_icon_size_146
                        ViewGroup.LayoutParams viewGroup$LayoutParams121 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams121.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_146);  // dimen:stamp_icon_size_146
                    } else if (mainActivity0.stamp_size.equals("Medium")) {
                        System.out.println("Called           1M");
                        ViewGroup.LayoutParams viewGroup$LayoutParams122 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams122.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_130);  // dimen:stamp_icon_size_130
                        ViewGroup.LayoutParams viewGroup$LayoutParams123 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams123.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_130);  // dimen:stamp_icon_size_130
                    } else if (mainActivity0.stamp_size.equals("Small")) {
                        System.out.println("Called           1S");
                        ViewGroup.LayoutParams viewGroup$LayoutParams124 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams124.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_115);  // dimen:stamp_icon_size_115
                        ViewGroup.LayoutParams viewGroup$LayoutParams125 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams125.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_115);  // dimen:stamp_icon_size_115
                    } else {
                        System.out.println("Called           1");
                        ViewGroup.LayoutParams viewGroup$LayoutParams126 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams126.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_100);  // dimen:stamp_icon_size_100
                        ViewGroup.LayoutParams viewGroup$LayoutParams127 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams127.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_100);  // dimen:stamp_icon_size_100
                    }
                } else if (mainActivity0.stamp_size.equals("Large")) {
                    System.out.println("Called           2L");
                    ViewGroup.LayoutParams viewGroup$LayoutParams128 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams128.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_146);  // dimen:stamp_icon_size_146
                    ViewGroup.LayoutParams viewGroup$LayoutParams129 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams129.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_146);  // dimen:stamp_icon_size_146
                } else if (mainActivity0.stamp_size.equals("Medium")) {
                    System.out.println("Called           2M");
                    ViewGroup.LayoutParams viewGroup$LayoutParams130 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams130.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                    ViewGroup.LayoutParams viewGroup$LayoutParams131 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams131.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                } else if (mainActivity0.stamp_size.equals("Small")) {
                    System.out.println("Called           2S");
                    ViewGroup.LayoutParams viewGroup$LayoutParams132 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams132.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_115);  // dimen:stamp_icon_size_115
                    ViewGroup.LayoutParams viewGroup$LayoutParams133 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams133.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_115);  // dimen:stamp_icon_size_115
                } else {
                    System.out.println("Called           2");
                    ViewGroup.LayoutParams viewGroup$LayoutParams134 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams134.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_100);  // dimen:stamp_icon_size_100
                    ViewGroup.LayoutParams viewGroup$LayoutParams135 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams135.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_100);  // dimen:stamp_icon_size_100
                }
            } else if (s2.length()>35) {
                if ((mainActivity0.isAddress) && s4.length()>70) {
                    if (mainActivity0.stamp_size.equals("Large")) {
                        System.out.println("Called           3L");
                        ViewGroup.LayoutParams viewGroup$LayoutParams136 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams136.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_146);  // dimen:stamp_icon_size_146
                        ViewGroup.LayoutParams viewGroup$LayoutParams137 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams137.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_146);  // dimen:stamp_icon_size_146
                    } else if (mainActivity0.stamp_size.equals("Medium")) {
                        System.out.println("Called           3M");
                        ViewGroup.LayoutParams viewGroup$LayoutParams138 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams138.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_130);  // dimen:stamp_icon_size_130
                        ViewGroup.LayoutParams viewGroup$LayoutParams139 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams139.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_130);  // dimen:stamp_icon_size_130
                    } else if (mainActivity0.stamp_size.equals("Small")) {
                        System.out.println("Called           3S");
                        ViewGroup.LayoutParams viewGroup$LayoutParams140 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams140.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_115);  // dimen:stamp_icon_size_115
                        ViewGroup.LayoutParams viewGroup$LayoutParams141 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams141.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_115);  // dimen:stamp_icon_size_115
                    } else {
                        System.out.println("Called           3");
                        ViewGroup.LayoutParams viewGroup$LayoutParams142 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams142.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_100);  // dimen:stamp_icon_size_100
                        ViewGroup.LayoutParams viewGroup$LayoutParams143 = mainActivity0.imgMap.getLayoutParams();
                        viewGroup$LayoutParams143.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_100);  // dimen:stamp_icon_size_100
                    }
                } else if (mainActivity0.stamp_size.equals("Large")) {
                    System.out.println("Called           4L");
                    ViewGroup.LayoutParams viewGroup$LayoutParams144 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams144.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_126);  // dimen:stamp_icon_size_126
                    ViewGroup.LayoutParams viewGroup$LayoutParams145 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams145.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_126);  // dimen:stamp_icon_size_126
                } else if (mainActivity0.stamp_size.equals("Medium")) {
                    System.out.println("Called           4M");
                    ViewGroup.LayoutParams viewGroup$LayoutParams146 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams146.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                    ViewGroup.LayoutParams viewGroup$LayoutParams147 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams147.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                } else if (mainActivity0.stamp_size.equals("Small")) {
                    System.out.println("Called           4S");
                    ViewGroup.LayoutParams viewGroup$LayoutParams148 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams148.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                    ViewGroup.LayoutParams viewGroup$LayoutParams149 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams149.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                } else {
                    System.out.println("Called           4");
                    ViewGroup.LayoutParams viewGroup$LayoutParams150 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams150.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                    ViewGroup.LayoutParams viewGroup$LayoutParams151 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams151.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                }
            } else if ((mainActivity0.isAddress) && s4.length()>70) {
                if (mainActivity0.stamp_size.equals("Large")) {
                    System.out.println("Called           5L");
                    ViewGroup.LayoutParams viewGroup$LayoutParams152 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams152.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_136);  // dimen:stamp_icon_size_136
                    ViewGroup.LayoutParams viewGroup$LayoutParams153 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams153.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_136);  // dimen:stamp_icon_size_136
                } else if (mainActivity0.stamp_size.equals("Medium")) {
                    System.out.println("Called           5M");
                    ViewGroup.LayoutParams viewGroup$LayoutParams154 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams154.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                    ViewGroup.LayoutParams viewGroup$LayoutParams155 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams155.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                } else if (mainActivity0.stamp_size.equals("Small")) {
                    System.out.println("Called           5S");
                    ViewGroup.LayoutParams viewGroup$LayoutParams156 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams156.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_115);  // dimen:stamp_icon_size_115
                    ViewGroup.LayoutParams viewGroup$LayoutParams157 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams157.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_115);  // dimen:stamp_icon_size_115
                } else {
                    System.out.println("Called           5");
                    ViewGroup.LayoutParams viewGroup$LayoutParams158 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams158.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_100);  // dimen:stamp_icon_size_100
                    ViewGroup.LayoutParams viewGroup$LayoutParams159 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams159.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_100);  // dimen:stamp_icon_size_100
                }
            } else if (mainActivity0.stamp_size.equals("Large")) {
                System.out.println("Called           6L");
                ViewGroup.LayoutParams viewGroup$LayoutParams160 = mainActivity0.li_stamp.getLayoutParams();
                viewGroup$LayoutParams160.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                ViewGroup.LayoutParams viewGroup$LayoutParams161 = mainActivity0.imgMap.getLayoutParams();
                viewGroup$LayoutParams161.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
            } else if (mainActivity0.stamp_size.equals("Medium")) {
                System.out.println("Called           6M");
                if (z) {
                    ViewGroup.LayoutParams viewGroup$LayoutParams162 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams162.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                    ViewGroup.LayoutParams viewGroup$LayoutParams163 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams163.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                } else {
                    ViewGroup.LayoutParams viewGroup$LayoutParams164 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams164.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                    ViewGroup.LayoutParams viewGroup$LayoutParams165 = mainActivity0.imgMap.getLayoutParams();
                    viewGroup$LayoutParams165.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                }
            } else if (mainActivity0.stamp_size.equals("Small")) {
                System.out.println("Called           6S");
                ViewGroup.LayoutParams viewGroup$LayoutParams166 = mainActivity0.li_stamp.getLayoutParams();
                viewGroup$LayoutParams166.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                ViewGroup.LayoutParams viewGroup$LayoutParams167 = mainActivity0.imgMap.getLayoutParams();
                viewGroup$LayoutParams167.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
            } else {
                System.out.println("Called           6");
                ViewGroup.LayoutParams viewGroup$LayoutParams168 = mainActivity0.li_stamp.getLayoutParams();
                viewGroup$LayoutParams168.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                ViewGroup.LayoutParams viewGroup$LayoutParams169 = mainActivity0.imgMap.getLayoutParams();
                viewGroup$LayoutParams169.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
            }
        } else {
            boolean z2 = mainActivity0.isLatLng;
            if ((z2) || (mainActivity0.isAddress) || (mainActivity0.isMagneticField) || (mainActivity0.isWeather) || (mainActivity0.isCompass)) {
                boolean z3 = mainActivity0.isAddress;
                if (!z3) {
                    mainActivity0.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, this.getResources().getDisplayMetrics()), 1.2f);
                    if (!mainActivity0.isDateTime && !mainActivity0.isLatLng || mainActivity0.tv_address_line_1.getMaxLines() == 1 && (!mainActivity0.isCompass && !mainActivity0.isMagneticField && !mainActivity0.isWeather || ((mainActivity0.isWeather) && !mainActivity0.isCompass && !mainActivity0.isMagneticField || (mainActivity0.isCompass) && !mainActivity0.isWeather && !mainActivity0.isMagneticField || (mainActivity0.isMagneticField) && !mainActivity0.isWeather && !mainActivity0.isCompass))) {
                        if (mainActivity0.lin_bottom_wether.getVisibility() == 8 && !mainActivity0.isCompass && !mainActivity0.isMagneticField && !mainActivity0.isWeather) {
                            if (((mainActivity0.isDateTime) || (mainActivity0.isLatLng)) && (mainActivity0.isNotes)) {
                                if (!mainActivity0.isNumbering && !mainActivity0.isPlusCode) {
                                    if (mainActivity0.stamp_size.equals("Large")) {
                                        System.out.println("Called           30L");
                                        ViewGroup.LayoutParams viewGroup$LayoutParams307 = mainActivity0.li_stamp.getLayoutParams();
                                        viewGroup$LayoutParams307.height = (int) this.getResources().getDimension(R.dimen.stamp_90dp);  // dimen:stamp_90dp
                                    } else {
                                        System.out.println("Called           30");
                                        ViewGroup.LayoutParams viewGroup$LayoutParams308 = mainActivity0.li_stamp.getLayoutParams();
                                        viewGroup$LayoutParams308.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_35);  // dimen:stamp_icon_size_35
                                    }
                                } else if (mainActivity0.stamp_size.equals("Large")) {
                                    System.out.println("Called           29L");
                                    ViewGroup.LayoutParams viewGroup$LayoutParams309 = mainActivity0.li_stamp.getLayoutParams();
                                    viewGroup$LayoutParams309.height = (int) this.getResources().getDimension(R.dimen.stamp_100dp);  // dimen:stamp_100dp
                                } else {
                                    System.out.println("Called           29");
                                    ViewGroup.LayoutParams viewGroup$LayoutParams310 = mainActivity0.li_stamp.getLayoutParams();
                                    viewGroup$LayoutParams310.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_45);  // dimen:stamp_icon_size_45
                                }
                            } else if (!mainActivity0.isNumbering && !mainActivity0.isPlusCode) {
                                if (mainActivity0.stamp_size.equals("Large")) {
                                    System.out.println("Called           32L");
                                    ViewGroup.LayoutParams viewGroup$LayoutParams311 = mainActivity0.li_stamp.getLayoutParams();
                                    viewGroup$LayoutParams311.height = (int) this.getResources().getDimension(R.dimen.stamp_70dp);  // dimen:stamp_70dp
                                } else {
                                    System.out.println("Called           32");
                                    ViewGroup.LayoutParams viewGroup$LayoutParams312 = mainActivity0.li_stamp.getLayoutParams();
                                    viewGroup$LayoutParams312.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_25);  // dimen:stamp_icon_size_25
                                }
                            } else if (mainActivity0.stamp_size.equals("Large")) {
                                System.out.println("Called           31L");
                                ViewGroup.LayoutParams viewGroup$LayoutParams313 = mainActivity0.li_stamp.getLayoutParams();
                                viewGroup$LayoutParams313.height = (int) this.getResources().getDimension(R.dimen.stamp_80dp);  // dimen:stamp_80dp
                            } else {
                                System.out.println("Called           31");
                                ViewGroup.LayoutParams viewGroup$LayoutParams314 = mainActivity0.li_stamp.getLayoutParams();
                                viewGroup$LayoutParams314.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_30);  // dimen:stamp_icon_size_30
                            }
                        } else if (mainActivity0.isLogo) {
                            if (!mainActivity0.isNumbering && !mainActivity0.isPlusCode) {
                                if (mainActivity0.stamp_size.equals("Large")) {
                                    System.out.println("Called           34L");
                                    ViewGroup.LayoutParams viewGroup$LayoutParams315 = mainActivity0.li_stamp.getLayoutParams();
                                    viewGroup$LayoutParams315.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                                } else if (mainActivity0.stamp_size.equals("Medium")) {
                                    System.out.println("Called           34M");
                                    ViewGroup.LayoutParams viewGroup$LayoutParams316 = mainActivity0.li_stamp.getLayoutParams();
                                    viewGroup$LayoutParams316.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                                } else if (mainActivity0.stamp_size.equals("Small")) {
                                    System.out.println("Called           34S");
                                    ViewGroup.LayoutParams viewGroup$LayoutParams317 = mainActivity0.li_stamp.getLayoutParams();
                                    viewGroup$LayoutParams317.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                                } else {
                                    System.out.println("Called           34");
                                    ViewGroup.LayoutParams viewGroup$LayoutParams318 = mainActivity0.li_stamp.getLayoutParams();
                                    viewGroup$LayoutParams318.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_65);  // dimen:stamp_icon_size_65
                                }
                            } else if (mainActivity0.stamp_size.equals("Large")) {
                                System.out.println("Called           33L");
                                ViewGroup.LayoutParams viewGroup$LayoutParams319 = mainActivity0.li_stamp.getLayoutParams();
                                viewGroup$LayoutParams319.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                            } else if (mainActivity0.stamp_size.equals("Medium")) {
                                System.out.println("Called           33M");
                                ViewGroup.LayoutParams viewGroup$LayoutParams320 = mainActivity0.li_stamp.getLayoutParams();
                                viewGroup$LayoutParams320.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                            } else if (mainActivity0.stamp_size.equals("Small")) {
                                System.out.println("Called           33S");
                                ViewGroup.LayoutParams viewGroup$LayoutParams321 = mainActivity0.li_stamp.getLayoutParams();
                                viewGroup$LayoutParams321.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                            } else {
                                System.out.println("Called           33");
                                ViewGroup.LayoutParams viewGroup$LayoutParams322 = mainActivity0.li_stamp.getLayoutParams();
                                viewGroup$LayoutParams322.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_75);  // dimen:stamp_icon_size_75
                            }
                        } else if (!mainActivity0.isNumbering && !mainActivity0.isPlusCode) {
                            if (mainActivity0.stamp_size.equals("Large")) {
                                System.out.println("Called           36L");
                                ViewGroup.LayoutParams viewGroup$LayoutParams323 = mainActivity0.li_stamp.getLayoutParams();
                                viewGroup$LayoutParams323.height = (int) this.getResources().getDimension(R.dimen.stamp_90dp);  // dimen:stamp_90dp
                            } else {
                                System.out.println("Called           36");
                                ViewGroup.LayoutParams viewGroup$LayoutParams324 = mainActivity0.li_stamp.getLayoutParams();
                                viewGroup$LayoutParams324.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_60);  // dimen:stamp_icon_size_60
                            }
                        } else if (mainActivity0.stamp_size.equals("Large")) {
                            System.out.println("Called           35L");
                            ViewGroup.LayoutParams viewGroup$LayoutParams325 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams325.height = (int) this.getResources().getDimension(R.dimen.stamp_100dp);  // dimen:stamp_100dp
                        } else {
                            System.out.println("Called           35");
                            ViewGroup.LayoutParams viewGroup$LayoutParams326 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams326.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_70);  // dimen:stamp_icon_size_70
                        }
                    } else if (!mainActivity0.isNumbering && !mainActivity0.isPlusCode) {
                        if (mainActivity0.stamp_size.equals("Large")) {
                            System.out.println("Called           38L");
                            ViewGroup.LayoutParams viewGroup$LayoutParams327 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams327.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                        } else if (mainActivity0.stamp_size.equals("Medium")) {
                            System.out.println("Called           38M");
                            ViewGroup.LayoutParams viewGroup$LayoutParams328 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams328.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                        } else if (mainActivity0.stamp_size.equals("Small")) {
                            System.out.println("Called           38S");
                            ViewGroup.LayoutParams viewGroup$LayoutParams329 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams329.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                        } else {
                            System.out.println("Called           38");
                            ViewGroup.LayoutParams viewGroup$LayoutParams330 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams330.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_65);  // dimen:stamp_icon_size_65
                        }
                    } else if (mainActivity0.stamp_size.equals("Large")) {
                        System.out.println("Called           37L");
                        ViewGroup.LayoutParams viewGroup$LayoutParams331 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams331.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                    } else if (mainActivity0.stamp_size.equals("Medium")) {
                        System.out.println("Called           37M");
                        ViewGroup.LayoutParams viewGroup$LayoutParams332 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams332.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                    } else if (mainActivity0.stamp_size.equals("Small")) {
                        System.out.println("Called           37S");
                        ViewGroup.LayoutParams viewGroup$LayoutParams333 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams333.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                    } else {
                        System.out.println("Called           37");
                        ViewGroup.LayoutParams viewGroup$LayoutParams334 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams334.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_65);  // dimen:stamp_icon_size_65
                    }
                } else if ((z3) && !z2) {
                    if (!mainActivity0.isNumbering && !mainActivity0.isPlusCode) {
                        mainActivity0.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(2, 2.0f, this.getResources().getDisplayMetrics()), 1.2f);
                        if (mainActivity0.stamp_size.equals("Large")) {
                            System.out.println("Called           40L");
                            ViewGroup.LayoutParams viewGroup$LayoutParams335 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams335.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                        } else if (mainActivity0.stamp_size.equals("Medium")) {
                            System.out.println("Called           40M");
                            ViewGroup.LayoutParams viewGroup$LayoutParams336 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams336.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                        } else if (mainActivity0.stamp_size.equals("Small")) {
                            System.out.println("Called           40S");
                            ViewGroup.LayoutParams viewGroup$LayoutParams337 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams337.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                        } else {
                            System.out.println("Called           40");
                            ViewGroup.LayoutParams viewGroup$LayoutParams338 = mainActivity0.li_stamp.getLayoutParams();
                            viewGroup$LayoutParams338.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_65);  // dimen:stamp_icon_size_65
                        }
                    } else if (mainActivity0.stamp_size.equals("Large")) {
                        System.out.println("Called           39L");
                        ViewGroup.LayoutParams viewGroup$LayoutParams339 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams339.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                    } else if (mainActivity0.stamp_size.equals("Medium")) {
                        System.out.println("Called           39M");
                        ViewGroup.LayoutParams viewGroup$LayoutParams340 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams340.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                    } else if (mainActivity0.stamp_size.equals("Small")) {
                        System.out.println("Called           39S");
                        ViewGroup.LayoutParams viewGroup$LayoutParams341 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams341.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_90);  // dimen:stamp_icon_size_90
                    } else {
                        System.out.println("Called           39");
                        ViewGroup.LayoutParams viewGroup$LayoutParams342 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams342.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_75);  // dimen:stamp_icon_size_75
                    }
                } else if (!mainActivity0.isNumbering && !mainActivity0.isPlusCode) {
                    if (mainActivity0.stamp_size.equals("Large")) {
                        System.out.println("Called           42L");
                        ViewGroup.LayoutParams viewGroup$LayoutParams343 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams343.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_115);  // dimen:stamp_icon_size_115
                    } else if (mainActivity0.stamp_size.equals("Medium")) {
                        System.out.println("Called           42M");
                        ViewGroup.LayoutParams viewGroup$LayoutParams344 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams344.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_105);  // dimen:stamp_icon_size_105
                    } else if (mainActivity0.stamp_size.equals("Small")) {
                        System.out.println("Called           42S");
                        ViewGroup.LayoutParams viewGroup$LayoutParams345 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams345.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                    } else {
                        System.out.println("Called           42");
                        ViewGroup.LayoutParams viewGroup$LayoutParams346 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams346.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_80);  // dimen:stamp_icon_size_80
                    }
                } else if (mainActivity0.stamp_size.equals("Large")) {
                    System.out.println("Called           41L");
                    ViewGroup.LayoutParams viewGroup$LayoutParams347 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams347.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_130);  // dimen:stamp_icon_size_130
                } else if (mainActivity0.stamp_size.equals("Medium")) {
                    System.out.println("Called           41M");
                    ViewGroup.LayoutParams viewGroup$LayoutParams348 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams348.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_120);  // dimen:stamp_icon_size_120
                } else if (mainActivity0.stamp_size.equals("Small")) {
                    System.out.println("Called           41S");
                    ViewGroup.LayoutParams viewGroup$LayoutParams349 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams349.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_110);  // dimen:stamp_icon_size_110
                } else {
                    System.out.println("Called           41");
                    ViewGroup.LayoutParams viewGroup$LayoutParams350 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams350.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_95);  // dimen:stamp_icon_size_95
                }
            } else if (!mainActivity0.isNumbering && !mainActivity0.isPlusCode) {
                if (mainActivity0.stamp_size.equals("Large")) {
                    System.out.println("Called           44L");
                    ViewGroup.LayoutParams viewGroup$LayoutParams298 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams298.height = (int) this.getResources().getDimension(R.dimen.stamp_70dp);  // dimen:stamp_70dp
                } else {
                    System.out.println("Called           44");
                    if (!mainActivity0.isLogo && !mainActivity0.isNotes) {
                        ViewGroup.LayoutParams viewGroup$LayoutParams299 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams299.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_35);  // dimen:stamp_icon_size_35
                    } else {
                        ViewGroup.LayoutParams viewGroup$LayoutParams300 = mainActivity0.li_stamp.getLayoutParams();
                        viewGroup$LayoutParams300.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_40);  // dimen:stamp_icon_size_40
                    }
                }
            } else if (!mainActivity0.stamp_size.equals("Large")) {
                System.out.println("Called           43");
                if (!mainActivity0.isNumbering) {
                    ViewGroup.LayoutParams viewGroup$LayoutParams304 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams304.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_40);  // dimen:stamp_icon_size_40
                } else if (mainActivity0.isPlusCode) {
                    ViewGroup.LayoutParams viewGroup$LayoutParams306 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams306.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_60);  // dimen:stamp_icon_size_60
                } else {
                    ViewGroup.LayoutParams viewGroup$LayoutParams305 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams305.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_40);  // dimen:stamp_icon_size_40
                }
            } else if (!mainActivity0.isNumbering) {
                ViewGroup.LayoutParams viewGroup$LayoutParams301 = mainActivity0.li_stamp.getLayoutParams();
                viewGroup$LayoutParams301.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_40);  // dimen:stamp_icon_size_40
            } else if (mainActivity0.isPlusCode) {
                ViewGroup.LayoutParams viewGroup$LayoutParams303 = mainActivity0.li_stamp.getLayoutParams();
                viewGroup$LayoutParams303.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_70);  // dimen:stamp_icon_size_70
            } else {
                ViewGroup.LayoutParams viewGroup$LayoutParams302 = mainActivity0.li_stamp.getLayoutParams();
                viewGroup$LayoutParams302.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_40);  // dimen:stamp_icon_size_40
            }
        }

        if (!mainActivity0.isAddress && !mainActivity0.isLatLng && !mainActivity0.isDateTime && !mainActivity0.isNotes && !mainActivity0.isWind && !mainActivity0.isHumidity && !mainActivity0.isAccuracy && !mainActivity0.isPressure && !mainActivity0.isAltitude && !mainActivity0.isNumbering && !mainActivity0.istimezone && !mainActivity0.isPlusCode) {
            mainActivity0.li_address.setVisibility(View.GONE);
            mainActivity0.li_rightView.setOrientation(0);
            mainActivity0.li_rightView.setGravity(17);
            mainActivity0.li_rightView.getLayoutParams().width = -1;
            mainActivity0.li_rightView.getLayoutParams().width = -1;
            if ((mainActivity0.isLogo) && !mainActivity0.isMap) {
                if (mainActivity0.stamp_size.equals("Large")) {
                    System.out.println("Called           45L");
                    ViewGroup.LayoutParams viewGroup$LayoutParams351 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams351.height = (int) this.getResources().getDimension(R.dimen.stamp_80dp);  // dimen:stamp_80dp
                } else {
                    System.out.println("Called           45");
                    ViewGroup.LayoutParams viewGroup$LayoutParams352 = mainActivity0.li_stamp.getLayoutParams();
                    viewGroup$LayoutParams352.height = (int) this.getResources().getDimension(R.dimen.stamp_icon_size_40);  // dimen:stamp_icon_size_40
                }
            }
        } else {
            mainActivity0.li_address.setVisibility(View.VISIBLE);
            mainActivity0.li_rightView.setOrientation(1);
            mainActivity0.li_rightView.setGravity(19);
            mainActivity0.li_rightView.getLayoutParams().width = -2;
            mainActivity0.li_rightView.getLayoutParams().width = -2;
        }

        if ((mainActivity0.isMap) && !mainActivity0.isAddress && !mainActivity0.isLatLng && !mainActivity0.isDateTime && !mainActivity0.isCompass && !mainActivity0.isMagneticField && !mainActivity0.isWeather && !mainActivity0.isNotes && !mainActivity0.isWind && !mainActivity0.isHumidity && !mainActivity0.isAccuracy && !mainActivity0.isPressure && !mainActivity0.isAltitude && !mainActivity0.isLogo && !mainActivity0.isNumbering && !mainActivity0.istimezone && !mainActivity0.isPlusCode) {
            mainActivity0.li_stamp.setVisibility(4);
        } else {
            mainActivity0.li_stamp.setVisibility(View.VISIBLE);
        }

        if (!mainActivity0.isLatLng && !mainActivity0.isAddress && !mainActivity0.isDateTime && !mainActivity0.isNotes && !mainActivity0.isNumbering && !mainActivity0.istimezone && !mainActivity0.isPlusCode) {
            mainActivity0.tv_address_line_1.setVisibility(View.GONE);
        } else {
            mainActivity0.tv_address_line_1.setVisibility(View.VISIBLE);
        }

        if (mainActivity0.mSP.getBoolean(mainActivity0, "is_water_mark", true)) {
            if (v == 0) {
                s5 = mainActivity0.sharedPreferences.getString("stamp_pos", "Bottom");
                if (s5.equals("Bottom")) {
                    mainActivity0.li_stamp.setBackground(this.getResources().getDrawable(R.drawable.rect_grey_1));  // drawable:rect_grey_1
                } else {
                    mainActivity0.li_stamp.setBackground(this.getResources().getDrawable(R.drawable.rect_grey_3));  // drawable:rect_grey_3
                }

                mainActivity0.lin_waterma.setBackground(this.getResources().getDrawable(R.drawable.rect_grey_2));  // drawable:rect_grey_2
                mainActivity0.lin_waterma_2.setBackground(this.getResources().getDrawable(R.drawable.rect_grey_4));  // drawable:rect_grey_4
            } else {
                mainActivity0.li_stamp.setBackground(this.getResources().getDrawable(R.drawable.classic_back));  // drawable:classic_back
                mainActivity0.lin_waterma.setBackground(this.getResources().getDrawable(R.drawable.classic_back));  // drawable:classic_back
                mainActivity0.lin_waterma_2.setBackground(this.getResources().getDrawable(R.drawable.classic_back));  // drawable:classic_back
                s5 = mainActivity0.sharedPreferences.getString("stamp_pos_classic", "Bottom");
            }

            if (s5.equals("Bottom")) {
                mainActivity0.lin_waterma.setVisibility(View.VISIBLE);
                mainActivity0.lin_waterma_2.setVisibility(View.GONE);
                ((GradientDrawable) mainActivity0.lin_waterma.getBackground().getCurrent()).setColor(v1);
            } else {
                mainActivity0.lin_waterma.setVisibility(View.GONE);
                mainActivity0.lin_waterma_2.setVisibility(View.VISIBLE);
                ((GradientDrawable) mainActivity0.lin_waterma_2.getBackground().getCurrent()).setColor(v1);
            }

            if ((mainActivity0.stamp_size.equals("Small")) || (mainActivity0.stamp_size.equals("Medium"))) {
                LinearLayout.LayoutParams linearLayout$LayoutParams7 = (LinearLayout.LayoutParams) mainActivity0.imgstamp_1.getLayoutParams();
                linearLayout$LayoutParams7.height = Util.dpToPx(mainActivity0, 20);
                linearLayout$LayoutParams7.width = Util.dpToPx(mainActivity0, 20);
                LinearLayout.LayoutParams linearLayout$LayoutParams8 = (LinearLayout.LayoutParams) mainActivity0.imgstamp_2.getLayoutParams();
                linearLayout$LayoutParams8.height = Util.dpToPx(mainActivity0, 20);
                linearLayout$LayoutParams8.width = Util.dpToPx(mainActivity0, 20);
                mainActivity0.txt_watermark_1.setTextSize(7.0f);
                mainActivity0.txt_watermark_2.setTextSize(7.0f);
            } else if (mainActivity0.stamp_size.equals("Extra Small")) {
                LinearLayout.LayoutParams linearLayout$LayoutParams3 = (LinearLayout.LayoutParams) mainActivity0.imgstamp_1.getLayoutParams();
                linearLayout$LayoutParams3.height = Util.dpToPx(mainActivity0, 14);
                linearLayout$LayoutParams3.width = Util.dpToPx(mainActivity0, 14);
                LinearLayout.LayoutParams linearLayout$LayoutParams4 = (LinearLayout.LayoutParams) mainActivity0.imgstamp_2.getLayoutParams();
                linearLayout$LayoutParams4.height = Util.dpToPx(mainActivity0, 14);
                linearLayout$LayoutParams4.width = Util.dpToPx(mainActivity0, 14);
                mainActivity0.txt_watermark_1.setTextSize(5.0f);
                mainActivity0.txt_watermark_2.setTextSize(5.0f);
            } else {
                LinearLayout.LayoutParams linearLayout$LayoutParams5 = (LinearLayout.LayoutParams) mainActivity0.imgstamp_1.getLayoutParams();
                linearLayout$LayoutParams5.height = Util.dpToPx(mainActivity0, 24);
                linearLayout$LayoutParams5.width = Util.dpToPx(mainActivity0, 24);
                LinearLayout.LayoutParams linearLayout$LayoutParams6 = (LinearLayout.LayoutParams) mainActivity0.imgstamp_2.getLayoutParams();
                linearLayout$LayoutParams6.height = Util.dpToPx(mainActivity0, 24);
                linearLayout$LayoutParams6.width = Util.dpToPx(mainActivity0, 24);
                mainActivity0.txt_watermark_1.setTextSize(9.0f);
                mainActivity0.txt_watermark_2.setTextSize(9.0f);
            }
        } else {
            mainActivity0.lin_waterma.setVisibility(View.GONE);
            mainActivity0.lin_waterma_2.setVisibility(View.GONE);
            if (v == 0) {
                mainActivity0.li_stamp.setBackground(this.getResources().getDrawable(R.drawable.rect_grey));  // drawable:rect_grey
            } else {
                mainActivity0.li_stamp.setBackground(this.getResources().getDrawable(R.drawable.classic_back));  // drawable:classic_back
            }
        }

        ((GradientDrawable) mainActivity0.li_stamp.getBackground().getCurrent()).setColor(v1);
        String s = CameraMainActivity.this.mSP.getInteger(CameraMainActivity.this, "template_type", 0) == 0 ? CameraMainActivity.this.mSP.getString(CameraMainActivity.this, "logo_uri", "no_logo") : CameraMainActivity.this.mSP.getString(CameraMainActivity.this, "logo_uri_classic", "no_logo");
        if (s.equals("no_logo")) {
            CameraMainActivity.this.imgLogo.setImageResource(R.mipmap.ic_launcher);  // mipmap:ic_launcher
            return;
        }
        new Handler().post(new Runnable() {
            @Override
            public void run() {
                Glide.with(CameraMainActivity.this).load(Util.decodeBase64(s)).into(CameraMainActivity.this.imgLogo);
            }
        });
        mainActivity0.tv_weather.setTextColor(v2);
        mainActivity0.tv_magnetic_field.setTextColor(v3);
        mainActivity0.tv_compass.setTextColor(v5);
    }

    private int DH;
    private int DW;
    float scale;

    public void setUpStampLayout2() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.DW = displayMetrics.heightPixels;
        this.DH = displayMetrics.widthPixels;

        this.scale = displayMetrics.scaledDensity;
        double f10;
        double f9;
        double f8;
        double f7;
        float f5;
        float f4;
        TextView textView24;
        TextView textView23;
        String s31;
        int v238;
        TextView textView19;
        LinearLayout linearLayout35;
        LinearLayout linearLayout34;
        LinearLayout linearLayout33;
        LinearLayout linearLayout32;
        String s15;
        LinearLayout linearLayout31;
        int v230;
        int v229;
        int v224;
        TextView textView15;
        ImageView imageView14;
        LinearLayout linearLayout30;
        int v222;
        TextView textView14;
        LinearLayout linearLayout29;
        ImageView imageView13 = null;
        ImageView imageView12;
        int v219;
        int v218;
        LinearLayout linearLayout28;
        ImageView imageView11;
        int v217;
        LinearLayout linearLayout27;
        LinearLayout linearLayout26;
        int v216;
        TextView textView13;
        LinearLayout linearLayout25;
        LinearLayout linearLayout24 = null;
        TextView textView12 = null;
        LinearLayout linearLayout23;
        LinearLayout linearLayout22;
        int v215;
        TextView textView11;
        int v214;
        LinearLayout linearLayout21;
        LinearLayout linearLayout18;
        LinearLayout linearLayout17;
        RoundCorners roundCorners2;
        int v212;
        int v211;
        int v210;
        int v109;
        int v108;
        int v107;
        RoundCorners roundCorners1;
        int v106;
        int v105;
        int v104;
        int v103;
        int v102;
        int v101;
        int v100;
        int v99;
        int v98;
        int v97;
        int v96;
        int v95;
        int v94;
        int v93;
        int v92;
        int v91;
        int v90;
        int v89;
        int v88;
        ImageView imageView10;
        int v87;
        LinearLayout linearLayout16;
        boolean z19;
        boolean z17;
        boolean z16;
        boolean z15;
        boolean z14;
        boolean z13;
        boolean z12;
        boolean z11;
        boolean z10;
        boolean z9;
        boolean z8;
        boolean z7;
        boolean z6;
        boolean z5;
        boolean z4;
        boolean z3;
        boolean z2;
        boolean z1;
        String s;
        String s1;
        String s2;
        String s3;
        String s4;
        String s5;
        String s6;
        int v26;
        int v25;
        int v24;
        int v23;
        int v22;
        float f;
        int v21;
        int v20;
        int v19;
        int v16;
        int v15;
        int v14;
        int v13;
        int v12;
        int v11;
        int v10;
        int v9;
        int v8;
        int v7;
        int v6;
        int v5;
        int v4;
        int v3;
        int v2;
        try {
            int v = mSP.getInteger(this, "template_type", 0);
            boolean z = mSP.getBoolean(this, "compass_found", false);
            if (v == 0) {
                z1 = mSP.getBoolean(this, "is_map", true);
                z2 = mSP.getBoolean(this, "is_address", true);
                z3 = mSP.getBoolean(this, "is_lat_lng_template", true);
                z4 = mSP.getBoolean(this, "is_plus_code", false);
                z5 = mSP.getBoolean(this, "is_weather", false);
                z6 = mSP.getBoolean(this, "is_date_time", true);
                z7 = mSP.getBoolean(this, "is_timezone", true);
                z8 = mSP.getBoolean(this, "is_numbering", false);
                z9 = mSP.getBoolean(this, "is_increment", true);
                z10 = mSP.getBoolean(this, "is_magnetic_field", false);
                z11 = mSP.getBoolean(this, "is_compass", false);
                z12 = mSP.getBoolean(this, "is_logo", false);
                z13 = mSP.getBoolean(this, "is_notes", false);
                s = mSP.getString(this, "stamp_size", "Medium");
                s1 = mSP.getString(this, "plusCodeType", "accurate");
                z14 = mSP.getBoolean(this, "is_humidity", false);
                z15 = mSP.getBoolean(this, "is_accuracy", false);
                z16 = mSP.getBoolean(this, "is_altitude", false);
                z17 = mSP.getBoolean(this, "is_wind", false);
                boolean z18 = mSP.getBoolean(this, "is_pressure", false);
                SP sP0 = mSP;
                z19 = z18;
                int v1 = Color.parseColor("#9c000000");
                v2 = sP0.getInteger(this, "BACKGROUND_COLOR", v1);
                v3 = mSP.getInteger(this, "WEATHER_COLOR", -1);
                v4 = mSP.getInteger(this, "MAGNETIC_FIELD_COLOR", -1);
                v5 = mSP.getInteger(this, "COMPASS_COLOR", -1);
                v6 = mSP.getInteger(this, "ADDRESS_COLOR", -1);
                v7 = mSP.getInteger(this, "DATE_TIME_COLOR", -1);
                v8 = mSP.getInteger(this, "LAT_LNG_COLOR", -1);
                v9 = mSP.getInteger(this, "PLUS_CODE_COLOR", -1);
                v10 = mSP.getInteger(this, "NOTES_HASHTAG_COLOR", -1);
                v11 = mSP.getInteger(this, "WIND_COLOR", -1);
                v12 = mSP.getInteger(this, "PRESSURE_COLOR", -1);
                v13 = mSP.getInteger(this, "HUMIDITY_COLOR", -1);
                v14 = mSP.getInteger(this, "ALTITUDE_COLOR", -1);
                v15 = mSP.getInteger(this, "ACCURACY_COLOR", -1);
                v16 = mSP.getInteger(this, "NUMBERING_COLOR", -1);
                int v17 = mSP.getInteger(this, "TIME_ZONE", 6);
                int v18 = mSP.getInteger(this, "SEQUENCE", 1);
                v19 = v17;
                s2 = mSP.getString(this, "PREFIX", "");
                s3 = mSP.getString(this, "SUFFIX", "");
                v20 = v18;
                s4 = mSP.getString(this, "date_format", "dd/MM/yy hh:mm a");
                v21 = mSP.getInteger(this, "lat_lng_type_1", 1);
                s5 = mSP.getString(this, "temprature_type", "Celsius");
                f = mSP.getFloat(this, "temprature_value");
                v22 = mSP.getInteger(this, "weather_icon", 0);
                v23 = mSP.getInteger(this, "wind_select", 0);
                v24 = mSP.getInteger(this, "pressure_select", 0);
                v25 = mSP.getInteger(this, "altitude_select", 0);
                v26 = mSP.getInteger(this, "accuracy_select", 0);
                s6 = mSP.getString(this, "logo_uri", "no_logo");
            } else {
                z1 = mSP.getBoolean(this, "is_map_classic", true);
                z2 = mSP.getBoolean(this, "is_address_classic", true);
                z3 = mSP.getBoolean(this, "is_lat_lng_template_classic", true);
                z4 = mSP.getBoolean(this, "is_plus_code_classic", false);
                z5 = mSP.getBoolean(this, "is_weather_classic", false);
                z6 = mSP.getBoolean(this, "is_date_time_classic", true);
                z7 = mSP.getBoolean(this, "is_timezone_classic", true);
                z8 = mSP.getBoolean(this, "is_numbering_classic", false);
                z9 = mSP.getBoolean(this, "is_increment_classic", true);
                z10 = mSP.getBoolean(this, "is_magnetic_field_classic", false);
                z11 = mSP.getBoolean(this, "is_compass_classic", false);
                z12 = mSP.getBoolean(this, "is_logo_classic", false);
                z13 = mSP.getBoolean(this, "is_notes_classic", false);
                s = mSP.getString(this, "stamp_size_classic", "Medium");
                s1 = mSP.getString(this, "stamp_size_classic", "accurate");
                z14 = mSP.getBoolean(this, "is_humidity_classic", false);
                z15 = mSP.getBoolean(this, "is_accuracy_classic", false);
                z16 = mSP.getBoolean(this, "is_altitude_classic", false);
                z17 = mSP.getBoolean(this, "is_wind_classic", false);
                boolean z20 = mSP.getBoolean(this, "is_pressure_classic", false);
                SP sP1 = mSP;
                z19 = z20;
                int v27 = Color.parseColor("#9c000000");
                v2 = sP1.getInteger(this, "BACKGROUND_COLOR_CLASSIC", v27);
                v3 = mSP.getInteger(this, "WEATHER_COLOR_CLASSIC", -1);
                v4 = mSP.getInteger(this, "MAGNETIC_FIELD_COLOR_CLASSIC", -1);
                v5 = mSP.getInteger(this, "COMPASS_COLOR_CLASSIC", -1);
                v6 = mSP.getInteger(this, "ADDRESS_COLOR_CLASSIC", -1);
                v7 = mSP.getInteger(this, "DATE_TIME_COLOR_CLASSIC", -1);
                v8 = mSP.getInteger(this, "LAT_LNG_COLOR_CLASSIC", -1);
                v9 = mSP.getInteger(this, "PLUS_CODE_COLOR_CLASSIC", -1);
                v10 = mSP.getInteger(this, "NOTES_HASHTAG_COLOR_CLASSIC", -1);
                v11 = mSP.getInteger(this, "WIND_COLOR_CLASSIC", -1);
                v12 = mSP.getInteger(this, "PRESSURE_COLOR_CLASSIC", -1);
                v13 = mSP.getInteger(this, "HUMIDITY_COLOR_CLASSIC", -1);
                v14 = mSP.getInteger(this, "ALTITUDE_COLOR_CLASSIC", -1);
                v15 = mSP.getInteger(this, "ACCURACY_COLOR_CLASSIC", -1);
                v16 = mSP.getInteger(this, "NUMBERING_COLOR_CLASSIC", -1);
                int v28 = mSP.getInteger(this, "TIME_ZONE_CLASSIC", 6);
                int v29 = mSP.getInteger(this, "SEQUENCE_CLASSIC", 1);
                v19 = v28;
                s2 = mSP.getString(this, "PREFIX_CLASSIC", "");
                s3 = mSP.getString(this, "SUFFIX_CLASSIC", "");
                v20 = v29;
                s4 = mSP.getString(this, "date_format_classic", "dd/MM/yy hh:mm a");
                v21 = mSP.getInteger(this, "lat_lng_type_1_classic", 1);
                s5 = mSP.getString(this, "temprature_type_classic", "Celsius");
                f = mSP.getFloat(this, "temprature_value");
                v22 = mSP.getInteger(this, "weather_icon", 0);
                v23 = mSP.getInteger(this, "wind_select_classic", 0);
                v24 = mSP.getInteger(this, "pressure_select_classic", 0);
                v25 = mSP.getInteger(this, "altitude_select_classic", 0);
                v26 = mSP.getInteger(this, "accuracy_select_classic", 0);
                s6 = mSP.getString(this, "logo_uri_classic", "no_logo");
            }

            String s7 = s6;
            String s8 = s;
            int v30 = v6;
            int v31 = v7;
            int v32 = v8;
            int v33 = v9;
            int v34 = v10;
            int v35 = v11;
            int v36 = v12;
            int v37 = v13;
            int v38 = v16;
            int v39 = v20;
            int v40 = v21;
            String s9 = s5;
            int v41 = v24;
            boolean z21 = z1;
            boolean z22 = z2;
            boolean z23 = z6;
            boolean z24 = z7;
            boolean z25 = z9;
            String s10 = s2;
            String s11 = s3;
            String s12 = s1;
            boolean z26 = z3;
            int v42 = v19;
            int v43 = v23;
            int v44 = v5;

            TextView tv_address_line_1 = this.tv_address_line_1;  // id:tv_address_line_1
            TextView tv_address = this.tv_address;  // id:tv_address
            TextView tv_weather = this.tv_weather;  // id:tv_weather
            int v45 = v4;
            TextView tv_compass = this.tv_compass;  // id:tv_compass
            int v46 = v3;
            TextView txt_watermark = this.txt_watermark_1;  // id:txt_watermark
            int v47 = v2;
            TextView txt_watermark_2 = this.txt_watermark_2;  // id:txt_watermark_2
            TextView textView6 = tv_address_line_1;
            TextView tv_magnetic_field = this.tv_magnetic_field;  // id:tv_magnetic_field
            boolean z27 = z;
            TextView txt_wind = this.txt_wind;  // id:txt_wind
            int v48 = v15;
            TextView txt_humidity = this.txt_humidity;  // id:txt_humidity
            int v49 = v26;
            TextView txt_pressure = this.txt_pressure;  // id:txt_pressure
            int v50 = v14;
            RoundCorners imgMap = this.imgMap;  // id:imgMap
            int v51 = v25;
            LinearLayout li_main_stamp_lay = this.li_main_stamp_lay;  // id:li_main_stamp_lay
            int v52 = v22;
            LinearLayout li_stamp = this.li_stamp;  // id:li_stamp
            LinearLayout lin_waterma = this.lin_waterma;  // id:lin_waterma
            LinearLayout lin_waterma_2 = this.lin_waterma_2;  // id:lin_waterma_2
            LinearLayout li_compass = this.li_compass;  // id:li_compass
            LinearLayout li_logo = this.li_logo;  // id:li_logo
            LinearLayout lin_bottom_wather = this.lin_bottom_wether;  // id:lin_bottom_wather
            LinearLayout li_main_stamp_lay2 = li_main_stamp_lay;
            LinearLayout lin_wind_stamp = this.lin_wind_stamp;  // id:lin_wind_stamp
            LinearLayout lin_humidity_stamp = this.lin_humity_stamp;  // id:lin_humidity_stamp
            LinearLayout lin_pressure_stamp = this.lin_pressure_stamp;  // id:lin_pressure_stamp
            ImageView imgCompass = (ImageView) this.imgCompass;  // id:imgCompass
            LinearLayout lin_bottom_wather2 = lin_bottom_wather;
            ImageView img_stamp = this.imgstamp_1;  // id:img_stamp
            ImageView img_stamp_2 = this.imgstamp_2;  // id:img_stamp_2
            ImageView imgWeather = this.imgWeather;  // id:imgWeather
            ImageView imgMagneticField = this.img_magnetic_field;  // id:imgMagneticField
            ImageView imgCompass2 = imgCompass;
            ImageView imgLogo = this.imgLogo;  // id:imgLogo
            ImageView img_wind_stamp = this.img_wind_stamp;  // id:img_wind_stamp
            ImageView img_humidity_stamp = this.img_humidity_stamp;  // id:img_humidity_stamp
            ImageView img_pressure_stamp = this.img_pressure_stamp;  // id:img_pressure_stamp
            LinearLayout li_rightView = this.li_rightView;  // id:li_rightView
            LinearLayout li_address = this.li_address;  // id:li_address
            LinearLayout li_magnetic_field = this.li_magnetic_field;  // id:li_magnetic_field
            LinearLayout li_weather = this.li_weather;
            View view1 = this.li_stamp;
            View bitmap0 = view1;
            Canvas canvas0 = new Canvas();
            if (s8.equals("Large")) {
                linearLayout16 = li_weather;
                int v53 = (int) (((float) bitmap0.getWidth()) * (this.scale * 6.0f) / ((float) this.DW));
                int v54 = (int) (((float) bitmap0.getWidth()) * (this.scale * 8.0f) / ((float) this.DW));
                int v55 = (int) (((float) bitmap0.getWidth()) * (this.scale * 10.0f) / ((float) this.DW));
                int v56 = (int) (((float) bitmap0.getWidth()) * (this.scale * 12.0f) / ((float) this.DW));
                int v57 = (int) (((float) bitmap0.getWidth()) * (this.scale * 18.0f) / ((float) this.DW));
                int v58 = (int) (((float) bitmap0.getWidth()) * (this.scale * 16.0f) / ((float) this.DW));
                int v59 = (int) (((float) bitmap0.getWidth()) * (this.scale * 4.0f) / ((float) this.DW));
                bitmap0.getWidth();
                int v60 = v59;
                int v61 = (int) (((float) bitmap0.getWidth()) * (this.scale * 36.0f) / ((float) this.DW));
                int v62 = (int) (((float) bitmap0.getWidth()) * (this.scale * 30.0f) / ((float) this.DW));
                int v63 = (int) (((float) bitmap0.getWidth()) * (this.scale * 60.0f) / ((float) this.DW));
                int v64 = (int) (((float) bitmap0.getWidth()) * (this.scale * 200.0f) / ((float) this.DW));
                int v65 = v63;
                int v66 = (int) (((float) bitmap0.getWidth()) * (this.scale * 210.0f) / ((float) this.DW));
                int v67 = (int) (((float) bitmap0.getWidth()) * (this.scale * 240.0f) / ((float) this.DW));
                int v68 = (int) (((float) bitmap0.getWidth()) * (this.scale * 250.0f) / ((float) this.DW));
                int v69 = (int) (((float) bitmap0.getWidth()) * (this.scale * 243.0f) / ((float) this.DW));
                int v70 = (int) (((float) bitmap0.getWidth()) * (this.scale * 253.0f) / ((float) this.DW));
                int v71 = (int) (((float) bitmap0.getWidth()) * (this.scale * 255.0f) / ((float) this.DW));
                int v72 = (int) (((float) bitmap0.getWidth()) * (this.scale * 130.0f) / ((float) this.DW));
                int v73 = (int) (((float) bitmap0.getWidth()) * (this.scale * 140.0f) / ((float) this.DW));
                int v74 = (int) (((float) bitmap0.getWidth()) * (this.scale * 155.0f) / ((float) this.DW));
                int v75 = (int) (((float) bitmap0.getWidth()) * (this.scale * 160.0f) / ((float) this.DW));
                int v76 = (int) (((float) bitmap0.getWidth()) * (this.scale * 170.0f) / ((float) this.DW));
                int v77 = (int) (((float) bitmap0.getWidth()) * (this.scale * 180.0f) / ((float) this.DW));
                if (bitmap0.getWidth()>bitmap0.getHeight()) {
                    v64 = (int) (((float) bitmap0.getWidth()) * (this.scale * 170.0f) / ((float) this.DW));
                    int v78 = (int) (((float) bitmap0.getWidth()) * (this.scale * 180.0f) / ((float) this.DW));
                    int v79 = (int) (((float) bitmap0.getWidth()) * (this.scale * 210.0f) / ((float) this.DW));
                    int v80 = (int) (((float) bitmap0.getWidth()) * (this.scale * 220.0f) / ((float) this.DW));
                    int v81 = (int) (((float) bitmap0.getWidth()) * (this.scale * 213.0f) / ((float) this.DW));
                    int v82 = (int) (((float) bitmap0.getWidth()) * (this.scale * 223.0f) / ((float) this.DW));
                    int v83 = (int) (((float) bitmap0.getWidth()) * (this.scale * 225.0f) / ((float) this.DW));
                    int v84 = (int) (((float) bitmap0.getWidth()) * (this.scale * 80.0f) / ((float) this.DW));
                    int v85 = (int) (((float) bitmap0.getWidth()) * (this.scale * 85.0f) / ((float) this.DW));
                    int v86 = (int) (((float) bitmap0.getWidth()) * (this.scale * 105.0f) / ((float) this.DW));
                    v87 = (int) (((float) bitmap0.getWidth()) * (this.scale * 110.0f) / ((float) this.DW));
                    imageView10 = imgMagneticField;
                    v88 = v78;
                    v89 = v86;
                    v90 = v79;
                    v91 = v80;
                    v92 = v81;
                    v93 = v82;
                    v94 = v53;
                    v95 = v54;
                    v96 = v55;
                    v97 = v58;
                    v98 = v60;
                    v99 = v61;
                    v100 = v62;
                    v101 = v65;
                    v102 = v83;
                    v103 = v84;
                    v104 = v85;
                } else {
                    imageView10 = imgMagneticField;
                    v89 = v74;
                    v103 = v72;
                    v87 = v75;
                    v94 = v53;
                    v95 = v54;
                    v96 = v55;
                    v97 = v58;
                    v98 = v60;
                    v99 = v61;
                    v100 = v62;
                    v101 = v65;
                    v88 = v66;
                    v90 = v67;
                    v91 = v68;
                    v92 = v69;
                    v93 = v70;
                    v102 = v71;
                    v104 = v73;
                }

                v105 = v76;
                v106 = v77;
                roundCorners1 = imgMap;
                v107 = v64;
                v108 = v56;
                v109 = v57;
            } else {
                linearLayout16 = li_weather;
                if (s8.equals("Medium")) {
                    int v110 = (int) (((float) bitmap0.getWidth()) * (this.scale * 4.0f) / ((float) this.DW));
                    int v111 = (int) (((float) bitmap0.getWidth()) * (this.scale * 6.0f) / ((float) this.DW));
                    int v112 = (int) (((float) bitmap0.getWidth()) * (this.scale * 8.0f) / ((float) this.DW));
                    int v113 = (int) (((float) bitmap0.getWidth()) * (this.scale * 10.0f) / ((float) this.DW));
                    v109 = (int) (((float) bitmap0.getWidth()) * (this.scale * 16.0f) / ((float) this.DW));
                    int v114 = (int) (((float) bitmap0.getWidth()) * (this.scale * 14.0f) / ((float) this.DW));
                    int v115 = (int) (((float) bitmap0.getWidth()) * (this.scale * 2.0f) / ((float) this.DW));
                    bitmap0.getWidth();
                    int v116 = v114;
                    int v117 = (int) (((float) bitmap0.getWidth()) * (this.scale * 33.0f) / ((float) this.DW));
                    int v118 = (int) (((float) bitmap0.getWidth()) * (this.scale * 30.0f) / ((float) this.DW));
                    int v119 = (int) (((float) bitmap0.getWidth()) * (this.scale * 55.0f) / ((float) this.DW));
                    int v120 = (int) (((float) bitmap0.getWidth()) * (this.scale * 170.0f) / ((float) this.DW));
                    int v121 = (int) (((float) bitmap0.getWidth()) * (this.scale * 180.0f) / ((float) this.DW));
                    int v122 = (int) (((float) bitmap0.getWidth()) * (this.scale * 200.0f) / ((float) this.DW));
                    int v123 = (int) (((float) bitmap0.getWidth()) * (this.scale * 210.0f) / ((float) this.DW));
                    int v124 = (int) (((float) bitmap0.getWidth()) * (this.scale * 195.0f) / ((float) this.DW));
                    int v125 = (int) (((float) bitmap0.getWidth()) * (this.scale * 215.0f) / ((float) this.DW));
                    int v126 = (int) (((float) bitmap0.getWidth()) * (this.scale * 210.0f) / ((float) this.DW));
                    int v127 = (int) (((float) bitmap0.getWidth()) * (this.scale * 114.0f) / ((float) this.DW));
                    int v128 = (int) (((float) bitmap0.getWidth()) * (this.scale * 120.0f) / ((float) this.DW));
                    int v129 = (int) (((float) bitmap0.getWidth()) * (this.scale * 125.0f) / ((float) this.DW));
                    int v130 = (int) (((float) bitmap0.getWidth()) * (this.scale * 140.0f) / ((float) this.DW));
                    int v131 = (int) (((float) bitmap0.getWidth()) * (this.scale * 160.0f) / ((float) this.DW));
                    int v132 = (int) (((float) bitmap0.getWidth()) * (this.scale * 170.0f) / ((float) this.DW));
                    if (bitmap0.getWidth()>bitmap0.getHeight()) {
                        int v133 = (int) (((float) bitmap0.getWidth()) * (this.scale * 150.0f) / ((float) this.DW));
                        int v134 = (int) (((float) bitmap0.getWidth()) * (this.scale * 160.0f) / ((float) this.DW));
                        int v135 = (int) (((float) bitmap0.getWidth()) * (this.scale * 190.0f) / ((float) this.DW));
                        int v136 = (int) (((float) bitmap0.getWidth()) * (this.scale * 200.0f) / ((float) this.DW));
                        int v137 = (int) (((float) bitmap0.getWidth()) * (this.scale * 195.0f) / ((float) this.DW));
                        int v138 = (int) (((float) bitmap0.getWidth()) * (this.scale * 203.0f) / ((float) this.DW));
                        int v139 = (int) (((float) bitmap0.getWidth()) * (this.scale * 205.0f) / ((float) this.DW));
                        int v140 = (int) (((float) bitmap0.getWidth()) * (this.scale * 80.0f) / ((float) this.DW));
                        int v141 = (int) (((float) bitmap0.getWidth()) * (this.scale * 85.0f) / ((float) this.DW));
                        int v142 = (int) (((float) bitmap0.getWidth()) * (this.scale * 90.0f) / ((float) this.DW));
                        v87 = (int) (((float) bitmap0.getWidth()) * (this.scale * 100.0f) / ((float) this.DW));
                        v94 = v110;
                        v90 = v135;
                        v88 = v134;
                        v106 = v132;
                        v91 = v136;
                        v92 = v137;
                        v101 = v119;
                        v95 = v111;
                        v96 = v112;
                        v97 = v116;
                        v99 = v117;
                        v100 = v118;
                        v93 = v138;
                        v102 = v139;
                        v103 = v140;
                        v104 = v141;
                        v89 = v142;
                        v105 = v131;
                        v98 = v115;
                        imageView10 = imgMagneticField;
                        v108 = v113;
                        roundCorners1 = imgMap;
                        v107 = v133;
                    } else {
                        v94 = v110;
                        v87 = v130;
                        v88 = v121;
                        v89 = v129;
                        v106 = v132;
                        v101 = v119;
                        v95 = v111;
                        v96 = v112;
                        v97 = v116;
                        v99 = v117;
                        v100 = v118;
                        v90 = v122;
                        v93 = v125;
                        v91 = v123;
                        v92 = v124;
                        v102 = v126;
                        v103 = v127;
                        v104 = v128;
                        v105 = v131;
                        roundCorners1 = imgMap;
                        v98 = v115;
                        imageView10 = imgMagneticField;
                        v108 = v113;
                        v107 = v120;
                    }
                } else if (s8.equals("Small")) {
                    int v143 = (int) (((float) bitmap0.getWidth()) * (this.scale * 3.0f) / ((float) this.DW));
                    int v144 = (int) (((float) bitmap0.getWidth()) * (this.scale * 5.0f) / ((float) this.DW));
                    int v145 = (int) (((float) bitmap0.getWidth()) * (this.scale * 7.0f) / ((float) this.DW));
                    int v146 = (int) (((float) bitmap0.getWidth()) * (this.scale * 9.0f) / ((float) this.DW));
                    v109 = (int) (((float) bitmap0.getWidth()) * (this.scale * 15.0f) / ((float) this.DW));
                    int v147 = (int) (((float) bitmap0.getWidth()) * (this.scale * 13.0f) / ((float) this.DW));
                    int v148 = (int) (((float) bitmap0.getWidth()) * (this.scale * 2.0f) / ((float) this.DW));
                    bitmap0.getWidth();
                    int v149 = v147;
                    int v150 = (int) (((float) bitmap0.getWidth()) * (this.scale * 32.0f) / ((float) this.DW));
                    int v151 = (int) (((float) bitmap0.getWidth()) * (this.scale * 28.0f) / ((float) this.DW));
                    int v152 = (int) (((float) bitmap0.getWidth()) * (this.scale * 50.0f) / ((float) this.DW));
                    int v153 = (int) (((float) bitmap0.getWidth()) * (this.scale * 160.0f) / ((float) this.DW));
                    int v154 = (int) (((float) bitmap0.getWidth()) * (this.scale * 170.0f) / ((float) this.DW));
                    int v155 = (int) (((float) bitmap0.getWidth()) * (this.scale * 190.0f) / ((float) this.DW));
                    int v156 = (int) (((float) bitmap0.getWidth()) * (this.scale * 200.0f) / ((float) this.DW));
                    int v157 = (int) (((float) bitmap0.getWidth()) * (this.scale * 185.0f) / ((float) this.DW));
                    int v158 = (int) (((float) bitmap0.getWidth()) * (this.scale * 205.0f) / ((float) this.DW));
                    int v159 = (int) (((float) bitmap0.getWidth()) * (this.scale * 200.0f) / ((float) this.DW));
                    int v160 = (int) (((float) bitmap0.getWidth()) * (this.scale * 104.0f) / ((float) this.DW));
                    int v161 = (int) (((float) bitmap0.getWidth()) * (this.scale * 110.0f) / ((float) this.DW));
                    int v162 = (int) (((float) bitmap0.getWidth()) * (this.scale * 115.0f) / ((float) this.DW));
                    int v163 = (int) (((float) bitmap0.getWidth()) * (this.scale * 130.0f) / ((float) this.DW));
                    int v164 = (int) (((float) bitmap0.getWidth()) * (this.scale * 150.0f) / ((float) this.DW));
                    int v165 = (int) (((float) bitmap0.getWidth()) * (this.scale * 160.0f) / ((float) this.DW));
                    if (bitmap0.getWidth()>bitmap0.getHeight()) {
                        int v166 = (int) (((float) bitmap0.getWidth()) * (this.scale * 140.0f) / ((float) this.DW));
                        int v167 = (int) (((float) bitmap0.getWidth()) * (this.scale * 150.0f) / ((float) this.DW));
                        int v168 = (int) (((float) bitmap0.getWidth()) * (this.scale * 180.0f) / ((float) this.DW));
                        int v169 = (int) (((float) bitmap0.getWidth()) * (this.scale * 190.0f) / ((float) this.DW));
                        int v170 = (int) (((float) bitmap0.getWidth()) * (this.scale * 185.0f) / ((float) this.DW));
                        int v171 = (int) (((float) bitmap0.getWidth()) * (this.scale * 193.0f) / ((float) this.DW));
                        int v172 = (int) (((float) bitmap0.getWidth()) * (this.scale * 195.0f) / ((float) this.DW));
                        int v173 = (int) (((float) bitmap0.getWidth()) * (this.scale * 70.0f) / ((float) this.DW));
                        int v174 = (int) (((float) bitmap0.getWidth()) * (this.scale * 75.0f) / ((float) this.DW));
                        int v175 = (int) (((float) bitmap0.getWidth()) * (this.scale * 85.0f) / ((float) this.DW));
                        v87 = (int) (((float) bitmap0.getWidth()) * (this.scale * 90.0f) / ((float) this.DW));
                        v98 = v148;
                        v88 = v167;
                        v94 = v143;
                        v90 = v168;
                        v91 = v169;
                        v106 = v165;
                        v92 = v170;
                        v101 = v152;
                        v95 = v144;
                        v96 = v145;
                        v108 = v146;
                        v97 = v149;
                        v99 = v150;
                        v100 = v151;
                        v93 = v171;
                        v102 = v172;
                        v103 = v173;
                        v104 = v174;
                        v89 = v175;
                        v105 = v164;
                        roundCorners1 = imgMap;
                        v107 = v166;
                    } else {
                        roundCorners1 = imgMap;
                        v98 = v148;
                        v87 = v163;
                        v94 = v143;
                        v90 = v155;
                        v103 = v160;
                        v106 = v165;
                        v101 = v152;
                        v95 = v144;
                        v96 = v145;
                        v108 = v146;
                        v97 = v149;
                        v99 = v150;
                        v100 = v151;
                        v107 = v153;
                        v88 = v154;
                        v93 = v158;
                        v91 = v156;
                        v92 = v157;
                        v102 = v159;
                        v104 = v161;
                        v89 = v162;
                        v105 = v164;
                    }

                    imageView10 = imgMagneticField;
                } else {
                    int v176 = (int) (((float) bitmap0.getWidth()) * (this.scale * 2.0f) / ((float) this.DW));
                    int v177 = (int) (((float) bitmap0.getWidth()) * (this.scale * 3.0f) / ((float) this.DW));
                    int v178 = (int) (((float) bitmap0.getWidth()) * (this.scale * 5.0f) / ((float) this.DW));
                    int v179 = (int) (((float) bitmap0.getWidth()) * (this.scale * 7.0f) / ((float) this.DW));
                    int v180 = (int) (((float) bitmap0.getWidth()) * (this.scale * 10.0f) / ((float) this.DW));
                    int v181 = (int) (((float) bitmap0.getWidth()) * (this.scale * 8.0f) / ((float) this.DW));
                    int v182 = (int) (((float) bitmap0.getWidth()) * (this.scale * 2.0f) / ((float) this.DW));
                    bitmap0.getWidth();
                    int v183 = v181;
                    int v184 = (int) (((float) bitmap0.getWidth()) * (this.scale * 27.0f) / ((float) this.DW));
                    int v185 = (int) (((float) bitmap0.getWidth()) * (this.scale * 23.0f) / ((float) this.DW));
                    int v186 = (int) (((float) bitmap0.getWidth()) * (this.scale * 42.0f) / ((float) this.DW));
                    int v187 = (int) (((float) bitmap0.getWidth()) * (this.scale * 120.0f) / ((float) this.DW));
                    int v188 = (int) (((float) bitmap0.getWidth()) * (this.scale * 130.0f) / ((float) this.DW));
                    int v189 = (int) (((float) bitmap0.getWidth()) * (this.scale * 150.0f) / ((float) this.DW));
                    int v190 = (int) (((float) bitmap0.getWidth()) * (this.scale * 160.0f) / ((float) this.DW));
                    int v191 = (int) (((float) bitmap0.getWidth()) * (this.scale * 145.0f) / ((float) this.DW));
                    int v192 = (int) (((float) bitmap0.getWidth()) * (this.scale * 165.0f) / ((float) this.DW));
                    int v193 = (int) (((float) bitmap0.getWidth()) * (this.scale * 160.0f) / ((float) this.DW));
                    int v194 = (int) (((float) bitmap0.getWidth()) * (this.scale * 65.0f) / ((float) this.DW));
                    int v195 = (int) (((float) bitmap0.getWidth()) * (this.scale * 70.0f) / ((float) this.DW));
                    int v196 = (int) (((float) bitmap0.getWidth()) * (this.scale * 75.0f) / ((float) this.DW));
                    int v197 = (int) (((float) bitmap0.getWidth()) * (this.scale * 90.0f) / ((float) this.DW));
                    int v198 = (int) (((float) bitmap0.getWidth()) * (this.scale * 110.0f) / ((float) this.DW));
                    int v199 = (int) (((float) bitmap0.getWidth()) * (this.scale * 120.0f) / ((float) this.DW));
                    if (bitmap0.getWidth()>bitmap0.getHeight()) {
                        int v200 = (int) (((float) bitmap0.getWidth()) * (this.scale * 100.0f) / ((float) this.DW));
                        int v201 = (int) (((float) bitmap0.getWidth()) * (this.scale * 110.0f) / ((float) this.DW));
                        int v202 = (int) (((float) bitmap0.getWidth()) * (this.scale * 140.0f) / ((float) this.DW));
                        int v203 = (int) (((float) bitmap0.getWidth()) * (this.scale * 150.0f) / ((float) this.DW));
                        int v204 = (int) (((float) bitmap0.getWidth()) * (this.scale * 145.0f) / ((float) this.DW));
                        int v205 = (int) (((float) bitmap0.getWidth()) * (this.scale * 153.0f) / ((float) this.DW));
                        int v206 = (int) (((float) bitmap0.getWidth()) * (this.scale * 155.0f) / ((float) this.DW));
                        int v207 = (int) (((float) bitmap0.getWidth()) * (this.scale * 45.0f) / ((float) this.DW));
                        int v208 = (int) (((float) bitmap0.getWidth()) * (this.scale * 50.0f) / ((float) this.DW));
                        int v209 = (int) (((float) bitmap0.getWidth()) * (this.scale * 60.0f) / ((float) this.DW));
                        v87 = (int) (((float) bitmap0.getWidth()) * (this.scale * 65.0f) / ((float) this.DW));
                        v88 = v201;
                        v90 = v202;
                        v94 = v176;
                        v95 = v177;
                        v96 = v178;
                        v91 = v203;
                        v92 = v204;
                        v97 = v183;
                        v99 = v184;
                        v100 = v185;
                        v101 = v186;
                        v93 = v205;
                        v102 = v206;
                        v103 = v207;
                        v104 = v208;
                        v89 = v209;
                        v106 = v199;
                        v105 = v198;
                        v98 = v182;
                        roundCorners1 = imgMap;
                        v107 = v200;
                        imageView10 = imgMagneticField;
                        v108 = v179;
                    } else {
                        roundCorners1 = imgMap;
                        imageView10 = imgMagneticField;
                        v94 = v176;
                        v95 = v177;
                        v96 = v178;
                        v108 = v179;
                        v87 = v197;
                        v88 = v188;
                        v97 = v183;
                        v99 = v184;
                        v100 = v185;
                        v101 = v186;
                        v107 = v187;
                        v90 = v189;
                        v93 = v192;
                        v91 = v190;
                        v92 = v191;
                        v102 = v193;
                        v103 = v194;
                        v104 = v195;
                        v89 = v196;
                        v106 = v199;
                        v105 = v198;
                        v98 = v182;
                    }

                    v109 = v180;
                }
            }

            if (isTablet) {
                float f1 = (float) v108;
                tv_weather.setTextSize(f1);
                tv_compass.setTextSize(f1);
                tv_magnetic_field.setTextSize(f1);
                txt_humidity.setTextSize(f1);
                txt_pressure.setTextSize(f1);
                txt_wind.setTextSize(f1);
                txt_watermark.setTextSize(f1);
                txt_watermark_2.setTextSize(f1);
            } else {
                float f2 = (float) v96;
                tv_weather.setTextSize(f2);
                tv_compass.setTextSize(f2);
                tv_magnetic_field.setTextSize(f2);
                txt_humidity.setTextSize(f2);
                txt_pressure.setTextSize(f2);
                txt_wind.setTextSize(f2);
                txt_watermark.setTextSize(f2);
                txt_watermark_2.setTextSize(f2);
            }

            LinearLayout.LayoutParams linearLayout$LayoutParams0 = new LinearLayout.LayoutParams(v107, v107);
            if (v == 0) {
                linearLayout$LayoutParams0.setMargins(0, 0, v97, 0);
                v210 = v98;
                v211 = v108;
                v212 = v107;
                roundCorners2 = roundCorners1;
                roundCorners2.setCornerRadius(((float) v210));
            } else {
                v212 = v107;
                roundCorners2 = roundCorners1;
                v210 = v98;
                v211 = v108;
                linearLayout$LayoutParams0.setMargins(0, 0, 0, 0);
                roundCorners2.setCornerRadius(0.0f);
            }

            linearLayout$LayoutParams0.gravity = 80;
            roundCorners2.setLayoutParams(linearLayout$LayoutParams0);
            imageView10.getLayoutParams().width = v100;
            imageView10.getLayoutParams().height = v100;
            imgCompass2.getLayoutParams().width = v100;
            imgCompass2.getLayoutParams().height = v100;
            img_stamp.getLayoutParams().width = v100;
            img_stamp_2.getLayoutParams().width = v100;
            img_stamp.getLayoutParams().height = v100;
            img_stamp_2.getLayoutParams().height = v100;
            img_humidity_stamp.getLayoutParams().width = v100;
            img_humidity_stamp.getLayoutParams().height = v100;
            img_wind_stamp.getLayoutParams().width = v100;
            img_wind_stamp.getLayoutParams().height = v100;
            img_pressure_stamp.getLayoutParams().width = v100;
            img_pressure_stamp.getLayoutParams().height = v100;
            lin_bottom_wather2.getLayoutParams().height = v100;
            if (v == 0) {
                linearLayout17 = li_main_stamp_lay2;
                linearLayout17.setPadding(v97, v97, v97, v97);
            } else {
                linearLayout17 = li_main_stamp_lay2;
                linearLayout17.setPadding(0, v97, 0, v97);
            }

            linearLayout18 = lin_waterma;
            linearLayout18.setPadding(v210, v210, v210, v210);
            lin_waterma_2.setPadding(v210, v210, v210, v210);
            LinearLayout linearLayout19 = lin_waterma_2;
            LinearLayout linearLayout20 = linearLayout18;
            int v213 = v95;
            tv_magnetic_field.setPadding(v213, 0, 0, 0);
            tv_compass.setPadding(v213, 0, 0, 0);
            txt_watermark.setPadding(v210, 0, v210, 0);
            txt_watermark_2.setPadding(v210, 0, v210, 0);
            tv_weather.setPadding(v213, 0, 0, 0);
            if (z5) {
                linearLayout16.setVisibility(View.VISIBLE);
                imgWeather.setImageResource(mWeatherIcon.getResourceId(v52, 0));
                imgWeather.getLayoutParams().width = v99;
                imgWeather.getLayoutParams().height = v99;
            } else {
                linearLayout16.setVisibility(View.GONE);
            }

            if (z12) {
                linearLayout21 = li_logo;
                linearLayout21.setVisibility(View.VISIBLE);
                v214 = v101;
                imgLogo.getLayoutParams().height = v214;
                textView11 = tv_compass;
                v215 = v89;
                imgLogo.getLayoutParams().width = v215;
            } else {
                textView11 = tv_compass;
                linearLayout21 = li_logo;
                v215 = v89;
                v214 = v101;
                linearLayout21.setVisibility(View.GONE);
            }

            if (!z14 && !z15 && !z16 && !z17 && !z19) {
                linearLayout22 = linearLayout21;
                linearLayout23 = lin_bottom_wather2;
                linearLayout23.setVisibility(View.GONE);
//                label_2888:
                textView12 = tv_magnetic_field;
            } else {
                linearLayout22 = linearLayout21;
                linearLayout23 = lin_bottom_wather2;
                linearLayout23.setVisibility(View.VISIBLE);
                if (isTablet) {
                    LinearLayout.LayoutParams linearLayout$LayoutParams1 = (LinearLayout.LayoutParams) linearLayout23.getLayoutParams();
                    textView12 = tv_magnetic_field;
                    ++linearLayout$LayoutParams1.height;
//                    label_2889:
                    if (z14) {
                        linearLayout24 = lin_humidity_stamp;
                        linearLayout24.setVisibility(View.VISIBLE);
                    } else {
                        linearLayout24 = lin_humidity_stamp;
                        linearLayout24.setVisibility(View.GONE);
                    }

                }

//                label_2888:
//                textView12 = tv_magnetic_field;
            }

//            label_2889:
//            if(z14) {
//                linearLayout24 = lin_humidity_stamp;
//                linearLayout24.setVisibility(View.VISIBLE);
//            }
//            else {
//                linearLayout24 = lin_humidity_stamp;
//                linearLayout24.setVisibility(View.GONE);
//            }

            if (z17) {
                linearLayout25 = lin_wind_stamp;
                textView13 = tv_weather;
                linearLayout25.setVisibility(View.VISIBLE);
            } else {
                linearLayout25 = lin_wind_stamp;
                textView13 = tv_weather;
                linearLayout25.setVisibility(View.GONE);
            }

            if (z19) {
                v216 = v;
                linearLayout26 = lin_pressure_stamp;
                linearLayout26.setVisibility(View.VISIBLE);
            } else {
                v216 = v;
                linearLayout26 = lin_pressure_stamp;
                linearLayout26.setVisibility(View.GONE);
            }

            if (z16) {
                linearLayout27 = linearLayout17;
                String s13 = Util.getAltitudeconvert(this, v51);
                v217 = v210;
                if (linearLayout26.getVisibility() == 8) {
                    linearLayout26.setVisibility(View.VISIBLE);
                    imageView11 = img_pressure_stamp;
                    imageView11.setImageResource(R.drawable.ic_altitiude);  // drawable:ic_altitiude
                    txt_pressure.setText(s13);
                    txt_pressure.setTextColor(v50);
                    linearLayout28 = linearLayout23;
                    v218 = v215;
                    v219 = v214;
                    imageView12 = img_wind_stamp;
//                    label_2975:
                    imageView13 = img_humidity_stamp;
                } else {
                    int v220 = v50;
                    imageView11 = img_pressure_stamp;
                    v218 = v215;
                    linearLayout28 = linearLayout23;
                    if (linearLayout25.getVisibility() == 8) {
                        linearLayout25.setVisibility(View.VISIBLE);
                        imageView12 = img_wind_stamp;
                        imageView12.setImageResource(R.drawable.ic_altitiude);  // drawable:ic_altitiude
                        txt_wind.setText(s13);
                        txt_wind.setTextColor(v220);
                        v219 = v214;
                    } else {
                        imageView12 = img_wind_stamp;
                        v219 = v214;
                        if (linearLayout24.getVisibility() == 8) {
                            linearLayout24.setVisibility(View.VISIBLE);
                            imageView13 = img_humidity_stamp;
                            imageView13.setImageResource(R.drawable.ic_altitiude);  // drawable:ic_altitiude
                            txt_humidity.setText(s13);
                            txt_humidity.setTextColor(v220);
//                            label_2985:
                            if (z15) {
                                String s14 = Util.getAccuracy(this, v49);
                                if (linearLayout26.getVisibility() == 8) {
                                    linearLayout26.setVisibility(View.VISIBLE);
                                    imageView11.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
                                    txt_pressure.setText(s14);
                                    txt_pressure.setTextColor(v48);
                                } else {
                                    int v221 = v48;
                                    if (linearLayout25.getVisibility() == 8) {
                                        linearLayout25.setVisibility(View.VISIBLE);
                                        imageView12.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
                                        txt_wind.setText(s14);
                                        txt_wind.setTextColor(v221);
                                    } else if (linearLayout24.getVisibility() == 8) {
                                        linearLayout24.setVisibility(View.VISIBLE);
                                        imageView13.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
                                        txt_humidity.setText(s14);
                                        txt_humidity.setTextColor(v221);
                                    }
                                }
                            }
                        }
                    }

//                    label_2975:
//                    imageView13 = img_humidity_stamp;
                }
            } else {
                linearLayout28 = linearLayout23;
                linearLayout27 = linearLayout17;
                v218 = v215;
                v217 = v210;
                v219 = v214;
                imageView12 = img_wind_stamp;
                imageView13 = img_humidity_stamp;
                imageView11 = img_pressure_stamp;
            }

            if (z27) {
                if (z11) {
                    li_compass.setVisibility(View.VISIBLE);
                    RotateAnimation rotateAnimation0 = new RotateAnimation(-(currentAzimuth + ((float) degree)), -(heading + ((float) degree)), 1, 0.5f, 1, 0.5f);
                    rotateAnimation0.setDuration(500L);
                    rotateAnimation0.setFillAfter(true);
                    imgCompass2.startAnimation(rotateAnimation0);
                } else {
                    li_compass.setVisibility(View.GONE);
                }
                if (z10) {
                    li_magnetic_field.setVisibility(View.VISIBLE);
                } else {
                    li_magnetic_field.setVisibility(View.GONE);
                }
            } else {
                li_compass.setVisibility(View.GONE);
                li_magnetic_field.setVisibility(View.GONE);
            }

            if (!z5 && !z10 && !z11 && !z12) {
                linearLayout29 = li_rightView;
                linearLayout29.setVisibility(View.GONE);
            } else {
                linearLayout29 = li_rightView;
                linearLayout29.setVisibility(View.VISIBLE);
            }

            if (z22) {
                textView14 = textView6;
                if (!z8 && !z4) {
                    textView14.setMaxLines(10);
                } else {
                    textView14.setMaxLines(12);
                }
            } else if ((z21) || ((z5) || (z10) || (z11) || (z26) || !z23) && ((z5) || (z10) || (z11) || (z23) || !z26) && (!z5 && !z11 && !z10 || !z23 || (z26)) && (!z5 && !z11 && !z10 || (z23) || !z26)) {
                textView14 = textView6;
                if (!z8 && !z4) {
                    textView14.setMaxLines(10);
                } else {
                    textView14.setMaxLines(12);
                }
            } else if (!z23 && !z26 || !z13) {
                textView14 = textView6;
                if (!z8 && !z24 && !z4) {
                    textView14.setMaxLines(1);
                } else {
                    textView14.setMaxLines(3);
                }
            } else if (!z8 && !z4) {
                textView14 = textView6;
                textView14.setMaxLines(3);
            } else {
                textView14 = textView6;
                textView14.setMaxLines(5);
            }

            if ((z21) && getMapBitmap() != null) {
                v222 = bitmap0.getWidth() - (v212 + v109 * 3);
                if (z12) {
                    if (!z8 && !z4) {
                        System.out.println("TemplateCalled             2");
                        li_stamp.getLayoutParams().height = v92;
                        roundCorners2.getLayoutParams().height = v92;
                    } else {
                        System.out.println("TemplateCalled             1");
                        li_stamp.getLayoutParams().height = v102;
                        roundCorners2.getLayoutParams().height = v102;
                    }
                } else if (!z8 && !z4) {
                    System.out.println("TemplateCalled             5");
                    li_stamp.getLayoutParams().height = v212;
                    roundCorners2.getLayoutParams().height = v212;
                } else if (!z17 && !z15 && !z16 && !z14 && !z19) {
                    System.out.println("TemplateCalled             4");
                    li_stamp.getLayoutParams().height = v91;
                    roundCorners2.getLayoutParams().height = v91;
                } else {
                    System.out.println("TemplateCalled             3");
                    li_stamp.getLayoutParams().height = v93;
                    roundCorners2.getLayoutParams().height = v93;
                }

                linearLayout30 = li_stamp;
                int v223 = v211;
                linearLayout30.setPadding(v223, v213, v223, v213);
                roundCorners2.setVisibility(View.VISIBLE);
                roundCorners2.setImageBitmap(getMapBitmap());
                imageView14 = imageView11;
                textView15 = txt_pressure;
                v224 = v103;
            } else {
                linearLayout30 = li_stamp;
                int v225 = v211;
                int v226 = v212;
                int v227 = v91;
                if (!z26 && !z22 && !z10 && !z11) {
                    if (z5) {
                        imageView14 = imageView11;
                        textView15 = txt_pressure;
                        v224 = v103;
//                        goto label_3321;
//                        label_3321:
                        roundCorners2.setVisibility(View.GONE);
                        int v232 = canvas0.getWidth() - v109 * 2;
                        if (z22) {
                            if (!z22 || (z26)) {
                                int v234 = v88;
                                if (!z8 && !z4) {
                                    System.out.println("TemplateCalled             19");
                                    linearLayout30.getLayoutParams().height = v226;
                                } else {
                                    System.out.println("TemplateCalled             18");
                                    linearLayout30.getLayoutParams().height = v234;
                                }
                            } else if (!z8 && !z4) {
                                System.out.println("TemplateCalled             17");
                                linearLayout30.getLayoutParams().height = v226;
                            } else {
                                System.out.println("TemplateCalled             16");
                                linearLayout30.getLayoutParams().height = v88;
                            }

                            linearLayout30.setPadding(v225, v213, v225, v213);
                        } else if (!z23 && !z26 || textView14.getMaxLines() == 1 && (!z11 && !z10 && !z5 || (z5) && !z11 && !z10 || (z11) && !z5 && !z10 || (z10) && !z5 && !z11)) {
                            if (linearLayout28.getVisibility() == 8 && !z11 && !z10 && !z5) {
                                if (((z23) || (z26)) && (z13)) {
                                    if (!z8 && !z4) {
                                        System.out.println("TemplateCalled             7");
                                        linearLayout30.getLayoutParams().height = v218;
                                    } else {
                                        System.out.println("TemplateCalled             6");
                                        linearLayout30.getLayoutParams().height = v87;
                                    }
                                } else if (!z8 && !z4) {
                                    System.out.println("TemplateCalled             9");
                                    linearLayout30.getLayoutParams().height = v224;
                                } else {
                                    System.out.println("TemplateCalled             8");
                                    linearLayout30.getLayoutParams().height = v104;
                                }
                            } else if (!z12) {
                                if (!z8 && !z4) {
                                    System.out.println("TemplateCalled             13");
                                } else {
                                    System.out.println("TemplateCalled             12");
                                }

                                linearLayout30.getLayoutParams().height = v105;
                            } else if (!z8 && !z4) {
                                System.out.println("TemplateCalled             11");
                                linearLayout30.getLayoutParams().height = v90;
                            } else {
                                System.out.println("TemplateCalled             10");
                                linearLayout30.getLayoutParams().height = v227;
                            }

                            linearLayout30.setPadding(v225, v225, v225, v225);
                        } else {
                            int v233 = v105;
                            if (!z8 && !z4) {
                                System.out.println("TemplateCalled             15");
                                linearLayout30.getLayoutParams().height = v233;
                            } else {
                                System.out.println("TemplateCalled             14");
                                linearLayout30.getLayoutParams().height = v106;
                            }

                            linearLayout30.setPadding(v225, v213, v225, v213);
                        }

                    }

                    int v228 = bitmap0.getWidth() - v109 * 2;
                    roundCorners2.setVisibility(View.GONE);
                    if ((z8) || (z4)) {
                        int v231 = v219;
                        v230 = v103;
                        v229 = v228;
                        System.out.println("TemplateCalled             20");
                        if (!z12 && !z13 && !z8) {
                            linearLayout30.getLayoutParams().height = v231;
                        } else if (!z12 && !z13 && !z4) {
                            linearLayout30.getLayoutParams().height = v231;
                        } else {
                            linearLayout30.setPadding(v225, v225, v225, v225);
                        }
                    } else if (!z12 && !z13) {
                        System.out.println("TemplateCalled             21");
                        linearLayout30.getLayoutParams().height = v219;
                        linearLayout30.setPadding(v94, v94, v94, v94);
                        v229 = v228;
                        v230 = v103;
                    } else {
                        System.out.println("TemplateCalled             22");
                        v230 = v103;
                        linearLayout30.getLayoutParams().height = v230;
                        linearLayout30.setPadding(v225, v225, v225, v225);
                        v229 = v228;
                    }

                    imageView14 = imageView11;
                    v222 = v229;
                    v224 = v230;
                    textView15 = txt_pressure;
                } else {
                    imageView14 = imageView11;
                    v224 = v103;
                    textView15 = txt_pressure;
//                    label_3321:
                    roundCorners2.setVisibility(View.GONE);
                    int v232 = bitmap0.getWidth() - v109 * 2;
                    if (z22) {
                        if (!z22 || (z26)) {
                            int v234 = v88;
                            if (!z8 && !z4) {
                                System.out.println("TemplateCalled             19");
                                linearLayout30.getLayoutParams().height = v226;
                            } else {
                                System.out.println("TemplateCalled             18");
                                linearLayout30.getLayoutParams().height = v234;
                            }
                        } else if (!z8 && !z4) {
                            System.out.println("TemplateCalled             17");
                            linearLayout30.getLayoutParams().height = v226;
                        } else {
                            System.out.println("TemplateCalled             16");
                            linearLayout30.getLayoutParams().height = v88;
                        }

                        linearLayout30.setPadding(v225, v213, v225, v213);
                    } else if (!z23 && !z26 || textView14.getMaxLines() == 1 && (!z11 && !z10 && !z5 || (z5) && !z11 && !z10 || (z11) && !z5 && !z10 || (z10) && !z5 && !z11)) {
                        if (linearLayout28.getVisibility() == 8 && !z11 && !z10 && !z5) {
                            if (((z23) || (z26)) && (z13)) {
                                if (!z8 && !z4) {
                                    System.out.println("TemplateCalled             7");
                                    linearLayout30.getLayoutParams().height = v218;
                                } else {
                                    System.out.println("TemplateCalled             6");
                                    linearLayout30.getLayoutParams().height = v87;
                                }
                            } else if (!z8 && !z4) {
                                System.out.println("TemplateCalled             9");
                                linearLayout30.getLayoutParams().height = v224;
                            } else {
                                System.out.println("TemplateCalled             8");
                                linearLayout30.getLayoutParams().height = v104;
                            }
                        } else if (!z12) {
                            if (!z8 && !z4) {
                                System.out.println("TemplateCalled             13");
                            } else {
                                System.out.println("TemplateCalled             12");
                            }

                            linearLayout30.getLayoutParams().height = v105;
                        } else if (!z8 && !z4) {
                            System.out.println("TemplateCalled             11");
                            linearLayout30.getLayoutParams().height = v90;
                        } else {
                            System.out.println("TemplateCalled             10");
                            linearLayout30.getLayoutParams().height = v227;
                        }

                        linearLayout30.setPadding(v225, v225, v225, v225);
                    } else {
                        int v233 = v105;
                        if (!z8 && !z4) {
                            System.out.println("TemplateCalled             15");
                            linearLayout30.getLayoutParams().height = v233;
                        } else {
                            System.out.println("TemplateCalled             14");
                            linearLayout30.getLayoutParams().height = v106;
                        }

                        linearLayout30.setPadding(v225, v213, v225, v213);
                    }

                    v222 = v232;
                }
            }

            int v235 = textView14.getMaxLines() == 1 && ((z5) || (z10) || (z11)) ? v217 : v217;
            textView14.setPadding(0, 0, v235, 0);
            if (!z22 && !z26 && !z23 && !z13 && !z17 && !z14 && !z15 && !z19 && !z16 && !z8 && !z24 && !z4) {
                linearLayout31 = li_address;
                linearLayout31.setVisibility(View.GONE);
                linearLayout29.setOrientation(0);
                linearLayout29.setGravity(17);
                linearLayout29.getLayoutParams().width = -1;
                linearLayout29.getLayoutParams().width = -1;
                if ((z12) && !z21) {
                    linearLayout30.getLayoutParams().height = v224;
                }
            } else {
                linearLayout31 = li_address;
                linearLayout31.setVisibility(View.VISIBLE);
                linearLayout31.setGravity(17);
                linearLayout29.setOrientation(1);
                linearLayout29.setGravity(17);
                linearLayout29.getLayoutParams().width = -2;
                linearLayout29.getLayoutParams().width = -2;
            }

            if (!z26 && !z22 && !z23 && !z13 && !z8 && !z24 && !z4) {
                textView14.setVisibility(View.GONE);
            } else {
                textView14.setVisibility(View.VISIBLE);
            }

            if (!z26 && !z22 && !z10 && !z5 && !z11 && !z23 && !z21 && !z13 && !z17 && !z14 && !z15 && !z19 && !z16 && !z12 && !z8 && !z24 && !z4) {
                linearLayout27.setVisibility(View.GONE);
            } else {
                linearLayout27.setVisibility(View.VISIBLE);
            }

            boolean z28 = mSP.getBoolean(this, "is_water_mark", true);
            if (z28) {
                if (v216 == 0) {
                    s15 = sharedPreferences.getString("stamp_pos", "Bottom");
                    if (s15.equals("Bottom")) {
                        linearLayout30.setBackground(getResources().getDrawable(R.drawable.rect_grey_1));  // drawable:rect_grey_1
                    } else {
                        linearLayout30.setBackground(getResources().getDrawable(R.drawable.rect_grey_3));  // drawable:rect_grey_3
                    }

                    linearLayout32 = linearLayout20;
                    linearLayout32.setBackground(getResources().getDrawable(R.drawable.rect_grey_2));  // drawable:rect_grey_2
                    linearLayout33 = linearLayout19;
                    linearLayout33.setBackground(getResources().getDrawable(R.drawable.rect_grey_4));  // drawable:rect_grey_4
                } else {
                    linearLayout32 = linearLayout20;
                    linearLayout33 = linearLayout19;
                    linearLayout30.setBackground(getResources().getDrawable(R.drawable.classic_back));  // drawable:classic_back
                    linearLayout32.setBackground(getResources().getDrawable(R.drawable.classic_back));  // drawable:classic_back
                    linearLayout33.setBackground(getResources().getDrawable(R.drawable.classic_back));  // drawable:classic_back
                    s15 = sharedPreferences.getString("stamp_pos_classic", "Bottom");
                }

                if (s15.equals("Bottom")) {
                    linearLayout32.setVisibility(View.VISIBLE);
                    linearLayout33.setVisibility(View.GONE);
                    ((GradientDrawable) linearLayout30.getBackground().getCurrent()).setColor(v47);
                    ((GradientDrawable) linearLayout32.getBackground().getCurrent()).setColor(v47);
                } else {
                    linearLayout32.setVisibility(View.GONE);
                    linearLayout33.setVisibility(View.VISIBLE);
                    ((GradientDrawable) linearLayout30.getBackground().getCurrent()).setColor(v47);
                    ((GradientDrawable) linearLayout33.getBackground().getCurrent()).setColor(v47);
                }
            } else {
                int v236 = v47;
                linearLayout20.setVisibility(View.GONE);
                linearLayout19.setVisibility(View.GONE);
                if (v216 == 0) {
                    linearLayout30.setBackground(getResources().getDrawable(R.drawable.rect_grey));  // drawable:rect_grey
                } else {
                    linearLayout30.setBackground(getResources().getDrawable(R.drawable.classic_back));  // drawable:classic_back
                }

                GradientDrawable gradientDrawable0 = (GradientDrawable) linearLayout30.getBackground().getCurrent();
                if (v216 == 0) {
                    gradientDrawable0.setCornerRadius(((float) v235));
                }

                gradientDrawable0.setColor(v236);
            }

            TextView textView16 = textView13;
            textView16.setTextColor(v46);
            TextView textView17 = textView12;
            textView17.setTextColor(v45);
            textView17.setText(getMagnaticFieldStr());
            TextView textView18 = textView11;
            textView18.setTextColor(v44);
            textView18.setText(getCompassStr());
            if (z17) {
                txt_wind.setText(Util.getwindConvert(this, v43));
                imageView12.setImageResource(R.drawable.ic_wind);  // drawable:ic_wind
                txt_wind.setTextColor(v35);
            }

            if (z14) {
                linearLayout34 = linearLayout29;
                linearLayout35 = linearLayout31;
                txt_humidity.setText(mSP.getString(this, "Humidity_value", "") + "%");
                imageView13.setImageResource(R.drawable.ic_humidity);  // drawable:ic_humidity
                txt_humidity.setTextColor(v37);
            } else {
                linearLayout35 = linearLayout31;
                linearLayout34 = linearLayout29;
            }

            if (z19) {
                textView19 = textView15;
                textView19.setText(Util.getpressureConvert(this, v41));
                imageView14.setImageResource(R.drawable.ic_pressure);  // drawable:ic_pressure
                textView19.setTextColor(v36);
            } else {
                textView19 = textView15;
            }

            LinearLayout.LayoutParams linearLayout$LayoutParams2 = new LinearLayout.LayoutParams(v222, linearLayout30.getLayoutParams().height);
            linearLayout$LayoutParams2.gravity = 17;
            linearLayout30.setLayoutParams(linearLayout$LayoutParams2);
            String s16 = mSP.getString(this, "loc_address_line_1", "").trim();
            String s17 = mSP.getString(this, "loc_city", "").trim();
            String s18 = mSP.getString(this, "loc_state", "").trim();
            TextView textView20 = textView17;
            String s19 = mSP.getString(this, "loc_country", "").trim();
            TextView textView21 = textView18;
            String s20 = mSP.getString(this, "PLUS_CODE", "").trim();
            if (!s20.isEmpty() && (s12.equals("concise"))) {
                s20 = s20.substring(4);
            }

            String s21 = s17 == null || (s17.isEmpty()) ? "" : "" + s17 + ", ";
            if (s18 != null && !s18.isEmpty()) {
                s21 = s21 + "" + s18 + ", ";
            }

            if (s19 != null && !s19.isEmpty()) {
                s21 = s21 + s19;
            }

            if (s21 != null && (s21.endsWith(", "))) {
                s21 = s21.substring(0, s21.length() - 2);
            }

            if (s16 == null || (s16.isEmpty())) {
                s16 = "";
            }

            int v237 = v30;
            String s22 = getColoredSpanned(s16, v237);
            String s23 = Util.getLatLong(this, v40);
            TextView textView22 = textView19;
            String s24 = getColoredSpanned(s23, v32);
            if ((z26) && s24 != null && v40 != 6 && v40 != 7 && s24.length()>55 && (z21) && !z10 && (z23) && !z5 && !z11) {
                String[] arr_s = s24.split(" Long");
                s24 = arr_s[0] + "<br/>Long " + arr_s[1];
            }

            if (z22) {
                if (z26) {
                    s22 = s22 + "<br/>" + s24;
                }
            } else if ((z26) && !z22) {
                s22 = s24;
            }

            if (z4) {
                String s25 = getColoredSpanned("Plus Code : " + s20, v33);
                s22 = (z22) || (z26) ? s22 + "<br/>" + s25 : s25;
            }

            if (z23) {
                String s26 = Util.setDateTimeFormat(s4);
                v238 = v31;
                String s27 = getColoredSpanned(s26, v238);
                s22 = !z22 && !z26 && !z4 ? s27 : s22 + "<br/>" + s27;
            } else {
                v238 = v31;
            }

            if (z24) {
                String s28 = getTimezone(v42);
                String s29 = getColoredSpanned(s28, v238);
                if (z23) {
                    s22 = s22 + " " + s29;
                } else if (!z22 && !z26 && !z4) {
                    s22 = s29;
                } else {
                    s22 = s22 + "<br/>" + s29;
                }
            }

            if (z13) {
                if (v216 == 0) {
                    String s30 = mSP.getString(this, "notes_hashtag", "Note : Captured by GPS Map Camera");
                    s31 = getColoredSpanned(s30, v34);
                    textView23 = txt_wind;
                } else {
                    textView23 = txt_wind;
                    String s32 = mSP.getString(this, "notes_hashtag_classic", "Note : Captured by GPS Map Camera");
                    s31 = getColoredSpanned(s32, v34);
                }

                s22 = !z22 && !z26 && !z23 && !z24 && !z4 ? s31 : s22 + "<br/>" + s31;
            } else {
                textView23 = txt_wind;
            }

            if (z8) {
                String s33 = getColoredSpanned(s10 + " " + v39 + " " + s11.trim(), v38);
                s22 = (z22) || (z26) || (z23) || (z24) || (z13) || (z4) ? s22 + "<br/>" + s33 : s33;
            }

            if (s22.contains("null")) {
                s22 = s22.replace("null", "");
            }

            textView14.setText(Html.fromHtml(s22));
            if (s21 != null && !s21.isEmpty() && (z22)) {
                textView24 = tv_address;
                textView24.setVisibility(View.VISIBLE);
                if (s21.contains("null")) {
                    s21 = s21.replace("null", "");
                }

                textView24.setText(Html.fromHtml(getColoredSpanned(s21, v237)));
            } else {
                textView24 = tv_address;
                textView24.setVisibility(View.GONE);
            }

            if (s9.equals("Celsius")) {
                textView16.setText(Util.getCelcius(f));
            } else {
                textView16.setText(Util.getFahrenheit(f));
            }

            if ((z21) && !z22 && !z26 && !z23 && !z11 && !z10 && !z5 && !z13 && !z17 && !z14 && !z15 && !z19 && !z16 && !z12 && !z24 && !z8 && !z4) {
                linearLayout30.setVisibility(4);
            } else {
                linearLayout30.setVisibility(View.VISIBLE);
            }

            String s34 = s7;
            if (s34.equals("no_logo")) {
                imgLogo.setImageResource(R.mipmap.ic_launcher);  // mipmap:ic_launcher
            } else {
                imgLogo.setImageBitmap(Util.decodeBase64(s34));
            }


        } catch (OutOfMemoryError outOfMemoryError0) {
            outOfMemoryError0.printStackTrace();
        }

    }


    private void setMapType() {
        if (this.mGMap != null) {
            int v = 0;
            String s = this.mSP.getInteger(this, "template_type", 0) == 0 ? this.mSP.getString(this, "map_type_template", "satellite") : this.mSP.getString(this, "map_type_template_classic", "satellite");
            s.hashCode();
            switch (s.hashCode()) {
                case 0xA1E0C93B: {
                    if (!s.equals("satellite")) {
                        v = -1;
                    }

                    break;
                }
                case -1423437003: {
                    v = s.equals("terrain") ? 1 : -1;
                    break;
                }
                case 0xB84F61FC: {
                    v = s.equals("hybrid") ? 2 : -1;
                    break;
                }
                case 1366708796: {
                    v = s.equals("roadmap") ? 3 : -1;
                    break;
                }
                default: {
                    v = -1;
                }
            }

            switch (v) {
                case 0: {
                    this.mGMap.setMapType(2);
                    return;
                }
                case 1: {
                    this.mGMap.setMapType(3);
                    return;
                }
                case 2: {
                    this.mGMap.setMapType(4);
                    return;
                }
                case 3: {
                    break;
                }
                default: {
                    return;
                }
            }

            this.mGMap.setMapType(1);
            return;
        }
    }

    private void setupCompass() {
        this.compass = new Compass(this);
        Compass.CompassListener compassListener = new Compass.CompassListener() {
            @Override
            public void onNewAzimuth(float f) {
                CameraMainActivity.this.adjustArrow(f);
            }

            @Override // com.live.gpsmap.camera.compass.Compass.CompassListener
            public void onMagField(float f) {
                CameraMainActivity.this.MagField(f);
            }
        };
        this.compass.setListener(compassListener);
        Compass compass = this.compass;
        if (compass != null) {
            compass.setListener(compassListener);
            if (this.compass.getStatus()) {
                this.compassFound = true;
                this.mSP.setBoolean(this, SP.COMPASS_FOUND, true);
                return;
            }
            this.mSP.setBoolean(this, SP.COMPASS_FOUND, false);
        }
    }

    public void adjustArrow(float f) {
        if (this.compass.getSensorData()) {
            this.heading = f;
            showDirection(f);
            int uIRotation = this.preview.getUIRotation();
            if (uIRotation == 0) {
                this.degree = 0;
            } else if (uIRotation == 90) {
                this.degree = 90;
            } else if (uIRotation == 180) {
                this.degree = BarcodeUtils.ROTATION_180;
            } else if (uIRotation == 270) {
                this.degree = BarcodeUtils.ROTATION_270;
            }
            float f2 = this.currentAzimuth;
            int i = this.degree;
            RotateAnimation rotateAnimation = new RotateAnimation(-(f2 + i), -(this.heading + i), 1, 0.5f, 1, 0.5f);
            this.currentAzimuth = this.heading;
            rotateAnimation.setDuration(500L);
            rotateAnimation.setFillAfter(true);
            this.imgCompass.startAnimation(rotateAnimation);
        }
    }

    private void showDirection(float f) {
        String str = Math.round(f) + "° " + ((f>=338.0f || f<23.0f) ? "N" : (f<23.0f || f>=68.0f) ? (f<68.0f || f>=113.0f) ? (f<113.0f || f>=158.0f) ? (f<158.0f || f>=203.0f) ? (f<203.0f || f>=248.0f) ? (f<248.0f || f>=293.0f) ? (f<293.0f || f>=338.0f) ? "" : "NW" : ExifInterface.LONGITUDE_WEST : "SW" : ExifInterface.LATITUDE_SOUTH : "SE" : ExifInterface.LONGITUDE_EAST : "NE");
        this.str_compass = str;
        this.mSP.setString(this, SP.COMPASS_VALUE, str);
        this.tv_compass.setText(this.str_compass);
    }

    public void MagField(float f) {
        String str = f + " μT";
        this.str_magnaticField = str;
        this.mSP.setString(this, SP.MAGNETIC_FIELD_VALUE, str);
        this.tv_magnetic_field.setText(this.str_magnaticField);
    }

    public int getRatioW(int i, int i2) {
        return (i2 * this.mScreenH) / i;
    }

    public int getRatioH(int i, int i2) {
        return (i * this.mScreenW) / i2;
    }


    public Bitmap getStampBitmap() {
        int i;
        int i2;
        String str;
        String str2;
        String string;
        int integer;
        String string2;
        int i3;
        int height;
        try {
            int uIRotation = this.preview.getUIRotation();
            int dimension = (int) getResources().getDimension(R.dimen.stamp_size_minus);
            int dimension2 = (int) getResources().getDimension(R.dimen.stamp_size);
            String[] strArr = this.ratio;
            if (strArr != null) {
                if (uIRotation != 90 && uIRotation != 270) {
                    i = getRatioW(Integer.parseInt(strArr[0]), Integer.parseInt(this.ratio[1]));
                    int i4 = this.mScreenW;
                    if (i>i4) {
                        i = i4;
                    } else if (i<i4) {
                        if (NetworkState.Companion.isOnline(this)) {
                            height = this.banner_native_layout.getHeight() / 2;
                            i -= height;
                        }
                    } else if (i == i4 && this.isTablet) {
                        height = this.banner_native_layout.getHeight() / 2;
                        i -= height;
                    }
                } else {
                    i = getRatioH(Integer.parseInt(strArr[0]), Integer.parseInt(this.ratio[1]));
                    int i5 = this.mScreenH;
                    if (i>i5) {
                        i = i5;
                    }
                    if (i == i5 && NetworkState.Companion.isOnline(this)) {
                        height = this.banner_native_layout.getHeight();
                        i -= height;
                    }
                }
            } else {
                i = this.mScreenW;
            }
            if (this.isMap && this.mapBitmap != null) {
                i2 = i - dimension2;
                this.imgMap.setVisibility(View.VISIBLE);
//                Glide.with(this)
//                        .load(mapBitmap)
//                        .into(imgMap);
                this.imgMap.setImageBitmap(this.mapBitmap);
            } else {
                i2 = i - (dimension2 - dimension);
                this.imgMap.setVisibility(View.GONE);
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mapSnapshot();
                }
            });

            int integer2 = this.mSP.getInteger(this, SP.TEMPLATE_TYPE, 0);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(i2, this.li_stamp.getLayoutParams().height);
            if (integer2 == 0) {
                layoutParams.setMargins(getResources().getDimensionPixelOffset(R.dimen._8dp), 0, 0, 0);
            } else {
                layoutParams.setMargins(0, 0, 0, 0);
            }
            this.li_stamp.setLayoutParams(layoutParams);
            String str3 = this.city;
            if (str3 == null || str3.isEmpty()) {
                str = "";
            } else {
                str = "" + this.city + ", ";
            }
            String str4 = this.state;
            if (str4 != null && !str4.isEmpty()) {
                str = str + "" + this.state + ", ";
            }
            String str5 = this.country;
            if (str5 != null && !str5.isEmpty()) {
                str = str + this.country;
            }
            if (str != null && str.endsWith(", ")) {
                str = str.substring(0, str.length() - 2);
            }
            String str6 = this.address_line_1;
            if (str6 == null || str6.isEmpty()) {
                str2 = "";
            } else {
                if (this.address_line_1.equalsIgnoreCase("null")) {
                    this.address_line_1 = "Loading";
                }
                str2 = getColoredSpanned(this.address_line_1, this.address_color);
            }
            String coloredSpanned = getColoredSpanned(Util.getLatLong(this, this.mLatLngType), this.lat_lng_color);
            if (this.isLatLng && coloredSpanned != null && (i3 = this.mLatLngType) != 6 && i3 != 7 && coloredSpanned.length()>55 && this.isMap && !this.isMagneticField && this.isDateTime && !this.isWeather && !this.isCompass) {
                String[] split = coloredSpanned.split(" Long");
                coloredSpanned = split[0] + ":" + split[1];
            }
            boolean z = this.isAddress;
            if (z) {
                if (this.isLatLng) {
                    str2 = str2 + "<br/>" + coloredSpanned;
                }
            } else if (this.isLatLng && !z) {
                str2 = coloredSpanned;
            }
            String trim = this.mSP.getString(this, SP.PLUS_CODE, "").trim();
            if (!trim.isEmpty() && this.pluscode_type.equals("concise")) {
                trim = trim.substring(4);
            }
            if (this.isPlusCode) {
                String coloredSpanned2 = getColoredSpanned("Plus Code : " + trim, this.plus_code_color);
                if (!this.isAddress && !this.isLatLng) {
                    str2 = coloredSpanned2;
                }
                str2 = str2 + "<br/>" + coloredSpanned2;
            }
            if (this.isDateTime) {
                String coloredSpanned3 = getColoredSpanned(Util.setDateTimeFormat(this.mDateFormat), this.date_time_color);
                if (!this.isAddress && !this.isLatLng && !this.isPlusCode) {
                    str2 = coloredSpanned3;
                }
                str2 = str2 + "<br/>" + coloredSpanned3;
            }
            if (this.istimezone) {
                String coloredSpanned4 = getColoredSpanned(getTimezone(this.timezone), this.date_time_color);
                if (!this.isDateTime) {
                    if (!this.isAddress && !this.isLatLng && !this.isPlusCode) {
                        str2 = coloredSpanned4;
                    }
                    str2 = str2 + "<br/>" + coloredSpanned4;
                } else {
                    str2 = str2 + " " + coloredSpanned4;
                }
            }
            if (this.isNotes) {
                if (this.mSP.getInteger(this, SP.TEMPLATE_TYPE, 0) == 0) {
                    string2 = this.mSP.getString(this, SP.NOTES_HASHTAG, Default.notes);
                } else {
                    string2 = this.mSP.getString(this, SP.NOTES_HASHTAG_CLASSIC, Default.notes);
                }
                String coloredSpanned5 = getColoredSpanned(string2, this.Notes_color);
                if (!this.isAddress && !this.isLatLng && !this.isDateTime && !this.istimezone && !this.isPlusCode) {
                    str2 = coloredSpanned5;
                }
                str2 = str2 + "<br/>" + coloredSpanned5;
            }
            if (this.isNumbering) {
                if (integer2 == 0) {
                    integer = this.mSP.getInteger(this, SP.SEQUENCE, 1);
                } else {
                    integer = this.mSP.getInteger(this, SP.SEQUENCE_CLASSIC, 1);
                }
                String coloredSpanned6 = getColoredSpanned((this.prefix + " " + integer + " " + this.suffix).trim(), this.numbering_color);
                if (!this.isAddress && !this.isLatLng && !this.isDateTime && !this.istimezone && !this.isNotes && !this.isPlusCode) {
                    str2 = coloredSpanned6;
                }
                str2 = str2 + "<br/>" + coloredSpanned6;
            }
            if (str2.contains("null")) {
                str2 = str2.replace("null", "Loading");
            }
            this.tv_address_line_1.setText(Html.fromHtml(str2));
            if (str != null && !str.isEmpty() && this.isAddress) {
                this.tv_address.setVisibility(View.VISIBLE);
                if (str.equalsIgnoreCase("null")) {
                    str = "Loading";
                }
                this.tv_address.setText(Html.fromHtml(getColoredSpanned(str, this.address_color)));
            } else {
                this.tv_address.setVisibility(View.GONE);
            }
            if (this.msTemprature_type.equals("Celsius")) {
                this.tv_weather.setText(Util.getCelcius(this.mfTemprature_value));
            } else {
                this.tv_weather.setText(Util.getFahrenheit(this.mfTemprature_value));
            }
            if (this.isWind) {
                this.txt_wind.setText(Util.getwindConvert(this, this.mWindtype));
                this.img_wind_stamp.setImageResource(R.drawable.ic_wind);
                this.txt_wind.setTextColor(this.wind_color);
            }
            if (this.isHumidity) {
                this.txt_humidity.setText(this.mSP.getString(this, SP.HUMIDITY_VALUE, "") + "%");
                this.img_humidity_stamp.setImageResource(R.drawable.ic_humidity);
                this.txt_humidity.setTextColor(this.humidity_color);
            }
            if (this.isPressure) {
                this.txt_pressure.setText(Util.getpressureConvert(this, this.mPressuretype));
                this.img_pressure_stamp.setImageResource(R.drawable.ic_pressure);
                this.txt_pressure.setTextColor(this.pressure_color);
            }
            if (integer2 == 0) {
                string = this.mSP.getString(this, SP.STAMP_FONT_STYLE, Default.DEFAULT_FONT_STYLE);
            } else {
                string = this.mSP.getString(this, SP.STAMP_FONT_STYLE_CLASSIC, Default.DEFAULT_FONT_STYLE);
            }
            this.txt_humidity.setTypeface(Util.getFontStyle(this, string));
            this.txt_wind.setTypeface(Util.getFontStyle(this, string));
            this.txt_pressure.setTypeface(Util.getFontStyle(this, string));
            this.tv_address_line_1.setTypeface(Util.getFontStyle(this, string));
            this.tv_address.setTypeface(Util.getFontStyle(this, string));
            this.tv_weather.setTypeface(Util.getFontStyle(this, string));
            this.tv_compass.setTypeface(Util.getFontStyle(this, string));
            this.tv_magnetic_field.setTypeface(Util.getFontStyle(this, string));
            this.bitmap = null;
            this.imgWeather.setImageResource(this.mWeatherIcon.getResourceId(this.mIconValue, 0));
            this.li_stamp_lay.measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
            View view = this.li_stamp_lay;
            view.layout(0, 0, view.getMeasuredWidth(), this.li_stamp_lay.getMeasuredHeight());
            this.bitmap = Bitmap.createBitmap(this.li_stamp_lay.getMeasuredWidth(), this.li_stamp_lay.getMeasuredHeight(), Bitmap.Config.ARGB_4444);
            this.li_stamp_lay.draw(new Canvas(this.bitmap));
            return this.bitmap;
        } catch (Exception | OutOfMemoryError unused) {
            return null;
        }
    }


    private String getTimezone(int i) {
        String displayName = Calendar.getInstance().getTimeZone().getDisplayName(false, 1);
        Date time = Calendar.getInstance(TimeZone.getTimeZone("GMT"), Locale.getDefault()).getTime();
        String format = new SimpleDateFormat("Z").format(time);
        String format2 = new SimpleDateFormat("ZZZZZ", Locale.getDefault()).format(time);
        switch (i) {
            case 1:
                return format;
            case 2:
                return "UTC " + format;
            case 3:
                return "GMT " + format;
            case 4:
                return format2;
            case 5:
                return "UTC " + format2;
            case 6:
                return "GMT " + format2;
            case 7:
                return displayName;
            default:
                return "";
        }
    }

    public String getColoredSpanned(String str, int i) {
        return "<font color=" + i + "><b>" + str + "</b></font>";
    }

    public void loadMap() {
        double d;
        double d2;
        String string = this.mSP.getString(this, SP.LATITUDE, "");
        String string2 = this.mSP.getString(this, SP.LONGITUDE, "");
//        callElevationApi(Double.parseDouble(string), Double.parseDouble(string2));
        this.mSP.setString(this, SP.PLUS_CODE, OpenLocationCode.encode(Double.parseDouble(string), Double.parseDouble(string2)));
        if (string == null || string2 == null || string.isEmpty() || string2.isEmpty()) {
            d = 0.0d;
            d2 = 0.0d;
        } else {
            if (string.contains(",")) {
                string = string.replace(",", ".");
            }
            if (string2.contains(",")) {
                string2 = string2.replace(",", ".");
            }
            d2 = Double.valueOf(string).doubleValue();
            d = Double.valueOf(string2).doubleValue();
        }
        if (this.mGMap == null || d2 == 0.0d || d == 0.0d) {
            return;
        }
        LatLng latLng = new LatLng(d2, d);
        this.mGMap.clear();
        this.marker = null;
        if (this.isTablet) {
            this.marker = this.mGMap.addMarker(new MarkerOptions().position(latLng).flat(true).draggable(false).anchor(0.5f, 0.5f).icon(BitmapFromVector(this, R.drawable.google_map_pin, 20, 35)));
        } else {
            this.marker = this.mGMap.addMarker(new MarkerOptions().position(latLng).flat(true).draggable(false).anchor(0.5f, 0.5f).icon(BitmapFromVector(this, R.drawable.google_map_pin, 35, 60)));
        }
        this.mGMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        this.mGMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16.0f));
    }

    private BitmapDescriptor BitmapFromVector(Context context, int i, int i2, int i3) {
        Drawable drawable = ContextCompat.getDrawable(context, i);
        drawable.setBounds(0, 0, i2, i3);
        Bitmap createBitmap = Bitmap.createBitmap(i2, i3, Bitmap.Config.ARGB_8888);
        drawable.draw(new Canvas(createBitmap));
        return BitmapDescriptorFactory.fromBitmap(createBitmap);
    }
    private void mapSnapshot() {
        try {
            System.gc();
            if (this.mGMap != null && HelperClass.check_internet(this)) {
                this.mGMap.snapshot(new GoogleMap.SnapshotReadyCallback() {
                    @Override
                    public void onSnapshotReady(Bitmap bitmap) {
                        if (bitmap != null) {
                            mapBitmap = bitmap;
                        }
                    }
                });
            }
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
        }
    }

//    private void mapSnapshot() {
//        System.gc();
//        if (checkPermissions()) {
//            mGMap.setOnMapLoadedCallback(new GoogleMap.OnMapLoadedCallback() {
//                public void onMapLoaded() {
//                    mGMap.snapshot(new GoogleMap.SnapshotReadyCallback() {
//                        public void onSnapshotReady(Bitmap bitmap) {
//                            MainActivity.this.mapBitmap = bitmap;
//                            Log.e(TAG, "onSnapshotReady: "+mapBitmap );
//                        }
//                    });
//                }
//            });
//        } else {
//            requestPermissions();
//        }
//
//    }
    private void requestPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION}, 12123);
    }

    private boolean checkPermissions() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

//        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    if (mGMap != null) {
//                        mGMap.snapshot(new GoogleMap.SnapshotReadyCallback() {
//                            @Override
//                            public void onSnapshotReady(Bitmap bitmap) {
//                                if (bitmap != null) {
//                                    MainActivity.this.mapBitmap = bitmap;
//                                }
//                            }
//                        });
//                    }
//                } catch (OutOfMemoryError e) {
//                    e.printStackTrace();
//                }
//            }
//        }, 1000); // 1-second delay, adjust as needed

    private boolean getbooleanvalue() {
        if (this.mSP.getInteger(this, "template_type", 0) == 0) {
            boolean z = this.mSP.getBoolean(this, "is_weather", false);
            boolean z1 = this.mSP.getBoolean(this, "is_pressure", false);
            boolean z2 = this.mSP.getBoolean(this, "is_wind", false);
            return (z) || (this.mSP.getBoolean(this, "is_humidity", false)) || (z1) || (z2);
        }

        boolean z3 = this.mSP.getBoolean(this, "is_weather_classic", false);
        boolean z4 = this.mSP.getBoolean(this, "is_pressure_classic", false);
        boolean z5 = this.mSP.getBoolean(this, "is_wind_classic", false);
        return (z3) || (this.mSP.getBoolean(this, "is_humidity_classic", false)) || (z4) || (z5);
    }

    private void callWeatherApi() {
        double d;
        if (this.mSP.getBoolean(this, SP.IS_CALL_WEATHER_API, true) && NetworkState.Companion.isOnline(this) && getbooleanvalue()) {
            this.mSP.setBoolean(this, SP.IS_CALL_WEATHER_API, false);
            String string = this.mSP.getString(this, SP.LATITUDE, "");
            String string2 = this.mSP.getString(this, SP.LONGITUDE, "");
            double d2 = 0.0d;
            if (string == null || string2 == null || string.isEmpty() || string2.isEmpty()) {
                d = 0.0d;
            } else {
                if (string.contains(",")) {
                    string = string.replace(",", ".");
                }
                if (string2.contains(",")) {
                    string2 = string2.replace(",", ".");
                }
                d2 = Double.valueOf(string).doubleValue();
                d = Double.valueOf(string2).doubleValue();
            }
            final double round = round(d2, 2);
            final double round2 = round(d, 2);
            if (round == this.oldlate && round2 == this.oldlong) {
                return;
            }
            Log.e("weather_api : ", NotificationCompat.CATEGORY_CALL);
            StringRequest stringRequest = new StringRequest(0, "https://api.openweathermap.org/data/2.5/weather?lat=" + d2 + "&lon=" + d + "&appid=" + "a84de63bb92490a6da346b833bfabd94" + "&units=metric", new Response.Listener<String>() {
                @Override // com.android.volley.Response.Listener
                public void onResponse(String str) {
                    try {
                        PrintStream printStream = System.out;
                        printStream.println("CallWeatherApi          " + str);
                        JSONObject jSONObject = new JSONObject(str);
                        JSONObject jSONObject2 = jSONObject.getJSONObject("main");
                        float parseFloat = Float.parseFloat(jSONObject2.getString("temp"));
                        String string3 = jSONObject2.getString("humidity");
                        float parseFloat2 = Float.parseFloat(jSONObject2.getString("pressure"));
                        CameraMainActivity.this.mfTemprature_value = parseFloat;
                        CameraMainActivity.this.mSP.setFloat(CameraMainActivity.this, SP.TEMPRETURE_VALUE, parseFloat);
                        CameraMainActivity.this.mSP.setString(CameraMainActivity.this, SP.HUMIDITY_VALUE, string3);
                        CameraMainActivity.this.mSP.setFloat(CameraMainActivity.this, SP.PRESSURE_VALUE, parseFloat2);
                        CameraMainActivity.this.oldlate = round;
                        CameraMainActivity.this.oldlong = round2;
                        JSONArray jSONArray = jSONObject.getJSONArray("weather");
                        Log.e("jAryIcon001", "" + jSONArray);
                        if (jSONArray.length() != 0) {
                            JSONObject jSONObject3 = jSONArray.getJSONObject(0);
                            SP sp = CameraMainActivity.this.mSP;
                            CameraMainActivity mainActivity = CameraMainActivity.this;
                            sp.setInteger(mainActivity, SP.WEATHER_ICON, mainActivity.getIconCode(jSONObject3.getString("icon")));
                        }
                        CameraMainActivity.this.mSP.setFloat(CameraMainActivity.this, SP.WIND_VALUE, Float.parseFloat(jSONObject.getJSONObject("wind").getString("speed")));
                        CameraMainActivity.this.setUpStampLayout();
                    } catch (JSONException e) {
                        Log.e("JSONException", "" + e.getMessage());
                    } catch (Exception e2) {
                        Log.e("Exception", "" + e2.getMessage());
                    }
                }
            }, new Response.ErrorListener() { // from class: com.live.gpsmap.camera.Camera.MainActivity.36
                @Override // com.android.volley.Response.ErrorListener
                public void onErrorResponse(VolleyError volleyError) {
                    Log.e("VolleyError", "" + volleyError.getMessage());
                }
            });
            stringRequest.setShouldCache(false);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(30000, 0, 1.0f));
            this.mVolleyQueue.add(stringRequest);
        }
    }

    private int getIconCode(String s) {
        s.equalsIgnoreCase("01d");
        boolean z = s.equalsIgnoreCase("02d");
        int z1 = 0;
        if (s.equalsIgnoreCase("03d")) {
            z1 = 2;
        }

        if (s.equalsIgnoreCase("04d")) {
            z1 = 3;
        }

        if (s.equalsIgnoreCase("09d")) {
            z1 = 4;
        }

        if (s.equalsIgnoreCase("10d")) {
            z1 = 5;
        }

        if (s.equalsIgnoreCase("11d")) {
            z1 = 6;
        }

        if (s.equalsIgnoreCase("13d")) {
            z1 = 7;
        }

        if (s.equalsIgnoreCase("50d")) {
            z1 = 8;
        }

        if (s.equalsIgnoreCase("01n")) {
            z1 = 9;
        }

        if (s.equalsIgnoreCase("02n")) {
            z1 = 10;
        }

        if (s.equalsIgnoreCase("03n")) {
            z1 = 11;
        }

        if (s.equalsIgnoreCase("04n")) {
            z1 = 12;
        }

        if (s.equalsIgnoreCase("09n")) {
            z1 = 13;
        }

        if (s.equalsIgnoreCase("10n")) {
            z1 = 14;
        }

        if (s.equalsIgnoreCase("11n")) {
            z1 = 15;
        }

        if (s.equalsIgnoreCase("13n")) {
            z1 = 16;
        }

        if (s.equalsIgnoreCase("50n")) {
            z1 = 17;
        }

        Log.e(":::icon:::", "getIconCode: " + ((int) z1));
        return (int) z1;
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.mGMap = googleMap;
        setMapType();
        if (this.mLocationType.equals(Default.MANUAL)) {
            loadMap();
        }

//        this.mGMap = googleMap;
//        if (checkPermissions()) {
//            mGMap.setOnMapLoadedCallback(new GoogleMap.OnMapLoadedCallback() {
//                public void onMapLoaded() {
//                    mGMap.snapshot(new GoogleMap.SnapshotReadyCallback() {
//                        public void onSnapshotReady(Bitmap bitmap) {
//                            MainActivity.this.mapBitmap = bitmap;
//                            Log.e(TAG, "onSnapshotReady: "+mapBitmap );
//                        }
//                    });
//                }
//            });
////            mGMap.snapshot(new GoogleMap.SnapshotReadyCallback() {
////                public void onSnapshotReady(Bitmap bitmap) {
////                    MainActivity.this.mapBitmap = bitmap;
////                    Log.e(TAG, "onSnapshotReady: "+mapBitmap );
////                }
////            });
//        } else {
//            requestPermissions();
//        }
//        setMapType();
//        if (this.mLocationType.equals(Default.MANUAL)) {
//            loadMap();
//        }
    }

    @Override

    public boolean onNavigationItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.nav_language /* 2131362535 */:
                closeDrawer();

                this.languageLauncher.launch(new Intent(this, ActivityLanguageSelection.class));
                break;
            case R.id.nav_more_app /* 2131362537 */:
                if (NetworkState.Companion.isOnline(this)) {
//                    startActivity(new Intent(this, MoreAppsActivity.class));
                } else {
                    RelativeLayout relativeLayout = this.moMainLayout;
                    Snackbar.make(relativeLayout, "" + getString(R.string.no_internet_msg), -1).show();
                }
                closeDrawer();
                break;
            case R.id.nav_privacy_policy /* 2131362538 */:
                if (NetworkState.Companion.isOnline(this)) {
//                    startActivity(new Intent(this, Privacy_Policy.class));
                } else {
                    RelativeLayout relativeLayout2 = this.moMainLayout;
                    Snackbar.make(relativeLayout2, "" + getString(R.string.no_internet_msg), -1).show();
                }
                closeDrawer();
                break;
            case R.id.nav_rate_app /* 2131362539 */:
                if (this.rate_appflag) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            CameraMainActivity.this.rate_appflag = true;
                        }
                    }, this.TIME);
                    this.rate_appflag = false;
                    closeDrawer();
//                    Util.showSayThanksDialog(this);
                    break;
                }
                break;
            case R.id.nav_sd_card /* 2131362540 */:
                navSDCardClick();
                break;
            case R.id.nav_send_an_error /* 2131362541 */:
//                startActivity(new Intent(this, Send_An_Error.class));
                closeDrawer();
                break;
            case R.id.nav_share_app /* 2131362542 */:
                if (this.share_flag) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            CameraMainActivity.this.share_flag = true;
                        }
                    }, this.TIME);
                    this.share_flag = false;
                    Util.shareApp(this);
                    closeDrawer();
                    break;
                }
                break;
            case R.id.nav_whatermark /* 2131362545 */:
                if (this.watermark_flag) {
                    new Handler().postDelayed(new Runnable() { // from class: com.live.gpsmap.camera.Camera.MainActivity.38
                        @Override
                        public void run() {
                            CameraMainActivity.this.watermark_flag = true;
                        }
                    }, this.TIME);
                    this.watermark_flag = false;
                    if (this.mSP.getBoolean(this, "isPurcheshOrNot",false ) || this.mSP.getBoolean(this, "is_use_all_function", false)) {
                        if (this.is_watermark) {
                            this.mSP.setBoolean(this, SP.IS_WATER_MARK, false);
                            this.is_watermark = false;
                            this.switchNav_Watermark.setChecked(false);
                        } else {
                            this.mSP.setBoolean(this, SP.IS_WATER_MARK, true);
                            this.is_watermark = true;
                            this.switchNav_Watermark.setChecked(true);
                        }
                        setUpStampLayout();
                    } else {
                        dialog();
                    }
                    closeDrawer();
                    break;
                }
                break;
        }
        return true;
    }

    private void navSDCardClick() {
        Log.e(":::TyTyTy:::", "navSDCardClick: " + this.isSDCardStorageEnabled);
        if (!this.isSDCardStorageEnabled) {
            if (EnvironmentSDCard.isSDCardAvailable(this)) {
                if (!this.isSDCardPermission) {
                    giveSDCardPermission();
                } else {
                    this.isSDCardStorageEnabled = true;
                    this.mSP.setBoolean(this, PreferenceKeys.UsingSAFPreferenceKey, true);
                    switchSDChecked();
                }
            }
        } else {
            this.isSDCardStorageEnabled = false;
            this.mSP.setBoolean(this, PreferenceKeys.UsingSAFPreferenceKey, false);
            switchSDChecked();
        }
        closeDrawer();
    }

    public void giveSDCardPermission() {
        try {
            AlertDialog alertDialog = this.alertSDPermissionDialog;
            if (alertDialog != null && this.alertHintDialog == null) {
                if (!alertDialog.isShowing()) {
                    this.alertSDPermissionDialog.show();
                }
            } else if (!isFinishing()) {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(getResources().getString(R.string.give_seconday_permission_title));
                builder.setMessage(getResources().getString(R.string.give_seconday_permission_message)).setCancelable(false).setPositiveButton(getResources().getString(R.string.give_seconday_permission_btn), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (CameraMainActivity.this.alertSDPermissionDialog != null) {
                            CameraMainActivity.this.alertSDPermissionDialog.dismiss();
                        }
                        CameraMainActivity.this.alertSDPermissionDialog = null;
                        CameraMainActivity.this.openStoragePermissionHintDialog();
                    }
                }).setNegativeButton(getResources().getString(R.string.skip), new DialogInterface.OnClickListener() { // from class: com.live.gpsmap.camera.Camera.MainActivity.41
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (CameraMainActivity.this.alertSDPermissionDialog != null) {
                            CameraMainActivity.this.alertSDPermissionDialog.dismiss();
                        }
                        CameraMainActivity.this.alertSDPermissionDialog = null;
                        CameraMainActivity.this.setSdCardPermissionFlag(false);
                    }
                });
                AlertDialog create = builder.create();
                this.alertSDPermissionDialog = create;
                if (this.alertHintDialog == null) {
                    create.show();
                }
            }
        } catch (Exception unused) {
            this.alertSDPermissionDialog = null;
        }
    }

    public void openStoragePermissionHintDialog() {
        try {
            AlertDialog alertDialog = this.alertHintDialog;
            if (alertDialog != null) {
                if (!alertDialog.isShowing()) {
                    this.alertHintDialog.show();
                }
            } else if (!isFinishing()) {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Hint");
                builder.setCancelable(false);
                LayoutInflater layoutInflater = (LayoutInflater) getSystemService("layout_inflater");
                View inflate = LayoutInflater.from(this).inflate(R.layout.hint_dialog, (ViewGroup) null);
                builder.setView(inflate);
                ((LinearLayout) inflate.findViewById(R.id.btn_ok)).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent;
                        try {
                            if (Build.VERSION.SDK_INT>=21) {
                                intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
                                intent.addFlags(64);
                                intent.addFlags(1);
                                intent.addFlags(2);
                                intent.addFlags(128);
                                intent.addFlags(16);
                            } else {
                                intent = new Intent();
                                intent.addFlags(1);
                                intent.addFlags(2);
                            }
                            if (CameraMainActivity.this.alertHintDialog != null) {
                                CameraMainActivity.this.alertHintDialog.dismiss();
                            }
                            CameraMainActivity.this.alertHintDialog = null;

                            CameraMainActivity.this.startActivityForResult(intent, 42);
                        } catch (ActivityNotFoundException unused) {
                            CameraMainActivity.this.setSdCardPermissionFlag(false);
                            CameraMainActivity.this.openNoIntentAvailableDialog();
                            CameraMainActivity.this.alertHintDialog = null;
                        }
                    }
                });
                AlertDialog create = builder.create();
                this.alertHintDialog = create;
                create.show();
            }
        } catch (Exception unused) {
        }
    }

    public void openNoIntentAvailableDialog() {
        if (isFinishing()) {
            return;
        }
        AlertDialog alertDialog = this.alertNoIntentDialog;
        if (alertDialog != null) {
            if (alertDialog.isShowing()) {
                return;
            }
            this.alertNoIntentDialog.show();
            return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getResources().getString(R.string.external_sdcard_write_permission));
        builder.setMessage(getResources().getString(R.string.sdcard_not_root_device)).setCancelable(false).setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (CameraMainActivity.this.alertNoIntentDialog != null) {
                    CameraMainActivity.this.alertNoIntentDialog.dismiss();
                }
                CameraMainActivity.this.alertNoIntentDialog = null;
            }
        });
        AlertDialog create = builder.create();
        this.alertNoIntentDialog = create;
        create.show();
    }

    private void switchSDChecked() {
        this.switchNav_SDCard.setChecked(this.isSDCardStorageEnabled);
    }

    public void setSdCardPermissionFlag(boolean z) {
        this.isSDCardPermission = z;
        this.isSDCardStorageEnabled = z;
        switchSDChecked();
        this.mSP.setBoolean(this, PreferenceKeys.UsingSAFPreferenceKey, this.isSDCardStorageEnabled);
        this.mSP.setBoolean(this, PreferenceKeys.IS_SDCARD_PERMISSION, this.isSDCardPermission);
    }

    public void setOnBackPressedListener(OnBackPressedListener onBackPressedListener) {
        this.onBackPressedListener = onBackPressedListener;
    }

    public boolean isMultiCamEnabled() {
        return this.is_multi_cam && PreferenceManager.getDefaultSharedPreferences(this).getBoolean(PreferenceKeys.MultiCamButtonPreferenceKey, true);
    }

    public int getNextCameraId() {
        String str = TAG;
        Log.d(str, "getNextCameraId");
        int actualCameraId = getActualCameraId();
        Log.d(str, "current cameraId: " + actualCameraId);
        if (this.preview.canSwitchCamera()) {
            if (isMultiCamEnabled()) {
                int i = AnonymousClass91.$SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$Facing[this.preview.getCameraControllerManager().getFacing(actualCameraId).ordinal()];
                if (i != 1) {
                    if (i == 2) {
                        if (this.other_camera_ids.size()>0) {
                            actualCameraId = this.other_camera_ids.get(0).intValue();
                        } else if (this.back_camera_ids.size()>0) {
                            actualCameraId = this.back_camera_ids.get(0).intValue();
                        }
                    } else if (this.back_camera_ids.size()>0) {
                        actualCameraId = this.back_camera_ids.get(0).intValue();
                    } else if (this.front_camera_ids.size()>0) {
                        actualCameraId = this.front_camera_ids.get(0).intValue();
                    }
                } else if (this.front_camera_ids.size()>0) {
                    actualCameraId = this.front_camera_ids.get(0).intValue();
                } else if (this.other_camera_ids.size()>0) {
                    actualCameraId = this.other_camera_ids.get(0).intValue();
                }
            } else {
                actualCameraId = (actualCameraId + 1) % this.preview.getCameraControllerManager().getNumberOfCameras();
            }
        }
        Log.d(str, "next cameraId: " + actualCameraId);
        return actualCameraId;
    }

    private int getActualCameraId() {
        if (this.preview.getCameraController() == null) {
            return this.applicationInterface.getCameraIdPref();
        }
        return this.preview.getCameraId();
    }

    private void userSwitchToCamera(int i) {
        Log.d(TAG, "userSwitchToCamera: " + i);
        this.li_switch_camera = (LinearLayout) findViewById(R.id.li_switch_camera);
        this.li_Multi_Camera = (LinearLayout) findViewById(R.id.liMultiCamera);
        this.li_switch_camera.setEnabled(false);
        this.li_Multi_Camera.setEnabled(false);
        this.applicationInterface.reset(true);
        this.preview.setCamera(i);
        this.li_switch_camera.setEnabled(true);
        this.li_Multi_Camera.setEnabled(true);
    }

    private void internetAlertDialog() {
        int i;
        if (isFinishing() || (i = this.isInternetDialog) != 0) {
            return;
        }
        this.isInternetDialog = i + 1;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getResources().getString(R.string.no_internet_msg)).setCancelable(false).setNeutralButton(getString(R.string.ok), new DialogInterface.OnClickListener() { // from class: com.live.gpsmap.camera.Camera.MainActivity.47
            @Override
            public void onClick(DialogInterface dialogInterface, int i2) {
                try {
                    CameraMainActivity.this.createLocationRequest();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                dialogInterface.dismiss();
            }
        }).setPositiveButton(getResources().getString(R.string.wifi), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i2) {
                CameraMainActivity.this.isInternetDialog = 0;
                dialogInterface.dismiss();
                try {

                    CameraMainActivity.this.startActivity(new Intent());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).setNegativeButton(getResources().getString(R.string.Mobiledata), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i2) {
                CameraMainActivity.this.isInternetDialog = 0;
                dialogInterface.dismiss();
                Intent intent = new Intent();
                intent.setAction("android.settings.WIRELESS_SETTINGS");

                CameraMainActivity.this.startActivityForResult(intent, 0);
            }
        });
        final AlertDialog create = builder.create();
        create.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                create.getButton(-1).setBackgroundResource(R.drawable.my_ripple);
                create.getButton(-2).setBackgroundResource(R.drawable.my_ripple);
                create.getButton(-3).setBackgroundResource(R.drawable.my_ripple);
            }
        });
        create.show();
    }
    public void isNotification() {
        SP sp = new SP(this);
        this.mSP = sp;
        if (sp.getBoolean(this, "isfromnotification")) {
            this.mSP.setBoolean(this, "isfromnotification", false);
            String string = this.mSP.getString(this, "isfromnotificationtype", "");
            if (string == null || string.equals("") || string.length()<=0) {
                return;
            }
            if (string.equals("rate")) {
//                Util.showSayThanksDialog(this);
            } else if (string.equals("share")) {
                Util.shareApp(this);
            } else if (string.equals("message")) {
                Util.showDialog(this, getResources().getString(R.string.app_name), this.mSP.getString(this, "isfromnotificationmessage", ""));
            } else if (string.equals("URL")) {

                startActivity(new Intent(Intent.ACTION_SEND, getIntent().getData()));
            }
        }
    }

    public void setDeviceDefaults() {
        Log.d(TAG, "setDeviceDefaults");
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        boolean contains = Build.MANUFACTURER.toLowerCase(Locale.US).contains("samsung");
        boolean contains2 = Build.MANUFACTURER.toLowerCase(Locale.US).contains("oneplus");
        Log.d(TAG, "is_samsung? " + contains);
        Log.d(TAG, "is_oneplus? " + contains2);
        if (contains || contains2) {
            Log.d(TAG, "set fake flash for camera2");
            SharedPreferences.Editor edit = defaultSharedPreferences.edit();
            edit.putBoolean(PreferenceKeys.Camera2FakeFlashPreferenceKey, true);
            edit.apply();
        }
    }

    private void setModeFromIntents(Bundle bundle) {
        boolean z;
        int i;
        Log.d(TAG, "setModeFromIntents");
        if (bundle != null) {
            Log.d(TAG, "restoring from saved state");
            return;
        }
        String action = getIntent().getAction();
        boolean z2 = true;
        if ((Build.VERSION.SDK_INT>=24 && MyTileServiceFrontCamera.TILE_ID.equals(action)) || ACTION_SHORTCUT_SELFIE.equals(action)) {
            Log.d(TAG, "launching from quick settings tile or application shortcut for Open Camera: selfie mode");
            this.applicationInterface.switchToCamera(true);
            z = true;
        } else {
            if (ACTION_SHORTCUT_GALLERY.equals(action)) {
                Log.d(TAG, "launching from application shortcut for Open Camera: gallery");
                openGallery();
            } else if (ACTION_SHORTCUT_SETTINGS.equals(action)) {
                Log.d(TAG, "launching from application shortcut for Open Camera: settings");
            }
            z = false;
        }
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            Log.d(TAG, "handle intent extra information");
            if (!z && ((i = extras.getInt("android.intent.extras.CAMERA_FACING", -1)) == 0 || i == 1)) {
                Log.d(TAG, "found android.intent.extras.CAMERA_FACING: " + i);
                this.applicationInterface.switchToCamera(i == 1);
                z = true;
            }
            if (!z && extras.getInt("android.intent.extras.LENS_FACING_FRONT", -1) == 1) {
                Log.d(TAG, "found android.intent.extras.LENS_FACING_FRONT");
                this.applicationInterface.switchToCamera(true);
                z = true;
            }
            if (!z && extras.getInt("android.intent.extras.LENS_FACING_BACK", -1) == 1) {
                Log.d(TAG, "found android.intent.extras.LENS_FACING_BACK");
                this.applicationInterface.switchToCamera(false);
                z = true;
            }
            if (!z && extras.getBoolean("android.intent.extra.USE_FRONT_CAMERA", false)) {
                Log.d(TAG, "found android.intent.extra.USE_FRONT_CAMERA");
                this.applicationInterface.switchToCamera(true);
                if (!z2 || this.applicationInterface.hasSetCameraId()) {
                }
                Log.d(TAG, "initialise to back camera");
                this.applicationInterface.switchToCamera(false);
                return;
            }
        }
        z2 = z;
        if (z2) {
        }
    }

    private void initCamera2Support() {
        Log.d(TAG, "initCamera2Support");
        this.supports_camera2 = false;
        if (Build.VERSION.SDK_INT>=21) {
            CameraControllerManager2 cameraControllerManager2 = new CameraControllerManager2(this);
            this.supports_camera2 = false;
            int numberOfCameras = cameraControllerManager2.getNumberOfCameras();
            if (numberOfCameras == 0) {
                Log.d(TAG, "Camera2 reports 0 cameras");
                this.supports_camera2 = false;
            }
            for (int i = 0; i<numberOfCameras && !this.supports_camera2; i++) {
                if (cameraControllerManager2.allowCamera2Support(i)) {
                    Log.d(TAG, "camera " + i + TAG);
                    this.supports_camera2 = true;
                }
            }
        }
        if (test_force_supports_camera2 && Build.VERSION.SDK_INT>=21) {
            Log.d(TAG, "forcing supports_camera2");
            this.supports_camera2 = true;
        }
        Log.d(TAG, "supports_camera2? " + this.supports_camera2);
        PrintStream printStream = System.out;
        printStream.println(TAG + this.supports_camera2);
        if (this.supports_camera2) {
            SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            if (!defaultSharedPreferences.contains(PreferenceKeys.CameraAPIPreferenceKey) && defaultSharedPreferences.contains("preference_use_camera2") && defaultSharedPreferences.getBoolean("preference_use_camera2", false)) {
                Log.d(TAG, "transfer legacy camera2 boolean preference to new api option");
                SharedPreferences.Editor edit = defaultSharedPreferences.edit();
                edit.putString(PreferenceKeys.CameraAPIPreferenceKey, "preference_camera_api_camera2");
                edit.remove("preference_use_camera2");
                edit.apply();
            }
        }
    }


    @Override
    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        activity_count--;
        Log.d(TAG, "activity_count: " + activity_count);
        cancelImageSavingNotification();
        waitUntilImageQueueEmpty();
        this.preview.onDestroy();
        MyApplicationInterface myApplicationInterface = this.applicationInterface;
        if (myApplicationInterface != null) {
            myApplicationInterface.onDestroy();
        }
        if (Build.VERSION.SDK_INT>=23 && activity_count == 0) {
            Log.d(TAG, "release renderscript contexts");
            RenderScript.releaseAllContexts();
        }
        if (this.textToSpeech != null) {
            Log.d(TAG, "free textToSpeech");
            this.textToSpeech.stop();
            this.textToSpeech.shutdown();
            this.textToSpeech = null;
        }
        stopLocationUpdates();
        cancelTimer();
        super.onDestroy();
        Log.d(TAG, "onDestroy done");
        SupportMapFragment supportMapFragment = this.mMapView;
        if (supportMapFragment != null) {
            supportMapFragment.onDestroy();
        }
    }

    public void audioTrigger() {
        Log.d(TAG, "ignore audio trigger due to popup open");
        if (this.camera_in_background) {
            Log.d(TAG, "ignore audio trigger due to camera in background");
        } else if (this.preview.isTakingPhotoOrOnTimer()) {
            Log.d(TAG, "ignore audio trigger due to already taking photo or on timer");
        } else if (this.preview.isVideoRecording()) {
            Log.d(TAG, "ignore audio trigger due to already recording video");
        } else {
            Log.d(TAG, "schedule take picture due to loud noise");
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Log.d(CameraMainActivity.TAG, "taking picture due to audio trigger");
                    CameraMainActivity.this.takePicture(false);
                }
            });
        }
    }

    @Override
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        Log.d(TAG, "onKeyDown: " + i);
        if (this.mainUI.onKeyDown(i, keyEvent)) {
            return true;
        }
        return super.onKeyDown(i, keyEvent);
    }

    @Override
    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        Log.d(TAG, "onKeyUp: " + i);
        this.mainUI.onKeyUp(i, keyEvent);
        return super.onKeyUp(i, keyEvent);
    }

    public void zoomIn() {
        this.mainUI.changeSeekbar(R.id.zoom_seekbar, -1);
    }

    public void zoomOut() {
        this.mainUI.changeSeekbar(R.id.zoom_seekbar, 1);
    }

    public float getWaterDensity() {
        return this.mWaterDensity;
    }

    @Override // android.app.Activity
    protected void onRestart() {
        super.onRestart();
        this.mLocationType = this.mSP.getString(this, SP.LOCATION_TYPE, Default.AUTOMATIC);
        initmap();
    }

    @Override
    public void onResume() {
        Log.e(TAG, " resultLauncher 22222222: " );
        try {
            window.clearFlags(16);
            if (this.mDrawerLayout.isDrawerOpen(3)) {
                showSystemUI();
            } else {
                hideSystemUI();
            }
            long currentTimeMillis = System.currentTimeMillis();
            if (this.ll_filterview.getVisibility() == 0) {
                this.ll_filterview.setVisibility(View.GONE);
            }
            super.onResume();
            if (Build.VERSION.SDK_INT>32 && !checkNotiPermission()) {
                getPermission();
            }
            this.applicationInterface.reset(false);
            if (checkStoragePermission() && checkLocationPermission()) {
                if (!this.scannerMode) {
                    setModePhoto();
                } else {
                    setModeQRCode();
                    AlertDialog alertDialog = this.resultDialog;
                    if (alertDialog != null) {
                        alertDialog.dismiss();
                    }
                }
            } else {
                this.mSP.setBoolean(this, SP.ALL_PERMISSION_ACCESS, false);

                startActivity(new Intent(this, ActivityPermission.class));
                finish();
            }
            this.mainUI.layoutUI();
            Default.ISEXITNATIVE = this.mSP.getInteger(this, SP.ISEXITNATIVE, 2);
            this.app_is_paused = false;
            if (Default.ISEXITNATIVE == 1) {
                this.exitDialogBinding = DialogExitNativeBinding.inflate(getLayoutInflater());
                setUpExitDialog();
                refreshNative();
            }
            cancelImageSavingNotification();
            getWindow().getDecorView().getRootView().setBackgroundColor(-16777216);
            this.mSensorManager.registerListener(this.accelerometerListener, this.mSensorAccelerometer, 3);
            this.magneticSensor.registerMagneticListener(this.mSensorManager);
            this.orientationEventListener.enable();
            ContextCompat.registerReceiver(this, cameraReceiver, new IntentFilter("com.miband2.action.CAMERA"), ContextCompat.RECEIVER_NOT_EXPORTED);
            this.bluetoothRemoteControl.startRemoteControl();
            this.speechControl.initSpeechRecognizer();
            initGyroSensors();
            this.applicationInterface.getImageSaver().onResume();
            this.soundPoolManager.initSound();
            this.soundPoolManager.loadSound(R.raw.mybeep);
            this.soundPoolManager.loadSound(R.raw.mybeep_hi);
            this.mainUI.toggleExposureUI();
            int cameraIdPref = this.applicationInterface.getCameraIdPref();
            if (cameraIdPref>0) {
                CameraControllerManager cameraControllerManager = this.preview.getCameraControllerManager();
                CameraController.Facing facing = cameraControllerManager.getFacing(cameraIdPref);
                Log.d(TAG, "front_facing: " + facing);
                if (cameraControllerManager.getNumberOfCameras()>2) {
                    boolean z = true;
                    for (int i = 0; i<cameraIdPref; i++) {
                        CameraController.Facing facing2 = cameraControllerManager.getFacing(i);
                        Log.d(TAG, "camera " + i + " that_front_facing: " + facing2);
                        if (facing2 == facing) {
                            z = false;
                        }
                    }
                    Log.d(TAG, "::::" + z);
                    if (!z) {
                        pushCameraIdToast(cameraIdPref);
                    }
                }
            }
            if (this.preview != null) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        int integer = CameraMainActivity.this.mSP.getInteger(CameraMainActivity.this, PreferenceKeys.FLASH_POS, 0);
                        if (integer == 0) {
                            CameraMainActivity.this.preview.updateFlash("flash_off", true);
                            CameraMainActivity.this.mainUI.updateCycleFlashIcon();
                        } else if (integer == 1) {
                            CameraMainActivity.this.preview.updateFlash("flash_auto", true);
                            CameraMainActivity.this.mainUI.updateCycleFlashIcon();
                        } else if (integer == 2) {
                            CameraMainActivity.this.preview.updateFlash("flash_on", true);
                            CameraMainActivity.this.mainUI.updateCycleFlashIcon();
                        } else if (integer != 3) {
                        } else {
                            CameraMainActivity.this.preview.updateFlash("flash_torch", true);
                            CameraMainActivity.this.mainUI.updateCycleFlashIcon();
                        }
                    }
                }, 400L);
            }
            Log.d(TAG, ":::" + (System.currentTimeMillis() - currentTimeMillis));
            Log.e(":::data:::", "onResume: " + useScopedStorage());
            if (checkStoragePermission()) {
                updateGalleryIcon();
                this.mLocationType = this.mSP.getString(this, SP.LOCATION_TYPE, Default.AUTOMATIC);
                if (checkLocationPermission()) {
                    Compass compass = this.compass;
                    if (compass != null) {
                        compass.start();
                    }
                    updateSaveFolder();
                    if (NetworkState.Companion.isOnline(this)) {
                        callWeatherApi();
                        createLocationRequest();
                        if (this.mLocationType.equals(Default.MANUAL)) {
                            if (this.mSP.getBoolean(this, SP.IS_LOCATION_CHANGED, false)) {
                                this.mSP.setBoolean(this, SP.IS_LOCATION_CHANGED, false);
                                this.mSP.setBoolean(this, SP.IS_CALL_WEATHER_API, true);
                                callWeatherApi();
                                initmap();
                            }
                            loadMap();
                        }
                    } else {
                        initmap();
                        internetAlertDialog();
                    }
                } else {
                    this.mSP.setBoolean(this, SP.ALL_PERMISSION_ACCESS, false);

                    startActivity(new Intent(this, ActivityPermission.class));
                    finish();
                }
            }
            if (!checkLocationPermission() && this.flag_prermission == 1) {
                this.flag_prermission = 0;
                this.mSP.setBoolean(this, SP.ALL_PERMISSION_ACCESS, false);

                startActivity(new Intent(this, ActivityPermission.class));
                finish();
            }
            if (this.mMapView != null) {
                this.mMapView.onResume();
            }
            setUpStampLayout();
            if (this.mSP.getBoolean(this, "isPurcheshOrNot", false) || this.mSP.getBoolean(this, "is_use_all_function", false)) {
                this.img_watermark.setVisibility(View.GONE);
            } else {
                this.img_watermark.setVisibility(View.VISIBLE);
            }
        }catch (IllegalStateException e){
            e.printStackTrace();
            Log.e(TAG, "onResume 111111111  : "+e.getMessage());
        }

    }

    private void getPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.POST_NOTIFICATIONS")) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.POST_NOTIFICATIONS"}, 100);
        }
    }

    private boolean checkNotiPermission() {
        return ContextCompat.checkSelfPermission(this, "android.permission.POST_NOTIFICATIONS") == 0;
    }

    public void updateSaveFolder() {
        File file = new File(this.mSP.getString(this, SP.FOLDER_PATH, Default.DEFAULT_FOLDER_PATH));
        String name = file.getName();
        if (this.mSP.getBoolean(this, SP.IS_DISPLAY_FOLDER_NAME, true)) {
            if (name.equals("Camera")) {
                this.mTv_folder_name.setText("Default");
            } else {
                this.mTv_folder_name.setText(file.getName());
            }
            this.mTv_folder_name.setVisibility(View.VISIBLE);
        } else {
            this.mTv_folder_name.setVisibility(View.GONE);
        }
        if (name != null) {
            SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            if (this.applicationInterface.getStorageUtils().getSaveLocation().equals(name)) {
                return;
            }
            Log.d(TAG, "changed save_folder to: " + this.applicationInterface.getStorageUtils().getSaveLocation());
            if (!name.equals("Camera")) {
                name = "GPS Map Camera/" + name;
            }
            SharedPreferences.Editor edit = defaultSharedPreferences.edit();
            edit.putString(PreferenceKeys.SaveLocationPreferenceKey, name);
            edit.apply();
            this.save_location_history.updateFolderHistory(getStorageUtils().getSaveLocation(), true);
        }
    }

    private void checkInApp() {
        if (NetworkState.Companion.isOnline(this)) {
            this.purchaseInAppHelper = new PurchaseHelper(this, getInAppHelperListener());
            loadData();
        }
    }

    public PurchaseHelper.PurchaseHelperListener getInAppHelperListener() {
        return new PurchaseHelper.PurchaseHelperListener() {
            @Override
            public void onProductQueryResponse(List<ProductDetails> list) {
            }

            @Override
            public void onPurchasesUpdated(BillingResult billingResult, List<Purchase> list) {
            }

            @Override
            public void onServiceConnected(int i) {
                Log.e("::MG::DDD1", "onServiceConnected: " + i);
                if (CameraMainActivity.this.isPurchaseQueryPending) {
                    CameraMainActivity.this.purchaseInAppHelper.getPurchasedItems("inapp");
                    CameraMainActivity.this.isPurchaseQueryPending = false;
                }
            }

            @Override
            public void onPurchasehistoryResponse(List<PurchaseHistoryRecord> list) {
                CameraMainActivity.this.purchaseHistory = list;
                if (CameraMainActivity.this.purchaseHistory != null) {
                    ArrayList arrayList = new ArrayList();
                    arrayList.add(CameraMainActivity.this.getResources().getString(R.string.PRODUCT_ID_ALL));
                    arrayList.add(CameraMainActivity.this.getResources().getString(R.string.PRODUCT_ID_WITH_AD));
                    arrayList.add(CameraMainActivity.this.getResources().getString(R.string.PRODUCT_ID_AD));
                    List<String> arrayList2 = new ArrayList<>();
                    arrayList2.add(CameraMainActivity.this.getResources().getString(R.string.PRODUCT_ID_ALL));
                    arrayList2.add(CameraMainActivity.this.getResources().getString(R.string.PRODUCT_ID_WITH_AD));
                    arrayList2.add(CameraMainActivity.this.getResources().getString(R.string.PRODUCT_ID_AD));
                    ArrayList<String> arrayList3 = new ArrayList(arrayList2);
                    List<String> purchasedProductIdListing = SearchHelper.getPurchasedProductIdListing(CameraMainActivity.this.purchaseHistory);
                    if (purchasedProductIdListing.size()>0) {
                        arrayList3.retainAll(purchasedProductIdListing);
                        for (String str : arrayList3) {
                            for (int i = 0; i<arrayList.size(); i++) {
                                if (str.equals(arrayList.get(i))) {
                                    CameraMainActivity.this.setSharedpr(i, true);
                                }
                            }
                        }
                        arrayList2.removeAll(purchasedProductIdListing);
                    }
                    for (String str2 : arrayList2) {
                        for (int i2 = 0; i2<arrayList.size(); i2++) {
                            if (str2.equals(arrayList.get(i2))) {
                                CameraMainActivity.this.setSharedpr(i2, false);
                            }
                        }
                    }
                    if (arrayList2.size()>0) {
                        CameraMainActivity.this.purchaseInAppHelper.getSkuDetails(arrayList2, "inapp");
                    }
                }
            }
        };
    }

    public void setSharedpr(int i, boolean z) {
        if (i != 0) {
            if (i == 1) {
                this.mSP.setBoolean(this, "is_use_all_function", z );
            } else if (i == 2 && !this.mSP.getBoolean(this, "isPurcheshOrNot", false)) {
                this.mSP.setBoolean(this, "isPurcheshOrNot", z);
            }
        } else if (!this.mSP.getBoolean(this, "isPurcheshOrNot", false)) {
            this.mSP.setBoolean(this, "isPurcheshOrNot", z);
        }
        if (this.mSP.getBoolean(this, "isPurcheshOrNot", false)) {
            this.rel_premium.setVisibility(View.GONE);
        }
    }

    private void loadData() {
        PurchaseHelper purchaseHelper = this.purchaseInAppHelper;
        if (purchaseHelper != null && purchaseHelper.isServiceConnected()) {
            this.purchaseInAppHelper.getPurchasedItems("inapp");
        } else {
            this.isPurchaseQueryPending = true;
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onWindowFocusChanged(boolean z) {
        Log.d(TAG, TAG + z);
        super.onWindowFocusChanged(z);
        if (this.camera_in_background || !z) {
            return;
        }
        initImmersiveMode();
    }
    @Override
    public void onPause() {
        Log.d(TAG, "onPause");
        System.currentTimeMillis();
        super.onPause();
        this.app_is_paused = true;
        this.mainUI.destroyPopup();
        this.mSensorManager.unregisterListener(this.accelerometerListener);
        this.magneticSensor.unregisterMagneticListener(this.mSensorManager);
        this.orientationEventListener.disable();
        try {
            unregisterReceiver(this.cameraReceiver);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
        this.bluetoothRemoteControl.stopRemoteControl();
        freeAudioListener(false);
        this.speechControl.stopSpeechRecognizer();
        this.applicationInterface.stopPanorama(true);
        this.applicationInterface.getGyroSensor().disableSensors();
        this.applicationInterface.getImageSaver().onPause();
        this.soundPoolManager.releaseSound();
        this.applicationInterface.clearLastImages();
        this.applicationInterface.getDrawPreview().clearGhostImage();
        this.preview.onPause();
        stopLocationUpdates();
        if (this.mMapView != null) {
            this.mMapView.onPause();
        }
        if (this.compass != null) {
            this.compass.stop();
        }
        cancelTimer();
    }
    private void stopLocationUpdates() {
        if (this.mGMap != null) {
            if (ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") != 0) {
                return;
            }
            this.mGMap.setMyLocationEnabled(false);
        }
        FusedLocationProviderClient fusedLocationProviderClient = this.fusedLocationClient;
        if (fusedLocationProviderClient != null) {
            fusedLocationProviderClient.removeLocationUpdates(this.mLocationCallback);
        }
    }


    @Override
    public void onStart() {
        super.onStart();
        SupportMapFragment supportMapFragment = this.mMapView;
        if (supportMapFragment != null) {
            supportMapFragment.onStart();
        }
    }


//    @Override
//    public void onStop() {
//        super.onStop();
//        Compass compass = this.compass;
//        if (compass != null) {
//            compass.stop();
//        }
//        SupportMapFragment supportMapFragment = this.mMapView;
//        if (supportMapFragment != null) {
//            supportMapFragment.onStop();
//        }
//        stopLocationUpdates();
//    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        SupportMapFragment supportMapFragment = this.mMapView;
        if (supportMapFragment != null) {
            supportMapFragment.onLowMemory();
        }
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        Log.d(TAG, "onConfigurationChanged()");
        this.preview.setCameraDisplayOrientation();
        super.onConfigurationChanged(configuration);
    }

    public void waitUntilImageQueueEmpty() {
        Log.d(TAG, "waitUntilImageQueueEmpty");
        this.applicationInterface.getImageSaver().waitUntilDone();
    }

    private boolean longClickedTakePhoto() {
        String str = TAG;
        Log.d(str, "longClickedTakePhoto");
        if (supportsFastBurst()) {
            CameraController.Size currentPictureSize = this.preview.getCurrentPictureSize();
            if (currentPictureSize != null && currentPictureSize.supports_burst) {
                MyApplicationInterface.PhotoMode photoMode = this.applicationInterface.getPhotoMode();
                if (photoMode == MyApplicationInterface.PhotoMode.Standard && this.applicationInterface.isRawOnly(photoMode)) {
                    Log.d(str, "fast burst not supported in RAW-only mode");
                } else if (photoMode == MyApplicationInterface.PhotoMode.Standard || photoMode == MyApplicationInterface.PhotoMode.FastBurst) {
                    takePicturePressed(false, true);
                    return true;
                }
            } else {
                Log.d(str, "fast burst not supported for this resolution");
            }
        } else {
            Log.d(str, "fast burst not supported");
        }
        return false;
    }

    public void clickedTakePhotoVideoSnapshot(View view) {
        Log.d(TAG, "clickedTakePhotoVideoSnapshot");
        takePicture(true);
    }

    public void clickedCancelPanorama(View view) {
        Log.d(TAG, "clickedCancelPanorama");
        this.applicationInterface.stopPanorama(true);
    }

    public void clickedCycleRaw(View view) {
        Log.d(TAG, "clickedCycleRaw");
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String str = "preference_raw_no";
        String string = defaultSharedPreferences.getString(PreferenceKeys.RawPreferenceKey, "preference_raw_no");
        string.hashCode();
        char c = 65535;
        switch (string.hashCode()) {
            case -1076775865:
                if (string.equals("preference_raw_only")) {
                    c = 0;
                    break;
                }
                break;
            case -866009364:
                if (string.equals("preference_raw_yes")) {
                    c = 1;
                    break;
                }
                break;
            case 664800540:
                if (string.equals("preference_raw_no")) {
                    c = 2;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                break;
            case 1:
                str = "preference_raw_only";
                break;
            case 2:
                str = "preference_raw_yes";
                break;
            default:
                Log.e(TAG, "unrecognised raw preference");
                str = null;
                break;
        }
        if (str != null) {
            SharedPreferences.Editor edit = defaultSharedPreferences.edit();
            edit.putString(PreferenceKeys.RawPreferenceKey, str);
            edit.apply();
            this.applicationInterface.getDrawPreview().updateSettings();
            this.preview.reopenCamera();
        }
    }

    public void refreshAdapter(int i, int i2, int i3) {
        this.ratio = Preview.getAspectRatio(i2, i3).split(":");

//        Log.d("RRRRR", "Ratio::" + ratio.toString() );

        if (!this.applicationInterface.getFocusPref(false).equals("focus_mode_auto")) {
            this.mImg_focus.setColorFilter(getResources().getColor(R.color._ffcc00));
        } else {
            this.mImg_focus.setColorFilter(getResources().getColor(R.color.white));
        }
    }

    public void updateForSettings() {
        updateForSettings(null, false);
    }

    public void updateForSettings(String str) {
        updateForSettings(str, false);
    }

    public void updateForSettings(String str, boolean z) {
        boolean z2;
        CameraController.TonemapProfile tonemapProfile;
        CameraController.TonemapProfile videoTonemapProfile;
        Log.d(TAG, "updateForSettings()");
        if (str != null) {
            Log.d(TAG, "toast_message: " + str);
        }
        long currentTimeMillis = System.currentTimeMillis();
        Log.d(TAG, "update folder history");
        this.save_location_history.updateFolderHistory(getStorageUtils().getSaveLocation(), true);
        Log.d(TAG, "updateForSettings: time after update folder history: " + (System.currentTimeMillis() - currentTimeMillis));
        imageQueueChanged();
        if (!z) {
            this.mainUI.destroyPopup();
            Log.d(TAG, "updateForSettings: time after destroy popup: " + (System.currentTimeMillis() - currentTimeMillis));
        }
        if (this.preview.getCameraController() != null) {
            SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            String sceneMode = this.preview.getCameraController().getSceneMode();
            Log.d(TAG, "" + sceneMode);
            String string = defaultSharedPreferences.getString(PreferenceKeys.SceneModePreferenceKey, "auto");
            if (!string.equals(sceneMode)) {
                Log.d(TAG, "scene mode changed to: " + string);
            } else {
                if (this.applicationInterface.useCamera2()) {
                    boolean useCamera2FakeFlash = this.preview.getCameraController().getUseCamera2FakeFlash();
                    Log.d(TAG, "camera2_fake_flash was: " + useCamera2FakeFlash);
                    if (this.applicationInterface.useCamera2FakeFlash() != useCamera2FakeFlash) {
                        Log.d(TAG, "camera2_fake_flash changed");
                    }
                }
                z2 = false;
                if (!z2 && (tonemapProfile = this.preview.getCameraController().getTonemapProfile()) != CameraController.TonemapProfile.TONEMAPPROFILE_OFF && (videoTonemapProfile = this.applicationInterface.getVideoTonemapProfile()) != CameraController.TonemapProfile.TONEMAPPROFILE_OFF && videoTonemapProfile != tonemapProfile) {
                    Log.d(TAG, "switching between tonemap profiles");
                    z2 = true;
                }
            }
            z2 = true;
            if (!z2) {
                Log.d(TAG, "switching between tonemap profiles");
                z2 = true;
            }
        } else {
            z2 = false;
        }
        Log.d(TAG, "updateForSettings: time after check need_reopen: " + (System.currentTimeMillis() - currentTimeMillis));
        this.mainUI.layoutUI();
        Log.d(TAG, "updateForSettings: time after layoutUI: " + (System.currentTimeMillis() - currentTimeMillis));
        checkDisableGUIIcons();
        this.speechControl.initSpeechRecognizer();
        initGyroSensors();
        Log.d(TAG, "updateForSettings: time after init speech and location: " + (System.currentTimeMillis() - currentTimeMillis));
        if (str != null) {
            if (z2 || this.preview.getCameraController() == null) {
                this.preview.reopenCamera();
                Log.d(TAG, "updateForSettings: time after reopen: " + (System.currentTimeMillis() - currentTimeMillis));
            } else {
                this.preview.setCameraDisplayOrientation();
                Log.d(TAG, "updateForSettings: time after set display orientation: " + (System.currentTimeMillis() - currentTimeMillis));
                this.preview.pausePreview(true);
                Log.d(TAG, "updateForSettings: time after pause: " + (System.currentTimeMillis() - currentTimeMillis));
                this.preview.setupCamera(false);
                Log.d(TAG, "updateForSettings: time after setup: " + (System.currentTimeMillis() - currentTimeMillis));
            }
        }
        if (str != null && str.length()>0) {
            this.preview.showToast((ToastBoxer) null, str);
        }
        this.magneticSensor.registerMagneticListener(this.mSensorManager);
        this.magneticSensor.checkMagneticAccuracy();
        Log.d(TAG, "updateForSettings: done: " + (System.currentTimeMillis() - currentTimeMillis));
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        Preview preview = this.preview;
        if (preview != null && preview.isPreviewPaused()) {
            Log.d(TAG, "preview was paused, so unpause it");
            this.preview.startCameraPreview();
        } else if (getSupportFragmentManager().getBackStackEntryCount()>0) {
            OnBackPressedListener onBackPressedListener = this.onBackPressedListener;
            if (onBackPressedListener != null) {
                onBackPressedListener.onBackPressed();
            }
        } else if (this.mDrawerLayout.isDrawerOpen(3)) {
            closeDrawer();
        } else if (this.ll_filterview.getVisibility() == 0) {
            slideright(this.ll_filterview);
            slideleft(this.rl_btn_layout);
            slideleft(this.rel_camera_mode);
        } else {
            Default.ISEXITNATIVE = this.mSP.getInteger(this, SP.ISEXITNATIVE, 2);
            boolean z = new SP(this).getBoolean(this, "isPurcheshOrNot", false);
            if (Default.ISEXITNATIVE == 1 && NetworkState.Companion.isOnline(this) && !z) {
                showExitDialog();
            } else if (this.doubleBackToExitPressedOnce) {
                System.gc();
                super.onBackPressed();
            } else {
                this.doubleBackToExitPressedOnce = true;
                Snackbar.make(findViewById(R.id.rl_camera_view_main), " ", -1).show();
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.live.gpsmap.camera.Camera.MainActivity.63
                    @Override
                    public void run() {
                        CameraMainActivity.this.doubleBackToExitPressedOnce = false;
                    }
                }, 3000L);
            }
        }
    }

    private void showExitDialog() {
        AlertDialog alertDialog = this.exitDialog;
        if (alertDialog == null) {
            this.exitDialog = new AlertDialog.Builder(this, R.style.RoundedCornersDialog).setCancelable(false).setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public final void onDismiss(DialogInterface dialogInterface) {
                    CameraMainActivity.this.m402xe76f390a(dialogInterface);
                }
            }).create();
        } else {
            alertDialog.show();
        }
        WindowManager.LayoutParams attributes = this.exitDialog.getWindow().getAttributes();
        attributes.dimAmount = 0.75f;
        this.exitDialog.getWindow().setAttributes(attributes);
//        if (AdsUtils.Companion.getAdLoaded()) {
//            return;
//        }
        refreshNative();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$showExitDialog$1$com-gpsmapcamera-geotagginglocationonphoto-Camera-MainActivity  reason: not valid java name */
    public /* synthetic */ void m402xe76f390a(DialogInterface dialogInterface) {
        if (this.doExit) {
            finishAffinity();
        } else {
            refreshNative();
        }
    }

    private void setUpExitDialog() {
        if (this.exitDialog == null) {
            this.exitDialog = new AlertDialog.Builder(this, R.style.RoundedCornersDialogExit).setCancelable(false).setOnKeyListener(new DialogInterface.OnKeyListener() { // from class: com.live.gpsmap.camera.Camera.MainActivity.64
                @Override // android.content.DialogInterface.OnKeyListener
                public boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
                    if (i == 4) {
                        keyEvent.getAction();
                        return false;
                    }
                    return false;
                }
            }).setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.live.gpsmap.camera.Camera.MainActivity$$ExternalSyntheticLambda2
                @Override // android.content.DialogInterface.OnDismissListener
                public final void onDismiss(DialogInterface dialogInterface) {
                    CameraMainActivity.this.m399x38487f63(dialogInterface);
                }
            }).create();
        }
        this.doExit = false;
        this.exitDialogBinding.btnNo.setOnClickListener(new View.OnClickListener() { // from class: com.live.gpsmap.camera.Camera.MainActivity$$ExternalSyntheticLambda3
            @Override
            public final void onClick(View view) {
                CameraMainActivity.this.m400xb6a98342(view);
            }
        });
        this.exitDialogBinding.btnYes.setOnClickListener(new View.OnClickListener() { // from class: com.live.gpsmap.camera.Camera.MainActivity$$ExternalSyntheticLambda4
            @Override
            public final void onClick(View view) {
                CameraMainActivity.this.m401x350a8721(view);
            }
        });
    }

    public /* synthetic */ void m399x38487f63(DialogInterface dialogInterface) {
        if (this.doExit) {
            finish();
        } else {
            refreshNative();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$setUpExitDialog$3$com-gpsmapcamera-geotagginglocationonphoto-Camera-MainActivity  reason: not valid java name */
    public /* synthetic */ void m400xb6a98342(View view) {
        this.exitDialog.dismiss();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$setUpExitDialog$4$com-gpsmapcamera-geotagginglocationonphoto-Camera-MainActivity  reason: not valid java name */
    public /* synthetic */ void m401x350a8721(View view) {
        this.doExit = true;
        this.exitDialog.dismiss();
    }

    private void refreshNative() {
//        try {
//            if (NetworkState.Companion.isOnline(this)) {
//                AdsUtils.Companion.loadNative(this, getResources().getString(R.string.exit_native_id), this.exitDialogBinding.adFrame, this.exitDialogBinding.pbNative);
//            }
//            AlertDialog alertDialog = this.exitDialog;
//            if (alertDialog != null) {
//                alertDialog.setView(this.exitDialogBinding.getRoot());
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }

    private void dissmissDialog() {
        Util.dismissProgressDialog();
    }

    private void cancelTimer() {
        Util.dismissProgressDialog();
    }

    public boolean usingKitKatImmersiveMode() {
        if (Build.VERSION.SDK_INT>=19) {
            String string = PreferenceManager.getDefaultSharedPreferences(this).getString(PreferenceKeys.ImmersiveModePreferenceKey, "immersive_mode_low_profile");
            return string.equals("immersive_mode_gui") || string.equals("immersive_mode_everything");
        }
        return false;
    }

    public boolean usingKitKatImmersiveModeEverything() {
        return Build.VERSION.SDK_INT>=19 && PreferenceManager.getDefaultSharedPreferences(this).getString(PreferenceKeys.ImmersiveModePreferenceKey, "immersive_mode_low_profile").equals("immersive_mode_everything");
    }

    private void setImmersiveTimer() {
        Runnable runnable;
        Handler handler = this.immersive_timer_handler;
        if (handler != null && (runnable = this.immersive_timer_runnable) != null) {
            handler.removeCallbacks(runnable);
        }
        Handler handler2 = new Handler();
        this.immersive_timer_handler = handler2;
        Runnable runnable2 = new Runnable() {
            @Override
            public void run() {
                Log.d(CameraMainActivity.TAG, "setImmersiveTimer: run");
                if (CameraMainActivity.this.camera_in_background || !CameraMainActivity.this.usingKitKatImmersiveMode()) {
                    return;
                }
                CameraMainActivity.this.setImmersiveMode(true);
            }
        };
        this.immersive_timer_runnable = runnable2;
        handler2.postDelayed(runnable2, 5000L);
    }

    public void initImmersiveMode() {
        if (!usingKitKatImmersiveMode()) {
            setImmersiveMode(true);
        } else {
            setImmersiveTimer();
        }
    }

    public void setImmersiveMode(boolean z) {
        Log.d(TAG, "setImmersiveMode: " + z);
        if (z) {
            return;
        }
        getWindow().getDecorView().setSystemUiVisibility(0);
    }

    public void setBrightnessForCamera(boolean z) {
        Log.d(TAG, "setBrightnessForCamera");
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        final WindowManager.LayoutParams attributes = getWindow().getAttributes();
        if (z || defaultSharedPreferences.getBoolean(PreferenceKeys.MaxBrightnessPreferenceKey, false)) {
            attributes.screenBrightness = 1.0f;
        } else {
            attributes.screenBrightness = -1.0f;
        }
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                CameraMainActivity.this.getWindow().setAttributes(attributes);
            }
        });
    }

    public void setBrightnessToMinimumIfWanted() {
        Log.d(TAG, "setBrightnessToMinimum");
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        final WindowManager.LayoutParams attributes = getWindow().getAttributes();
        if (defaultSharedPreferences.getBoolean(PreferenceKeys.DimWhenDisconnectedPreferenceKey, false)) {
            attributes.screenBrightness = 0.0f;
        } else {
            attributes.screenBrightness = -1.0f;
        }
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                CameraMainActivity.this.getWindow().setAttributes(attributes);
            }
        });
    }

    public void setWindowFlagsForCamera() {
        MainUI mainUI;
        Log.d(TAG, "setWindowFlagsForCamera");
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        setRequestedOrientation(1);
        Preview preview = this.preview;
        if (preview != null) {
            preview.setCameraDisplayOrientation();
        }
        if (this.preview != null && (mainUI = this.mainUI) != null) {
            mainUI.layoutUI();
        }
        if (defaultSharedPreferences.getBoolean(PreferenceKeys.KeepDisplayOnPreferenceKey, true)) {
            Log.d(TAG, "do keep screen on");
            getWindow().addFlags(128);
        } else {
            Log.d(TAG, "don't keep screen on");
            getWindow().clearFlags(128);
        }
        if (defaultSharedPreferences.getBoolean(PreferenceKeys.ShowWhenLockedPreferenceKey, false)) {
            showWhenLocked(false);
        } else {
            showWhenLocked(false);
        }
        setBrightnessForCamera(false);
        initImmersiveMode();
        this.camera_in_background = false;
        this.magneticSensor.clearDialog();
    }

    private void setWindowFlagsForSettings() {
        setWindowFlagsForSettings(true);
    }

    public void setWindowFlagsForSettings(boolean z) {
        Log.d(TAG, "setWindowFlagsForSettings: " + z);
        setRequestedOrientation(-1);
        getWindow().clearFlags(128);
        if (z) {
            showWhenLocked(false);
        }
        WindowManager.LayoutParams attributes = getWindow().getAttributes();
        attributes.screenBrightness = -1.0f;
        getWindow().setAttributes(attributes);
        setImmersiveMode(false);
        this.camera_in_background = true;
    }

    private void showWhenLocked(boolean z) {
        Log.d(TAG, "showWhenLocked: " + z);
        if (z) {
            getWindow().addFlags(524288);
        } else {
            getWindow().clearFlags(524288);
        }
    }

    public void showAlert(final AlertDialog alertDialog) {
        Log.d(TAG, "showAlert");
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                alertDialog.show();
            }
        }, 20L);
    }

    public void showPreview(boolean z) {
        Log.d(TAG, "showPreview: " + z);
    }

    public void updateGalleryIconToBlank() {
        Log.d(TAG, "updateGalleryIconToBlank");
        ImageView imageView = (ImageView) findViewById(R.id.img_gallery);
        int paddingBottom = imageView.getPaddingBottom();
        int paddingTop = imageView.getPaddingTop();
        int paddingRight = imageView.getPaddingRight();
        int paddingLeft = imageView.getPaddingLeft();
        imageView.setImageBitmap(null);
        imageView.setImageResource(R.drawable.ic_gallery);
        imageView.setPadding(paddingLeft, paddingTop, paddingRight, paddingBottom);
        this.gallery_bitmap = null;
    }

    private Bitmap loadThumbnailFromUri(Uri uri0, int v, boolean z) {
        Bitmap bitmap0 = null;
        try {
            BitmapFactory.Options bitmapFactory$Options0 = new BitmapFactory.Options();
            InputStream inputStream0 = this.getContentResolver().openInputStream(uri0);
            bitmapFactory$Options0.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(inputStream0, null, bitmapFactory$Options0);
            int v1 = bitmapFactory$Options0.outWidth;
            int v2 = bitmapFactory$Options0.outHeight;
            Point point0 = new Point();
            this.getWindowManager().getDefaultDisplay().getSize(point0);
            Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "bitmap_width: " + v1);
            Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "bitmap_height: " + v2);
            Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "display width: " + point0.x);
            Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "display height: " + point0.y);
            if (point0.x<point0.y) {
                point0.set(point0.y, point0.x);
            }

            if (v1<v2) {
                int v3 = v2;
                v2 = v1;
                v1 = v3;
            }

            Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "bitmap_width: " + v1);
            Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "bitmap_height: " + v2);
            Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "display width: " + point0.x);
            Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "display height: " + point0.y);
            bitmapFactory$Options0.inSampleSize = 1;
            while (v2 / (bitmapFactory$Options0.inSampleSize * 2)>=point0.y) {
                bitmapFactory$Options0.inSampleSize *= 2;
            }

            bitmapFactory$Options0.inSampleSize *= v;
            Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "inSampleSize: " + bitmapFactory$Options0.inSampleSize);
            bitmapFactory$Options0.inJustDecodeBounds = false;
            inputStream0.close();
            InputStream inputStream1 = this.getContentResolver().openInputStream(uri0);
            bitmap0 = BitmapFactory.decodeStream(inputStream1, null, bitmapFactory$Options0);
            if (bitmap0 == null) {
                Log.e("com.gpsvideocamera.videotimestamp.CameraActivity", "decodeStream returned null bitmap for ghost image last");
            }

            inputStream1.close();
            if (!z) {
                return this.rotateForExif(bitmap0, uri0);
            }
        } catch (IOException iOException0) {
            Log.e("com.gpsvideocamera.videotimestamp.CameraActivity", "failed to load bitmap for ghost image last");
            iOException0.printStackTrace();
            return bitmap0;
        }

        return bitmap0;
    }


    public Bitmap rotateForExif(Bitmap bitmap0, Uri uri0) throws IOException {
        ExifInterface exifInterface0;
        InputStream inputStream0 = null;
        try {
            inputStream0 = this.getContentResolver().openInputStream(uri0);
            exifInterface0 = new ExifInterface(inputStream0);
        } catch (Throwable throwable0) {
            if (inputStream0 != null) {
                inputStream0.close();
            }

            throw throwable0;
        }

        if (inputStream0 != null) {
            inputStream0.close();
        }

        int v = 0;
        int v1 = exifInterface0.getAttributeInt("Orientation", 0);
        int v2 = 1;
        if (v1 != 0 && v1 != 1) {
            switch (v1) {
                case 3: {
                    v = 180;
                    break;
                }
                case 6: {
                    v = 90;
                    break;
                }
                case 8: {
                    v = 270;
                    break;
                }
                default: {
                    Log.e("com.gpsvideocamera.videotimestamp.CameraActivity", "    unsupported exif orientation: " + v1);
                    v2 = 0;
                }
            }
        } else {
            v2 = 0;
        }

        Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "    exif orientation: " + v);
        if (v2 != 0) {
            Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", ":::" + v2);
            Matrix matrix0 = new Matrix();
            matrix0.setRotate(((float) v), ((float) bitmap0.getWidth()) * 0.5f, ((float) bitmap0.getHeight()) * 0.5f);
            Bitmap bitmap1 = Bitmap.createBitmap(bitmap0, 0, 0, bitmap0.getWidth(), bitmap0.getHeight(), matrix0, true);
            if (bitmap1 != bitmap0) {
                bitmap0.recycle();
                return bitmap1;
            }
        }

        return bitmap0;
    }

    public void updateGalleryIcon(Bitmap bitmap) {
        Log.d(TAG, "updateGalleryIcon: " + bitmap);
        ((ImageView) findViewById(R.id.img_gallery)).setImageBitmap(bitmap);
        this.gallery_bitmap = bitmap;
    }


    /**
     * Updates the gallery icon by searching for the most recent photo.
     * Launches the task in a separate thread.
     */
    public void updateGalleryIcon() {
        long debug_time = 0;
        if (MyDebug.LOG) {
            Log.d(TAG, "updateGalleryIcon");
            debug_time = System.currentTimeMillis();
        }

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String ghost_image_pref = sharedPreferences.getString(PreferenceKeys.GhostImagePreferenceKey, "preference_ghost_image_off");
        final boolean ghost_image_last = ghost_image_pref.equals("preference_ghost_image_last");
        new AsyncTask<Void, Void, Bitmap>() {
            private static final String TAG = "MainActivity/AsyncTask";
            private boolean is_video;

            /** The system calls this to perform work in a worker thread and
             * delivers it the parameters given to AsyncTask.execute() */
            protected Bitmap doInBackground(Void... params) {
                if (MyDebug.LOG) Log.d(TAG, "doInBackground");
                StorageUtils.Media media = applicationInterface.getStorageUtils().getLatestMedia();
                Bitmap thumbnail = null;
                KeyguardManager keyguard_manager = (KeyguardManager) CameraMainActivity.this.getSystemService(Context.KEYGUARD_SERVICE);
                boolean is_locked = keyguard_manager != null && keyguard_manager.inKeyguardRestrictedInputMode();
                if (MyDebug.LOG) Log.d(TAG, "is_locked?: " + is_locked);
                if (media != null && getContentResolver() != null && !is_locked) {
                    // check for getContentResolver() != null, as have had reported Google Play crashes
                    if (ghost_image_last && !media.video) {
                        if (MyDebug.LOG)
                            Log.d(TAG, "load full size bitmap for ghost image last photo");
                        try {
                            //thumbnail = MediaStore.Images.Media.getBitmap(getContentResolver(), media.uri);
                            // only need to load a bitmap as large as the screen size
                            BitmapFactory.Options options = new BitmapFactory.Options();
                            InputStream is = getContentResolver().openInputStream(media.uri);
                            // get dimensions
                            options.inJustDecodeBounds = true;
                            BitmapFactory.decodeStream(is, null, options);
                            int bitmap_width = options.outWidth;
                            int bitmap_height = options.outHeight;
                            Point display_size = new Point();
                            Display display = getWindowManager().getDefaultDisplay();
                            display.getSize(display_size);
                            if (MyDebug.LOG) {
                                Log.d(TAG, "bitmap_width: " + bitmap_width);
                                Log.d(TAG, "bitmap_height: " + bitmap_height);
                                Log.d(TAG, "display width: " + display_size.x);
                                Log.d(TAG, "display height: " + display_size.y);
                            }
                            // align dimensions
                            if (display_size.x<display_size.y) {
                                display_size.set(display_size.y, display_size.x);
                            }
                            if (bitmap_width<bitmap_height) {
                                int dummy = bitmap_width;
                                bitmap_width = bitmap_height;
                                bitmap_height = dummy;
                            }
                            if (MyDebug.LOG) {
                                Log.d(TAG, "bitmap_width: " + bitmap_width);
                                Log.d(TAG, "bitmap_height: " + bitmap_height);
                                Log.d(TAG, "display width: " + display_size.x);
                                Log.d(TAG, "display height: " + display_size.y);
                            }
                            // only care about height, to save worrying about different aspect ratios
                            options.inSampleSize = 1;
                            while (bitmap_height / (2 * options.inSampleSize)>=display_size.y) {
                                options.inSampleSize *= 2;
                            }
                            if (MyDebug.LOG) {
                                Log.d(TAG, "inSampleSize: " + options.inSampleSize);
                            }
                            options.inJustDecodeBounds = false;
                            // need a new inputstream, see https://stackoverflow.com/questions/2503628/bitmapfactory-decodestream-returning-null-when-options-are-set
                            is.close();
                            is = getContentResolver().openInputStream(media.uri);
                            thumbnail = BitmapFactory.decodeStream(is, null, options);
                            if (thumbnail == null) {
                                Log.e(TAG, "decodeStream returned null bitmap for ghost image last");
                            }
                            is.close();
                        } catch (IOException e) {
                            Log.e(TAG, "failed to load bitmap for ghost image last");
                            e.printStackTrace();
                        }
                    }
                    if (thumbnail == null) {
                        try {
                            if (media.video) {
                                if (MyDebug.LOG) Log.d(TAG, "load thumbnail for video");
                                thumbnail = MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), media.id, MediaStore.Video.Thumbnails.MINI_KIND, null);
                                is_video = true;
                            } else {
                                if (MyDebug.LOG) Log.d(TAG, "load thumbnail for photo");
                                thumbnail = MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(), media.id, MediaStore.Images.Thumbnails.MINI_KIND, null);
                            }
                        } catch (Throwable exception) {
                            // have had Google Play NoClassDefFoundError crashes from getThumbnail() for Galaxy Ace4 (vivalto3g), Galaxy S Duos3 (vivalto3gvn)
                            // also NegativeArraySizeException - best to catch everything
                            if (MyDebug.LOG) Log.e(TAG, "exif orientation exception");
                            exception.printStackTrace();
                        }
                    }
                    if (thumbnail != null) {
                        if (media.orientation != 0) {
                            if (MyDebug.LOG)
                                Log.d(TAG, "thumbnail size is " + thumbnail.getWidth() + " x " + thumbnail.getHeight());
                            Matrix matrix = new Matrix();
                            matrix.setRotate(media.orientation, thumbnail.getWidth() * 0.5f, thumbnail.getHeight() * 0.5f);
                            try {
                                Bitmap rotated_thumbnail = Bitmap.createBitmap(thumbnail, 0, 0, thumbnail.getWidth(), thumbnail.getHeight(), matrix, true);
                                // careful, as rotated_thumbnail is sometimes not a copy!
                                if (rotated_thumbnail != thumbnail) {
                                    thumbnail.recycle();
                                    thumbnail = rotated_thumbnail;
                                }
                            } catch (Throwable t) {
                                if (MyDebug.LOG) Log.d(TAG, "failed to rotate thumbnail");
                            }
                        }
                    }
                }
                return thumbnail;
            }

            /** The system calls this to perform work in the UI thread and delivers
             * the result from doInBackground() */
            protected void onPostExecute(Bitmap thumbnail) {
                if (MyDebug.LOG) Log.d(TAG, "onPostExecute");
                // since we're now setting the thumbnail to the latest media on disk, we need to make sure clicking the Gallery goes to this
                applicationInterface.getStorageUtils().clearLastMediaScanned();
                if (thumbnail != null) {
                    if (MyDebug.LOG) Log.d(TAG, "set gallery button to thumbnail");
                    updateGalleryIcon(thumbnail);
                    applicationInterface.getDrawPreview().updateThumbnail(thumbnail, is_video, false); // needed in case last ghost image is enabled
                } else {
                    if (MyDebug.LOG) Log.d(TAG, "set gallery button to blank");
                    updateGalleryIconToBlank();
                }
            }
        }.execute();

        if (MyDebug.LOG)
            Log.d(TAG, "updateGalleryIcon: total time to update gallery icon: " + (System.currentTimeMillis() - debug_time));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void savingImage(final boolean z) {
        Log.d(TAG, "savingImage: " + z);
        runOnUiThread(new Runnable() { // from class: com.live.gpsmap.camera.Camera.MainActivity.70
            @Override
            public void run() {
                final ImageView imageView = (ImageView) CameraMainActivity.this.findViewById(R.id.img_gallery);
                if (z) {
                    imageView.setColorFilter(-2130706433, PorterDuff.Mode.MULTIPLY);
                    if (CameraMainActivity.this.gallery_save_anim == null) {
                        CameraMainActivity.this.gallery_save_anim = ValueAnimator.ofInt(Color.argb(200, 255, 255, 255), Color.argb(63, 255, 255, 255));
                        CameraMainActivity.this.gallery_save_anim.setEvaluator(new ArgbEvaluator());
                        CameraMainActivity.this.gallery_save_anim.setRepeatCount(-1);
                        CameraMainActivity.this.gallery_save_anim.setRepeatMode(2);
                        CameraMainActivity.this.gallery_save_anim.setDuration(500L);
                    }
                    CameraMainActivity.this.gallery_save_anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.live.gpsmap.camera.Camera.MainActivity.70.1
                        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                        public void onAnimationUpdate(ValueAnimator valueAnimator) {
                            imageView.setColorFilter(((Integer) valueAnimator.getAnimatedValue()).intValue(), PorterDuff.Mode.MULTIPLY);
                        }
                    });
                    CameraMainActivity.this.gallery_save_anim.start();
                } else if (CameraMainActivity.this.gallery_save_anim != null) {
                    CameraMainActivity.this.gallery_save_anim.cancel();
                    imageView.setColorFilter((ColorFilter) null);
                }
            }
        });
    }

    public void imageQueueChanged() {
        Log.d(TAG, "imageQueueChanged");
        this.applicationInterface.getDrawPreview().setImageQueueFull(!this.applicationInterface.canTakeNewPhoto());
        if (this.applicationInterface.getImageSaver().getNImagesToSave() == 0) {
            cancelImageSavingNotification();
        }
    }

    public void clickedGallery(View view) {
        Log.d(TAG, "clickedGallery");
        openGallery();
    }

    @SuppressWarnings("deprecation")
    public long freeMemory() {
        if (MyDebug.LOG) Log.d(TAG, "freeMemory");
        try {
            File folder = applicationInterface.getStorageUtils().getImageFolder();
            if (folder == null) {
                throw new IllegalArgumentException(); // so that we fall onto the backup
            }
            StatFs statFs = new StatFs(folder.getAbsolutePath());
            // cast to long to avoid overflow!
            long blocks = statFs.getAvailableBlocks();
            long size = statFs.getBlockSize();
            return (blocks * size) / 1048576;
        } catch (IllegalArgumentException e) {
            // this can happen if folder doesn't exist, or don't have read access
            // if the save folder is a subfolder of DCIM, we can just use that instead
            try {
                if (!applicationInterface.getStorageUtils().isUsingSAF()) {
                    // StorageUtils.getSaveLocation() only valid if !isUsingSAF()
                    String folder_name = applicationInterface.getStorageUtils().getSaveLocation();
                    if (!folder_name.startsWith("/")) {
                        File folder = StorageUtils.getBaseFolder();
                        StatFs statFs = new StatFs(folder.getAbsolutePath());
                        // cast to long to avoid overflow!
                        long blocks = statFs.getAvailableBlocks();
                        long size = statFs.getBlockSize();
                        return (blocks * size) / 1048576;
                    }
                }
            } catch (IllegalArgumentException e2) {
                // just in case
            }
        }
        return -1;
    }

    private void openGallery() {
        int v1;
        Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "openGallery");
        Uri uri0 = this.applicationInterface.getStorageUtils().getLastMediaScanned();
        int v = 1;
        if (uri0 == null) {
            Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "go to latest media");
            StorageUtils.Media storageUtils$Media0 = this.applicationInterface.getStorageUtils().getLatestMedia();
            if (storageUtils$Media0 == null) {
                v1 = 0;
            } else {
                Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "latest uri:" + storageUtils$Media0.uri);
                uri0 = storageUtils$Media0.getMediaStoreUri(this);
                Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "media uri:" + uri0);
                v1 = storageUtils$Media0.filename != null && (storageUtils$Media0.filename.toLowerCase(Locale.US).endsWith(".dng")) ? 1 : 0;
            }
        } else {
            v1 = 0;
        }

        if (uri0 != null && !CameraMainActivity.useScopedStorage()) {
            Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "found most recent uri: " + uri0);
//            Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "is_raw: " + ((boolean) v1));
            try {
                ParcelFileDescriptor parcelFileDescriptor0 = this.getContentResolver().openFileDescriptor(uri0, "r");
                if (parcelFileDescriptor0 == null) {
                    Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "uri no longer exists (1): " + uri0);
                    uri0 = null;
                } else {
                    parcelFileDescriptor0.close();
                }

                if (uri0 == null) {
                    uri0 = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    v1 = 0;
                }
            } catch (IOException unused_ex) {
                Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "uri no longer exists (2): " + uri0);
            }


            v1 = 0;
        }


        if (!this.is_test) {
            Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "launch uri:" + uri0);
            if (v1 == 0) {
                Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "try REVIEW_ACTION");
                try {
                    Intent intent0 = new Intent("com.android.camera.action.REVIEW", uri0);
                    try {

                        this.startActivity(intent0);
                    } catch (Exception unused_ex) {
                        Intent intent1 = new Intent("android.intent.action.VIEW", uri0);

                        this.startActivity(intent1);
                        if (intent1.resolveActivity(this.getPackageManager()) == null) {
                            this.preview.showToast(null, R.string.img_not_available);  // string:img_not_available "Image not available"
                            if (v == 0) {
                                Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "try ACTION_VIEW");
                                Intent intent2 = new Intent("android.intent.action.VIEW", uri0);
                                if (intent2.resolveActivity(this.getPackageManager()) != null) {
                                    try {

                                        this.startActivity(intent2);
                                    } catch (SecurityException securityException0) {
                                        Log.e("com.gpsvideocamera.videotimestamp.CameraActivity", "SecurityException from ACTION_VIEW startActivity");
                                        securityException0.printStackTrace();
                                    }

                                    return;
                                }

                                this.preview.showToast(null, R.string.no_gallery_app);  // string:no_gallery_app "No gallery app available"
                            }

                            unused_ex.printStackTrace();
                            v = 0;
                        }

                    }
                } catch (ActivityNotFoundException activityNotFoundException0) {
                    activityNotFoundException0.printStackTrace();
                }
            } else {
                v = 0;
            }
        }
    }

    public void openFolderChooserDialogSAF(boolean z) {
        Log.d(TAG, "openFolderChooserDialogSAF: " + z);
        this.saf_dialog_from_preferences = z;

        startActivityForResult(new Intent("android.intent.action.OPEN_DOCUMENT_TREE"), 42);
    }

    public void openGhostImageChooserDialogSAF(boolean z) {
        Log.d(TAG, "openGhostImageChooserDialogSAF: " + z);
        this.saf_dialog_from_preferences = z;
        Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT");
        intent.addCategory("android.intent.category.OPENABLE");
        intent.setType("image/*");
        try {

            startActivityForResult(intent, 43);
        } catch (ActivityNotFoundException e) {
            Log.e(TAG, "ActivityNotFoundException from startActivityForResult");
            e.printStackTrace();
        }
    }

    public void updateFolderHistorySAF(String str) {
        Log.d(TAG, "updateSaveHistorySAF");
        if (this.save_location_history_saf == null) {
            this.save_location_history_saf = new SaveLocationHistory(this, "save_location_history_saf", str);
        }
        this.save_location_history_saf.updateFolderHistory(str, true);
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        Log.d(TAG, "onActivityResult: " + i);
        if (i == 1) {
            if (i2 == 0) {
                this.isPermission++;
                return;
            } else if (i2 == -1) {
                this.isPermission = 0;
                return;
            } else {
                return;
            }
        }
        switch (i) {
            case 42:
                Log.d(":::sd_card:::", "returned_treeUri: " + intent);
                if (i2 == -1 && intent != null) {
                    Uri data = intent.getData();
                    try {
                        getContentResolver().takePersistableUriPermission(data, intent.getFlags() & 3);
                        SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(this).edit();
                        edit.putString(PreferenceKeys.SaveLocationSAFPreferenceKey, data.toString());
                        edit.apply();
                        setSdCardPermissionFlag(true);
                        Log.e(":::sd_card:::", "update folder history for saf");
                        updateFolderHistorySAF(data.toString());
                        return;
                    } catch (SecurityException e) {
                        Log.e(TAG, "SecurityException failed to take permission");
                        e.printStackTrace();
                        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
                        if (defaultSharedPreferences.getString(PreferenceKeys.SaveLocationSAFPreferenceKey, "").length() == 0) {
                            Log.d(TAG, "no SAF save location was set");
                            SharedPreferences.Editor edit2 = defaultSharedPreferences.edit();
                            edit2.putBoolean(PreferenceKeys.UsingSAFPreferenceKey, false);
                            edit2.apply();
                            return;
                        }
                        return;
                    }
                }
                Log.d(TAG, "SAF dialog cancelled");
                SharedPreferences defaultSharedPreferences2 = PreferenceManager.getDefaultSharedPreferences(this);
                if (defaultSharedPreferences2.getString(PreferenceKeys.SaveLocationSAFPreferenceKey, "").length() == 0) {
                    Log.d(TAG, "no SAF save location was set");
                    SharedPreferences.Editor edit3 = defaultSharedPreferences2.edit();
                    edit3.putBoolean(PreferenceKeys.UsingSAFPreferenceKey, false);
                    edit3.apply();
                    setSdCardPermissionFlag(false);
                    Log.e(":::TyTyTy:::", "onActivityResult: ");
                    return;
                }
                return;
            case 43:
                if (i2 == -1 && intent != null) {
                    Uri data2 = intent.getData();
                    Log.d(TAG, "returned single fileUri: " + data2);
                    try {
                        getContentResolver().takePersistableUriPermission(data2, intent.getFlags() & 3);
                        SharedPreferences.Editor edit4 = PreferenceManager.getDefaultSharedPreferences(this).edit();
                        edit4.putString(PreferenceKeys.GhostSelectedImageSAFPreferenceKey, data2.toString());
                        edit4.apply();
                    } catch (SecurityException e2) {
                        Log.e(TAG, "SecurityException failed to take permission");
                        e2.printStackTrace();
                        SharedPreferences defaultSharedPreferences3 = PreferenceManager.getDefaultSharedPreferences(this);
                        if (defaultSharedPreferences3.getString(PreferenceKeys.GhostSelectedImageSAFPreferenceKey, "").length() == 0) {
                            Log.d(TAG, "no SAF ghost image was set");
                            SharedPreferences.Editor edit5 = defaultSharedPreferences3.edit();
                            edit5.putString(PreferenceKeys.GhostImagePreferenceKey, "preference_ghost_image_off");
                            edit5.apply();
                        }
                    }
                } else {
                    Log.d(TAG, "SAF dialog cancelled");
                    SharedPreferences defaultSharedPreferences4 = PreferenceManager.getDefaultSharedPreferences(this);
                    if (defaultSharedPreferences4.getString(PreferenceKeys.GhostSelectedImageSAFPreferenceKey, "").length() == 0) {
                        Log.d(TAG, "no SAF ghost image was set");
                        SharedPreferences.Editor edit6 = defaultSharedPreferences4.edit();
                        edit6.putString(PreferenceKeys.GhostImagePreferenceKey, "preference_ghost_image_off");
                        edit6.apply();
                    }
                }
                if (this.saf_dialog_from_preferences) {
                    return;
                }
                setWindowFlagsForCamera();
                showPreview(true);
                return;
            case 44:
                if (i2 == -1 && intent != null) {
                    Uri data3 = intent.getData();
                    Log.d(TAG, "returned single fileUri: " + data3);
                    try {
                        getContentResolver().takePersistableUriPermission(data3, intent.getFlags() & 3);
                        this.settingsManager.loadSettings(data3);
                    } catch (SecurityException e3) {
                        Log.e(TAG, "SecurityException failed to take permission");
                        e3.printStackTrace();
                    }
                } else {
                    Log.d(TAG, "SAF dialog cancelled");
                }
                if (this.saf_dialog_from_preferences) {
                    return;
                }
                setWindowFlagsForCamera();
                showPreview(true);
                return;
            default:
                return;
        }
    }

    public boolean isMultiCam() {
        return this.is_multi_cam;
    }

    public void clickedSwitchMultiCamera(View view) {
        Log.d(TAG, "clickedSwitchMultiCamera");
        if (!isMultiCamEnabled()) {
            Log.e(TAG, "switch multi camera icon shouldn't have been visible");
        } else if (this.preview.isOpeningCamera()) {
            Log.d(TAG, "already opening camera in background thread");
        } else if (this.preview.canSwitchCamera()) {
            int nextMultiCameraId = getNextMultiCameraId();
            pushCameraIdToast(nextMultiCameraId);
            userSwitchToCamera(nextMultiCameraId);
        }
    }

    public int getNextMultiCameraId() {
        List<Integer> list;
        int intValue;
        Log.d(TAG, "getNextMultiCameraId");
        if (!isMultiCamEnabled()) {
            Log.e(TAG, "getNextMultiCameraId() called but not in multi-cam mode");
            throw new RuntimeException("getNextMultiCameraId() called but not in multi-cam mode");
        }
        int actualCameraId = getActualCameraId();
        int i = AnonymousClass91.$SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$Facing[this.preview.getCameraControllerManager().getFacing(actualCameraId).ordinal()];
        if (i == 1) {
            list = this.back_camera_ids;
        } else if (i == 2) {
            list = this.front_camera_ids;
        } else {
            list = this.other_camera_ids;
        }
        int indexOf = list.indexOf(Integer.valueOf(actualCameraId));
        if (indexOf == -1) {
            Log.e(TAG, "camera id not in current camera set");
            intValue = list.get(0).intValue();
        } else {
            intValue = list.get((indexOf + 1) % list.size()).intValue();
        }
        Log.d(TAG, "next multi cameraId: " + intValue);
        return intValue;
    }

    private void pushCameraIdToast(int i) {
        String description;
        Log.d(TAG, "pushCameraIdToast: " + i);
        if (this.preview.getCameraControllerManager().getNumberOfCameras()<=2 || (description = this.preview.getCameraControllerManager().getDescription(this, i)) == null) {
            return;
        }
        this.push_info_toast_text = (description + ": ") + getResources().getString(R.string.camera_id) + " " + i;
    }

    public void clickedPauseVideo(View view) {
        Log.d(TAG, "clickedPauseVideo");
        if (this.preview.isVideoRecording()) {
            this.preview.pauseVideo();
            this.mainUI.setPauseVideoContentDescription();
        }
    }

    private boolean checkDisableGUIIcons() {
        Log.d(TAG, "checkDisableGUIIcons");
        return (showSwitchMultiCamIcon() || findViewById(R.id.liMultiCamera).getVisibility() == 8) ? false : true;
    }

    public void clearFolderHistory() {
        Log.d(TAG, "clearFolderHistory");
        this.save_location_history.clearFolderHistory(getStorageUtils().getSaveLocation());
    }

    public void clearFolderHistorySAF() {
        Log.d(TAG, "clearFolderHistorySAF");
        this.save_location_history_saf.clearFolderHistory(getStorageUtils().getSaveLocationSAF());
    }

    public void clickedShare(View view) {
        Log.d(TAG, "clickedShare");
        this.applicationInterface.shareLastImage();
    }

    public void clickedTrash(View view) {
        Log.d(TAG, "clickedTrash");
        this.applicationInterface.trashLastImage();
    }

    private boolean has_cached_display_rotation;
    private long cached_display_rotation_time_ms;
    private int cached_display_rotation;

    public int getDisplayRotation(boolean prefer_later) {
        /*if( MyDebug.LOG ) {
            Log.d(TAG, "getDisplayRotationDegrees");
            Log.d(TAG, "prefer_later: " + prefer_later);
        }*/
        if (lock_to_landscape || prefer_later) {
            return getWindowManager().getDefaultDisplay().getRotation();
        }
        // we cache to reduce effect of annoying problem where rotation changes shortly before the
        // configuration actually changes (several frames), so on-screen elements would briefly show
        // in wrong location when device rotates from/to portrait and landscape; also not a bad idea
        // to cache for performance anyway, to avoid calling
        // getWindowManager().getDefaultDisplay().getRotation() every frame
        long time_ms = System.currentTimeMillis();
        if (has_cached_display_rotation && time_ms<cached_display_rotation_time_ms + 1000) {
            return cached_display_rotation;
        }
        has_cached_display_rotation = true;
        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        cached_display_rotation = rotation;
        cached_display_rotation_time_ms = time_ms;
        return rotation;
    }

    public void takePicture(boolean z) {
        Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "takePicture");
        if (this.applicationInterface.getPhotoMode() == MyApplicationInterface.PhotoMode.Panorama) {
            if (this.preview.isTakingPhoto()) {
                Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "ignore whilst taking panorama photo");
            } else {
                if (this.applicationInterface.getGyroSensor().isRecording()) {
                    Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "panorama complete");
                    this.applicationInterface.finishPanorama();
                    return;
                }

                if (this.applicationInterface.canTakeNewPhoto()) {
                    Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "start panorama");
                    this.applicationInterface.startPanorama();
                } else {
                    Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "can\'t start new panoroma, still saving in background");
                }
            }
        }

        this.takePicturePressed(z, false);
    }


    public boolean lastContinuousFastBurst() {
        return this.last_continuous_fast_burst;
    }

    public void takePicturePressed(boolean z, boolean z1) {
        Log.d("com.gpsvideocamera.videotimestamp.CameraActivity", "takePicturePressed");
        this.closePopup();
        this.last_continuous_fast_burst = z1;
        this.preview.takePicturePressed(z, z1);
//        if(!this.mSP.getBoolean(this, Util.IS_PURCHESH_OR_NOT, true)) {
        AlarmReceiver alarmReceiver0 = new AlarmReceiver();
        int v = this.mSP.getInteger(this, "TOTAL_PHOTO_CAPTURE", 0) + 1;
        if (v == 45) {
            Calendar calendar0 = Calendar.getInstance();
            calendar0.set(11, 21);
            calendar0.set(12, 0);
            calendar0.set(13, 0);
            calendar0.set(14, 0);
            alarmReceiver0.setAlarm(this, calendar0.getTimeInMillis(), 53);
        } else if (v == 50) {
            Calendar calendar1 = Calendar.getInstance();
            calendar1.set(11, 21);
            calendar1.set(12, 0);
            calendar1.set(13, 0);
            calendar1.set(14, 0);
            alarmReceiver0.setAlarm(this, calendar1.getTimeInMillis(), 54);
        } else if (v % 100 == 0) {
            Calendar calendar2 = Calendar.getInstance();
            calendar2.set(11, 21);
            calendar2.set(12, 0);
            calendar2.set(13, 0);
            calendar2.set(14, 0);
            alarmReceiver0.setAlarm(this, calendar2.getTimeInMillis(), 55);
        }

        this.mSP.setInteger(this, "TOTAL_PHOTO_CAPTURE", v);
        int v1 = this.mSP.getInteger(this, "TOTAL_TIME_APP_OPEN", 0);
        if (v1 != 9 && v != 30) {
            if (v1 != 5 && v != 25) {
                if (v1 != 6 && v != 20) {
                    if (v1 != 7 && v != 15) {
                        if (v1 != 4 && v != 18) {
                            if (v == 10) {
                                if (this.mSP.getInteger(this, "FONT_STYLE_OPEN_TIME", 0) == 0) {
                                    Calendar calendar3 = Calendar.getInstance();
                                    calendar3.set(11, 21);
                                    calendar3.set(12, 0);
                                    calendar3.set(13, 0);
                                    calendar3.set(14, 0);
                                    alarmReceiver0.setAlarm(this, calendar3.getTimeInMillis(), 0x3F);
                                }
                            } else if (v == 13 && this.mSP.getInteger(this, "STAMP_POS_OPEN_TIME", 0) == 0) {
                                Calendar calendar4 = Calendar.getInstance();
                                calendar4.set(11, 21);
                                calendar4.set(12, 0);
                                calendar4.set(13, 0);
                                calendar4.set(14, 0);
                                alarmReceiver0.setAlarm(this, calendar4.getTimeInMillis(), 0x40);
                            }
                        } else if (this.mSP.getInteger(this, "TEMPLT_OPEN_TIME", 0) == 0) {
                            Calendar calendar5 = Calendar.getInstance();
                            calendar5.set(11, 21);
                            calendar5.set(12, 0);
                            calendar5.set(13, 0);
                            calendar5.set(14, 0);
                            alarmReceiver0.setAlarm(this, calendar5.getTimeInMillis(), 62);
                        }
                    } else if (this.mSP.getInteger(this, "FILE_NAME_OPEN_TIME", 0) == 0) {
                        Calendar calendar6 = Calendar.getInstance();
                        calendar6.set(11, 21);
                        calendar6.set(12, 0);
                        calendar6.set(13, 0);
                        calendar6.set(14, 0);
                        alarmReceiver0.setAlarm(this, calendar6.getTimeInMillis(), 61);
                    }
                } else if (this.mSP.getInteger(this, "FOLDER_OPEN_TIME", 0) == 0) {
                    Calendar calendar7 = Calendar.getInstance();
                    calendar7.set(11, 21);
                    calendar7.set(12, 0);
                    calendar7.set(13, 0);
                    calendar7.set(14, 0);
                    alarmReceiver0.setAlarm(this, calendar7.getTimeInMillis(), 60);
                }
            } else if (this.mSP.getInteger(this, "CAM_SET_OPEN_TIME", 0) == 0) {
                Calendar calendar8 = Calendar.getInstance();
                calendar8.set(11, 21);
                calendar8.set(12, 0);
                calendar8.set(13, 0);
                calendar8.set(14, 0);
                alarmReceiver0.setAlarm(this, calendar8.getTimeInMillis(), 59);
            }
        } else if (this.mSP.getInteger(this, "MAP_DATA_OPEN_TIME", 0) == 0) {
            Calendar calendar9 = Calendar.getInstance();
            calendar9.set(11, 21);
            calendar9.set(12, 0);
            calendar9.set(13, 0);
            calendar9.set(14, 0);
            alarmReceiver0.setAlarm(this, calendar9.getTimeInMillis(), 58);
        }

        int v2 = this.mSP.getInteger(this, "TOTAL_PHOTO_CAPTURE_FORINAPPREVIEW", 0) + 1;
        this.mSP.setInteger(this, "TOTAL_PHOTO_CAPTURE_FORINAPPREVIEW", v2);
        if (Default.IN_APP_REVIEW == 1 && v2 == 5) {
            ReviewManager reviewManager0 = ReviewManagerFactory.create(this);
            reviewManager0.requestReviewFlow().addOnCompleteListener(new OnCompleteListener<ReviewInfo>() {
                @Override
                public void onComplete(@NonNull Task<ReviewInfo> task0) {
                    ReviewInfo reviewInfo0 = (ReviewInfo) task0.getResult();
                    if (reviewInfo0 != null) {
                        reviewManager0.launchReviewFlow(CameraMainActivity.this, reviewInfo0).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    task.getException().printStackTrace();
                                }
                                return;
                            }
                        });
                    } else {
                        Log.e("TAG", "onClick: " + task0.getException());
                    }
                }
            });
        }
    }


    public void lockScreen() {
        this.screen_is_locked = true;
    }

    public void unlockScreen() {
        this.screen_is_locked = false;
    }

    public boolean isScreenLocked() {
        return this.screen_is_locked;
    }

    @Override
    protected void onSaveInstanceState(Bundle bundle) {
        Log.d(TAG, "onSaveInstanceState");
        super.onSaveInstanceState(bundle);
        Preview preview = this.preview;
        if (preview != null) {
            preview.onSaveInstanceState(bundle);
        }
        MyApplicationInterface myApplicationInterface = this.applicationInterface;
        if (myApplicationInterface != null) {
            myApplicationInterface.onSaveInstanceState(bundle);
        }
    }

    public boolean supportsExposureButton() {
        if (this.preview.getCameraController() == null || this.preview.isVideoHighSpeed()) {
            return false;
        }
        return this.preview.supportsExposures() || ((PreferenceManager.getDefaultSharedPreferences(this).getString(PreferenceKeys.ISOPreferenceKey, "auto").equals("auto") ^ true) && this.preview.supportsISORange());
    }

    public void cameraSetup() {
        Log.d(TAG, "cameraSetup");
        long currentTimeMillis = System.currentTimeMillis();
        if (supportsForceVideo4K() && this.preview.usingCamera2API()) {
            Log.d(TAG, "using Camera2 API, so can disable the force 4K option");
            disableForceVideo4K();
        }
        if (supportsForceVideo4K() && this.preview.getVideoQualityHander().getSupportedVideoSizes() != null) {
            for (CameraController.Size size : this.preview.getVideoQualityHander().getSupportedVideoSizes()) {
                if (size.width>=3840 && size.height>=2160) {
                    Log.d(TAG, "camera natively supports 4K, so can disable the force option");
                    disableForceVideo4K();
                }
            }
        }
        Log.d(TAG, "cameraSetup: time after handling Force 4K option: " + (System.currentTimeMillis() - currentTimeMillis));
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        Log.d(TAG, "set up zoom");
        Log.d(TAG, "has_zoom? " + this.preview.supportsZoom());
        ZoomControls zoomControls = (ZoomControls) findViewById(R.id.zoom);
        SeekBar seekBar = (SeekBar) findViewById(R.id.zoom_seekbar);
        if (this.preview.supportsZoom()) {
            if (defaultSharedPreferences.getBoolean(PreferenceKeys.ShowZoomControlsPreferenceKey, false)) {
                zoomControls.setIsZoomInEnabled(true);
                zoomControls.setIsZoomOutEnabled(true);
                zoomControls.setZoomSpeed(20L);
                zoomControls.setOnZoomInClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        CameraMainActivity.this.zoomIn();
                    }
                });
                zoomControls.setOnZoomOutClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        CameraMainActivity.this.zoomOut();
                    }
                });
                if (!this.mainUI.inImmersiveMode()) {
                    zoomControls.setVisibility(View.VISIBLE);
                }
            } else {
                zoomControls.setVisibility(View.GONE);
            }
            seekBar.setOnSeekBarChangeListener(null);
            seekBar.setMax(this.preview.getMaxZoom());
            seekBar.setProgress(this.preview.getMaxZoom() - this.preview.getCameraController().getZoom());
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onStartTrackingTouch(SeekBar seekBar2) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar2) {
                }

                @Override
                public void onProgressChanged(SeekBar seekBar2, int i, boolean z) {
                    Log.d(CameraMainActivity.TAG, "zoom onProgressChanged: " + i);
                    CameraMainActivity.this.preview.zoomTo(CameraMainActivity.this.preview.getMaxZoom() - i);
                }
            });
            if (defaultSharedPreferences.getBoolean(PreferenceKeys.ShowZoomSliderControlsPreferenceKey, false)) {
                if (!this.mainUI.inImmersiveMode()) {
                    seekBar.setVisibility(View.VISIBLE);
                }
            } else {
                seekBar.setVisibility(4);
            }
        } else {
            zoomControls.setVisibility(View.GONE);
            seekBar.setVisibility(4);
        }
        Log.d(TAG, "cameraSetup: time after setting up zoom: " + (System.currentTimeMillis() - currentTimeMillis));
        View findViewById = findViewById(R.id.take_photo);
        if (defaultSharedPreferences.getBoolean(PreferenceKeys.ShowTakePhotoPreferenceKey, true)) {
            if (!this.mainUI.inImmersiveMode()) {
                findViewById.setVisibility(View.VISIBLE);
            }
        } else {
            findViewById.setVisibility(4);
        }
        Log.d(TAG, "set up manual focus");
        setManualFocusSeekbar(false);
        setManualFocusSeekbar(true);
        Log.d(TAG, "cameraSetup: time after setting up manual focus: " + (System.currentTimeMillis() - currentTimeMillis));
        setManualWBSeekbar();
        Log.d(TAG, "cameraSetup: time after setting up iso: " + (System.currentTimeMillis() - currentTimeMillis));
        if (this.preview.supportsExposures()) {
            Log.d(TAG, "set up exposure compensation");
            final int minimumExposure = this.preview.getMinimumExposure();
            final VerticalSeekBar verticalSeekBar = (VerticalSeekBar) findViewById(R.id.exposure_seekbar);
            verticalSeekBar.setOnSeekBarChangeListener(null);
            verticalSeekBar.setMax(this.preview.getMaximumExposure() - minimumExposure);
            verticalSeekBar.setProgress(this.preview.getCurrentExposure() - minimumExposure);
            verticalSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onStartTrackingTouch(SeekBar seekBar2) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar2) {
                }

                @Override
                public void onProgressChanged(SeekBar seekBar2, int i, boolean z) {
                    Log.d(CameraMainActivity.TAG, "exposure seekbar onProgressChanged: " + i);
                    CameraMainActivity.this.preview.setExposure(minimumExposure + i);

                    CameraMainActivity.this.exposureHandler.removeCallbacksAndMessages(null);
                    CameraMainActivity.this.exposureHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            verticalSeekBar.setVisibility(View.GONE);
                        }
                    }, 3000L);
                }
            });
        }
        Log.d(TAG, "cameraSetup: time after setting up exposure: " + (System.currentTimeMillis() - currentTimeMillis));
        if (checkDisableGUIIcons()) {
            Log.d(TAG, "cameraSetup: need to layoutUI as we hid some icons");
            this.mainUI.layoutUI();
        }
        this.mainUI.updateOnScreenIcons();
        Log.d(TAG, "" + (System.currentTimeMillis() - currentTimeMillis));
        this.mainUI.setTakePhotoIcon();
        this.mainUI.setSwitchCameraContentDescription();
        Log.d(TAG, "cameraSetup: time after setting take photo icon: " + (System.currentTimeMillis() - currentTimeMillis));
        Log.d(TAG, "cameraSetup: total time for cameraSetup: " + (System.currentTimeMillis() - currentTimeMillis));
    }

    private void setManualFocusSeekbar(boolean z) {
        Log.d(TAG, "setManualFocusSeekbar");
        setManualFocusSeekBarVisibility(z);
    }

    public void setManualFocusSeekBarVisibility(boolean z) {
        boolean z2 = this.preview.getCurrentFocusValue() != null && getPreview().getCurrentFocusValue().equals("focus_mode_manual2");
        if (z && z2 && this.applicationInterface.getPhotoMode() == MyApplicationInterface.PhotoMode.FocusBracketing) {
            this.preview.isVideo();
        }
    }

    public void setManualWBSeekbar() {
        Log.d(TAG, "setManualWBSeekbar");
        if (this.preview.getSupportedWhiteBalances() == null || !this.preview.supportsWhiteBalanceTemperature()) {
            return;
        }
        Log.d(TAG, "set up manual white balance");
        this.preview.getMinimumWhiteBalanceTemperature();
        this.preview.getMaximumWhiteBalanceTemperature();
    }

    public boolean supportsAutoStabilise() {
        if (this.applicationInterface.isRawOnly() || this.applicationInterface.getPhotoMode() == MyApplicationInterface.PhotoMode.Panorama) {
            return false;
        }
        return this.supports_auto_stabilise;
    }

    public boolean supportsDRO() {
        return !this.applicationInterface.isRawOnly(MyApplicationInterface.PhotoMode.DRO) && Build.VERSION.SDK_INT>=21;
    }

    public boolean supportsHDR() {
        return Build.VERSION.SDK_INT>=21 && this.large_heap_memory>=128 && this.preview.supportsExpoBracketing();
    }

    public boolean supportsExpoBracketing() {
        if (this.applicationInterface.isImageCaptureIntent()) {
            return false;
        }
        return this.preview.supportsExpoBracketing();
    }

    public boolean supportsFocusBracketing() {
        if (this.applicationInterface.isImageCaptureIntent()) {
            return false;
        }
        return this.preview.supportsFocusBracketing();
    }

    public boolean supportsPanorama() {
        return !this.applicationInterface.isImageCaptureIntent() && Build.VERSION.SDK_INT>=21 && this.large_heap_memory>=256 && this.applicationInterface.getGyroSensor().hasSensors();
    }

    public boolean hasAudioControl() {
        String string = PreferenceManager.getDefaultSharedPreferences(this).getString(PreferenceKeys.AudioControlPreferenceKey, "none");
        if (string.equals("voice")) {
            return this.speechControl.hasSpeechRecognition();
        }
        return string.equals("noise");
    }

    public boolean showSwitchMultiCamIcon() {
        if (isMultiCamEnabled()) {
            int i = AnonymousClass91.$SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$Facing[this.preview.getCameraControllerManager().getFacing(getActualCameraId()).ordinal()];
            return i != 1 ? i != 2 ? this.other_camera_ids.size()>0 : this.front_camera_ids.size()>0 : this.back_camera_ids.size()>0;
        }
        return false;
    }

    public boolean supportsFastBurst() {
        return !this.applicationInterface.isImageCaptureIntent() && this.preview.usingCamera2API() && this.large_heap_memory>=512 && this.preview.supportsBurst();
    }

    public boolean supportsNoiseReduction() {
        return Build.VERSION.SDK_INT>=24 && this.preview.usingCamera2API() && this.large_heap_memory>=512 && this.preview.supportsBurst() && this.preview.supportsExposureTime();
    }

    public boolean supportsBurstRaw() {
        return this.large_heap_memory>=512;
    }

    public boolean supportsPreviewBitmaps() {
        return Build.VERSION.SDK_INT>=21 && (this.preview.getView() instanceof TextureView) && this.large_heap_memory>=128;
    }

    private int maxExpoBracketingNImages() {
        return this.preview.maxExpoBracketingNImages();
    }

    public boolean supportsForceVideo4K() {
        return this.supports_force_video_4k;
    }

    public boolean supportsCamera2() {
        return this.supports_camera2;
    }

    private void disableForceVideo4K() {
        this.supports_force_video_4k = false;
    }

    public Preview getPreview() {
        return this.preview;
    }

    public boolean showManualFocusSeekbar(boolean z) {
        boolean z2 = true;
        boolean z3 = this.preview.getCurrentFocusValue() != null && getPreview().getCurrentFocusValue().equals("focus_mode_manual2");
        if (z) {
            return (z3 && this.applicationInterface.getPhotoMode() == MyApplicationInterface.PhotoMode.FocusBracketing && !this.preview.isVideo()) ? false : false;
        }
        return z3;
    }

    public boolean isCameraInBackground() {
        return this.camera_in_background;
    }

    public boolean isAppPaused() {
        return this.app_is_paused;
    }

    public BluetoothRemoteControl getBluetoothRemoteControl() {
        return this.bluetoothRemoteControl;
    }

    public SettingsManager getSettingsManager() {
        return this.settingsManager;
    }

    public MainUI getMainUI() {
        return this.mainUI;
    }

    public ManualSeekbars getManualSeekbars() {
        return this.manualSeekbars;
    }

    public MyApplicationInterface getApplicationInterface() {
        return this.applicationInterface;
    }

    public TextFormatter getTextFormatter() {
        return this.textFormatter;
    }

    public SoundPoolManager getSoundPoolManager() {
        return this.soundPoolManager;
    }

    public LocationSupplier getLocationSupplier() {
        return this.applicationInterface.getLocationSupplier();
    }

    public StorageUtils getStorageUtils() {
        return this.applicationInterface.getStorageUtils();
    }

    public File getImageFolder() {
        return this.applicationInterface.getStorageUtils().getImageFolder();
    }

    public ToastBoxer getChangedAutoStabiliseToastBoxer() {
        return this.changed_auto_stabilise_toast;
    }

    private void freeAudioListener(boolean z) {
        Log.d(TAG, "freeAudioListener");
        AudioListener audioListener = this.audio_listener;
        if (audioListener != null) {
            audioListener.release(z);
            this.audio_listener = null;
        }
    }

    public void stopAudioListeners() {
        freeAudioListener(true);
        if (this.speechControl.hasSpeechRecognition()) {
            this.speechControl.stopListening();
        }
    }

    private void initGyroSensors() {
        Log.d(TAG, "initGyroSensors");
        if (this.applicationInterface.getPhotoMode() == MyApplicationInterface.PhotoMode.Panorama) {
            this.applicationInterface.getGyroSensor().enableSensors();
        } else {
            this.applicationInterface.getGyroSensor().disableSensors();
        }
    }

    public void speak(String str) {
        TextToSpeech textToSpeech = this.textToSpeech;
        if (textToSpeech == null || !this.textToSpeechSuccess) {
            return;
        }
        textToSpeech.speak(str, 0, null);
    }

    public void restartOpenCamera() {

        Log.d(TAG, "restartOpenCamera");
        waitUntilImageQueueEmpty();
        Intent launchIntentForPackage = getPackageManager().getLaunchIntentForPackage(getPackageName());
        launchIntentForPackage.addFlags(67108864);
        startActivity(launchIntentForPackage);
    }

    public void takePhotoButtonLongClickCancelled() {
        Log.d(TAG, "takePhotoButtonLongClickCancelled");
        if (this.preview.getCameraController() == null || !this.preview.getCameraController().isContinuousBurstInProgress()) {
            return;
        }
        this.preview.getCameraController().stopContinuousBurst();
    }

    public ToastBoxer getAudioControlToast() {
        return this.audio_control_toast;
    }

    public SaveLocationHistory getSaveLocationHistory() {
        return this.save_location_history;
    }

    public SaveLocationHistory getSaveLocationHistorySAF() {
        return this.save_location_history_saf;
    }

    public void usedFolderPicker() {
        if (this.applicationInterface.getStorageUtils().isUsingSAF()) {
            this.save_location_history_saf.updateFolderHistory(getStorageUtils().getSaveLocationSAF(), true);
        } else {
            this.save_location_history.updateFolderHistory(getStorageUtils().getSaveLocation(), true);
        }
    }

    public boolean hasThumbnailAnimation() {
        return this.applicationInterface.hasThumbnailAnimation();
    }

    public boolean testHasNotification() {
        return this.has_notification;
    }

    boolean checkStoragePermission() {
        boolean z;
        if (Build.VERSION.SDK_INT>32) {
            z = ContextCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_IMAGES") == 0;
            if (ContextCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_VIDEO") != 0) {
                z = false;
            }
            if (ContextCompat.checkSelfPermission(this, "android.permission.CAMERA") != 0) {
                return false;
            }
            return z;
        }
        z = ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0;
        if (ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            z = false;
        }
        if (ContextCompat.checkSelfPermission(this, "android.permission.CAMERA") != 0) {
            return false;
        }
        return z;
    }

    boolean checkLocationPermission() {
        boolean z = ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0;
        if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") != 0) {
            return false;
        }
        return z;
    }

    private void checkSaveLocations() {
        boolean z;
        String str;
        Log.d(TAG, "checkSaveLocations");
        if (useScopedStorage()) {
            SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            String saveLocation = getStorageUtils().getSaveLocation();
            CheckSaveLocationResult checkSaveLocation = checkSaveLocation(saveLocation);
            if (checkSaveLocation.res) {
                z = false;
            } else {
                Log.d(TAG, "save_location not valid with scoped storage: " + saveLocation);
                if (checkSaveLocation.alt == null) {
                    str = "OpenCamera";
                } else {
                    Log.d(TAG, "alternative: " + checkSaveLocation.alt);
                    str = checkSaveLocation.alt;
                }
                SharedPreferences.Editor edit = defaultSharedPreferences.edit();
                edit.putString(PreferenceKeys.SaveLocationPreferenceKey, str);
                edit.apply();
                z = true;
            }
            for (int size = this.save_location_history.size() - 1; size>=0; size--) {
                String str2 = this.save_location_history.get(size);
                CheckSaveLocationResult checkSaveLocation2 = checkSaveLocation(str2);
                if (!checkSaveLocation2.res) {
                    Log.d(TAG, "save_location in history " + size + " not valid with scoped storage: " + str2);
                    if (checkSaveLocation2.alt == null) {
                        this.save_location_history.remove(size);
                    } else {
                        Log.d(TAG, "alternative: " + checkSaveLocation2.alt);
                        this.save_location_history.set(size, checkSaveLocation2.alt);
                    }
                    z = true;
                }
            }
            if (z) {
                this.save_location_history.updateFolderHistory(getStorageUtils().getSaveLocation(), false);
            }
        }
    }

    public void showExposureButton() {
        if (supportsExposureButton()) {
            final VerticalSeekBar verticalSeekBar = (VerticalSeekBar) findViewById(R.id.exposure_seekbar);
            verticalSeekBar.setVisibility(View.VISIBLE);
            this.exposureHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    verticalSeekBar.setVisibility(View.GONE);
                }
            }, 3000L);
        }
    }

    public void doWorkWithNewLocation(final Location location) {
        this.executor.execute(new Runnable() {
            @Override
            public final void run() {
                CameraMainActivity.this.m398x109b2a8e(location);
            }
        });
    }

    public void m398x109b2a8e(Location location) {
        location.getAccuracy();
        String string = this.mSP.getString(this, "", Default.AUTOMATIC);
//        if (!string.equals(Default.MANUAL)) {
//            callElevationApi(location.getLatitude(), location.getLongitude());
//        }
        if (string != null && string.equals(Default.AUTOMATIC) && Geocoder.isPresent()) {
            double latitude = location.getLatitude();
            double longitude = location.getLongitude();
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            if (Geocoder.isPresent()) {
                try {
                    List<Address> fromLocation = geocoder.getFromLocation(latitude, longitude, 1);
                    if (fromLocation == null || fromLocation.isEmpty()) {
                        return;
                    }
                    String str = fromLocation.get(0).getAddressLine(0) + "";
                    fromLocation.get(0).getMaxAddressLineIndex();
                    String str2 = fromLocation.get(0).getLocality() + "";
                    String str3 = fromLocation.get(0).getAdminArea() + "";
                    String str4 = fromLocation.get(0).getCountryName() + "";
                    fromLocation.get(0).getFeatureName();
                    if (str2.equals("null") || str2.equals("")) {
                        str2 = fromLocation.get(0).getSubAdminArea() + "";
                    }
                    int i = (latitude>0.0d ? 1 : (latitude == 0.0d ? 0 : -1));
                    if (i != 0) {
                        String format = this.dFormat.format(latitude);
                        if (format.contains(",")) {
                            format = format.replace(",", ".");
                        }
                        this.mSP.setString(this, SP.LATITUDE, format);
                    }
                    this.mSP.setFloat(this, SP.ACCURACY_VALUE, location.getAccuracy());
                    int i2 = (longitude>0.0d ? 1 : (longitude == 0.0d ? 0 : -1));
                    if (i2 != 0) {
                        String format2 = this.dFormat.format(longitude);
                        if (format2.contains(",")) {
                            format2 = format2.replace(",", ".");
                        }
                        this.mSP.setString(this, SP.LONGITUDE, format2);
                    }
                    if (i != 0 || i2 != 0) {
                        this.mSP.setString(this, SP.PLUS_CODE, OpenLocationCode.encode(latitude, longitude));
                    }
                    if (str != null) {
                        this.address_line_1 = str;
                        this.mSP.setString(this, SP.LOC_LINE_1_ADDRESS, str);
                    }
                    if (str2 != null) {
                        this.city = str2;
                        this.mSP.setString(this, SP.LOC_LINE_2_CITY, str2);
                    }
                    if (str3 != null) {
                        this.state = str3;
                        this.mSP.setString(this, SP.LOC_LINE_3_STATE, str3);
                    }
                    if (str4 != null) {
                        this.country = str4;
                        this.mSP.setString(this, SP.LOC_LINE_4_COUNTRY, str4);
                    }
                    this.handler.post(new Runnable() {
                        @Override
                        public void run() {
                            CameraMainActivity.this.loadMap();
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }


    public static class CheckSaveLocationResult {
        final String alt;
        final boolean res;

        public CheckSaveLocationResult(boolean z, String str) {
            this.res = z;
            this.alt = str;
        }

        public boolean equals(Object obj) {
            if (obj instanceof CheckSaveLocationResult) {
                CheckSaveLocationResult checkSaveLocationResult = (CheckSaveLocationResult) obj;
                if (checkSaveLocationResult.res == this.res) {
                    String str = checkSaveLocationResult.alt;
                    String str2 = this.alt;
                    return str == str2 || (str != null && str.equals(str2));
                }
                return false;
            }
            return false;
        }

        public int hashCode() {
            int i = this.res ? 1249 : 1259;
            String str = this.alt;
            return i ^ (str == null ? 0 : str.hashCode());
        }

        public String toString() {
            return "CheckSaveLocationResult{" + this.res + " , " + this.alt + "}";
        }
    }


    private class MyGestureDetector extends GestureDetector.SimpleOnGestureListener {
        @Override

        public boolean onDown(MotionEvent motionEvent) {
            return true;
        }

        private MyGestureDetector() {
        }

        @Override

        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
            try {
                Log.d(CameraMainActivity.TAG, "from " + motionEvent.getX() + " , " + motionEvent.getY() + " to " + motionEvent2.getX() + " , " + motionEvent2.getY());
                ViewConfiguration viewConfiguration = ViewConfiguration.get(CameraMainActivity.this);
                int i = (int) ((CameraMainActivity.this.getResources().getDisplayMetrics().density * 160.0f) + 0.5f);
                int scaledMinimumFlingVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
                Log.d(CameraMainActivity.TAG, "from " + motionEvent.getX() + " , " + motionEvent.getY() + " to " + motionEvent2.getX() + " , " + motionEvent2.getY());
                StringBuilder sb = new StringBuilder();
                sb.append("swipeMinDistance: ");
                sb.append(i);
                Log.d(CameraMainActivity.TAG, sb.toString());
                float x = motionEvent.getX() - motionEvent2.getX();
                float y = motionEvent.getY() - motionEvent2.getY();
                float f3 = (f * f) + (f2 * f2);
                if ((x * x) + (y * y)<=i * i || f3<=scaledMinimumFlingVelocity * scaledMinimumFlingVelocity) {
                    return false;
                }
                CameraMainActivity.this.unlockScreen();
                return false;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
    }

    private void enableAutoStart() {
        if (Build.BRAND.equalsIgnoreCase("xiaomi") || Build.BRAND.equalsIgnoreCase("redmi")) {
            final SP sp = new SP(this);
            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(false);
            builder.setTitle("Enable AutoStart");
            builder.setMessage("Please allow us to run in the background, else our services can’t be accessed.");
            builder.setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    try {
                        Intent intent = new Intent();
                        intent.setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"));

                        CameraMainActivity.this.startActivity(intent);
                        sp.setBoolean(CameraMainActivity.this, "enableAutostart", true);
                    } catch (Exception e) {
                        e.printStackTrace();
                        builder.setCancelable(true);
                        sp.setBoolean(CameraMainActivity.this, "enableAutostart", true);
                    }
                    builder.setCancelable(true);
                }
            });
            AlertDialog create = builder.create();
            create.show();
            create.getButton(-1).setTextColor(getResources().getColor(R.color.black));
        }
    }

    private void OnesignalDialogs() {
        OSNotificationHelper.showLinkDialogNotification(this, new int[0], new LinkDialogBtnClickListener() {
            @Override
            public void onLinkBtnClicked(String str) {

                try {
                    CameraMainActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
                } catch (ActivityNotFoundException unused) {
                    CameraMainActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
                }
            }
        });
        OSNotificationHelper.showShareDialog(this, new int[0], new ShareDialogBtnClickListener() {
            @Override
            public void onShareBtnClicked() {
                Util.shareApp(CameraMainActivity.this);
            }
        });
        OSNotificationHelper.showMessageDialog(this, new int[0], new MessageDialogBtnClickListener() {
            @Override
            public void onMessageBtnClicked() {
            }
        });
        OSNotificationHelper.showOfferDialogNotification(this, new int[0], new OfferDialogBtnClickListener() {
            @Override
            public void onOfferBtnClicked() {
                CameraMainActivity.this.onInAppClicked();
            }
        });
        OSNotificationHelper.showRateDialogNotification(this, new int[0], new RateDialogBtnClickListener() {
            @Override
            public void onRateBtnClicked() {
//                Util.showSayThanksDialog(MainActivity.this);
            }
        });
    }

    public void setModePhoto() {
        try {
            unLockDrawer();
            this.scannerMode = false;
            this.scannerView.setVisibility(View.GONE);
            this.mCodeScanner.releaseResources();
            this.mTopScreenPannel.setVisibility(View.VISIBLE);
            this.rl_btn_layout.setVisibility(View.VISIBLE);
            this.previewlay.setVisibility(View.VISIBLE);
            this.mapfragmentlay.setVisibility(View.VISIBLE);
            preview.onResume();

            updateTextViews(R.color.white, R.drawable.yellow_rect, R.color._262626, R.drawable.text_back, R.color._262626, R.drawable.text_back);
            new Handler().postDelayed(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.Camera.MainActivity.75
                @Override // java.lang.Runnable
                public void run() {
                    CameraMainActivity.this.preview.setExposure(0);
                }
            }, 1000);

        } catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG, "setModePhoto  : " + e.getMessage());
        }
    }


    public void setModeQRCode() {
        try {
            long j;
            this.scannerMode = true;
            closePopup();
            if (this.preview.getCameraId() != 0) {
                this.preview.setCamera(0);
                j = 1000;
            } else {
                j = 0;
            }
            this.mCodeScanner.releaseResources();
            new Handler().postDelayed(() -> {
                this.scannerView.setVisibility(View.VISIBLE);
                this.mTopScreenPannel.setVisibility(View.GONE);
                this.rl_btn_layout.setVisibility(View.GONE);
                this.previewlay.setVisibility(View.GONE);
                this.mapfragmentlay.setVisibility(View.GONE);
                this.preview.onPause();
                CameraMainActivity.this.mCodeScanner.startPreview();
                updateTextViews(R.color._262626, R.drawable.text_back, R.color.white, R.drawable.yellow_rect, R.color._262626, R.drawable.text_back);
            }, j);

        } catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG, "setModeQRCode  : " + e.getMessage());
        }
    }

    public void setModeVideo() {
        try {
            lockDrawer();
            this.scannerMode = false;
            closePopup();
            if (this.preview.getCameraId() != 0) {
                this.preview.setCamera(0);
            }

            new Handler().postDelayed(() -> {

                this.scannerView.setVisibility(View.GONE);
                this.mTopScreenPannel.setVisibility(View.GONE);
                this.rl_btn_layout.setVisibility(View.GONE);
                this.previewlay.setVisibility(View.GONE);
                this.mapfragmentlay.setVisibility(View.GONE);
                this.preview.onPause();

                updateTextViews(R.color._262626, R.drawable.text_back, R.color._262626, R.drawable.text_back, R.color.white, R.drawable.yellow_rect);

            }, UPDATE_INTERVAL_IN_MILLISECONDS);

        } catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG, "setModeVideo  : " + e.getMessage());
        }
    }


    private void updateTextViews(int photoTextColor, int photoBackground, int qrCodeTextColor, int qrCodeBackground, int videoTextColor, int videoBackground) {
        int dimensionPixelOffset = getResources().getDimensionPixelOffset(R.dimen._4dp);
        int dimensionPixelOffset2 = getResources().getDimensionPixelOffset(R.dimen._12dp);

        // Update colors and backgrounds
        this.tv_photo.setTextColor(getResources().getColor(photoTextColor));
        this.tv_photo.setBackgroundResource(photoBackground);

        this.tv_qrcode.setTextColor(getResources().getColor(qrCodeTextColor));
        this.tv_qrcode.setBackgroundResource(qrCodeBackground);

        this.tv_video.setTextColor(getResources().getColor(videoTextColor));
        this.tv_video.setBackgroundResource(videoBackground);

        // Update layout params for TextViews
        RelativeLayout.LayoutParams videoLayoutParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        videoLayoutParams.addRule(RelativeLayout.CENTER_IN_PARENT);
        this.tv_video.setLayoutParams(videoLayoutParams);
        this.tv_video.setPadding(dimensionPixelOffset2, dimensionPixelOffset, dimensionPixelOffset2, dimensionPixelOffset);

        RelativeLayout.LayoutParams photoLayoutParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        photoLayoutParams.addRule(RelativeLayout.LEFT_OF, R.id.tv_video);
        photoLayoutParams.addRule(RelativeLayout.CENTER_VERTICAL);
        photoLayoutParams.setMargins(dimensionPixelOffset2, 0, 0, 0);
        this.tv_photo.setLayoutParams(photoLayoutParams);
        this.tv_photo.setPadding(dimensionPixelOffset2, dimensionPixelOffset, dimensionPixelOffset2, dimensionPixelOffset);

        RelativeLayout.LayoutParams qrCodeLayoutParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        qrCodeLayoutParams.addRule(RelativeLayout.RIGHT_OF, R.id.tv_video);
        qrCodeLayoutParams.addRule(RelativeLayout.CENTER_VERTICAL);
        qrCodeLayoutParams.setMargins(0, 0, dimensionPixelOffset2, 0);
        this.tv_qrcode.setLayoutParams(qrCodeLayoutParams);
        this.tv_qrcode.setPadding(dimensionPixelOffset2, dimensionPixelOffset, dimensionPixelOffset2, dimensionPixelOffset);
    }


//    public void setModePhoto() {
//        try {
//            unLockDrawer();
//            this.scannerMode = false;
//            this.scannerView.setVisibility(View.GONE);
//            this.mCodeScanner.releaseResources();
//            this.mTopScreenPannel.setVisibility(View.VISIBLE);
//            this.rl_btn_layout.setVisibility(View.VISIBLE);
//            this.previewlay.setVisibility(View.VISIBLE);
//            this.mapfragmentlay.setVisibility(View.VISIBLE);
//            preview.onResume();
//
//            int dimensionPixelOffset = getResources().getDimensionPixelOffset(R.dimen._4dp);
//            int dimensionPixelOffset2 = getResources().getDimensionPixelOffset(R.dimen._12dp);
//            this.tv_qrcode.setTextColor(getResources().getColor(R.color.white));
//            this.tv_photo.setTextColor(getResources().getColor(R.color._262626));
//            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
//            layoutParams.addRule(14, -1);
//            layoutParams.addRule(15);
//            this.tv_photo.setLayoutParams(layoutParams);
//            this.tv_photo.setPadding(dimensionPixelOffset2, dimensionPixelOffset, dimensionPixelOffset2, dimensionPixelOffset);
//            this.tv_photo.setBackgroundResource(R.drawable.yellow_rect);
//            RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
//            layoutParams2.setMargins(dimensionPixelOffset2, 0, 0, 0);
//            layoutParams2.addRule(15);
//            layoutParams2.addRule(1, R.id.tv_photo);
//            this.tv_qrcode.setLayoutParams(layoutParams2);
//            this.tv_qrcode.setPadding(dimensionPixelOffset2, dimensionPixelOffset, dimensionPixelOffset2, dimensionPixelOffset);
//            this.tv_qrcode.setBackgroundResource(R.drawable.text_back);
//        }catch (Exception e){
//            e.printStackTrace();
//            Log.e(TAG, "setModePhoto  : "+e.getMessage());
//
//
//        }
//
//    }
//
//    public void setModeQRCode() {
//        long j;
//        lockDrawer();
//        this.scannerMode = true;
//        closePopup();
//        if (this.preview.getCameraId() != 0) {
//            this.preview.setCamera(0);
//            j = UPDATE_INTERVAL_IN_MILLISECONDS;
//        } else {
//            j = 0;
//        }
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                MainActivity.this.scannerView.setVisibility(View.VISIBLE);
//                MainActivity.this.mTopScreenPannel.setVisibility(View.GONE);
//                MainActivity.this.rl_btn_layout.setVisibility(View.GONE);
//                MainActivity.this.previewlay.setVisibility(View.GONE);
//                MainActivity.this.mapfragmentlay.setVisibility(View.GONE);
//                MainActivity.this.preview.onPause();
//                MainActivity.this.mCodeScanner.startPreview();
//                int dimensionPixelOffset = MainActivity.this.getResources().getDimensionPixelOffset(R.dimen._4dp);
//                int dimensionPixelOffset2 = MainActivity.this.getResources().getDimensionPixelOffset(R.dimen._12dp);
//                MainActivity.this.tv_qrcode.setTextColor(MainActivity.this.getResources().getColor(R.color._262626));
//                MainActivity.this.tv_video.setTextColor(MainActivity.this.getResources().getColor(R.color._262626));
//                MainActivity.this.tv_photo.setTextColor(MainActivity.this.getResources().getColor(R.color.white));
//                RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
//                layoutParams.addRule(14, -1);
//                layoutParams.addRule(15);
//                MainActivity.this.tv_qrcode.setLayoutParams(layoutParams);
//                MainActivity.this.tv_qrcode.setPadding(dimensionPixelOffset2, dimensionPixelOffset, dimensionPixelOffset2, dimensionPixelOffset);
//                MainActivity.this.tv_qrcode.setPadding(dimensionPixelOffset2, dimensionPixelOffset, dimensionPixelOffset2, dimensionPixelOffset);
//                MainActivity.this.tv_qrcode.setBackgroundResource(R.drawable.yellow_rect);
//
//                RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
//                layoutParams2.setMargins(0, 0, dimensionPixelOffset2, 0);
//                layoutParams2.addRule(0, R.id.tv_qrcode);
//                layoutParams2.addRule(15);
//                MainActivity.this.tv_photo.setLayoutParams(layoutParams2);
//                MainActivity.this.tv_photo.setPadding(dimensionPixelOffset2, dimensionPixelOffset, dimensionPixelOffset2, dimensionPixelOffset);
//                MainActivity.this.tv_photo.setBackgroundResource(R.drawable.text_back);
//            }
//        }, j);
//    }
//
//    public void setModeVideo() {
//        try {
//            lockDrawer(); // Assuming you have this method to lock the drawer for video mode
//            this.scannerMode = false; // Adjust this based on your logic
//            closePopup(); // Close any popup if open
//            this.scannerView.setVisibility(View.GONE); // Hide scanner view
//            this.mCodeScanner.releaseResources(); // Release scanner resources
//            this.mTopScreenPannel.setVisibility(View.VISIBLE); // Show top screen panel
//            this.rl_btn_layout.setVisibility(View.VISIBLE); // Show button layout
//            this.previewlay.setVisibility(View.VISIBLE); // Show preview layout
//            this.mapfragmentlay.setVisibility(View.VISIBLE); // Show map fragment layout
//            this.preview.onResume(); // Resume preview
//
//            int dimensionPixelOffset = getResources().getDimensionPixelOffset(R.dimen._4dp);
//            int dimensionPixelOffset2 = getResources().getDimensionPixelOffset(R.dimen._12dp);
//
//            // Update TextView colors
//            this.tv_qrcode.setTextColor(getResources().getColor(R.color._262626));
//            this.tv_photo.setTextColor(getResources().getColor(R.color._262626));
//            this.tv_video.setTextColor(getResources().getColor(R.color.white));
//
//            // Set up layout parameters for tv_video
//            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(
//                    RelativeLayout.LayoutParams.WRAP_CONTENT,
//                    RelativeLayout.LayoutParams.WRAP_CONTENT
//            );
//            layoutParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
//            layoutParams.addRule(RelativeLayout.ALIGN_PARENT_END);
//            this.tv_video.setLayoutParams(layoutParams);
//            this.tv_video.setPadding(dimensionPixelOffset2, dimensionPixelOffset, dimensionPixelOffset2, dimensionPixelOffset);
//            this.tv_video.setBackgroundResource(R.drawable.yellow_rect);
//
//            // Set up layout parameters for tv_photo
//            RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(
//                    RelativeLayout.LayoutParams.WRAP_CONTENT,
//                    RelativeLayout.LayoutParams.WRAP_CONTENT
//            );
//            layoutParams2.setMargins(dimensionPixelOffset2, 0, 0, 0);
//            layoutParams2.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
//            layoutParams2.addRule(RelativeLayout.START_OF, R.id.tv_video);
//            this.tv_photo.setLayoutParams(layoutParams2);
//            this.tv_photo.setPadding(dimensionPixelOffset2, dimensionPixelOffset, dimensionPixelOffset2, dimensionPixelOffset);
//            this.tv_photo.setBackgroundResource(R.drawable.text_back);
//
//            // Set up layout parameters for tv_qrcode
//            RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(
//                    RelativeLayout.LayoutParams.WRAP_CONTENT,
//                    RelativeLayout.LayoutParams.WRAP_CONTENT
//            );
//            layoutParams3.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
//            layoutParams3.addRule(RelativeLayout.START_OF, R.id.tv_photo);
//            this.tv_qrcode.setLayoutParams(layoutParams3);
//            this.tv_qrcode.setPadding(dimensionPixelOffset2, dimensionPixelOffset, dimensionPixelOffset2, dimensionPixelOffset);
//            this.tv_qrcode.setBackgroundResource(R.drawable.text_back);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            Log.e(TAG, "setModeVideo : " + e.getMessage());
//        }
//    }

    public enum SystemOrientation {
        LANDSCAPE, PORTRAIT, REVERSE_LANDSCAPE
    }

    public static final boolean lock_to_landscape = false;
    private boolean has_cached_system_orientation;
    private SystemOrientation cached_system_orientation;

    public SystemOrientation getSystemOrientation() {
        if (lock_to_landscape) {
            return SystemOrientation.LANDSCAPE;
        }
        if (has_cached_system_orientation) {
            return cached_system_orientation;
        }
        SystemOrientation result;
        int system_orientation = getResources().getConfiguration().orientation;
        if (MyDebug.LOG) Log.d(TAG, "system orientation: " + system_orientation);
        switch (system_orientation) {
            case Configuration.ORIENTATION_LANDSCAPE:
                result = SystemOrientation.LANDSCAPE;
                // now try to distinguish between landscape and reverse landscape
                // check whether the display matches the landscape configuration, in case this is inconsistent?
                Point display_size = new Point();
                Display display = getWindowManager().getDefaultDisplay();
                display.getSize(display_size);
                if (display_size.x>display_size.y) {
                    int rotation = getWindowManager().getDefaultDisplay().getRotation();
                    if (MyDebug.LOG) Log.d(TAG, "rotation: " + rotation);
                    switch (rotation) {
                        case Surface.ROTATION_0:
                        case Surface.ROTATION_90:
                            // landscape
                            if (MyDebug.LOG) Log.d(TAG, "landscape");
                            break;
                        case Surface.ROTATION_180:
                        case Surface.ROTATION_270:
                            // reverse landscape
                            if (MyDebug.LOG) Log.d(TAG, "reverse landscape");
                            result = SystemOrientation.REVERSE_LANDSCAPE;
                            break;
                        default:
                            if (MyDebug.LOG) Log.e(TAG, "unknown rotation: " + rotation);
                            break;
                    }
                } else {
                    if (MyDebug.LOG) Log.e(TAG, "display size not landscape: " + display_size);
                }
                break;
            case Configuration.ORIENTATION_PORTRAIT:
                result = SystemOrientation.PORTRAIT;
                break;
            case Configuration.ORIENTATION_SQUARE:
            case Configuration.ORIENTATION_UNDEFINED:
            default:
                if (MyDebug.LOG) Log.e(TAG, "unknown system orientation: " + system_orientation);
                result = SystemOrientation.LANDSCAPE;
                break;
        }
        if (MyDebug.LOG) Log.d(TAG, "system orientation is now: " + result);
        this.has_cached_system_orientation = true;
        this.cached_system_orientation = result;
        return result;
    }

    private void setScanner() {
        GpCodeScanner gpCodeScanner = new GpCodeScanner(this, this.scannerView);
        this.mCodeScanner = gpCodeScanner;
        gpCodeScanner.setDecodeCallback(new DecodeCallback() {
            @Override
            public void onDecoded(final Result result) {
                CameraMainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        CameraMainActivity.this.showDialogForScanner(result.getText());
                    }
                });
            }
        });
    }

    public void showDialogForScanner(final String str) {
        if (str == null || str.isEmpty()) {
            return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AlertDialogCustom);
        View inflate = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.scanner_result_layout, (ViewGroup) null);
        builder.setView(inflate);
        builder.setCancelable(true);
        AlertDialog create = builder.create();
        this.resultDialog = create;
        if (!create.isShowing()) {
            this.resultDialog.show();
        }
        this.resultDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        Matcher matcher = Patterns.WEB_URL.matcher(str);
        final String extractUrls = extractUrls(str);
        TextView textView = (TextView) inflate.findViewById(R.id.tv_scresult);
        TextView textView2 = (TextView) inflate.findViewById(R.id.btn_openlink);
        TextView textView3 = (TextView) inflate.findViewById(R.id.btn_close);
        ImageView imageView = (ImageView) inflate.findViewById(R.id.iv_copytext);
        textView.setText(str);
        Linkify.addLinks(textView, 1);
        textView.setLinkTextColor(ContextCompat.getColor(this, R.color._0086ff));
        if (!matcher.find()) {
            textView2.setVisibility(View.GONE);
        }
        textView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CameraMainActivity.this.resultDialog.dismiss();

                try {

                    CameraMainActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(extractUrls)));
                } catch (ActivityNotFoundException unused) {
                    CameraMainActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(extractUrls)));
                }
            }
        });
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((ClipboardManager) CameraMainActivity.this.getSystemService(Context.CLIPBOARD_SERVICE)).setText(str);
                Toast.makeText(CameraMainActivity.this, "Copied to clipboard", Toast.LENGTH_SHORT).show();
            }
        });
        textView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CameraMainActivity.this.resultDialog.dismiss();
            }
        });
        this.resultDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                CameraMainActivity.this.mCodeScanner.startPreview();
            }
        });
    }

    public static String extractUrls(String str) {
        ArrayList arrayList = new ArrayList();
        String[] split = str.split("\\s+");
        Pattern pattern = Patterns.WEB_URL;
        for (String str2 : split) {
            if (pattern.matcher(str2).find()) {
                if (!str2.toLowerCase().contains("http://") && !str2.toLowerCase().contains("https://")) {
                    str2 = "http://" + str2;
                }
                arrayList.add(str2);
            }
        }
        return arrayList.size()>0 ? (String) arrayList.get(0) : "";
    }

    public void blinkAnimation() {
        Animation loadAnimation = AnimationUtils.loadAnimation(this, R.anim.fade_out_half);
        this.fadeOut = loadAnimation;
        loadAnimation.setAnimationListener(this.fadeOutListener);
        Animation loadAnimation2 = AnimationUtils.loadAnimation(this, R.anim.fade_in_half);
        this.fadeIn = loadAnimation2;
        loadAnimation2.setAnimationListener(this.fadeInListener);
        this.rlCaptureBlink.startAnimation(this.fadeIn);
    }
}
