package com.live.gpsmap.camera.Fragment;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.live.gpsmap.camera.Adapter.Notes_adapter;
import com.live.gpsmap.camera.Database.DateTimeDB;
import com.live.gpsmap.camera.Interface.OnRecyclerItemClickListener;
import com.live.gpsmap.camera.Model.NotesModal;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Default;
import com.live.gpsmap.camera.Utils.SP;

import java.util.ArrayList;

/* loaded from: classes2.dex */
public class Note_bottom_sheetfragment extends BottomSheetDialogFragment {
    public static final String TAG = "Note_bottom_sheetfragment";
    ArrayList<NotesModal> Note_list = new ArrayList<>();
    TextView btn_add;
    ImageView btn_clearnote;
    ImageView btn_cleartitle;
    Context context;
    DateTimeDB dateTimeDB;
    EditText mEd_notes;
    EditText mEd_title;
    SP mSP;
    Notes_adapter notes_adapter;
    Onselectitem onselectitem;
    RecyclerView rv_notes;

    /* loaded from: classes2.dex */
    public interface Onselectitem {
        void Onselect();
    }

    public void setOnselectitem(Onselectitem onselectitem) {
        this.onselectitem = onselectitem;
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @SuppressLint("RestrictedApi")
    @Override // androidx.appcompat.app.AppCompatDialogFragment, androidx.fragment.app.DialogFragment
    public void setupDialog(Dialog dialog, int i) {
        super.setupDialog(dialog, i);
        View inflate = View.inflate(getContext(), R.layout.note_bottom_sheet_fragment, null);
        this.btn_add = (TextView) inflate.findViewById(R.id.btn_add);
        this.btn_clearnote = (ImageView) inflate.findViewById(R.id.btn_clearnote);
        this.btn_cleartitle = (ImageView) inflate.findViewById(R.id.btn_cleartitle);
        this.mEd_notes = (EditText) inflate.findViewById(R.id.mEd_notes);
        this.mEd_title = (EditText) inflate.findViewById(R.id.mEd_title);
        this.rv_notes = (RecyclerView) inflate.findViewById(R.id.rv_notes);
        this.context = inflate.getContext();
        dialog.setContentView(inflate);
        this.dateTimeDB = new DateTimeDB(this.context);
        this.mSP = new SP(getContext());
        init();
        setadapter();
    }

    private void setadapter() {
        this.rv_notes.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, true));
        Notes_adapter notes_adapter = new Notes_adapter(getContext(), this.Note_list, new OnRecyclerItemClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.Note_bottom_sheetfragment.1
            @Override // com.gpsmapcamera.geotagginglocationonphoto.interfaces.OnRecyclerItemClickListener
            public void OnClick_(int i, View view) {
                NotesModal notesModal = Note_bottom_sheetfragment.this.Note_list.get(i);
                SP sp = Note_bottom_sheetfragment.this.mSP;
                Context context = Note_bottom_sheetfragment.this.getContext();
                sp.setString(context, "notes", notesModal.getTiitle() + " " + notesModal.getNotes());
                Note_bottom_sheetfragment.this.onselectitem.Onselect();
                Note_bottom_sheetfragment.this.dismiss();
            }

            @Override // com.gpsmapcamera.geotagginglocationonphoto.interfaces.OnRecyclerItemClickListener
            public void OnLongClick_(final int i, View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Note_bottom_sheetfragment.this.getActivity());
                builder.setTitle(Note_bottom_sheetfragment.this.getString(R.string.delete));
                builder.setMessage(Note_bottom_sheetfragment.this.getString(R.string.delete_note_msg));
                builder.setPositiveButton(Note_bottom_sheetfragment.this.getString(R.string.yes), new DialogInterface.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.Note_bottom_sheetfragment.1.1
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        Note_bottom_sheetfragment.this.dateTimeDB.deleteNote(Note_bottom_sheetfragment.this.Note_list.get(i).getID());
                        Note_bottom_sheetfragment.this.refrecedata();
                        dialogInterface.dismiss();
                    }
                });
                builder.setNegativeButton(Note_bottom_sheetfragment.this.getString(R.string.no), new DialogInterface.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.Note_bottom_sheetfragment.1.2
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        dialogInterface.dismiss();
                    }
                });
                builder.create().show();
            }
        });
        this.notes_adapter = notes_adapter;
        this.rv_notes.setAdapter(notes_adapter);
    }

    public void refrecedata() {
        this.Note_list.clear();
        this.Note_list = this.dateTimeDB.getNotes();
        String string = this.mSP.getString(getContext(), "notes", Default.notes);
        boolean z = true;
        for (int i = 0; i < this.Note_list.size(); i++) {
            NotesModal notesModal = this.Note_list.get(i);
            if (string.equals(notesModal.getTiitle() + " " + notesModal.getNotes())) {
                notesModal.setSelected(1);
                z = false;
            } else {
                notesModal.setSelected(0);
            }
        }
        if (z && this.Note_list.size() > 0) {
            this.Note_list.get(0).setSelected(1);
        }
        this.notes_adapter.refreceadapter(this.Note_list);
    }

    private void init() {
        this.btn_add.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.Note_bottom_sheetfragment.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (!Note_bottom_sheetfragment.this.mEd_title.getText().toString().trim().equals("") || !Note_bottom_sheetfragment.this.mEd_notes.getText().toString().trim().equals("")) {
                    String trim = Note_bottom_sheetfragment.this.mEd_notes.getText().toString().trim();
                    String trim2 = Note_bottom_sheetfragment.this.mEd_title.getText().toString().trim();
                    for (int i = 0; i < Note_bottom_sheetfragment.this.Note_list.size(); i++) {
                        if (Note_bottom_sheetfragment.this.Note_list.get(i).getNotes().trim().equalsIgnoreCase(trim)) {
                            Note_bottom_sheetfragment.this.mEd_notes.setFocusableInTouchMode(true);
                            Note_bottom_sheetfragment.this.mEd_notes.setError(Note_bottom_sheetfragment.this.getString(R.string.note_exist));
                            Note_bottom_sheetfragment.this.mEd_notes.requestFocus();
                            return;
                        }
                    }
                    Note_bottom_sheetfragment.this.dateTimeDB.insetNote(trim, trim2);
                    Note_bottom_sheetfragment.this.Note_list.clear();
                    Note_bottom_sheetfragment note_bottom_sheetfragment = Note_bottom_sheetfragment.this;
                    note_bottom_sheetfragment.Note_list = note_bottom_sheetfragment.dateTimeDB.getNotes();
                    for (int i2 = 0; i2 < Note_bottom_sheetfragment.this.Note_list.size(); i2++) {
                        if (Note_bottom_sheetfragment.this.Note_list.size() - 1 == i2) {
                            Note_bottom_sheetfragment.this.Note_list.get(i2).setSelected(1);
                        } else {
                            Note_bottom_sheetfragment.this.Note_list.get(i2).setSelected(0);
                        }
                    }
                    NotesModal notesModal = Note_bottom_sheetfragment.this.Note_list.get(Note_bottom_sheetfragment.this.Note_list.size() - 1);
                    SP sp = Note_bottom_sheetfragment.this.mSP;
                    Context context = Note_bottom_sheetfragment.this.getContext();
                    sp.setString(context, "notes", notesModal.getTiitle() + " " + notesModal.getNotes());
                    Note_bottom_sheetfragment.this.onselectitem.Onselect();
                    Note_bottom_sheetfragment.this.dismiss();
                    return;
                }
                Toast.makeText(Note_bottom_sheetfragment.this.getActivity(), "please enter any one from title or note", Toast.LENGTH_LONG).show();
            }
        });
        this.btn_clearnote.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.Note_bottom_sheetfragment.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Note_bottom_sheetfragment.this.mEd_notes.setText("");
            }
        });
        this.btn_cleartitle.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.Note_bottom_sheetfragment.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Note_bottom_sheetfragment.this.mEd_title.setText("");
            }
        });
        this.Note_list = this.dateTimeDB.getNotes();
        String string = this.mSP.getString(getContext(), "notes", Default.notes);
        boolean z = true;
        for (int i = 0; i < this.Note_list.size(); i++) {
            NotesModal notesModal = this.Note_list.get(i);
            if (string.equals(notesModal.getTiitle() + " " + notesModal.getNotes())) {
                notesModal.setSelected(1);
                this.mEd_title.setText(notesModal.getTiitle());
                this.mEd_notes.setText(notesModal.getNotes());
                z = false;
            } else {
                notesModal.setSelected(0);
            }
        }
        if (!z || this.Note_list.size() <= 0) {
            return;
        }
        this.Note_list.get(0).setSelected(1);
        this.mEd_title.setText(this.Note_list.get(0).getTiitle());
        this.mEd_notes.setText(this.Note_list.get(0).getNotes());
    }
}