package com.live.gpsmap.camera.Camera;

/* loaded from: classes.dex */
public class MyDebug {
    public static final boolean LOG = true;
}
