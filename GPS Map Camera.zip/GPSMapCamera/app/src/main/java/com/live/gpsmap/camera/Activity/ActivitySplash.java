package com.live.gpsmap.camera.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.live.gpsmap.camera.Camera.CameraMainActivity;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.databinding.ActivitySplashBinding;

public class ActivitySplash extends AppCompatActivity {
    ActivitySplashBinding binding;
    SP sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        sp = new SP(this);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                continueExecution();
            }
        }, 5000);

    }

    private void continueExecution() {
        int integer = this.sp.getInteger(this, SP.LANGUAGE_COUNT, 0);
        boolean z = this.sp.getBoolean(this, SP.ALL_PERMISSION_ACCESS, false);
        boolean z2 = this.sp.getBoolean(this, SP.INAPP_FEATURES, false);
        Intent intent;

        if (integer == 0){
            intent = new Intent(this, ActivityLanguageSelection.class);
        }else {
            if (z) {
                if (z2) {
                    intent = new Intent(this, CameraMainActivity.class);
                } else {
                    intent = new Intent(this, ActivityAppFeatures.class);
                }
            } else if (checkCameraPermission() && checkLocationPermission() && checkStoragePermission()) {
                intent = new Intent(this, CameraMainActivity.class);
            } else {
                intent = new Intent(this, ActivityPermission.class);
            }
        }

        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);
        finish();


    }
    private boolean checkLocationPermission() {
        boolean z = ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0;
        if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") != 0) {
            return false;
        }
        return z;
    }

    private boolean checkStoragePermission() {
        boolean z = ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0;
        if (ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            return false;
        }
        return z;
    }

    private boolean checkCameraPermission() {
        return ContextCompat.checkSelfPermission(this, "android.permission.CAMERA") == 0;
    }
}