package com.live.gpsmap.camera.os_notifications;

/* loaded from: classes2.dex */
public interface OfferDialogBtnClickListener {
    void onOfferBtnClicked();
}
