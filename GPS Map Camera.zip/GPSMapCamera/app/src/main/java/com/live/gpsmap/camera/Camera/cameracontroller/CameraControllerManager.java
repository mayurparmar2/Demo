package com.live.gpsmap.camera.Camera.cameracontroller;

import android.content.Context;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraController;

public abstract class CameraControllerManager {
    public abstract String getDescription(Context context, int i);

    public abstract CameraController.Facing getFacing(int i);

    public abstract int getNumberOfCameras();
}
