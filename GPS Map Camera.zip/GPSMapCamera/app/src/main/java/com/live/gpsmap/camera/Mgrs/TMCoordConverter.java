package com.live.gpsmap.camera.Mgrs;


/* loaded from: classes.dex */
class TMCoordConverter {
    private static final double MAX_DELTA_LONG = 1.5707963267948966d;
    private static final double MAX_LAT = 1.570621793869697d;
    private static final double MAX_SCALE_FACTOR = 3.0d;
    private static final double MIN_SCALE_FACTOR = 0.3d;
    private static final double PI = 3.141592653589793d;
    public static final double PI_OVER = 1.5707963267948966d;
    private static final int TRANMERC_A_ERROR = 64;
    private static final int TRANMERC_CENT_MER_ERROR = 32;
    public static final int TRANMERC_EASTING_ERROR = 4;
    private static final int TRANMERC_INV_F_ERROR = 128;
    private static final int TRANMERC_LAT_ERROR = 1;
    private static final int TRANMERC_LON_ERROR = 2;
    public static final int TRANMERC_LON_WARNING = 512;
    public static final int TRANMERC_NORTHING_ERROR = 8;
    public static final int TRANMERC_NO_ERROR = 0;
    private static final int TRANMERC_ORIGIN_LAT_ERROR = 16;
    private static final int TRANMERC_SCALE_FACTOR_ERROR = 256;
    private double Easting;
    private double Latitude;
    private double Longitude;
    private double Northing;
    private double TranMerc_Delta_Easting = 4.0E7d;
    private double TranMerc_Delta_Northing = 4.0E7d;
    private double TranMerc_False_Easting = 0.0d;
    private double TranMerc_False_Northing = 0.0d;
    private double TranMerc_Origin_Lat = 0.0d;
    private double TranMerc_Origin_Long = 0.0d;
    private double TranMerc_Scale_Factor = 1.0d;
    private double TranMerc_a = 6378137.0d;
    private double TranMerc_ap = 6367449.1458008d;
    private double TranMerc_bp = 16038.508696861d;
    private double TranMerc_cp = 16.832613334334d;
    private double TranMerc_dp = 0.021984404273757d;
    private double TranMerc_ebs = 0.0067394967565869d;
    private double TranMerc_ep = 3.1148371319283E-5d;
    private double TranMerc_es = 0.00669437999014138d;
    private double TranMerc_f = 0.0033528106647474805d;

    public double getA() {
        return this.TranMerc_a;
    }

    public double getF() {
        return this.TranMerc_f;
    }

    public long setTransverseMercatorParameters(double d, double d2, double d3, double d4, double d5, double d6, double d7) {
        double d8 = 1.0d / d2;
        long j = d <= 0.0d ? 64L : 0L;
        if (d8 < 250.0d || d8 > 350.0d) {
            j |= 128;
        }
        if (d3 < -1.570621793869697d || d3 > MAX_LAT) {
            j |= 16;
        }
        if (d4 < -3.141592653589793d || d4 > 6.283185307179586d) {
            j |= 32;
        }
        if (d7 < MIN_SCALE_FACTOR || d7 > MAX_SCALE_FACTOR) {
            j |= 256;
        }
        if (j == 0) {
            this.TranMerc_a = d;
            this.TranMerc_f = d2;
            this.TranMerc_Origin_Lat = 0.0d;
            this.TranMerc_Origin_Long = 0.0d;
            this.TranMerc_False_Northing = 0.0d;
            this.TranMerc_False_Easting = 0.0d;
            this.TranMerc_Scale_Factor = 1.0d;
            double d9 = (d2 * 2.0d) - (d2 * d2);
            this.TranMerc_es = d9;
            this.TranMerc_ebs = (1.0d / (1.0d - d9)) - 1.0d;
            double d10 = d * (1.0d - d2);
            double d11 = (d - d10) / (d10 + d);
            double d12 = d11 * d11;
            double d13 = d12 * d11;
            double d14 = d13 * d11;
            double d15 = d14 * d11;
            double d16 = d12 - d13;
            double d17 = d14 - d15;
            this.TranMerc_ap = ((1.0d - d11) + ((5.0d * d16) / 4.0d) + ((81.0d * d17) / 64.0d)) * d;
            double d18 = d13 - d14;
            this.TranMerc_bp = ((d * MAX_SCALE_FACTOR) * (((d11 - d12) + ((7.0d * d18) / 8.0d)) + ((55.0d * d15) / 64.0d))) / 2.0d;
            this.TranMerc_cp = ((15.0d * d) * (d16 + ((MAX_SCALE_FACTOR * d17) / 4.0d))) / 16.0d;
            this.TranMerc_dp = ((35.0d * d) * (d18 + ((d15 * 11.0d) / 16.0d))) / 48.0d;
            this.TranMerc_ep = ((d * 315.0d) * d17) / 512.0d;
            convertGeodeticToTransverseMercator(MAX_LAT, 1.5707963267948966d);
            this.TranMerc_Delta_Easting = getEasting();
            this.TranMerc_Delta_Northing = getNorthing();
            convertGeodeticToTransverseMercator(0.0d, 1.5707963267948966d);
            this.TranMerc_Delta_Easting = getEasting();
            this.TranMerc_Origin_Lat = d3;
            this.TranMerc_Origin_Long = d4 > 3.141592653589793d ? d4 - 6.283185307179586d : d4;
            this.TranMerc_False_Northing = d6;
            this.TranMerc_False_Easting = d5;
            this.TranMerc_Scale_Factor = d7;
        }
        return j;
    }

    public long convertGeodeticToTransverseMercator(double d, double d2) {
        long j = (d < -1.570621793869697d || d > MAX_LAT) ? 1L : 0L;
        double d3 = d2 > 3.141592653589793d ? d2 - 6.283185307179586d : d2;
        double d4 = this.TranMerc_Origin_Long;
        if (d3 < d4 - 1.5707963267948966d || d3 > d4 + 1.5707963267948966d) {
            double d5 = d3 < 0.0d ? d3 + 6.283185307179586d : d3;
            double d6 = d4 < 0.0d ? d4 + 6.283185307179586d : d4;
            if (d5 < d6 - 1.5707963267948966d || d5 > d6 + 1.5707963267948966d) {
                j |= 2;
            }
        }
        if (j != 0) {
            return j;
        }
        double d7 = d3 - d4;
        if (Math.abs(d7) > 0.15707963267948966d) {
            j |= 512;
        }
        if (d7 > 3.141592653589793d) {
            d7 -= 6.283185307179586d;
        }
        if (d7 < -3.141592653589793d) {
            d7 += 6.283185307179586d;
        }
        if (Math.abs(d7) < 2.0E-10d) {
            d7 = 0.0d;
        }
        double sin = Math.sin(d);
        double cos = Math.cos(d);
        double d8 = cos * cos;
        double d9 = d8 * cos;
        double d10 = d9 * d8;
        double d11 = d10 * d8;
        double tan = Math.tan(d);
        double d12 = tan * tan;
        double d13 = d12 * tan * tan;
        double d14 = d13 * tan * tan;
        long j2 = j;
        double d15 = this.TranMerc_ebs * d8;
        double d16 = d15 * d15;
        double d17 = d16 * d15;
        double d18 = d17 * d15;
        double sqrt = this.TranMerc_a / Math.sqrt(1.0d - (this.TranMerc_es * Math.pow(Math.sin(d), 2.0d)));
        double d19 = sin * sqrt;
        double d20 = 58.0d * d12;
        double d21 = this.TranMerc_False_Northing;
        double sin2 = ((((this.TranMerc_ap * d) - (this.TranMerc_bp * Math.sin(d * 2.0d))) + (this.TranMerc_cp * Math.sin(d * 4.0d))) - (this.TranMerc_dp * Math.sin(d * 6.0d))) + (this.TranMerc_ep * Math.sin(d * 8.0d));
        double d22 = this.TranMerc_ap;
        double d23 = this.TranMerc_Origin_Lat;
        double sin3 = d21 + ((sin2 - (((((d22 * d23) - (this.TranMerc_bp * Math.sin(d23 * 2.0d))) + (this.TranMerc_cp * Math.sin(this.TranMerc_Origin_Lat * 4.0d))) - (this.TranMerc_dp * Math.sin(this.TranMerc_Origin_Lat * 6.0d))) + (this.TranMerc_ep * Math.sin(this.TranMerc_Origin_Lat * 8.0d)))) * this.TranMerc_Scale_Factor) + (Math.pow(d7, 2.0d) * (((d19 * cos) * this.TranMerc_Scale_Factor) / 2.0d)) + (Math.pow(d7, 4.0d) * ((((d19 * d9) * this.TranMerc_Scale_Factor) * (((5.0d - d12) + (9.0d * d15)) + (d16 * 4.0d))) / 24.0d)) + (Math.pow(d7, 6.0d) * ((((d19 * d10) * this.TranMerc_Scale_Factor) * ((((((((((61.0d - d20) + d13) + (270.0d * d15)) - ((330.0d * d12) * d15)) + (445.0d * d16)) + (324.0d * d17)) - ((680.0d * d12) * d16)) + (88.0d * d18)) - ((600.0d * d12) * d17)) - ((192.0d * d12) * d18))) / 720.0d));
        double pow = Math.pow(d7, 8.0d);
        double d24 = d19 * d11;
        double d25 = this.TranMerc_Scale_Factor;
        this.Northing = sin3 + (pow * (((d24 * d25) * (((1385.0d - (3111.0d * d12)) + (543.0d * d13)) - d14)) / 40320.0d));
        this.Easting = this.TranMerc_False_Easting + (cos * sqrt * d25 * d7) + (Math.pow(d7, MAX_SCALE_FACTOR) * ((((sqrt * d9) * this.TranMerc_Scale_Factor) * ((1.0d - d12) + d15)) / 6.0d)) + (Math.pow(d7, 5.0d) * ((((sqrt * d10) * this.TranMerc_Scale_Factor) * ((((((((5.0d - (18.0d * d12)) + d13) + (14.0d * d15)) - (d20 * d15)) + (13.0d * d16)) + (4.0d * d17)) - ((64.0d * d12) * d16)) - ((24.0d * d12) * d17))) / 120.0d)) + (Math.pow(d7, 7.0d) * ((((sqrt * d11) * this.TranMerc_Scale_Factor) * (((61.0d - (d12 * 479.0d)) + (d13 * 179.0d)) - d14)) / 5040.0d));
        return j2;
    }

    public double getEasting() {
        return this.Easting;
    }

    public double getNorthing() {
        return this.Northing;
    }

    public long convertTransverseMercatorToGeodetic(double d, double d2) {
        double d3 = this.TranMerc_False_Easting;
        double d4 = this.TranMerc_Delta_Easting;
        long j = (d < d3 - d4 || d > d3 + d4) ? 4L : 0L;
        double d5 = this.TranMerc_False_Northing;
        double d6 = this.TranMerc_Delta_Northing;
        if (d2 < d5 - d6 || d2 > d5 + d6) {
            j |= 8;
        }
        if (j == 0) {
            double d7 = this.TranMerc_ap;
            double d8 = this.TranMerc_Origin_Lat;
            double d9 = 2.0d;
            double sin = ((((d7 * d8) - (this.TranMerc_bp * Math.sin(d8 * 2.0d))) + (this.TranMerc_cp * Math.sin(this.TranMerc_Origin_Lat * 4.0d))) - (this.TranMerc_dp * Math.sin(this.TranMerc_Origin_Lat * 6.0d))) + (this.TranMerc_ep * Math.sin(this.TranMerc_Origin_Lat * 8.0d)) + ((d2 - this.TranMerc_False_Northing) / this.TranMerc_Scale_Factor);
            double d10 = this.TranMerc_a;
            double d11 = this.TranMerc_es;
            double d12 = 0.0d;
            double pow = sin / ((d10 * (1.0d - d11)) / Math.pow(Math.sqrt(1.0d - (d11 * Math.pow(Math.sin(0.0d), 2.0d))), MAX_SCALE_FACTOR));
            int i = 0;
            while (i < 5) {
                double sin2 = sin - (((((this.TranMerc_ap * pow) - (this.TranMerc_bp * Math.sin(pow * d9))) + (this.TranMerc_cp * Math.sin(pow * 4.0d))) - (this.TranMerc_dp * Math.sin(pow * 6.0d))) + (this.TranMerc_ep * Math.sin(pow * 8.0d)));
                double d13 = this.TranMerc_a;
                double d14 = this.TranMerc_es;
                pow += sin2 / ((d13 * (1.0d - d14)) / Math.pow(Math.sqrt(1.0d - (d14 * Math.pow(Math.sin(pow), 2.0d))), MAX_SCALE_FACTOR));
                i++;
                sin = sin;
                j = j;
                d9 = 2.0d;
            }
            long j2 = j;
            double d15 = this.TranMerc_a;
            double d16 = this.TranMerc_es;
            double pow2 = (d15 * (1.0d - d16)) / Math.pow(Math.sqrt(1.0d - (d16 * Math.pow(Math.sin(pow), 2.0d))), MAX_SCALE_FACTOR);
            double sqrt = this.TranMerc_a / Math.sqrt(1.0d - (this.TranMerc_es * Math.pow(Math.sin(pow), 2.0d)));
            double cos = Math.cos(pow);
            double tan = Math.tan(pow);
            double d17 = tan * tan;
            double d18 = d17 * d17;
            double d19 = pow;
            double pow3 = this.TranMerc_ebs * Math.pow(cos, 2.0d);
            double d20 = pow3 * pow3;
            double d21 = d20 * pow3;
            double d22 = d21 * pow3;
            double d23 = d - this.TranMerc_False_Easting;
            if (Math.abs(d23) >= 1.0E-4d) {
                d12 = d23;
            }
            double pow4 = tan / (((pow2 * 2.0d) * sqrt) * Math.pow(this.TranMerc_Scale_Factor, 2.0d));
            double pow5 = ((((((d17 * MAX_SCALE_FACTOR) + 5.0d) + pow3) - (Math.pow(pow3, 2.0d) * 4.0d)) - ((9.0d * d17) * pow3)) * tan) / (((pow2 * 24.0d) * Math.pow(sqrt, MAX_SCALE_FACTOR)) * Math.pow(this.TranMerc_Scale_Factor, 4.0d));
            double d24 = d20 * MAX_SCALE_FACTOR;
            double pow6 = ((((((((((((((d17 * 90.0d) + 61.0d) + (46.0d * pow3)) + (45.0d * d18)) - ((252.0d * d17) * pow3)) - d24) + (100.0d * d21)) - ((66.0d * d17) * d20)) - ((90.0d * d18) * pow3)) + (88.0d * d22)) + ((225.0d * d18) * d20)) + ((84.0d * d17) * d21)) - ((192.0d * d17) * d22)) * tan) / (((pow2 * 720.0d) * Math.pow(sqrt, 5.0d)) * Math.pow(this.TranMerc_Scale_Factor, 6.0d));
            double pow7 = (((((3633.0d * d17) + 1385.0d) + (4095.0d * d18)) + (Math.pow(tan, 6.0d) * 1575.0d)) * tan) / (((pow2 * 40320.0d) * Math.pow(sqrt, 7.0d)) * Math.pow(this.TranMerc_Scale_Factor, 8.0d));
            double d25 = d12;
            this.Latitude = (((d19 - (Math.pow(d25, 2.0d) * pow4)) + (Math.pow(d25, 4.0d) * pow5)) - (Math.pow(d25, 6.0d) * pow6)) + (Math.pow(d25, 8.0d) * pow7);
            double pow8 = (((d25 * (1.0d / ((sqrt * cos) * this.TranMerc_Scale_Factor))) - (Math.pow(d25, MAX_SCALE_FACTOR) * ((((d17 * 2.0d) + 1.0d) + pow3) / (((Math.pow(sqrt, MAX_SCALE_FACTOR) * 6.0d) * cos) * Math.pow(this.TranMerc_Scale_Factor, MAX_SCALE_FACTOR))))) + (Math.pow(d25, 5.0d) * ((((((((((pow3 * 6.0d) + 5.0d) + (28.0d * d17)) - d24) + ((8.0d * d17) * pow3)) + (d18 * 24.0d)) - (d21 * 4.0d)) + ((4.0d * d17) * d20)) + ((24.0d * d17) * d21)) / (((Math.pow(sqrt, 5.0d) * 120.0d) * cos) * Math.pow(this.TranMerc_Scale_Factor, 5.0d))))) - (Math.pow(d25, 7.0d) * (((((d17 * 662.0d) + 61.0d) + (d18 * 1320.0d)) + (Math.pow(tan, 6.0d) * 720.0d)) / (((Math.pow(sqrt, 7.0d) * 5040.0d) * cos) * Math.pow(this.TranMerc_Scale_Factor, 7.0d))));
            this.Longitude = this.TranMerc_Origin_Long + pow8;
            long j3 = Math.abs(this.Latitude) > 1.5707963267948966d ? j2 | 8 : j2;
            double d26 = this.Longitude;
            if (d26 > 3.141592653589793d) {
                double d27 = d26 - 6.283185307179586d;
                this.Longitude = d27;
                if (Math.abs(d27) > 3.141592653589793d) {
                    j3 |= 4;
                }
            }
            if (Math.abs(pow8) > Math.cos(this.Latitude) * 0.15707963267948966d) {
                j3 |= 512;
            }
            return this.Latitude > 1.0E10d ? j3 | 512 : j3;
        }
        return j;
    }

    public double getLatitude() {
        return this.Latitude;
    }

    public double getLongitude() {
        return this.Longitude;
    }
}
