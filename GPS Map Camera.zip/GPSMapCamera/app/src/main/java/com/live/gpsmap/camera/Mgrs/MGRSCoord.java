package com.live.gpsmap.camera.Mgrs;


public class MGRSCoord {
    private final String MGRSString;
    private final Angle latitude;
    private final Angle longitude;

    public MGRSCoord(Angle angle0, Angle angle1, String s) {
        if (angle0 != null && angle1 != null) {
//            if (s != null) {
//                if (s.length() != 0) {
                    this.latitude = angle0;
                    this.longitude = angle1;
                    this.MGRSString = s;
                    return;
//                }

//                throw new IllegalArgumentException("String Is Empty");
//            }

//            throw new IllegalArgumentException("String Is Null");
        }
        throw new IllegalArgumentException("Latitude Or Longitude Is Null");
    }

    public static MGRSCoord fromLatLon(Angle angle0, Angle angle1) {
        return MGRSCoord.fromLatLon(angle0, angle1, 5);
    }

    public static MGRSCoord fromLatLon(Angle latitude, Angle longitude, int precision) {
        if (latitude == null || longitude == null) {
            throw new IllegalArgumentException("Latitude Or Longitude Is Null");
        }
        final MGRSCoordConverter converter = new MGRSCoordConverter();
        long err = converter.convertGeodeticToMGRS(latitude.radians, longitude.radians, precision);
//        if (err != MGRSCoordConverter.MGRS_NO_ERROR)
//        {
//            throw new IllegalArgumentException("MGRS Conversion Error");
//        }
        return new MGRSCoord(latitude, longitude, converter.getMGRSString());
    }

    public static MGRSCoord fromString(String s) {
//        if(s != null && s.length() != 0) {
        String s1 = s.toUpperCase().replaceAll(" ", "");
        MGRSCoordConverter mGRSCoordConverter0 = new MGRSCoordConverter();
        if (mGRSCoordConverter0.convertMGRSToGeodetic(s1) == 0L) {
            return new MGRSCoord(Angle.fromRadians(mGRSCoordConverter0.getLatitude()), Angle.fromRadians(mGRSCoordConverter0.getLongitude()), s1);
        }

//            throw new IllegalArgumentException("MGRS Conversion Error");
//        }
        return null;
//        throw new IllegalArgumentException("String Is Null");
    }

    public Angle getLatitude() {
        return this.latitude;
    }

    public Angle getLongitude() {
        return this.longitude;
    }

    @Override
    public String toString() {
        return this.MGRSString;
    }
}
