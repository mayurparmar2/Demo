package com.live.gpsmap.camera.Camera;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;
import java.util.ArrayList;

@SuppressWarnings("All")
public class SaveLocationHistory {
    private static final String TAG = "SaveLocationHistory";
    private final CameraMainActivity main_activity;
    private final String pref_base;
    private final ArrayList<String> save_location_history;

    /* JADX INFO: Access modifiers changed from: package-private */
    public SaveLocationHistory(CameraMainActivity mainActivity, String str, String str2) {
        ArrayList<String> arrayList = new ArrayList<>();
        this.save_location_history = arrayList;
        Log.d(TAG, "pref_base: " + str);
        this.main_activity = mainActivity;
        this.pref_base = str;
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(mainActivity);
        arrayList.clear();
        int i = defaultSharedPreferences.getInt(str + "_size", 0);
        Log.d(TAG, "save_location_history_size: " + i);
        for (int i2 = 0; i2 < i; i2++) {
            String string = defaultSharedPreferences.getString(str + "_" + i2, null);
            if (string != null) {
                Log.d(TAG, "save_location_history " + i2 + ": " + string);
                this.save_location_history.add(string);
            }
        }
        updateFolderHistory(str2, false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void updateFolderHistory(String str, boolean z) {
        updateFolderHistory(str);
        if (z) {
            this.main_activity.updateGalleryIcon();
        }
    }

    private void updateFolderHistory(String str) {
        Log.d(TAG, "updateFolderHistory: " + str);
        Log.d(TAG, "save_location_history size: " + this.save_location_history.size());
        for (int i = 0; i < this.save_location_history.size(); i++) {
            Log.d(TAG, this.save_location_history.get(i));
        }
        do {
        } while (this.save_location_history.remove(str));
        this.save_location_history.add(str);
        while (this.save_location_history.size() > 6) {
            this.save_location_history.remove(0);
        }
        writeSaveLocations();
        Log.d(TAG, "updateFolderHistory exit:");
        Log.d(TAG, "save_location_history size: " + this.save_location_history.size());
        for (int i2 = 0; i2 < this.save_location_history.size(); i2++) {
            Log.d(TAG, this.save_location_history.get(i2));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void clearFolderHistory(String str) {
        Log.d(TAG, "clearFolderHistory: " + str);
        this.save_location_history.clear();
        updateFolderHistory(str, true);
    }

    private void writeSaveLocations() {
        Log.d(TAG, "writeSaveLocations");
        SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(this.main_activity).edit();
        edit.putInt(this.pref_base + "_size", this.save_location_history.size());
        Log.d(TAG, "save_location_history_size = " + this.save_location_history.size());
        for (int i = 0; i < this.save_location_history.size(); i++) {
            edit.putString(this.pref_base + "_" + i, this.save_location_history.get(i));
        }
        edit.apply();
    }

    public int size() {
        return this.save_location_history.size();
    }

    public String get(int i) {
        return this.save_location_history.get(i);
    }

    public void remove(int i) {
        this.save_location_history.remove(i);
    }

    public void set(int i, String str) {
        this.save_location_history.set(i, str);
    }

    public boolean contains(String str) {
        return this.save_location_history.contains(str);
    }
}
