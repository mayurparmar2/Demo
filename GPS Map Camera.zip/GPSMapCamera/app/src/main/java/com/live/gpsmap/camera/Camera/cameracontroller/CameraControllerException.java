package com.live.gpsmap.camera.Camera.cameracontroller;

public class CameraControllerException extends Exception {
    private static final long serialVersionUID = 7904697847749213106L;
}
