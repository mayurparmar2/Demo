package com.live.gpsmap.camera.Camera.cameracontroller;

import android.hardware.camera2.DngCreator;
import android.media.Image;
import android.util.Log;
import java.io.IOException;
import java.io.OutputStream;

public class RawImage {
    private static final String TAG = "RawImage";
    private final DngCreator dngCreator;
    private final Image image;

    public RawImage(DngCreator dngCreator, Image image) {
        this.dngCreator = dngCreator;
        this.image = image;
    }

    public void writeImage(OutputStream outputStream) throws IOException {
        try {
            this.dngCreator.writeImage(outputStream, this.image);
        } catch (AssertionError e) {
            e.printStackTrace();
            throw new IOException();
        } catch (IllegalStateException e2) {
            e2.printStackTrace();
            throw new IOException();
        }
    }

    public void close() {
        Log.d(TAG, "close");
        this.image.close();
        this.dngCreator.close();
    }
}
