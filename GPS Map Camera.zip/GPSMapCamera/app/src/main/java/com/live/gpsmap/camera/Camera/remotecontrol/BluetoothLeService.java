package com.live.gpsmap.camera.Camera.remotecontrol;

import android.annotation.SuppressLint;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import androidx.work.WorkRequest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

@SuppressWarnings("All")
public class BluetoothLeService extends Service {
    public static final String ACTION_DATA_AVAILABLE = "net.sourceforge.opencamera.Remotecontrol.ACTION_DATA_AVAILABLE";
    public static final String ACTION_GATT_CONNECTED = "net.sourceforge.opencamera.Remotecontrol.ACTION_GATT_CONNECTED";
    public static final String ACTION_GATT_DISCONNECTED = "net.sourceforge.opencamera.Remotecontrol.ACTION_GATT_DISCONNECTED";
    public static final String ACTION_GATT_SERVICES_DISCOVERED = "net.sourceforge.opencamera.Remotecontrol.ACTION_GATT_SERVICES_DISCOVERED";
    public static final String ACTION_REMOTE_COMMAND = "net.sourceforge.opencamera.Remotecontrol.COMMAND";
    public static final String ACTION_SENSOR_VALUE = "net.sourceforge.opencamera.Remotecontrol.SENSOR";
    public static final int COMMAND_AFMF = 97;
    public static final int COMMAND_DOWN = 80;
    public static final int COMMAND_MENU = 48;
    public static final int COMMAND_MODE = 16;
    public static final int COMMAND_SHUTTER = 32;
    public static final int COMMAND_UP = 64;
    public static final String EXTRA_DATA = "net.sourceforge.opencamera.Remotecontrol.EXTRA_DATA";
    public static final String SENSOR_DEPTH = "net.sourceforge.opencamera.Remotecontrol.DEPTH";
    public static final String SENSOR_TEMPERATURE = "net.sourceforge.opencamera.Remotecontrol.TEMPERATURE";
    private static final String TAG = "BluetoothLeService";
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothGatt bluetoothGatt;
    private BluetoothManager bluetoothManager;
    private String device_address;
    private String remote_device_type;
    private final Handler bluetoothHandler = new Handler();
    private final HashMap<String, BluetoothGattCharacteristic> subscribed_characteristics = new HashMap<>();
    private final List<BluetoothGattCharacteristic> charsToSubscribe = new ArrayList();
    private double currentTemp = -1.0d;
    private double currentDepth = -1.0d;
    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        @Override
        public void onConnectionStateChange(BluetoothGatt bluetoothGatt, int i, int i2) {
            if (i2 == 2) {
                BluetoothLeService.this.broadcastUpdate(BluetoothLeService.ACTION_GATT_CONNECTED);
                Log.d(BluetoothLeService.TAG, "Connected to GATT server, call discoverServices()");
                BluetoothLeService.this.bluetoothGatt.discoverServices();
                BluetoothLeService.this.currentDepth = -1.0d;
                BluetoothLeService.this.currentTemp = -1.0d;
            } else if (i2 == 0) {
                Log.d(BluetoothLeService.TAG, "Disconnected from GATT server, reattempting every 5 seconds.");
                BluetoothLeService.this.broadcastUpdate(BluetoothLeService.ACTION_GATT_DISCONNECTED);
                attemptReconnect();
            }
        }

        void attemptReconnect() {
            new Timer().schedule(new TimerTask() { // from class: com.live.gpsmap.camera.Camera.remotecontrol.BluetoothLeService.2.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    Log.d(BluetoothLeService.TAG, "Attempting to reconnect to remote.");
                    BluetoothLeService.this.connect(BluetoothLeService.this.device_address);
                }
            }, 5000L);
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt bluetoothGatt, int i) {
            if (i == 0) {
                BluetoothLeService.this.broadcastUpdate(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
                BluetoothLeService.this.subscribeToServices();
                return;
            }
            Log.d(BluetoothLeService.TAG, "onServicesDiscovered received: " + i);
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic bluetoothGattCharacteristic, int i) {
            if (i == 0) {
                BluetoothLeService.this.broadcastUpdate(BluetoothLeService.ACTION_DATA_AVAILABLE, bluetoothGattCharacteristic);
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic bluetoothGattCharacteristic) {
            Log.d(BluetoothLeService.TAG, "Got notification");
            BluetoothLeService.this.broadcastUpdate(BluetoothLeService.ACTION_DATA_AVAILABLE, bluetoothGattCharacteristic);
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt bluetoothGatt, BluetoothGattDescriptor bluetoothGattDescriptor, int i) {
            if (BluetoothLeService.this.charsToSubscribe.isEmpty()) {
                return;
            }
            BluetoothLeService bluetoothLeService = BluetoothLeService.this;
            bluetoothLeService.setCharacteristicNotification((BluetoothGattCharacteristic) bluetoothLeService.charsToSubscribe.remove(0), true);
        }
    };
    private final IBinder mBinder = new LocalBinder();

    @SuppressLint("MissingPermission")
    private void triggerScan() {
        this.bluetoothHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                BluetoothLeService.this.bluetoothAdapter.stopLeScan(null);
            }
        }, WorkRequest.MIN_BACKOFF_MILLIS);
        this.bluetoothAdapter.startLeScan(null);
    }

    public void setRemoteDeviceType(String str) {
        Log.d(TAG, "Setting remote type: " + str);
        this.remote_device_type = str;
    }


    public void subscribeToServices() {
        List<UUID> desiredCharacteristics;
        List<BluetoothGattService> supportedGattServices = getSupportedGattServices();
        if (supportedGattServices == null) {
            return;
        }
        String str = this.remote_device_type;
        str.hashCode();
        if (str.equals("preference_remote_type_kraken")) {
            desiredCharacteristics = KrakenGattAttributes.getDesiredCharacteristics();
        } else {
            desiredCharacteristics = Collections.singletonList(UUID.fromString("0000"));
        }
        for (BluetoothGattService bluetoothGattService : supportedGattServices) {
            for (BluetoothGattCharacteristic bluetoothGattCharacteristic : bluetoothGattService.getCharacteristics()) {
                UUID uuid = bluetoothGattCharacteristic.getUuid();
                if (desiredCharacteristics.contains(uuid)) {
                    Log.d(TAG, "Found characteristic to subscribe to: " + uuid);
                    this.charsToSubscribe.add(bluetoothGattCharacteristic);
                }
            }
        }
        setCharacteristicNotification(this.charsToSubscribe.remove(0), true);
    }


    public void broadcastUpdate(String str) {
        sendBroadcast(new Intent(str));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x005b, code lost:
        if (r8 == 80) goto L6;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void broadcastUpdate(String str, BluetoothGattCharacteristic bluetoothGattCharacteristic0) {
        UUID uUID0 = bluetoothGattCharacteristic0.getUuid();
        if(KrakenGattAttributes.KRAKEN_BUTTONS_CHARACTERISTIC.equals(uUID0)) {
            Log.d("BluetoothLeService", "Got Kraken button press");
            int v = (int)bluetoothGattCharacteristic0.getIntValue(17, 0);
            Log.d("BluetoothLeService", String.format("Received Button press: %d", v));
            int v1 = 80;
            if(v == 0x20) {
                v1 = 0x20;
            }
            else if(v == 16) {
                v1 = 16;
            }
            else if(v == 0x30) {
                v1 = 0x30;
            }
            else if(v == 97) {
                v1 = 97;
            }
            else {
                switch(v) {
                    case 0x40: {
                        v1 = 0x40;
                    }
                    case 80: {
                        break;
                    }
                    default: {
                        v1 = -1;
                    }
                }
            }

            if(v1 > -1) {
                Intent intent0 = new Intent("net.sourceforge.opencamera.Remotecontrol.COMMAND");
                intent0.putExtra("net.sourceforge.opencamera.Remotecontrol.EXTRA_DATA", v1);
                this.sendBroadcast(intent0);
                return;
            }
        }
        else if(KrakenGattAttributes.KRAKEN_SENSORS_CHARACTERISTIC.equals(uUID0)) {
            double f = ((double)(((int)bluetoothGattCharacteristic0.getIntValue(18, 2)))) / 10.0;
            double f1 = ((double)(((int)bluetoothGattCharacteristic0.getIntValue(18, 0)))) / 10.0;
            if(f == this.currentTemp && f1 == this.currentDepth) {
                return;
            }

            this.currentDepth = f1;
            this.currentTemp = f;
            Log.d("BluetoothLeService", "Got new Kraken sensor reading. Temperature: " + f + " Depth:" + f1);
            Intent intent1 = new Intent();
            intent1.putExtra("net.sourceforge.opencamera.Remotecontrol.TEMPERATURE", f);
            intent1.putExtra("net.sourceforge.opencamera.Remotecontrol.DEPTH", f1);
            this.sendBroadcast(intent1);
        }
    }


    public class LocalBinder extends Binder {
        public LocalBinder() {
        }

        public BluetoothLeService getService() {
            return BluetoothLeService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "Starting OpenCamera Bluetooth Service");
        return this.mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        close();
        return super.onUnbind(intent);
    }

    public boolean initialize() {
        if (this.bluetoothManager == null) {
            BluetoothManager bluetoothManager = (BluetoothManager) getSystemService("bluetooth");
            this.bluetoothManager = bluetoothManager;
            if (bluetoothManager == null) {
                Log.e(TAG, "Unable to initialize BluetoothManager.");
                return false;
            }
        }
        BluetoothAdapter adapter = this.bluetoothManager.getAdapter();
        this.bluetoothAdapter = adapter;
        if (adapter == null) {
            Log.e(TAG, "Unable to obtain a BluetoothAdapter.");
            return false;
        }
        return true;
    }

    public boolean connect(final String str) {
        BluetoothGatt bluetoothGatt;
        Log.d(TAG, "connect: " + str);
        if (this.bluetoothAdapter == null) {
            Log.d(TAG, "bluetoothAdapter is null");
            return false;
        } else if (str == null) {
            Log.d(TAG, "address is null");
            return false;
        } else {
            if (str.equals(this.device_address) && (bluetoothGatt = this.bluetoothGatt) != null) {
                bluetoothGatt.disconnect();
                this.bluetoothGatt.close();
                this.bluetoothGatt = null;
            }
            BluetoothDevice remoteDevice = this.bluetoothAdapter.getRemoteDevice(str);
            if (remoteDevice == null) {
                Log.d(TAG, "device not found");
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Log.d(BluetoothLeService.TAG, "attempt to connect to remote");
                        BluetoothLeService.this.connect(str);
                    }
                }, 5000L);
                return false;
            }
            triggerScan();
            this.bluetoothGatt = remoteDevice.connectGatt(this, true, this.mGattCallback);
            this.device_address = str;
            return true;
        }
    }

    private void close() {
        BluetoothGatt bluetoothGatt = this.bluetoothGatt;
        if (bluetoothGatt == null) {
            return;
        }
        bluetoothGatt.close();
        this.bluetoothGatt = null;
    }


    public void setCharacteristicNotification(BluetoothGattCharacteristic bluetoothGattCharacteristic, boolean z) {
        if (this.bluetoothAdapter == null) {
            Log.d(TAG, "bluetoothAdapter is null");
        } else if (this.bluetoothGatt == null) {
            Log.d(TAG, "bluetoothGatt is null");
        } else {
            String uuid = bluetoothGattCharacteristic.getUuid().toString();
            this.bluetoothGatt.setCharacteristicNotification(bluetoothGattCharacteristic, z);
            if (z) {
                this.subscribed_characteristics.put(uuid, bluetoothGattCharacteristic);
            } else {
                this.subscribed_characteristics.remove(uuid);
            }
            BluetoothGattDescriptor descriptor = bluetoothGattCharacteristic.getDescriptor(KrakenGattAttributes.CLIENT_CHARACTERISTIC_CONFIG);
            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            this.bluetoothGatt.writeDescriptor(descriptor);
        }
    }

    private List<BluetoothGattService> getSupportedGattServices() {
        BluetoothGatt bluetoothGatt = this.bluetoothGatt;
        if (bluetoothGatt == null) {
            return null;
        }
        return bluetoothGatt.getServices();
    }
}
