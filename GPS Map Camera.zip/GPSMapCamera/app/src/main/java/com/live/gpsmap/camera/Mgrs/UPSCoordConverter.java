package com.live.gpsmap.camera.Mgrs;

/* loaded from: classes.dex */
public class UPSCoordConverter {
    private static final double MAX_EAST_NORTH = 4000000.0d;
    private static final double MAX_LAT = 1.5707963267948966d;
    private static final double MAX_ORIGIN_LAT = 1.4157155848011311d;
    private static final double MIN_EAST_NORTH = 0.0d;
    private static final double MIN_NORTH_LAT = 1.2566370614359172d;
    private static final double MIN_SOUTH_LAT = -1.2566370614359172d;
    private static final double PI = 3.141592653589793d;
    private static final int UPS_A_ERROR = 32;
    public static final int UPS_EASTING_ERROR = 8;
    public static final int UPS_HEMISPHERE_ERROR = 4;
    private static final int UPS_INV_F_ERROR = 64;
    private static final int UPS_LAT_ERROR = 1;
    private static final int UPS_LON_ERROR = 2;
    public static final int UPS_NORTHING_ERROR = 16;
    public static final int UPS_NO_ERROR = 0;
    private double Easting = 0.0d;
    private String Hemisphere = AVKey.NORTH;
    private double Latitude = 0.0d;
    private double Longitude = 0.0d;
    private double Northing = 0.0d;
    private double UPS_Easting = 0.0d;
    private double UPS_False_Easting = 2000000.0d;
    private double UPS_False_Northing = 2000000.0d;
    private double UPS_Northing = 0.0d;
    private double UPS_Origin_Latitude = MAX_ORIGIN_LAT;
    private double UPS_Origin_Longitude = 0.0d;
    private double UPS_a = 6378137.0d;
    private double UPS_f = 0.0033528106647474805d;
    private double false_easting = 0.0d;
    private double false_northing = 0.0d;
    private PolarCoordConverter polarConverter = new PolarCoordConverter();

    public long setUPSParameters(double d, double d2) {
        double d3 = 1.0d / d2;
        if (d <= 0.0d) {
            return 32L;
        }
        if (d3 < 250.0d || d3 > 350.0d) {
            return 64L;
        }
        this.UPS_a = d;
        this.UPS_f = d2;
        return 0L;
    }

    public long convertGeodeticToUPS(double d, double d2) {
        if (d < -1.5707963267948966d || d > 1.5707963267948966d) {
            return 1L;
        }
        int i = (d > 0.0d ? 1 : (d == 0.0d ? 0 : -1));
        if (i >= 0 || d <= MIN_SOUTH_LAT) {
            if (d < 0.0d || d >= MIN_NORTH_LAT) {
                if (d2 < -3.141592653589793d || d2 > 6.283185307179586d) {
                    return 2L;
                }
                if (i < 0) {
                    this.UPS_Origin_Latitude = -1.4157155848011311d;
                    this.Hemisphere = AVKey.SOUTH;
                } else {
                    this.UPS_Origin_Latitude = MAX_ORIGIN_LAT;
                    this.Hemisphere = AVKey.NORTH;
                }
                this.polarConverter.setPolarStereographicParameters(this.UPS_a, this.UPS_f, this.UPS_Origin_Latitude, this.UPS_Origin_Longitude, this.false_easting, this.false_northing);
                this.polarConverter.convertGeodeticToPolarStereographic(d, d2);
                this.UPS_Easting = this.UPS_False_Easting + this.polarConverter.getEasting();
                this.UPS_Northing = this.UPS_False_Northing + this.polarConverter.getNorthing();
                if (AVKey.SOUTH.equals(this.Hemisphere)) {
                    this.UPS_Northing = this.UPS_False_Northing - this.polarConverter.getNorthing();
                }
                this.Easting = this.UPS_Easting;
                this.Northing = this.UPS_Northing;
                return 0L;
            }
            return 1L;
        }
        return 1L;
    }

    public double getEasting() {
        return this.Easting;
    }

    public double getNorthing() {
        return this.Northing;
    }

    public String getHemisphere() {
        return this.Hemisphere;
    }

    public long convertUPSToGeodetic(String str, double d, double d2) {
        long j = (AVKey.NORTH.equals(str) || AVKey.SOUTH.equals(str)) ? 0L : 4L;
        if (d < 0.0d || d > MAX_EAST_NORTH) {
            j |= 8;
        }
        if (d2 < 0.0d || d2 > MAX_EAST_NORTH) {
            j |= 16;
        }
        if (AVKey.NORTH.equals(str)) {
            this.UPS_Origin_Latitude = MAX_ORIGIN_LAT;
        }
        if (AVKey.SOUTH.equals(str)) {
            this.UPS_Origin_Latitude = -1.4157155848011311d;
        }
        if (j == 0) {
            long j2 = j;
            this.polarConverter.setPolarStereographicParameters(this.UPS_a, this.UPS_f, this.UPS_Origin_Latitude, this.UPS_Origin_Longitude, this.UPS_False_Easting, this.UPS_False_Northing);
            this.polarConverter.convertPolarStereographicToGeodetic(d, d2);
            this.Latitude = this.polarConverter.getLatitude();
            this.Longitude = this.polarConverter.getLongitude();
            double d3 = this.Latitude;
            long j3 = (d3 >= 0.0d || d3 <= MIN_SOUTH_LAT) ? j2 : j2 | 1;
            return (d3 < 0.0d || d3 >= MIN_NORTH_LAT) ? j3 : j3 | 1;
        }
        return j;
    }

    public double getLatitude() {
        return this.Latitude;
    }

    public double getLongitude() {
        return this.Longitude;
    }
}
