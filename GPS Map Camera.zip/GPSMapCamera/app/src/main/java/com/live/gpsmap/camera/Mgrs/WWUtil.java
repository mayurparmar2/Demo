package com.live.gpsmap.camera.Mgrs;

/* loaded from: classes2.dex */
public class WWUtil {
    public static boolean isEmpty(Object obj) {
        return obj == null || ((obj instanceof String) && ((String) obj).length() == 0);
    }
}
