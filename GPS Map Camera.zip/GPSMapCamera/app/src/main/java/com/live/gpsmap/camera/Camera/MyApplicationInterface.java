package com.live.gpsmap.camera.Camera;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetFileDescriptor;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.ParcelFileDescriptor;
import android.preference.PreferenceManager;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Html;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Pair;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.RotateAnimation;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.exifinterface.media.ExifInterface;

import com.live.gpsmap.camera.Camera.cameracontroller.CameraController;
import com.live.gpsmap.camera.Camera.cameracontroller.RawImage;
import com.live.gpsmap.camera.Camera.preview.ApplicationInterface;
import com.live.gpsmap.camera.Camera.preview.BasicApplicationInterface;
import com.live.gpsmap.camera.Camera.preview.Preview;
import com.live.gpsmap.camera.Camera.preview.VideoProfile;
import com.live.gpsmap.camera.Camera.ui.DrawPreview;
import com.live.gpsmap.camera.Camera.utils.GPS;
import com.live.gpsmap.camera.Camera.utils.NetworkState;
import com.live.gpsmap.camera.Compass.RoundCorners;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.Utils.Util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;

import kotlinx.coroutines.DebugKt;


@SuppressWarnings("All")
public class MyApplicationInterface extends BasicApplicationInterface {
    private static final String TAG = "MyApplicationInterface";
    private static final String TAG_DATETIME_DIGITIZED = "DateTimeDigitized";
    private static final String TAG_DATETIME_ORIGINAL = "DateTimeOriginal";
    private static final String TAG_GPS_IMG_DIRECTION = "GPSImgDirection";
    private static final String TAG_GPS_IMG_DIRECTION_REF = "GPSImgDirectionRef";
    private static final float aperture_default = -1.0f;
    private static final int cameraId_default = 0;
    public static final int max_panorama_pics_c = 10;
    private static final String nr_mode_default = "preference_nr_mode_normal";
    private static final float panorama_pics_per_screen = 3.33333f;
    private int DH;
    private int DW;
    private float aperture;
    private int cameraId;
    private final DrawPreview drawPreview;
    private final GyroSensor gyroSensor;
    private boolean has_set_cameraId;
    private final ImageSaver imageSaver;
    Bitmap imagecompress;
    boolean isTablet;
    private boolean last_images_saf;
    private final LocationSupplier locationSupplier;
    SP mSP;
    TypedArray mWeatherIcon;
    private final CameraMainActivity main_activity;
    private String nr_mode;
    public Bitmap orginalImage;
    private boolean panorama_pic_accepted;
    float scale;
    private final SharedPreferences sharedPreferences;
    Bitmap stampBitmap;
    private final StorageUtils storageUtils;
    private TimerTask subtitleVideoTimerTask;
    public volatile int test_max_mp;
    public volatile int test_n_videos_scanned;
    private boolean used_front_screen_flash;
    private int zoom_factor;
    private final Timer subtitleVideoTimer = new Timer();
    private final Rect text_bounds = new Rect();
    private final List<LastImage> last_images = new ArrayList();
    private final ToastBoxer photo_delete_toast = new ToastBoxer();
    public boolean test_set_available_memory = false;
    public long test_available_memory = 0;
    private LastImagesType last_images_type = LastImagesType.FILE;
    private int n_capture_images = 0;
    private int n_capture_images_raw = 0;
    private int n_panorama_pics = 0;
    private boolean panorama_dir_left_to_right = true;
    private File last_video_file = null;
    private Uri last_video_file_saf = null;
    private Uri last_video_file_uri = null;

    public enum Alignment {
        ALIGNMENT_TOP,
        ALIGNMENT_CENTRE,
        ALIGNMENT_BOTTOM
    }

    public enum LastImagesType {
        FILE,
        SAF,
        MEDIASTORE
    }

    /* loaded from: classes.dex */
    public enum PhotoMode {
        Standard,
        DRO, // single image "fake" HDR
        HDR, // HDR created from multiple (expo bracketing) images
        ExpoBracketing, // take multiple expo bracketed images, without combining to a single image
        FocusBracketing, // take multiple focus bracketed images, without combining to a single image
        FastBurst,
        NoiseReduction,
        Panorama,
        // camera vendor extensions:
        X_Auto,
        X_HDR,
        X_Night,
        X_Bokeh,
        X_Beauty
    }

    /* loaded from: classes3.dex */
    public enum Shadow {
        SHADOW_NONE,
        SHADOW_OUTLINE,
        SHADOW_BACKGROUND
    }


    public static float getPanoramaPicsPerScreen() {
        return panorama_pics_per_screen;
    }

    public MyApplicationInterface(CameraMainActivity mainActivity, Bundle bundle) {
        this.cameraId = 0;
        this.nr_mode = nr_mode_default;
        this.aperture = -1.0f;
        Log.d(TAG, TAG);
        long currentTimeMillis = System.currentTimeMillis();
        this.main_activity = mainActivity;
        DisplayMetrics displayMetrics = new DisplayMetrics();
        mainActivity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.DW = displayMetrics.heightPixels;
        this.DH = displayMetrics.widthPixels;
        this.scale = displayMetrics.scaledDensity;
        this.mWeatherIcon = mainActivity.getResources().obtainTypedArray(R.array.wI);
        this.mSP = new SP(mainActivity);
        this.isTablet = mainActivity.getResources().getBoolean(R.bool.isTablet);
        this.sharedPreferences = PreferenceManager.getDefaultSharedPreferences(mainActivity);
        this.locationSupplier = new LocationSupplier(mainActivity);
        Log.d(TAG, "MyApplicationInterface: time after creating location supplier: " + (System.currentTimeMillis() - currentTimeMillis));
        this.gyroSensor = new GyroSensor(mainActivity);
        this.storageUtils = new StorageUtils(mainActivity, this);
        Log.d(TAG, "MyApplicationInterface: time after creating storage utils: " + (System.currentTimeMillis() - currentTimeMillis));
        this.drawPreview = new DrawPreview(mainActivity, this);
        ImageSaver imageSaver = new ImageSaver(mainActivity);
        this.imageSaver = imageSaver;
        imageSaver.start();
        reset(false);
        if (bundle != null) {
            Log.d(TAG, "read from savedInstanceState");
            this.has_set_cameraId = true;
            this.cameraId = bundle.getInt("cameraId", 0);
            Log.d(TAG, "found cameraId: " + this.cameraId);
            this.nr_mode = bundle.getString("nr_mode", nr_mode_default);
            Log.d(TAG, "found nr_mode: " + this.nr_mode);
            this.aperture = bundle.getFloat("aperture", -1.0f);
            Log.d(TAG, "found aperture: " + this.aperture);
        }
        Log.d(TAG, "MyApplicationInterface: total time to create MyApplicationInterface: " + (System.currentTimeMillis() - currentTimeMillis));
    }

    public static CameraController.Size choosePanoramaResolution(List<CameraController.Size> list) {
        boolean z = false;
        CameraController.Size size = null;
        for (CameraController.Size size2 : list) {
            if (size2.width<=2080 && Math.abs((size2.width / size2.height) - 1.3333333333333333d)<1.0E-5d && (!z || size2.width>size.width)) {
                size = size2;
                z = true;
            }
        }
        if (z) {
            return size;
        }
        for (CameraController.Size size3 : list) {
            if (size3.width<=2080 && (!z || size3.width>size.width)) {
                size = size3;
                z = true;
            }
        }
        if (z) {
            return size;
        }
        for (CameraController.Size size4 : list) {
            if (!z || size4.width<size.width) {
                size = size4;
                z = true;
            }
        }
        return size;
    }

    public void onSaveInstanceState(Bundle bundle) {
        bundle.putInt("cameraId", this.cameraId);
        Log.d(TAG, "save nr_mode: " + this.nr_mode);
        bundle.putString("nr_mode", this.nr_mode);
        Log.d(TAG, "save aperture: " + this.aperture);
        bundle.putFloat("aperture", this.aperture);
    }

    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        DrawPreview drawPreview = this.drawPreview;
        if (drawPreview != null) {
            drawPreview.onDestroy();
        }
        ImageSaver imageSaver = this.imageSaver;
        if (imageSaver != null) {
            imageSaver.onDestroy();
        }
    }

    public LocationSupplier getLocationSupplier() {
        return this.locationSupplier;
    }

    public GyroSensor getGyroSensor() {
        return this.gyroSensor;
    }

    public StorageUtils getStorageUtils() {
        return this.storageUtils;
    }

    public ImageSaver getImageSaver() {
        return this.imageSaver;
    }

    public DrawPreview getDrawPreview() {
        return this.drawPreview;
    }

    @Override // com.live.gpsmap.camera.Camera.preview.ApplicationInterface
    public Context getContext() {
        return this.main_activity;
    }

    @Override // com.live.gpsmap.camera.Camera.preview.ApplicationInterface
    public boolean useCamera2() {
        return this.main_activity.supportsCamera2();
    }

    @Override
    public Location getLocation() {
        return this.locationSupplier.getLocation();
    }

    @Override // com.live.gpsmap.camera.Camera.preview.ApplicationInterface
    public ApplicationInterface.VideoMethod createOutputVideoMethod() {
        Uri uri;
        if (isVideoCaptureIntent()) {
            Log.d(TAG, "from video capture intent");
            Bundle extras = this.main_activity.getIntent().getExtras();
            if (extras != null && (uri = (Uri) extras.getParcelable("output")) != null) {
                Log.d(TAG, "save to: " + uri);
                return ApplicationInterface.VideoMethod.URI;
            }
            Log.d(TAG, "intent uri not specified");
            if (CameraMainActivity.useScopedStorage()) {
                return ApplicationInterface.VideoMethod.MEDIASTORE;
            }
            return ApplicationInterface.VideoMethod.FILE;
        } else if (this.storageUtils.isUsingSAF()) {
            return ApplicationInterface.VideoMethod.SAF;
        } else {
            if (CameraMainActivity.useScopedStorage()) {
                return ApplicationInterface.VideoMethod.MEDIASTORE;
            }
            return ApplicationInterface.VideoMethod.FILE;
        }
    }

    boolean isVideoCaptureIntent() {
//        if (JHrqmCvkh.fcXrR.equals(this.main_activity.getIntent().getAction())) {
//            Log.d(TAG, "from video capture intent");
//            return true;
//        }
        return false;
    }

    @Override // com.live.gpsmap.camera.Camera.preview.ApplicationInterface
    public File createOutputVideoFile(String str) throws IOException {
        File createOutputMediaFile = this.storageUtils.createOutputMediaFile(2, "", str, new Date());
        this.last_video_file = createOutputMediaFile;
        return createOutputMediaFile;
    }

    @Override // com.live.gpsmap.camera.Camera.preview.ApplicationInterface
    public Uri createOutputVideoSAF(String str) throws IOException {
        Uri createOutputMediaFileSAF = this.storageUtils.createOutputMediaFileSAF(2, "", str, new Date());
        this.last_video_file_uri = createOutputMediaFileSAF;
        return createOutputMediaFileSAF;
    }

    @Override // com.live.gpsmap.camera.Camera.preview.ApplicationInterface
    public Uri createOutputVideoMediaStore(String str) throws IOException {
        Uri uri;
        if (Build.VERSION.SDK_INT>=29) {
            uri = MediaStore.Video.Media.getContentUri("external_primary");
        } else {
            uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        }
        ContentValues contentValues = new ContentValues();
        StorageUtils storageUtils = this.storageUtils;
        String createMediaFilename = storageUtils.createMediaFilename(2, "", 0, "." + str, new Date());
        Log.d(TAG, "filename: " + createMediaFilename);
        contentValues.put("_display_name", createMediaFilename);
        String videoMimeType = this.storageUtils.getVideoMimeType(str);
        Log.d(TAG, "mime_type: " + videoMimeType);
        contentValues.put("mime_type", videoMimeType);
        if (Build.VERSION.SDK_INT>=29) {
            String saveRelativeFolder = this.storageUtils.getSaveRelativeFolder();
            Log.d(TAG, "relative_path: " + saveRelativeFolder);
            contentValues.put("relative_path", saveRelativeFolder);
            contentValues.put("is_pending", (Integer) 1);
        }
        this.last_video_file_uri = this.main_activity.getContentResolver().insert(uri, contentValues);
        Log.d(TAG, "uri: " + this.last_video_file_uri);
        Uri uri2 = this.last_video_file_uri;
        if (uri2 != null) {
            return uri2;
        }
        throw new IOException();
    }

    @Override // com.live.gpsmap.camera.Camera.preview.ApplicationInterface
    public Uri createOutputVideoUri() {
        Uri uri;
        if ("android.media.action.VIDEO_CAPTURE".equals(this.main_activity.getIntent().getAction())) {
            Log.d(TAG, "from video capture intent");
            Bundle extras = this.main_activity.getIntent().getExtras();
            if (extras != null && (uri = (Uri) extras.getParcelable("output")) != null) {
                Log.d(TAG, "save to: " + uri);
                return uri;
            }
        }
        throw new RuntimeException();
    }

    @Override // com.live.gpsmap.camera.Camera.preview.ApplicationInterface
    public int getFlashPref_Pos() {
        return this.sharedPreferences.getInt(PreferenceKeys.getFlashPreferenceKey_Pos(this.cameraId), 0);
    }

    @Override // com.live.gpsmap.camera.Camera.preview.ApplicationInterface
    public void setFlashPref_Pos(int i) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putInt(PreferenceKeys.getFlashPreferenceKey_Pos(this.cameraId), i);
        edit.apply();
    }

    @Override
    public int getCameraIdPref() {
        return this.cameraId;
    }

    @Override
    public void setCameraIdPref(int i) {
        this.has_set_cameraId = true;
        this.cameraId = i;
    }

    @Override
    public String getFlashPref() {
        return this.sharedPreferences.getString(PreferenceKeys.getFlashPreferenceKey(this.cameraId), "");
    }

    @Override
    public void setFlashPref(String str) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putString(PreferenceKeys.getFlashPreferenceKey(this.cameraId), str);
        edit.apply();
    }

    @Override
    public String getFocusPref(boolean z) {
        return (getPhotoMode() != PhotoMode.FocusBracketing || this.main_activity.getPreview().isVideo()) ? this.sharedPreferences.getString(PreferenceKeys.getFocusPreferenceKey(this.cameraId, z), "") : "focus_mode_manual2";
    }

    int getFocusAssistPref() {
        int i;
        String string = this.sharedPreferences.getString(PreferenceKeys.FocusAssistPreferenceKey, "0");
        try {
            i = Integer.parseInt(string);
        } catch (NumberFormatException e) {
            Log.e(TAG, "failed to parse focus_assist_value: " + string);
            e.printStackTrace();
            i = 0;
        }
        if (i<=0 || !this.main_activity.getPreview().isVideoRecording()) {
            return i;
        }
        return 0;
    }

    @Override
    public boolean isVideoPref() {
        return this.sharedPreferences.getBoolean(PreferenceKeys.IsVideoPreferenceKey, false);
    }

    @Override
    public void setVideoPref(boolean z) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putBoolean(PreferenceKeys.IsVideoPreferenceKey, z);
        edit.apply();
    }

    @Override
    public String getSceneModePref() {
        return this.sharedPreferences.getString(PreferenceKeys.SceneModePreferenceKey, "auto");
    }

    @Override
    public void setSceneModePref(String str) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putString(PreferenceKeys.SceneModePreferenceKey, str);
        edit.apply();
    }

    @Override
    public String getColorEffectPref() {
        return this.sharedPreferences.getString(PreferenceKeys.ColorEffectPreferenceKey, "none");
    }

    @Override
    public void setColorEffectPref(String str) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putString(PreferenceKeys.ColorEffectPreferenceKey, str);
        edit.apply();
    }

    @Override
    public String getWhiteBalancePref() {
        return this.sharedPreferences.getString(PreferenceKeys.WhiteBalancePreferenceKey, "auto");
    }

    @Override
    public void setWhiteBalancePref(String str) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putString(PreferenceKeys.WhiteBalancePreferenceKey, str);
        edit.apply();
    }

    @Override
    public int getWhiteBalanceTemperaturePref() {
        return this.sharedPreferences.getInt(PreferenceKeys.WhiteBalanceTemperaturePreferenceKey, 5000);
    }

    @Override
    public void setWhiteBalanceTemperaturePref(int i) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putInt(PreferenceKeys.WhiteBalanceTemperaturePreferenceKey, i);
        edit.apply();
    }

    @Override
    public String getAntiBandingPref() {
        return this.sharedPreferences.getString(PreferenceKeys.AntiBandingPreferenceKey, "auto");
    }

    @Override
    public String getEdgeModePref() {
        return this.sharedPreferences.getString(PreferenceKeys.EdgeModePreferenceKey, "default");
    }

    @Override
    public String getCameraNoiseReductionModePref() {
        return this.sharedPreferences.getString(PreferenceKeys.CameraNoiseReductionModePreferenceKey, "default");
    }

    @Override
    public String getISOPref() {
        return this.sharedPreferences.getString(PreferenceKeys.ISOPreferenceKey, "auto");
    }

    @Override
    public void setISOPref(String str) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putString(PreferenceKeys.ISOPreferenceKey, str);
        edit.apply();
    }

    @Override
    public int getExposureCompensationPref() {
        int i;
        String string = this.sharedPreferences.getString(PreferenceKeys.ExposurePreferenceKey, "0");
        Log.d(TAG, "saved exposure value: " + string);
        try {
            i = Integer.parseInt(string);
            try {
                Log.d(TAG, "exposure: " + i);
            } catch (NumberFormatException unused) {
                Log.d(TAG, "exposure invalid format, can't parse to int");
                return i;
            }
        } catch (NumberFormatException unused2) {
            i = 0;
        }
        return i;
    }

    @Override
    public void setExposureCompensationPref(int i) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putString(PreferenceKeys.ExposurePreferenceKey, "" + i);
        edit.apply();
    }

    @Override
    public Pair<Integer, Integer> getCameraResolutionPref(ApplicationInterface.CameraResolutionConstraints cameraResolutionConstraints) {
        PhotoMode photoMode = getPhotoMode();
        if (photoMode == PhotoMode.Panorama) {
            CameraController.Size choosePanoramaResolution = choosePanoramaResolution(this.main_activity.getPreview().getSupportedPictureSizes(false));
            return new Pair<>(Integer.valueOf(choosePanoramaResolution.width), Integer.valueOf(choosePanoramaResolution.height));
        }
        String string = this.sharedPreferences.getString(PreferenceKeys.getResolutionPreferenceKey(this.cameraId), "");
        Log.d(TAG, "resolution_value: " + string);
        Pair<Integer, Integer> pair = null;
        if (string.length()>0) {
            int indexOf = string.indexOf(32);
            if (indexOf == -1) {
                Log.d(TAG, "resolution_value invalid format, can't find space");
            } else {
                String substring = string.substring(0, indexOf);
                String substring2 = string.substring(indexOf + 1);
                Log.d(TAG, "resolution_w_s: " + substring);
                Log.d(TAG, "resolution_h_s: " + substring2);
                try {
                    int parseInt = Integer.parseInt(substring);
                    Log.d(TAG, "resolution_w: " + parseInt);
                    int parseInt2 = Integer.parseInt(substring2);
                    Log.d(TAG, "resolution_h: " + parseInt2);
                    pair = new Pair<>(Integer.valueOf(parseInt), Integer.valueOf(parseInt2));
                } catch (NumberFormatException unused) {
                    Log.d(TAG, "resolution_value invalid format, can't parse w or h to int");
                }
            }
        }
        if (photoMode == PhotoMode.NoiseReduction || photoMode == PhotoMode.HDR) {
            cameraResolutionConstraints.has_max_mp = true;
            cameraResolutionConstraints.max_mp = 22000000;
            if (this.main_activity.is_test && this.test_max_mp != 0) {
                cameraResolutionConstraints.max_mp = this.test_max_mp;
            }
        }
        return pair;
    }

    private int getSaveImageQualityPref() {
        int i;
        Log.d(TAG, "getSaveImageQualityPref");
        String string = this.sharedPreferences.getString(PreferenceKeys.QualityPreferenceKey, "90");
        try {
            i = Integer.parseInt(string);
        } catch (NumberFormatException unused) {
            Log.e(TAG, "image_quality_s invalid format: " + string);
            i = 90;
        }
        if (isRawOnly()) {
            Log.d(TAG, "set lower quality for raw_only mode");
            return Math.min(i, 70);
        }
        return i;
    }

    @Override
    public int getImageQualityPref() {
        Log.d(TAG, "getImageQualityPref");
        PhotoMode photoMode = getPhotoMode();
        if ((!this.main_activity.getPreview().isVideo() && (photoMode == PhotoMode.DRO || photoMode == PhotoMode.HDR || photoMode == PhotoMode.NoiseReduction)) || getImageFormatPref() != ImageSaver.Request.ImageFormat.STD) {
            return 100;
        }
        return getSaveImageQualityPref();
    }

    @Override
    public boolean getFaceDetectionPref() {
        return this.sharedPreferences.getBoolean(PreferenceKeys.FaceDetectionPreferenceKey, false);
    }

    public boolean fpsIsHighSpeed() {
        return this.main_activity.getPreview().fpsIsHighSpeed(getVideoFPSPref());
    }

    @Override
    public String getVideoQualityPref() {
        if ("android.media.action.VIDEO_CAPTURE".equals(this.main_activity.getIntent().getAction())) {
            Log.d(TAG, "from video capture intent");
            if (this.main_activity.getIntent().hasExtra("android.intent.extra.videoQuality")) {
                int intExtra = this.main_activity.getIntent().getIntExtra("android.intent.extra.videoQuality", 0);
                Log.d(TAG, "intent_quality: " + intExtra);
                if (intExtra == 0 || intExtra == 1) {
                    List<String> supportedVideoQuality = this.main_activity.getPreview().getVideoQualityHander().getSupportedVideoQuality();
                    if (intExtra == 0) {
                        Log.d(TAG, "return lowest quality");
                        return supportedVideoQuality.get(supportedVideoQuality.size() - 1);
                    }
                    Log.d(TAG, "return highest quality");
                    return supportedVideoQuality.get(0);
                }
            }
        }
        return this.sharedPreferences.getString(PreferenceKeys.getVideoQualityPreferenceKey(this.cameraId, fpsIsHighSpeed()), "");
    }

    @Override
    public void setVideoQualityPref(String str) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putString(PreferenceKeys.getVideoQualityPreferenceKey(this.cameraId, fpsIsHighSpeed()), str);
        edit.apply();
    }

    @Override
    public boolean getVideoStabilizationPref() {
        return this.sharedPreferences.getBoolean(PreferenceKeys.VideoStabilizationPreferenceKey, false);
    }

    @Override
    public boolean getForce4KPref() {
        return this.cameraId == 0 && this.sharedPreferences.getBoolean(PreferenceKeys.ForceVideo4KPreferenceKey, false) && this.main_activity.supportsForceVideo4K();
    }

    @Override
    public String getRecordVideoOutputFormatPref() {
        return this.sharedPreferences.getString(PreferenceKeys.VideoFormatPreferenceKey, "preference_video_output_format_default");
    }

    @Override
    public String getVideoBitratePref() {
        return this.sharedPreferences.getString(PreferenceKeys.VideoBitratePreferenceKey, "default");
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x00b1  */
//    @Override
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    @Override
    public String getVideoFPSPref() {
        float capture_rate_factor = getVideoCaptureRateFactor();
        if (capture_rate_factor<1.0f - 1.0e-5f) {
            if (MyDebug.LOG)
                Log.d(TAG, "set fps for slow motion, capture rate: " + capture_rate_factor);
            int preferred_fps = (int) (30.0 / capture_rate_factor + 0.5);
            if (MyDebug.LOG)
                Log.d(TAG, "preferred_fps: " + preferred_fps);
            if (main_activity.getPreview().getVideoQualityHander().videoSupportsFrameRateHighSpeed(preferred_fps) ||
                    main_activity.getPreview().getVideoQualityHander().videoSupportsFrameRate(preferred_fps))
                return "" + preferred_fps;
            // just in case say we support 120fps but NOT 60fps, getSupportedSlowMotionRates() will have returned that 2x slow
            // motion is supported, but we need to set 120fps instead of 60fps
            while (preferred_fps<240) {
                preferred_fps *= 2;
                if (MyDebug.LOG)
                    Log.d(TAG, "preferred_fps not supported, try: " + preferred_fps);
                if (main_activity.getPreview().getVideoQualityHander().videoSupportsFrameRateHighSpeed(preferred_fps) ||
                        main_activity.getPreview().getVideoQualityHander().videoSupportsFrameRate(preferred_fps))
                    return "" + preferred_fps;
            }
            // shouln't happen based on getSupportedSlowMotionRates()
            Log.e(TAG, "can't find valid fps for slow motion");
            return "default";
        }
        return sharedPreferences.getString(PreferenceKeys.getVideoFPSPreferenceKey(cameraId), "default");
    }


    @Override
    public float getVideoCaptureRateFactor() {
        float f = this.sharedPreferences.getFloat(PreferenceKeys.getVideoCaptureRatePreferenceKey(this.main_activity.getPreview().getCameraId()), 1.0f);
        Log.d(TAG, "capture_rate_factor: " + f);
        if (Math.abs(f - 1.0f)>1.0E-5d) {
            Log.d(TAG, "check stored capture rate is valid");
            List<Float> supportedVideoCaptureRates = getSupportedVideoCaptureRates();
            Log.d(TAG, "supported_capture_rates: " + supportedVideoCaptureRates);
            boolean z = false;
            Iterator<Float> it = supportedVideoCaptureRates.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                } else if (Math.abs(f - it.next().floatValue())<1.0E-5d) {
                    z = true;
                    break;
                }
            }
            if (!z) {
                Log.e(TAG, "stored capture_rate_factor: " + f + " not supported");
                return 1.0f;
            }
        }
        return f;
    }

    public List<Float> getSupportedVideoCaptureRates() {
        ArrayList arrayList = new ArrayList();
        if (this.main_activity.getPreview().supportsVideoHighSpeed()) {
            if (this.main_activity.getPreview().getVideoQualityHander().videoSupportsFrameRateHighSpeed(240) || this.main_activity.getPreview().getVideoQualityHander().videoSupportsFrameRate(240)) {
                arrayList.add(Float.valueOf(0.125f));
                arrayList.add(Float.valueOf(0.25f));
                arrayList.add(Float.valueOf(0.5f));
            } else if (this.main_activity.getPreview().getVideoQualityHander().videoSupportsFrameRateHighSpeed(120) || this.main_activity.getPreview().getVideoQualityHander().videoSupportsFrameRate(120)) {
                arrayList.add(Float.valueOf(0.25f));
                arrayList.add(Float.valueOf(0.5f));
            } else if (this.main_activity.getPreview().getVideoQualityHander().videoSupportsFrameRateHighSpeed(60) || this.main_activity.getPreview().getVideoQualityHander().videoSupportsFrameRate(60)) {
                arrayList.add(Float.valueOf(0.5f));
            }
        }
        arrayList.add(Float.valueOf(1.0f));
        if (Build.VERSION.SDK_INT>=21) {
            arrayList.add(Float.valueOf(2.0f));
            arrayList.add(Float.valueOf(3.0f));
            arrayList.add(Float.valueOf(4.0f));
            arrayList.add(Float.valueOf(5.0f));
            arrayList.add(Float.valueOf(10.0f));
            arrayList.add(Float.valueOf(20.0f));
            arrayList.add(Float.valueOf(30.0f));
            arrayList.add(Float.valueOf(60.0f));
            arrayList.add(Float.valueOf(120.0f));
            arrayList.add(Float.valueOf(240.0f));
        }
        return arrayList;
    }

    @Override
    public CameraController.TonemapProfile getVideoTonemapProfile() {
        String string = this.sharedPreferences.getString(PreferenceKeys.VideoLogPreferenceKey, DebugKt.DEBUG_PROPERTY_VALUE_OFF);
        string.hashCode();
        char c = 65535;
        switch (string.hashCode()) {
            case -1275673231:
                if (string.equals("jtvideo")) {
                    c = 0;
                    break;
                }
                break;
            case -1149821512:
                if (string.equals("jtlog2")) {
                    c = 1;
                    break;
                }
                break;
            case -1078030475:
                if (string.equals("medium")) {
                    c = 2;
                    break;
                }
                break;
            case -934964752:
                if (string.equals("rec709")) {
                    c = 3;
                    break;
                }
                break;
            case -891980137:
                if (string.equals("strong")) {
                    c = 4;
                    break;
                }
                break;
            case 107348:
                if (string.equals("low")) {
                    c = 5;
                    break;
                }
                break;
            case 109935:
                if (string.equals(DebugKt.DEBUG_PROPERTY_VALUE_OFF)) {
                    c = 6;
                    break;
                }
                break;
            case 3143098:
                if (string.equals("fine")) {
                    c = 7;
                    break;
                }
                break;
            case 3538810:
                if (string.equals("srgb")) {
                    c = '\b';
                    break;
                }
                break;
            case 98120615:
                if (string.equals("gamma")) {
                    c = '\t';
                    break;
                }
                break;
            case 101456314:
                if (string.equals("jtlog")) {
                    c = '\n';
                    break;
                }
                break;
            case 1419914662:
                if (string.equals("extra_strong")) {
                    c = 11;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                return CameraController.TonemapProfile.TONEMAPPROFILE_JTVIDEO;
            case 1:
                return CameraController.TonemapProfile.TONEMAPPROFILE_JTLOG2;
            case 2:
            case 4:
            case 5:
            case 7:
            case 11:
                return CameraController.TonemapProfile.TONEMAPPROFILE_LOG;
            case 3:
                return CameraController.TonemapProfile.TONEMAPPROFILE_REC709;
            case 6:
                return CameraController.TonemapProfile.TONEMAPPROFILE_OFF;
            case '\b':
                return CameraController.TonemapProfile.TONEMAPPROFILE_SRGB;
            case '\t':
                return CameraController.TonemapProfile.TONEMAPPROFILE_GAMMA;
            case '\n':
                return CameraController.TonemapProfile.TONEMAPPROFILE_JTLOG;
            default:
                return CameraController.TonemapProfile.TONEMAPPROFILE_OFF;
        }
    }

    @Override
    public float getVideoLogProfileStrength() {
        String string = this.sharedPreferences.getString(PreferenceKeys.VideoLogPreferenceKey, DebugKt.DEBUG_PROPERTY_VALUE_OFF);
        string.hashCode();
        char c = 65535;
        switch (string.hashCode()) {
            case -1078030475:
                if (string.equals("medium")) {
                    c = 0;
                    break;
                }
                break;
            case -891980137:
                if (string.equals("strong")) {
                    c = 1;
                    break;
                }
                break;
            case 107348:
                if (string.equals("low")) {
                    c = 2;
                    break;
                }
                break;
            case 3143098:
                if (string.equals("fine")) {
                    c = 3;
                    break;
                }
                break;
            case 1419914662:
                if (string.equals("extra_strong")) {
                    c = 4;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                return 100.0f;
            case 1:
                return 224.0f;
            case 2:
                return 32.0f;
            case 3:
                return 10.0f;
            case 4:
                return 500.0f;
            default:
                return 0.0f;
        }
    }

    @Override
    public float getVideoProfileGamma() {
        float f;
        String string = this.sharedPreferences.getString(PreferenceKeys.VideoProfileGammaPreferenceKey, "2.2");
        try {
            f = Float.parseFloat(string);
        } catch (NumberFormatException e) {
            e = e;
            f = 0.0f;
        }
        try {
            Log.d(TAG, "gamma: " + f);
        } catch (NumberFormatException e2) {
            Log.e(TAG, "failed to parse gamma value: " + string);
            e2.printStackTrace();
            return f;
        }
        return f;
    }

    @Override
    public long getVideoMaxDurationPref() {
        if ("android.media.action.VIDEO_CAPTURE".equals(this.main_activity.getIntent().getAction())) {
            Log.d(TAG, "from video capture intent");
            if (this.main_activity.getIntent().hasExtra("android.intent.extra.durationLimit")) {
                int intExtra = this.main_activity.getIntent().getIntExtra("android.intent.extra.durationLimit", 0);
                Log.d(TAG, "intent_duration_limit: " + intExtra);
                return intExtra * 1000;
            }
        }
        String string = this.sharedPreferences.getString(PreferenceKeys.VideoMaxDurationPreferenceKey, "0");
        try {
            return Integer.parseInt(string) * 1000;
        } catch (NumberFormatException e) {
            Log.e(TAG, "failed to parse preference_video_max_duration value: " + string);
            e.printStackTrace();
            return 0L;
        }
    }

    @Override
    public int getVideoRestartTimesPref() {
        String string = this.sharedPreferences.getString(PreferenceKeys.VideoRestartPreferenceKey, "0");
        try {
            return Integer.parseInt(string);
        } catch (NumberFormatException e) {
            Log.e(TAG, "failed to parse preference_video_restart value: " + string);
            e.printStackTrace();
            return 0;
        }
    }

    long getVideoMaxFileSizeUserPref() {
        Log.d(TAG, "getVideoMaxFileSizeUserPref");
        long j = 0;
        if ("android.media.action.VIDEO_CAPTURE".equals(this.main_activity.getIntent().getAction())) {
            Log.d(TAG, "from video capture intent");
            if (this.main_activity.getIntent().hasExtra("android.intent.extra.sizeLimit")) {
                long longExtra = this.main_activity.getIntent().getLongExtra("android.intent.extra.sizeLimit", 0L);
                Log.d(TAG, "intent_size_limit: " + longExtra);
                return longExtra;
            }
        }
        String string = this.sharedPreferences.getString(PreferenceKeys.VideoMaxFileSizePreferenceKey, "0");
        try {
            j = Long.parseLong(string);
        } catch (NumberFormatException e) {
            Log.e(TAG, "failed to parse preference_video_max_filesize value: " + string);
            e.printStackTrace();
        }
        Log.d(TAG, "video_max_filesize: " + j);
        return j;
    }

    private boolean getVideoRestartMaxFileSizeUserPref() {
        if ("android.media.action.VIDEO_CAPTURE".equals(this.main_activity.getIntent().getAction())) {
            Log.d(TAG, "from video capture intent");
            if (this.main_activity.getIntent().hasExtra("android.intent.extra.sizeLimit")) {
                return false;
            }
        }
        return this.sharedPreferences.getBoolean(PreferenceKeys.VideoRestartMaxFileSizePreferenceKey, true);
    }

    @Override
    public ApplicationInterface.VideoMaxFileSize getVideoMaxFileSizePref() throws ApplicationInterface.NoFreeStorageException {
        Log.d(TAG, "getVideoMaxFileSizePref");
        ApplicationInterface.VideoMaxFileSize videoMaxFileSize = new ApplicationInterface.VideoMaxFileSize();
        videoMaxFileSize.max_filesize = getVideoMaxFileSizeUserPref();
        videoMaxFileSize.auto_restart = getVideoRestartMaxFileSizeUserPref();
        boolean z = true;
        if (!this.storageUtils.isUsingSAF()) {
            String saveLocation = this.storageUtils.getSaveLocation();
            Log.d(TAG, "saving to: " + saveLocation);
            if (saveLocation.startsWith("/")) {
                File externalStorageDirectory = Environment.getExternalStorageDirectory();
                Log.d(TAG, "compare to: " + externalStorageDirectory.getAbsolutePath());
                if (!saveLocation.startsWith(externalStorageDirectory.getAbsolutePath())) {
                    z = false;
                }
            }
            Log.d(TAG, "using internal storage?" + z);
        }
        if (z) {
            Log.d(TAG, "try setting max filesize");
            long freeMemory = this.storageUtils.freeMemory();
            if (freeMemory>=0) {
                long j = freeMemory * 1024 * 1024;
                long j2 = j - 50000000;
                if (this.test_set_available_memory) {
                    j2 = this.test_available_memory;
                }
                Log.d(TAG, "free_memory: " + j);
                Log.d(TAG, "available_memory: " + j2);
                if (j2>20000000) {
                    if (videoMaxFileSize.max_filesize == 0 || videoMaxFileSize.max_filesize>j2) {
                        videoMaxFileSize.max_filesize = j2;
                        Log.d(TAG, "set video_max_filesize to avoid running out of space: " + videoMaxFileSize);
                    }
                } else {
                    Log.e(TAG, "not enough free storage to record video");
                    throw new ApplicationInterface.NoFreeStorageException();
                }
            } else {
                Log.d(TAG, "can't determine remaining free space");
            }
        }
        return videoMaxFileSize;
    }

    @Override
    public boolean getVideoFlashPref() {
        return this.sharedPreferences.getBoolean(PreferenceKeys.VideoFlashPreferenceKey, false);
    }

    @Override
    public boolean getVideoLowPowerCheckPref() {
        return this.sharedPreferences.getBoolean(PreferenceKeys.VideoLowPowerCheckPreferenceKey, true);
    }

    @Override
    public String getPreviewSizePref() {
        return this.sharedPreferences.getString(PreferenceKeys.PreviewSizePreferenceKey, "preference_preview_size_wysiwyg");
    }

    @Override // com.live.gpsmap.camera.Camera.preview.ApplicationInterface
    public String getPreviewRotationPref() {
        return this.sharedPreferences.getString(PreferenceKeys.RotatePreviewPreferenceKey, "0");
    }

    @Override
    public String getLockOrientationPref() {
        return getPhotoMode() == PhotoMode.Panorama ? "portrait" : this.sharedPreferences.getString(PreferenceKeys.LockOrientationPreferenceKey, "none");
    }

    @Override
    public boolean getTouchCapturePref() {
        return this.sharedPreferences.getString(PreferenceKeys.TouchCapturePreferenceKey, "none").equals("single");
    }

    @Override
    public boolean getDoubleTapCapturePref() {
        return this.sharedPreferences.getString(PreferenceKeys.TouchCapturePreferenceKey, "none").equals("double");
    }

    @Override
    public boolean getPausePreviewPref() {
        if (this.main_activity.getPreview().isVideoRecording() || this.main_activity.lastContinuousFastBurst() || getPhotoMode() == PhotoMode.Panorama) {
            return false;
        }
        return this.sharedPreferences.getBoolean(PreferenceKeys.PausePreviewPreferenceKey, false);
    }

    @Override
    public boolean getShowToastsPref() {
        return this.sharedPreferences.getBoolean(PreferenceKeys.ShowToastsPreferenceKey, true);
    }

    public boolean getThumbnailAnimationPref() {
        return this.sharedPreferences.getBoolean(PreferenceKeys.ThumbnailAnimationPreferenceKey, false);
    }

    @Override
    public boolean getShutterSoundPref() {
        if (getPhotoMode() == PhotoMode.Panorama) {
            return false;
        }
        return this.sharedPreferences.getBoolean(PreferenceKeys.ShutterSoundPreferenceKey, false);
    }

    public void setShutterSoundPref(boolean z) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putBoolean(PreferenceKeys.ShutterSoundPreferenceKey, z);
        edit.apply();
    }

    @Override
    public boolean getStartupFocusPref() {
        return this.sharedPreferences.getBoolean(PreferenceKeys.StartupFocusPreferenceKey, true);
    }

    @Override
    public long getTimerPref() {
        if (getPhotoMode() == PhotoMode.Panorama) {
            return 0L;
        }
        String string = this.sharedPreferences.getString(PreferenceKeys.TimerPreferenceKey, "0");
        try {
            return 1000 * Integer.parseInt(string);
        } catch (NumberFormatException e) {
            Log.e(TAG, "failed to parse preference_timer value: " + string);
            e.printStackTrace();
            return 0L;
        }
    }

    @Override
    public String getRepeatPref() {
        return getPhotoMode() == PhotoMode.Panorama ? "1" : this.sharedPreferences.getString(PreferenceKeys.RepeatModePreferenceKey, "1");
    }

    @Override
    public long getRepeatIntervalPref() {
        String s = this.sharedPreferences.getString("preference_burst_interval", "0");
        try {
            float f = Float.parseFloat(s);
            Log.d("MyApplicationInterface", "timer_delay_s: " + f);
            return (long) (f * 1000.0f);
        } catch (NumberFormatException numberFormatException0) {
            Log.e("MyApplicationInterface", "failed to parse repeat interval value: " + s);
            numberFormatException0.printStackTrace();
            return 0L;
        }
    }

    @Override
    public boolean getGeotaggingPref() {
        return this.sharedPreferences.getBoolean(PreferenceKeys.LocationPreferenceKey, true);
    }

    @Override
    public boolean getRequireLocationPref() {
        return this.sharedPreferences.getBoolean(PreferenceKeys.RequireLocationPreferenceKey, false);
    }


    public boolean getGeodirectionPref() {
        return this.sharedPreferences.getBoolean(PreferenceKeys.GPSDirectionPreferenceKey, false);
    }

    @Override
    public boolean getRecordAudioPref() {
        return this.sharedPreferences.getBoolean(PreferenceKeys.RecordAudioPreferenceKey, true);
    }

    @Override
    public String getRecordAudioChannelsPref() {
        return this.sharedPreferences.getString(PreferenceKeys.RecordAudioChannelsPreferenceKey, "audio_default");
    }

    @Override
    public String getRecordAudioSourcePref() {
        return this.sharedPreferences.getString(PreferenceKeys.RecordAudioSourcePreferenceKey, "audio_src_camcorder");
    }

    public boolean getAutoStabilisePref() {
        return this.sharedPreferences.getBoolean(PreferenceKeys.AutoStabilisePreferenceKey, false) && this.main_activity.supportsAutoStabilise();
    }

    public int getGhostImageAlpha() {
        int i;
        String string = this.sharedPreferences.getString(PreferenceKeys.GhostImageAlphaPreferenceKey, "50");
        try {
            i = Integer.parseInt(string);
        } catch (NumberFormatException e) {
            Log.e(TAG, "failed to parse ghost_image_alpha_value: " + string);
            e.printStackTrace();
            i = 50;
        }
        return (int) ((i * 2.55f) + 0.1f);
    }

    public String getStampPref() {
        return this.sharedPreferences.getString(PreferenceKeys.StampPreferenceKey, "preference_stamp_no");
    }

    private String getStampDateFormatPref() {
        return this.sharedPreferences.getString(PreferenceKeys.StampDateFormatPreferenceKey, "preference_stamp_dateformat_default");
    }

    private String getStampTimeFormatPref() {
        return this.sharedPreferences.getString(PreferenceKeys.StampTimeFormatPreferenceKey, "preference_stamp_timeformat_default");
    }

    private String getStampGPSFormatPref() {
        return this.sharedPreferences.getString(PreferenceKeys.StampGPSFormatPreferenceKey, "preference_stamp_gpsformat_default");
    }

    private String getStampGeoAddressPref() {
        return this.sharedPreferences.getString(PreferenceKeys.StampGeoAddressPreferenceKey, "preference_stamp_geo_address_no");
    }

    private String getUnitsDistancePref() {
        return this.sharedPreferences.getString(PreferenceKeys.UnitsDistancePreferenceKey, "preference_units_distance_m");
    }

    public String getTextStampPref() {
        return this.sharedPreferences.getString(PreferenceKeys.TextStampPreferenceKey, "");
    }

    private int getTextStampFontSizePref() {
        int i;
        String string = this.sharedPreferences.getString(PreferenceKeys.StampFontSizePreferenceKey, "12");
        Log.d(TAG, "saved font size: " + string);
        try {
            i = Integer.parseInt(string);
        } catch (NumberFormatException unused) {
            i = 12;
        }
        try {
            Log.d(TAG, "::::" + i);
        } catch (NumberFormatException unused2) {
            Log.d(TAG, "font size invalid format, can't parse to int");
            return i;
        }
        return i;
    }

    private String getVideoSubtitlePref() {
        return this.sharedPreferences.getString(PreferenceKeys.VideoSubtitlePref, "preference_video_subtitle_no");
    }

    @Override
    public int getZoomPref() {
        Log.d(TAG, "getZoomPref: " + this.zoom_factor);
        return this.zoom_factor;
    }

    @Override
    public void setZoomPref(int i) {
        Log.d(TAG, "setZoomPref: " + i);
        this.zoom_factor = i;
    }

    @Override
    public double getCalibratedLevelAngle() {
        return this.sharedPreferences.getFloat(PreferenceKeys.CalibratedLevelAnglePreferenceKey, 0.0f);
    }

    @Override
    public boolean canTakeNewPhoto() {
        int burstNImages;
        int i;
        Log.d(TAG, "canTakeNewPhoto");
        if (this.main_activity.getPreview().isVideo()) {
            burstNImages = 0;
            i = 1;
        } else {
            if (this.main_activity.getPreview().supportsExpoBracketing() && isExpoBracketingPref()) {
                burstNImages = getExpoBracketingNImagesPref();
            } else if ((this.main_activity.getPreview().supportsFocusBracketing() && isFocusBracketingPref()) || !this.main_activity.getPreview().supportsBurst() || !isCameraBurstPref()) {
                burstNImages = 1;
            } else if (getBurstForNoiseReduction()) {
                burstNImages = getNRModePref() == ApplicationInterface.NRModePref.NRMODE_LOW_LIGHT ? 15 : 8;
            } else {
                burstNImages = getBurstNImages();
            }
            if (this.main_activity.getPreview().supportsRaw() && getRawPref() == ApplicationInterface.RawPref.RAWPREF_JPEG_DNG) {
                i = burstNImages;
            } else {
                i = burstNImages;
                burstNImages = 0;
            }
        }
        int computePhotoCost = this.imageSaver.computePhotoCost(burstNImages, i);
        if (this.imageSaver.queueWouldBlock(computePhotoCost)) {
            Log.d(TAG, "canTakeNewPhoto: no, as queue would block");
            return false;
        }
        int nImagesToSave = this.imageSaver.getNImagesToSave();
        PhotoMode photoMode = getPhotoMode();
        if ((photoMode == PhotoMode.FastBurst || photoMode == PhotoMode.Panorama) && nImagesToSave>0) {
            Log.d(TAG, "canTakeNewPhoto: no, as too many for fast burst");
            return false;
        } else if (photoMode == PhotoMode.NoiseReduction && nImagesToSave>=computePhotoCost * 2) {
            Log.d(TAG, "canTakeNewPhoto: no, as too many for nr");
            return false;
        } else if (i>1 && nImagesToSave>=computePhotoCost * 3) {
            Log.d(TAG, "canTakeNewPhoto: no, as too many for burst");
            return false;
        } else if (burstNImages>0 && nImagesToSave>=computePhotoCost * 3) {
            Log.d(TAG, "canTakeNewPhoto: no, as too many for raw");
            return false;
        } else if (nImagesToSave<computePhotoCost * 5 || (this.main_activity.supportsNoiseReduction() && nImagesToSave<=8)) {
            return true;
        } else {
            Log.d(TAG, "canTakeNewPhoto: no, as too many for regular");
            return false;
        }
    }

    @Override
    public boolean imageQueueWouldBlock(int i, int i2) {
        Log.d(TAG, "imageQueueWouldBlock");
        return this.imageSaver.queueWouldBlock(i, i2);
    }

    @Override
    public long getExposureTimePref() {
        return this.sharedPreferences.getLong(PreferenceKeys.ExposureTimePreferenceKey, CameraController.EXPOSURE_TIME_DEFAULT);
    }

    @Override
    public void setExposureTimePref(long j) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putLong(PreferenceKeys.ExposureTimePreferenceKey, j);
        edit.apply();
    }

    @Override
    public float getFocusDistancePref(boolean z) {
        return this.sharedPreferences.getFloat(z ? PreferenceKeys.FocusBracketingTargetDistancePreferenceKey : PreferenceKeys.FocusDistancePreferenceKey, 0.0f);
    }

    @Override
    public boolean isExpoBracketingPref() {
        PhotoMode photoMode = getPhotoMode();
        return photoMode == PhotoMode.HDR || photoMode == PhotoMode.ExpoBracketing;
    }

    @Override
    public boolean isFocusBracketingPref() {
        return getPhotoMode() == PhotoMode.FocusBracketing;
    }

    @Override
    public boolean isCameraBurstPref() {
        PhotoMode photoMode = getPhotoMode();
        return photoMode == PhotoMode.FastBurst || photoMode == PhotoMode.NoiseReduction;
    }

    @Override
    public int getBurstNImages() {
        if (getPhotoMode() == PhotoMode.FastBurst) {
            String string = this.sharedPreferences.getString(PreferenceKeys.FastBurstNImagesPreferenceKey, "5");
            try {
                return Integer.parseInt(string);
            } catch (NumberFormatException e) {
                Log.e(TAG, "failed to parse FastBurstNImagesPreferenceKey value: " + string);
                e.printStackTrace();
                return 5;
            }
        }
        return 1;
    }

    @Override
    public boolean getBurstForNoiseReduction() {
        return getPhotoMode() == PhotoMode.NoiseReduction;
    }

    public String getNRMode() {
        return this.nr_mode;
    }

    public void setNRMode(String str) {
        this.nr_mode = str;
    }

    @Override
    public ApplicationInterface.NRModePref getNRModePref() {
        String str = this.nr_mode;
        str.hashCode();
        if (str.equals("preference_nr_mode_low_light")) {
            return ApplicationInterface.NRModePref.NRMODE_LOW_LIGHT;
        }
        return ApplicationInterface.NRModePref.NRMODE_NORMAL;
    }

    public void setAperture(float f) {
        this.aperture = f;
    }

    @Override
    public float getAperturePref() {
        return this.aperture;
    }

    @Override
    public int getExpoBracketingNImagesPref() {
        Log.d(TAG, "getExpoBracketingNImagesPref");
        int i = 3;
        if (getPhotoMode() != PhotoMode.HDR) {
            String string = this.sharedPreferences.getString(PreferenceKeys.ExpoBracketingNImagesPreferenceKey, ExifInterface.GPS_MEASUREMENT_3D);
            try {
                i = Integer.parseInt(string);
            } catch (NumberFormatException unused) {
                Log.e(TAG, "n_images_s invalid format: " + string);
            }
        }
        Log.d(TAG, "n_images = " + i);
        return i;
    }

    @Override
    public double getExpoBracketingStopsPref() {
        Log.d(TAG, "getExpoBracketingStopsPref");
        double d = 2.0d;
        if (getPhotoMode() != PhotoMode.HDR) {
            String string = this.sharedPreferences.getString(PreferenceKeys.ExpoBracketingStopsPreferenceKey, ExifInterface.GPS_MEASUREMENT_2D);
            try {
                d = Double.parseDouble(string);
            } catch (NumberFormatException unused) {
                Log.e(TAG, "n_stops_s invalid format: " + string);
            }
        }
        Log.d(TAG, "n_stops = " + d);
        return d;
    }

    @Override
    public int getFocusBracketingNImagesPref() {
        int i;
        Log.d(TAG, "getFocusBracketingNImagesPref");
        String string = this.sharedPreferences.getString(PreferenceKeys.FocusBracketingNImagesPreferenceKey, ExifInterface.GPS_MEASUREMENT_3D);
        try {
            i = Integer.parseInt(string);
        } catch (NumberFormatException unused) {
            Log.e(TAG, "n_images_s invalid format: " + string);
            i = 3;
        }
        Log.d(TAG, "n_images = " + i);
        return i;
    }

    @Override
    public boolean getFocusBracketingAddInfinityPref() {
        return this.sharedPreferences.getBoolean(PreferenceKeys.FocusBracketingAddInfinityPreferenceKey, false);
    }

    public PhotoMode getPhotoMode() {
        String string = this.sharedPreferences.getString(PreferenceKeys.PhotoModePreferenceKey, "preference_photo_mode_std");
        if (string.equals("preference_photo_mode_dro") && this.main_activity.supportsDRO()) {
            return PhotoMode.DRO;
        }
        if (string.equals("preference_photo_mode_hdr") && this.main_activity.supportsHDR()) {
            return PhotoMode.HDR;
        }
        if (string.equals("preference_photo_mode_expo_bracketing") && this.main_activity.supportsExpoBracketing()) {
            return PhotoMode.ExpoBracketing;
        }
        if (string.equals("preference_photo_mode_focus_bracketing") && this.main_activity.supportsFocusBracketing()) {
            return PhotoMode.FocusBracketing;
        }
        if (string.equals("preference_photo_mode_fast_burst") && this.main_activity.supportsFastBurst()) {
            return PhotoMode.FastBurst;
        }
        if (string.equals("preference_photo_mode_noise_reduction") && this.main_activity.supportsNoiseReduction()) {
            return PhotoMode.NoiseReduction;
        }
        if (string.equals("preference_photo_mode_panorama") && !this.main_activity.getPreview().isVideo() && this.main_activity.supportsPanorama()) {
            return PhotoMode.Panorama;
        }
        return PhotoMode.Standard;
    }

    @Override // com.live.gpsmap.camera.Camera.preview.ApplicationInterface
    public boolean getOptimiseAEForDROPref() {
        return getPhotoMode() == PhotoMode.DRO;
    }

    private ImageSaver.Request.ImageFormat getImageFormatPref() {
        String string = this.sharedPreferences.getString(PreferenceKeys.ImageFormatPreferenceKey, "preference_image_format_jpeg");
        string.hashCode();
        if (string.equals("preference_image_format_png")) {
            return ImageSaver.Request.ImageFormat.PNG;
        }
        if (string.equals("preference_image_format_webp")) {
            return ImageSaver.Request.ImageFormat.WEBP;
        }
        return ImageSaver.Request.ImageFormat.STD;
    }

    public boolean isRawAllowed(PhotoMode photoMode) {
        if (isImageCaptureIntent() || this.main_activity.getPreview().isVideo()) {
            return false;
        }
        if (photoMode == PhotoMode.Standard || photoMode == PhotoMode.DRO) {
            return true;
        }
        return photoMode == PhotoMode.ExpoBracketing ? this.sharedPreferences.getBoolean(PreferenceKeys.AllowRawForExpoBracketingPreferenceKey, true) && this.main_activity.supportsBurstRaw() : photoMode == PhotoMode.HDR ? this.sharedPreferences.getBoolean(PreferenceKeys.HDRSaveExpoPreferenceKey, false) && this.sharedPreferences.getBoolean(PreferenceKeys.AllowRawForExpoBracketingPreferenceKey, true) && this.main_activity.supportsBurstRaw() : photoMode == PhotoMode.FocusBracketing && this.sharedPreferences.getBoolean(PreferenceKeys.AllowRawForFocusBracketingPreferenceKey, true) && this.main_activity.supportsBurstRaw();
    }

    @Override
    public ApplicationInterface.RawPref getRawPref() {
        if (isRawAllowed(getPhotoMode())) {
            String string = this.sharedPreferences.getString(PreferenceKeys.RawPreferenceKey, "preference_raw_no");
            string.hashCode();
            if (string.equals("preference_raw_only") || string.equals("preference_raw_yes")) {
                return ApplicationInterface.RawPref.RAWPREF_JPEG_DNG;
            }
        }
        return ApplicationInterface.RawPref.RAWPREF_JPEG_ONLY;
    }

    public boolean isRawOnly() {
        return isRawOnly(getPhotoMode());
    }

    public boolean isRawOnly(PhotoMode photoMode) {
        if (isRawAllowed(photoMode)) {
            String string = this.sharedPreferences.getString(PreferenceKeys.RawPreferenceKey, "preference_raw_no");
            string.hashCode();
            return string.equals("preference_raw_only");
        }
        return false;
    }

    @Override
    public int getMaxRawImages() {
        return this.imageSaver.getMaxDNG();
    }

    @Override
    public boolean useCamera2FakeFlash() {
        return this.sharedPreferences.getBoolean(PreferenceKeys.Camera2FakeFlashPreferenceKey, false);
    }

    @Override
    public boolean useCamera2FastBurst() {
        return this.sharedPreferences.getBoolean(PreferenceKeys.Camera2FastBurstPreferenceKey, true);
    }

    @Override
    public boolean usePhotoVideoRecording() {
        if (useCamera2()) {
            return this.sharedPreferences.getBoolean(PreferenceKeys.Camera2PhotoVideoRecordingPreferenceKey, true);
        }
        return true;
    }

    @Override
    public boolean isPreviewInBackground() {
        return this.main_activity.isCameraInBackground();
    }

    @Override
    public boolean allowZoom() {
        return getPhotoMode() != PhotoMode.Panorama;
    }

    @Override
    public boolean isTestAlwaysFocus() {
        Log.d(TAG, "isTestAlwaysFocus: " + this.main_activity.is_test);
        return this.main_activity.is_test;
    }

    @Override
    public void cameraSetup() {
        this.main_activity.cameraSetup();
        this.drawPreview.clearContinuousFocusMove();
        this.drawPreview.updateSettings();
    }

    @Override
    public void onContinuousFocusMove(boolean z) {
        Log.d(TAG, "onContinuousFocusMove: " + z);
        this.drawPreview.onContinuousFocusMove(z);
    }

    public void startPanorama() {
        Log.d(TAG, "startPanorama");
        this.gyroSensor.startRecording();
        this.n_panorama_pics = 0;
        this.panorama_pic_accepted = false;
        this.panorama_dir_left_to_right = true;
        this.main_activity.getMainUI().setTakePhotoIcon();
    }

    public void finishPanorama() {
        Log.d(TAG, "finishPanorama");
        this.imageSaver.getImageBatchRequest().panorama_dir_left_to_right = this.panorama_dir_left_to_right;
        stopPanorama(false);
        this.imageSaver.finishImageBatch(saveInBackground(isImageCaptureIntent()));
    }

    public void stopPanorama(boolean z) {
        Log.d(TAG, "stopPanorama");
        if (!this.gyroSensor.isRecording()) {
            Log.d(TAG, "...nothing to stop");
            return;
        }
        this.gyroSensor.stopRecording();
        clearPanoramaPoint();
        if (z) {
            this.imageSaver.flushImageBatch();
        }
        this.main_activity.getMainUI().setTakePhotoIcon();
    }

    private void setNextPanoramaPoint(boolean z) {
        Log.d(TAG, "setNextPanoramaPoint");
        float viewAngleY = this.main_activity.getPreview().getViewAngleY(false);
        if (!z) {
            this.n_panorama_pics++;
        }
        Log.d(TAG, "n_panorama_pics is now: " + this.n_panorama_pics);
        if (this.n_panorama_pics == 10) {
            Log.d(TAG, "reached max panorama limit");
            finishPanorama();
            return;
        }
        float radians = (float) Math.toRadians(viewAngleY);
        int i = this.n_panorama_pics;
        float f = radians * i;
        if (i>1 && !this.panorama_dir_left_to_right) {
            f = -f;
        }
        double d = f / panorama_pics_per_screen;
        setNextPanoramaPoint((float) Math.sin(d), 0.0f, (float) (-Math.cos(d)));
        if (this.n_panorama_pics == 1) {
            double d2 = (-f) / panorama_pics_per_screen;
            float sin = (float) Math.sin(d2);
            float f2 = (float) (-Math.cos(d2));
            this.gyroSensor.addTarget(sin, 0.0f, f2);
            this.drawPreview.addGyroDirectionMarker(sin, 0.0f, f2);
        }
    }

    private void setNextPanoramaPoint(float f, float f2, float f3) {
        Log.d(TAG, "setNextPanoramaPoint : " + f + " , " + f2 + " , " + f3);
        this.gyroSensor.setTarget(f, f2, f3, 0.017453292f, 0.03490481f, 0.7853982f, new GyroSensor.TargetCallback() { // from class: com.live.gpsmap.camera.Camera.MyApplicationInterface.1
            @Override // com.live.gpsmap.camera.Camera.GyroSensor.TargetCallback
            public void onAchieved(int i) {
                Log.d(MyApplicationInterface.TAG, "TargetCallback.onAchieved: " + i);
                Log.d(MyApplicationInterface.TAG, "    n_panorama_pics: " + MyApplicationInterface.this.n_panorama_pics);
                MyApplicationInterface.this.gyroSensor.disableTargetCallback();
                if (MyApplicationInterface.this.n_panorama_pics == 1) {
                    MyApplicationInterface.this.panorama_dir_left_to_right = i == 0;
                    Log.d(MyApplicationInterface.TAG, "set panorama_dir_left_to_right to " + MyApplicationInterface.this.panorama_dir_left_to_right);
                }
                MyApplicationInterface.this.main_activity.takePicturePressed(false, false);
            }

            @Override // com.live.gpsmap.camera.Camera.GyroSensor.TargetCallback
            public void onTooFar() {
                Log.d(MyApplicationInterface.TAG, "TargetCallback.onTooFar");
                if (MyApplicationInterface.this.main_activity.is_test) {
                    return;
                }
                MyApplicationInterface.this.main_activity.getPreview().showToast((ToastBoxer) null, R.string.panorama_cancelled);
                MyApplicationInterface.this.stopPanorama(true);
            }
        });
        this.drawPreview.setGyroDirectionMarker(f, f2, f3);
    }

    private void clearPanoramaPoint() {
        Log.d(TAG, "clearPanoramaPoint");
        this.gyroSensor.clearTarget();
        this.drawPreview.clearGyroDirectionMarker();
    }

    @Override
    public void touchEvent(MotionEvent motionEvent) {
        this.main_activity.closePopup();
        if (this.main_activity.usingKitKatImmersiveMode()) {
            this.main_activity.setImmersiveMode(false);
        }
    }

    @Override
    public void startingVideo() {
        if (this.sharedPreferences.getBoolean(PreferenceKeys.LockVideoPreferenceKey, false)) {
            this.main_activity.lockScreen();
        }
        this.main_activity.stopAudioListeners();
        ((ImageButton) this.main_activity.findViewById(R.id.take_photo)).setContentDescription(getContext().getResources().getString(R.string.stop_video));
        this.main_activity.getMainUI().destroyPopup();
    }

    @Override
    public void startedVideo() {
        if (MyDebug.LOG)
            Log.d(TAG, "startedVideo()");
        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.N) {
            if (!(main_activity.getMainUI().inImmersiveMode() && main_activity.usingKitKatImmersiveModeEverything())) {
//                View pauseVideoButton = main_activity.findViewById(R.id.pause_video);
//                pauseVideoButton.setVisibility(View.VISIBLE);
            }
            main_activity.getMainUI().setPauseVideoContentDescription();
        }
        if (main_activity.getPreview().supportsPhotoVideoRecording() && this.usePhotoVideoRecording()) {
            if (!(main_activity.getMainUI().inImmersiveMode() && main_activity.usingKitKatImmersiveModeEverything())) {
                View takePhotoVideoButton = main_activity.findViewById(R.id.take_photo);
                takePhotoVideoButton.setVisibility(View.VISIBLE);
            }
        }
        final int video_method = this.createOutputVideoMethod().getDeclaringClass().getModifiers();
        boolean dategeo_subtitles = getVideoSubtitlePref().equals("preference_video_subtitle_yes");
        if (dategeo_subtitles && video_method != 3) {
            final String preference_stamp_dateformat = this.getStampDateFormatPref();
            final String preference_stamp_timeformat = this.getStampTimeFormatPref();
            final String preference_stamp_gpsformat = this.getStampGPSFormatPref();
            final boolean store_location = getGeotaggingPref();
            final boolean store_geo_direction = getGeodirectionPref();
            class SubtitleVideoTimerTask extends TimerTask {
                OutputStreamWriter writer;
                private int count = 1;
                private long min_video_time_from = 0;

                private String getSubtitleFilename(String video_filename) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "getSubtitleFilename");
                    int indx = video_filename.indexOf('.');
                    if (indx != -1) {
                        video_filename = video_filename.substring(0, indx);
                    }
                    video_filename = video_filename + ".srt";
                    if (MyDebug.LOG)
                        Log.d(TAG, "return filename: " + video_filename);
                    return video_filename;
                }

                public void run() {
                    if (MyDebug.LOG)
                        Log.d(TAG, "SubtitleVideoTimerTask run");
                    long video_time = main_activity.getPreview().getVideoTime();
                    if (!main_activity.getPreview().isVideoRecording()) {
                        if (MyDebug.LOG)
                            Log.d(TAG, "no longer video recording");
                        return;
                    }
                    if (main_activity.getPreview().isVideoRecordingPaused()) {
                        if (MyDebug.LOG)
                            Log.d(TAG, "video recording is paused");
                        return;
                    }
                    Date current_date = new Date();
                    Calendar current_calendar = Calendar.getInstance();
                    int offset_ms = current_calendar.get(Calendar.MILLISECOND);
                    // We subtract an offset, because if the current time is say 00:00:03.425 and the video has been recording for
                    // 1s, we instead need to record the video time when it became 00:00:03.000. This does mean that the GPS
                    // location is going to be off by up to 1s, but that should be less noticeable than the clock being off.
                    if (MyDebug.LOG) {
                        Log.d(TAG, "count: " + count);
                        Log.d(TAG, "offset_ms: " + offset_ms);
                        Log.d(TAG, "video_time: " + video_time);
                    }
                    String date_stamp = TextFormatter.getDateString(preference_stamp_dateformat, current_date);
                    String time_stamp = TextFormatter.getTimeString(preference_stamp_timeformat, current_date);
                    Location location = store_location ? getLocation() : null;
                    double geo_direction = store_geo_direction && main_activity.getPreview().hasGeoDirection() ? main_activity.getPreview().getGeoDirection() : 0.0;
                    String gps_stamp = main_activity.getTextFormatter().getGPSString(preference_stamp_gpsformat, getUnitsDistancePref(), store_location && location != null, location, store_geo_direction && main_activity.getPreview().hasGeoDirection(), geo_direction);
                    if (MyDebug.LOG) {
                        Log.d(TAG, "date_stamp: " + date_stamp);
                        Log.d(TAG, "time_stamp: " + time_stamp);
                        Log.d(TAG, "gps_stamp: " + gps_stamp);
                    }
                    String datetime_stamp = "";
                    if (date_stamp.length()>0)
                        datetime_stamp += date_stamp;
                    if (time_stamp.length()>0) {
                        if (datetime_stamp.length()>0)
                            datetime_stamp += " ";
                        datetime_stamp += time_stamp;
                    }
                    String subtitles = "";
                    if (datetime_stamp.length()>0)
                        subtitles += datetime_stamp + "\n";
                    if (gps_stamp.length()>0)
                        subtitles += gps_stamp + "\n";
                    if (subtitles.length() == 0) {
                        return;
                    }
                    long video_time_from = video_time - offset_ms;
                    long video_time_to = video_time_from + 999;
                    // don't want to start from before 0; also need to keep track of min_video_time_from to avoid bug reported at
                    // https://forum.xda-developers.com/showpost.php?p=74827802&postcount=345 for pause video where we ended up
                    // with overlapping times when resuming
                    if (video_time_from<min_video_time_from)
                        video_time_from = min_video_time_from;
                    min_video_time_from = video_time_to + 1;
                    String subtitle_time_from = TextFormatter.formatTimeMS(video_time_from);
                    String subtitle_time_to = TextFormatter.formatTimeMS(video_time_to);
                    try {
                        synchronized (this) {
                            if (writer == null) {
                                if (video_method == 0) {
                                    String subtitle_filename = last_video_file.getAbsolutePath();
                                    subtitle_filename = getSubtitleFilename(subtitle_filename);
                                    writer = new FileWriter(subtitle_filename);
                                } else {
                                    if (MyDebug.LOG)
                                        Log.d(TAG, "last_video_file_saf: " + last_video_file_saf);
                                    File file = storageUtils.getFileFromDocumentUriSAF(last_video_file_saf, false);
                                    String subtitle_filename = file.getName();
                                    subtitle_filename = getSubtitleFilename(subtitle_filename);
                                    Uri subtitle_uri = storageUtils.createOutputFileSAF(subtitle_filename, ""); // don't set a mimetype, as we don't want it to append a new extension
                                    ParcelFileDescriptor pfd_saf = getContext().getContentResolver().openFileDescriptor(subtitle_uri, "w");
                                    writer = new FileWriter(pfd_saf.getFileDescriptor());
                                }
                            }
                            if (writer != null) {
                                writer.append(Integer.toString(count));
                                writer.append('\n');
                                writer.append(subtitle_time_from);
                                writer.append(" --> ");
                                writer.append(subtitle_time_to);
                                writer.append('\n');
                                writer.append(subtitles); // subtitles should include the '\n' at the end
                                writer.append('\n'); // additional newline to indicate end of this subtitle
                                writer.flush();
                                // n.b., we flush rather than closing/reopening the writer each time, as appending doesn't seem to work with storage access framework
                            }
                        }
                        count++;
                    } catch (IOException e) {
                        if (MyDebug.LOG)
                            Log.e(TAG, "SubtitleVideoTimerTask failed to create or write");
                        e.printStackTrace();
                    }
                    if (MyDebug.LOG)
                        Log.d(TAG, "SubtitleVideoTimerTask exit");
                }

                public boolean cancel() {
                    if (MyDebug.LOG)
                        Log.d(TAG, "SubtitleVideoTimerTask cancel");
                    synchronized (this) {
                        if (writer != null) {
                            if (MyDebug.LOG)
                                Log.d(TAG, "close writer");
                            try {
                                writer.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            writer = null;
                        }
                    }
                    return super.cancel();
                }
            }
            subtitleVideoTimer.schedule(subtitleVideoTimerTask = new SubtitleVideoTimerTask(), 0, 1000);
        }
    }


    @Override
    public void stoppingVideo() {
        Log.d(TAG, "stoppingVideo()");
        this.main_activity.unlockScreen();
        ((ImageButton) this.main_activity.findViewById(R.id.take_photo)).setContentDescription(getContext().getResources().getString(R.string.start_video));
    }


    @Override
    public void stoppedVideo(int video_method, final Uri uri, final String filename) {
        if (MyDebug.LOG) {
            Log.d(TAG, "stoppedVideo");
            Log.d(TAG, "video_method " + video_method);
            Log.d(TAG, "uri " + uri);
            Log.d(TAG, "filename " + filename);
        }
//        View pauseVideoButton = main_activity.findViewById(R.id.pause_video);
//        pauseVideoButton.setVisibility(View.GONE);
        View takePhotoVideoButton = main_activity.findViewById(R.id.take_photo);
        takePhotoVideoButton.setVisibility(View.GONE);
        main_activity.getMainUI().setPauseVideoContentDescription(); // just to be safe
        main_activity.getMainUI().destroyPopup(); // as the available popup options change while recording video
        if (subtitleVideoTimerTask != null) {
            subtitleVideoTimerTask.cancel();
            subtitleVideoTimerTask = null;
        }

        boolean done = false;
        if (video_method == 0) {
            if (filename != null) {
                File file = new File(filename);
                storageUtils.broadcastFile(file, false, true, true);
                done = true;
            }
        } else {
            if (uri != null) {
                // see note in onPictureTaken() for where we call broadcastFile for SAF photos
                File real_file = storageUtils.getFileFromDocumentUriSAF(uri, false);
                if (MyDebug.LOG)
                    Log.d(TAG, "real_file: " + real_file);
                if (real_file != null) {
                    storageUtils.broadcastFile(real_file, false, true, true);
                    main_activity.test_last_saved_image = real_file.getAbsolutePath();
                } else {
                    // announce the SAF Uri
                    storageUtils.announceUri(uri, false, true);
                }
                done = true;
            }
        }
        if (MyDebug.LOG)
            Log.d(TAG, "done? " + done);

        String action = main_activity.getIntent().getAction();
        if (MediaStore.ACTION_VIDEO_CAPTURE.equals(action)) {
            if (done && video_method == 0) {
                // do nothing here - we end the activity from storageUtils.broadcastFile after the file has been scanned, as it seems caller apps seem to prefer the content:// Uri rather than one based on a File
            } else {
                if (MyDebug.LOG)
                    Log.d(TAG, "from video capture intent");
                Intent output = null;
                if (done) {
                    // may need to pass back the Uri we saved to, if the calling application didn't specify a Uri
                    // set note above for VIDEOMETHOD_FILE
                    // n.b., currently this code is not used, as we always switch to VIDEOMETHOD_FILE if the calling application didn't specify a Uri, but I've left this here for possible future behaviour
                    if (video_method == 1) {
                        output = new Intent();
                        output.setData(uri);
                        if (MyDebug.LOG)
                            Log.d(TAG, "pass back output uri [saf]: " + output.getData());
                    }
                }
                main_activity.setResult(done ? Activity.RESULT_OK : Activity.RESULT_CANCELED, output);
                main_activity.finish();
            }
        } else if (done) {
            // create thumbnail
            long debug_time = System.currentTimeMillis();
            Bitmap thumbnail = null;
            MediaMetadataRetriever retriever = new MediaMetadataRetriever();
            try {
                if (video_method == 0) {
                    File file = new File(filename);
                    retriever.setDataSource(file.getPath());
                } else {
                    ParcelFileDescriptor pfd_saf = getContext().getContentResolver().openFileDescriptor(uri, "r");
                    retriever.setDataSource(pfd_saf.getFileDescriptor());
                }
                thumbnail = retriever.getFrameAtTime(-1);
            } catch (FileNotFoundException | /*IllegalArgumentException |*/ RuntimeException e) {
                // video file wasn't saved or corrupt video file?
                Log.d(TAG, "failed to find thumbnail");
                e.printStackTrace();
            } finally {
                try {
                    retriever.release();
                } catch (RuntimeException ex) {
                    // ignore
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if (thumbnail != null) {
                ImageButton galleryButton = main_activity.findViewById(R.id.img_gallery);
                int width = thumbnail.getWidth();
                int height = thumbnail.getHeight();
                if (MyDebug.LOG)
                    Log.d(TAG, "    video thumbnail size " + width + " x " + height);
                if (width>galleryButton.getWidth()) {
                    float scale = (float) galleryButton.getWidth() / width;
                    int new_width = Math.round(scale * width);
                    int new_height = Math.round(scale * height);
                    if (MyDebug.LOG)
                        Log.d(TAG, "    scale video thumbnail to " + new_width + " x " + new_height);
                    Bitmap scaled_thumbnail = Bitmap.createScaledBitmap(thumbnail, new_width, new_height, true);
                    // careful, as scaled_thumbnail is sometimes not a copy!
                    if (scaled_thumbnail != thumbnail) {
                        thumbnail.recycle();
                        thumbnail = scaled_thumbnail;
                    }
                }
                final Bitmap thumbnail_f = thumbnail;
                main_activity.runOnUiThread(new Runnable() {
                    public void run() {
                        updateThumbnail(thumbnail_f, true);
                    }
                });
            }
            if (MyDebug.LOG)
                Log.d(TAG, "    time to create thumbnail: " + (System.currentTimeMillis() - debug_time));
        }
    }

    //     this.main_activity.runOnUiThread(new Runnable() { // from class: com.live.gpsmap.camera.Camera.MyApplicationInterface.2
//        @Override // java.lang.Runnable
//        public void run() {
//            MyApplicationInterface.this.updateThumbnail(bitmap, true);
//        }
//    });
    private void completeVideo(ApplicationInterface.VideoMethod videoMethod, Uri uri) {
        Log.d(TAG, "completeVideo");
        if (videoMethod != ApplicationInterface.VideoMethod.MEDIASTORE || Build.VERSION.SDK_INT<29) {
            return;
        }
        ContentValues contentValues = new ContentValues();
        contentValues.put("is_pending", (Integer) 0);
        this.main_activity.getContentResolver().update(uri, contentValues, null, null);
    }

    @Override
    public void restartedVideo(ApplicationInterface.VideoMethod videoMethod, Uri uri, String str) {
        String str2 = TAG;
        Log.d(str2, "restartedVideo");
        Log.d(str2, "video_method " + videoMethod);
        Log.d(str2, "uri " + uri);
        Log.d(str2, "filename " + str);
        completeVideo(videoMethod, uri);
        broadcastVideo(videoMethod, uri, str);
    }

    private boolean broadcastVideo(ApplicationInterface.VideoMethod videoMethod, Uri uri, String str) {
        Log.d(TAG, "broadcastVideo");
        Log.d(TAG, "video_method " + videoMethod);
        Log.d(TAG, "uri " + uri);
        Log.d(TAG, "filename " + str);
        boolean z = false;
        if (videoMethod == ApplicationInterface.VideoMethod.MEDIASTORE) {
            if (uri != null) {
                this.storageUtils.announceUri(uri, false, true);
                this.storageUtils.setLastMediaScanned(uri);
                z = true;
            }
        } else if (videoMethod == ApplicationInterface.VideoMethod.FILE) {
            if (str != null) {
                this.storageUtils.broadcastFile(new File(str), false, true, true);
                z = true;
            }
        } else if (uri != null) {
            this.storageUtils.broadcastUri(uri, false, true, true, false);
            z = true;
        }
        if (z) {
            this.test_n_videos_scanned++;
            Log.d(TAG, "test_n_videos_scanned is now: " + this.test_n_videos_scanned);
        }
        if (videoMethod == ApplicationInterface.VideoMethod.MEDIASTORE && isVideoCaptureIntent()) {
            finishVideoIntent(uri);
        }
        return z;
    }

    @Override
    public void deleteUnusedVideo(ApplicationInterface.VideoMethod videoMethod, Uri uri, String str) {
        Log.d(TAG, "deleteUnusedVideo");
        Log.d(TAG, "video_method " + videoMethod);
        Log.d(TAG, "uri " + uri);
        Log.d(TAG, "filename " + str);
        if (videoMethod == ApplicationInterface.VideoMethod.FILE) {
            trashImage(LastImagesType.FILE, uri, str, false);
        } else if (videoMethod == ApplicationInterface.VideoMethod.SAF) {
            trashImage(LastImagesType.SAF, uri, str, false);
        } else if (videoMethod == ApplicationInterface.VideoMethod.MEDIASTORE) {
            trashImage(LastImagesType.MEDIASTORE, uri, str, false);
        }
    }

    @Override
    public void onVideoInfo(int i, int i2) {
        if (Build.VERSION.SDK_INT>=26 && i == 803) {
            Log.d(TAG, "next output file started");
            this.main_activity.getPreview().showToast((ToastBoxer) null, R.string.video_max_filesize);
        } else if (i == 801) {
            Log.d(TAG, "max filesize reached");
            this.main_activity.getPreview().showToast((ToastBoxer) null, R.string.video_max_filesize);
        }
        String str = "info_" + i + "_" + i2;
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putString("last_video_error", str);
        edit.apply();
    }

    @Override
    public void onFailedStartPreview() {
        this.main_activity.getPreview().showToast((ToastBoxer) null, R.string.failed_to_start_camera_preview);
    }

    @Override
    public void onCameraError() {
        this.main_activity.getPreview().showToast((ToastBoxer) null, R.string.camera_error);
    }

    @Override
    public void onPhotoError() {
        this.main_activity.getPreview().showToast((ToastBoxer) null, R.string.failed_to_take_picture);
    }

    @Override
    public void onVideoError(int i, int i2) {
        int i3;
        Log.d(TAG, "onVideoError: " + i + " extra: " + i2);
        if (i == 100) {
            Log.d(TAG, "error: server died");
            i3 = R.string.video_error_server_died;
        } else {
            i3 = R.string.video_error_unknown;
        }
        this.main_activity.getPreview().showToast((ToastBoxer) null, i3);
        String str = "error_" + i + "_" + i2;
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putString("last_video_error", str);
        edit.apply();
    }

    @Override
    public void onVideoRecordStartError(VideoProfile videoProfile) {
        String string;
        Log.d(TAG, "onVideoRecordStartError");
        String errorFeatures = this.main_activity.getPreview().getErrorFeatures(videoProfile);
        if (errorFeatures.length()>0) {
            string = getContext().getResources().getString(R.string.sorry) + ", " + errorFeatures + " " + getContext().getResources().getString(R.string.not_supported);
        } else {
            string = getContext().getResources().getString(R.string.failed_to_record_video);
        }
        this.main_activity.getPreview().showToast((ToastBoxer) null, string);
        ((ImageButton) this.main_activity.findViewById(R.id.take_photo)).setContentDescription(getContext().getResources().getString(R.string.start_video));
    }

    @Override
    public void onVideoRecordStopError(VideoProfile videoProfile) {
        Log.d(TAG, "onVideoRecordStopError");
        String errorFeatures = this.main_activity.getPreview().getErrorFeatures(videoProfile);
        String string = getContext().getResources().getString(R.string.video_may_be_corrupted);
        if (errorFeatures.length()>0) {
            string = string + ", " + errorFeatures + " " + getContext().getResources().getString(R.string.not_supported);
        }
        this.main_activity.getPreview().showToast((ToastBoxer) null, string);
    }

    @Override
    public void onFailedReconnectError() {
        this.main_activity.getPreview().showToast((ToastBoxer) null, R.string.failed_to_reconnect_camera);
    }

    @Override
    public void onFailedCreateVideoFileError() {
        this.main_activity.getPreview().showToast((ToastBoxer) null, R.string.failed_to_save_video);
        ((ImageButton) this.main_activity.findViewById(R.id.take_photo)).setContentDescription(getContext().getResources().getString(R.string.start_video));
    }

    @Override
    public void hasPausedPreview(boolean z) {
        Log.d(TAG, "hasPausedPreview: " + z);
        if (z) {
            return;
        }
        clearLastImages();
    }

    @Override
    public void cameraInOperation(boolean z, boolean z2) {
        Log.d(TAG, "cameraInOperation: " + z);
        if (!z && this.used_front_screen_flash) {
            this.main_activity.setBrightnessForCamera(false);
            this.used_front_screen_flash = false;
        }
        this.drawPreview.cameraInOperation(z);
        this.main_activity.getMainUI().showGUI(!z, z2);
    }

    @Override
    public void turnFrontScreenFlashOn() {
        Log.d(TAG, "turnFrontScreenFlashOn");
        this.used_front_screen_flash = true;
        this.main_activity.setBrightnessForCamera(true);
        this.drawPreview.turnFrontScreenFlashOn();
    }

    @Override
    public void onCaptureStarted() {
        Log.d(TAG, "onCaptureStarted");
        this.n_capture_images = 0;
        this.n_capture_images_raw = 0;
        this.drawPreview.onCaptureStarted();
    }

    public void playSound() {
        MediaPlayer mediaPlayer = new MediaPlayer();
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = new MediaPlayer();
        }
        try {
            AssetFileDescriptor openFd = this.main_activity.getAssets().openFd("capture.ogg");
            mediaPlayer.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
            openFd.close();
            mediaPlayer.prepare();
            ((AudioManager) this.main_activity.getSystemService("audio")).setStreamVolume(3, ((AudioManager) this.main_activity.getSystemService("audio")).getStreamMaxVolume(3), 0);
            mediaPlayer.setAudioStreamType(3);
            mediaPlayer.setLooping(false);
            mediaPlayer.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onPictureCompleted() {
        if (MyDebug.LOG)
            Log.d(TAG, "onPictureCompleted");

        PhotoMode photo_mode = getPhotoMode();
        if (main_activity.getPreview().isVideo()) {
            if (MyDebug.LOG)
                Log.d(TAG, "snapshot mode");
            // must be in photo snapshot while recording video mode, only support standard photo mode
            photo_mode = PhotoMode.Standard;
        }
        if (photo_mode == PhotoMode.NoiseReduction) {
            boolean image_capture_intent = isImageCaptureIntent();
            boolean do_in_background = saveInBackground(image_capture_intent);
            imageSaver.finishImageBatch(do_in_background);
        } else if (photo_mode == MyApplicationInterface.PhotoMode.Panorama && gyroSensor.isRecording()) {
            if (panorama_pic_accepted) {
                if (MyDebug.LOG)
                    Log.d(TAG, "set next panorama point");
                this.setNextPanoramaPoint(false);
            } else {
                if (MyDebug.LOG)
                    Log.d(TAG, "panorama pic wasn't accepted");
                this.setNextPanoramaPoint(true);
            }
        } else if (photo_mode == PhotoMode.FocusBracketing) {
            if (MyDebug.LOG)
                Log.d(TAG, "focus bracketing completed");
            if (getShutterSoundPref()) {
                if (MyDebug.LOG)
                    Log.d(TAG, "play completion sound");
                MediaPlayer player = MediaPlayer.create(getContext(), Settings.System.DEFAULT_NOTIFICATION_URI);
                if (player != null) {
                    player.start();
                }
            }
        }

        // call this, so that if pause-preview-after-taking-photo option is set, we remove the "taking photo" border indicator straight away
        // also even for normal (not pausing) behaviour, good to remove the border asap
        drawPreview.cameraInOperation(false);
    }

    @Override
    public void cameraClosed() {
        Log.d(TAG, "cameraClosed");
        stopPanorama(true);
        this.main_activity.getMainUI().destroyPopup();
        this.drawPreview.clearContinuousFocusMove();
    }


    public void updateThumbnail(Bitmap bitmap, boolean z) {
        Log.d(TAG, "updateThumbnail");
        this.main_activity.updateGalleryIcon(bitmap);
        this.drawPreview.updateThumbnail(bitmap, z, true);
        if (z || !getPausePreviewPref()) {
            return;
        }
        this.drawPreview.showLastImage();
    }

    @Override
    public void timerBeep(long j) {
        Log.d(TAG, "timerBeep()");
        Log.d(TAG, "remaining_time: " + j);
        if (this.sharedPreferences.getBoolean(PreferenceKeys.TimerBeepPreferenceKey, true)) {
            Log.d(TAG, "play beep!");
            this.main_activity.getSoundPoolManager().playSound(j<=1000 ? R.raw.mybeep_hi : R.raw.mybeep);
        }
        if (this.sharedPreferences.getBoolean(PreferenceKeys.TimerSpeakPreferenceKey, false)) {
            Log.d(TAG, "speak countdown!");
            int i = (int) (j / 1000);
            if (i<=60) {
                CameraMainActivity mainActivity = this.main_activity;
                mainActivity.speak("" + i);
            }
        }
    }

    @Override
    public void multitouchZoom(int i) {
        this.main_activity.getMainUI().setSeekbarZoom(i);
    }

    public void switchToCamera(boolean z) {
        Log.d(TAG, "::::" + z);
        int numberOfCameras = this.main_activity.getPreview().getCameraControllerManager().getNumberOfCameras();
        CameraController.Facing facing = z ? CameraController.Facing.FACING_FRONT : CameraController.Facing.FACING_BACK;
        for (int i = 0; i<numberOfCameras; i++) {
            if (this.main_activity.getPreview().getCameraControllerManager().getFacing(i) == facing) {
                Log.d(TAG, "found desired camera: " + i);
                setCameraIdPref(i);
                return;
            }
        }
    }

    public boolean hasSetCameraId() {
        return this.has_set_cameraId;
    }

    @Override
    public void setFocusPref(String str, boolean z) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putString(PreferenceKeys.getFocusPreferenceKey(this.cameraId, z), str);
        edit.apply();
        this.main_activity.setManualFocusSeekBarVisibility(false);
    }

    @Override
    public void clearSceneModePref() {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.remove(PreferenceKeys.SceneModePreferenceKey);
        edit.apply();
    }

    @Override
    public void clearColorEffectPref() {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.remove(PreferenceKeys.ColorEffectPreferenceKey);
        edit.apply();
    }

    @Override
    public void clearWhiteBalancePref() {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.remove(PreferenceKeys.WhiteBalancePreferenceKey);
        edit.apply();
    }

    @Override
    public void clearISOPref() {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.remove(PreferenceKeys.ISOPreferenceKey);
        edit.apply();
    }

    @Override
    public void clearExposureCompensationPref() {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.remove(PreferenceKeys.ExposurePreferenceKey);
        edit.apply();
    }

    @Override
    public void setCameraResolutionPref(int i, int i2) {
        if (getPhotoMode() == PhotoMode.Panorama) {
            return;
        }
        String str = i + " " + i2;
        Log.d(TAG, "save new resolution_value: " + str);
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putString(PreferenceKeys.getResolutionPreferenceKey(this.cameraId), str);
        edit.apply();
    }

    @Override
    public void requestCameraPermission() {
        Log.d(TAG, "requestCameraPermission");
    }

    @Override
    public boolean needsStoragePermission() {
        Log.d(TAG, "needsStoragePermission");
        return !CameraMainActivity.useScopedStorage();
    }

    @Override
    public void requestStoragePermission() {
        Log.d(TAG, "requestStoragePermission");
    }

    @Override
    public void requestRecordAudioPermission() {
        Log.d(TAG, "requestRecordAudioPermission");
    }

    @Override
    public void clearExposureTimePref() {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.remove(PreferenceKeys.ExposureTimePreferenceKey);
        edit.apply();
    }

    @Override
    public void setFocusDistancePref(float f, boolean z) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putFloat(z ? PreferenceKeys.FocusBracketingTargetDistancePreferenceKey : PreferenceKeys.FocusDistancePreferenceKey, f);
        edit.apply();
    }

    private int getStampFontColor() {
        return Color.parseColor(this.sharedPreferences.getString(PreferenceKeys.StampFontColorPreferenceKey, "#ffffff"));
    }

    public void reset(boolean z) {
        Log.d(TAG, "reset");
        if (z) {
            this.aperture = -1.0f;
        }
        this.zoom_factor = 0;
    }

    @Override
    public void onDrawPreview(Canvas canvas) {
        if (this.main_activity.isCameraInBackground()) {
            return;
        }
        this.drawPreview.onDrawPreview(canvas);
    }

//    public int drawTextWithBackground(Canvas canvas, Paint paint, String str, int i, int i2, int i3, int i4) {
//        return drawTextWithBackground(canvas, paint, str, i, i2, i3, i4, Alignment.ALIGNMENT_BOTTOM);
//    }
//
//    public int drawTextWithBackground(Canvas canvas, Paint paint, String str, int i, int i2, int i3, int i4, Alignment alignment) {
//        return drawTextWithBackground(canvas, paint, str, i, i2, i3, i4, alignment, null, Shadow.SHADOW_OUTLINE);
//    }
//
//    public int drawTextWithBackground(Canvas canvas, Paint paint, String str, int i, int i2, int i3, int i4, Alignment alignment, String str2, Shadow shadow) {
//        PrintStream printStream = System.out;
//        printStream.println("DrawTextWithBackgroundPreview       2  " + str);
//        return drawTextWithBackground(canvas, paint, str, i, i2, i3, i4, alignment, null, shadow, null);
//    }
//
//    public int drawTextWithBackground(Canvas canvas, Paint paint, String str, int i, int i2, int i3, int i4, Alignment alignment, String str2, Shadow shadow, Rect rect) {
//        int i5;
//        Rect rect2;
//        Rect rect3;
//        int i6;
//        Rect rect4;
//        System.out.println("DrawTextWithBackgroundPreview        3 " + str);
//        float f = getContext().getResources().getDisplayMetrics().density;
//        paint.setStyle(Paint.Style.FILL);
//        paint.setColor(i2);
//        paint.setAlpha(64);
//        if (rect != null) {
//            this.text_bounds.set(rect);
//        } else {
//            if (str2 != null) {
//                paint.getTextBounds(str2, 0, str2.length(), this.text_bounds);
//                i5 = this.text_bounds.bottom - this.text_bounds.top;
//            } else {
//                i5 = 0;
//            }
//            paint.getTextBounds(str, 0, str.length(), this.text_bounds);
//            if (str2 != null) {
//                Rect rect5 = this.text_bounds;
//                rect5.bottom = rect5.top + i5;
//            }
//        }
//        int i7 = (int) ((f * 2.0f) + 0.5f);
//        if (paint.getTextAlign() == Paint.Align.RIGHT || paint.getTextAlign() == Paint.Align.CENTER) {
//            float measureText = paint.measureText(str);
//            if (paint.getTextAlign() == Paint.Align.CENTER) {
//                measureText /= 2.0f;
//            }
//            this.text_bounds.left = (int) (rect.left - measureText);
//            this.text_bounds.right = (int) (rect.right - measureText);
//        }
//        this.text_bounds.left += i3 - i7;
//        this.text_bounds.right += i3 + i7;
//        int i8 = ((-this.text_bounds.top) + i7) - 1;
//        if (alignment == Alignment.ALIGNMENT_TOP) {
//            int i9 = (this.text_bounds.bottom - this.text_bounds.top) + (i7 * 2);
//            this.text_bounds.top = i4 - 1;
//            Rect rect6 = this.text_bounds;
//            rect6.bottom = rect6.top + i9;
//            i6 = i4 + i8;
//        } else if (alignment == Alignment.ALIGNMENT_CENTRE) {
//            int i10 = (this.text_bounds.bottom - this.text_bounds.top) + (i7 * 2);
//            this.text_bounds.top = (int) (((i4 - 1) + ((rect.top + i4) - i7)) * 0.5d);
//            Rect rect7 = this.text_bounds;
//            rect7.bottom = rect7.top + i10;
//            i6 = i4 + ((int) (i8 * 0.5d));
//        } else {
//            this.text_bounds.top += i4 - i7;
//            this.text_bounds.bottom += i4 + i7;
//            i6 = i4;
//        }
//        if (shadow == Shadow.SHADOW_BACKGROUND) {
//            paint.setColor(i2);
//            paint.setAlpha(64);
//            canvas.drawRect(this.text_bounds, paint);
//            paint.setAlpha(255);
//        }
//        paint.setColor(i);
//        float f2 = i3;
//        float f3 = i6;
//        canvas.drawText(str, f2, f3, paint);
//        if (shadow == Shadow.SHADOW_OUTLINE) {
//            paint.setColor(i2);
//            paint.setStyle(Paint.Style.STROKE);
//            float strokeWidth = paint.getStrokeWidth();
//            paint.setStrokeWidth(1.0f);
//            canvas.drawText(str, f2, f3, paint);
//            paint.setStyle(Paint.Style.FILL);
//            paint.setStrokeWidth(strokeWidth);
//        }
//        return this.text_bounds.bottom - this.text_bounds.top;
//    }
//
//

    public int drawTextWithBackground(Canvas canvas, Paint paint, String str, int i, int i2, int i3, int i4) {
        return drawTextWithBackground(canvas, paint, str, i, i2, i3, i4, Alignment.ALIGNMENT_BOTTOM);
    }

    public int drawTextWithBackground(Canvas canvas, Paint paint, String str, int i, int i2, int i3, int i4, Alignment alignment) {
        return drawTextWithBackground(canvas, paint, str, i, i2, i3, i4, alignment, null, Shadow.SHADOW_OUTLINE);
    }

    public int drawTextWithBackground(Canvas canvas, Paint paint, String str, int i, int i2, int i3, int i4, Alignment alignment, String str2, Shadow shadow) {
        PrintStream printStream = System.out;
        printStream.println("DrawTextWithBackgroundPreview       2  " + str);
        return drawTextWithBackground(canvas, paint, str, i, i2, i3, i4, alignment, null, shadow, null);
    }


//    public int drawTextWithBackground(Canvas canvas, Paint paint, String text, int foreground, int background, int location_x, int location_y, Alignment alignment_y, String ybounds_text, Shadow shadow, Rect bounds) {
//        final float scale = getContext().getResources().getDisplayMetrics().density;
//        paint.setStyle(Paint.Style.FILL);
//        paint.setColor(background);
//        paint.setAlpha(64);
//        if (bounds != null) {
//            text_bounds.set(bounds);
//        } else {
//            int alt_height = 0;
//            if (ybounds_text != null) {
//                paint.getTextBounds(ybounds_text, 0, ybounds_text.length(), text_bounds);
//                alt_height = text_bounds.bottom - text_bounds.top;
//            }
//            paint.getTextBounds(text, 0, text.length(), text_bounds);
//            if (ybounds_text != null) {
//                text_bounds.bottom = text_bounds.top + alt_height;
//            }
//        }
//        final int padding = (int) (2 * scale + 0.5f); // convert dps to pixels
//        if (paint.getTextAlign() == Paint.Align.RIGHT || paint.getTextAlign() == Paint.Align.CENTER) {
//            float width = paint.measureText(text); // n.b., need to use measureText rather than getTextBounds here
//			/*if( MyDebug.LOG )
//				Log.d(TAG, "width: " + width);*/
//            if (paint.getTextAlign() == Paint.Align.CENTER)
//                width /= 2.0f;
//            text_bounds.left -= width;
//            text_bounds.right -= width;
//        }
//		/*if( MyDebug.LOG )
//			Log.d(TAG, "text_bounds left-right: " + text_bounds.left + " , " + text_bounds.right);*/
//        text_bounds.left += location_x - padding;
//        text_bounds.right += location_x + padding;
//        // unclear why we need the offset of -1, but need this to align properly on Galaxy Nexus at least
//        int top_y_diff = -text_bounds.top + padding - 1;
//        if (alignment_y == Alignment.ALIGNMENT_TOP) {
//            int height = text_bounds.bottom - text_bounds.top + 2 * padding;
//            text_bounds.top = location_y - 1;
//            text_bounds.bottom = text_bounds.top + height;
//            location_y += top_y_diff;
//        } else if (alignment_y == Alignment.ALIGNMENT_CENTRE) {
//            int height = text_bounds.bottom - text_bounds.top + 2 * padding;
//            //int y_diff = - text_bounds.top + padding - 1;
//            text_bounds.top = (int) (0.5 * ((location_y - 1) + (text_bounds.top + location_y - padding))); // average of ALIGNMENT_TOP and ALIGNMENT_BOTTOM
//            text_bounds.bottom = text_bounds.top + height;
//            location_y += (int) (0.5 * top_y_diff); // average of ALIGNMENT_TOP and ALIGNMENT_BOTTOM
//        } else {
//            text_bounds.top += location_y - padding;
//            text_bounds.bottom += location_y + padding;
//        }
//        paint.setColor(foreground);
//        canvas.drawText(text, location_x, location_y, paint);
//        if (shadow == Shadow.SHADOW_NONE) {
//            paint.setColor(background);
//            paint.setStyle(Paint.Style.STROKE);
//            paint.setStrokeWidth(1);
//            canvas.drawText(text, location_x, location_y, paint);
//            paint.setStyle(Paint.Style.FILL); // set back to default
//        }
//        return text_bounds.bottom - text_bounds.top;
//    }

    public int drawTextWithBackground(Canvas canvas0, Paint paint0, String s, int v, int v1, int v2, int v3, Alignment myApplicationInterface$Alignment0, String s1, Shadow myApplicationInterface$Shadow0, Rect rect0) {
        int v8;
        int v4;
        System.out.println("DrawTextWithBackgroundPreview        3 " + s);
        float f = this.getContext().getResources().getDisplayMetrics().density;
        paint0.setStyle(Paint.Style.FILL);
        paint0.setColor(v1);
        paint0.setAlpha(0x40);
        if (rect0 == null) {
            if (s1 == null) {
                v4 = 0;
            } else {
                paint0.getTextBounds(s1, 0, s1.length(), this.text_bounds);
                v4 = this.text_bounds.bottom - this.text_bounds.top;
            }

            paint0.getTextBounds(s, 0, s.length(), this.text_bounds);
            if (s1 != null) {
                this.text_bounds.bottom = this.text_bounds.top + v4;
            }
        } else {
            this.text_bounds.set(rect0);
        }

        int v5 = (int) (f * 2.0f + 0.5f);
        if (paint0.getTextAlign() == Paint.Align.RIGHT || paint0.getTextAlign() == Paint.Align.CENTER) {
            float f1 = paint0.measureText(s);
            if (paint0.getTextAlign() == Paint.Align.CENTER) {
                f1 /= 2.0f;
            }

            this.text_bounds.left = (int) (((float) this.text_bounds.left) - f1);
            this.text_bounds.right = (int) (((float) this.text_bounds.right) - f1);
        }

        this.text_bounds.left += v2 - v5;
        this.text_bounds.right += v2 + v5;
        int v6 = -this.text_bounds.top + v5 - 1;
        if (myApplicationInterface$Alignment0 == Alignment.ALIGNMENT_TOP) {
            int v7 = this.text_bounds.bottom - this.text_bounds.top + v5 * 2;
            this.text_bounds.top = v3 - 1;
            this.text_bounds.bottom = this.text_bounds.top + v7;
            v8 = v3 + v6;
        } else if (myApplicationInterface$Alignment0 == Alignment.ALIGNMENT_CENTRE) {
            int v9 = this.text_bounds.bottom - this.text_bounds.top + v5 * 2;
            this.text_bounds.top = (int) (((double) (v3 - 1 + (this.text_bounds.top + v3 - v5))) * 0.5);
            this.text_bounds.bottom = this.text_bounds.top + v9;
            v8 = v3 + ((int) (((double) v6) * 0.5));
        } else {
            this.text_bounds.top += v3 - v5;
            this.text_bounds.bottom += v3 + v5;
            v8 = v3;
        }

        if (myApplicationInterface$Shadow0 == Shadow.SHADOW_BACKGROUND) {
            paint0.setColor(v1);
            paint0.setAlpha(0x40);
            canvas0.drawRect(this.text_bounds, paint0);
            paint0.setAlpha(0xFF);
        }

        paint0.setColor(v);
        float f2 = (float) v2;
        float f3 = (float) v8;
        canvas0.drawText(s, f2, f3, paint0);
        if (myApplicationInterface$Shadow0 == Shadow.SHADOW_OUTLINE) {
            paint0.setColor(v1);
            paint0.setStyle(Paint.Style.STROKE);
            float f4 = paint0.getStrokeWidth();
            paint0.setStrokeWidth(1.0f);
            canvas0.drawText(s, f2, f3, paint0);
            paint0.setStyle(Paint.Style.FILL);
            paint0.setStrokeWidth(f4);
        }

        return this.text_bounds.bottom - this.text_bounds.top;
    }

    private boolean saveInBackground(boolean z) {
        return (z || getPausePreviewPref()) ? false : true;
    }

    public boolean isImageCaptureIntent() {
        String action = this.main_activity.getIntent().getAction();
        if ("android.media.action.IMAGE_CAPTURE".equals(action) || "android.media.action.IMAGE_CAPTURE_SECURE".equals(action)) {
            Log.d(TAG, "from image capture intent");
            return true;
        }
        return false;
    }

    private boolean forceSuffix(PhotoMode photoMode) {
        return photoMode == PhotoMode.FocusBracketing || photoMode == PhotoMode.FastBurst || (this.main_activity.getPreview().getCameraController() != null && this.main_activity.getPreview().getCameraController().isCapturingBurst());
    }

    private boolean saveImage(boolean save_expo, List<byte[]> images, Date current_date) {
        if (MyDebug.LOG)
            Log.d(TAG, "saveImage");

        System.gc();

        boolean image_capture_intent = isImageCaptureIntent();
        Uri image_capture_intent_uri = null;
        if (image_capture_intent) {
            if (MyDebug.LOG)
                Log.d(TAG, "from image capture intent");
            Bundle myExtras = main_activity.getIntent().getExtras();
            if (myExtras != null) {
                image_capture_intent_uri = myExtras.getParcelable(MediaStore.EXTRA_OUTPUT);
                if (MyDebug.LOG)
                    Log.d(TAG, "save to: " + image_capture_intent_uri);
            }
        }

        boolean using_camera2 = main_activity.getPreview().usingCamera2API();
        boolean using_camera_extensions = isCameraExtensionPref();
        ImageSaver.Request.ImageFormat image_format = getImageFormatPref();
        boolean store_ypr = sharedPreferences.getBoolean(PreferenceKeys.AddYPRToComments, false) &&
                main_activity.getPreview().hasLevelAngle() &&
                main_activity.getPreview().hasPitchAngle() &&
                main_activity.getPreview().hasGeoDirection();
        if (MyDebug.LOG) {
            Log.d(TAG, "store_ypr: " + store_ypr);
            Log.d(TAG, "has level angle: " + main_activity.getPreview().hasLevelAngle());
            Log.d(TAG, "has pitch angle: " + main_activity.getPreview().hasPitchAngle());
            Log.d(TAG, "has geo direction: " + main_activity.getPreview().hasGeoDirection());
        }
        int image_quality = getSaveImageQualityPref();
        if (MyDebug.LOG)
            Log.d(TAG, "image_quality: " + image_quality);
        boolean do_auto_stabilise = getAutoStabilisePref() && main_activity.getPreview().hasLevelAngleStable();
        double level_angle = (main_activity.getPreview().hasLevelAngle()) ? main_activity.getPreview().getLevelAngle() : 0.0;
        double pitch_angle = (main_activity.getPreview().hasPitchAngle()) ? main_activity.getPreview().getPitchAngle() : 0.0;
        if (do_auto_stabilise && main_activity.test_have_angle)
            level_angle = main_activity.test_angle;
        if (do_auto_stabilise && main_activity.test_low_memory)
            level_angle = 45.0;
        // I have received crashes where camera_controller was null - could perhaps happen if this thread was running just as the camera is closing?
        boolean is_front_facing = main_activity.getPreview().getCameraController() != null && (main_activity.getPreview().getCameraController().getFacing() == CameraController.Facing.FACING_FRONT);
        boolean mirror = is_front_facing && sharedPreferences.getString(PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_no").equals("preference_front_camera_mirror_photo");
        String preference_stamp = this.getStampPref();
        String preference_textstamp = this.getTextStampPref();
        int font_size = getTextStampFontSizePref();
        int color = getStampFontColor();
        String pref_style = sharedPreferences.getString(PreferenceKeys.StampStyleKey, "preference_stamp_style_shadowed");
        String preference_stamp_dateformat = this.getStampDateFormatPref();
        String preference_stamp_timeformat = this.getStampTimeFormatPref();
        String preference_stamp_gpsformat = this.getStampGPSFormatPref();
        //String preference_stamp_geo_address = this.getStampGeoAddressPref();
        String preference_units_distance = this.getUnitsDistancePref();
        boolean panorama_crop = sharedPreferences.getString(PreferenceKeys.PanoramaCropPreferenceKey, "preference_panorama_crop_on").equals("preference_panorama_crop_on");
        ImageSaver.Request.RemoveDeviceExif remove_device_exif = getRemoveDeviceExifPref();
        boolean store_location = getGeotaggingPref() && getLocation() != null;
        Location location = store_location ? getLocation() : null;
        boolean store_geo_direction = main_activity.getPreview().hasGeoDirection() && getGeodirectionPref();
        double geo_direction = main_activity.getPreview().hasGeoDirection() ? main_activity.getPreview().getGeoDirection() : 0.0;
        String custom_tag_artist = sharedPreferences.getString(PreferenceKeys.ExifArtistPreferenceKey, "");
        String custom_tag_copyright = sharedPreferences.getString(PreferenceKeys.ExifCopyrightPreferenceKey, "");

        int iso = 800; // default value if we can't get ISO
        long exposure_time = 1000000000L / 30; // default value if we can't get shutter speed
        float zoom_factor = 1.0f;
        if (main_activity.getPreview().getCameraController() != null) {
            if (main_activity.getPreview().getCameraController().captureResultHasIso()) {
                iso = main_activity.getPreview().getCameraController().captureResultIso();
                if (MyDebug.LOG)
                    Log.d(TAG, "iso: " + iso);
            }
            if (main_activity.getPreview().getCameraController().captureResultHasExposureTime()) {
                exposure_time = main_activity.getPreview().getCameraController().captureResultExposureTime();
                if (MyDebug.LOG)
                    Log.d(TAG, "exposure_time: " + exposure_time);
            }

            zoom_factor = main_activity.getPreview().getZoomRatio();
        }

        boolean has_thumbnail_animation = getThumbnailAnimationPref();

        boolean do_in_background = saveInBackground(image_capture_intent);

        String ghost_image_pref = sharedPreferences.getString(PreferenceKeys.GhostImagePreferenceKey, "preference_ghost_image_off");

        int sample_factor = 1;
        if (!this.getPausePreviewPref() && !ghost_image_pref.equals("preference_ghost_image_last")) {
            // if pausing the preview, we use the thumbnail also for the preview, so don't downsample
            // similarly for ghosting last image
            // otherwise, we can downsample by 4 to increase performance, without noticeable loss in visual quality (even for the thumbnail animation)
            sample_factor *= 4;
            if (!has_thumbnail_animation) {
                // can use even lower resolution if we don't have the thumbnail animation
                sample_factor *= 4;
            }
        }
        if (MyDebug.LOG)
            Log.d(TAG, "sample_factor: " + sample_factor);

        boolean success;
        PhotoMode photo_mode = getPhotoMode();
        if (main_activity.getPreview().isVideo()) {
            if (MyDebug.LOG)
                Log.d(TAG, "snapshot mode");
            // must be in photo snapshot while recording video mode, only support standard photo mode
            photo_mode = PhotoMode.Standard;
        }

        if (!main_activity.is_test && photo_mode == PhotoMode.Panorama && gyroSensor.isRecording() && gyroSensor.hasTarget() && !gyroSensor.isTargetAchieved()) {
            if (MyDebug.LOG)
                Log.d(TAG, "ignore panorama image as target no longer achieved!");
            // n.b., gyroSensor.hasTarget() will be false if this is the first picture in the panorama series
            panorama_pic_accepted = false;
            success = true; // still treat as success
        } else if (photo_mode == PhotoMode.NoiseReduction || photo_mode == PhotoMode.Panorama) {
            boolean first_image;
            if (photo_mode == PhotoMode.Panorama) {
                panorama_pic_accepted = true;
                first_image = n_panorama_pics == 0;
            } else
                first_image = n_capture_images == 1;
            if (first_image) {
                ImageSaver.Request.SaveBase save_base = ImageSaver.Request.SaveBase.SAVEBASE_NONE;
                if (photo_mode == PhotoMode.NoiseReduction) {
                    String save_base_preference = sharedPreferences.getString(PreferenceKeys.NRSaveExpoPreferenceKey, "preference_nr_save_no");
                    switch (save_base_preference) {
                        case "preference_nr_save_single":
                            save_base = ImageSaver.Request.SaveBase.SAVEBASE_FIRST;
                            break;
                        case "preference_nr_save_all":
                            save_base = ImageSaver.Request.SaveBase.SAVEBASE_ALL;
                            break;
                    }
                } else if (photo_mode == PhotoMode.Panorama) {
                    String save_base_preference = sharedPreferences.getString(PreferenceKeys.PanoramaSaveExpoPreferenceKey, "preference_panorama_save_no");
                    switch (save_base_preference) {
                        case "preference_panorama_save_all":
                            save_base = ImageSaver.Request.SaveBase.SAVEBASE_ALL;
                            break;
                        case "preference_panorama_save_all_plus_debug":
                            save_base = ImageSaver.Request.SaveBase.SAVEBASE_ALL_PLUS_DEBUG;
                            break;
                    }
                }

                imageSaver.startImageBatch(true,
                        photo_mode == PhotoMode.NoiseReduction ? ImageSaver.Request.ProcessType.AVERAGE : ImageSaver.Request.ProcessType.PANORAMA,
                        save_base,
                        image_capture_intent, image_capture_intent_uri,
                        using_camera2, using_camera_extensions,
                        image_format, image_quality,
                        do_auto_stabilise, level_angle, photo_mode == PhotoMode.Panorama,
                        is_front_facing,
                        mirror,
                        current_date,
                        iso,
                        exposure_time,
                        zoom_factor,
                        preference_stamp, preference_textstamp, font_size, color, pref_style, preference_stamp_dateformat, preference_stamp_timeformat, preference_stamp_gpsformat,
                        //preference_stamp_geo_address,
                        preference_units_distance,
                        panorama_crop,
                        remove_device_exif,
                        store_location, location, store_geo_direction, geo_direction,
                        pitch_angle, store_ypr,
                        custom_tag_artist, custom_tag_copyright,
                        sample_factor);

                if (photo_mode == PhotoMode.Panorama) {
                    imageSaver.getImageBatchRequest().camera_view_angle_x = main_activity.getPreview().getViewAngleX(false);
                    imageSaver.getImageBatchRequest().camera_view_angle_y = main_activity.getPreview().getViewAngleY(false);
                }
            }

            float[] gyro_rotation_matrix = null;
            if (photo_mode == PhotoMode.Panorama) {
                gyro_rotation_matrix = new float[9];
                this.gyroSensor.getRotationMatrix(gyro_rotation_matrix);
            }

            imageSaver.addImageBatch(images.get(0), gyro_rotation_matrix);
            success = true;
        } else {
            ImageSaver.Request.ProcessType processType;
            if (photo_mode == PhotoMode.DRO || photo_mode == PhotoMode.HDR)
                processType = ImageSaver.Request.ProcessType.HDR;
            else if (photo_mode == PhotoMode.X_Night)
                processType = ImageSaver.Request.ProcessType.X_NIGHT;
            else
                processType = ImageSaver.Request.ProcessType.NORMAL;
            boolean force_suffix = forceSuffix(photo_mode);

            HDRProcessor.TonemappingAlgorithm preference_hdr_tonemapping_algorithm = HDRProcessor.default_tonemapping_algorithm_c;
            {
                String tonemapping_algorithm_pref = sharedPreferences.getString(PreferenceKeys.HDRSaveExpoPreferenceKey, "preference_hdr_tonemapping_default");
                switch (tonemapping_algorithm_pref) {
                    case "preference_hdr_tonemapping_clamp":
                        preference_hdr_tonemapping_algorithm = HDRProcessor.TonemappingAlgorithm.TONEMAPALGORITHM_CLAMP;
                        break;
                    case "preference_hdr_tonemapping_exponential":
                        preference_hdr_tonemapping_algorithm = HDRProcessor.TonemappingAlgorithm.TONEMAPALGORITHM_EXPONENTIAL;
                        break;
                    case "preference_hdr_tonemapping_default": // reinhard
                        preference_hdr_tonemapping_algorithm = HDRProcessor.default_tonemapping_algorithm_c;
                        break;
                    case "preference_hdr_tonemapping_aces":
                        preference_hdr_tonemapping_algorithm = HDRProcessor.TonemappingAlgorithm.TONEMAPALGORITHM_ACES;
                        break;
                    default:
                        Log.e(TAG, "unhandled case for tonemapping: " + tonemapping_algorithm_pref);
                        break;
                }
            }
            String preference_hdr_contrast_enhancement = sharedPreferences.getString(PreferenceKeys.HDRContrastEnhancementPreferenceKey, "preference_hdr_contrast_enhancement_smart");

            success = imageSaver.saveImageJpeg(do_in_background, processType,
                    force_suffix,
                    // N.B., n_capture_images will be 1 for first image, not 0, so subtract 1 so we start off from _0.
                    // (It wouldn't be a huge problem if we did start from _1, but it would be inconsistent with the naming
                    // of images where images.size() > 1 (e.g., expo bracketing mode) where we also start from _0.)
                    force_suffix ? (n_capture_images - 1) : 0,
                    save_expo, images,
                    image_capture_intent, image_capture_intent_uri,
                    using_camera2, using_camera_extensions,
                    image_format, image_quality,
                    do_auto_stabilise, level_angle,
                    is_front_facing,
                    mirror,
                    current_date,
                    preference_hdr_tonemapping_algorithm,
                    preference_hdr_contrast_enhancement,
                    iso,
                    exposure_time,
                    zoom_factor,
                    preference_stamp, preference_textstamp, font_size, color, pref_style, preference_stamp_dateformat, preference_stamp_timeformat, preference_stamp_gpsformat,
                    //preference_stamp_geo_address,
                    preference_units_distance,
                    false, // panorama doesn't use this codepath
                    remove_device_exif,
                    store_location, location, store_geo_direction, geo_direction,
                    pitch_angle, store_ypr,
                    custom_tag_artist, custom_tag_copyright,
                    sample_factor);
        }

        if (MyDebug.LOG)
            Log.d(TAG, "saveImage complete, success: " + success);

        return success;
    }

    @Override // com.live.gpsmap.camera.Camera.preview.ApplicationInterface
    public boolean onPictureTaken(byte[] bArr, Date date) {
        Log.d(TAG, "onPictureTaken");
        this.n_capture_images++;
        Log.d(TAG, "n_capture_images is now " + this.n_capture_images);
        ArrayList arrayList = new ArrayList();
        arrayList.add(bArr);
        boolean saveImage = saveImage(false, arrayList, date);
        Log.d(TAG, "onPictureTaken complete, success: " + saveImage);
        return saveImage;
    }

    private ImageSaver.Request.RemoveDeviceExif getRemoveDeviceExifPref() {
        switch (sharedPreferences.getString(PreferenceKeys.ExifArtistPreferenceKey, "preference_remove_device_exif_off")) {
            case "preference_remove_device_exif_on":
                return ImageSaver.Request.RemoveDeviceExif.ON;
            case "preference_remove_device_exif_keep_datetime":
                return ImageSaver.Request.RemoveDeviceExif.KEEP_DATETIME;
            default:
                return ImageSaver.Request.RemoveDeviceExif.OFF;
        }
    }

    @Override
    public boolean onBurstPictureTaken(List<byte[]> list, Date date) {
        Log.d(TAG, "onBurstPictureTaken: received " + list.size() + " images");
        PhotoMode photoMode = getPhotoMode();
        if (this.main_activity.getPreview().isVideo()) {
            Log.d(TAG, "snapshot mode");
            photoMode = PhotoMode.Standard;
        }
        if (photoMode == PhotoMode.HDR) {
            Log.d(TAG, "HDR mode");
            boolean z = this.sharedPreferences.getBoolean(PreferenceKeys.HDRSaveExpoPreferenceKey, false);
            Log.d(TAG, "save_expo: " + z);
            return saveImage(z, list, date);
        }
        Log.d(TAG, "exposure/focus bracketing mode mode");
        if (photoMode != PhotoMode.ExpoBracketing && photoMode != PhotoMode.FocusBracketing) {
            Log.e(TAG, "onBurstPictureTaken called with unexpected photo mode?!: " + photoMode);
        }
        return saveImage(true, list, date);
    }

    @Override
    public boolean onRawPictureTaken(RawImage rawImage, Date date) {
        Log.d(TAG, "onRawPictureTaken");
        System.gc();
        this.n_capture_images_raw++;
        Log.d(TAG, "n_capture_images_raw is now " + this.n_capture_images_raw);
        boolean saveInBackground = saveInBackground(false);
        PhotoMode photoMode = getPhotoMode();
        if (this.main_activity.getPreview().isVideo()) {
            Log.d(TAG, "snapshot mode");
            photoMode = PhotoMode.Standard;
        }
        boolean forceSuffix = forceSuffix(photoMode);
        boolean saveImageRaw = this.imageSaver.saveImageRaw(saveInBackground, forceSuffix, forceSuffix ? this.n_capture_images_raw - 1 : 0, rawImage, date);
        Log.d(TAG, "onRawPictureTaken complete");
        return saveImageRaw;
    }

    @Override
    public boolean onRawBurstPictureTaken(List<RawImage> list, Date date) {
        Log.d(TAG, "onRawBurstPictureTaken");
        System.gc();
        boolean saveInBackground = saveInBackground(false);
        boolean z = true;
        for (int i = 0; i<list.size() && z; i++) {
            z = this.imageSaver.saveImageRaw(saveInBackground, true, i, list.get(i), date);
        }
        Log.d(TAG, "onRawBurstPictureTaken complete");
        return z;
    }


    public void addLastImage(File file, boolean z) {
        Log.d(TAG, "addLastImage: " + file);
        Log.d(TAG, "share?: " + z);
        this.last_images_saf = false;
        this.last_images.add(new LastImage(file.getAbsolutePath(), z));
    }


    public void addLastImageSAF(Uri uri, boolean z) {
        Log.d(TAG, "addLastImageSAF: " + uri);
        Log.d(TAG, "share?: " + z);
        this.last_images_saf = true;
        this.last_images.add(new LastImage(uri, z));
    }

    public void clearLastImages() {
        Log.d(TAG, "clearLastImages");
        this.last_images_saf = false;
        this.last_images.clear();
        this.drawPreview.clearLastImage();
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x0070  */
    /* JADX WARN: Removed duplicated region for block: B:26:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    void shareLastImage() {
        if (MyDebug.LOG)
            Log.d(TAG, "shareLastImage");
        Preview preview = main_activity.getPreview();
        if (preview.isPreviewPaused()) {
            LastImage share_image = null;
            for (int i = 0; i<last_images.size() && share_image == null; i++) {
                LastImage last_image = last_images.get(i);
                if (last_image.share) {
                    share_image = last_image;
                }
            }
            boolean done = true;
            if (share_image != null) {
                Uri last_image_uri = share_image.uri;
                if (MyDebug.LOG)
                    Log.d(TAG, "Share: " + last_image_uri);
                if (last_image_uri == null) {
                    // could happen with Android 7+ with non-SAF if the image hasn't been scanned yet,
                    // so we don't know the uri yet
                    Log.e(TAG, "can't share last image as don't yet have uri");
                    done = false;
                } else {
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("image/jpeg");
                    intent.putExtra(Intent.EXTRA_STREAM, last_image_uri);
                    main_activity.startActivity(Intent.createChooser(intent, "Photo"));
                }
            }
            if (done) {
                clearLastImages();
                preview.startCameraPreview();
            }
        }
    }

    private void trashImage(LastImagesType lastImagesType, Uri uri, String str, boolean z) {
        Log.d(TAG, "trashImage");
        Preview preview = this.main_activity.getPreview();
        if (lastImagesType == LastImagesType.SAF && uri != null) {
            Log.d(TAG, "Delete SAF: " + uri);
            File fileFromDocumentUriSAF = this.storageUtils.getFileFromDocumentUriSAF(uri, false);
            try {
                if (!DocumentsContract.deleteDocument(this.main_activity.getContentResolver(), uri)) {
                    Log.e(TAG, "failed to delete " + uri);
                    return;
                }
                Log.d(TAG, "successfully deleted " + uri);
                if (z) {
                    preview.showToast((ToastBoxer) null, R.string.photo_deleted);
                }
                if (fileFromDocumentUriSAF != null) {
                    this.storageUtils.broadcastFile(fileFromDocumentUriSAF, false, false, true);
                }
            } catch (FileNotFoundException e) {
                Log.e(TAG, "exception when deleting " + uri);
                e.printStackTrace();
            }
        } else if (lastImagesType == LastImagesType.MEDIASTORE && uri != null) {
            Log.d(TAG, "Delete MediaStore: " + uri);
            this.main_activity.getContentResolver().delete(uri, null, null);
        } else if (str != null) {
            Log.d(TAG, "Delete: " + str);
            File file = new File(str);
            if (!file.delete()) {
                Log.e(TAG, "failed to delete " + str);
                return;
            }
            Log.d(TAG, "successfully deleted " + str);
            if (z) {
                preview.showToast(this.photo_delete_toast, R.string.photo_deleted);
            }
            this.storageUtils.broadcastFile(file, false, false, true);
        }
    }


    public void trashLastImage() {
        Log.d(TAG, "trashLastImage");
        Preview preview = this.main_activity.getPreview();
        if (preview.isPreviewPaused()) {
            for (int i = 0; i<this.last_images.size(); i++) {
                LastImage lastImage = this.last_images.get(i);
                trashImage(this.last_images_type, lastImage.uri, lastImage.name, true);
            }
            clearLastImages();
            this.drawPreview.clearGhostImage();
            preview.startCameraPreview();
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                MyApplicationInterface.this.main_activity.updateGalleryIcon();
            }
        }, 500L);
    }


    public void scannedFile(File file, Uri uri) {
        Log.d(TAG, "scannedFile");
        Log.d(TAG, "file: " + file);
        Log.d(TAG, "uri: " + uri);
        for (int i = 0; i<this.last_images.size(); i++) {
            LastImage lastImage = this.last_images.get(i);
            Log.d(TAG, "compare to last_image: " + lastImage.name);
            if (lastImage.uri == null && lastImage.name != null && lastImage.name.equals(file.getAbsolutePath())) {
                Log.d(TAG, "updated last_image : " + i);
                lastImage.uri = uri;
            }
        }
    }

    public boolean hasThumbnailAnimation() {
        return this.drawPreview.hasThumbnailAnimation();
    }

    public HDRProcessor getHDRProcessor() {
        return this.imageSaver.getHDRProcessor();
    }

    public PanoramaProcessor getPanoramaProcessor() {
        return this.imageSaver.getPanoramaProcessor();
    }


    private void storeImage(final ImageSaver.Request request, Bitmap bitmap) {
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).toString() + "/Camera");
        if (!file.exists()) {
            file.mkdirs();
        }
        String format = new SimpleDateFormat("ddMMyyyy_HHmmss").format(new Date());
        File file2 = new File(file, "GMC" + format + ".jpg");
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        if (bitmap != null) {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
        }
        byteArrayOutputStream.toByteArray();
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file2, false);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        if (Build.VERSION.SDK_INT>=8) {
            MediaScannerConnection.scanFile(this.main_activity, new String[]{file2.toString()}, null, new MediaScannerConnection.OnScanCompletedListener() { // from class: com.live.gpsmap.camera.Camera.MyApplicationInterface.4
                @Override
                public void onScanCompleted(String str, Uri uri) {
                    try {
                        ParcelFileDescriptor openFileDescriptor = MyApplicationInterface.this.main_activity.getContentResolver().openFileDescriptor(uri, "rw");
                        if (openFileDescriptor != null) {
                            MyApplicationInterface.this.setExifFrompfd(request.jpeg_images.get(0), openFileDescriptor.getFileDescriptor());
                        } else {
                            MyApplicationInterface.this.setExifFromData(request.jpeg_images.get(0), new File(str));
                        }
                    } catch (FileNotFoundException e3) {
                        e3.printStackTrace();
                    } catch (IOException e4) {
                        e4.printStackTrace();
                    }
                }
            });
        }
        bitmap.recycle();
    }

    public void setExifFromData(byte[] bArr, File file) throws IOException {
        ByteArrayInputStream byteArrayInputStream = null;
        ByteArrayInputStream byteArrayInputStream2 = null;
        try {
            byteArrayInputStream = new ByteArrayInputStream(bArr);
            setExif(new ExifInterface(byteArrayInputStream), new ExifInterface(file.getAbsolutePath()));
            byteArrayInputStream.close();
        } catch (Throwable th2) {
            byteArrayInputStream2 = byteArrayInputStream;
            if (byteArrayInputStream2 != null) {
                byteArrayInputStream2.close();
            }
            th2.printStackTrace();
        }
    }

    public void setExifFrompfd(byte[] bArr, FileDescriptor fileDescriptor) throws IOException {
        ByteArrayInputStream byteArrayInputStream = null;
        ByteArrayInputStream byteArrayInputStream2;
        try {
            byteArrayInputStream = new ByteArrayInputStream(bArr);
            setExif(new ExifInterface(byteArrayInputStream), new ExifInterface(fileDescriptor));
            byteArrayInputStream.close();
        } catch (Throwable th2) {
            byteArrayInputStream2 = byteArrayInputStream;
            if (byteArrayInputStream2 != null) {
                byteArrayInputStream2.close();
            }
            th2.printStackTrace();
        }
    }

    private void setExif(ExifInterface exifInterface, ExifInterface exifInterface2) throws IOException {
        MyApplicationInterface myApplicationInterface;
        SP sp = new SP(this.main_activity);
        String string = sp.getString(this.main_activity, SP.LATITUDE, "");
        String string2 = sp.getString(this.main_activity, SP.LONGITUDE, "");
        Log.d(TAG, "setExif");
        Log.d(TAG, "read back EXIF data");
        String attribute = exifInterface.getAttribute(ExifInterface.TAG_F_NUMBER);
        String attribute2 = exifInterface.getAttribute(ExifInterface.TAG_DATETIME);
        String attribute3 = exifInterface.getAttribute(ExifInterface.TAG_EXPOSURE_TIME);
        String attribute4 = exifInterface.getAttribute(ExifInterface.TAG_FLASH);
        String attribute5 = exifInterface.getAttribute(ExifInterface.TAG_FOCAL_LENGTH);
        String attribute6 = exifInterface.getAttribute(ExifInterface.TAG_GPS_ALTITUDE);
        String attribute7 = exifInterface.getAttribute(ExifInterface.TAG_GPS_ALTITUDE_REF);
        String attribute8 = exifInterface.getAttribute(ExifInterface.TAG_GPS_DATESTAMP);
        String attribute9 = exifInterface.getAttribute(ExifInterface.TAG_GPS_LATITUDE);
        String attribute10 = exifInterface.getAttribute(ExifInterface.TAG_GPS_LATITUDE_REF);
        String attribute11 = exifInterface.getAttribute(ExifInterface.TAG_GPS_LONGITUDE);
        String attribute12 = exifInterface.getAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF);
        String attribute13 = exifInterface.getAttribute(ExifInterface.TAG_GPS_PROCESSING_METHOD);
        String attribute14 = exifInterface.getAttribute(ExifInterface.TAG_GPS_TIMESTAMP);
        String attribute15 = exifInterface.getAttribute(ExifInterface.TAG_ISO_SPEED_RATINGS);
        String attribute16 = exifInterface.getAttribute(ExifInterface.TAG_MAKE);
        String attribute17 = exifInterface.getAttribute(ExifInterface.TAG_MODEL);
        String attribute18 = exifInterface.getAttribute(ExifInterface.TAG_WHITE_BALANCE);
        String attribute19 = exifInterface.getAttribute("DateTimeDigitized");
        String attribute20 = exifInterface.getAttribute(ExifInterface.TAG_SUBSEC_TIME);
        String attribute21 = exifInterface.getAttribute(ExifInterface.TAG_SUBSEC_TIME_DIGITIZED);
        String attribute22 = exifInterface.getAttribute(ExifInterface.TAG_SUBSEC_TIME_ORIGINAL);
        String attribute23 = exifInterface.getAttribute(ExifInterface.TAG_APERTURE_VALUE);
        String attribute24 = exifInterface.getAttribute(ExifInterface.TAG_BRIGHTNESS_VALUE);
        String attribute25 = exifInterface.getAttribute(ExifInterface.TAG_CFA_PATTERN);
        String attribute26 = exifInterface.getAttribute(ExifInterface.TAG_COLOR_SPACE);
        String attribute27 = exifInterface.getAttribute(ExifInterface.TAG_COMPONENTS_CONFIGURATION);
        String attribute28 = exifInterface.getAttribute(ExifInterface.TAG_COMPRESSED_BITS_PER_PIXEL);
        String attribute29 = exifInterface.getAttribute(ExifInterface.TAG_COMPRESSION);
        String attribute30 = exifInterface.getAttribute(ExifInterface.TAG_CONTRAST);
        String attribute31 = exifInterface.getAttribute("DateTimeOriginal");
        String attribute32 = exifInterface.getAttribute(ExifInterface.TAG_DEVICE_SETTING_DESCRIPTION);
        String attribute33 = exifInterface.getAttribute(ExifInterface.TAG_DIGITAL_ZOOM_RATIO);
        String attribute34 = exifInterface.getAttribute(ExifInterface.TAG_EXPOSURE_BIAS_VALUE);
        String attribute35 = exifInterface.getAttribute(ExifInterface.TAG_EXPOSURE_INDEX);
        String attribute36 = exifInterface.getAttribute(ExifInterface.TAG_EXPOSURE_MODE);
        String attribute37 = exifInterface.getAttribute(ExifInterface.TAG_EXPOSURE_PROGRAM);
        String attribute38 = exifInterface.getAttribute(ExifInterface.TAG_FLASH_ENERGY);
        String attribute39 = exifInterface.getAttribute(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM);
        String attribute40 = exifInterface.getAttribute(ExifInterface.TAG_FOCAL_PLANE_RESOLUTION_UNIT);
        String attribute41 = exifInterface.getAttribute(ExifInterface.TAG_FOCAL_PLANE_X_RESOLUTION);
        String attribute42 = exifInterface.getAttribute(ExifInterface.TAG_FOCAL_PLANE_Y_RESOLUTION);
        String attribute43 = exifInterface.getAttribute(ExifInterface.TAG_GAIN_CONTROL);
        String attribute44 = exifInterface.getAttribute(ExifInterface.TAG_GPS_AREA_INFORMATION);
        String attribute45 = exifInterface.getAttribute(ExifInterface.TAG_GPS_DIFFERENTIAL);
        String attribute46 = exifInterface.getAttribute(ExifInterface.TAG_GPS_DOP);
        String attribute47 = exifInterface.getAttribute(ExifInterface.TAG_GPS_MEASURE_MODE);
        String attribute48 = exifInterface.getAttribute(ExifInterface.TAG_IMAGE_DESCRIPTION);
        String attribute49 = exifInterface.getAttribute(ExifInterface.TAG_LIGHT_SOURCE);
        String attribute50 = exifInterface.getAttribute(ExifInterface.TAG_MAKER_NOTE);
        String attribute51 = exifInterface.getAttribute(ExifInterface.TAG_MAX_APERTURE_VALUE);
        String attribute52 = exifInterface.getAttribute(ExifInterface.TAG_METERING_MODE);
        String attribute53 = exifInterface.getAttribute(ExifInterface.TAG_OECF);
        String attribute54 = exifInterface.getAttribute(ExifInterface.TAG_PHOTOMETRIC_INTERPRETATION);
        String attribute55 = exifInterface.getAttribute(ExifInterface.TAG_SATURATION);
        String attribute56 = exifInterface.getAttribute(ExifInterface.TAG_SCENE_CAPTURE_TYPE);
        String attribute57 = exifInterface.getAttribute(ExifInterface.TAG_SCENE_TYPE);
        String attribute58 = exifInterface.getAttribute(ExifInterface.TAG_SENSING_METHOD);
        String attribute59 = exifInterface.getAttribute(ExifInterface.TAG_SHARPNESS);
        String attribute60 = exifInterface.getAttribute(ExifInterface.TAG_SHUTTER_SPEED_VALUE);
        String attribute61 = exifInterface.getAttribute(ExifInterface.TAG_SOFTWARE);
        String attribute62 = exifInterface.getAttribute(ExifInterface.TAG_USER_COMMENT);
        Log.d(TAG, "now write new EXIF data");
        if (attribute != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_F_NUMBER, attribute);
        }
        if (attribute2 != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_DATETIME, attribute2);
        }
        if (attribute3 != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_EXPOSURE_TIME, attribute3);
        }
        if (attribute4 != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_FLASH, attribute4);
        }
        if (attribute5 != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_FOCAL_LENGTH, attribute5);
        }
        if (attribute6 != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_GPS_ALTITUDE, attribute6);
        }
        if (attribute7 != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_GPS_ALTITUDE_REF, attribute7);
        }
        if (attribute8 != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_GPS_DATESTAMP, attribute8);
        }
        if (attribute13 != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_GPS_PROCESSING_METHOD, attribute13);
        }
        if (attribute14 != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_GPS_TIMESTAMP, attribute14);
        }
        if (attribute15 != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_ISO_SPEED_RATINGS, attribute15);
        }
        if (attribute16 != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_MAKE, attribute16);
        }
        if (attribute17 != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_MODEL, attribute17 + " :: Captured by - GPS Map Camera");
        }
        if (attribute18 != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_WHITE_BALANCE, attribute18);
        }
        if (string == null || string.isEmpty() || string2 == null || string2.isEmpty()) {
            myApplicationInterface = this;
        } else {
            myApplicationInterface = this;
            if (NetworkState.Companion.isOnline(myApplicationInterface.main_activity)) {
                exifInterface2.setAttribute(ExifInterface.TAG_GPS_LATITUDE, GPS.convert(Double.parseDouble(string)));
                exifInterface2.setAttribute(ExifInterface.TAG_GPS_LONGITUDE, GPS.convert(Double.parseDouble(string2)));
                exifInterface2.setAttribute(ExifInterface.TAG_GPS_LATITUDE_REF, GPS.latitudeRef(Double.parseDouble(string)));
                exifInterface2.setAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF, GPS.longitudeRef(Double.parseDouble(string2)));
                if (attribute19 != null) {
                    exifInterface2.setAttribute("DateTimeDigitized", attribute19);
                }
                if (attribute20 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_SUBSEC_TIME, attribute20);
                }
                if (attribute21 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_SUBSEC_TIME_DIGITIZED, attribute21);
                }
                if (attribute22 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_SUBSEC_TIME_ORIGINAL, attribute22);
                }
                if (attribute23 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_APERTURE_VALUE, attribute23);
                }
                if (attribute24 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_BRIGHTNESS_VALUE, attribute24);
                }
                if (attribute25 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_CFA_PATTERN, attribute25);
                }
                if (attribute26 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_COLOR_SPACE, attribute26);
                }
                if (attribute27 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_COMPONENTS_CONFIGURATION, attribute27);
                }
                if (attribute28 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_COMPRESSED_BITS_PER_PIXEL, attribute28);
                }
                if (attribute29 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_COMPRESSION, attribute29);
                }
                if (attribute30 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_CONTRAST, attribute30);
                }
                if (attribute31 != null) {
                    exifInterface2.setAttribute("DateTimeOriginal", attribute31);
                }
                if (attribute32 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_DEVICE_SETTING_DESCRIPTION, attribute32);
                }
                if (attribute33 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_DIGITAL_ZOOM_RATIO, attribute33);
                }
                if (attribute34 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_EXPOSURE_BIAS_VALUE, attribute34);
                }
                if (attribute35 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_EXPOSURE_INDEX, attribute35);
                }
                if (attribute36 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_EXPOSURE_MODE, attribute36);
                }
                if (attribute37 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_EXPOSURE_PROGRAM, attribute37);
                }
                if (attribute38 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_FLASH_ENERGY, attribute38);
                }
                if (attribute39 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, attribute39);
                }
                if (attribute40 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_FOCAL_PLANE_RESOLUTION_UNIT, attribute40);
                }
                if (attribute41 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_FOCAL_PLANE_X_RESOLUTION, attribute41);
                }
                if (attribute42 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_FOCAL_PLANE_Y_RESOLUTION, attribute42);
                }
                if (attribute43 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_GAIN_CONTROL, attribute43);
                }
                if (attribute44 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_GPS_AREA_INFORMATION, attribute44);
                }
                if (attribute45 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_GPS_DIFFERENTIAL, attribute45);
                }
                if (attribute46 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_GPS_DOP, attribute46);
                }
                if (attribute47 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_GPS_MEASURE_MODE, attribute47);
                }
                if (attribute48 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_IMAGE_DESCRIPTION, attribute48);
                }
                if (attribute49 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_LIGHT_SOURCE, attribute49);
                }
                if (attribute50 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_MAKER_NOTE, attribute50);
                }
                if (attribute51 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_MAX_APERTURE_VALUE, attribute51);
                }
                if (attribute52 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_METERING_MODE, attribute52);
                }
                if (attribute53 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_OECF, attribute53);
                }
                if (attribute54 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_PHOTOMETRIC_INTERPRETATION, attribute54);
                }
                if (attribute55 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_SATURATION, attribute55);
                }
                if (attribute56 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_SCENE_CAPTURE_TYPE, attribute56);
                }
                if (attribute57 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_SCENE_TYPE, attribute57);
                }
                if (attribute58 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_SENSING_METHOD, attribute58);
                }
                if (attribute59 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_SHARPNESS, attribute59);
                }
                if (attribute60 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_SHUTTER_SPEED_VALUE, attribute60);
                }
                if (attribute61 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_SOFTWARE, attribute61);
                }
                if (attribute62 != null) {
                    exifInterface2.setAttribute(ExifInterface.TAG_USER_COMMENT, attribute62);
                }
                myApplicationInterface.setDateTimeExif(exifInterface2);
                exifInterface2.saveAttributes();
            }
        }
        if (attribute9 != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_GPS_LATITUDE, attribute9);
        }
        if (attribute10 != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_GPS_LATITUDE_REF, attribute10);
        }
        if (attribute11 != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_GPS_LONGITUDE, attribute11);
        }
        if (attribute12 != null) {
            exifInterface2.setAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF, attribute12);
        }
        if (attribute19 != null) {
        }
        if (attribute20 != null) {
        }
        if (attribute21 != null) {
        }
        if (attribute22 != null) {
        }
        if (attribute23 != null) {
        }
        if (attribute24 != null) {
        }
        if (attribute25 != null) {
        }
        if (attribute26 != null) {
        }
        if (attribute27 != null) {
        }
        if (attribute28 != null) {
        }
        if (attribute29 != null) {
        }
        if (attribute30 != null) {
        }
        if (attribute31 != null) {
        }
        if (attribute32 != null) {
        }
        if (attribute33 != null) {
        }
        if (attribute34 != null) {
        }
        if (attribute35 != null) {
        }
        if (attribute36 != null) {
        }
        if (attribute37 != null) {
        }
        if (attribute38 != null) {
        }
        if (attribute39 != null) {
        }
        if (attribute40 != null) {
        }
        if (attribute41 != null) {
        }
        if (attribute42 != null) {
        }
        if (attribute43 != null) {
        }
        if (attribute44 != null) {
        }
        if (attribute45 != null) {
        }
        if (attribute46 != null) {
        }
        if (attribute47 != null) {
        }
        if (attribute48 != null) {
        }
        if (attribute49 != null) {
        }
        if (attribute50 != null) {
        }
        if (attribute51 != null) {
        }
        if (attribute52 != null) {
        }
        if (attribute53 != null) {
        }
        if (attribute54 != null) {
        }
        if (attribute55 != null) {
        }
        if (attribute56 != null) {
        }
        if (attribute57 != null) {
        }
        if (attribute58 != null) {
        }
        if (attribute59 != null) {
        }
        if (attribute60 != null) {
        }
        if (attribute61 != null) {
        }
        if (attribute62 != null) {
        }
        myApplicationInterface.setDateTimeExif(exifInterface2);
        exifInterface2.saveAttributes();
    }

    private void setDateTimeExif(ExifInterface exifInterface) {
        String attribute = exifInterface.getAttribute(ExifInterface.TAG_DATETIME);
        if (attribute != null) {
            exifInterface.setAttribute("DateTimeOriginal", attribute);
            exifInterface.setAttribute("DateTimeDigitized", attribute);
        }
    }

    String dec2DMS(double d) {
        String str = d<0.0d ? "-" : "";
        double abs = Math.abs(d);
        int i = (int) abs;
        boolean z = true;
        boolean z2 = i == 0;
        String valueOf = String.valueOf(i);
        double d2 = (abs - i) * 60.0d;
        int i2 = (int) d2;
        boolean z3 = z2 && i2 == 0;
        String valueOf2 = String.valueOf(i2);
        int i3 = (int) ((d2 - i2) * 60.0d);
        z = (z3 && i3 == 0) ? false : false;
        String valueOf3 = String.valueOf(i3);
        String str2 = z ? "" : str;
        return str2 + valueOf + "°" + valueOf2 + "'" + valueOf3 + "\"";
    }

    /*  JADX ERROR: IndexOutOfBoundsException in pass: SSATransform
        java.lang.IndexOutOfBoundsException: bitIndex < 0: -112
        	at java.base/java.util.BitSet.get(Unknown Source)
        	at jadx.core.dex.visitors.ssa.LiveVarAnalysis.fillBasicBlockInfo(LiveVarAnalysis.java:65)
        	at jadx.core.dex.visitors.ssa.LiveVarAnalysis.runAnalysis(LiveVarAnalysis.java:36)
        	at jadx.core.dex.visitors.ssa.SSATransform.process(SSATransform.java:55)
        	at jadx.core.dex.visitors.ssa.SSATransform.visit(SSATransform.java:41)
        */
//    public Bitmap capturedStampBitmap(ImageSaver.Request request, Canvas r142, Paint p, Bitmap bitmap) {
//        boolean dategeo_stamp = /*request.preference_stamp.equals("preference_stamp_yes");*/false;//Changed
//        boolean text_stamp = /*request.preference_textstamp.length()>0*/false;
//        if (bitmap != null) {
//            if (MyDebug.LOG)
//                Log.d(TAG, "stamp info to bitmap: " + bitmap);
//            if (MyDebug.LOG)
//                Log.d(TAG, "bitmap is mutable?: " + bitmap.isMutable());
//            int font_size = request.font_size;
//            int color = request.color;
//            String pref_style = request.pref_style;
//            String preference_stamp_dateformat = request.preference_stamp_dateformat;
//            String preference_stamp_timeformat = request.preference_stamp_timeformat;
//            String preference_stamp_gpsformat = request.preference_stamp_gpsformat;
//            int width = bitmap.getWidth();
//            int height = bitmap.getHeight();
//            if (MyDebug.LOG) {
//                Log.d(TAG, "decoded bitmap size " + width + ", " + height);
//                Log.d(TAG, "bitmap size: " + width * height * 4);
//            }
//            r142.setBitmap(bitmap);
////            Canvas canvas = new Canvas(bitmap);
////            p.setColor(Color.WHITE);
//            // we don't use the density of the screen, because we're stamping to the image, not drawing on the screen (we don't want the font height to depend on the device's resolution)
//            // instead we go by 1 pt == 1/72 inch height, and scale for an image height (or width if in portrait) of 4" (this means the font height is also independent of the photo resolution)
//            int smallest_size = (width<height) ? width : height;
//            float scale = ((float) smallest_size) / (72.0f * 4.0f);
////            int font_size_pixel = (int) (font_size * scale + 0.5f); // convert pt to pixels
//            if (MyDebug.LOG) {
//                Log.d(TAG, "scale: " + scale);
//                Log.d(TAG, "font_size: " + font_size);
////                Log.d(TAG, "font_size_pixel: " + font_size_pixel);
//            }
////            p.setTextSize(font_size_pixel);
//            int offset_x = (int) (8 * scale + 0.5f); // convert pt to pixels
//            int offset_y = (int) (8 * scale + 0.5f); // convert pt to pixels
//            int diff_y = (int) ((font_size + 4) * scale + 0.5f); // convert pt to pixels
//            int ypos = height - offset_y;
////            p.setTextAlign(Paint.Align.RIGHT);
//            boolean draw_shadowed = false;
//            if (pref_style.equals("preference_stamp_style_shadowed")) {
//                draw_shadowed = true;
//            } else if (pref_style.equals("preference_stamp_style_plain")) {
//                draw_shadowed = false;
//            }
//
//
//            drawStamp(r142, p);
//        }
//        return bitmap;
//    }

//    public void drawStamp(Canvas canvas, Paint paint) {
//        boolean z;
//        String string;
//        double width;
//        double width2;
//        double width3;
//        double d;
//        double d2;
//        float f;
//        float height;
//        float f2;
//        int uIRotation = this.main_activity.getPreview().getUIRotation();
//        Log.e("LKLK", "" + uIRotation);
//        double currentPreviewAspectRatio = this.main_activity.getPreview().getCurrentPreviewAspectRatio();
//        int integer = this.mSP.getInteger(this.main_activity, SP.TEMPLATE_TYPE, 0);
//        if (integer == 0) {
//            z = this.mSP.getBoolean(this.main_activity, SP.IS_MAP, true);
//            this.mSP.getBoolean(this.main_activity, SP.IS_ADDRESS, true);
//            this.mSP.getBoolean(this.main_activity, SP.IS_LAT_LNG_TEMPLATE, true);
//            this.mSP.getBoolean(this.main_activity, SP.IS_WEATHER, false);
//            this.mSP.getBoolean(this.main_activity, SP.IS_DATE_TIME, true);
//            this.mSP.getBoolean(this.main_activity, SP.IS_TIMEZONE, true);
//            this.mSP.getBoolean(this.main_activity, SP.IS_NUMBERING, false);
//            this.mSP.getBoolean(this.main_activity, SP.IS_MAGNETIC_FIELD, false);
//            this.mSP.getBoolean(this.main_activity, SP.IS_COMPASS, false);
//        } else {
//            z = this.mSP.getBoolean(this.main_activity, SP.IS_MAP_CLASSIC, true);
//            this.mSP.getBoolean(this.main_activity, SP.IS_ADDRESS_CLASSIC, true);
//            this.mSP.getBoolean(this.main_activity, SP.IS_LAT_LNG_TEMPLATE_CLASSIC, true);
//            this.mSP.getBoolean(this.main_activity, SP.IS_WEATHER_CLASSIC, false);
//            this.mSP.getBoolean(this.main_activity, SP.IS_DATE_TIME_CLASSIC, true);
//            this.mSP.getBoolean(this.main_activity, SP.IS_TIMEZONE_CLASSIC, true);
//            this.mSP.getBoolean(this.main_activity, SP.IS_NUMBERING_CLASSIC, false);
//            this.mSP.getBoolean(this.main_activity, SP.IS_MAGNETIC_FIELD_CLASSIC, false);
//            this.mSP.getBoolean(this.main_activity, SP.IS_COMPASS_CLASSIC, false);
//        }
//
////        Draw:::: 1308:::276
////           C     :::: 1821:::551
//
//
////        this.imagecompress = this.main_activity.getStampBitmap();
//        this.imagecompress = this.main_activity.getStampBitmap();
//        Log.d("BITMAPPPP", "Draw:::: " + imagecompress.getWidth() + ":::" + imagecompress.getHeight());
//        if (integer == 0) {
//            string = this.sharedPreferences.getString(SP.STAMP_POS, "Bottom");
//        } else {
//            string = this.sharedPreferences.getString(SP.STAMP_POS_CLASSIC, "Bottom");
//        }
//        if (this.imagecompress != null) {
//            float f3 = 0.0f;
//            /*if (integer == 0) {
//                f = (canvas.getWidth() / 2) - (this.imagecompress.getWidth() / 2);
//            } else */
//            {
//                if (z) {
//                    if (uIRotation == 90 || uIRotation == 270) {
//                        if (String.valueOf(currentPreviewAspectRatio).contains("1.777")) {
//                            width = canvas.getWidth() / 2;
//                            width2 = this.imagecompress.getWidth();
//                            width3 = this.imagecompress.getWidth();
//                            d = 2.08d;
//
//                            Log.d("WIDDDD", "width::1.777:" + width);
//                            Log.d("WIDDDD", "width2::1.777:" + width2);
//                            Log.d("WIDDDD", "width3::1.777:" + width3);
//
//                        } else if (String.valueOf(currentPreviewAspectRatio).contains("1.0")) {
//                            width = canvas.getWidth() / 2;
//                            width2 = this.imagecompress.getWidth();
//                            width3 = this.imagecompress.getWidth();
//                            d = 2.17d;
//
//                            Log.d("WIDDDD", "width::1.0:" + width);
//                            Log.d("WIDDDD", "width2::1.0:" + width2);
//                            Log.d("WIDDDD", "width3::1.0:" + width3);
//
//                        } else {
//                            width = canvas.getWidth() / 2;
//                            width2 = this.imagecompress.getWidth();
//                            width3 = this.imagecompress.getWidth();
//                            d = 2.15d;
//
//                            Log.d("WIDDDD", "width::else:" + width);
//                            Log.d("WIDDDD", "width2::else:" + width2);
//                            Log.d("WIDDDD", "width3::else:" + width3);
//
//                        }
//                        d2 = width - (width2 - (width3 / d));
//                        f = (float) d2;
//
//                        Log.d("WIDDDD", "d2:" + d2);
//                        Log.d("WIDDDD", "f:" + f);
//
//
////                        f = (float) d;
//                    } else {
//                        d2 = (canvas.getWidth() / 2) - (this.imagecompress.getWidth() - (this.imagecompress.getWidth() / 2.18d));
//                        f = (float) d2;
//
//                    }
//
//                } else if (uIRotation == 90 || uIRotation == 270) {
//                    if (String.valueOf(currentPreviewAspectRatio).contains("1.777")) {
//                        width = canvas.getWidth() / 2;
//                        width2 = this.imagecompress.getWidth();
//                        width3 = this.imagecompress.getWidth();
//                        d = 2.05d;
//
//
//                        Log.d("WIDDDD", "width::1.777:" + width);
//                        Log.d("WIDDDD", "width2::1.777:" + width2);
//                        Log.d("WIDDDD", "width3::1.777:" + width3);
//
//                    } else if (String.valueOf(currentPreviewAspectRatio).contains("1.0")) {
//                        width = canvas.getWidth() / 2;
//                        width2 = this.imagecompress.getWidth();
//                        width3 = this.imagecompress.getWidth();
//                        d = 2.094d;
//
//
//                        Log.d("WIDDDD", "width::1.0:" + width);
//                        Log.d("WIDDDD", "width2::1.0:" + width2);
//                        Log.d("WIDDDD", "width3::1.0:" + width3);
//
//
//                    } else {
//                        width = canvas.getWidth() / 2;
//                        width2 = this.imagecompress.getWidth();
//                        width3 = this.imagecompress.getWidth();
//                        d = 2.07d;
//
//
//                        Log.d("WIDDDD", "width::else:" + width);
//                        Log.d("WIDDDD", "width2::else:" + width2);
//                        Log.d("WIDDDD", "width3::else:" + width3);
//
//
//                    }
//                    d2 = width - (width2 - (width3 / d));
//                    f = (float) d2;
////                    f = (float) d;
//
//                    Log.d("WIDDDD", "d2:" + d2);
//                    Log.d("WIDDDD", "f:" + f);
//
//
//                } else {
//                    width = canvas.getWidth() / 2;
//                    width2 = this.imagecompress.getWidth();
//                    width3 = this.imagecompress.getWidth();
//                    d = 2.092d;
//                    d2 = width - (width2 - (width3 / d));
//                    f = (float) d2;
//
//                    Log.d("WIDDDD", "else:d2:" + d2);
//                    Log.d("WIDDDD", "else:f:" + f);
//
//
//                }
//
//            }
//
//            paint.setAntiAlias(true);
//            int height2 = this.imagecompress.getHeight();
//            if (uIRotation == 90 || uIRotation == 270) {
//                f3 = 0.0f - ((canvas.getWidth() - canvas.getHeight()) / 2);
//            }
//            this.imagecompress.getHeight();
//            if (string.equals("Bottom")) {
//                if (integer == 0) {
//                    height = canvas.getHeight();
//                    f2 = height2;
//                } else {
//                    height = canvas.getHeight();
//                    f3 += height2;
//                    f2 = 50.0f;
//                }
//                f3 = height - (f3 + f2);
//            }
//            if (integer == 0) {
//                canvas.drawBitmap(this.imagecompress, f, f3, paint);
//            } else if (uIRotation == 90 || uIRotation == 270) {
//                canvas.drawBitmap(Bitmap.createScaledBitmap(this.imagecompress, canvas.getHeight() + 50, this.imagecompress.getHeight() + 50, true), f, f3, paint);
//            } else {
//                canvas.drawBitmap(Bitmap.createScaledBitmap(this.imagecompress, canvas.getWidth() + 50, this.imagecompress.getHeight() + 50, true), f, f3, paint);
//            }
//            this.imagecompress.recycle();
//            this.imagecompress = null;
//            System.gc();
//        }
//    }

    public void drawStamp(Canvas canvas0, Paint paint0) {
        float f5;
        float f4;
        double f3;
        float f2;
        boolean z;
        MyApplicationInterface myApplicationInterface0 = this;
        Canvas canvas1 = canvas0;
        Paint paint1 = paint0;
        int v = myApplicationInterface0.main_activity.getPreview().getUIRotation();
//        Log.e("LKLK", "" + v);
        double f = myApplicationInterface0.main_activity.getPreview().getCurrentPreviewAspectRatio();
        int v1 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "template_type", 0);
        if (v1 == 0) {
            z = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_map", true);
            myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_address", true);
            myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_lat_lng_template", true);
            myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_weather", false);
            myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_date_time", true);
            myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_timezone", true);
            myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_numbering", false);
            myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_magnetic_field", false);
            myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_compass", false);
        } else {
            z = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_map_classic", true);
            myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_address_classic", true);
            myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_lat_lng_template_classic", true);
            myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_weather_classic", false);
            myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_date_time_classic", true);
            myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_timezone_classic", true);
            myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_numbering_classic", false);
            myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_magnetic_field_classic", false);
            myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_compass_classic", false);
        }

        myApplicationInterface0.imagecompress = myApplicationInterface0.main_activity.getStampBitmap();
        String s = v1 == 0 ? myApplicationInterface0.sharedPreferences.getString("stamp_pos", "Bottom") : myApplicationInterface0.sharedPreferences.getString("stamp_pos_classic", "Bottom");
        if (myApplicationInterface0.imagecompress != null) {
            float f1 = 0.0f;
            if (v1 == 0) {
                f2 = (float) (canvas0.getWidth() / 2 - myApplicationInterface0.imagecompress.getWidth() / 2);
            } else {
                if (z) {
                    if (v != 90 && v != 270) {
                        f3 = ((double) (canvas0.getWidth() / 2)) - (((double) myApplicationInterface0.imagecompress.getWidth()) - ((double) myApplicationInterface0.imagecompress.getWidth()) / 2.18);
                    } else if (String.valueOf(f).contains("1.777")) {
                        f3 = ((double) (canvas0.getWidth() / 2)) - (((double) myApplicationInterface0.imagecompress.getWidth()) - ((double) myApplicationInterface0.imagecompress.getWidth()) / 2.08);
                    } else if (String.valueOf(f).contains("1.0")) {
                        f3 = ((double) (canvas0.getWidth() / 2)) - (((double) myApplicationInterface0.imagecompress.getWidth()) - ((double) myApplicationInterface0.imagecompress.getWidth()) / 2.17);
                    } else {
                        f3 = ((double) (canvas0.getWidth() / 2)) - (((double) myApplicationInterface0.imagecompress.getWidth()) - ((double) myApplicationInterface0.imagecompress.getWidth()) / 2.15);
                    }
                } else if (v != 90 && v != 270) {
                    f3 = ((double) (canvas0.getWidth() / 2)) - (((double) myApplicationInterface0.imagecompress.getWidth()) - ((double) myApplicationInterface0.imagecompress.getWidth()) / 2.092);
                } else if (String.valueOf(f).contains("1.777")) {
                    f3 = ((double) (canvas0.getWidth() / 2)) - (((double) myApplicationInterface0.imagecompress.getWidth()) - ((double) myApplicationInterface0.imagecompress.getWidth()) / 2.05);
                } else {
                    f3 = String.valueOf(f).contains("1.0") ? ((double) (canvas0.getWidth() / 2)) - (((double) myApplicationInterface0.imagecompress.getWidth()) - ((double) myApplicationInterface0.imagecompress.getWidth()) / 2.094) : ((double) (canvas0.getWidth() / 2)) - (((double) myApplicationInterface0.imagecompress.getWidth()) - ((double) myApplicationInterface0.imagecompress.getWidth()) / 2.07);
                }

                f2 = (float) f3;
            }

            paint1.setAntiAlias(true);
            int v2 = myApplicationInterface0.imagecompress.getHeight();
            if (v == 90 || v == 270) {
                f1 = 0.0f - ((float) ((canvas0.getWidth() - canvas0.getHeight()) / 2));
            }

            myApplicationInterface0.imagecompress.getHeight();
            if (s.equals("Bottom")) {
                if (v1 == 0) {
                    f4 = (float) canvas0.getHeight();
                    f5 = (float) v2;
                } else {
                    f4 = (float) canvas0.getHeight();
                    f1 += (float) v2;
                    f5 = 50.0f;
                }

                f1 = f4 - (f1 + f5);
            }

            if (v1 == 0) {
                canvas1.drawBitmap(myApplicationInterface0.imagecompress, f2, f1, paint1);
            } else if (v != 90 && v != 270) {
                canvas1.drawBitmap(Bitmap.createScaledBitmap(myApplicationInterface0.imagecompress, canvas0.getWidth() + 50, myApplicationInterface0.imagecompress.getHeight() + 50, true), f2, f1, paint1);
            } else {
                canvas1.drawBitmap(Bitmap.createScaledBitmap(myApplicationInterface0.imagecompress, canvas0.getHeight() + 50, myApplicationInterface0.imagecompress.getHeight() + 50, true), f2, f1, paint1);
            }

            myApplicationInterface0.imagecompress.recycle();
            myApplicationInterface0.imagecompress = null;
            System.gc();
        }
    }

    public Bitmap capturedStampBitmap(ImageSaver.Request imageSaver$Request0, Canvas
            canvas0, Paint paint0, Bitmap bitmap0) {
        double f10;
        double f9;
        double f8;
        double f7;
        float f5;
        float f4;
        TextView textView24;
        TextView textView23;
        String s31;
        int v238;
        TextView textView19;
        LinearLayout linearLayout35;
        LinearLayout linearLayout34;
        LinearLayout linearLayout33;
        LinearLayout linearLayout32;
        String s15;
        LinearLayout linearLayout31;
        int v230;
        int v229;
        int v224;
        TextView textView15;
        ImageView imageView14;
        LinearLayout linearLayout30;
        int v222;
        TextView textView14;
        LinearLayout linearLayout29;
        ImageView imageView13 = null;
        ImageView imageView12;
        int v219;
        int v218;
        LinearLayout linearLayout28;
        ImageView imageView11;
        int v217;
        LinearLayout linearLayout27;
        LinearLayout linearLayout26;
        int v216;
        TextView textView13;
        LinearLayout linearLayout25;
        LinearLayout linearLayout24;
        TextView textView12;
        LinearLayout linearLayout23;
        LinearLayout linearLayout22;
        int v215;
        TextView textView11;
        int v214;
        LinearLayout linearLayout21;
        LinearLayout linearLayout18;
        LinearLayout linearLayout17;
        RoundCorners roundCorners2;
        int v212;
        int v211;
        int v210;
        int v109;
        int v108;
        int v107;
        RoundCorners roundCorners1;
        int v106;
        int v105;
        int v104;
        int v103;
        int v102;
        int v101;
        int v100;
        int v99;
        int v98;
        int v97;
        int v96;
        int v95;
        int v94;
        int v93;
        int v92;
        int v91;
        int v90;
        int v89;
        int v88;
        ImageView imageView10;
        int v87;
        LinearLayout linearLayout16;
        String s6;
        int v26;
        int v25;
        int v24;
        int v23;
        int v22;
        float f;
        String s5;
        int v21;
        String s4;
        int v20;
        String s3;
        String s2;
        int v19;
        int v16;
        int v15;
        int v14;
        int v13;
        int v12;
        int v11;
        int v10;
        int v9;
        int v8;
        int v7;
        int v6;
        int v5;
        int v4;
        int v3;
        int v2;
        boolean z19;
        boolean z17;
        boolean z16;
        boolean z15;
        boolean z14;
        String s1;
        String s;
        boolean z13;
        boolean z12;
        boolean z11;
        boolean z10;
        boolean z9;
        boolean z8;
        boolean z7;
        boolean z6;
        boolean z5;
        boolean z4;
        boolean z3;
        boolean z2;
        boolean z1;
        MyApplicationInterface myApplicationInterface0 = this;
        Log.e("LALU", "capturedStampBitmap: ");
        myApplicationInterface0.orginalImage = bitmap0.copy(bitmap0.getConfig(), true);
        if (new SP(myApplicationInterface0.main_activity).getBoolean(myApplicationInterface0.main_activity, "is_original_image", false)) {
            Bitmap bitmap1 = myApplicationInterface0.orginalImage;
            if (bitmap1 != null) {
                myApplicationInterface0.storeImage(imageSaver$Request0, bitmap1);
            }
        }

        try {
            int v = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "template_type", 0);
            boolean z = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "compass_found", false);
            if (v == 0) {
                z1 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_map", true);
                z2 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_address", true);
                z3 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_lat_lng_template", true);
                z4 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_plus_code", false);
                z5 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_weather", false);
                z6 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_date_time", true);
                z7 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_timezone", true);
                z8 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_numbering", false);
                z9 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_increment", true);
                z10 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_magnetic_field", false);
                z11 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_compass", false);
                z12 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_logo", false);
                z13 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_notes", false);
                s = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "stamp_size", "Medium");
                s1 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "plusCodeType", "accurate");
                z14 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_humidity", false);
                z15 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_accuracy", false);
                z16 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_altitude", false);
                z17 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_wind", false);
                boolean z18 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_pressure", false);
                SP sP0 = myApplicationInterface0.mSP;
                z19 = z18;
                int v1 = Color.parseColor("#9c000000");
                v2 = sP0.getInteger(myApplicationInterface0.main_activity, "BACKGROUND_COLOR", v1);
                v3 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "WEATHER_COLOR", -1);
                v4 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "MAGNETIC_FIELD_COLOR", -1);
                v5 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "COMPASS_COLOR", -1);
                v6 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "ADDRESS_COLOR", -1);
                v7 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "DATE_TIME_COLOR", -1);
                v8 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "LAT_LNG_COLOR", -1);
                v9 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "PLUS_CODE_COLOR", -1);
                v10 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "NOTES_HASHTAG_COLOR", -1);
                v11 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "WIND_COLOR", -1);
                v12 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "PRESSURE_COLOR", -1);
                v13 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "HUMIDITY_COLOR", -1);
                v14 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "ALTITUDE_COLOR", -1);
                v15 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "ACCURACY_COLOR", -1);
                v16 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "NUMBERING_COLOR", -1);
                int v17 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "TIME_ZONE", 6);
                int v18 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "SEQUENCE", 1);
                v19 = v17;
                s2 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "PREFIX", "");
                s3 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "SUFFIX", "");
                v20 = v18;
                s4 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "date_format", "dd/MM/yy hh:mm a");
                v21 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "lat_lng_type_1", 1);
                s5 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "temprature_type", "Celsius");
                f = myApplicationInterface0.mSP.getFloat(myApplicationInterface0.main_activity, "temprature_value");
                v22 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "weather_icon", 0);
                v23 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "wind_select", 0);
                v24 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "pressure_select", 0);
                v25 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "altitude_select", 0);
                v26 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "accuracy_select", 0);
                s6 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "logo_uri", "no_logo");
            }
            else {
                z1 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_map_classic", true);
                z2 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_address_classic", true);
                z3 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_lat_lng_template_classic", true);
                z4 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_plus_code_classic", false);
                z5 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_weather_classic", false);
                z6 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_date_time_classic", true);
                z7 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_timezone_classic", true);
                z8 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_numbering_classic", false);
                z9 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_increment_classic", true);
                z10 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_magnetic_field_classic", false);
                z11 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_compass_classic", false);
                z12 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_logo_classic", false);
                z13 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_notes_classic", false);
                s = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "stamp_size_classic", "Medium");
                s1 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "stamp_size_classic", "accurate");
                z14 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_humidity_classic", false);
                z15 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_accuracy_classic", false);
                z16 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_altitude_classic", false);
                z17 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_wind_classic", false);
                boolean z20 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_pressure_classic", false);
                SP sP1 = myApplicationInterface0.mSP;
                z19 = z20;
                int v27 = Color.parseColor("#9c000000");
                v2 = sP1.getInteger(myApplicationInterface0.main_activity, "BACKGROUND_COLOR_CLASSIC", v27);
                v3 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "WEATHER_COLOR_CLASSIC", -1);
                v4 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "MAGNETIC_FIELD_COLOR_CLASSIC", -1);
                v5 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "COMPASS_COLOR_CLASSIC", -1);
                v6 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "ADDRESS_COLOR_CLASSIC", -1);
                v7 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "DATE_TIME_COLOR_CLASSIC", -1);
                v8 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "LAT_LNG_COLOR_CLASSIC", -1);
                v9 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "PLUS_CODE_COLOR_CLASSIC", -1);
                v10 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "NOTES_HASHTAG_COLOR_CLASSIC", -1);
                v11 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "WIND_COLOR_CLASSIC", -1);
                v12 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "PRESSURE_COLOR_CLASSIC", -1);
                v13 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "HUMIDITY_COLOR_CLASSIC", -1);
                v14 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "ALTITUDE_COLOR_CLASSIC", -1);
                v15 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "ACCURACY_COLOR_CLASSIC", -1);
                v16 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "NUMBERING_COLOR_CLASSIC", -1);
                int v28 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "TIME_ZONE_CLASSIC", 6);
                int v29 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", 1);
                v19 = v28;
                s2 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "PREFIX_CLASSIC", "");
                s3 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "SUFFIX_CLASSIC", "");
                v20 = v29;
                s4 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "date_format_classic", "dd/MM/yy hh:mm a");
                v21 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "lat_lng_type_1_classic", 1);
                s5 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "temprature_type_classic", "Celsius");
                f = myApplicationInterface0.mSP.getFloat(myApplicationInterface0.main_activity, "temprature_value");
                v22 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "weather_icon", 0);
                v23 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "wind_select_classic", 0);
                v24 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "pressure_select_classic", 0);
                v25 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "altitude_select_classic", 0);
                v26 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "accuracy_select_classic", 0);
                s6 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "logo_uri_classic", "no_logo");
            }

            String s7 = s6;
            String s8 = s;
            int v30 = v6;
            int v31 = v7;
            int v32 = v8;
            int v33 = v9;
            int v34 = v10;
            int v35 = v11;
            int v36 = v12;
            int v37 = v13;
            int v38 = v16;
            int v39 = v20;
            int v40 = v21;
            String s9 = s5;
            int v41 = v24;
            boolean z21 = z1;
            boolean z22 = z2;
            boolean z23 = z6;
            boolean z24 = z7;
            boolean z25 = z9;
            String s10 = s2;
            String s11 = s3;
            String s12 = s1;
            boolean z26 = z3;
            int v42 = v19;
            int v43 = v23;
            int v44 = v5;
            View view0 = ((LayoutInflater) myApplicationInterface0.main_activity.getSystemService("layout_inflater")).inflate(R.layout.stamp_layout_save, null);  // layout:stamp_layout_save
            TextView tv_address_line_1 = (TextView) view0.findViewById(R.id.tv_address_line_1);  // id:tv_address_line_1
            TextView tv_address = (TextView) view0.findViewById(R.id.tv_address);  // id:tv_address
            TextView tv_weather = (TextView) view0.findViewById(R.id.tv_weather);  // id:tv_weather
            int v45 = /*v4*/R.color.white;
            TextView tv_compass = (TextView) view0.findViewById(R.id.tv_compass);  // id:tv_compass
            int v46 = v3;
            TextView txt_watermark = (TextView) view0.findViewById(R.id.txt_watermark);  // id:txt_watermark
            int v47 = v2;
            TextView txt_watermark_2 = (TextView) view0.findViewById(R.id.txt_watermark_2);  // id:txt_watermark_2
            TextView textView6 = tv_address_line_1;
            TextView tv_magnetic_field = (TextView) view0.findViewById(R.id.tv_magnetic_field);  // id:tv_magnetic_field
            boolean z27 = z;
            TextView txt_wind = (TextView) view0.findViewById(R.id.txt_wind);  // id:txt_wind
            int v48 = v15;
            TextView txt_humidity = (TextView) view0.findViewById(R.id.txt_humidity);  // id:txt_humidity
            int v49 = v26;
            TextView txt_pressure = (TextView) view0.findViewById(R.id.txt_pressure);  // id:txt_pressure
            int v50 = v14;
            RoundCorners imgMap = (RoundCorners) view0.findViewById(R.id.imgMap);  // id:imgMap
            int v51 = v25;
            LinearLayout li_main_stamp_lay = (LinearLayout) view0.findViewById(R.id.li_main_stamp_lay);  // id:li_main_stamp_lay
            int v52 = v22;
            LinearLayout li_stamp = (LinearLayout) view0.findViewById(R.id.li_stamp);  // id:li_stamp
            LinearLayout lin_waterma = (LinearLayout) view0.findViewById(R.id.lin_waterma);  // id:lin_waterma
            LinearLayout lin_waterma_2 = (LinearLayout) view0.findViewById(R.id.lin_waterma_2);  // id:lin_waterma_2
            LinearLayout li_compass = (LinearLayout) view0.findViewById(R.id.li_compass);  // id:li_compass
            LinearLayout li_logo = (LinearLayout) view0.findViewById(R.id.li_logo);  // id:li_logo
            LinearLayout lin_bottom_wather = (LinearLayout) view0.findViewById(R.id.lin_bottom_wather);  // id:lin_bottom_wather
            LinearLayout li_main_stamp_lay2 = li_main_stamp_lay;
            LinearLayout lin_wind_stamp = (LinearLayout) view0.findViewById(R.id.lin_wind_stamp);  // id:lin_wind_stamp
            LinearLayout lin_humidity_stamp = (LinearLayout) view0.findViewById(R.id.lin_humidity_stamp);  // id:lin_humidity_stamp
            LinearLayout lin_pressure_stamp = (LinearLayout) view0.findViewById(R.id.lin_pressure_stamp);  // id:lin_pressure_stamp
            ImageView imgCompass = (ImageView) view0.findViewById(R.id.imgCompass);  // id:imgCompass
            LinearLayout lin_bottom_wather2 = lin_bottom_wather;
            ImageView img_stamp = (ImageView) view0.findViewById(R.id.img_stamp);  // id:img_stamp
            ImageView img_stamp_2 = (ImageView) view0.findViewById(R.id.img_stamp_2);  // id:img_stamp_2
            ImageView imgWeather = (ImageView) view0.findViewById(R.id.imgWeather);  // id:imgWeather
            ImageView imgMagneticField = (ImageView) view0.findViewById(R.id.imgMagneticField);  // id:imgMagneticField
            ImageView imgCompass2 = imgCompass;
            ImageView imgLogo = (ImageView) view0.findViewById(R.id.imgLogo);  // id:imgLogo
            ImageView img_wind_stamp = (ImageView) view0.findViewById(R.id.img_wind_stamp);  // id:img_wind_stamp
            ImageView img_humidity_stamp = (ImageView) view0.findViewById(R.id.img_humidity_stamp);  // id:img_humidity_stamp
            ImageView img_pressure_stamp = (ImageView) view0.findViewById(R.id.img_pressure_stamp);  // id:img_pressure_stamp
            LinearLayout li_rightView = (LinearLayout) view0.findViewById(R.id.li_rightView);  // id:li_rightView
            LinearLayout li_address = (LinearLayout) view0.findViewById(R.id.li_address);  // id:li_address
            LinearLayout li_magnetic_field = (LinearLayout) view0.findViewById(R.id.li_magnetic_field);  // id:li_magnetic_field
            LinearLayout li_weather = (LinearLayout) view0.findViewById(R.id.li_weather);  // id:li_weather
            View view1 = view0;
            linearLayout24 = lin_humidity_stamp;
            textView12 = tv_magnetic_field;
            if (s8.equals("Large")) {
                linearLayout16 = li_weather;
                int v53 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 6.0f) / ((float) myApplicationInterface0.DW));
                int v54 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 8.0f) / ((float) myApplicationInterface0.DW));
                int v55 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 10.0f) / ((float) myApplicationInterface0.DW));
                int v56 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 12.0f) / ((float) myApplicationInterface0.DW));
                int v57 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 18.0f) / ((float) myApplicationInterface0.DW));
                int v58 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 16.0f) / ((float) myApplicationInterface0.DW));
                int v59 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 4.0f) / ((float) myApplicationInterface0.DW));
                bitmap0.getWidth();
                int v60 = v59;
                int v61 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 36.0f) / ((float) myApplicationInterface0.DW));
                int v62 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 30.0f) / ((float) myApplicationInterface0.DW));
                int v63 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 60.0f) / ((float) myApplicationInterface0.DW));
                int v64 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 200.0f) / ((float) myApplicationInterface0.DW));
                int v65 = v63;
                int v66 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 210.0f) / ((float) myApplicationInterface0.DW));
                int v67 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 240.0f) / ((float) myApplicationInterface0.DW));
                int v68 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 250.0f) / ((float) myApplicationInterface0.DW));
                int v69 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 243.0f) / ((float) myApplicationInterface0.DW));
                int v70 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 253.0f) / ((float) myApplicationInterface0.DW));
                int v71 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 255.0f) / ((float) myApplicationInterface0.DW));
                int v72 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 130.0f) / ((float) myApplicationInterface0.DW));
                int v73 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 140.0f) / ((float) myApplicationInterface0.DW));
                int v74 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 155.0f) / ((float) myApplicationInterface0.DW));
                int v75 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 160.0f) / ((float) myApplicationInterface0.DW));
                int v76 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 170.0f) / ((float) myApplicationInterface0.DW));
                int v77 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 180.0f) / ((float) myApplicationInterface0.DW));
                if (bitmap0.getWidth()>bitmap0.getHeight()) {
                    v64 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 170.0f) / ((float) myApplicationInterface0.DW));
                    int v78 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 180.0f) / ((float) myApplicationInterface0.DW));
                    int v79 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 210.0f) / ((float) myApplicationInterface0.DW));
                    int v80 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 220.0f) / ((float) myApplicationInterface0.DW));
                    int v81 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 213.0f) / ((float) myApplicationInterface0.DW));
                    int v82 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 223.0f) / ((float) myApplicationInterface0.DW));
                    int v83 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 225.0f) / ((float) myApplicationInterface0.DW));
                    int v84 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 80.0f) / ((float) myApplicationInterface0.DW));
                    int v85 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 85.0f) / ((float) myApplicationInterface0.DW));
                    int v86 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 105.0f) / ((float) myApplicationInterface0.DW));
                    v87 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 110.0f) / ((float) myApplicationInterface0.DW));
                    imageView10 = imgMagneticField;
                    v88 = v78;
                    v89 = v86;
                    v90 = v79;
                    v91 = v80;
                    v92 = v81;
                    v93 = v82;
                    v94 = v53;
                    v95 = v54;
                    v96 = v55;
                    v97 = v58;
                    v98 = v60;
                    v99 = v61;
                    v100 = v62;
                    v101 = v65;
                    v102 = v83;
                    v103 = v84;
                    v104 = v85;
                } else {
                    imageView10 = imgMagneticField;
                    v89 = v74;
                    v103 = v72;
                    v87 = v75;
                    v94 = v53;
                    v95 = v54;
                    v96 = v55;
                    v97 = v58;
                    v98 = v60;
                    v99 = v61;
                    v100 = v62;
                    v101 = v65;
                    v88 = v66;
                    v90 = v67;
                    v91 = v68;
                    v92 = v69;
                    v93 = v70;
                    v102 = v71;
                    v104 = v73;
                }

                v105 = v76;
                v106 = v77;
                roundCorners1 = imgMap;
                v107 = v64;
                v108 = v56;
                v109 = v57;
            }
            else {
                linearLayout16 = li_weather;
                if (s8.equals("Medium")) {
                    int v110 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 4.0f) / ((float) myApplicationInterface0.DW));
                    int v111 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 6.0f) / ((float) myApplicationInterface0.DW));
                    int v112 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 8.0f) / ((float) myApplicationInterface0.DW));
                    int v113 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 10.0f) / ((float) myApplicationInterface0.DW));
                    v109 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 16.0f) / ((float) myApplicationInterface0.DW));
                    int v114 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 14.0f) / ((float) myApplicationInterface0.DW));
                    int v115 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 2.0f) / ((float) myApplicationInterface0.DW));
                    bitmap0.getWidth();
                    int v116 = v114;
                    int v117 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 33.0f) / ((float) myApplicationInterface0.DW));
                    int v118 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 30.0f) / ((float) myApplicationInterface0.DW));
                    int v119 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 55.0f) / ((float) myApplicationInterface0.DW));
                    int v120 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 170.0f) / ((float) myApplicationInterface0.DW));
                    int v121 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 180.0f) / ((float) myApplicationInterface0.DW));
                    int v122 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 200.0f) / ((float) myApplicationInterface0.DW));
                    int v123 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 210.0f) / ((float) myApplicationInterface0.DW));
                    int v124 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 195.0f) / ((float) myApplicationInterface0.DW));
                    int v125 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 215.0f) / ((float) myApplicationInterface0.DW));
                    int v126 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 210.0f) / ((float) myApplicationInterface0.DW));
                    int v127 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 114.0f) / ((float) myApplicationInterface0.DW));
                    int v128 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 120.0f) / ((float) myApplicationInterface0.DW));
                    int v129 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 125.0f) / ((float) myApplicationInterface0.DW));
                    int v130 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 140.0f) / ((float) myApplicationInterface0.DW));
                    int v131 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 160.0f) / ((float) myApplicationInterface0.DW));
                    int v132 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 170.0f) / ((float) myApplicationInterface0.DW));
                    if (bitmap0.getWidth()>bitmap0.getHeight()) {
                        int v133 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 150.0f) / ((float) myApplicationInterface0.DW));
                        int v134 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 160.0f) / ((float) myApplicationInterface0.DW));
                        int v135 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 190.0f) / ((float) myApplicationInterface0.DW));
                        int v136 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 200.0f) / ((float) myApplicationInterface0.DW));
                        int v137 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 195.0f) / ((float) myApplicationInterface0.DW));
                        int v138 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 203.0f) / ((float) myApplicationInterface0.DW));
                        int v139 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 205.0f) / ((float) myApplicationInterface0.DW));
                        int v140 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 80.0f) / ((float) myApplicationInterface0.DW));
                        int v141 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 85.0f) / ((float) myApplicationInterface0.DW));
                        int v142 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 90.0f) / ((float) myApplicationInterface0.DW));
                        v87 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 100.0f) / ((float) myApplicationInterface0.DW));
                        v94 = v110;
                        v90 = v135;
                        v88 = v134;
                        v106 = v132;
                        v91 = v136;
                        v92 = v137;
                        v101 = v119;
                        v95 = v111;
                        v96 = v112;
                        v97 = v116;
                        v99 = v117;
                        v100 = v118;
                        v93 = v138;
                        v102 = v139;
                        v103 = v140;
                        v104 = v141;
                        v89 = v142;
                        v105 = v131;
                        v98 = v115;
                        imageView10 = imgMagneticField;
                        v108 = v113;
                        roundCorners1 = imgMap;
                        v107 = v133;
                    } else {
                        v94 = v110;
                        v87 = v130;
                        v88 = v121;
                        v89 = v129;
                        v106 = v132;
                        v101 = v119;
                        v95 = v111;
                        v96 = v112;
                        v97 = v116;
                        v99 = v117;
                        v100 = v118;
                        v90 = v122;
                        v93 = v125;
                        v91 = v123;
                        v92 = v124;
                        v102 = v126;
                        v103 = v127;
                        v104 = v128;
                        v105 = v131;
                        roundCorners1 = imgMap;
                        v98 = v115;
                        imageView10 = imgMagneticField;
                        v108 = v113;
                        v107 = v120;
                    }
                }
                else if (s8.equals("Small")) {
                    int v143 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 3.0f) / ((float) myApplicationInterface0.DW));
                    int v144 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 5.0f) / ((float) myApplicationInterface0.DW));
                    int v145 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 7.0f) / ((float) myApplicationInterface0.DW));
                    int v146 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 9.0f) / ((float) myApplicationInterface0.DW));
                    v109 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 15.0f) / ((float) myApplicationInterface0.DW));
                    int v147 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 13.0f) / ((float) myApplicationInterface0.DW));
                    int v148 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 2.0f) / ((float) myApplicationInterface0.DW));
                    bitmap0.getWidth();
                    int v149 = v147;
                    int v150 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 32.0f) / ((float) myApplicationInterface0.DW));
                    int v151 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 28.0f) / ((float) myApplicationInterface0.DW));
                    int v152 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 50.0f) / ((float) myApplicationInterface0.DW));
                    int v153 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 160.0f) / ((float) myApplicationInterface0.DW));
                    int v154 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 170.0f) / ((float) myApplicationInterface0.DW));
                    int v155 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 190.0f) / ((float) myApplicationInterface0.DW));
                    int v156 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 200.0f) / ((float) myApplicationInterface0.DW));
                    int v157 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 185.0f) / ((float) myApplicationInterface0.DW));
                    int v158 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 205.0f) / ((float) myApplicationInterface0.DW));
                    int v159 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 200.0f) / ((float) myApplicationInterface0.DW));
                    int v160 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 104.0f) / ((float) myApplicationInterface0.DW));
                    int v161 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 110.0f) / ((float) myApplicationInterface0.DW));
                    int v162 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 115.0f) / ((float) myApplicationInterface0.DW));
                    int v163 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 130.0f) / ((float) myApplicationInterface0.DW));
                    int v164 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 150.0f) / ((float) myApplicationInterface0.DW));
                    int v165 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 160.0f) / ((float) myApplicationInterface0.DW));
                    if (bitmap0.getWidth()>bitmap0.getHeight()) {
                        int v166 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 140.0f) / ((float) myApplicationInterface0.DW));
                        int v167 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 150.0f) / ((float) myApplicationInterface0.DW));
                        int v168 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 180.0f) / ((float) myApplicationInterface0.DW));
                        int v169 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 190.0f) / ((float) myApplicationInterface0.DW));
                        int v170 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 185.0f) / ((float) myApplicationInterface0.DW));
                        int v171 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 193.0f) / ((float) myApplicationInterface0.DW));
                        int v172 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 195.0f) / ((float) myApplicationInterface0.DW));
                        int v173 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 70.0f) / ((float) myApplicationInterface0.DW));
                        int v174 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 75.0f) / ((float) myApplicationInterface0.DW));
                        int v175 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 85.0f) / ((float) myApplicationInterface0.DW));
                        v87 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 90.0f) / ((float) myApplicationInterface0.DW));
                        v98 = v148;
                        v88 = v167;
                        v94 = v143;
                        v90 = v168;
                        v91 = v169;
                        v106 = v165;
                        v92 = v170;
                        v101 = v152;
                        v95 = v144;
                        v96 = v145;
                        v108 = v146;
                        v97 = v149;
                        v99 = v150;
                        v100 = v151;
                        v93 = v171;
                        v102 = v172;
                        v103 = v173;
                        v104 = v174;
                        v89 = v175;
                        v105 = v164;
                        roundCorners1 = imgMap;
                        v107 = v166;
                    } else {
                        roundCorners1 = imgMap;
                        v98 = v148;
                        v87 = v163;
                        v94 = v143;
                        v90 = v155;
                        v103 = v160;
                        v106 = v165;
                        v101 = v152;
                        v95 = v144;
                        v96 = v145;
                        v108 = v146;
                        v97 = v149;
                        v99 = v150;
                        v100 = v151;
                        v107 = v153;
                        v88 = v154;
                        v93 = v158;
                        v91 = v156;
                        v92 = v157;
                        v102 = v159;
                        v104 = v161;
                        v89 = v162;
                        v105 = v164;
                    }

                    imageView10 = imgMagneticField;
                }
                else {
                    int v176 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 2.0f) / ((float) myApplicationInterface0.DW));
                    int v177 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 3.0f) / ((float) myApplicationInterface0.DW));
                    int v178 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 5.0f) / ((float) myApplicationInterface0.DW));
                    int v179 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 7.0f) / ((float) myApplicationInterface0.DW));
                    int v180 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 10.0f) / ((float) myApplicationInterface0.DW));
                    int v181 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 8.0f) / ((float) myApplicationInterface0.DW));
                    int v182 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 2.0f) / ((float) myApplicationInterface0.DW));
                    bitmap0.getWidth();
                    int v183 = v181;
                    int v184 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 27.0f) / ((float) myApplicationInterface0.DW));
                    int v185 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 23.0f) / ((float) myApplicationInterface0.DW));
                    int v186 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 42.0f) / ((float) myApplicationInterface0.DW));
                    int v187 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 120.0f) / ((float) myApplicationInterface0.DW));
                    int v188 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 130.0f) / ((float) myApplicationInterface0.DW));
                    int v189 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 150.0f) / ((float) myApplicationInterface0.DW));
                    int v190 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 160.0f) / ((float) myApplicationInterface0.DW));
                    int v191 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 145.0f) / ((float) myApplicationInterface0.DW));
                    int v192 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 165.0f) / ((float) myApplicationInterface0.DW));
                    int v193 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 160.0f) / ((float) myApplicationInterface0.DW));
                    int v194 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 65.0f) / ((float) myApplicationInterface0.DW));
                    int v195 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 70.0f) / ((float) myApplicationInterface0.DW));
                    int v196 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 75.0f) / ((float) myApplicationInterface0.DW));
                    int v197 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 90.0f) / ((float) myApplicationInterface0.DW));
                    int v198 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 110.0f) / ((float) myApplicationInterface0.DW));
                    int v199 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 120.0f) / ((float) myApplicationInterface0.DW));
                    if (bitmap0.getWidth()>bitmap0.getHeight()) {
                        int v200 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 100.0f) / ((float) myApplicationInterface0.DW));
                        int v201 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 110.0f) / ((float) myApplicationInterface0.DW));
                        int v202 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 140.0f) / ((float) myApplicationInterface0.DW));
                        int v203 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 150.0f) / ((float) myApplicationInterface0.DW));
                        int v204 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 145.0f) / ((float) myApplicationInterface0.DW));
                        int v205 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 153.0f) / ((float) myApplicationInterface0.DW));
                        int v206 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 155.0f) / ((float) myApplicationInterface0.DW));
                        int v207 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 45.0f) / ((float) myApplicationInterface0.DW));
                        int v208 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 50.0f) / ((float) myApplicationInterface0.DW));
                        int v209 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 60.0f) / ((float) myApplicationInterface0.DW));
                        v87 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 65.0f) / ((float) myApplicationInterface0.DW));
                        v88 = v201;
                        v90 = v202;
                        v94 = v176;
                        v95 = v177;
                        v96 = v178;
                        v91 = v203;
                        v92 = v204;
                        v97 = v183;
                        v99 = v184;
                        v100 = v185;
                        v101 = v186;
                        v93 = v205;
                        v102 = v206;
                        v103 = v207;
                        v104 = v208;
                        v89 = v209;
                        v106 = v199;
                        v105 = v198;
                        v98 = v182;
                        roundCorners1 = imgMap;
                        v107 = v200;
                        imageView10 = imgMagneticField;
                        v108 = v179;
                    } else {
                        roundCorners1 = imgMap;
                        imageView10 = imgMagneticField;
                        v94 = v176;
                        v95 = v177;
                        v96 = v178;
                        v108 = v179;
                        v87 = v197;
                        v88 = v188;
                        v97 = v183;
                        v99 = v184;
                        v100 = v185;
                        v101 = v186;
                        v107 = v187;
                        v90 = v189;
                        v93 = v192;
                        v91 = v190;
                        v92 = v191;
                        v102 = v193;
                        v103 = v194;
                        v104 = v195;
                        v89 = v196;
                        v106 = v199;
                        v105 = v198;
                        v98 = v182;
                    }

                    v109 = v180;
                }
            }

            if (myApplicationInterface0.isTablet) {
                float f1 = (float) v108;
                tv_weather.setTextSize(f1);
                tv_compass.setTextSize(f1);
                tv_magnetic_field.setTextSize(f1);
                txt_humidity.setTextSize(f1);
                txt_pressure.setTextSize(f1);
                txt_wind.setTextSize(f1);
                txt_watermark.setTextSize(f1);
                txt_watermark_2.setTextSize(f1);
            }
            else {
                float f2 = (float) v96;
                tv_weather.setTextSize(f2);
                tv_compass.setTextSize(f2);
                tv_magnetic_field.setTextSize(f2);
                txt_humidity.setTextSize(f2);
                txt_pressure.setTextSize(f2);
                txt_wind.setTextSize(f2);
                txt_watermark.setTextSize(f2);
                txt_watermark_2.setTextSize(f2);
            }

            LinearLayout.LayoutParams linearLayout$LayoutParams0 = new LinearLayout.LayoutParams(v107, v107);
            if (v == 0) {
                linearLayout$LayoutParams0.setMargins(0, 0, v97, 0);
                v210 = v98;
                v211 = v108;
                v212 = v107;
                roundCorners2 = roundCorners1;
                roundCorners2.setCornerRadius(((float) v210));
            }
            else {
                v212 = v107;
                roundCorners2 = roundCorners1;
                v210 = v98;
                v211 = v108;
                linearLayout$LayoutParams0.setMargins(0, 0, 0, 0);
                roundCorners2.setCornerRadius(0.0f);
            }

            linearLayout$LayoutParams0.gravity = 80;
            roundCorners2.setLayoutParams(linearLayout$LayoutParams0);
            imageView10.getLayoutParams().width = v100;
            imageView10.getLayoutParams().height = v100;
            imgCompass2.getLayoutParams().width = v100;
            imgCompass2.getLayoutParams().height = v100;
            img_stamp.getLayoutParams().width = v100;
            img_stamp_2.getLayoutParams().width = v100;
            img_stamp.getLayoutParams().height = v100;
            img_stamp_2.getLayoutParams().height = v100;
            img_humidity_stamp.getLayoutParams().width = v100;
            img_humidity_stamp.getLayoutParams().height = v100;
            img_wind_stamp.getLayoutParams().width = v100;
            img_wind_stamp.getLayoutParams().height = v100;
            img_pressure_stamp.getLayoutParams().width = v100;
            img_pressure_stamp.getLayoutParams().height = v100;
            lin_bottom_wather2.getLayoutParams().height = v100;
            if (v == 0) {
                linearLayout17 = li_main_stamp_lay2;
                linearLayout17.setPadding(v97, v97, v97, v97);
            }
            else {
                linearLayout17 = li_main_stamp_lay2;
                linearLayout17.setPadding(0, v97, 0, v97);
            }

            linearLayout18 = lin_waterma;
            linearLayout18.setPadding(v210, v210, v210, v210);
            lin_waterma_2.setPadding(v210, v210, v210, v210);
            LinearLayout linearLayout19 = lin_waterma_2;
            LinearLayout linearLayout20 = linearLayout18;
            int v213 = v95;
            tv_magnetic_field.setPadding(v213, 0, 0, 0);
            tv_compass.setPadding(v213, 0, 0, 0);
            txt_watermark.setPadding(v210, 0, v210, 0);
            txt_watermark_2.setPadding(v210, 0, v210, 0);
            tv_weather.setPadding(v213, 0, 0, 0);
            if (z5) {
                linearLayout16.setVisibility(View.VISIBLE);
                imgWeather.setImageResource(myApplicationInterface0.mWeatherIcon.getResourceId(v52, 0));
                imgWeather.getLayoutParams().width = v99;
                imgWeather.getLayoutParams().height = v99;
            } else {
                linearLayout16.setVisibility(View.GONE);
            }

            if (z12) {
                linearLayout21 = li_logo;
                linearLayout21.setVisibility(View.VISIBLE);
                v214 = v101;
                imgLogo.getLayoutParams().height = v214;
                textView11 = tv_compass;
                v215 = v89;
                imgLogo.getLayoutParams().width = v215;
            } else {
                textView11 = tv_compass;
                linearLayout21 = li_logo;
                v215 = v89;
                v214 = v101;
                linearLayout21.setVisibility(View.GONE);
            }

            if (!z14 && !z15 && !z16 && !z17 && !z19) {
                linearLayout22 = linearLayout21;
                linearLayout23 = lin_bottom_wather2;
                linearLayout23.setVisibility(View.GONE);
//                label_2888:
                textView12 = tv_magnetic_field;
            }
            else {
                linearLayout22 = linearLayout21;
                linearLayout23 = lin_bottom_wather2;
                linearLayout23.setVisibility(View.VISIBLE);
                if (myApplicationInterface0.isTablet) {
                    LinearLayout.LayoutParams linearLayout$LayoutParams1 = (LinearLayout.LayoutParams) linearLayout23.getLayoutParams();
                    textView12 = tv_magnetic_field;
                    ++linearLayout$LayoutParams1.height;
//                    label_2889:
                    if (z14) {
                        linearLayout24 = lin_humidity_stamp;
                        linearLayout24.setVisibility(View.VISIBLE);
                    } else {
                        linearLayout24 = lin_humidity_stamp;
                        linearLayout24.setVisibility(View.GONE);
                    }

                }

//                label_2888:
//                textView12 = tv_magnetic_field;
            }

//            label_2889:
//            if(z14) {
//                linearLayout24 = lin_humidity_stamp;
//                linearLayout24.setVisibility(View.VISIBLE);
//            }
//            else {
//                linearLayout24 = lin_humidity_stamp;
//                linearLayout24.setVisibility(View.GONE);
//            }

            if (z17) {
                linearLayout25 = lin_wind_stamp;
                textView13 = tv_weather;
                linearLayout25.setVisibility(View.VISIBLE);
            }
            else {
                linearLayout25 = lin_wind_stamp;
                textView13 = tv_weather;
                linearLayout25.setVisibility(View.GONE);
            }

            if (z19) {
                v216 = v;
                linearLayout26 = lin_pressure_stamp;
                linearLayout26.setVisibility(View.VISIBLE);
            }
            else {
                v216 = v;
                linearLayout26 = lin_pressure_stamp;
                linearLayout26.setVisibility(View.GONE);
            }

            if (z16) {
                linearLayout27 = linearLayout17;
                String s13 = Util.getAltitudeconvert(myApplicationInterface0.main_activity, v51);
                v217 = v210;
                if (linearLayout26.getVisibility() == 8) {
                    linearLayout26.setVisibility(View.VISIBLE);
                    imageView11 = img_pressure_stamp;
                    imageView11.setImageResource(R.drawable.ic_altitiude);  // drawable:ic_altitiude
                    txt_pressure.setText(s13);
                    txt_pressure.setTextColor(v50);
                    linearLayout28 = linearLayout23;
                    v218 = v215;
                    v219 = v214;
                    imageView12 = img_wind_stamp;
//                    label_2975:
                    imageView13 = img_humidity_stamp;
                } else {
                    int v220 = v50;
                    imageView11 = img_pressure_stamp;
                    v218 = v215;
                    linearLayout28 = linearLayout23;
                    if (linearLayout25.getVisibility() == 8) {
                        linearLayout25.setVisibility(View.VISIBLE);
                        imageView12 = img_wind_stamp;
                        imageView12.setImageResource(R.drawable.ic_altitiude);  // drawable:ic_altitiude
                        txt_wind.setText(s13);
                        txt_wind.setTextColor(v220);
                        v219 = v214;
                    } else {
                        imageView12 = img_wind_stamp;
                        v219 = v214;
                        if (linearLayout24.getVisibility() == 8) {
                            linearLayout24.setVisibility(View.VISIBLE);
                            imageView13 = img_humidity_stamp;
                            imageView13.setImageResource(R.drawable.ic_altitiude);  // drawable:ic_altitiude
                            txt_humidity.setText(s13);
                            txt_humidity.setTextColor(v220);
//                            label_2985:
                            if (z15) {
                                String s14 = Util.getAccuracy(myApplicationInterface0.main_activity, v49);
                                if (linearLayout26.getVisibility() == 8) {
                                    linearLayout26.setVisibility(View.VISIBLE);
                                    imageView11.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
                                    txt_pressure.setText(s14);
                                    txt_pressure.setTextColor(v48);
                                } else {
                                    int v221 = v48;
                                    if (linearLayout25.getVisibility() == 8) {
                                        linearLayout25.setVisibility(View.VISIBLE);
                                        imageView12.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
                                        txt_wind.setText(s14);
                                        txt_wind.setTextColor(v221);
                                    } else if (linearLayout24.getVisibility() == 8) {
                                        linearLayout24.setVisibility(View.VISIBLE);
                                        imageView13.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
                                        txt_humidity.setText(s14);
                                        txt_humidity.setTextColor(v221);
                                    }
                                }
                            }
                        }
                    }

//                    label_2975:
//                    imageView13 = img_humidity_stamp;
                }
            }
            else {
                linearLayout28 = linearLayout23;
                linearLayout27 = linearLayout17;
                v218 = v215;
                v217 = v210;
                v219 = v214;
                imageView12 = img_wind_stamp;
                imageView13 = img_humidity_stamp;
                imageView11 = img_pressure_stamp;
            }

//            label_2985:
//            if(z15) {
//                String s14 = Util.getAccuracy(myApplicationInterface0.main_activity, v49);
//                if(linearLayout26.getVisibility() == 8) {
//                    linearLayout26.setVisibility(View.VISIBLE);
//                    imageView11.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
//                    txt_pressure.setText(s14);
//                    txt_pressure.setTextColor(v48);
//                }
//                else {
//                    int v221 = v48;
//                    if(linearLayout25.getVisibility() == 8) {
//                        linearLayout25.setVisibility(View.VISIBLE);
//                        imageView12.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
//                        txt_wind.setText(s14);
//                        txt_wind.setTextColor(v221);
//                    }
//                    else if(linearLayout24.getVisibility() == 8) {
//                        linearLayout24.setVisibility(View.VISIBLE);
//                        imageView13.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
//                        txt_humidity.setText(s14);
//                        txt_humidity.setTextColor(v221);
//                    }
//                }
//            }

            if (z27) {
                if (z11) {
                    li_compass.setVisibility(View.VISIBLE);
                    RotateAnimation rotateAnimation0 = new RotateAnimation(-(myApplicationInterface0.main_activity.currentAzimuth + ((float) myApplicationInterface0.main_activity.degree)), -(myApplicationInterface0.main_activity.heading + ((float) myApplicationInterface0.main_activity.degree)), 1, 0.5f, 1, 0.5f);
                    rotateAnimation0.setDuration(500L);
                    rotateAnimation0.setFillAfter(true);
                    imgCompass2.startAnimation(rotateAnimation0);
                }
                else {
                    li_compass.setVisibility(View.GONE);
                }
                if (z10) {
                    li_magnetic_field.setVisibility(View.VISIBLE);
                } else {
                    li_magnetic_field.setVisibility(View.GONE);
                }
            }
            else {
                li_compass.setVisibility(View.GONE);
                li_magnetic_field.setVisibility(View.GONE);
            }

            if (!z5 && !z10 && !z11 && !z12) {
                linearLayout29 = li_rightView;
                linearLayout29.setVisibility(View.GONE);
            }
            else {
                linearLayout29 = li_rightView;
                linearLayout29.setVisibility(View.VISIBLE);
            }

            if (z22) {
                textView14 = textView6;
                if (!z8 && !z4) {
                    textView14.setMaxLines(10);
                } else {
                    textView14.setMaxLines(12);
                }
            } else if ((z21) || ((z5) || (z10) || (z11) || (z26) || !z23) && ((z5) || (z10) || (z11) || (z23) || !z26) && (!z5 && !z11 && !z10 || !z23 || (z26)) && (!z5 && !z11 && !z10 || (z23) || !z26)) {
                textView14 = textView6;
                if (!z8 && !z4) {
                    textView14.setMaxLines(10);
                } else {
                    textView14.setMaxLines(12);
                }
            }
            else if (!z23 && !z26 || !z13) {
                textView14 = textView6;
                if (!z8 && !z24 && !z4) {
                    textView14.setMaxLines(1);
                } else {
                    textView14.setMaxLines(3);
                }
            }
            else if (!z8 && !z4) {
                textView14 = textView6;
                textView14.setMaxLines(3);
            } else {
                textView14 = textView6;
                textView14.setMaxLines(5);
            }

            if ((z21) && myApplicationInterface0.main_activity.getMapBitmap() != null) {
                v222 = canvas0.getWidth() - (v212 + v109 * 3);
                if (z12) {
                    if (!z8 && !z4) {
                        System.out.println("TemplateCalled             2");
                        li_stamp.getLayoutParams().height = v92;
                        roundCorners2.getLayoutParams().height = v92;
                    } else {
                        System.out.println("TemplateCalled             1");
                        li_stamp.getLayoutParams().height = v102;
                        roundCorners2.getLayoutParams().height = v102;
                    }
                } else if (!z8 && !z4) {
                    System.out.println("TemplateCalled             5");
                    li_stamp.getLayoutParams().height = v212;
                    roundCorners2.getLayoutParams().height = v212;
                } else if (!z17 && !z15 && !z16 && !z14 && !z19) {
                    System.out.println("TemplateCalled             4");
                    li_stamp.getLayoutParams().height = v91;
                    roundCorners2.getLayoutParams().height = v91;
                } else {
                    System.out.println("TemplateCalled             3");
                    li_stamp.getLayoutParams().height = v93;
                    roundCorners2.getLayoutParams().height = v93;
                }

                linearLayout30 = li_stamp;
                int v223 = v211;
                linearLayout30.setPadding(v223, v213, v223, v213);
                roundCorners2.setVisibility(View.VISIBLE);
                roundCorners2.setImageBitmap(myApplicationInterface0.main_activity.getMapBitmap());
                imageView14 = imageView11;
                textView15 = txt_pressure;
                v224 = v103;
            } else {
                linearLayout30 = li_stamp;
                int v225 = v211;
                int v226 = v212;
                int v227 = v91;
                if (!z26 && !z22 && !z10 && !z11) {
                    if (z5) {
                        imageView14 = imageView11;
                        textView15 = txt_pressure;
                        v224 = v103;
//                        goto label_3321;
//                        label_3321:
                        roundCorners2.setVisibility(View.GONE);
                        int v232 = canvas0.getWidth() - v109 * 2;
                        if (z22) {
                            if (!z22 || (z26)) {
                                int v234 = v88;
                                if (!z8 && !z4) {
                                    System.out.println("TemplateCalled             19");
                                    linearLayout30.getLayoutParams().height = v226;
                                } else {
                                    System.out.println("TemplateCalled             18");
                                    linearLayout30.getLayoutParams().height = v234;
                                }
                            } else if (!z8 && !z4) {
                                System.out.println("TemplateCalled             17");
                                linearLayout30.getLayoutParams().height = v226;
                            } else {
                                System.out.println("TemplateCalled             16");
                                linearLayout30.getLayoutParams().height = v88;
                            }

                            linearLayout30.setPadding(v225, v213, v225, v213);
                        } else if (!z23 && !z26 || textView14.getMaxLines() == 1 && (!z11 && !z10 && !z5 || (z5) && !z11 && !z10 || (z11) && !z5 && !z10 || (z10) && !z5 && !z11)) {
                            if (linearLayout28.getVisibility() == 8 && !z11 && !z10 && !z5) {
                                if (((z23) || (z26)) && (z13)) {
                                    if (!z8 && !z4) {
                                        System.out.println("TemplateCalled             7");
                                        linearLayout30.getLayoutParams().height = v218;
                                    } else {
                                        System.out.println("TemplateCalled             6");
                                        linearLayout30.getLayoutParams().height = v87;
                                    }
                                } else if (!z8 && !z4) {
                                    System.out.println("TemplateCalled             9");
                                    linearLayout30.getLayoutParams().height = v224;
                                } else {
                                    System.out.println("TemplateCalled             8");
                                    linearLayout30.getLayoutParams().height = v104;
                                }
                            } else if (!z12) {
                                if (!z8 && !z4) {
                                    System.out.println("TemplateCalled             13");
                                } else {
                                    System.out.println("TemplateCalled             12");
                                }

                                linearLayout30.getLayoutParams().height = v105;
                            } else if (!z8 && !z4) {
                                System.out.println("TemplateCalled             11");
                                linearLayout30.getLayoutParams().height = v90;
                            } else {
                                System.out.println("TemplateCalled             10");
                                linearLayout30.getLayoutParams().height = v227;
                            }

                            linearLayout30.setPadding(v225, v225, v225, v225);
                        } else {
                            int v233 = v105;
                            if (!z8 && !z4) {
                                System.out.println("TemplateCalled             15");
                                linearLayout30.getLayoutParams().height = v233;
                            } else {
                                System.out.println("TemplateCalled             14");
                                linearLayout30.getLayoutParams().height = v106;
                            }

                            linearLayout30.setPadding(v225, v213, v225, v213);
                        }

                    }

                    int v228 = canvas0.getWidth() - v109 * 2;
                    roundCorners2.setVisibility(View.GONE);
                    if ((z8) || (z4)) {
                        int v231 = v219;
                        v230 = v103;
                        v229 = v228;
                        System.out.println("TemplateCalled             20");
                        if (!z12 && !z13 && !z8) {
                            linearLayout30.getLayoutParams().height = v231;
                        } else if (!z12 && !z13 && !z4) {
                            linearLayout30.getLayoutParams().height = v231;
                        } else {
                            linearLayout30.setPadding(v225, v225, v225, v225);
                        }
                    } else if (!z12 && !z13) {
                        System.out.println("TemplateCalled             21");
                        linearLayout30.getLayoutParams().height = v219;
                        linearLayout30.setPadding(v94, v94, v94, v94);
                        v229 = v228;
                        v230 = v103;
                    } else {
                        System.out.println("TemplateCalled             22");
                        v230 = v103;
                        linearLayout30.getLayoutParams().height = v230;
                        linearLayout30.setPadding(v225, v225, v225, v225);
                        v229 = v228;
                    }

                    imageView14 = imageView11;
                    v222 = v229;
                    v224 = v230;
                    textView15 = txt_pressure;
                } else {
                    imageView14 = imageView11;
                    v224 = v103;
                    textView15 = txt_pressure;
//                    label_3321:
                    roundCorners2.setVisibility(View.GONE);
                    int v232 = canvas0.getWidth() - v109 * 2;
                    if (z22) {
                        if (!z22 || (z26)) {
                            int v234 = v88;
                            if (!z8 && !z4) {
                                System.out.println("TemplateCalled             19");
                                linearLayout30.getLayoutParams().height = v226;
                            } else {
                                System.out.println("TemplateCalled             18");
                                linearLayout30.getLayoutParams().height = v234;
                            }
                        } else if (!z8 && !z4) {
                            System.out.println("TemplateCalled             17");
                            linearLayout30.getLayoutParams().height = v226;
                        } else {
                            System.out.println("TemplateCalled             16");
                            linearLayout30.getLayoutParams().height = v88;
                        }

                        linearLayout30.setPadding(v225, v213, v225, v213);
                    } else if (!z23 && !z26 || textView14.getMaxLines() == 1 && (!z11 && !z10 && !z5 || (z5) && !z11 && !z10 || (z11) && !z5 && !z10 || (z10) && !z5 && !z11)) {
                        if (linearLayout28.getVisibility() == 8 && !z11 && !z10 && !z5) {
                            if (((z23) || (z26)) && (z13)) {
                                if (!z8 && !z4) {
                                    System.out.println("TemplateCalled             7");
                                    linearLayout30.getLayoutParams().height = v218;
                                } else {
                                    System.out.println("TemplateCalled             6");
                                    linearLayout30.getLayoutParams().height = v87;
                                }
                            } else if (!z8 && !z4) {
                                System.out.println("TemplateCalled             9");
                                linearLayout30.getLayoutParams().height = v224;
                            } else {
                                System.out.println("TemplateCalled             8");
                                linearLayout30.getLayoutParams().height = v104;
                            }
                        } else if (!z12) {
                            if (!z8 && !z4) {
                                System.out.println("TemplateCalled             13");
                            } else {
                                System.out.println("TemplateCalled             12");
                            }

                            linearLayout30.getLayoutParams().height = v105;
                        } else if (!z8 && !z4) {
                            System.out.println("TemplateCalled             11");
                            linearLayout30.getLayoutParams().height = v90;
                        } else {
                            System.out.println("TemplateCalled             10");
                            linearLayout30.getLayoutParams().height = v227;
                        }

                        linearLayout30.setPadding(v225, v225, v225, v225);
                    } else {
                        int v233 = v105;
                        if (!z8 && !z4) {
                            System.out.println("TemplateCalled             15");
                            linearLayout30.getLayoutParams().height = v233;
                        } else {
                            System.out.println("TemplateCalled             14");
                            linearLayout30.getLayoutParams().height = v106;
                        }

                        linearLayout30.setPadding(v225, v213, v225, v213);
                    }

                    v222 = v232;
                }
            }

            int v235 = textView14.getMaxLines() == 1 && ((z5) || (z10) || (z11)) ? v217 : v217;
            textView14.setPadding(0, 0, v235, 0);
            if (!z22 && !z26 && !z23 && !z13 && !z17 && !z14 && !z15 && !z19 && !z16 && !z8 && !z24 && !z4) {
                linearLayout31 = li_address;
                linearLayout31.setVisibility(View.GONE);
                linearLayout29.setOrientation(0);
                linearLayout29.setGravity(17);
                linearLayout29.getLayoutParams().width = -1;
                linearLayout29.getLayoutParams().width = -1;
                if ((z12) && !z21) {
                    linearLayout30.getLayoutParams().height = v224;
                }
            } else {
                linearLayout31 = li_address;
                linearLayout31.setVisibility(View.VISIBLE);
                linearLayout31.setGravity(17);
                linearLayout29.setOrientation(1);
                linearLayout29.setGravity(17);
                linearLayout29.getLayoutParams().width = -2;
                linearLayout29.getLayoutParams().width = -2;
            }

            if (!z26 && !z22 && !z23 && !z13 && !z8 && !z24 && !z4) {
                textView14.setVisibility(View.GONE);
            } else {
                textView14.setVisibility(View.VISIBLE);
            }

            if (!z26 && !z22 && !z10 && !z5 && !z11 && !z23 && !z21 && !z13 && !z17 && !z14 && !z15 && !z19 && !z16 && !z12 && !z8 && !z24 && !z4) {
                linearLayout27.setVisibility(View.GONE);
            } else {
                linearLayout27.setVisibility(View.VISIBLE);
            }

            boolean z28 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_water_mark", true);
            if (z28) {
                if (v216 == 0) {
                    s15 = myApplicationInterface0.sharedPreferences.getString("stamp_pos", "Bottom");
                    if (s15.equals("Bottom")) {
                        linearLayout30.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.rect_grey_1));  // drawable:rect_grey_1
                    } else {
                        linearLayout30.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.rect_grey_3));  // drawable:rect_grey_3
                    }

                    linearLayout32 = linearLayout20;
                    linearLayout32.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.rect_grey_2));  // drawable:rect_grey_2
                    linearLayout33 = linearLayout19;
                    linearLayout33.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.rect_grey_4));  // drawable:rect_grey_4
                } else {
                    linearLayout32 = linearLayout20;
                    linearLayout33 = linearLayout19;
                    linearLayout30.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.classic_back));  // drawable:classic_back
                    linearLayout32.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.classic_back));  // drawable:classic_back
                    linearLayout33.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.classic_back));  // drawable:classic_back
                    s15 = myApplicationInterface0.sharedPreferences.getString("stamp_pos_classic", "Bottom");
                }

                if (s15.equals("Bottom")) {
                    linearLayout32.setVisibility(View.VISIBLE);
                    linearLayout33.setVisibility(View.GONE);
                    ((GradientDrawable) linearLayout30.getBackground().getCurrent()).setColor(v47);
                    ((GradientDrawable) linearLayout32.getBackground().getCurrent()).setColor(v47);
                } else {
                    linearLayout32.setVisibility(View.GONE);
                    linearLayout33.setVisibility(View.VISIBLE);
                    ((GradientDrawable) linearLayout30.getBackground().getCurrent()).setColor(v47);
                    ((GradientDrawable) linearLayout33.getBackground().getCurrent()).setColor(v47);
                }
            } else {
                int v236 = v47;
                linearLayout20.setVisibility(View.GONE);
                linearLayout19.setVisibility(View.GONE);
                if (v216 == 0) {
                    linearLayout30.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.rect_grey));  // drawable:rect_grey
                } else {
                    linearLayout30.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.classic_back));  // drawable:classic_back
                }

                GradientDrawable gradientDrawable0 = (GradientDrawable) linearLayout30.getBackground().getCurrent();
                if (v216 == 0) {
                    gradientDrawable0.setCornerRadius(((float) v235));
                }

                gradientDrawable0.setColor(v236);
            }

            TextView textView16 = textView13;
            textView16.setTextColor(v46);
            TextView textView17 = textView12;
            textView17.setTextColor(v45);
            textView17.setText(myApplicationInterface0.main_activity.getMagnaticFieldStr());
            TextView textView18 = textView11;
            textView18.setTextColor(v44);
            textView18.setText(myApplicationInterface0.main_activity.getCompassStr());
            if (z17) {
                txt_wind.setText(Util.getwindConvert(myApplicationInterface0.main_activity, v43));
                imageView12.setImageResource(R.drawable.ic_wind);  // drawable:ic_wind
                txt_wind.setTextColor(v35);
            }

            if (z14) {
                linearLayout34 = linearLayout29;
                linearLayout35 = linearLayout31;
                txt_humidity.setText(myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "Humidity_value", "") + "%");
                imageView13.setImageResource(R.drawable.ic_humidity);  // drawable:ic_humidity
                txt_humidity.setTextColor(v37);
            } else {
                linearLayout35 = linearLayout31;
                linearLayout34 = linearLayout29;
            }

            if (z19) {
                textView19 = textView15;
                textView19.setText(Util.getpressureConvert(myApplicationInterface0.main_activity, v41));
                imageView14.setImageResource(R.drawable.ic_pressure);  // drawable:ic_pressure
                textView19.setTextColor(v36);
            } else {
                textView19 = textView15;
            }

            LinearLayout.LayoutParams linearLayout$LayoutParams2 = new LinearLayout.LayoutParams(v222, linearLayout30.getLayoutParams().height);
            linearLayout$LayoutParams2.gravity = 17;
            linearLayout30.setLayoutParams(linearLayout$LayoutParams2);
            String s16 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "loc_address_line_1", "").trim();
            String s17 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "loc_city", "").trim();
            String s18 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "loc_state", "").trim();
            TextView textView20 = textView17;
            String s19 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "loc_country", "").trim();
            TextView textView21 = textView18;
            String s20 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "PLUS_CODE", "").trim();
            if (!s20.isEmpty() && (s12.equals("concise"))) {
                s20 = s20.substring(4);
            }

            String s21 = s17 == null || (s17.isEmpty()) ? "" : "" + s17 + ", ";
            if (s18 != null && !s18.isEmpty()) {
                s21 = s21 + "" + s18 + ", ";
            }

            if (s19 != null && !s19.isEmpty()) {
                s21 = s21 + s19;
            }

            if (s21 != null && (s21.endsWith(", "))) {
                s21 = s21.substring(0, s21.length() - 2);
            }

            if (s16 == null || (s16.isEmpty())) {
                s16 = "";
            }

            int v237 = v30;
            String s22 = myApplicationInterface0.main_activity.getColoredSpanned(s16, v237);
            String s23 = Util.getLatLong(myApplicationInterface0.main_activity, v40);
            TextView textView22 = textView19;
            String s24 = myApplicationInterface0.main_activity.getColoredSpanned(s23, v32);
            if ((z26) && s24 != null && v40 != 6 && v40 != 7 && s24.length()>55 && (z21) && !z10 && (z23) && !z5 && !z11) {
                String[] arr_s = s24.split(" Long");
                s24 = arr_s[0] + "<br/>Long " + arr_s[1];
            }

            if (z22) {
                if (z26) {
                    s22 = s22 + "<br/>" + s24;
                }
            } else if ((z26) && !z22) {
                s22 = s24;
            }

            if (z4) {
                String s25 = myApplicationInterface0.main_activity.getColoredSpanned("Plus Code : " + s20, v33);
                s22 = (z22) || (z26) ? s22 + "<br/>" + s25 : s25;
            }

            if (z23) {
                String s26 = Util.setDateTimeFormat(s4);
                v238 = v31;
                String s27 = myApplicationInterface0.main_activity.getColoredSpanned(s26, v238);
                s22 = !z22 && !z26 && !z4 ? s27 : s22 + "<br/>" + s27;
            } else {
                v238 = v31;
            }

            if (z24) {
                String s28 = myApplicationInterface0.getTimezone(v42);
                String s29 = myApplicationInterface0.main_activity.getColoredSpanned(s28, v238);
                if (z23) {
                    s22 = s22 + " " + s29;
                } else if (!z22 && !z26 && !z4) {
                    s22 = s29;
                } else {
                    s22 = s22 + "<br/>" + s29;
                }
            }

            if (z13) {
                if (v216 == 0) {
                    String s30 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "notes_hashtag", "Note : Captured by GPS Map Camera");
                    s31 = myApplicationInterface0.main_activity.getColoredSpanned(s30, v34);
                    textView23 = txt_wind;
                } else {
                    textView23 = txt_wind;
                    String s32 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "notes_hashtag_classic", "Note : Captured by GPS Map Camera");
                    s31 = myApplicationInterface0.main_activity.getColoredSpanned(s32, v34);
                }

                s22 = !z22 && !z26 && !z23 && !z24 && !z4 ? s31 : s22 + "<br/>" + s31;
            } else {
                textView23 = txt_wind;
            }

            if (z8) {
                String s33 = myApplicationInterface0.main_activity.getColoredSpanned(s10 + " " + v39 + " " + s11.trim(), v38);
                s22 = (z22) || (z26) || (z23) || (z24) || (z13) || (z4) ? s22 + "<br/>" + s33 : s33;
            }

            if (s22.contains("null")) {
                s22 = s22.replace("null", "");
            }

            textView14.setText(Html.fromHtml(s22));
            if (s21 != null && !s21.isEmpty() && (z22)) {
                textView24 = tv_address;
                textView24.setVisibility(View.VISIBLE);
                if (s21.contains("null")) {
                    s21 = s21.replace("null", "");
                }

                textView24.setText(Html.fromHtml(myApplicationInterface0.main_activity.getColoredSpanned(s21, v237)));
            } else {
                textView24 = tv_address;
                textView24.setVisibility(View.GONE);
            }

            if (s9.equals("Celsius")) {
                textView16.setText(Util.getCelcius(f));
            } else {
                textView16.setText(Util.getFahrenheit(f));
            }

            if ((z21) && !z22 && !z26 && !z23 && !z11 && !z10 && !z5 && !z13 && !z17 && !z14 && !z15 && !z19 && !z16 && !z12 && !z24 && !z8 && !z4) {
                linearLayout30.setVisibility(4);
            } else {
                linearLayout30.setVisibility(View.VISIBLE);
            }

            String s34 = s7;
            if (s34.equals("no_logo")) {
                imgLogo.setImageResource(R.mipmap.ic_launcher);  // mipmap:ic_launcher
            } else {
                imgLogo.setImageBitmap(Util.decodeBase64(s34));
            }

            String s35 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "template_type", 0) == 0 ? myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "stamp_font_style", "sfuitext_regular.otf") : myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "stamp_font_style_classic", "sfuitext_regular.otf");
            txt_humidity.setTypeface(Util.getFontStyle(myApplicationInterface0.main_activity, s35));
            textView23.setTypeface(Util.getFontStyle(myApplicationInterface0.main_activity, s35));
            textView22.setTypeface(Util.getFontStyle(myApplicationInterface0.main_activity, s35));
            textView14.setTypeface(Util.getFontStyle(myApplicationInterface0.main_activity, s35));
            textView24.setTypeface(Util.getFontStyle(myApplicationInterface0.main_activity, s35));
            textView16.setTypeface(Util.getFontStyle(myApplicationInterface0.main_activity, s35));
            textView21.setTypeface(Util.getFontStyle(myApplicationInterface0.main_activity, s35));
            textView20.setTypeface(Util.getFontStyle(myApplicationInterface0.main_activity, s35));
            Log.e("LLLLL", "--" + linearLayout35.getVisibility());
            Log.e("LLLLL", "--" + linearLayout34.getVisibility());
            Log.e("LLLLL", "--" + linearLayout30.getVisibility());
            Log.e("LLLLL", "--" + linearLayout22.getVisibility());
            myApplicationInterface0.stampBitmap = myApplicationInterface0.loadBitmapFromView(view1);
            String s36 = v216 == 0 ? myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "stamp_pos", "Bottom") : myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "stamp_pos_classic", "Bottom");

            Log.d("BITMAPPPP", ":::: " + myApplicationInterface0.stampBitmap.getWidth() + ":::" + myApplicationInterface0.stampBitmap.getHeight());
            float f3 = 0.0f;
            if (bitmap0 != null && myApplicationInterface0.stampBitmap != null) {
                if (s36.equals("Bottom")) {
                    if (v216 == 0) {
                        f4 = (float) canvas0.getHeight();
                        f5 = (float) myApplicationInterface0.stampBitmap.getHeight();
                    } else {
                        f4 = (float) canvas0.getHeight();
                        f5 = (float) myApplicationInterface0.stampBitmap.getHeight();
                        f3 = 50.0f;
                    }

                    f3 = f4 - (f5 + f3);
                }

                if (v216 == 0) {
                    float f6 = (float) (canvas0.getWidth() / 2 - myApplicationInterface0.stampBitmap.getWidth() / 2);
                    canvas0.drawBitmap(myApplicationInterface0.stampBitmap, f6, f3, paint0);
                } else {
                    Canvas canvas1 = canvas0;
                    Paint paint1 = paint0;
                    if (z21) {
                        f7 = (double) (canvas0.getWidth() / 2);
                        f8 = (double) myApplicationInterface0.stampBitmap.getWidth();
                        f9 = (double) myApplicationInterface0.stampBitmap.getWidth();
                        f10 = 2.17;
                    } else {
                        f7 = (double) (canvas0.getWidth() / 2);
                        f8 = (double) myApplicationInterface0.stampBitmap.getWidth();
                        f9 = (double) myApplicationInterface0.stampBitmap.getWidth();
                        f10 = 2.106;
                    }

                    float f11 = (float) (f7 - (f8 - f9 / f10));
                    canvas1.drawBitmap(Bitmap.createScaledBitmap(myApplicationInterface0.stampBitmap, canvas0.getWidth(), myApplicationInterface0.stampBitmap.getHeight() + 50, false), f11, f3, paint1);
                }

                myApplicationInterface0.stampBitmap.recycle();
                myApplicationInterface0.stampBitmap = null;
                System.gc();
            }

            if (z8) {
                if (v216 == 0) {
                    if (z25) {
                        if (myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "SEQUENCE", 1) == 0x3B9AC9FF) {
                            myApplicationInterface0.mSP.setInteger(myApplicationInterface0.main_activity, "SEQUENCE", 0);
                        }

                        SP sP2 = myApplicationInterface0.mSP;
                        int v239 = sP2.getInteger(myApplicationInterface0.main_activity, "SEQUENCE", 1) + 1;
                        sP2.setInteger(myApplicationInterface0.main_activity, "SEQUENCE", v239);
                        return bitmap0;
                    }

                    if (myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "SEQUENCE", 1) == 0xC4653601) {
                        myApplicationInterface0.mSP.setInteger(myApplicationInterface0.main_activity, "SEQUENCE", 0);
                    }

                    SP sP3 = myApplicationInterface0.mSP;
                    int v240 = sP3.getInteger(myApplicationInterface0.main_activity, "SEQUENCE", 1) - 1;
                    sP3.setInteger(myApplicationInterface0.main_activity, "SEQUENCE", v240);
                    return bitmap0;
                }

                if (z25) {
                    if (myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", 1) == 0x3B9AC9FF) {
                        myApplicationInterface0.mSP.setInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", 0);
                    }

                    SP sP4 = myApplicationInterface0.mSP;
                    int v241 = sP4.getInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", 1) + 1;
                    sP4.setInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", v241);
                    return bitmap0;
                }

                if (myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", 1) == 0xC4653601) {
                    myApplicationInterface0.mSP.setInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", 0);
                }

                SP sP5 = myApplicationInterface0.mSP;
                int v242 = sP5.getInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", 1) - 1;
                sP5.setInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", v242);
                return bitmap0;
            }
        } catch (OutOfMemoryError outOfMemoryError0) {
            outOfMemoryError0.printStackTrace();
            return null;
        }

        return bitmap0;
    }


//    public Bitmap capturedStampBitmap(ImageSaver.Request imageSaver$Request0, Canvas
//            canvas0, Paint paint0, Bitmap bitmap0) {
//        double f10;
//        double f9;
//        double f8;
//        double f7;
//        float f5;
//        float f4;
//        TextView textView24;
//        TextView textView23;
//        String s31;
//        int v238;
//        TextView textView19;
//        LinearLayout linearLayout35;
//        LinearLayout linearLayout34;
//        LinearLayout linearLayout33;
//        LinearLayout linearLayout32;
//        String s15;
//        LinearLayout linearLayout31;
//        int v230;
//        int v229;
//        int v224;
//        TextView textView15;
//        ImageView imageView14;
//        LinearLayout linearLayout30;
//        int v222;
//        TextView textView14;
//        LinearLayout linearLayout29;
//        ImageView imageView13 = null;
//        ImageView imageView12;
//        int v219;
//        int v218;
//        LinearLayout linearLayout28;
//        ImageView imageView11;
//        int v217;
//        LinearLayout linearLayout27;
//        LinearLayout linearLayout26;
//        int v216;
//        TextView textView13;
//        LinearLayout linearLayout25;
//        LinearLayout linearLayout24 = null;
//        TextView textView12 = null;
//        LinearLayout linearLayout23;
//        LinearLayout linearLayout22;
//        int v215;
//        TextView textView11;
//        int v214;
//        LinearLayout linearLayout21;
//        LinearLayout linearLayout18;
//        LinearLayout linearLayout17;
//        RoundCorners roundCorners2;
//        int v212;
//        int v211;
//        int v210;
//        int v109;
//        int v108;
//        int v107;
//        RoundCorners roundCorners1;
//        int v106;
//        int v105;
//        int v104;
//        int v103;
//        int v102;
//        int v101;
//        int v100;
//        int v99;
//        int v98;
//        int v97;
//        int v96;
//        int v95;
//        int v94;
//        int v93;
//        int v92;
//        int v91;
//        int v90;
//        int v89;
//        int v88;
//        ImageView imageView10;
//        int v87;
//        LinearLayout linearLayout16;
//        String s6;
//        int v26;
//        int v25;
//        int v24;
//        int v23;
//        int v22;
//        float f;
//        String s5;
//        int v21;
//        String s4;
//        int v20;
//        String s3;
//        String s2;
//        int v19;
//        int v16;
//        int v15;
//        int v14;
//        int v13;
//        int v12;
//        int v11;
//        int v10;
//        int v9;
//        int v8;
//        int v7;
//        int v6;
//        int v5;
//        int v4;
//        int v3;
//        int v2;
//        boolean z19;
//        boolean z17;
//        boolean z16;
//        boolean z15;
//        boolean z14;
//        String s1;
//        String s;
//        boolean z13;
//        boolean z12;
//        boolean z11;
//        boolean z10;
//        boolean z9;
//        boolean z8;
//        boolean z7;
//        boolean z6;
//        boolean z5;
//        boolean z4;
//        boolean z3;
//        boolean z2;
//        boolean z1;
//        MyApplicationInterface myApplicationInterface0 = this;
//        Log.e("LALU", "capturedStampBitmap: ");
//        myApplicationInterface0.orginalImage = bitmap0.copy(bitmap0.getConfig(), true);
//        if (new SP(myApplicationInterface0.main_activity).getBoolean(myApplicationInterface0.main_activity, "is_original_image", false)) {
//            Bitmap bitmap1 = myApplicationInterface0.orginalImage;
//            if (bitmap1 != null) {
//                myApplicationInterface0.storeImage(imageSaver$Request0, bitmap1);
//            }
//        }
//
//        try {
//            int v = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "template_type", 0);
//            boolean z = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "compass_found", false);
//            if (v == 0) {
//                z1 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_map", true);
//                z2 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_address", true);
//                z3 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_lat_lng_template", true);
//                z4 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_plus_code", false);
//                z5 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_weather", false);
//                z6 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_date_time", true);
//                z7 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_timezone", true);
//                z8 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_numbering", false);
//                z9 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_increment", true);
//                z10 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_magnetic_field", false);
//                z11 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_compass", false);
//                z12 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_logo", false);
//                z13 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_notes", false);
//                s = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "stamp_size", "Medium");
//                s1 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "plusCodeType", "accurate");
//                z14 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_humidity", false);
//                z15 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_accuracy", false);
//                z16 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_altitude", false);
//                z17 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_wind", false);
//                boolean z18 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_pressure", false);
//                SP sP0 = myApplicationInterface0.mSP;
//                z19 = z18;
//                int v1 = Color.parseColor("#9c000000");
//                v2 = sP0.getInteger(myApplicationInterface0.main_activity, "BACKGROUND_COLOR", v1);
//                v3 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "WEATHER_COLOR", -1);
//                v4 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "MAGNETIC_FIELD_COLOR", -1);
//                v5 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "COMPASS_COLOR", -1);
//                v6 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "ADDRESS_COLOR", -1);
//                v7 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "DATE_TIME_COLOR", -1);
//                v8 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "LAT_LNG_COLOR", -1);
//                v9 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "PLUS_CODE_COLOR", -1);
//                v10 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "NOTES_HASHTAG_COLOR", -1);
//                v11 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "WIND_COLOR", -1);
//                v12 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "PRESSURE_COLOR", -1);
//                v13 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "HUMIDITY_COLOR", -1);
//                v14 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "ALTITUDE_COLOR", -1);
//                v15 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "ACCURACY_COLOR", -1);
//                v16 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "NUMBERING_COLOR", -1);
//                int v17 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "TIME_ZONE", 6);
//                int v18 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "SEQUENCE", 1);
//                v19 = v17;
//                s2 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "PREFIX", "");
//                s3 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "SUFFIX", "");
//                v20 = v18;
//                s4 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "date_format", "dd/MM/yy hh:mm a");
//                v21 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "lat_lng_type_1", 1);
//                s5 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "temprature_type", "Celsius");
//                f = myApplicationInterface0.mSP.getFloat(myApplicationInterface0.main_activity, "temprature_value");
//                v22 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "weather_icon", 0);
//                v23 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "wind_select", 0);
//                v24 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "pressure_select", 0);
//                v25 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "altitude_select", 0);
//                v26 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "accuracy_select", 0);
//                s6 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "logo_uri", "no_logo");
//            }
//            else {
//                z1 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_map_classic", true);
//                z2 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_address_classic", true);
//                z3 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_lat_lng_template_classic", true);
//                z4 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_plus_code_classic", false);
//                z5 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_weather_classic", false);
//                z6 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_date_time_classic", true);
//                z7 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_timezone_classic", true);
//                z8 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_numbering_classic", false);
//                z9 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_increment_classic", true);
//                z10 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_magnetic_field_classic", false);
//                z11 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_compass_classic", false);
//                z12 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_logo_classic", false);
//                z13 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_notes_classic", false);
//                s = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "stamp_size_classic", "Medium");
//                s1 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "stamp_size_classic", "accurate");
//                z14 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_humidity_classic", false);
//                z15 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_accuracy_classic", false);
//                z16 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_altitude_classic", false);
//                z17 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_wind_classic", false);
//                boolean z20 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_pressure_classic", false);
//                SP sP1 = myApplicationInterface0.mSP;
//                z19 = z20;
//                int v27 = Color.parseColor("#9c000000");
//                v2 = sP1.getInteger(myApplicationInterface0.main_activity, "BACKGROUND_COLOR_CLASSIC", v27);
//                v3 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "WEATHER_COLOR_CLASSIC", -1);
//                v4 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "MAGNETIC_FIELD_COLOR_CLASSIC", -1);
//                v5 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "COMPASS_COLOR_CLASSIC", -1);
//                v6 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "ADDRESS_COLOR_CLASSIC", -1);
//                v7 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "DATE_TIME_COLOR_CLASSIC", -1);
//                v8 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "LAT_LNG_COLOR_CLASSIC", -1);
//                v9 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "PLUS_CODE_COLOR_CLASSIC", -1);
//                v10 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "NOTES_HASHTAG_COLOR_CLASSIC", -1);
//                v11 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "WIND_COLOR_CLASSIC", -1);
//                v12 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "PRESSURE_COLOR_CLASSIC", -1);
//                v13 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "HUMIDITY_COLOR_CLASSIC", -1);
//                v14 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "ALTITUDE_COLOR_CLASSIC", -1);
//                v15 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "ACCURACY_COLOR_CLASSIC", -1);
//                v16 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "NUMBERING_COLOR_CLASSIC", -1);
//                int v28 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "TIME_ZONE_CLASSIC", 6);
//                int v29 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", 1);
//                v19 = v28;
//                s2 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "PREFIX_CLASSIC", "");
//                s3 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "SUFFIX_CLASSIC", "");
//                v20 = v29;
//                s4 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "date_format_classic", "dd/MM/yy hh:mm a");
//                v21 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "lat_lng_type_1_classic", 1);
//                s5 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "temprature_type_classic", "Celsius");
//                f = myApplicationInterface0.mSP.getFloat(myApplicationInterface0.main_activity, "temprature_value");
//                v22 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "weather_icon", 0);
//                v23 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "wind_select_classic", 0);
//                v24 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "pressure_select_classic", 0);
//                v25 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "altitude_select_classic", 0);
//                v26 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "accuracy_select_classic", 0);
//                s6 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "logo_uri_classic", "no_logo");
//            }
//
//            String s7 = s6;
//            String s8 = s;
//            int v30 = v6;
//            int v31 = v7;
//            int v32 = v8;
//            int v33 = v9;
//            int v34 = v10;
//            int v35 = v11;
//            int v36 = v12;
//            int v37 = v13;
//            int v38 = v16;
//            int v39 = v20;
//            int v40 = v21;
//            String s9 = s5;
//            int v41 = v24;
//            boolean z21 = z1;
//            boolean z22 = z2;
//            boolean z23 = z6;
//            boolean z24 = z7;
//            boolean z25 = z9;
//            String s10 = s2;
//            String s11 = s3;
//            String s12 = s1;
//            boolean z26 = z3;
//            int v42 = v19;
//            int v43 = v23;
//            int v44 = v5;
//            View view0 = ((LayoutInflater) myApplicationInterface0.main_activity.getSystemService("layout_inflater")).inflate(R.layout.stamp_layout_save, null);  // layout:stamp_layout_save
//            TextView textView0 = (TextView) view0.findViewById(R.id.tv_address_line_1);  // id:tv_address_line_1
//            TextView textView1 = (TextView) view0.findViewById(R.id.tv_address);  // id:tv_address
//            TextView textView2 = (TextView) view0.findViewById(R.id.tv_weather);  // id:tv_weather
//            int v45 = v4;
//            TextView textView3 = (TextView) view0.findViewById(R.id.tv_compass);  // id:tv_compass
//            int v46 = v3;
//            TextView textView4 = (TextView) view0.findViewById(R.id.txt_watermark);  // id:txt_watermark
//            int v47 = v2;
//            TextView textView5 = (TextView) view0.findViewById(R.id.txt_watermark_2);  // id:txt_watermark_2
//            TextView textView6 = textView0;
//            TextView textView7 = (TextView) view0.findViewById(R.id.tv_magnetic_field);  // id:tv_magnetic_field
//            boolean z27 = z;
//            TextView textView8 = (TextView) view0.findViewById(R.id.txt_wind);  // id:txt_wind
//            int v48 = v15;
//            TextView textView9 = (TextView) view0.findViewById(R.id.txt_humidity);  // id:txt_humidity
//            int v49 = v26;
//            TextView textView10 = (TextView) view0.findViewById(R.id.txt_pressure);  // id:txt_pressure
//            int v50 = v14;
//            RoundCorners roundCorners0 = (RoundCorners) view0.findViewById(R.id.imgMap);  // id:imgMap
//            int v51 = v25;
//            LinearLayout linearLayout0 = (LinearLayout) view0.findViewById(R.id.li_main_stamp_lay);  // id:li_main_stamp_lay
//            int v52 = v22;
//            LinearLayout linearLayout1 = (LinearLayout) view0.findViewById(R.id.li_stamp);  // id:li_stamp
//            LinearLayout linearLayout2 = (LinearLayout) view0.findViewById(R.id.lin_waterma);  // id:lin_waterma
//            LinearLayout linearLayout3 = (LinearLayout) view0.findViewById(R.id.lin_waterma_2);  // id:lin_waterma_2
//            LinearLayout linearLayout4 = (LinearLayout) view0.findViewById(R.id.li_compass);  // id:li_compass
//            LinearLayout linearLayout5 = (LinearLayout) view0.findViewById(R.id.li_logo);  // id:li_logo
//            LinearLayout linearLayout6 = (LinearLayout) view0.findViewById(R.id.lin_bottom_wather);  // id:lin_bottom_wather
//            LinearLayout linearLayout7 = linearLayout0;
//            LinearLayout linearLayout8 = (LinearLayout) view0.findViewById(R.id.lin_wind_stamp);  // id:lin_wind_stamp
//            LinearLayout linearLayout9 = (LinearLayout) view0.findViewById(R.id.lin_humidity_stamp);  // id:lin_humidity_stamp
//            LinearLayout linearLayout10 = (LinearLayout) view0.findViewById(R.id.lin_pressure_stamp);  // id:lin_pressure_stamp
//            ImageView imageView0 = (ImageView) view0.findViewById(R.id.imgCompass);  // id:imgCompass
//            LinearLayout linearLayout11 = linearLayout6;
//            ImageView imageView1 = (ImageView) view0.findViewById(R.id.img_stamp);  // id:img_stamp
//            ImageView imageView2 = (ImageView) view0.findViewById(R.id.img_stamp_2);  // id:img_stamp_2
//            ImageView imageView3 = (ImageView) view0.findViewById(R.id.imgWeather);  // id:imgWeather
//            ImageView imageView4 = (ImageView) view0.findViewById(R.id.imgMagneticField);  // id:imgMagneticField
//            ImageView imageView5 = imageView0;
//            ImageView imageView6 = (ImageView) view0.findViewById(R.id.imgLogo);  // id:imgLogo
//            ImageView imageView7 = (ImageView) view0.findViewById(R.id.img_wind_stamp);  // id:img_wind_stamp
//            ImageView imageView8 = (ImageView) view0.findViewById(R.id.img_humidity_stamp);  // id:img_humidity_stamp
//            ImageView imageView9 = (ImageView) view0.findViewById(R.id.img_pressure_stamp);  // id:img_pressure_stamp
//            LinearLayout linearLayout12 = (LinearLayout) view0.findViewById(R.id.li_rightView);  // id:li_rightView
//            LinearLayout linearLayout13 = (LinearLayout) view0.findViewById(R.id.li_address);  // id:li_address
//            LinearLayout linearLayout14 = (LinearLayout) view0.findViewById(R.id.li_magnetic_field);  // id:li_magnetic_field
//            LinearLayout linearLayout15 = (LinearLayout) view0.findViewById(R.id.li_weather);  // id:li_weather
//            View view1 = view0;
//            if (s8.equals("Large")) {
//                linearLayout16 = linearLayout15;
//                int v53 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 6.0f) / ((float) myApplicationInterface0.DW));
//                int v54 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 8.0f) / ((float) myApplicationInterface0.DW));
//                int v55 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 10.0f) / ((float) myApplicationInterface0.DW));
//                int v56 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 12.0f) / ((float) myApplicationInterface0.DW));
//                int v57 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 18.0f) / ((float) myApplicationInterface0.DW));
//                int v58 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 16.0f) / ((float) myApplicationInterface0.DW));
//                int v59 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 4.0f) / ((float) myApplicationInterface0.DW));
//                bitmap0.getWidth();
//                int v60 = v59;
//                int v61 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 36.0f) / ((float) myApplicationInterface0.DW));
//                int v62 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 30.0f) / ((float) myApplicationInterface0.DW));
//                int v63 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 60.0f) / ((float) myApplicationInterface0.DW));
//                int v64 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 200.0f) / ((float) myApplicationInterface0.DW));
//                int v65 = v63;
//                int v66 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 210.0f) / ((float) myApplicationInterface0.DW));
//                int v67 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 240.0f) / ((float) myApplicationInterface0.DW));
//                int v68 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 250.0f) / ((float) myApplicationInterface0.DW));
//                int v69 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 243.0f) / ((float) myApplicationInterface0.DW));
//                int v70 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 253.0f) / ((float) myApplicationInterface0.DW));
//                int v71 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 255.0f) / ((float) myApplicationInterface0.DW));
//                int v72 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 130.0f) / ((float) myApplicationInterface0.DW));
//                int v73 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 140.0f) / ((float) myApplicationInterface0.DW));
//                int v74 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 155.0f) / ((float) myApplicationInterface0.DW));
//                int v75 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 160.0f) / ((float) myApplicationInterface0.DW));
//                int v76 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 170.0f) / ((float) myApplicationInterface0.DW));
//                int v77 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 180.0f) / ((float) myApplicationInterface0.DW));
//                if (bitmap0.getWidth()>bitmap0.getHeight()) {
//                    v64 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 170.0f) / ((float) myApplicationInterface0.DW));
//                    int v78 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 180.0f) / ((float) myApplicationInterface0.DW));
//                    int v79 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 210.0f) / ((float) myApplicationInterface0.DW));
//                    int v80 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 220.0f) / ((float) myApplicationInterface0.DW));
//                    int v81 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 213.0f) / ((float) myApplicationInterface0.DW));
//                    int v82 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 223.0f) / ((float) myApplicationInterface0.DW));
//                    int v83 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 225.0f) / ((float) myApplicationInterface0.DW));
//                    int v84 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 80.0f) / ((float) myApplicationInterface0.DW));
//                    int v85 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 85.0f) / ((float) myApplicationInterface0.DW));
//                    int v86 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 105.0f) / ((float) myApplicationInterface0.DW));
//                    v87 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 110.0f) / ((float) myApplicationInterface0.DW));
//                    imageView10 = imageView4;
//                    v88 = v78;
//                    v89 = v86;
//                    v90 = v79;
//                    v91 = v80;
//                    v92 = v81;
//                    v93 = v82;
//                    v94 = v53;
//                    v95 = v54;
//                    v96 = v55;
//                    v97 = v58;
//                    v98 = v60;
//                    v99 = v61;
//                    v100 = v62;
//                    v101 = v65;
//                    v102 = v83;
//                    v103 = v84;
//                    v104 = v85;
//                } else {
//                    imageView10 = imageView4;
//                    v89 = v74;
//                    v103 = v72;
//                    v87 = v75;
//                    v94 = v53;
//                    v95 = v54;
//                    v96 = v55;
//                    v97 = v58;
//                    v98 = v60;
//                    v99 = v61;
//                    v100 = v62;
//                    v101 = v65;
//                    v88 = v66;
//                    v90 = v67;
//                    v91 = v68;
//                    v92 = v69;
//                    v93 = v70;
//                    v102 = v71;
//                    v104 = v73;
//                }
//
//                v105 = v76;
//                v106 = v77;
//                roundCorners1 = roundCorners0;
//                v107 = v64;
//                v108 = v56;
//                v109 = v57;
//            }
//            else {
//                linearLayout16 = linearLayout15;
//                if (s8.equals("Medium")) {
//                    int v110 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 4.0f) / ((float) myApplicationInterface0.DW));
//                    int v111 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 6.0f) / ((float) myApplicationInterface0.DW));
//                    int v112 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 8.0f) / ((float) myApplicationInterface0.DW));
//                    int v113 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 10.0f) / ((float) myApplicationInterface0.DW));
//                    v109 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 16.0f) / ((float) myApplicationInterface0.DW));
//                    int v114 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 14.0f) / ((float) myApplicationInterface0.DW));
//                    int v115 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 2.0f) / ((float) myApplicationInterface0.DW));
//                    bitmap0.getWidth();
//                    int v116 = v114;
//                    int v117 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 33.0f) / ((float) myApplicationInterface0.DW));
//                    int v118 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 30.0f) / ((float) myApplicationInterface0.DW));
//                    int v119 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 55.0f) / ((float) myApplicationInterface0.DW));
//                    int v120 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 170.0f) / ((float) myApplicationInterface0.DW));
//                    int v121 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 180.0f) / ((float) myApplicationInterface0.DW));
//                    int v122 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 200.0f) / ((float) myApplicationInterface0.DW));
//                    int v123 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 210.0f) / ((float) myApplicationInterface0.DW));
//                    int v124 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 195.0f) / ((float) myApplicationInterface0.DW));
//                    int v125 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 215.0f) / ((float) myApplicationInterface0.DW));
//                    int v126 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 210.0f) / ((float) myApplicationInterface0.DW));
//                    int v127 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 114.0f) / ((float) myApplicationInterface0.DW));
//                    int v128 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 120.0f) / ((float) myApplicationInterface0.DW));
//                    int v129 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 125.0f) / ((float) myApplicationInterface0.DW));
//                    int v130 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 140.0f) / ((float) myApplicationInterface0.DW));
//                    int v131 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 160.0f) / ((float) myApplicationInterface0.DW));
//                    int v132 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 170.0f) / ((float) myApplicationInterface0.DW));
//                    if (bitmap0.getWidth()>bitmap0.getHeight()) {
//                        int v133 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 150.0f) / ((float) myApplicationInterface0.DW));
//                        int v134 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 160.0f) / ((float) myApplicationInterface0.DW));
//                        int v135 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 190.0f) / ((float) myApplicationInterface0.DW));
//                        int v136 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 200.0f) / ((float) myApplicationInterface0.DW));
//                        int v137 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 195.0f) / ((float) myApplicationInterface0.DW));
//                        int v138 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 203.0f) / ((float) myApplicationInterface0.DW));
//                        int v139 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 205.0f) / ((float) myApplicationInterface0.DW));
//                        int v140 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 80.0f) / ((float) myApplicationInterface0.DW));
//                        int v141 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 85.0f) / ((float) myApplicationInterface0.DW));
//                        int v142 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 90.0f) / ((float) myApplicationInterface0.DW));
//                        v87 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 100.0f) / ((float) myApplicationInterface0.DW));
//                        v94 = v110;
//                        v90 = v135;
//                        v88 = v134;
//                        v106 = v132;
//                        v91 = v136;
//                        v92 = v137;
//                        v101 = v119;
//                        v95 = v111;
//                        v96 = v112;
//                        v97 = v116;
//                        v99 = v117;
//                        v100 = v118;
//                        v93 = v138;
//                        v102 = v139;
//                        v103 = v140;
//                        v104 = v141;
//                        v89 = v142;
//                        v105 = v131;
//                        v98 = v115;
//                        imageView10 = imageView4;
//                        v108 = v113;
//                        roundCorners1 = roundCorners0;
//                        v107 = v133;
//                    } else {
//                        v94 = v110;
//                        v87 = v130;
//                        v88 = v121;
//                        v89 = v129;
//                        v106 = v132;
//                        v101 = v119;
//                        v95 = v111;
//                        v96 = v112;
//                        v97 = v116;
//                        v99 = v117;
//                        v100 = v118;
//                        v90 = v122;
//                        v93 = v125;
//                        v91 = v123;
//                        v92 = v124;
//                        v102 = v126;
//                        v103 = v127;
//                        v104 = v128;
//                        v105 = v131;
//                        roundCorners1 = roundCorners0;
//                        v98 = v115;
//                        imageView10 = imageView4;
//                        v108 = v113;
//                        v107 = v120;
//                    }
//                }
//                else if (s8.equals("Small")) {
//                    int v143 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 3.0f) / ((float) myApplicationInterface0.DW));
//                    int v144 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 5.0f) / ((float) myApplicationInterface0.DW));
//                    int v145 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 7.0f) / ((float) myApplicationInterface0.DW));
//                    int v146 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 9.0f) / ((float) myApplicationInterface0.DW));
//                    v109 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 15.0f) / ((float) myApplicationInterface0.DW));
//                    int v147 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 13.0f) / ((float) myApplicationInterface0.DW));
//                    int v148 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 2.0f) / ((float) myApplicationInterface0.DW));
//                    bitmap0.getWidth();
//                    int v149 = v147;
//                    int v150 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 32.0f) / ((float) myApplicationInterface0.DW));
//                    int v151 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 28.0f) / ((float) myApplicationInterface0.DW));
//                    int v152 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 50.0f) / ((float) myApplicationInterface0.DW));
//                    int v153 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 160.0f) / ((float) myApplicationInterface0.DW));
//                    int v154 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 170.0f) / ((float) myApplicationInterface0.DW));
//                    int v155 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 190.0f) / ((float) myApplicationInterface0.DW));
//                    int v156 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 200.0f) / ((float) myApplicationInterface0.DW));
//                    int v157 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 185.0f) / ((float) myApplicationInterface0.DW));
//                    int v158 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 205.0f) / ((float) myApplicationInterface0.DW));
//                    int v159 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 200.0f) / ((float) myApplicationInterface0.DW));
//                    int v160 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 104.0f) / ((float) myApplicationInterface0.DW));
//                    int v161 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 110.0f) / ((float) myApplicationInterface0.DW));
//                    int v162 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 115.0f) / ((float) myApplicationInterface0.DW));
//                    int v163 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 130.0f) / ((float) myApplicationInterface0.DW));
//                    int v164 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 150.0f) / ((float) myApplicationInterface0.DW));
//                    int v165 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 160.0f) / ((float) myApplicationInterface0.DW));
//                    if (bitmap0.getWidth()>bitmap0.getHeight()) {
//                        int v166 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 140.0f) / ((float) myApplicationInterface0.DW));
//                        int v167 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 150.0f) / ((float) myApplicationInterface0.DW));
//                        int v168 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 180.0f) / ((float) myApplicationInterface0.DW));
//                        int v169 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 190.0f) / ((float) myApplicationInterface0.DW));
//                        int v170 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 185.0f) / ((float) myApplicationInterface0.DW));
//                        int v171 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 193.0f) / ((float) myApplicationInterface0.DW));
//                        int v172 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 195.0f) / ((float) myApplicationInterface0.DW));
//                        int v173 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 70.0f) / ((float) myApplicationInterface0.DW));
//                        int v174 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 75.0f) / ((float) myApplicationInterface0.DW));
//                        int v175 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 85.0f) / ((float) myApplicationInterface0.DW));
//                        v87 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 90.0f) / ((float) myApplicationInterface0.DW));
//                        v98 = v148;
//                        v88 = v167;
//                        v94 = v143;
//                        v90 = v168;
//                        v91 = v169;
//                        v106 = v165;
//                        v92 = v170;
//                        v101 = v152;
//                        v95 = v144;
//                        v96 = v145;
//                        v108 = v146;
//                        v97 = v149;
//                        v99 = v150;
//                        v100 = v151;
//                        v93 = v171;
//                        v102 = v172;
//                        v103 = v173;
//                        v104 = v174;
//                        v89 = v175;
//                        v105 = v164;
//                        roundCorners1 = roundCorners0;
//                        v107 = v166;
//                    } else {
//                        roundCorners1 = roundCorners0;
//                        v98 = v148;
//                        v87 = v163;
//                        v94 = v143;
//                        v90 = v155;
//                        v103 = v160;
//                        v106 = v165;
//                        v101 = v152;
//                        v95 = v144;
//                        v96 = v145;
//                        v108 = v146;
//                        v97 = v149;
//                        v99 = v150;
//                        v100 = v151;
//                        v107 = v153;
//                        v88 = v154;
//                        v93 = v158;
//                        v91 = v156;
//                        v92 = v157;
//                        v102 = v159;
//                        v104 = v161;
//                        v89 = v162;
//                        v105 = v164;
//                    }
//
//                    imageView10 = imageView4;
//                }
//                else {
//                    int v176 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 2.0f) / ((float) myApplicationInterface0.DW));
//                    int v177 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 3.0f) / ((float) myApplicationInterface0.DW));
//                    int v178 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 5.0f) / ((float) myApplicationInterface0.DW));
//                    int v179 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 7.0f) / ((float) myApplicationInterface0.DW));
//                    int v180 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 10.0f) / ((float) myApplicationInterface0.DW));
//                    int v181 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 8.0f) / ((float) myApplicationInterface0.DW));
//                    int v182 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 2.0f) / ((float) myApplicationInterface0.DW));
//                    bitmap0.getWidth();
//                    int v183 = v181;
//                    int v184 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 27.0f) / ((float) myApplicationInterface0.DW));
//                    int v185 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 23.0f) / ((float) myApplicationInterface0.DW));
//                    int v186 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 42.0f) / ((float) myApplicationInterface0.DW));
//                    int v187 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 120.0f) / ((float) myApplicationInterface0.DW));
//                    int v188 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 130.0f) / ((float) myApplicationInterface0.DW));
//                    int v189 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 150.0f) / ((float) myApplicationInterface0.DW));
//                    int v190 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 160.0f) / ((float) myApplicationInterface0.DW));
//                    int v191 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 145.0f) / ((float) myApplicationInterface0.DW));
//                    int v192 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 165.0f) / ((float) myApplicationInterface0.DW));
//                    int v193 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 160.0f) / ((float) myApplicationInterface0.DW));
//                    int v194 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 65.0f) / ((float) myApplicationInterface0.DW));
//                    int v195 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 70.0f) / ((float) myApplicationInterface0.DW));
//                    int v196 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 75.0f) / ((float) myApplicationInterface0.DW));
//                    int v197 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 90.0f) / ((float) myApplicationInterface0.DW));
//                    int v198 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 110.0f) / ((float) myApplicationInterface0.DW));
//                    int v199 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 120.0f) / ((float) myApplicationInterface0.DW));
//                    if (bitmap0.getWidth()>bitmap0.getHeight()) {
//                        int v200 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 100.0f) / ((float) myApplicationInterface0.DW));
//                        int v201 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 110.0f) / ((float) myApplicationInterface0.DW));
//                        int v202 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 140.0f) / ((float) myApplicationInterface0.DW));
//                        int v203 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 150.0f) / ((float) myApplicationInterface0.DW));
//                        int v204 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 145.0f) / ((float) myApplicationInterface0.DW));
//                        int v205 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 153.0f) / ((float) myApplicationInterface0.DW));
//                        int v206 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 155.0f) / ((float) myApplicationInterface0.DW));
//                        int v207 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 45.0f) / ((float) myApplicationInterface0.DW));
//                        int v208 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 50.0f) / ((float) myApplicationInterface0.DW));
//                        int v209 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 60.0f) / ((float) myApplicationInterface0.DW));
//                        v87 = (int) (((float) bitmap0.getWidth()) * (myApplicationInterface0.scale * 65.0f) / ((float) myApplicationInterface0.DW));
//                        v88 = v201;
//                        v90 = v202;
//                        v94 = v176;
//                        v95 = v177;
//                        v96 = v178;
//                        v91 = v203;
//                        v92 = v204;
//                        v97 = v183;
//                        v99 = v184;
//                        v100 = v185;
//                        v101 = v186;
//                        v93 = v205;
//                        v102 = v206;
//                        v103 = v207;
//                        v104 = v208;
//                        v89 = v209;
//                        v106 = v199;
//                        v105 = v198;
//                        v98 = v182;
//                        roundCorners1 = roundCorners0;
//                        v107 = v200;
//                        imageView10 = imageView4;
//                        v108 = v179;
//                    } else {
//                        roundCorners1 = roundCorners0;
//                        imageView10 = imageView4;
//                        v94 = v176;
//                        v95 = v177;
//                        v96 = v178;
//                        v108 = v179;
//                        v87 = v197;
//                        v88 = v188;
//                        v97 = v183;
//                        v99 = v184;
//                        v100 = v185;
//                        v101 = v186;
//                        v107 = v187;
//                        v90 = v189;
//                        v93 = v192;
//                        v91 = v190;
//                        v92 = v191;
//                        v102 = v193;
//                        v103 = v194;
//                        v104 = v195;
//                        v89 = v196;
//                        v106 = v199;
//                        v105 = v198;
//                        v98 = v182;
//                    }
//
//                    v109 = v180;
//                }
//            }
//
//            if (myApplicationInterface0.isTablet) {
//                float f1 = (float) v108;
//                textView2.setTextSize(f1);
//                textView3.setTextSize(f1);
//                textView7.setTextSize(f1);
//                textView9.setTextSize(f1);
//                textView10.setTextSize(f1);
//                textView8.setTextSize(f1);
//                textView4.setTextSize(f1);
//                textView5.setTextSize(f1);
//            }
//            else {
//                float f2 = (float) v96;
//                textView2.setTextSize(f2);
//                textView3.setTextSize(f2);
//                textView7.setTextSize(f2);
//                textView9.setTextSize(f2);
//                textView10.setTextSize(f2);
//                textView8.setTextSize(f2);
//                textView4.setTextSize(f2);
//                textView5.setTextSize(f2);
//            }
//
//            LinearLayout.LayoutParams linearLayout$LayoutParams0 = new LinearLayout.LayoutParams(v107, v107);
//            if (v == 0) {
//                linearLayout$LayoutParams0.setMargins(0, 0, v97, 0);
//                v210 = v98;
//                v211 = v108;
//                v212 = v107;
//                roundCorners2 = roundCorners1;
//                roundCorners2.setCornerRadius(((float) v210));
//            }
//            else {
//                v212 = v107;
//                roundCorners2 = roundCorners1;
//                v210 = v98;
//                v211 = v108;
//                linearLayout$LayoutParams0.setMargins(0, 0, 0, 0);
//                roundCorners2.setCornerRadius(0.0f);
//            }
//
//            linearLayout$LayoutParams0.gravity = 80;
//            roundCorners2.setLayoutParams(linearLayout$LayoutParams0);
//            imageView10.getLayoutParams().width = v100;
//            imageView10.getLayoutParams().height = v100;
//            imageView5.getLayoutParams().width = v100;
//            imageView5.getLayoutParams().height = v100;
//            imageView1.getLayoutParams().width = v100;
//            imageView2.getLayoutParams().width = v100;
//            imageView1.getLayoutParams().height = v100;
//            imageView2.getLayoutParams().height = v100;
//            imageView8.getLayoutParams().width = v100;
//            imageView8.getLayoutParams().height = v100;
//            imageView7.getLayoutParams().width = v100;
//            imageView7.getLayoutParams().height = v100;
//            imageView9.getLayoutParams().width = v100;
//            imageView9.getLayoutParams().height = v100;
//            linearLayout11.getLayoutParams().height = v100;
//            if (v == 0) {
//                linearLayout17 = linearLayout7;
//                linearLayout17.setPadding(v97, v97, v97, v97);
//            }
//            else {
//                linearLayout17 = linearLayout7;
//                linearLayout17.setPadding(0, v97, 0, v97);
//            }
//
//            linearLayout18 = linearLayout2;
//            linearLayout18.setPadding(v210, v210, v210, v210);
//            linearLayout3.setPadding(v210, v210, v210, v210);
//            LinearLayout linearLayout19 = linearLayout3;
//            LinearLayout linearLayout20 = linearLayout18;
//            int v213 = v95;
//            textView7.setPadding(v213, 0, 0, 0);
//            textView3.setPadding(v213, 0, 0, 0);
//            textView4.setPadding(v210, 0, v210, 0);
//            textView5.setPadding(v210, 0, v210, 0);
//            textView2.setPadding(v213, 0, 0, 0);
//            if (z5) {
//                linearLayout16.setVisibility(View.VISIBLE);
//                imageView3.setImageResource(myApplicationInterface0.mWeatherIcon.getResourceId(v52, 0));
//                imageView3.getLayoutParams().width = v99;
//                imageView3.getLayoutParams().height = v99;
//            } else {
//                linearLayout16.setVisibility(View.GONE);
//            }
//
//            if (z12) {
//                linearLayout21 = linearLayout5;
//                linearLayout21.setVisibility(View.VISIBLE);
//                v214 = v101;
//                imageView6.getLayoutParams().height = v214;
//                textView11 = textView3;
//                v215 = v89;
//                imageView6.getLayoutParams().width = v215;
//            } else {
//                textView11 = textView3;
//                linearLayout21 = linearLayout5;
//                v215 = v89;
//                v214 = v101;
//                linearLayout21.setVisibility(View.GONE);
//            }
//
//            if (!z14 && !z15 && !z16 && !z17 && !z19) {
//                linearLayout22 = linearLayout21;
//                linearLayout23 = linearLayout11;
//                linearLayout23.setVisibility(View.GONE);
////                label_2888:
//                textView12 = textView7;
//            }
//            else {
//                linearLayout22 = linearLayout21;
//                linearLayout23 = linearLayout11;
//                linearLayout23.setVisibility(View.VISIBLE);
//                if (myApplicationInterface0.isTablet) {
//                    LinearLayout.LayoutParams linearLayout$LayoutParams1 = (LinearLayout.LayoutParams) linearLayout23.getLayoutParams();
//                    textView12 = textView7;
//                    ++linearLayout$LayoutParams1.height;
////                    label_2889:
//                    if (z14) {
//                        linearLayout24 = linearLayout9;
//                        linearLayout24.setVisibility(View.VISIBLE);
//                    } else {
//                        linearLayout24 = linearLayout9;
//                        linearLayout24.setVisibility(View.GONE);
//                    }
//
//                }
//
////                label_2888:
////                textView12 = textView7;
//            }
//
////            label_2889:
////            if(z14) {
////                linearLayout24 = linearLayout9;
////                linearLayout24.setVisibility(View.VISIBLE);
////            }
////            else {
////                linearLayout24 = linearLayout9;
////                linearLayout24.setVisibility(View.GONE);
////            }
//
//            if (z17) {
//                linearLayout25 = linearLayout8;
//                textView13 = textView2;
//                linearLayout25.setVisibility(View.VISIBLE);
//            }
//            else {
//                linearLayout25 = linearLayout8;
//                textView13 = textView2;
//                linearLayout25.setVisibility(View.GONE);
//            }
//
//            if (z19) {
//                v216 = v;
//                linearLayout26 = linearLayout10;
//                linearLayout26.setVisibility(View.VISIBLE);
//            }
//            else {
//                v216 = v;
//                linearLayout26 = linearLayout10;
//                linearLayout26.setVisibility(View.GONE);
//            }
//
//            if (z16) {
//                linearLayout27 = linearLayout17;
//                String s13 = Util.getAltitudeconvert(myApplicationInterface0.main_activity, v51);
//                v217 = v210;
//                if (linearLayout26.getVisibility() == 8) {
//                    linearLayout26.setVisibility(View.VISIBLE);
//                    imageView11 = imageView9;
//                    imageView11.setImageResource(R.drawable.ic_altitiude);  // drawable:ic_altitiude
//                    textView10.setText(s13);
//                    textView10.setTextColor(v50);
//                    linearLayout28 = linearLayout23;
//                    v218 = v215;
//                    v219 = v214;
//                    imageView12 = imageView7;
////                    label_2975:
//                    imageView13 = imageView8;
//                } else {
//                    int v220 = v50;
//                    imageView11 = imageView9;
//                    v218 = v215;
//                    linearLayout28 = linearLayout23;
//                    if (linearLayout25.getVisibility() == 8) {
//                        linearLayout25.setVisibility(View.VISIBLE);
//                        imageView12 = imageView7;
//                        imageView12.setImageResource(R.drawable.ic_altitiude);  // drawable:ic_altitiude
//                        textView8.setText(s13);
//                        textView8.setTextColor(v220);
//                        v219 = v214;
//                    } else {
//                        imageView12 = imageView7;
//                        v219 = v214;
//                        if (linearLayout24.getVisibility() == 8) {
//                            linearLayout24.setVisibility(View.VISIBLE);
//                            imageView13 = imageView8;
//                            imageView13.setImageResource(R.drawable.ic_altitiude);  // drawable:ic_altitiude
//                            textView9.setText(s13);
//                            textView9.setTextColor(v220);
////                            label_2985:
//                            if (z15) {
//                                String s14 = Util.getAccuracy(myApplicationInterface0.main_activity, v49);
//                                if (linearLayout26.getVisibility() == 8) {
//                                    linearLayout26.setVisibility(View.VISIBLE);
//                                    imageView11.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
//                                    textView10.setText(s14);
//                                    textView10.setTextColor(v48);
//                                } else {
//                                    int v221 = v48;
//                                    if (linearLayout25.getVisibility() == 8) {
//                                        linearLayout25.setVisibility(View.VISIBLE);
//                                        imageView12.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
//                                        textView8.setText(s14);
//                                        textView8.setTextColor(v221);
//                                    } else if (linearLayout24.getVisibility() == 8) {
//                                        linearLayout24.setVisibility(View.VISIBLE);
//                                        imageView13.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
//                                        textView9.setText(s14);
//                                        textView9.setTextColor(v221);
//                                    }
//                                }
//                            }
//                        }
//                    }
//
////                    label_2975:
////                    imageView13 = imageView8;
//                }
//            }
//            else {
//                linearLayout28 = linearLayout23;
//                linearLayout27 = linearLayout17;
//                v218 = v215;
//                v217 = v210;
//                v219 = v214;
//                imageView12 = imageView7;
//                imageView13 = imageView8;
//                imageView11 = imageView9;
//            }
//
////            label_2985:
////            if(z15) {
////                String s14 = Util.getAccuracy(myApplicationInterface0.main_activity, v49);
////                if(linearLayout26.getVisibility() == 8) {
////                    linearLayout26.setVisibility(View.VISIBLE);
////                    imageView11.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
////                    textView10.setText(s14);
////                    textView10.setTextColor(v48);
////                }
////                else {
////                    int v221 = v48;
////                    if(linearLayout25.getVisibility() == 8) {
////                        linearLayout25.setVisibility(View.VISIBLE);
////                        imageView12.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
////                        textView8.setText(s14);
////                        textView8.setTextColor(v221);
////                    }
////                    else if(linearLayout24.getVisibility() == 8) {
////                        linearLayout24.setVisibility(View.VISIBLE);
////                        imageView13.setImageResource(R.drawable.ic_accuracy);  // drawable:ic_accuracy
////                        textView9.setText(s14);
////                        textView9.setTextColor(v221);
////                    }
////                }
////            }
//
//            if (z27) {
//                if (z11) {
//                    linearLayout4.setVisibility(View.VISIBLE);
//                    RotateAnimation rotateAnimation0 = new RotateAnimation(-(myApplicationInterface0.main_activity.currentAzimuth + ((float) myApplicationInterface0.main_activity.degree)), -(myApplicationInterface0.main_activity.heading + ((float) myApplicationInterface0.main_activity.degree)), 1, 0.5f, 1, 0.5f);
//                    rotateAnimation0.setDuration(500L);
//                    rotateAnimation0.setFillAfter(true);
//                    imageView5.startAnimation(rotateAnimation0);
//                }
//                else {
//                    linearLayout4.setVisibility(View.GONE);
//                }
//                if (z10) {
//                    linearLayout14.setVisibility(View.VISIBLE);
//                } else {
//                    linearLayout14.setVisibility(View.GONE);
//                }
//            }
//            else {
//                linearLayout4.setVisibility(View.GONE);
//                linearLayout14.setVisibility(View.GONE);
//            }
//
//            if (!z5 && !z10 && !z11 && !z12) {
//                linearLayout29 = linearLayout12;
//                linearLayout29.setVisibility(View.GONE);
//            }
//            else {
//                linearLayout29 = linearLayout12;
//                linearLayout29.setVisibility(View.VISIBLE);
//            }
//
//            if (z22) {
//                textView14 = textView6;
//                if (!z8 && !z4) {
//                    textView14.setMaxLines(10);
//                } else {
//                    textView14.setMaxLines(12);
//                }
//            } else if ((z21) || ((z5) || (z10) || (z11) || (z26) || !z23) && ((z5) || (z10) || (z11) || (z23) || !z26) && (!z5 && !z11 && !z10 || !z23 || (z26)) && (!z5 && !z11 && !z10 || (z23) || !z26)) {
//                textView14 = textView6;
//                if (!z8 && !z4) {
//                    textView14.setMaxLines(10);
//                } else {
//                    textView14.setMaxLines(12);
//                }
//            }
//            else if (!z23 && !z26 || !z13) {
//                textView14 = textView6;
//                if (!z8 && !z24 && !z4) {
//                    textView14.setMaxLines(1);
//                } else {
//                    textView14.setMaxLines(3);
//                }
//            }
//            else if (!z8 && !z4) {
//                textView14 = textView6;
//                textView14.setMaxLines(3);
//            } else {
//                textView14 = textView6;
//                textView14.setMaxLines(5);
//            }
//
//            if ((z21) && myApplicationInterface0.main_activity.getMapBitmap() != null) {
//                v222 = canvas0.getWidth() - (v212 + v109 * 3);
//                if (z12) {
//                    if (!z8 && !z4) {
//                        System.out.println("TemplateCalled             2");
//                        linearLayout1.getLayoutParams().height = v92;
//                        roundCorners2.getLayoutParams().height = v92;
//                    } else {
//                        System.out.println("TemplateCalled             1");
//                        linearLayout1.getLayoutParams().height = v102;
//                        roundCorners2.getLayoutParams().height = v102;
//                    }
//                } else if (!z8 && !z4) {
//                    System.out.println("TemplateCalled             5");
//                    linearLayout1.getLayoutParams().height = v212;
//                    roundCorners2.getLayoutParams().height = v212;
//                } else if (!z17 && !z15 && !z16 && !z14 && !z19) {
//                    System.out.println("TemplateCalled             4");
//                    linearLayout1.getLayoutParams().height = v91;
//                    roundCorners2.getLayoutParams().height = v91;
//                } else {
//                    System.out.println("TemplateCalled             3");
//                    linearLayout1.getLayoutParams().height = v93;
//                    roundCorners2.getLayoutParams().height = v93;
//                }
//
//                linearLayout30 = linearLayout1;
//                int v223 = v211;
//                linearLayout30.setPadding(v223, v213, v223, v213);
//                roundCorners2.setVisibility(View.VISIBLE);
//                roundCorners2.setImageBitmap(myApplicationInterface0.main_activity.getMapBitmap());
//                imageView14 = imageView11;
//                textView15 = textView10;
//                v224 = v103;
//            } else {
//                linearLayout30 = linearLayout1;
//                int v225 = v211;
//                int v226 = v212;
//                int v227 = v91;
//                if (!z26 && !z22 && !z10 && !z11) {
//                    if (z5) {
//                        imageView14 = imageView11;
//                        textView15 = textView10;
//                        v224 = v103;
////                        goto label_3321;
////                        label_3321:
//                        roundCorners2.setVisibility(View.GONE);
//                        int v232 = canvas0.getWidth() - v109 * 2;
//                        if (z22) {
//                            if (!z22 || (z26)) {
//                                int v234 = v88;
//                                if (!z8 && !z4) {
//                                    System.out.println("TemplateCalled             19");
//                                    linearLayout30.getLayoutParams().height = v226;
//                                } else {
//                                    System.out.println("TemplateCalled             18");
//                                    linearLayout30.getLayoutParams().height = v234;
//                                }
//                            } else if (!z8 && !z4) {
//                                System.out.println("TemplateCalled             17");
//                                linearLayout30.getLayoutParams().height = v226;
//                            } else {
//                                System.out.println("TemplateCalled             16");
//                                linearLayout30.getLayoutParams().height = v88;
//                            }
//
//                            linearLayout30.setPadding(v225, v213, v225, v213);
//                        } else if (!z23 && !z26 || textView14.getMaxLines() == 1 && (!z11 && !z10 && !z5 || (z5) && !z11 && !z10 || (z11) && !z5 && !z10 || (z10) && !z5 && !z11)) {
//                            if (linearLayout28.getVisibility() == 8 && !z11 && !z10 && !z5) {
//                                if (((z23) || (z26)) && (z13)) {
//                                    if (!z8 && !z4) {
//                                        System.out.println("TemplateCalled             7");
//                                        linearLayout30.getLayoutParams().height = v218;
//                                    } else {
//                                        System.out.println("TemplateCalled             6");
//                                        linearLayout30.getLayoutParams().height = v87;
//                                    }
//                                } else if (!z8 && !z4) {
//                                    System.out.println("TemplateCalled             9");
//                                    linearLayout30.getLayoutParams().height = v224;
//                                } else {
//                                    System.out.println("TemplateCalled             8");
//                                    linearLayout30.getLayoutParams().height = v104;
//                                }
//                            } else if (!z12) {
//                                if (!z8 && !z4) {
//                                    System.out.println("TemplateCalled             13");
//                                } else {
//                                    System.out.println("TemplateCalled             12");
//                                }
//
//                                linearLayout30.getLayoutParams().height = v105;
//                            } else if (!z8 && !z4) {
//                                System.out.println("TemplateCalled             11");
//                                linearLayout30.getLayoutParams().height = v90;
//                            } else {
//                                System.out.println("TemplateCalled             10");
//                                linearLayout30.getLayoutParams().height = v227;
//                            }
//
//                            linearLayout30.setPadding(v225, v225, v225, v225);
//                        } else {
//                            int v233 = v105;
//                            if (!z8 && !z4) {
//                                System.out.println("TemplateCalled             15");
//                                linearLayout30.getLayoutParams().height = v233;
//                            } else {
//                                System.out.println("TemplateCalled             14");
//                                linearLayout30.getLayoutParams().height = v106;
//                            }
//
//                            linearLayout30.setPadding(v225, v213, v225, v213);
//                        }
//
//                    }
//
//                    int v228 = canvas0.getWidth() - v109 * 2;
//                    roundCorners2.setVisibility(View.GONE);
//                    if ((z8) || (z4)) {
//                        int v231 = v219;
//                        v230 = v103;
//                        v229 = v228;
//                        System.out.println("TemplateCalled             20");
//                        if (!z12 && !z13 && !z8) {
//                            linearLayout30.getLayoutParams().height = v231;
//                        } else if (!z12 && !z13 && !z4) {
//                            linearLayout30.getLayoutParams().height = v231;
//                        } else {
//                            linearLayout30.setPadding(v225, v225, v225, v225);
//                        }
//                    } else if (!z12 && !z13) {
//                        System.out.println("TemplateCalled             21");
//                        linearLayout30.getLayoutParams().height = v219;
//                        linearLayout30.setPadding(v94, v94, v94, v94);
//                        v229 = v228;
//                        v230 = v103;
//                    } else {
//                        System.out.println("TemplateCalled             22");
//                        v230 = v103;
//                        linearLayout30.getLayoutParams().height = v230;
//                        linearLayout30.setPadding(v225, v225, v225, v225);
//                        v229 = v228;
//                    }
//
//                    imageView14 = imageView11;
//                    v222 = v229;
//                    v224 = v230;
//                    textView15 = textView10;
//                } else {
//                    imageView14 = imageView11;
//                    v224 = v103;
//                    textView15 = textView10;
////                    label_3321:
//                    roundCorners2.setVisibility(View.GONE);
//                    int v232 = canvas0.getWidth() - v109 * 2;
//                    if (z22) {
//                        if (!z22 || (z26)) {
//                            int v234 = v88;
//                            if (!z8 && !z4) {
//                                System.out.println("TemplateCalled             19");
//                                linearLayout30.getLayoutParams().height = v226;
//                            } else {
//                                System.out.println("TemplateCalled             18");
//                                linearLayout30.getLayoutParams().height = v234;
//                            }
//                        } else if (!z8 && !z4) {
//                            System.out.println("TemplateCalled             17");
//                            linearLayout30.getLayoutParams().height = v226;
//                        } else {
//                            System.out.println("TemplateCalled             16");
//                            linearLayout30.getLayoutParams().height = v88;
//                        }
//
//                        linearLayout30.setPadding(v225, v213, v225, v213);
//                    } else if (!z23 && !z26 || textView14.getMaxLines() == 1 && (!z11 && !z10 && !z5 || (z5) && !z11 && !z10 || (z11) && !z5 && !z10 || (z10) && !z5 && !z11)) {
//                        if (linearLayout28.getVisibility() == 8 && !z11 && !z10 && !z5) {
//                            if (((z23) || (z26)) && (z13)) {
//                                if (!z8 && !z4) {
//                                    System.out.println("TemplateCalled             7");
//                                    linearLayout30.getLayoutParams().height = v218;
//                                } else {
//                                    System.out.println("TemplateCalled             6");
//                                    linearLayout30.getLayoutParams().height = v87;
//                                }
//                            } else if (!z8 && !z4) {
//                                System.out.println("TemplateCalled             9");
//                                linearLayout30.getLayoutParams().height = v224;
//                            } else {
//                                System.out.println("TemplateCalled             8");
//                                linearLayout30.getLayoutParams().height = v104;
//                            }
//                        } else if (!z12) {
//                            if (!z8 && !z4) {
//                                System.out.println("TemplateCalled             13");
//                            } else {
//                                System.out.println("TemplateCalled             12");
//                            }
//
//                            linearLayout30.getLayoutParams().height = v105;
//                        } else if (!z8 && !z4) {
//                            System.out.println("TemplateCalled             11");
//                            linearLayout30.getLayoutParams().height = v90;
//                        } else {
//                            System.out.println("TemplateCalled             10");
//                            linearLayout30.getLayoutParams().height = v227;
//                        }
//
//                        linearLayout30.setPadding(v225, v225, v225, v225);
//                    } else {
//                        int v233 = v105;
//                        if (!z8 && !z4) {
//                            System.out.println("TemplateCalled             15");
//                            linearLayout30.getLayoutParams().height = v233;
//                        } else {
//                            System.out.println("TemplateCalled             14");
//                            linearLayout30.getLayoutParams().height = v106;
//                        }
//
//                        linearLayout30.setPadding(v225, v213, v225, v213);
//                    }
//
//                    v222 = v232;
//                }
//            }
//
//            int v235 = textView14.getMaxLines() == 1 && ((z5) || (z10) || (z11)) ? v217 : v217;
//            textView14.setPadding(0, 0, v235, 0);
//            if (!z22 && !z26 && !z23 && !z13 && !z17 && !z14 && !z15 && !z19 && !z16 && !z8 && !z24 && !z4) {
//                linearLayout31 = linearLayout13;
//                linearLayout31.setVisibility(View.GONE);
//                linearLayout29.setOrientation(0);
//                linearLayout29.setGravity(17);
//                linearLayout29.getLayoutParams().width = -1;
//                linearLayout29.getLayoutParams().width = -1;
//                if ((z12) && !z21) {
//                    linearLayout30.getLayoutParams().height = v224;
//                }
//            } else {
//                linearLayout31 = linearLayout13;
//                linearLayout31.setVisibility(View.VISIBLE);
//                linearLayout31.setGravity(17);
//                linearLayout29.setOrientation(1);
//                linearLayout29.setGravity(17);
//                linearLayout29.getLayoutParams().width = -2;
//                linearLayout29.getLayoutParams().width = -2;
//            }
//
//            if (!z26 && !z22 && !z23 && !z13 && !z8 && !z24 && !z4) {
//                textView14.setVisibility(View.GONE);
//            } else {
//                textView14.setVisibility(View.VISIBLE);
//            }
//
//            if (!z26 && !z22 && !z10 && !z5 && !z11 && !z23 && !z21 && !z13 && !z17 && !z14 && !z15 && !z19 && !z16 && !z12 && !z8 && !z24 && !z4) {
//                linearLayout27.setVisibility(View.GONE);
//            } else {
//                linearLayout27.setVisibility(View.VISIBLE);
//            }
//
//            boolean z28 = myApplicationInterface0.mSP.getBoolean(myApplicationInterface0.main_activity, "is_water_mark", true);
//            if (z28) {
//                if (v216 == 0) {
//                    s15 = myApplicationInterface0.sharedPreferences.getString("stamp_pos", "Bottom");
//                    if (s15.equals("Bottom")) {
//                        linearLayout30.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.rect_grey_1));  // drawable:rect_grey_1
//                    } else {
//                        linearLayout30.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.rect_grey_3));  // drawable:rect_grey_3
//                    }
//
//                    linearLayout32 = linearLayout20;
//                    linearLayout32.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.rect_grey_2));  // drawable:rect_grey_2
//                    linearLayout33 = linearLayout19;
//                    linearLayout33.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.rect_grey_4));  // drawable:rect_grey_4
//                } else {
//                    linearLayout32 = linearLayout20;
//                    linearLayout33 = linearLayout19;
//                    linearLayout30.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.classic_back));  // drawable:classic_back
//                    linearLayout32.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.classic_back));  // drawable:classic_back
//                    linearLayout33.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.classic_back));  // drawable:classic_back
//                    s15 = myApplicationInterface0.sharedPreferences.getString("stamp_pos_classic", "Bottom");
//                }
//
//                if (s15.equals("Bottom")) {
//                    linearLayout32.setVisibility(View.VISIBLE);
//                    linearLayout33.setVisibility(View.GONE);
//                    ((GradientDrawable) linearLayout30.getBackground().getCurrent()).setColor(v47);
//                    ((GradientDrawable) linearLayout32.getBackground().getCurrent()).setColor(v47);
//                } else {
//                    linearLayout32.setVisibility(View.GONE);
//                    linearLayout33.setVisibility(View.VISIBLE);
//                    ((GradientDrawable) linearLayout30.getBackground().getCurrent()).setColor(v47);
//                    ((GradientDrawable) linearLayout33.getBackground().getCurrent()).setColor(v47);
//                }
//            } else {
//                int v236 = v47;
//                linearLayout20.setVisibility(View.GONE);
//                linearLayout19.setVisibility(View.GONE);
//                if (v216 == 0) {
//                    linearLayout30.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.rect_grey));  // drawable:rect_grey
//                } else {
//                    linearLayout30.setBackground(myApplicationInterface0.main_activity.getResources().getDrawable(R.drawable.classic_back));  // drawable:classic_back
//                }
//
//                GradientDrawable gradientDrawable0 = (GradientDrawable) linearLayout30.getBackground().getCurrent();
//                if (v216 == 0) {
//                    gradientDrawable0.setCornerRadius(((float) v235));
//                }
//
//                gradientDrawable0.setColor(v236);
//            }
//
//            TextView textView16 = textView13;
//            textView16.setTextColor(v46);
//            TextView textView17 = textView12;
//            textView17.setTextColor(v45);
//            textView17.setText(myApplicationInterface0.main_activity.getMagnaticFieldStr());
//            TextView textView18 = textView11;
//            textView18.setTextColor(v44);
//            textView18.setText(myApplicationInterface0.main_activity.getCompassStr());
//            if (z17) {
//                textView8.setText(Util.getwindConvert(myApplicationInterface0.main_activity, v43));
//                imageView12.setImageResource(R.drawable.ic_wind);  // drawable:ic_wind
//                textView8.setTextColor(v35);
//            }
//
//            if (z14) {
//                linearLayout34 = linearLayout29;
//                linearLayout35 = linearLayout31;
//                textView9.setText(myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "Humidity_value", "") + "%");
//                imageView13.setImageResource(R.drawable.ic_humidity);  // drawable:ic_humidity
//                textView9.setTextColor(v37);
//            } else {
//                linearLayout35 = linearLayout31;
//                linearLayout34 = linearLayout29;
//            }
//
//            if (z19) {
//                textView19 = textView15;
//                textView19.setText(Util.getpressureConvert(myApplicationInterface0.main_activity, v41));
//                imageView14.setImageResource(R.drawable.ic_pressure);  // drawable:ic_pressure
//                textView19.setTextColor(v36);
//            } else {
//                textView19 = textView15;
//            }
//
//            LinearLayout.LayoutParams linearLayout$LayoutParams2 = new LinearLayout.LayoutParams(v222, linearLayout30.getLayoutParams().height);
//            linearLayout$LayoutParams2.gravity = 17;
//            linearLayout30.setLayoutParams(linearLayout$LayoutParams2);
//            String s16 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "loc_address_line_1", "").trim();
//            String s17 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "loc_city", "").trim();
//            String s18 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "loc_state", "").trim();
//            TextView textView20 = textView17;
//            String s19 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "loc_country", "").trim();
//            TextView textView21 = textView18;
//            String s20 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "PLUS_CODE", "").trim();
//            if (!s20.isEmpty() && (s12.equals("concise"))) {
//                s20 = s20.substring(4);
//            }
//
//            String s21 = s17 == null || (s17.isEmpty()) ? "" : "" + s17 + ", ";
//            if (s18 != null && !s18.isEmpty()) {
//                s21 = s21 + "" + s18 + ", ";
//            }
//
//            if (s19 != null && !s19.isEmpty()) {
//                s21 = s21 + s19;
//            }
//
//            if (s21 != null && (s21.endsWith(", "))) {
//                s21 = s21.substring(0, s21.length() - 2);
//            }
//
//            if (s16 == null || (s16.isEmpty())) {
//                s16 = "";
//            }
//
//            int v237 = v30;
//            String s22 = myApplicationInterface0.main_activity.getColoredSpanned(s16, v237);
//            String s23 = Util.getLatLong(myApplicationInterface0.main_activity, v40);
//            TextView textView22 = textView19;
//            String s24 = myApplicationInterface0.main_activity.getColoredSpanned(s23, v32);
//            if ((z26) && s24 != null && v40 != 6 && v40 != 7 && s24.length()>55 && (z21) && !z10 && (z23) && !z5 && !z11) {
//                String[] arr_s = s24.split(" Long");
//                s24 = arr_s[0] + "<br/>Long " + arr_s[1];
//            }
//
//            if (z22) {
//                if (z26) {
//                    s22 = s22 + "<br/>" + s24;
//                }
//            } else if ((z26) && !z22) {
//                s22 = s24;
//            }
//
//            if (z4) {
//                String s25 = myApplicationInterface0.main_activity.getColoredSpanned("Plus Code : " + s20, v33);
//                s22 = (z22) || (z26) ? s22 + "<br/>" + s25 : s25;
//            }
//
//            if (z23) {
//                String s26 = Util.setDateTimeFormat(s4);
//                v238 = v31;
//                String s27 = myApplicationInterface0.main_activity.getColoredSpanned(s26, v238);
//                s22 = !z22 && !z26 && !z4 ? s27 : s22 + "<br/>" + s27;
//            } else {
//                v238 = v31;
//            }
//
//            if (z24) {
//                String s28 = myApplicationInterface0.getTimezone(v42);
//                String s29 = myApplicationInterface0.main_activity.getColoredSpanned(s28, v238);
//                if (z23) {
//                    s22 = s22 + " " + s29;
//                } else if (!z22 && !z26 && !z4) {
//                    s22 = s29;
//                } else {
//                    s22 = s22 + "<br/>" + s29;
//                }
//            }
//
//            if (z13) {
//                if (v216 == 0) {
//                    String s30 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "notes_hashtag", "Note : Captured by GPS Map Camera");
//                    s31 = myApplicationInterface0.main_activity.getColoredSpanned(s30, v34);
//                    textView23 = textView8;
//                } else {
//                    textView23 = textView8;
//                    String s32 = myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "notes_hashtag_classic", "Note : Captured by GPS Map Camera");
//                    s31 = myApplicationInterface0.main_activity.getColoredSpanned(s32, v34);
//                }
//
//                s22 = !z22 && !z26 && !z23 && !z24 && !z4 ? s31 : s22 + "<br/>" + s31;
//            } else {
//                textView23 = textView8;
//            }
//
//            if (z8) {
//                String s33 = myApplicationInterface0.main_activity.getColoredSpanned(s10 + " " + v39 + " " + s11.trim(), v38);
//                s22 = (z22) || (z26) || (z23) || (z24) || (z13) || (z4) ? s22 + "<br/>" + s33 : s33;
//            }
//
//            if (s22.contains("null")) {
//                s22 = s22.replace("null", "");
//            }
//
//            textView14.setText(Html.fromHtml(s22));
//            if (s21 != null && !s21.isEmpty() && (z22)) {
//                textView24 = textView1;
//                textView24.setVisibility(View.VISIBLE);
//                if (s21.contains("null")) {
//                    s21 = s21.replace("null", "");
//                }
//
//                textView24.setText(Html.fromHtml(myApplicationInterface0.main_activity.getColoredSpanned(s21, v237)));
//            } else {
//                textView24 = textView1;
//                textView24.setVisibility(View.GONE);
//            }
//
//            if (s9.equals("Celsius")) {
//                textView16.setText(Util.getCelcius(f));
//            } else {
//                textView16.setText(Util.getFahrenheit(f));
//            }
//
//            if ((z21) && !z22 && !z26 && !z23 && !z11 && !z10 && !z5 && !z13 && !z17 && !z14 && !z15 && !z19 && !z16 && !z12 && !z24 && !z8 && !z4) {
//                linearLayout30.setVisibility(4);
//            } else {
//                linearLayout30.setVisibility(View.VISIBLE);
//            }
//
//            String s34 = s7;
//            if (s34.equals("no_logo")) {
//                imageView6.setImageResource(R.mipmap.ic_launcher);  // mipmap:ic_launcher
//            } else {
//                imageView6.setImageBitmap(Util.decodeBase64(s34));
//            }
//
//            String s35 = myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "template_type", 0) == 0 ? myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "stamp_font_style", "sfuitext_regular.otf") : myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "stamp_font_style_classic", "sfuitext_regular.otf");
//            textView9.setTypeface(Util.getFontStyle(myApplicationInterface0.main_activity, s35));
//            textView23.setTypeface(Util.getFontStyle(myApplicationInterface0.main_activity, s35));
//            textView22.setTypeface(Util.getFontStyle(myApplicationInterface0.main_activity, s35));
//            textView14.setTypeface(Util.getFontStyle(myApplicationInterface0.main_activity, s35));
//            textView24.setTypeface(Util.getFontStyle(myApplicationInterface0.main_activity, s35));
//            textView16.setTypeface(Util.getFontStyle(myApplicationInterface0.main_activity, s35));
//            textView21.setTypeface(Util.getFontStyle(myApplicationInterface0.main_activity, s35));
//            textView20.setTypeface(Util.getFontStyle(myApplicationInterface0.main_activity, s35));
//            Log.e("LLLLL", "--" + linearLayout35.getVisibility());
//            Log.e("LLLLL", "--" + linearLayout34.getVisibility());
//            Log.e("LLLLL", "--" + linearLayout30.getVisibility());
//            Log.e("LLLLL", "--" + linearLayout22.getVisibility());
//            myApplicationInterface0.stampBitmap = myApplicationInterface0.loadBitmapFromView(view1);
//            String s36 = v216 == 0 ? myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "stamp_pos", "Bottom") : myApplicationInterface0.mSP.getString(myApplicationInterface0.main_activity, "stamp_pos_classic", "Bottom");
//
//            Log.d("BITMAPPPP", ":::: " + myApplicationInterface0.stampBitmap.getWidth() + ":::" + myApplicationInterface0.stampBitmap.getHeight());
//            float f3 = 0.0f;
//            if (bitmap0 != null && myApplicationInterface0.stampBitmap != null) {
//                if (s36.equals("Bottom")) {
//                    if (v216 == 0) {
//                        f4 = (float) canvas0.getHeight();
//                        f5 = (float) myApplicationInterface0.stampBitmap.getHeight();
//                    } else {
//                        f4 = (float) canvas0.getHeight();
//                        f5 = (float) myApplicationInterface0.stampBitmap.getHeight();
//                        f3 = 50.0f;
//                    }
//
//                    f3 = f4 - (f5 + f3);
//                }
//
//                if (v216 == 0) {
//                    float f6 = (float) (canvas0.getWidth() / 2 - myApplicationInterface0.stampBitmap.getWidth() / 2);
//                    canvas0.drawBitmap(myApplicationInterface0.stampBitmap, f6, f3, paint0);
//                } else {
//                    Canvas canvas1 = canvas0;
//                    Paint paint1 = paint0;
//                    if (z21) {
//                        f7 = (double) (canvas0.getWidth() / 2);
//                        f8 = (double) myApplicationInterface0.stampBitmap.getWidth();
//                        f9 = (double) myApplicationInterface0.stampBitmap.getWidth();
//                        f10 = 2.17;
//                    } else {
//                        f7 = (double) (canvas0.getWidth() / 2);
//                        f8 = (double) myApplicationInterface0.stampBitmap.getWidth();
//                        f9 = (double) myApplicationInterface0.stampBitmap.getWidth();
//                        f10 = 2.106;
//                    }
//
//                    float f11 = (float) (f7 - (f8 - f9 / f10));
//                    canvas1.drawBitmap(Bitmap.createScaledBitmap(myApplicationInterface0.stampBitmap, canvas0.getWidth(), myApplicationInterface0.stampBitmap.getHeight() + 50, false), f11, f3, paint1);
//                }
//
//                myApplicationInterface0.stampBitmap.recycle();
//                myApplicationInterface0.stampBitmap = null;
//                System.gc();
//            }
//
//            if (z8) {
//                if (v216 == 0) {
//                    if (z25) {
//                        if (myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "SEQUENCE", 1) == 0x3B9AC9FF) {
//                            myApplicationInterface0.mSP.setInteger(myApplicationInterface0.main_activity, "SEQUENCE", 0);
//                        }
//
//                        SP sP2 = myApplicationInterface0.mSP;
//                        int v239 = sP2.getInteger(myApplicationInterface0.main_activity, "SEQUENCE", 1) + 1;
//                        sP2.setInteger(myApplicationInterface0.main_activity, "SEQUENCE", v239);
//                        return bitmap0;
//                    }
//
//                    if (myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "SEQUENCE", 1) == 0xC4653601) {
//                        myApplicationInterface0.mSP.setInteger(myApplicationInterface0.main_activity, "SEQUENCE", 0);
//                    }
//
//                    SP sP3 = myApplicationInterface0.mSP;
//                    int v240 = sP3.getInteger(myApplicationInterface0.main_activity, "SEQUENCE", 1) - 1;
//                    sP3.setInteger(myApplicationInterface0.main_activity, "SEQUENCE", v240);
//                    return bitmap0;
//                }
//
//                if (z25) {
//                    if (myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", 1) == 0x3B9AC9FF) {
//                        myApplicationInterface0.mSP.setInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", 0);
//                    }
//
//                    SP sP4 = myApplicationInterface0.mSP;
//                    int v241 = sP4.getInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", 1) + 1;
//                    sP4.setInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", v241);
//                    return bitmap0;
//                }
//
//                if (myApplicationInterface0.mSP.getInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", 1) == 0xC4653601) {
//                    myApplicationInterface0.mSP.setInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", 0);
//                }
//
//                SP sP5 = myApplicationInterface0.mSP;
//                int v242 = sP5.getInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", 1) - 1;
//                sP5.setInteger(myApplicationInterface0.main_activity, "SEQUENCE_CLASSIC", v242);
//                return bitmap0;
//            }
//        } catch (OutOfMemoryError outOfMemoryError0) {
//            outOfMemoryError0.printStackTrace();
//            return null;
//        }
//
//        return bitmap0;
//    }


    private String getTimezone(int i) {
        String displayName = Calendar.getInstance().getTimeZone().getDisplayName(false, 1);
        Date time = Calendar.getInstance(TimeZone.getTimeZone("GMT"), Locale.getDefault()).getTime();
        String format = new SimpleDateFormat("Z").format(time);
        String format2 = new SimpleDateFormat("ZZZZZ", Locale.getDefault()).format(time);
        switch (i) {
            case 1:
                return format;
            case 2:
                return "UTC " + format;
            case 3:
                return "GMT " + format;
            case 4:
                return format2;
            case 5:
                return "UTC " + format2;
            case 6:
                return "GMT " + format2;
            case 7:
                return displayName;
            default:
                return "";
        }
    }

    public int toSP(float f) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, f, this.main_activity.getResources().getDisplayMetrics());
    }

    public Bitmap loadBitmapFromView(View view) {
        try {
            view.measure(0, 0);
            Bitmap createBitmap = Bitmap.createBitmap(view.getMeasuredWidth(), view.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(createBitmap);
            view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
            view.draw(canvas);
            System.gc();
            return createBitmap;
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
            return null;
        }
    }


    public void finishVideoIntent(Uri uri) {
        Log.d(TAG, "finishVideoIntent:" + uri);
        Intent intent = new Intent();
        intent.setData(uri);
        this.main_activity.setResult(-1, intent);
        this.main_activity.finish();
    }


    public void addLastImageMediaStore(Uri uri, boolean z) {
        Log.d(TAG, "addLastImageMediaStore: " + uri);
        Log.d(TAG, "share?: " + z);
        this.last_images_type = LastImagesType.MEDIASTORE;
        this.last_images.add(new LastImage(uri, z));
    }

    public static class LastImage {
        final String name;
        final boolean share;
        Uri uri;

        LastImage(Uri uri, boolean z) {
            this.name = null;
            this.uri = uri;
            this.share = z;
        }

        LastImage(String str, boolean z) {
            this.name = str;
            if (Build.VERSION.SDK_INT>=24) {
                this.uri = null;
            } else {
                this.uri = Uri.parse("file://" + str);
            }
            this.share = z;
        }
    }
}
