package com.live.gpsmap.camera.Adapter;

import android.content.Context;
import android.content.res.TypedArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.live.gpsmap.camera.Interface.OnRecyclerItemClickListener;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.SP;

public class LanguageAdapter extends RecyclerView.Adapter<LanguageAdapter.Holder> {
    private final int count;
    TypedArray langIcon;
    Context mContext;
    String[] mLanArray;
    SP mSP;
    OnRecyclerItemClickListener onRecyclerItemClickListener;
    int seleced_pos;

    public LanguageAdapter(Context context, String[] strArr, TypedArray typedArray, OnRecyclerItemClickListener onRecyclerItemClickListener) {
        this.seleced_pos = 0;
        this.mContext = context;
        this.mLanArray = strArr;
        this.onRecyclerItemClickListener = onRecyclerItemClickListener;
        SP sp = new SP(context);
        this.mSP = sp;
        this.langIcon = typedArray;
        int integer = sp.getInteger(context, SP.LANGUAGE_COUNT, 0);
        this.count = integer;
        if (integer == 0) {
            this.seleced_pos = this.mSP.getInteger(context, SP.LANGUAGE_POS, 0);
            return;
        }
        int integer2 = this.mSP.getInteger(context, SP.LANGUAGE_POS, 0);
        this.seleced_pos = integer2;
        if (integer2 == -1) {
            this.seleced_pos = 0;
        }
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View inflate;
        if (this.count == 0) {
            inflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_language_home, viewGroup, false);
        } else {
            inflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_language, viewGroup, false);
        }
        return new Holder(inflate);
    }

    public void refAdapter(int i) {
        this.seleced_pos = i;
        notifyDataSetChanged();
    }

    @Override
    public void onBindViewHolder(Holder holder, int i) {
        TextView textView = holder.mtvTitle;
        textView.setText("" + this.mLanArray[i]);
        holder.imgflag.setImageResource(this.langIcon.getResourceId(i, 0));
        if (this.seleced_pos == i) {
            if (this.count != 0) {
                holder.img_chek.setImageResource(R.drawable.ic_select_btn);
            } else {
                holder.img_chek.setVisibility(View.VISIBLE);
            }
        } else if (this.count != 0) {
            holder.img_chek.setImageResource(R.drawable.ic_radio_btn_black);
        } else {
            holder.img_chek.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return this.mLanArray.length;
    }

    public class Holder extends RecyclerView.ViewHolder {
        private ImageView img_chek;
        private ImageView imgflag;
        private TextView mtvTitle;

        public Holder(View view) {
            super(view);
            this.mtvTitle = (TextView) view.findViewById(R.id.tv_title);
            this.img_chek = (ImageView) view.findViewById(R.id.img_check);
            this.imgflag = (ImageView) view.findViewById(R.id.imgflag);
            if (LanguageAdapter.this.count == 0) {
                ((CardView) view.findViewById(R.id.cardView)).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view2) {
                        if (LanguageAdapter.this.onRecyclerItemClickListener != null) {
                            LanguageAdapter.this.onRecyclerItemClickListener.OnClick_(Holder.this.getAdapterPosition(), view2);
                        }
                    }
                });
            } else {
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view2) {
                        if (LanguageAdapter.this.onRecyclerItemClickListener != null) {
                            LanguageAdapter.this.onRecyclerItemClickListener.OnClick_(Holder.this.getAdapterPosition(), view2);
                        }
                    }
                });
            }
        }
    }
}