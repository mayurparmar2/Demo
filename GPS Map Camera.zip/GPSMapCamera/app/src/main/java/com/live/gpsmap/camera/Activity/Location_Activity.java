package com.live.gpsmap.camera.Activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.IntentSender;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

import com.live.gpsmap.camera.Adapter.LoctionAdapter;
import com.live.gpsmap.camera.Camera.LocationSupplier;
import com.live.gpsmap.camera.Camera.utils.NetworkState;
import com.live.gpsmap.camera.Database.DateTimeDB;
import com.live.gpsmap.camera.Interface.OnRecyclerItemClickListener;
import com.live.gpsmap.camera.Model.LoctionModel;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Default;
import com.live.gpsmap.camera.Utils.Helper.SingleClickListener;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.Utils.Util;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;

@SuppressWarnings("All")
public class Location_Activity extends AppCompatActivity implements View.OnClickListener, OnMapReadyCallback, GoogleMap.OnCameraIdleListener {
    private static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = 5000;
    private static final int REQUEST_CHECK_SETTINGS = 100;
    private static final long UPDATE_INTERVAL_IN_MILLISECONDS = 1000;
    View bootmSheetCardView;
    DateTimeDB dateTimeDB;
    FusedLocationProviderClient fusedLocationClient;
    private ImageView img_add_address;
    private RelativeLayout lin_automatic;
    private LinearLayout lin_manual;
    private LinearLayout lin_no_list;
    private LinearLayout lin_title;
    private LocationSupplier locationSupplier;
    LoctionAdapter loctionAdapter;
    String mAddress_line_1;
    private BottomSheetBehavior mBottomSheetCardView;
    String mCity;
    String mCountry;
    private Location mCurrentLocation;
    EditText mEd_city;
    EditText mEd_country;
    EditText mEd_latitude;
    EditText mEd_loc_line_1;
    EditText mEd_longitude;
    EditText mEd_state;
    EditText mEd_title;
    private Util mHelperClass;
    private ImageView mImg_menu;
    double mLatitude;
    private LocationCallback mLocationCallback;
    private LocationRequest mLocationRequest;
    private LocationSettingsRequest mLocationSettingsRequest;
    String mLocationType;
    private AppBarLayout mLocation_toolbar;
    double mLongitude;
    GoogleMap mMap;
    SupportMapFragment mMapFragment;
    RelativeLayout mMap_view;
    String mPostalCode;
    RelativeLayout mRel_mask;
    SP mSP;
    NestedScrollView mScrollView;
    private SettingsClient mSettingsClient;
    String mState;
    private RelativeLayout mToolbar_back;
    private LinearLayout mToolbar_menu;
    ImageView moImg_location;
    ImageView moImg_mapType;
    ImageView moImg_map_fs;
    RelativeLayout mrelLocation_layout;
    private TextView mtv_toolbar_title;
    RecyclerView rv_map_list;
    private RelativeLayout toolbar_done_manual;
    Marker marker = null;
    int flage = 0;
    private ArrayList<LoctionModel> Loction_list = new ArrayList<>();
    private int camMove = 0;
    private boolean app_is_paused = false;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
//        LicenseClientV3.onActivityCreate(this);
        super.onCreate(bundle);
        Util helperClass = new Util();
        this.mHelperClass = helperClass;
        helperClass.SetLanguage(this);
        setContentView(R.layout.location_activity);
        init();
        initMapFragment();
        new Handler().postDelayed(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.Location_Activity.1
            @Override // java.lang.Runnable
            public void run() {
                Location_Activity.this.loadAds();
            }
        }, 200L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loadAds() {
//        new Admob().loadAdaptive_banner(this, (RelativeLayout) findViewById(R.id.rel_adaptive_banner), getString(R.string.GMC_Banner_Details));
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        this.app_is_paused = false;
        startLocationUpdates();
    }

    private void onClicks() {
        this.mToolbar_menu.setOnClickListener(this);
        this.mToolbar_back.setOnClickListener(new SingleClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.Location_Activity.2
            @Override // com.gpsmapcamera.geotagginglocationonphoto.helper.SingleClickListener
            public void performClick(View view) {
                Util.hideSoftKeyboard(Location_Activity.this, view);
                Location_Activity.this.onBackPressed();
            }
        });
        this.moImg_location.setOnClickListener(this);
        this.moImg_mapType.setOnClickListener(this);
        this.moImg_map_fs.setOnClickListener(this);
        this.img_add_address.setOnClickListener(this);
        this.toolbar_done_manual.setOnClickListener(this);
    }

    public int getStatusBarHeight() {
        int identifier = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (identifier > 0) {
            return getResources().getDimensionPixelSize(identifier);
        }
        return 0;
    }

    private void init() {
        SP sp = new SP(this);
        this.mSP = sp;
        this.mSP.setInteger(this, "MAP_DATA_OPEN_TIME", sp.getInteger(this, "MAP_DATA_OPEN_TIME", 0) + 1);
        DateTimeDB dateTimeDB = new DateTimeDB(this);
        this.dateTimeDB = dateTimeDB;
        this.Loction_list = dateTimeDB.getIsSelectedLoction();
        this.mToolbar_menu = (LinearLayout) findViewById(R.id.toolbar_menu);
        this.mToolbar_back = (RelativeLayout) findViewById(R.id.toolbar_back);
        this.toolbar_done_manual = (RelativeLayout) findViewById(R.id.toolbar_done_manual);
        this.mtv_toolbar_title = (TextView) findViewById(R.id.tv_toolbar_title);
        this.mImg_menu = (ImageView) findViewById(R.id.img_menu);
        this.mEd_latitude = (EditText) findViewById(R.id.mEd_latitude);
        this.lin_automatic = (RelativeLayout) findViewById(R.id.lin_automatic);
        this.lin_manual = (LinearLayout) findViewById(R.id.lin_manual);
        this.lin_no_list = (LinearLayout) findViewById(R.id.lin_no_list);
        this.mEd_longitude = (EditText) findViewById(R.id.mEd_longitude);
        this.mEd_loc_line_1 = (EditText) findViewById(R.id.mEd_loc_line_1);
        this.mEd_city = (EditText) findViewById(R.id.mEd_city);
        this.mEd_state = (EditText) findViewById(R.id.mEd_state);
        this.mEd_title = (EditText) findViewById(R.id.mEd_title);
        this.mEd_country = (EditText) findViewById(R.id.mEd_country);
        this.mScrollView = (NestedScrollView) findViewById(R.id.nes_location_detail);
        this.mRel_mask = (RelativeLayout) findViewById(R.id.rel_mask);
//        this.bootmSheetCardView = findViewById(R.id.bottomSheetCardView);
        this.moImg_map_fs = (ImageView) findViewById(R.id.img_map_fs);
        this.moImg_mapType = (ImageView) findViewById(R.id.img_mapType);
        this.moImg_location = (ImageView) findViewById(R.id.img_location);
        this.mMap_view = (RelativeLayout) findViewById(R.id.map_view);
        this.img_add_address = (ImageView) findViewById(R.id.img_add_address);
        this.mrelLocation_layout = (RelativeLayout) findViewById(R.id.location_layout);
        this.mLocation_toolbar = (AppBarLayout) findViewById(R.id.location_toolbar);
        this.rv_map_list = (RecyclerView) findViewById(R.id.rv_map_list);
        this.lin_title = (LinearLayout) findViewById(R.id.lin_title);
        String location_Type = getLocation_Type();
        this.mLocationType = location_Type;
        if (location_Type.equals(Default.AUTOMATIC)) {
            this.mtv_toolbar_title.setText(getString(R.string.automatic));
        } else {
            this.mtv_toolbar_title.setText(getString(R.string.manual));
        }
        onClicks();
        getadressadpter();
        updateManualLocationUI();
        if (NetworkState.Companion.isOnline(this)) {
            return;
        }
        RelativeLayout relativeLayout = this.mMap_view;
        Snackbar.make(relativeLayout, "" + getString(R.string.no_internet_msg), BaseTransientBottomBar.LENGTH_INDEFINITE).show();
    }

    private void getadressadpter() {
        selctedLoction();
        this.mSP.getString(this, SP.LATITUDE, "");
        this.mSP.getString(this, SP.LONGITUDE, "");
        String string = this.mSP.getString(this, SP.LOCATION_SELECTION_TITLE, "");
        if (this.Loction_list.size() > 0) {
            if (string.equals("")) {
                for (int i = 0; i < this.Loction_list.size(); i++) {
                    this.Loction_list.get(i).setSelection(0);
                }
                this.Loction_list.get(0).setSelection(1);
            } else {
                boolean z = true;
                for (int i2 = 0; i2 < this.Loction_list.size(); i2++) {
                    if (this.Loction_list.get(i2).getTitle().equals(string)) {
                        this.Loction_list.get(i2).setSelection(1);
                        z = false;
                    } else {
                        this.Loction_list.get(i2).setSelection(0);
                    }
                }
                if (z) {
                    this.Loction_list.get(0).setSelection(1);
                }
            }
        }
        this.rv_map_list.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        LoctionAdapter loctionAdapter = new LoctionAdapter(this, this.Loction_list, new OnRecyclerItemClickListener() {
            @Override // com.gpsmapcamera.geotagginglocationonphoto.interfaces.OnRecyclerItemClickListener
            public void OnClick_(int i3, View view) {
                for (int i4 = 0; i4 < Location_Activity.this.Loction_list.size(); i4++) {
                    if (i4 == i3) {
                        ((LoctionModel) Location_Activity.this.Loction_list.get(i4)).setSelection(1);
                    } else {
                        ((LoctionModel) Location_Activity.this.Loction_list.get(i4)).setSelection(0);
                    }
                }
                Location_Activity.this.saveData();
                Location_Activity.this.loctionAdapter.refreceadpter(Location_Activity.this.Loction_list);
                Location_Activity.this.finish();
            }

            @Override // com.gpsmapcamera.geotagginglocationonphoto.interfaces.OnRecyclerItemClickListener
            public void OnLongClick_(final int i3, View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Location_Activity.this);
                builder.setTitle(Location_Activity.this.getString(R.string.delete));
                builder.setMessage(Location_Activity.this.getString(R.string.delete_location_msg));
                builder.setPositiveButton(Location_Activity.this.getString(R.string.yes), new DialogInterface.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.Location_Activity.3.1
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i4) {
                        Location_Activity.this.dateTimeDB.deleteLocation(((LoctionModel) Location_Activity.this.Loction_list.get(i3)).getId());
                        Location_Activity.this.refrecedata();
                        dialogInterface.dismiss();
                    }
                });
                builder.setNegativeButton(Location_Activity.this.getString(R.string.no), new DialogInterface.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.Location_Activity.3.2
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i4) {
                        dialogInterface.dismiss();
                    }
                });
                builder.create().show();
            }
        });
        this.loctionAdapter = loctionAdapter;
        this.rv_map_list.setAdapter(loctionAdapter);
        if (this.Loction_list.size() > 0) {
            this.lin_no_list.setVisibility(View.GONE);
        } else {
            this.lin_no_list.setVisibility(View.VISIBLE);
        }
    }

    private void selctedLoction() {
        String string = this.mSP.getString(this, SP.LOCATION_SELECTION, "");
        if (this.Loction_list.size() > 0) {
            if (string.equals("")) {
                for (int i = 0; i < this.Loction_list.size(); i++) {
                    this.Loction_list.get(i).setSelection(0);
                }
                this.Loction_list.get(0).setSelection(1);
                return;
            }
            boolean z = true;
            for (int i2 = 0; i2 < this.Loction_list.size(); i2++) {
                LoctionModel loctionModel = this.Loction_list.get(i2);
                if (string.equals(loctionModel.getLatitude() + " , " + loctionModel.getLongitude())) {
                    loctionModel.setSelection(1);
                    z = false;
                } else {
                    loctionModel.setSelection(0);
                }
            }
            if (z) {
                this.Loction_list.get(0).setSelection(1);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void refrecedata() {
        this.Loction_list.clear();
        this.Loction_list = this.dateTimeDB.getIsSelectedLoction();
        selctedLoction();
        this.loctionAdapter.refreceadpter(this.Loction_list);
        if (this.Loction_list.size() > 0) {
            this.lin_no_list.setVisibility(View.GONE);
            return;
        }
        this.flage = 0;
        this.lin_no_list.setVisibility(View.VISIBLE);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void disableUI() {
        if (this.mLocationType.equals(Default.AUTOMATIC)) {
            refreshLocation();
            this.mtv_toolbar_title.setText(getString(R.string.automatic));
            this.mEd_latitude.setCursorVisible(false);
            this.mEd_longitude.setCursorVisible(false);
            this.mEd_city.setCursorVisible(false);
            this.mEd_country.setCursorVisible(false);
            this.mEd_state.setCursorVisible(false);
            this.mEd_loc_line_1.setCursorVisible(false);
            this.mScrollView.setAlpha(0.5f);
            this.mMap_view.setAlpha(0.5f);
            this.mRel_mask.setVisibility(View.VISIBLE);
            this.lin_automatic.setVisibility(View.VISIBLE);
            this.lin_manual.setVisibility(View.GONE);
            this.lin_title.setVisibility(View.GONE);
            updateLiveLocaionUI();
            return;
        }
        this.mtv_toolbar_title.setText(getString(R.string.manual));
        latitude_CursorPos();
        longitude_CursorPos();
        line_1_cursorPos();
        cityCursorPos();
        state_CursorPos();
        country_CursorPos();
        this.mEd_latitude.setCursorVisible(true);
        this.mEd_longitude.setCursorVisible(true);
        this.mEd_city.setCursorVisible(true);
        this.mEd_country.setCursorVisible(true);
        this.mEd_state.setCursorVisible(true);
        this.mEd_loc_line_1.setCursorVisible(true);
        this.mMap_view.setAlpha(1.0f);
        this.mScrollView.setAlpha(1.0f);
        this.mRel_mask.setVisibility(View.GONE);
        this.lin_automatic.setVisibility(View.GONE);
        this.lin_manual.setVisibility(View.VISIBLE);
        this.lin_title.setVisibility(View.VISIBLE);
        updateManualLocationUI();
    }

    private void country_CursorPos() {
        EditText editText = this.mEd_country;
        editText.setSelection(editText.getText().toString().trim().length());
    }

    private void state_CursorPos() {
        EditText editText = this.mEd_state;
        editText.setSelection(editText.getText().toString().trim().length());
    }

    private void longitude_CursorPos() {
        EditText editText = this.mEd_longitude;
        editText.setSelection(editText.getText().toString().trim().length());
    }

    private void cityCursorPos() {
        EditText editText = this.mEd_city;
        editText.setSelection(editText.getText().toString().trim().length());
    }

    private void line_1_cursorPos() {
        EditText editText = this.mEd_loc_line_1;
        editText.setSelection(editText.getText().toString().trim().length());
    }

    private void latitude_CursorPos() {
        EditText editText = this.mEd_latitude;
        editText.setSelection(editText.getText().toString().trim().length());
    }

    private void updateManualLocationUI() {
        if (this.mLocationType.equals(Default.MANUAL) || isEmpty()) {
            String string = this.mSP.getString(this, SP.LATITUDE, "");
            if (string != null && !string.isEmpty()) {
                if (string.contains(",")) {
                    string = string.replace(",", ".");
                }
                this.mLatitude = Double.valueOf(string).doubleValue();
            }
            String string2 = this.mSP.getString(this, SP.LONGITUDE, "");
            if (string2 != null && !string2.isEmpty()) {
                if (string2.contains(",")) {
                    string2 = string2.replace(",", ".");
                }
                this.mLongitude = Double.valueOf(string2).doubleValue();
            }
            this.mAddress_line_1 = this.mSP.getString(this, SP.LOC_LINE_1_ADDRESS, "");
            this.mCity = this.mSP.getString(this, SP.LOC_LINE_2_CITY, "");
            this.mState = this.mSP.getString(this, SP.LOC_LINE_3_STATE, "");
            this.mCountry = this.mSP.getString(this, SP.LOC_LINE_4_COUNTRY, "");
            setEditTextData(this.mLatitude, this.mLongitude);
            animateMarker(this.mLatitude, this.mLongitude);
        }
    }

    private void setEditTextData(double d, double d2) {
        DecimalFormat decimalFormat = new DecimalFormat("#.######");
        String str = this.mAddress_line_1;
        if (str != null && !str.isEmpty()) {
            this.mEd_loc_line_1.setText(this.mAddress_line_1);
            line_1_cursorPos();
        }
        if (d != 0.0d) {
            EditText editText = this.mEd_latitude;
            editText.setText("" + decimalFormat.format(d));
            latitude_CursorPos();
        }
        if (d2 != 0.0d) {
            EditText editText2 = this.mEd_longitude;
            editText2.setText("" + decimalFormat.format(d2));
            longitude_CursorPos();
        }
        String str2 = this.mCity;
        if (str2 != null && !str2.isEmpty()) {
            this.mEd_city.setText(this.mCity);
            cityCursorPos();
        }
        String str3 = this.mCountry;
        if (str3 != null && !str3.isEmpty()) {
            this.mEd_country.setText(this.mCountry);
            country_CursorPos();
        }
        String str4 = this.mState;
        if (str4 == null || str4.isEmpty()) {
            return;
        }
        this.mEd_state.setText(this.mState);
        state_CursorPos();
    }

    private void animateMarker(double d, double d2) {
        if (d2 == 0.0d || d == 0.0d) {
            return;
        }
        LatLng latLng = new LatLng(d, d2);
        if (this.mMap != null) {
            Marker marker = this.marker;
            if (marker == null) {
                if (getResources().getBoolean(R.bool.isTablet)) {
                    this.marker = this.mMap.addMarker(new MarkerOptions().position(latLng).title(this.mCity).flat(true).draggable(false).anchor(0.5f, 0.5f).icon(BitmapFromVector(this, R.drawable.google_map_pin, 20, 35)));
                } else {
                    this.marker = this.mMap.addMarker(new MarkerOptions().position(latLng).title(this.mCity).flat(true).draggable(false).anchor(0.5f, 0.5f).icon(BitmapFromVector(this, R.drawable.google_map_pin, 35, 60)));
                }
            } else {
                marker.setPosition(latLng);
            }
            this.mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
            this.mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15.0f));
        }
    }

    private BitmapDescriptor BitmapFromVector(Context context, int i, int i2, int i3) {
        Drawable drawable = ContextCompat.getDrawable(context, i);
        drawable.setBounds(0, 0, i2, i3);
        Bitmap createBitmap = Bitmap.createBitmap(i2, i3, Bitmap.Config.ARGB_8888);
        drawable.draw(new Canvas(createBitmap));
        return BitmapDescriptorFactory.fromBitmap(createBitmap);
    }

    private void initMapFragment() {
        MapsInitializer.initialize(this);
        initLocation();
        SupportMapFragment supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        this.mMapFragment = supportMapFragment;
        if (supportMapFragment != null) {
            supportMapFragment.getMapAsync(this);
        }
    }

    private void initLocation() {
        this.locationSupplier = new LocationSupplier(this);
        this.fusedLocationClient = LocationServices.getFusedLocationProviderClient((Activity) this);
        this.mLocationCallback = new LocationCallback() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.Location_Activity.4
            @Override // com.google.android.gms.location.LocationCallback
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    if (location != null) {
                        Location_Activity.this.mCurrentLocation = location;
                        Location_Activity.this.updateLiveLocaionUI();
                        Location_Activity.this.locationSupplier.setLocation(location);
                    }
                }
            }
        };
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateLiveLocaionUI() {
        if (this.mCurrentLocation == null || !this.mLocationType.equals(Default.AUTOMATIC)) {
            return;
        }
        this.mLatitude = this.mCurrentLocation.getLatitude();
        double longitude = this.mCurrentLocation.getLongitude();
        this.mLongitude = longitude;
        getAddress(this.mLatitude, longitude);
        setEditTextData(this.mLatitude, this.mLongitude);
        animateMarker(this.mLatitude, this.mLongitude);
    }

    private void getAddress(final double d, final double d2) {
        Executors.newSingleThreadExecutor().execute(new Runnable() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.Location_Activity$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                Location_Activity.this.m811x9b84e57b(d, d2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$getAddress$0$com-gpsmapcamera-geotagginglocationonphoto-activity-Location_Activity  reason: not valid java name */
    public /* synthetic */ void m811x9b84e57b(double d, double d2) {
        List<Address> fromLocation;
        new ArrayList();
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            if (!Geocoder.isPresent() || (fromLocation = geocoder.getFromLocation(d, d2, 1)) == null || fromLocation.size() <= 0) {
                return;
            }
            this.mAddress_line_1 = fromLocation.get(0).getAddressLine(0);
            this.mCity = fromLocation.get(0).getLocality();
            this.mState = fromLocation.get(0).getAdminArea();
            this.mCountry = fromLocation.get(0).getCountryName();
            this.mPostalCode = fromLocation.get(0).getPostalCode();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void startLocationUpdates() {
        LocationRequest locationRequest = new LocationRequest();
        this.mLocationRequest = locationRequest;
        locationRequest.setInterval(UPDATE_INTERVAL_IN_MILLISECONDS);
        this.mLocationRequest.setFastestInterval(5000L);
        this.mLocationRequest.setPriority(100);
        this.mSettingsClient = LocationServices.getSettingsClient((Activity) this);
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        builder.addLocationRequest(this.mLocationRequest);
        this.mLocationSettingsRequest = builder.build();
        this.fusedLocationClient = LocationServices.getFusedLocationProviderClient((Activity) this);
        this.mSettingsClient.checkLocationSettings(this.mLocationSettingsRequest).addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.Location_Activity.6
            @Override // com.google.android.gms.tasks.OnSuccessListener
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                if (Location_Activity.this.fusedLocationClient == null || Location_Activity.this.mLocationCallback == null) {
                    return;
                }
                Location_Activity.this.fusedLocationClient.requestLocationUpdates(Location_Activity.this.mLocationRequest, Location_Activity.this.mLocationCallback, Looper.myLooper());
            }
        }).addOnFailureListener(this, new OnFailureListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.activity.Location_Activity.5
            @Override // com.google.android.gms.tasks.OnFailureListener
            public void onFailure(Exception exc) {
                int statusCode = ((ApiException) exc).getStatusCode();
                if (statusCode == 6) {
                    try {
                        ((ResolvableApiException) exc).startResolutionForResult(Location_Activity.this, 100);
                    } catch (IntentSender.SendIntentException unused) {
                    }
                } else if (statusCode != 8502) {
                } else {
                    Toast.makeText(Location_Activity.this, "Location settings are inadequate, and cannot be fixed here. Fix in Settings.", 1).show();
                }
            }
        });
    }

    private void locationType_Popup(View view) {
        View inflate = View.inflate(this, R.layout.popup_location, null);
        final PopupWindow popupWindow = new PopupWindow(inflate, -2, -2, true);
        popupWindow.setOutsideTouchable(true);
        LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.li_automatic);
        LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.li_manual);
        final ImageView imageView = (ImageView) inflate.findViewById(R.id.img_automatic);
        final ImageView imageView2 = (ImageView) inflate.findViewById(R.id.img_manual);
        if (this.mLocationType.equals(Default.AUTOMATIC)) {
            imageView.setVisibility(View.VISIBLE);
        } else {
            imageView2.setVisibility(View.VISIBLE);
        }
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                if (!Location_Activity.this.mLocationType.equals(Default.AUTOMATIC)) {
                    Location_Activity.this.mLocationType = Default.AUTOMATIC;
                    imageView.setVisibility(View.VISIBLE);
                    imageView2.setVisibility(4);
                    Location_Activity.this.disableUI();
                    PopupWindow popupWindow2 = popupWindow;
                    if (popupWindow2 != null) {
                        popupWindow2.dismiss();
                    }
                    Location_Activity.this.flage = 0;
                    Location_Activity.this.toolbar_done_manual.setVisibility(View.GONE);
                    return;
                }
                PopupWindow popupWindow3 = popupWindow;
                if (popupWindow3 != null) {
                    popupWindow3.dismiss();
                }
            }
        });
        linearLayout2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view2) {
                if (!Location_Activity.this.mLocationType.equals(Default.MANUAL)) {
                    Location_Activity.this.mLocationType = Default.MANUAL;
                    imageView.setVisibility(4);
                    imageView2.setVisibility(View.VISIBLE);
                    Location_Activity.this.disableUI();
                    PopupWindow popupWindow2 = popupWindow;
                    if (popupWindow2 != null) {
                        popupWindow2.dismiss();
                        return;
                    }
                    return;
                }
                PopupWindow popupWindow3 = popupWindow;
                if (popupWindow3 != null) {
                    popupWindow3.dismiss();
                }
            }
        });
        popupWindow.showAtLocation(view, 49, 0, (int) getResources().getDimension(R.dimen._62dp));
    }

    private String getLocation_Type() {
        return this.mSP.getString(this, SP.LOCATION_TYPE, Default.AUTOMATIC);
    }

    private void mapType_Popup(View view) {
        View inflate = View.inflate(this, R.layout.popup_map_type, null);
        final PopupWindow popupWindow = new PopupWindow(inflate, -2, -2, true);
        popupWindow.setOutsideTouchable(true);
        final ImageView imageView = (ImageView) inflate.findViewById(R.id.img_normal_done);
        final ImageView imageView2 = (ImageView) inflate.findViewById(R.id.img_setelite_done);
        final ImageView imageView3 = (ImageView) inflate.findViewById(R.id.img_terrain_done);
        final ImageView imageView4 = (ImageView) inflate.findViewById(R.id.img_hybird_done);
        LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.li_normal);
        LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.li_setellite);
        showDone(imageView, imageView2, imageView3, imageView4);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view2) {
                Location_Activity.this.mMap.setMapType(1);
                Location_Activity.this.mSP.setString(Location_Activity.this, SP.MAP_TYPE, Default.NORMAL_1);
                Location_Activity.this.showDone(imageView, imageView2, imageView3, imageView4);
                popupWindow.dismiss();
            }
        });
        linearLayout2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view2) {
                Location_Activity.this.mMap.setMapType(2);
                Location_Activity.this.mSP.setString(Location_Activity.this, SP.MAP_TYPE, Default.SETELLITE_2);
                Location_Activity.this.showDone(imageView, imageView2, imageView3, imageView4);
                popupWindow.dismiss();
            }
        });
        ((LinearLayout) inflate.findViewById(R.id.li_terrain)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view2) {
                Location_Activity.this.mMap.setMapType(3);
                Location_Activity.this.mSP.setString(Location_Activity.this, SP.MAP_TYPE, Default.TERRAIN_3);
                Location_Activity.this.showDone(imageView, imageView2, imageView3, imageView4);
                popupWindow.dismiss();
            }
        });
        ((LinearLayout) inflate.findViewById(R.id.li_hybird)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view2) {
                Location_Activity.this.mMap.setMapType(4);
                Location_Activity.this.mSP.setString(Location_Activity.this, SP.MAP_TYPE, Default.HYBRID_4);
                Location_Activity.this.showDone(imageView, imageView2, imageView3, imageView4);
                popupWindow.dismiss();
            }
        });
        if (this.moImg_map_fs.getTag().equals("Full_Screen")) {
            popupWindow.showAtLocation(this.mrelLocation_layout, 5, 0, 190);
        } else {
            popupWindow.showAtLocation(view, 5, 0, -135);
        }
    }

    private void setMapType() {
        String string = this.mSP.getString(this, SP.MAP_TYPE, Default.SETELLITE_2);
        string.hashCode();
        char c = 65535;
        switch (string.hashCode()) {
            case -1579103941:
                if (string.equals(Default.SETELLITE_2)) {
                    c = 0;
                    break;
                }
                break;
            case -1423437003:
                if (string.equals(Default.TERRAIN_3)) {
                    c = 1;
                    break;
                }
                break;
            case -1202757124:
                if (string.equals(Default.HYBRID_4)) {
                    c = 2;
                    break;
                }
                break;
            case 1366708796:
                if (string.equals(Default.NORMAL_1)) {
                    c = 3;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                this.mMap.setMapType(2);
                return;
            case 1:
                this.mMap.setMapType(3);
                return;
            case 2:
                this.mMap.setMapType(4);
                return;
            case 3:
                this.mMap.setMapType(1);
                return;
            default:
                return;
        }
    }


    public void showDone(ImageView imageView, ImageView imageView2, ImageView imageView3, ImageView imageView4) {
        String string = this.mSP.getString(this, SP.MAP_TYPE, Default.SETELLITE_2);
        string.hashCode();
        char c = 65535;
        switch (string.hashCode()) {
            case -1579103941:
                if (string.equals(Default.SETELLITE_2)) {
                    c = 0;
                    break;
                }
                break;
            case -1423437003:
                if (string.equals(Default.TERRAIN_3)) {
                    c = 1;
                    break;
                }
                break;
            case -1202757124:
                if (string.equals(Default.HYBRID_4)) {
                    c = 2;
                    break;
                }
                break;
            case 1366708796:
                if (string.equals(Default.NORMAL_1)) {
                    c = 3;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                imageView.setVisibility(4);
                imageView2.setVisibility(View.VISIBLE);
                imageView3.setVisibility(4);
                imageView4.setVisibility(4);
                return;
            case 1:
                imageView.setVisibility(4);
                imageView2.setVisibility(4);
                imageView3.setVisibility(View.VISIBLE);
                imageView4.setVisibility(4);
                return;
            case 2:
                imageView.setVisibility(4);
                imageView2.setVisibility(4);
                imageView3.setVisibility(4);
                imageView4.setVisibility(View.VISIBLE);
                return;
            case 3:
                imageView.setVisibility(View.VISIBLE);
                imageView2.setVisibility(4);
                imageView3.setVisibility(4);
                imageView4.setVisibility(4);
                return;
            default:
                return;
        }
    }

    public void savemanuleaddress() {
        this.lin_manual.setVisibility(View.VISIBLE);
        this.lin_automatic.setVisibility(View.GONE);
        this.toolbar_done_manual.setVisibility(View.GONE);
        this.flage = 0;
    }

    @Override
    public void onClick(View view) {
        Util.hideSoftKeyboard(this, view);
        switch (view.getId()) {
            case R.id.img_add_address:
                if (this.mLocationType.equals(Default.MANUAL) && this.flage == 0) {
                    this.lin_manual.setVisibility(View.GONE);
                    this.lin_automatic.setVisibility(View.VISIBLE);
                    this.toolbar_done_manual.setVisibility(View.VISIBLE);
                    this.mEd_title.setText("");
                    this.flage = 1;
                    return;
                }
                return;
            case R.id.img_location:
                refreshLocation();
                return;
            case R.id.img_mapType :
                mapType_Popup(view);
                return;
            case R.id.img_map_fs:
                if (this.moImg_map_fs.getTag().equals("minimize")) {
                    this.mMap_view.setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
                    this.moImg_map_fs.setImageResource(R.drawable.ic_map_zoom_out);
                    this.moImg_map_fs.setTag("Full_Screen");
                    return;
                } else if (this.moImg_map_fs.getTag().equals("Full_Screen")) {
                    this.mMap_view.setLayoutParams(new RelativeLayout.LayoutParams(-1, (int) getResources().getDimension(R.dimen.map_size)));
                    this.moImg_map_fs.setImageResource(R.drawable.ic_map_zoom);
                    this.moImg_map_fs.setTag("minimize");
                    return;
                } else {
                    return;
                }
            case R.id.toolbar_done_manual:
                if (this.flage == 1) {
                    String trim = this.mEd_latitude.getText().toString().trim();
                    String trim2 = this.mEd_longitude.getText().toString().trim();
                    if (trim.contains(",")) {
                        trim = trim.replace(",", ".");
                    }
                    String str = trim;
                    if (trim2.contains(",")) {
                        trim2 = trim2.replace(",", ".");
                    }
                    String str2 = trim2;
                    if (this.mEd_title.getText().toString().trim().equals("")) {
                        Snackbar.make(view, getResources().getString(R.string.please_enter_title), 0).show();
                        return;
                    }
                    for (int i = 0; i < this.Loction_list.size(); i++) {
                        if (this.Loction_list.get(i).getTitle().trim().equalsIgnoreCase(this.mEd_title.getText().toString().trim())) {
                            this.mEd_title.setFocusableInTouchMode(true);
                            this.mEd_title.setError(getString(R.string.note_title_exist));
                            this.mEd_title.requestFocus();
                            return;
                        }
                    }
                    this.dateTimeDB.insetLoction(this.mEd_title.getText().toString().trim(), str, str2, this.mEd_loc_line_1.getText().toString().trim(), this.mEd_city.getText().toString().trim(), this.mEd_state.getText().toString().trim(), this.mEd_country.getText().toString().trim());
                    upgateadapter();
                    savemanuleaddress();
                    return;
                }
                return;
            case R.id.toolbar_menu:
                locationType_Popup(this.mImg_menu);
                return;
            default:
                return;
        }
    }

    private void upgateadapter() {
        this.Loction_list.clear();
        this.Loction_list = this.dateTimeDB.getIsSelectedLoction();
        for (int i = 0; i < this.Loction_list.size(); i++) {
            if (this.Loction_list.size() - 1 == i) {
                this.Loction_list.get(i).setSelection(1);
            } else {
                this.Loction_list.get(i).setSelection(0);
            }
        }
        this.loctionAdapter.refreceadpter(this.Loction_list);
        if (this.Loction_list.size() > 0) {
            this.lin_no_list.setVisibility(View.GONE);
        } else {
            this.lin_no_list.setVisibility(View.VISIBLE);
        }
    }

    private void refreshLocation() {
        Location location = this.mCurrentLocation;
        if (location != null) {
            this.mLatitude = location.getLatitude();
            double longitude = this.mCurrentLocation.getLongitude();
            this.mLongitude = longitude;
            getAddress(this.mLatitude, longitude);
            setEditTextData(this.mLatitude, this.mLongitude);
            animateMarker(this.mLatitude, this.mLongitude);
        }
    }

    public void stopLocationUpdates() {
        if (this.mMap != null) {
            if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") != 0) {
                return;
            }
            this.mMap.setMyLocationEnabled(false);
        }
        FusedLocationProviderClient fusedLocationProviderClient = this.fusedLocationClient;
        if (fusedLocationProviderClient != null) {
            fusedLocationProviderClient.removeLocationUpdates(this.mLocationCallback);
        }
    }


    @Override
    public void onPause() {
        super.onPause();
        this.app_is_paused = true;
        stopLocationUpdates();
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        stopLocationUpdates();
    }
    public void saveData() {
        String str;
        String str2;
        String str3;
        String str4;
        String str5;
        String str6;
        if (!isEmpty_1()) {
            if (this.mLocationType.equals(Default.AUTOMATIC)) {
                str = this.mEd_latitude.getText().toString().trim();
                str2 = this.mEd_longitude.getText().toString().trim();
                if (str.contains(",")) {
                    str = str.replace(",", ".");
                }
                if (str2.contains(",")) {
                    str2 = str2.replace(",", ".");
                }
                str3 = this.mEd_loc_line_1.getText().toString().trim();
                str4 = this.mEd_city.getText().toString().trim();
                str5 = this.mEd_state.getText().toString().trim();
                str6 = this.mEd_country.getText().toString().trim();
            } else {
                String str7 = "";
                String str8 = "";
                String str9 = str8;
                String str10 = str9;
                String str11 = str10;
                String str12 = str11;
                String str13 = str12;
                for (int i = 0; i < this.Loction_list.size(); i++) {
                    LoctionModel loctionModel = this.Loction_list.get(i);
                    if (loctionModel.getSelection() == 1) {
                        str7 = loctionModel.getLatitude();
                        str8 = loctionModel.getLongitude();
                        str10 = loctionModel.getLoc_line_1();
                        str11 = loctionModel.getCity();
                        str12 = loctionModel.getState();
                        str13 = loctionModel.getCountry();
                        str9 = loctionModel.getTitle();
                    }
                }
                SP sp = this.mSP;
                sp.setString(this, SP.LOCATION_SELECTION, str7 + " , " + str8);
                this.mSP.setString(this, SP.LOCATION_SELECTION_TITLE, str9);
                str = str7;
                str2 = str8;
                str3 = str10;
                str4 = str11;
                str5 = str12;
                str6 = str13;
            }
            this.mSP.setString(this, SP.LATITUDE, str);
            this.mSP.setString(this, SP.LONGITUDE, str2);
            this.mSP.setString(this, SP.LOC_LINE_1_ADDRESS, str3);
            this.mSP.setString(this, SP.LOC_LINE_2_CITY, str4);
            this.mSP.setString(this, SP.LOC_LINE_3_STATE, str5);
            this.mSP.setString(this, SP.LOC_LINE_4_COUNTRY, str6);
            this.mSP.setString(this, SP.LOCATION_TYPE, this.mLocationType);
//            FirebaseAnalytics.getInstance(this).setUserProperty("Map_Data", this.mLocationType);
            if (this.mLocationType.equals(Default.AUTOMATIC)) {
                msgDialog();
                return;
            }
            this.mSP.setBoolean(this, SP.IS_LOCATION_CHANGED, true);
            finish();
        } else if (!this.mLocationType.equals(Default.AUTOMATIC) && this.Loction_list.size() == 0) {
            finish();
        } else {
            Snackbar.make(this.mMap_view, getString(R.string.empty_location_msg), -1).show();
        }
    }
    private boolean anyChange() {
        return (this.mLocationType.equals(Default.AUTOMATIC) && this.mEd_latitude.getText().toString().trim().equals(getLatitude()) && this.mEd_longitude.getText().toString().trim().equals(getLongitude()) && this.mEd_loc_line_1.getText().toString().trim().equals(getAddress_Line1()) && this.mEd_city.getText().toString().trim().equals(getCity()) && this.mEd_state.getText().toString().trim().equals(getState()) && this.mEd_country.getText().toString().trim().equals(getCountry()) && this.mLocationType.equals(getLocation_Type())) ? false : true;
    }
    private void msgDialog() {
        if (isFinishing()) {
            return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getString(R.string.save_location_msg));
        builder.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                Location_Activity.this.finish();
            }
        });
        builder.create().show();
    }
    private String getCountry() {
        return this.mSP.getString(this, SP.LOC_LINE_4_COUNTRY, "");
    }
    private String getState() {
        return this.mSP.getString(this, SP.LOC_LINE_3_STATE, "");
    }
    private String getCity() {
        return this.mSP.getString(this, SP.LOC_LINE_2_CITY, "");
    }
    private String getAddress_Line1() {
        return this.mSP.getString(this, SP.LOC_LINE_1_ADDRESS, "");
    }

    private String getLongitude() {
        return this.mSP.getString(this, SP.LONGITUDE, "");
    }

    private String getLatitude() {
        return this.mSP.getString(this, SP.LATITUDE, "");
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.mMap = googleMap;
        this.mCurrentLocation = this.locationSupplier.getLocation();
        this.mMap.setOnCameraIdleListener(new GoogleMap.OnCameraIdleListener() {
            @Override
            public final void onCameraIdle() {
                Location_Activity.this.onCameraIdle();
            }
        });
        disableUI();
        setMapType();
    }

    @Override
    public void onBackPressed() {
        if (this.flage == 1) {
            savemanuleaddress();
        } else if (anyChange()) {
            saveData();
        } else {
            finish();
        }
        Log.e("KKKK", "onBackPressed: ");
    }

    private boolean isEmpty() {
        return this.mEd_loc_line_1.getText().toString().trim().isEmpty() && this.mEd_latitude.getText().toString().trim().isEmpty() && this.mEd_longitude.getText().toString().trim().isEmpty() && this.mEd_state.getText().toString().trim().isEmpty() && this.mEd_city.getText().toString().trim().isEmpty() && this.mEd_country.getText().toString().trim().isEmpty();
    }

    private boolean isEmpty_1() {
        String s1;
        String s;
        if(this.mLocationType.equals("Automatic")) {
            s = this.mEd_latitude.getText().toString().trim();
            s1 = this.mEd_longitude.getText().toString().trim();
        }
        else {
            s = "";
            s1 = "";
            int v;
            for(v = 0; v < this.Loction_list.size(); ++v) {
                LoctionModel loctionModel0 = (LoctionModel)this.Loction_list.get(v);
                if(loctionModel0.getSelection() == 1) {
                    s = loctionModel0.getLatitude();
                    s1 = loctionModel0.getLongitude();
                }
            }
        }

        if(!s.isEmpty() && !s1.isEmpty() && !s.equals("-") && !s1.equals("-") && !s.equals(".") && !s1.equals(".")) {
            try {
                if(s.contains(",")) {
                    s = s.replace(",", ".");
                }

                if(s1.contains(",")) {
                    s1 = s1.replace(",", ".");
                }

                double f = (double)Double.valueOf(s);
                double f1 = (double)Double.valueOf(s1);
                return f < -90.0 || f > 90.0 || f == 0.0 || (f1 < -180.0 || f1 > 180.0 || f1 == 0.0);
            }
            catch(NumberFormatException unused_ex) {
                return true;
            }
        }

        return true;
    }
    @Override
    public void onCameraIdle() {
        LatLng latLng;
        int i = this.camMove + 1;
        this.camMove = i;
        if (i < 2 || (latLng = this.mMap.getCameraPosition().target) == null) {
            return;
        }
        getAddress(latLng.latitude, latLng.longitude);
        setEditTextData(latLng.latitude, latLng.longitude);
    }
}