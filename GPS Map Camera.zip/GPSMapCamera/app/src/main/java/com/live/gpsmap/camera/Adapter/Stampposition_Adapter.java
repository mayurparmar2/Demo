package com.live.gpsmap.camera.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.live.gpsmap.camera.Interface.OnRecyclerItemClickListener;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.SP;

/* loaded from: classes3.dex */
public class Stampposition_Adapter extends RecyclerView.Adapter<Stampposition_Adapter.Holder> {
    Context mContext;
    String[] mList;
    OnRecyclerItemClickListener mOnRecyclerItemClickListener;
    SP mSP;
    int selPos;
    String selected_pos;

    public Stampposition_Adapter(Context context, String[] strArr, OnRecyclerItemClickListener onRecyclerItemClickListener) {
        this.selPos = 1;
        this.mContext = context;
        this.mList = strArr;
        this.mOnRecyclerItemClickListener = onRecyclerItemClickListener;
        SP sp = new SP(this.mContext);
        this.mSP = sp;
        String string = sp.getString(this.mContext, "pos_type_temp", "Bottom");
        this.selected_pos = string;
        if (string.equals("Top")) {
            this.selPos = 0;
        } else {
            this.selPos = 1;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_date_time_adapter, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(Holder holder, int i) {
        TextView textView = holder.tv_dateFormat;
        textView.setText(this.mList[i] + "");
        if (i == this.selPos) {
            holder.img_selection.setVisibility(View.VISIBLE);
        } else {
            holder.img_selection.setVisibility(View.GONE);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.mList.length;
    }

    /* loaded from: classes2.dex */
    public class Holder extends RecyclerView.ViewHolder {
        LinearLayout date_main_lay;
        ImageView img_selection;
        TextView tv_dateFormat;

        public Holder(View view) {
            super(view);
            this.tv_dateFormat = (TextView) view.findViewById(R.id.tv_temp_name);
            this.date_main_lay = (LinearLayout) view.findViewById(R.id.dt_main_lay);
            this.img_selection = (ImageView) view.findViewById(R.id.img_selection);
            this.date_main_lay.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.adapter.Stampposition_Adapter.Holder.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    if (Holder.this.getAdapterPosition() < 0 || Stampposition_Adapter.this.mOnRecyclerItemClickListener == null) {
                        return;
                    }
                    Stampposition_Adapter.this.mOnRecyclerItemClickListener.OnClick_(Holder.this.getAdapterPosition(), view2);
                }
            });
        }
    }
}