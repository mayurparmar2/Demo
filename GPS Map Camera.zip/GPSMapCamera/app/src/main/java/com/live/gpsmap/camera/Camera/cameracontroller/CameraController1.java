package com.live.gpsmap.camera.Camera.cameracontroller;

import android.hardware.Camera;
import android.location.Location;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.TextureView;

import com.live.gpsmap.camera.Camera.MyDebug;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import kotlinx.coroutines.DebugKt;

@SuppressWarnings("All")
public class CameraController1 extends CameraController {
    private static final String TAG = "CameraController1";
    private static final int max_expo_bracketing_n_images = 3;
    private List<Integer> burst_exposures;
    private Camera camera;
    private final CameraController.ErrorCallback camera_error_cb;
    private final Camera.CameraInfo camera_info;
    private int current_exposure_compensation;
    private int current_zoom_value;
    private int display_orientation;
    private int expo_bracketing_n_images;
    private double expo_bracketing_stops;
    private boolean frontscreen_flash;
    private String iso_key;
    private int n_burst;
    private final List<byte[]> pending_burst_images;
    private int picture_height;
    private int picture_width;
    private boolean sounds_enabled;
    private boolean want_expo_bracketing;

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public String getAPI() {
        return "Camera";
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getCameraExtension() {
        return -1;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public String getEdgeMode() {
        return null;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public long getExposureTime() {
        return 0L;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public float getFocusBracketingSourceDistance() {
        return 0.0f;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public float getFocusBracketingTargetDistance() {
        return 0.0f;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public float getFocusDistance() {
        return 0.0f;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getISO() {
        return 0;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public String getNoiseReductionMode() {
        return null;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean getOpticalStabilization() {
        return false;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getWhiteBalanceTemperature() {
        return 0;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void initVideoRecorderPostPrepare(MediaRecorder mediaRecorder, boolean z) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean isBurstOrExpo() {
        return false;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean isCameraExtension() {
        return false;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean isContinuousBurstInProgress() {
        return false;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean isManualISO() {
        return false;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean sceneModeAffectsFunctionality() {
        return true;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setAperture(float f) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setBurstForNoiseReduction(boolean z, boolean z2) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setBurstNImages(int i) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setCameraExtension(boolean z, int i) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setCaptureFollowAutofocusHint(boolean z) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setDummyCaptureHack(boolean z) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.SupportedValues setEdgeMode(String str) {
        return null;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean setExposureTime(long j) {
        return false;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setFocusBracketingAddInfinity(boolean z) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setFocusBracketingNImages(int i) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setFocusBracketingSourceDistance(float f) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setFocusBracketingTargetDistance(float f) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean setFocusDistance(float f) {
        return false;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean setISO(int i) {
        return false;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setManualISO(boolean z, int i) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.SupportedValues setNoiseReductionMode(String str) {
        return null;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setOptimiseAEForDRO(boolean z) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setRaw(boolean z, int i) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setTonemapProfile(CameraController.TonemapProfile tonemapProfile, float f, float f2) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setUseExpoFastBurst(boolean z) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setVideoHighSpeed(boolean z) {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean setWhiteBalanceTemperature(int i) {
        return false;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void stopContinuousBurst() {
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void stopFocusBracketingBurst() {
    }

    public CameraController1(int i, CameraController.ErrorCallback errorCallback) throws CameraControllerException {
        super(i);
        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        this.camera_info = cameraInfo;
        this.sounds_enabled = false;
        this.pending_burst_images = new ArrayList();
        this.expo_bracketing_n_images = 3;
        this.expo_bracketing_stops = 2.0d;
        Log.d(TAG, "create new CameraController1: " + i);
        this.camera_error_cb = errorCallback;
        try {
            Camera open = Camera.open(i);
            this.camera = open;
            if (open == null) {
                Log.e(TAG, "camera.open returned null");
                throw new CameraControllerException();
            }
            try {
                Camera.getCameraInfo(i, cameraInfo);
                this.camera.setErrorCallback(new CameraErrorCallback());
            } catch (RuntimeException e) {
                Log.e(TAG, "failed to get camera info");
                e.printStackTrace();
                release();
                throw new CameraControllerException();
            }
        } catch (RuntimeException e2) {
            Log.e(TAG, "failed to open camera");
            e2.printStackTrace();
            throw new CameraControllerException();
        }
    }

    @Override
    public void onError() {
        Log.e(TAG, "onError");
        Camera camera = this.camera;
        if (camera != null) {
            camera.release();
            this.camera = null;
        }
        CameraController.ErrorCallback errorCallback = this.camera_error_cb;
        if (errorCallback != null) {
            errorCallback.onError();
        }
    }

    /* loaded from: classes.dex */
    private class CameraErrorCallback implements Camera.ErrorCallback {
        private CameraErrorCallback() {
        }

        @Override // android.hardware.Camera.ErrorCallback
        public void onError(int i, Camera camera) {
            Log.e(CameraController1.TAG, "camera onError: " + i);
            if (i == 100) {
                Log.e(CameraController1.TAG, "    CAMERA_ERROR_SERVER_DIED");
                CameraController1.this.onError();
            } else if (i == 1) {
                Log.e(CameraController1.TAG, "    CAMERA_ERROR_UNKNOWN ");
            }
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void release() {
        Camera camera = this.camera;
        if (camera != null) {
            try {
                camera.release();
                this.camera = null;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Camera.Parameters getParameters() {
        Log.d(TAG, "getParameters");
        return this.camera.getParameters();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setCameraParameters(Camera.Parameters parameters) {
        Log.d(TAG, "setCameraParameters");
        try {
            this.camera.setParameters(parameters);
            Log.d(TAG, "done");
        } catch (RuntimeException e) {
            Log.d(TAG, "failed to set parameters");
            e.printStackTrace();
            this.count_camera_parameters_exception++;
        }
    }

    private List<String> convertFlashModesToValues(List<String> list) {
        Log.d(TAG, "convertFlashModesToValues()");
        Log.d(TAG, "supported_flash_modes: " + list);
        ArrayList arrayList = new ArrayList();
        if (list != null) {
            if (list.contains(DebugKt.DEBUG_PROPERTY_VALUE_OFF)) {
                arrayList.add("flash_off");
                Log.d(TAG, " supports flash_off");
            }
            if (list.contains("auto")) {
                arrayList.add("flash_auto");
                Log.d(TAG, " supports flash_auto");
            }
            if (list.contains(DebugKt.DEBUG_PROPERTY_VALUE_ON)) {
                arrayList.add("flash_on");
                Log.d(TAG, " supports flash_on");
            }
            if (list.contains("torch")) {
                arrayList.add("flash_torch");
                Log.d(TAG, " supports flash_torch");
            }
            if (list.contains("red-eye")) {
                arrayList.add("flash_red_eye");
                Log.d(TAG, " supports flash_red_eye");
            }
        }
        if (arrayList.size()>1) {
            Log.d(TAG, "flash supported");
        } else if (getFacing() == CameraController.Facing.FACING_FRONT) {
            Log.d(TAG, "front-screen with no flash");
            arrayList.clear();
            arrayList.add("flash_off");
            arrayList.add("flash_frontscreen_on");
            arrayList.add("flash_frontscreen_torch");
        } else {
            Log.d(TAG, "no flash");
            arrayList.clear();
        }
        return arrayList;
    }

    private List<String> convertFocusModesToValues(List<String> list) {
        Log.d(TAG, "convertFocusModesToValues()");
        ArrayList arrayList = new ArrayList();
        if (list != null) {
            if (list.contains("auto")) {
                arrayList.add("focus_mode_auto");
                Log.d(TAG, " supports focus_mode_auto");
            }
            if (list.contains("infinity")) {
                arrayList.add("focus_mode_infinity");
                Log.d(TAG, " supports focus_mode_infinity");
            }
            if (list.contains("macro")) {
                arrayList.add("focus_mode_macro");
                Log.d(TAG, " supports focus_mode_macro");
            }
            if (list.contains("auto")) {
                arrayList.add("focus_mode_locked");
                Log.d(TAG, " supports focus_mode_locked");
            }
            if (list.contains("fixed")) {
                arrayList.add("focus_mode_fixed");
                Log.d(TAG, " supports focus_mode_fixed");
            }
            if (list.contains("edof")) {
                arrayList.add("focus_mode_edof");
                Log.d(TAG, " supports focus_mode_edof");
            }
            if (list.contains("continuous-picture")) {
                arrayList.add("focus_mode_continuous_picture");
                Log.d(TAG, " supports focus_mode_continuous_picture");
            }
            if (list.contains("continuous-video")) {
                arrayList.add("focus_mode_continuous_video");
                Log.d(TAG, " supports focus_mode_continuous_video");
            }
        }
        return arrayList;
    }

    @Override // com.gpsmapcamera.geotagginglocationonphoto.Camera.cameracontroller.CameraController
    public CameraController.CameraFeatures getCameraFeatures() throws CameraControllerException {
        Log.d(TAG, "getCameraFeatures()");
        try {
            Camera.Parameters parameters = getParameters();
            CameraController.CameraFeatures cameraFeatures = new CameraController.CameraFeatures();
            cameraFeatures.is_zoom_supported = parameters.isZoomSupported();
            if (cameraFeatures.is_zoom_supported) {
                cameraFeatures.max_zoom = parameters.getMaxZoom();
                try {
                    cameraFeatures.zoom_ratios = parameters.getZoomRatios();
                } catch (NumberFormatException e) {
                    Log.e(TAG, "NumberFormatException in getZoomRatios()");
                    e.printStackTrace();
                    cameraFeatures.is_zoom_supported = false;
                    cameraFeatures.max_zoom = 0;
                    cameraFeatures.zoom_ratios = null;
                }
            }
            boolean z = true;
            cameraFeatures.supports_face_detection = parameters.getMaxNumDetectedFaces() > 0;
            List<Camera.Size> supportedPictureSizes = parameters.getSupportedPictureSizes();
            if (supportedPictureSizes == null) {
                Log.e(TAG, "getSupportedPictureSizes() returned null!");
                throw new CameraControllerException();
            }
            cameraFeatures.picture_sizes = new ArrayList();
            for (Camera.Size size : supportedPictureSizes) {
                cameraFeatures.picture_sizes.add(new CameraController.Size(size.width, size.height));
            }
            Collections.sort(cameraFeatures.picture_sizes, new CameraController.SizeSorter());
            cameraFeatures.supported_flash_values = convertFlashModesToValues(parameters.getSupportedFlashModes());
            cameraFeatures.supported_focus_values = convertFocusModesToValues(parameters.getSupportedFocusModes());
            cameraFeatures.max_num_focus_areas = parameters.getMaxNumFocusAreas();
            cameraFeatures.is_exposure_lock_supported = parameters.isAutoExposureLockSupported();
            cameraFeatures.is_white_balance_lock_supported = parameters.isAutoWhiteBalanceLockSupported();
            cameraFeatures.is_video_stabilization_supported = parameters.isVideoStabilizationSupported();
            cameraFeatures.is_photo_video_recording_supported = parameters.isVideoSnapshotSupported();
            cameraFeatures.min_exposure = parameters.getMinExposureCompensation();
            cameraFeatures.max_exposure = parameters.getMaxExposureCompensation();
            cameraFeatures.exposure_step = getExposureCompensationStep();
            cameraFeatures.supports_expo_bracketing = (cameraFeatures.min_exposure == 0 || cameraFeatures.max_exposure == 0) ? false : false;
            cameraFeatures.max_expo_bracketing_n_images = 3;
            List<Camera.Size> supportedVideoSizes = parameters.getSupportedVideoSizes();
            if (supportedVideoSizes == null) {
                Log.d(TAG, "take video_sizes from preview sizes");
                supportedVideoSizes = parameters.getSupportedPreviewSizes();
            }
            cameraFeatures.video_sizes = new ArrayList();
            for (Camera.Size size2 : supportedVideoSizes) {
                cameraFeatures.video_sizes.add(new CameraController.Size(size2.width, size2.height));
            }
            Collections.sort(cameraFeatures.video_sizes, new CameraController.SizeSorter());
            List<Camera.Size> supportedPreviewSizes = parameters.getSupportedPreviewSizes();
            cameraFeatures.preview_sizes = new ArrayList();
            for (Camera.Size size3 : supportedPreviewSizes) {
                cameraFeatures.preview_sizes.add(new CameraController.Size(size3.width, size3.height));
            }
            Log.d(TAG, "camera parameters: " + parameters.flatten());
            if (Build.VERSION.SDK_INT >= 17) {
                cameraFeatures.can_disable_shutter_sound = this.camera_info.canDisableShutterSound;
            } else {
                cameraFeatures.can_disable_shutter_sound = false;
            }
            try {
                cameraFeatures.view_angle_x = parameters.getHorizontalViewAngle();
                cameraFeatures.view_angle_y = parameters.getVerticalViewAngle();
            } catch (Exception e2) {
                e2.printStackTrace();
                Log.e(TAG, "exception reading horizontal or vertical view angles");
                cameraFeatures.view_angle_x = 55.0f;
                cameraFeatures.view_angle_y = 43.0f;
            }
            Log.d(TAG, "view_angle_x: " + cameraFeatures.view_angle_x);
            Log.d(TAG, "view_angle_y: " + cameraFeatures.view_angle_y);
            if (cameraFeatures.view_angle_x > 150.0f || cameraFeatures.view_angle_y > 150.0f) {
                Log.e(TAG, "camera API reporting stupid view angles, set to sensible defaults");
                cameraFeatures.view_angle_x = 55.0f;
                cameraFeatures.view_angle_y = 43.0f;
            }
            return cameraFeatures;
        } catch (RuntimeException e3) {
            Log.e(TAG, "failed to get camera parameters");
            e3.printStackTrace();
            throw new CameraControllerException();
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.SupportedValues setSceneMode(String str) {
        String sceneMode;
        try {
            Camera.Parameters parameters = getParameters();
            CameraController.SupportedValues checkModeIsSupported = checkModeIsSupported(parameters.getSupportedSceneModes(), str, "auto");
            if (checkModeIsSupported != null && (sceneMode = parameters.getSceneMode()) != null && !sceneMode.equals(checkModeIsSupported.selected_value)) {
                parameters.setSceneMode(checkModeIsSupported.selected_value);
                setCameraParameters(parameters);
            }
            return checkModeIsSupported;
        } catch (RuntimeException e) {
            Log.e(TAG, "exception from getParameters");
            e.printStackTrace();
            this.count_camera_parameters_exception++;
            return null;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public String getSceneMode() {
        return getParameters().getSceneMode();
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.SupportedValues setColorEffect(String str) {
        String colorEffect;
        Camera.Parameters parameters = getParameters();
        CameraController.SupportedValues checkModeIsSupported = checkModeIsSupported(parameters.getSupportedColorEffects(), str, "none");
        if (checkModeIsSupported != null && ((colorEffect = parameters.getColorEffect()) == null || !colorEffect.equals(checkModeIsSupported.selected_value))) {
            parameters.setColorEffect(checkModeIsSupported.selected_value);
            setCameraParameters(parameters);
        }
        return checkModeIsSupported;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public String getColorEffect() {
        return getParameters().getColorEffect();
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.SupportedValues setWhiteBalance(String str) {
        String whiteBalance;
        Log.d(TAG, "setWhiteBalance: " + str);
        Camera.Parameters parameters = getParameters();
        List<String> supportedWhiteBalance = parameters.getSupportedWhiteBalance();
        if (supportedWhiteBalance != null) {
            while (supportedWhiteBalance.contains("manual")) {
                supportedWhiteBalance.remove("manual");
            }
        }
        CameraController.SupportedValues checkModeIsSupported = checkModeIsSupported(supportedWhiteBalance, str, "auto");
        if (checkModeIsSupported != null && (whiteBalance = parameters.getWhiteBalance()) != null && !whiteBalance.equals(checkModeIsSupported.selected_value)) {
            parameters.setWhiteBalance(checkModeIsSupported.selected_value);
            setCameraParameters(parameters);
        }
        return checkModeIsSupported;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public String getWhiteBalance() {
        return getParameters().getWhiteBalance();
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.SupportedValues setAntiBanding(String str) {
        String antibanding;
        Camera.Parameters parameters = getParameters();
        CameraController.SupportedValues checkModeIsSupported = checkModeIsSupported(parameters.getSupportedAntibanding(), str, "auto");
        if (checkModeIsSupported != null && checkModeIsSupported.selected_value.equals(str) && ((antibanding = parameters.getAntibanding()) == null || !antibanding.equals(checkModeIsSupported.selected_value))) {
            parameters.setAntibanding(checkModeIsSupported.selected_value);
            setCameraParameters(parameters);
        }
        return checkModeIsSupported;
    }

    @Override
    public String getAntiBanding() {
        return getParameters().getAntibanding();
    }

    @Override
    public CameraController.SupportedValues setISO(String str) {
        ArrayList arrayList0;
        Camera.Parameters camera$Parameters0 = this.getParameters();
        String s1 = camera$Parameters0.get("iso-values");
        if(s1 == null) {
            s1 = camera$Parameters0.get("iso-mode-values");
            if(s1 == null) {
                s1 = camera$Parameters0.get("iso-speed-values");
                if(s1 == null) {
                    s1 = camera$Parameters0.get("nv-picture-iso-values");
                }
            }
        }

        if(s1 != null && s1.length() > 0) {
            Log.d("CameraController1", "iso_values: " + s1);
            String[] arr_s = s1.split(",");
            if(arr_s.length > 0) {
                HashSet hashSet0 = new HashSet();
                arrayList0 = new ArrayList();
                int v;
                for(v = 0; v < arr_s.length; ++v) {
                    String s2 = arr_s[v];
                    if(!hashSet0.contains(s2)) {
                        arrayList0.add(s2);
                        hashSet0.add(s2);
                    }
                }
            }
            else {
                arrayList0 = null;
            }
        }
        else {
            arrayList0 = null;
        }

        this.iso_key = "iso";
        if(camera$Parameters0.get("iso") == null) {
            this.iso_key = "iso-speed";
            if(camera$Parameters0.get("iso-speed") == null) {
                this.iso_key = "nv-picture-iso";
                if(camera$Parameters0.get("nv-picture-iso") == null) {
                    this.iso_key = Build.MODEL.contains("Z00") ? "iso" : null;
                }
            }
        }

        if(this.iso_key != null) {
            if(arrayList0 == null) {
                arrayList0 = new ArrayList();
                arrayList0.add("auto");
                arrayList0.add("50");
                arrayList0.add("100");
                arrayList0.add("200");
                arrayList0.add("400");
                arrayList0.add("800");
                arrayList0.add("1600");
            }

            SupportedValues cameraController$SupportedValues0 = this.checkModeIsSupported(arrayList0, str, "auto");
            if(cameraController$SupportedValues0 != null) {
                Log.d("CameraController1", "set: " + this.iso_key + " to: " + cameraController$SupportedValues0.selected_value);
                camera$Parameters0.set(this.iso_key, cameraController$SupportedValues0.selected_value);
                this.setCameraParameters(camera$Parameters0);
            }

            return cameraController$SupportedValues0;
        }

        return null;
    }

    @Override
    public String getISOKey() {
        Log.d(TAG, "getISOKey");
        return this.iso_key;
    }

    @Override
    public CameraController.Size getPictureSize() {
        return new CameraController.Size(this.picture_width, this.picture_height);
    }

    @Override
    public void setPictureSize(int i, int i2) {
        Camera.Parameters parameters = getParameters();
        this.picture_width = i;
        this.picture_height = i2;
        parameters.setPictureSize(i, i2);
        Log.d(TAG, "set picture size: " + parameters.getPictureSize().width + ", " + parameters.getPictureSize().height);
        setCameraParameters(parameters);
    }

    @Override
    public CameraController.Size getPreviewSize() {
        Camera.Size previewSize = getParameters().getPreviewSize();
        return new CameraController.Size(previewSize.width, previewSize.height);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setPreviewSize(int i, int i2) {
        Camera.Parameters parameters = getParameters();
        String str = TAG;
        Log.d(str, "current preview size: " + parameters.getPreviewSize().width + ", " + parameters.getPreviewSize().height);
        parameters.setPreviewSize(i, i2);
        Log.d(str, "new preview size: " + parameters.getPreviewSize().width + ", " + parameters.getPreviewSize().height);
        setCameraParameters(parameters);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setBurstType(CameraController.BurstType burstType) {
        Log.d(TAG, "setBurstType: " + burstType);
        if (this.camera == null) {
            Log.e(TAG, "no camera");
        } else if (burstType != CameraController.BurstType.BURSTTYPE_NONE && burstType != CameraController.BurstType.BURSTTYPE_EXPO) {
            Log.e(TAG, "burst type not supported");
        } else {
            this.want_expo_bracketing = burstType == CameraController.BurstType.BURSTTYPE_EXPO;
        }
    }

    @Override
    public CameraController.BurstType getBurstType() {
        return this.want_expo_bracketing ? CameraController.BurstType.BURSTTYPE_EXPO : CameraController.BurstType.BURSTTYPE_NONE;
    }

    @Override
    public void setExpoBracketingNImages(int i) {
        Log.d(TAG, "setExpoBracketingNImages: " + i);
        if (i<=1 || i % 2 == 0) {
            Log.e(TAG, "n_images should be an odd number greater than 1");
            throw new RuntimeException();
        }
        if (i>3) {
            Log.e(TAG, "limiting n_images to max of 3");
            i = 3;
        }
        this.expo_bracketing_n_images = i;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setExpoBracketingStops(double d) {
        Log.d(TAG, "setExpoBracketingStops: " + d);
        if (d<=0.0d) {
            Log.e(TAG, "stops should be positive");
            throw new RuntimeException();
        } else {
            this.expo_bracketing_stops = d;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean isCapturingBurst() {
        return getBurstTotal()>1 && getNBurstTaken()<getBurstTotal();
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getNBurstTaken() {
        return this.pending_burst_images.size();
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getBurstTotal() {
        return this.n_burst;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setVideoStabilization(boolean z) {
        Camera.Parameters parameters = getParameters();
        parameters.setVideoStabilization(z);
        setCameraParameters(parameters);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean getVideoStabilization() {
        try {
            return getParameters().getVideoStabilization();
        } catch (RuntimeException e) {
            Log.e(TAG, "failed to get parameters for video stabilization");
            e.printStackTrace();
            this.count_camera_parameters_exception++;
            return false;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public CameraController.TonemapProfile getTonemapProfile() {
        return CameraController.TonemapProfile.TONEMAPPROFILE_OFF;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getJpegQuality() {
        return getParameters().getJpegQuality();
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setJpegQuality(int i) {
        Camera.Parameters parameters = getParameters();
        parameters.setJpegQuality(i);
        setCameraParameters(parameters);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getZoom() {
        return this.current_zoom_value;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setZoom(int i) {
        try {
            Camera.Parameters parameters = getParameters();
            Log.d(TAG, "zoom was: " + parameters.getZoom());
            this.current_zoom_value = i;
            parameters.setZoom(i);
            setCameraParameters(parameters);
        } catch (RuntimeException e) {
            Log.e(TAG, "failed to set parameters for zoom");
            e.printStackTrace();
            this.count_camera_parameters_exception++;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void resetZoom() {
        setZoom(0);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public int getExposureCompensation() {
        return this.current_exposure_compensation;
    }

    private float getExposureCompensationStep() {
        try {
            return getParameters().getExposureCompensationStep();
        } catch (Exception e) {
            Log.e(TAG, "exception from getExposureCompensationStep()");
            e.printStackTrace();
            return 0.33333334f;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean setExposureCompensation(int i) {
        if (i != this.current_exposure_compensation) {
            Log.d(TAG, "change exposure from " + this.current_exposure_compensation + " to " + i);
            Camera.Parameters parameters = getParameters();
            this.current_exposure_compensation = i;
            parameters.setExposureCompensation(i);
            setCameraParameters(parameters);
            return true;
        }
        return false;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setPreviewFpsRange(int i, int i2) {
        Log.d(TAG, "setPreviewFpsRange: " + i + " to " + i2);
        try {
            Camera.Parameters parameters = getParameters();
            parameters.setPreviewFpsRange(i, i2);
            setCameraParameters(parameters);
        } catch (RuntimeException e) {
            Log.e(TAG, "setPreviewFpsRange failed to get parameters");
            e.printStackTrace();
            this.count_camera_parameters_exception++;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void clearPreviewFpsRange() {
        Log.d(TAG, "clearPreviewFpsRange");
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public List<int[]> getSupportedPreviewFpsRange() {
        try {
            return getParameters().getSupportedPreviewFpsRange();
        } catch (RuntimeException e) {
            e.printStackTrace();
            this.count_camera_parameters_exception++;
            return null;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setFocusValue(String str) {
        Camera.Parameters parameters = getParameters();
        str.hashCode();
        char c = 65535;
        switch (str.hashCode()) {
            case -2084726721:
                if (str.equals("focus_mode_locked")) {
                    c = 0;
                    break;
                }
                break;
            case -1897460700:
                if (str.equals("focus_mode_auto")) {
                    c = 1;
                    break;
                }
                break;
            case -1897358037:
                if (str.equals("focus_mode_edof")) {
                    c = 2;
                    break;
                }
                break;
            case -711944829:
                if (str.equals("focus_mode_continuous_picture")) {
                    c = 3;
                    break;
                }
                break;
            case 402565696:
                if (str.equals("focus_mode_continuous_video")) {
                    c = 4;
                    break;
                }
                break;
            case 590698013:
                if (str.equals("focus_mode_infinity")) {
                    c = 5;
                    break;
                }
                break;
            case 1312524191:
                if (str.equals("focus_mode_fixed")) {
                    c = 6;
                    break;
                }
                break;
            case 1318730743:
                if (str.equals("focus_mode_macro")) {
                    c = 7;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
            case 1:
                parameters.setFocusMode("auto");
                break;
            case 2:
                parameters.setFocusMode("edof");
                break;
            case 3:
                parameters.setFocusMode("continuous-picture");
                break;
            case 4:
                parameters.setFocusMode("continuous-video");
                break;
            case 5:
                parameters.setFocusMode("infinity");
                break;
            case 6:
                parameters.setFocusMode("fixed");
                break;
            case 7:
                parameters.setFocusMode("macro");
                break;
            default:
                Log.d(TAG, "setFocusValue() received unknown focus value " + str);
                break;
        }
        setCameraParameters(parameters);
    }

    private String convertFocusModeToValue(String str) {
        Log.d(TAG, "convertFocusModeToValue: " + str);
        if (str != null) {
            if (str.equals("auto")) {
                return "focus_mode_auto";
            }
            if (str.equals("infinity")) {
                return "focus_mode_infinity";
            }
            if (str.equals("macro")) {
                return "focus_mode_macro";
            }
            if (str.equals("fixed")) {
                return "focus_mode_fixed";
            }
            if (str.equals("edof")) {
                return "focus_mode_edof";
            }
            if (str.equals("continuous-picture")) {
                return "focus_mode_continuous_picture";//Changed
            }
            if (str.equals("continuous-video")) {
                return "focus_mode_continuous_video";
            }
        }
        return "";
    }

    @Override
    public String getFocusValue() {
        return convertFocusModeToValue(getParameters().getFocusMode());
    }

    private String convertFlashValueToMode(String flash_value) {
        String flash_mode = "";
        switch(flash_value) {
            case "flash_off":
            case "flash_frontscreen_on":
            case "flash_frontscreen_torch":
                flash_mode = Camera.Parameters.FLASH_MODE_OFF;
                break;
            case "flash_auto":
                flash_mode = Camera.Parameters.FLASH_MODE_AUTO;
                break;
            case "flash_on":
                flash_mode = Camera.Parameters.FLASH_MODE_ON;
                break;
            case "flash_torch":
                flash_mode = Camera.Parameters.FLASH_MODE_TORCH;
                break;
            case "flash_red_eye":
                flash_mode = Camera.Parameters.FLASH_MODE_RED_EYE;
                break;
        }
        return flash_mode;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setFlashValue(String str) {
        Camera.Parameters parameters = getParameters();
        Log.d(TAG, "setFlashValue: " + str);
        this.frontscreen_flash = false;
        if (str.equals("flash_frontscreen_on")) {
            this.frontscreen_flash = true;
        } else if (parameters.getFlashMode() == null) {
            Log.d(TAG, "flash mode not supported");
        } else {
            final String convertFlashValueToMode = convertFlashValueToMode(str);
            if (convertFlashValueToMode.length()<=0 || convertFlashValueToMode.equals(parameters.getFlashMode())) {
                return;
            }
            if (parameters.getFlashMode().equals("torch") && !convertFlashValueToMode.equals(DebugKt.DEBUG_PROPERTY_VALUE_OFF)) {
                Log.d(TAG, "first turn torch off");
                parameters.setFlashMode(DebugKt.DEBUG_PROPERTY_VALUE_OFF);
                setCameraParameters(parameters);
                new Handler().postDelayed(new Runnable() { // from class: com.live.gpsmap.camera.Camera.cameracontroller.CameraController1.1
                    @Override // java.lang.Runnable
                    public void run() {
                        Log.d(CameraController1.TAG, "now set actual flash mode after turning torch off");
                        if (CameraController1.this.camera != null) {
                            Camera.Parameters parameters2 = CameraController1.this.getParameters();
                            parameters2.setFlashMode(convertFlashValueToMode);
                            CameraController1.this.setCameraParameters(parameters2);
                        }
                    }
                }, 100L);
                return;
            }
            parameters.setFlashMode(convertFlashValueToMode);
            setCameraParameters(parameters);
        }
    }

    private String convertFlashModeToValue(String str) {
        Log.d(TAG, "convertFlashModeToValue: " + str);
        if (str != null) {
            if (str.equals(DebugKt.DEBUG_PROPERTY_VALUE_OFF)) {
                return "flash_off";
            }
            if (str.equals("auto")) {
                return /*nXtPBjQgziZk.ucPpPE*/"flash_auto";//Changed
            }
            if (str.equals(DebugKt.DEBUG_PROPERTY_VALUE_ON)) {
                return "flash_on";
            }
            if (str.equals("torch")) {
                return "flash_torch";
            }
            if (str.equals("red-eye")) {
                return "flash_red_eye";
            }
        }
        return "";
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public String getFlashValue() {
        return convertFlashModeToValue(getParameters().getFlashMode());
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setRecordingHint(boolean z) {
        Log.d(TAG, "setRecordingHint: " + z);
        try {
            Camera.Parameters parameters = getParameters();
            String focusMode = parameters.getFocusMode();
            if (focusMode == null || focusMode.equals("continuous-video")) {
                return;
            }
            parameters.setRecordingHint(z);
            setCameraParameters(parameters);
        } catch (RuntimeException e) {
            Log.e(TAG, "setRecordingHint failed to get parameters");
            e.printStackTrace();
            this.count_camera_parameters_exception++;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setAutoExposureLock(boolean z) {
        Camera.Parameters parameters = getParameters();
        parameters.setAutoExposureLock(z);
        setCameraParameters(parameters);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean getAutoExposureLock() {
        Camera.Parameters parameters = getParameters();
        if (parameters.isAutoExposureLockSupported()) {
            return parameters.getAutoExposureLock();
        }
        return false;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setAutoWhiteBalanceLock(boolean z) {
        Camera.Parameters parameters = getParameters();
        parameters.setAutoWhiteBalanceLock(z);
        setCameraParameters(parameters);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean getAutoWhiteBalanceLock() {
        Camera.Parameters parameters = getParameters();
        if (parameters.isAutoWhiteBalanceLockSupported()) {
            return parameters.getAutoWhiteBalanceLock();
        }
        return false;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void setRotation(int i) {
        Camera.Parameters parameters = getParameters();
        parameters.setRotation(i);
        setCameraParameters(parameters);
    }

    @Override
    public void setLocationInfo(Location location) {
        Log.d(TAG, "setLocationInfo");
        Camera.Parameters parameters = getParameters();
        parameters.removeGpsData();
        parameters.setGpsTimestamp(System.currentTimeMillis() / 1000);
        parameters.setGpsLatitude(location.getLatitude());
        parameters.setGpsLongitude(location.getLongitude());
        parameters.setGpsProcessingMethod(location.getProvider());
        if (location.hasAltitude()) {
            parameters.setGpsAltitude(location.getAltitude());
        } else {
            parameters.setGpsAltitude(0.0d);
        }
        if (location.getTime() != 0) {
            parameters.setGpsTimestamp(location.getTime() / 1000);
        }
        setCameraParameters(parameters);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void removeLocationInfo() {
        Camera.Parameters parameters = getParameters();
        parameters.removeGpsData();
        setCameraParameters(parameters);
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void enableShutterSound(boolean z) {
        if (Build.VERSION.SDK_INT>=17) {
            this.camera.enableShutterSound(false);
        }
        this.sounds_enabled = z;
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public boolean setFocusAndMeteringArea(List<Area> list) {
        ArrayList arrayList = new ArrayList();
        for (CameraController.Area area : list) {
            arrayList.add(new Camera.Area(area.rect, area.weight));
        }
        try {
            Camera.Parameters parameters = getParameters();
            String focusMode = parameters.getFocusMode();
            if (parameters.getMaxNumFocusAreas() != 0 && focusMode != null && (focusMode.equals("auto") || focusMode.equals("macro") || focusMode.equals("continuous-picture") || focusMode.equals("continuous-video"))) {
                parameters.setFocusAreas(arrayList);
                if (parameters.getMaxNumMeteringAreas() == 0) {
                    Log.d(TAG, "metering areas not supported");
                } else {
                    parameters.setMeteringAreas(arrayList);
                }
                setCameraParameters(parameters);
                return true;
            } else if (parameters.getMaxNumMeteringAreas() != 0) {
                parameters.setMeteringAreas(arrayList);
                setCameraParameters(parameters);
                return false;
            } else {
                Log.d(TAG, "metering areas not supported");
                return false;
            }
        } catch (RuntimeException e) {
            e.printStackTrace();
            this.count_camera_parameters_exception++;
            return false;
        }
    }

    @Override // com.live.gpsmap.camera.Camera.cameracontroller.CameraController
    public void clearFocusAndMetering() {
        try {
            Camera.Parameters parameters = getParameters();
            boolean z = false;
            if (parameters.getMaxNumFocusAreas()>0) {
                parameters.setFocusAreas(null);
                z = true;
            }
            if (parameters.getMaxNumMeteringAreas()>0) {
                parameters.setMeteringAreas(null);
                z = true;
            }
            if (z) {
                setCameraParameters(parameters);
            }
        } catch (RuntimeException e) {
            e.printStackTrace();
            this.count_camera_parameters_exception++;
        }
    }

    @Override
    public List<Area> getFocusAreas() {
        List<Camera.Area> focusAreas = getParameters().getFocusAreas();
        if (focusAreas == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (Camera.Area area : focusAreas) {
            arrayList.add(new CameraController.Area(area.rect, area.weight));
        }
        return arrayList;
    }

    @Override
    public List<Area> getMeteringAreas() {
        List<Camera.Area> meteringAreas = getParameters().getMeteringAreas();
        if (meteringAreas == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (Camera.Area area : meteringAreas) {
            arrayList.add(new CameraController.Area(area.rect, area.weight));
        }
        return arrayList;
    }

    @Override
    public boolean supportsAutoFocus() {
        try {
            String focusMode = getParameters().getFocusMode();
            if (focusMode != null) {
                if (!focusMode.equals("auto")) {
                    if (!focusMode.equals("macro")) {
                        return false;
                    }
                }
                return true;
            }
            return false;
        } catch (RuntimeException e) {
            e.printStackTrace();
            this.count_camera_parameters_exception++;
            return false;
        }
    }

    @Override
    public boolean supportsMetering() {
        try {
            return getParameters().getMaxNumMeteringAreas()>0;
        } catch (RuntimeException e) {
            e.printStackTrace();
            this.count_camera_parameters_exception++;
            return false;
        }
    }

    @Override
    public boolean focusIsContinuous() {
        try {
            String focusMode = getParameters().getFocusMode();
            if (focusMode != null) {
                if (!focusMode.equals("continuous-picture")) {
                    if (!focusMode.equals("continuous-video")) {
                        return false;
                    }
                }
                return true;
            }
            return false;
        } catch (RuntimeException e) {
            e.printStackTrace();
            this.count_camera_parameters_exception++;
            return false;
        }
    }

    @Override
    public boolean focusIsVideo() {
        String focusMode = getParameters().getFocusMode();
        boolean z = focusMode != null && focusMode.equals("continuous-video");
        Log.d(TAG, "current_focus_mode: " + focusMode);
        Log.d(TAG, "focus_is_video: " + z);
        return z;
    }

    @Override
    public void reconnect() throws CameraControllerException {
        Log.d(TAG, "reconnect");
        try {
            this.camera.reconnect();
        } catch (IOException e) {
            Log.e(TAG, "reconnect threw IOException");
            e.printStackTrace();
            throw new CameraControllerException();
        }
    }

    @Override
    public void setPreviewDisplay(SurfaceHolder surfaceHolder) throws CameraControllerException {
        Log.d(TAG, "setPreviewDisplay");
        try {
            this.camera.setPreviewDisplay(surfaceHolder);
        } catch (IOException e) {
            e.printStackTrace();
            throw new CameraControllerException();
        }
    }

    @Override
    public void setPreviewTexture(TextureView textureView) throws CameraControllerException {
        try {
            this.camera.setPreviewTexture(textureView.getSurfaceTexture());
        } catch (IOException e) {
            e.printStackTrace();
            throw new CameraControllerException();
        }
    }

    @Override
    public void startPreview() throws CameraControllerException {
        Log.d(TAG, "startPreview");
        try {
            this.camera.startPreview();
        } catch (RuntimeException e) {
            Log.e(TAG, "failed to start preview");
            e.printStackTrace();
            throw new CameraControllerException();
        }
    }

    @Override
    public void stopPreview() {
        Camera camera = this.camera;
        if (camera != null) {
            camera.stopPreview();
        }
    }

    @Override
    public boolean startFaceDetection() {
        Log.d(TAG, "startFaceDetection");
        try {
            this.camera.startFaceDetection();
            return true;
        } catch (RuntimeException unused) {
            Log.d(TAG, "face detection failed or already started");
            this.count_camera_parameters_exception++;
            return false;
        }
    }

    @Override
    public void setFaceDetectionListener(final CameraController.FaceDetectionListener faceDetectionListener) {
        if (faceDetectionListener != null) {
            this.camera.setFaceDetectionListener(new Camera.FaceDetectionListener() {
                @Override
                public void onFaceDetection(Camera.Face[] faceArr, Camera camera) {
                    CameraController.Face[] faceArr2 = new CameraController.Face[faceArr.length];
                    for (int i = 0; i<faceArr.length; i++) {
                        faceArr2[i] = new CameraController.Face(faceArr[i].score, faceArr[i].rect);
                    }
                    faceDetectionListener.onFaceDetection(faceArr2);
                }
            });
        } else {
            this.camera.setFaceDetectionListener(null);
        }
    }

    @Override
    public void autoFocus(final CameraController.AutoFocusCallback autoFocusCallback, boolean z) {
        Log.d(TAG, "autoFocus");
        try {
            this.camera.autoFocus(new Camera.AutoFocusCallback() {
                boolean done_autofocus = false;
                @Override
                public void onAutoFocus(boolean z2, Camera camera) {
                    Log.d(CameraController1.TAG, "autoFocus.onAutoFocus");
                    if (!this.done_autofocus) {
                        this.done_autofocus = true;
                        autoFocusCallback.onAutoFocus(z2);
                        return;
                    }
                    Log.e(CameraController1.TAG, "ignore repeated autofocus");
                }
            });
        } catch (RuntimeException e) {
            Log.e(TAG, "runtime exception from autoFocus");
            e.printStackTrace();
            autoFocusCallback.onAutoFocus(false);
        }
    }

    @Override
    public void cancelAutoFocus() {
        try {
            this.camera.cancelAutoFocus();
        } catch (RuntimeException e) {
            Log.d(TAG, "cancelAutoFocus() failed");
            e.printStackTrace();
        }
    }

    @Override
    public void setContinuousFocusMoveCallback(final CameraController.ContinuousFocusMoveCallback continuousFocusMoveCallback) {
        Log.d(TAG, "setContinuousFocusMoveCallback");
        if (Build.VERSION.SDK_INT>=16) {
            try {
                if (continuousFocusMoveCallback != null) {
                    this.camera.setAutoFocusMoveCallback(new Camera.AutoFocusMoveCallback() {
                        @Override
                        public void onAutoFocusMoving(boolean z, Camera camera) {
                            Log.d(CameraController1.TAG, "onAutoFocusMoving: " + z);
                            continuousFocusMoveCallback.onContinuousFocusMove(z);
                        }
                    });
                } else {
                    this.camera.setAutoFocusMoveCallback(null);
                }
                return;
            } catch (RuntimeException e) {
                Log.e(TAG, "runtime exception from setAutoFocusMoveCallback");
                e.printStackTrace();
                return;
            }
        }
        Log.d(TAG, "setContinuousFocusMoveCallback requires Android JELLY_BEAN or higher");
    }

    public static class TakePictureShutterCallback implements Camera.ShutterCallback {
        private TakePictureShutterCallback() {
        }

        @Override
        public void onShutter() {
            Log.d(CameraController1.TAG, "shutterCallback.onShutter()");
        }
    }

    private void clearPending() {
        this.pending_burst_images.clear();
        this.burst_exposures = null;
        this.n_burst = 0;
    }


//    public void takePictureNow(final CameraController.PictureCallback pictureCallback, final CameraController.ErrorCallback errorCallback) {
//        Log.d(TAG, "takePictureNow");
//        if (this.sounds_enabled) {
//            new TakePictureShutterCallback();
//        }
//        Camera.PictureCallback pictureCallback2 = pictureCallback == null ? null : new Camera.PictureCallback() {
//            @Override
//            public void onPictureTaken(byte[] bArr, Camera camera) {
//                Log.d(CameraController1.TAG, "onPictureTaken");
//                if (CameraController1.this.want_expo_bracketing && CameraController1.this.n_burst>1) {
//                    CameraController1.this.pending_burst_images.add(bArr);
//                    if (CameraController1.this.pending_burst_images.size()>=CameraController1.this.n_burst) {
//                        Log.d(CameraController1.TAG, "all burst images available");
//                        if (CameraController1.this.pending_burst_images.size()>CameraController1.this.n_burst) {
//                            Log.e(CameraController1.TAG, "pending_burst_images size " + CameraController1.this.pending_burst_images.size() + " is greater than n_burst " + CameraController1.this.n_burst);
//                        }
//                        CameraController1 cameraController1 = CameraController1.this;
//                        cameraController1.setExposureCompensation(((Integer) cameraController1.burst_exposures.get(0)).intValue());
//                        int size = CameraController1.this.pending_burst_images.size() / 2;
//                        ArrayList arrayList = new ArrayList();
//                        int i = 0;
//                        while (i<size) {
//                            i++;
//                            arrayList.add((byte[]) CameraController1.this.pending_burst_images.get(i));
//                        }
//                        arrayList.add((byte[]) CameraController1.this.pending_burst_images.get(0));
//                        for (int i2 = 0; i2<size; i2++) {
//                            arrayList.add((byte[]) CameraController1.this.pending_burst_images.get(size + 1));
//                        }
//                        pictureCallback.onBurstPictureTaken(arrayList);
//                        CameraController1.this.pending_burst_images.clear();
//                        pictureCallback.onCompleted();
//                        return;
//                    }
//                    Log.d(CameraController1.TAG, "number of burst images is now: " + CameraController1.this.pending_burst_images.size());
//                    CameraController1 cameraController12 = CameraController1.this;
//                    cameraController12.setExposureCompensation(((Integer) cameraController12.burst_exposures.get(CameraController1.this.pending_burst_images.size())).intValue());
//                    try {
//                        CameraController1.this.startPreview();
//                    } catch (CameraControllerException e) {
//                        Log.d(CameraController1.TAG, "CameraControllerException trying to startPreview");
//                        e.printStackTrace();
//                    }
//                    new Handler().postDelayed(new Runnable() {
//                        @Override
//                        public void run() {
//                            Log.d(CameraController1.TAG, "take picture after delay for next expo");
//                            if (CameraController1.this.camera != null) {
//                                CameraController1.this.takePictureNow(pictureCallback, errorCallback);
//                            }
//                        }
//                    }, 1000L);
//                    return;
//                }
//                pictureCallback.onPictureTaken(bArr);
//                pictureCallback.onCompleted();
//            }
//        };
//        if (pictureCallback != null) {
//            Log.d(TAG, "call onStarted() in callback");
//            pictureCallback.onStarted();
//        }
//        try {
//            this.camera.takePicture(null, null, pictureCallback2);
//        } catch (RuntimeException e) {
//            Log.e(TAG, "runtime exception from takePicture");
//            e.printStackTrace();
//            errorCallback.onError();
//        }
//    }

    private void takePictureNow(final CameraController.PictureCallback picture, final ErrorCallback error) {
        if( MyDebug.LOG )
            Log.d(TAG, "takePictureNow");

        // only set the shutter callback if sounds enabled
        final Camera.ShutterCallback shutter = sounds_enabled ? new TakePictureShutterCallback() : null;
        final Camera.PictureCallback camera_jpeg = picture == null ? null : new Camera.PictureCallback() {
            public void onPictureTaken(byte[] data, Camera cam) {
                if( MyDebug.LOG )
                    Log.d(TAG, "onPictureTaken");
                // n.b., this is automatically run in a different thread

                if( want_expo_bracketing && n_burst > 1 ) {
                    pending_burst_images.add(data);
                    if( pending_burst_images.size() >= n_burst ) { // shouldn't ever be greater, but just in case
                        if( MyDebug.LOG )
                            Log.d(TAG, "all burst images available");
                        if( pending_burst_images.size() > n_burst ) {
                            Log.e(TAG, "pending_burst_images size " + pending_burst_images.size() + " is greater than n_burst " + n_burst);
                        }

                        // set exposure compensation back to original
                        setExposureCompensation(burst_exposures.get(0));

                        // take a copy, so that we can clear pending_burst_images
                        // also allows us to reorder from dark to light
                        // since we took the images with the base exposure being first
                        int n_half_images = pending_burst_images.size()/2;
                        List<byte []> images = new ArrayList<>();
                        // darker images
                        for(int i=0;i<n_half_images;i++) {
                            images.add(pending_burst_images.get(i+1));
                        }
                        // base image
                        images.add(pending_burst_images.get(0));
                        // lighter images
                        for(int i=0;i<n_half_images;i++) {
                            images.add(pending_burst_images.get(n_half_images+1));
                        }

                        picture.onBurstPictureTaken(images);
                        pending_burst_images.clear();
                        picture.onCompleted();
                    }
                    else {
                        if( MyDebug.LOG )
                            Log.d(TAG, "number of burst images is now: " + pending_burst_images.size());
                        // set exposure compensation for next image
                        setExposureCompensation(burst_exposures.get(pending_burst_images.size()));

                        // need to start preview again: otherwise fail to take subsequent photos on Nexus 6
                        // and Nexus 7; on Galaxy Nexus we succeed, but exposure compensation has no effect
                        try {
                            startPreview();
                        }
                        catch(CameraControllerException e) {
                            if( MyDebug.LOG )
                                Log.d(TAG, "CameraControllerException trying to startPreview");
                            e.printStackTrace();
                        }

                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable(){
                            @Override
                            public void run(){
                                if( MyDebug.LOG )
                                    Log.d(TAG, "take picture after delay for next expo");
                                if( camera != null ) { // make sure camera wasn't released in the meantime
                                    takePictureNow(picture, error);
                                }
                            }
                        }, 1000);
                    }
                }
                else {
                    picture.onPictureTaken(data);
                    picture.onCompleted();
                }
            }
        };

        if( picture != null ) {
            if( MyDebug.LOG )
                Log.d(TAG, "call onStarted() in callback");
            picture.onStarted();
        }
        try {
            camera.takePicture(shutter, null, camera_jpeg);
        }
        catch(RuntimeException e) {
            // just in case? We got a RuntimeException report here from 1 user on Google Play; I also encountered it myself once of Galaxy Nexus when starting up
            if( MyDebug.LOG )
                Log.e(TAG, "runtime exception from takePicture");
            e.printStackTrace();
            error.onError();
        }
    }


//    @Override
//    public void takePicture(final CameraController.PictureCallback pictureCallback, final CameraController.ErrorCallback errorCallback) {
//        Log.d(TAG, "takePicture");
//        clearPending();
//        if (this.want_expo_bracketing) {
//            Log.d(TAG, "set up expo bracketing");
//            Camera.Parameters parameters = getParameters();
//            int i = this.expo_bracketing_n_images / 2;
//            int minExposureCompensation = parameters.getMinExposureCompensation();
//            int maxExposureCompensation = parameters.getMaxExposureCompensation();
//            float exposureCompensationStep = getExposureCompensationStep();
//            if (exposureCompensationStep == 0.0f) {
//                exposureCompensationStep = 0.33333334f;
//            }
//            int exposureCompensation = getExposureCompensation();
//            int max = Math.max((int) (((this.expo_bracketing_stops / i) + 1.0E-5d) / exposureCompensationStep), 1);
//            Log.d(TAG, "steps: " + max);
//            Log.d(TAG, "exposure_current: " + exposureCompensation);
//            ArrayList arrayList = new ArrayList();
//            arrayList.add(Integer.valueOf(exposureCompensation));
//            int i2 = 0;
//            for (int i3 = 0; i3<i; i3++) {
//                int max2 = Math.max(exposureCompensation - ((i - i3) * max), minExposureCompensation);
//                arrayList.add(Integer.valueOf(max2));
//                Log.d(TAG, "add burst request for " + i3 + "th dark image:");
//                StringBuilder sb = new StringBuilder();
//                sb.append("exposure: ");
//                sb.append(max2);
//                Log.d(TAG, sb.toString());
//            }
//            while (i2<i) {
//                int i4 = i2 + 1;
//                int min = Math.min((i4 * max) + exposureCompensation, maxExposureCompensation);
//                arrayList.add(Integer.valueOf(min));
//                Log.d(TAG, "add burst request for " + i2 + "th light image:");
//                StringBuilder sb2 = new StringBuilder();
//                sb2.append("exposure: ");
//                sb2.append(min);
//                Log.d(TAG, sb2.toString());
//                i2 = i4;
//            }
//            this.burst_exposures = arrayList;
//            this.n_burst = arrayList.size();
//        }
//        if (this.frontscreen_flash) {
//            Log.d(TAG, "front screen flash");
//            pictureCallback.onFrontScreenTurnOn();
//            new Handler().postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    Log.d(CameraController1.TAG, "take picture after delay for front screen flash");
//                    if (CameraController1.this.camera != null) {
//                        CameraController1.this.takePictureNow(pictureCallback, errorCallback);
//                    }
//                }
//            }, 1000L);
//            return;
//        }
//        takePictureNow(pictureCallback, errorCallback);
//    }

    public void takePicture(final CameraController.PictureCallback picture, final ErrorCallback error) {
        if( MyDebug.LOG )
            Log.d(TAG, "takePicture");

        clearPending();
        if( want_expo_bracketing ) {
            if( MyDebug.LOG )
                Log.d(TAG, "set up expo bracketing");
            Camera.Parameters parameters = this.getParameters();
            int n_half_images = expo_bracketing_n_images/2;
            int min_exposure = parameters.getMinExposureCompensation();
            int max_exposure = parameters.getMaxExposureCompensation();
            float exposure_step = getExposureCompensationStep();
            if( exposure_step == 0.0f ) // just in case?
                exposure_step = 1.0f/3.0f; // make up a typical example
            int exposure_current = getExposureCompensation();
            double stops_per_image = expo_bracketing_stops / (double)n_half_images;
            int steps = (int)((stops_per_image+1.0e-5) / exposure_step); // need to add a small amount, otherwise we can round down
            steps = Math.max(steps, 1);
            if( MyDebug.LOG ) {
                Log.d(TAG, "steps: " + steps);
                Log.d(TAG, "exposure_current: " + exposure_current);
            }

            List<Integer> requests = new ArrayList<>();

            // do the current exposure first, so we can take the first shot immediately
            // if we change the order, remember to update the code that re-orders for passing resultant images back to picture.onBurstPictureTaken()
            requests.add(exposure_current);

            // darker images
            for(int i=0;i<n_half_images;i++) {
                int exposure = exposure_current - (n_half_images-i)*steps;
                exposure = Math.max(exposure, min_exposure);
                requests.add(exposure);
                if( MyDebug.LOG ) {
                    Log.d(TAG, "add burst request for " + i + "th dark image:");
                    Log.d(TAG, "exposure: " + exposure);
                }
            }

            // lighter images
            for(int i=0;i<n_half_images;i++) {
                int exposure = exposure_current + (i+1)*steps;
                exposure = Math.min(exposure, max_exposure);
                requests.add(exposure);
                if( MyDebug.LOG ) {
                    Log.d(TAG, "add burst request for " + i + "th light image:");
                    Log.d(TAG, "exposure: " + exposure);
                }
            }

            burst_exposures = requests;
            n_burst = requests.size();
        }

        if( frontscreen_flash ) {
            if( MyDebug.LOG )
                Log.d(TAG, "front screen flash");
            picture.onFrontScreenTurnOn();
            // take picture after a delay, to allow autoexposure and autofocus to update (unlike CameraController2, we can't tell when this happens, so we just wait for a fixed delay)
            Handler handler = new Handler();
            handler.postDelayed(new Runnable(){
                @Override
                public void run(){
                    if( MyDebug.LOG )
                        Log.d(TAG, "take picture after delay for front screen flash");
                    if( camera != null ) { // make sure camera wasn't released in the meantime
                        takePictureNow(picture, error);
                    }
                }
            }, 1000);
            return;
        }
        takePictureNow(picture, error);
    }

    @Override
    public void setDisplayOrientation(int i) {
        int i2;
        if (this.camera_info.facing == 1) {
            i2 = (360 - ((this.camera_info.orientation + i) % 360)) % 360;
        } else {
            i2 = ((this.camera_info.orientation - i) + 360) % 360;
        }
        Log.d(TAG, "    info orientation is " + this.camera_info.orientation);
        Log.d(TAG, "    setDisplayOrientation to " + i2);
        try {
            this.camera.setDisplayOrientation(i2);
        } catch (RuntimeException e) {
            Log.e(TAG, "failed to set display orientation");
            e.printStackTrace();
        }
        this.display_orientation = i2;
    }

    @Override
    public int getDisplayOrientation() {
        return this.display_orientation;
    }

    @Override
    public int getCameraOrientation() {
        return this.camera_info.orientation;
    }

    @Override
    public CameraController.Facing getFacing() {
        int i = this.camera_info.facing;
        if (i != 0) {
            if (i == 1) {
                return CameraController.Facing.FACING_FRONT;
            }
            return CameraController.Facing.FACING_UNKNOWN;
        }
        return CameraController.Facing.FACING_BACK;
    }

    @Override
    public void unlock() {
        stopPreview();
        this.camera.unlock();
    }

    @Override
    public void initVideoRecorderPrePrepare(MediaRecorder mediaRecorder) {
        mediaRecorder.setCamera(this.camera);
    }

    @Override
    public String getParametersString() {
        try {
            return getParameters().flatten();
        } catch (Exception e) {
            Log.e(TAG, "exception from getParameters().flatten()");
            e.printStackTrace();
            return "";
        }
    }
}
