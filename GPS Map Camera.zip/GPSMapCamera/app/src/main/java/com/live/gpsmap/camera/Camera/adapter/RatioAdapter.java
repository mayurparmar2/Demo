package com.live.gpsmap.camera.Camera.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.live.gpsmap.camera.Camera.PreferenceKeys;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraController;
import com.live.gpsmap.camera.Camera.onRecyclerClickListener;
import com.live.gpsmap.camera.Camera.preview.Preview;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.SP;
import java.util.List;


public class RatioAdapter extends RecyclerView.Adapter<RatioAdapter.MyViewHolder> {
    Context mContext;
    onRecyclerClickListener mOnRecyclerClickListener;
    List<CameraController.Size> mRatio_entries;
    SP mSP;
    int selctedPos;

    public RatioAdapter(Context context, Preview preview, List<CameraController.Size> list, onRecyclerClickListener onrecyclerclicklistener) {
        this.mContext = context;
        this.mRatio_entries = list;
        SP sp = new SP(context);
        this.mSP = sp;
        this.mOnRecyclerClickListener = onrecyclerclicklistener;
        this.selctedPos = sp.getInteger(context, PreferenceKeys.getRatioPos_PrefrenceKey(preview.getCameraId()), 0);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_grid_dialog, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(MyViewHolder myViewHolder, @SuppressLint("RecyclerView") final int i) {
        if (myViewHolder instanceof MyViewHolder) {
            myViewHolder.tv_ratio.setText(Preview.getAspectRatioMPString(this.mContext.getResources(), this.mRatio_entries.get(i).width, this.mRatio_entries.get(i).height, true) + " ");
            if (this.selctedPos == i) {
                myViewHolder.imgTick.setImageResource(R.drawable.ic_radio_btn_yellow);
            } else {
                myViewHolder.imgTick.setImageResource(R.drawable.ic_radio_btn_white);
            }
            myViewHolder.main_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (RatioAdapter.this.mOnRecyclerClickListener != null) {
                        RatioAdapter.this.mOnRecyclerClickListener.setOnItemClickListener(i, view);
                    }
                    RatioAdapter.this.selctedPos = i;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            RatioAdapter.this.notifyDataSetChanged();
                        }
                    }, 150L);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        List<CameraController.Size> list = this.mRatio_entries;
        if (list == null) {
            return 0;
        }
        return list.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView imgTick;
        LinearLayout main_layout;
        TextView tv_ratio;

        public MyViewHolder(View view) {
            super(view);
            this.tv_ratio = (TextView) view.findViewById(R.id.tv_grid);
            this.imgTick = (ImageView) view.findViewById(R.id.img_tick);
            this.main_layout = (LinearLayout) view.findViewById(R.id.grid_layout);
        }
    }
}
