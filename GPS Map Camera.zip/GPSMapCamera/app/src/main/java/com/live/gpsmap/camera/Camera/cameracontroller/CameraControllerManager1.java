package com.live.gpsmap.camera.Camera.cameracontroller;

import android.content.Context;
import android.hardware.Camera;
import android.util.Log;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraController;
import com.live.gpsmap.camera.R;

public class CameraControllerManager1 extends CameraControllerManager {
    private static final String TAG = "CControllerManager1";

    @Override 
    public int getNumberOfCameras() {
        return Camera.getNumberOfCameras();
    }

    @Override 
    public CameraController.Facing getFacing(int i) {
        Camera.CameraInfo cameraInfo = null;
        int i2 = 0;
        try {
            cameraInfo = new Camera.CameraInfo();
            Camera.getCameraInfo(i, cameraInfo);
            i2 = cameraInfo.facing;
        } catch (RuntimeException e) {
            Log.e(TAG, "failed to get facing");
            e.printStackTrace();
        }
        if (i2 != 0) {
            if (i2 == 1) {
                return CameraController.Facing.FACING_FRONT;
            }
            Log.e(TAG, "unknown camera_facing: " + cameraInfo.facing);
            return CameraController.Facing.FACING_UNKNOWN;
        }
        return CameraController.Facing.FACING_BACK;
    }

  
    static class AnonymousClass1 {
        static final  int[] $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$Facing;

        static {
            int[] iArr = new int[CameraController.Facing.values().length];
            $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$Facing = iArr;
            try {
                iArr[CameraController.Facing.FACING_FRONT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$Facing[CameraController.Facing.FACING_BACK.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }

    @Override 
    public String getDescription(Context context, int i) {
        int i2 = AnonymousClass1.$SwitchMap$com$gpsmapcamera$geotagginglocationonphoto$Camera$cameracontroller$CameraController$Facing[getFacing(i).ordinal()];
        if (i2 != 1) {
            if (i2 != 2) {
                return null;
            }
            return context.getResources().getString(R.string.back_camera);
        }
        return context.getResources().getString(R.string.front_camera);
    }
}
