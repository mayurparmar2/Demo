package com.live.gpsmap.camera.Camera;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.os.Environment;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RSInvalidStateException;
import android.renderscript.RenderScript;
import android.renderscript.Script;
import android.renderscript.Type;
import android.util.Log;

import com.live.gpsmap.camera.Camera.Script.ScriptC_feature_detector;
import com.live.gpsmap.camera.Camera.Script.ScriptC_pyramid_blending;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

@SuppressWarnings("All")
public class PanoramaProcessor {
    private static final String TAG = "PanoramaProcessor";
    private static final int blend_n_levels = 4;
    private final Context context;
    private final HDRProcessor hdrProcessor;
    private RenderScript rs;
    private ScriptC_pyramid_blending pyramidBlendingScript = null;
    private ScriptC_feature_detector featureDetectorScript = null;

    public PanoramaProcessor(Context context, HDRProcessor hDRProcessor) {
        this.context = context;
        this.hdrProcessor = hDRProcessor;
    }

    private void freeScripts() {
        Log.d(TAG, "freeScripts");
        this.pyramidBlendingScript = null;
        this.featureDetectorScript = null;
    }

    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        freeScripts();
        RenderScript renderScript = this.rs;
        if (renderScript != null) {
            try {
                renderScript.destroy();
            } catch (RSInvalidStateException e) {
                e.printStackTrace();
            }
            this.rs = null;
        }
    }

    private void initRenderscript() {
        Log.d(TAG, "initRenderscript");
        if (this.rs == null) {
            this.rs = RenderScript.create(this.context);
            Log.d(TAG, "create renderscript object");
        }
    }

    private Allocation reduceBitmap(ScriptC_pyramid_blending scriptC_pyramid_blending, Allocation allocation) {
        Log.d(TAG, "reduceBitmap");
        int x = allocation.getType().getX();
        int y = allocation.getType().getY();
        RenderScript renderScript = this.rs;
        Allocation createTyped = Allocation.createTyped(renderScript, Type.createXY(renderScript, Element.RGBA_8888(renderScript), x / 2, y / 2));
        scriptC_pyramid_blending.set_bitmap(allocation);
        scriptC_pyramid_blending.forEach_reduce(createTyped, createTyped);
        return createTyped;
    }

    private Allocation expandBitmap(ScriptC_pyramid_blending scriptC_pyramid_blending, Allocation allocation) {
        Log.d(TAG, "expandBitmap");
        long currentTimeMillis = System.currentTimeMillis();
        int x = allocation.getType().getX();
        int y = allocation.getType().getY();
        RenderScript renderScript = this.rs;
        int i = x * 2;
        int i2 = y * 2;
        Allocation createTyped = Allocation.createTyped(renderScript, Type.createXY(renderScript, Element.RGBA_8888(renderScript), i, i2));
        Log.d(TAG, "### expandBitmap: time after creating expanded_allocation: " + (System.currentTimeMillis() - currentTimeMillis));
        scriptC_pyramid_blending.set_bitmap(allocation);
        scriptC_pyramid_blending.forEach_expand(createTyped, createTyped);
        Log.d(TAG, "### expandBitmap: time after expand: " + (System.currentTimeMillis() - currentTimeMillis));
        RenderScript renderScript2 = this.rs;
        Allocation createTyped2 = Allocation.createTyped(renderScript2, Type.createXY(renderScript2, Element.RGBA_8888(renderScript2), i, i2));
        Log.d(TAG, "### expandBitmap: time after creating temp_allocation: " + (System.currentTimeMillis() - currentTimeMillis));
        scriptC_pyramid_blending.set_bitmap(createTyped);
        scriptC_pyramid_blending.forEach_blur1dX(createTyped, createTyped2);
        Log.d(TAG, "### expandBitmap: time after blur1dX: " + (System.currentTimeMillis() - currentTimeMillis));
        scriptC_pyramid_blending.set_bitmap(createTyped2);
        scriptC_pyramid_blending.forEach_blur1dY(createTyped2, createTyped);
        Log.d(TAG, "### expandBitmap: time after blur1dY: " + (System.currentTimeMillis() - currentTimeMillis));
        createTyped2.destroy();
        return createTyped;
    }

    private Allocation subtractBitmap(ScriptC_pyramid_blending scriptC_pyramid_blending, Allocation allocation, Allocation allocation2) {
        Log.d(TAG, "subtractBitmap");
        int x = allocation.getType().getX();
        int y = allocation.getType().getY();
        if (allocation2.getType().getX() != x || allocation2.getType().getY() != y) {
            Log.e(TAG, "allocations of different dimensions");
            throw new RuntimeException();
        }
        RenderScript renderScript = this.rs;
        Allocation createTyped = Allocation.createTyped(renderScript, Type.createXY(renderScript, Element.F32_3(renderScript), x, y));
        scriptC_pyramid_blending.set_bitmap(allocation2);
        scriptC_pyramid_blending.forEach_subtract(allocation, createTyped);
        return createTyped;
    }

    private void addBitmap(ScriptC_pyramid_blending scriptC_pyramid_blending, Allocation allocation, Allocation allocation2) {
        Log.d(TAG, "addBitmap");
        int x = allocation.getType().getX();
        int y = allocation.getType().getY();
        if (allocation2.getType().getX() != x || allocation2.getType().getY() != y) {
            Log.e(TAG, "allocations of different dimensions");
            throw new RuntimeException();
        }
        scriptC_pyramid_blending.set_bitmap(allocation2);
        scriptC_pyramid_blending.forEach_add(allocation, allocation);
    }

    private List<Allocation> createGaussianPyramid(ScriptC_pyramid_blending scriptC_pyramid_blending, Bitmap bitmap, int i) {
        Log.d(TAG, "createGaussianPyramid");
        ArrayList arrayList = new ArrayList();
        Allocation createFromBitmap = Allocation.createFromBitmap(this.rs, bitmap);
        arrayList.add(createFromBitmap);
        for (int i2 = 0; i2 < i; i2++) {
            createFromBitmap = reduceBitmap(scriptC_pyramid_blending, createFromBitmap);
            arrayList.add(createFromBitmap);
        }
        return arrayList;
    }

    private List<Allocation> createLaplacianPyramid(ScriptC_pyramid_blending scriptC_pyramid_blending, Bitmap bitmap, int i, String str) {
        Log.d(TAG, "createLaplacianPyramid");
        long currentTimeMillis = System.currentTimeMillis();
        List<Allocation> createGaussianPyramid = createGaussianPyramid(scriptC_pyramid_blending, bitmap, i);
        Log.d(TAG, "### createLaplacianPyramid: time after createGaussianPyramid: " + (System.currentTimeMillis() - currentTimeMillis));
        ArrayList arrayList = new ArrayList();
        int i2 = 0;
        while (i2 < createGaussianPyramid.size() - 1) {
            Log.d(TAG, "createLaplacianPyramid: i = " + i2);
            Allocation allocation = createGaussianPyramid.get(i2);
            int i3 = i2 + 1;
            Allocation allocation2 = createGaussianPyramid.get(i3);
            Allocation expandBitmap = expandBitmap(scriptC_pyramid_blending, allocation2);
            Log.d(TAG, "### createLaplacianPyramid: time after expandBitmap for level " + i2 + ": " + (System.currentTimeMillis() - currentTimeMillis));
            Log.d(TAG, "this_gauss: " + allocation.getType().getX() + " , " + allocation.getType().getY());
            Log.d(TAG, "next_gauss: " + allocation2.getType().getX() + " , " + allocation2.getType().getY());
            Log.d(TAG, "next_gauss_expanded: " + expandBitmap.getType().getX() + " , " + expandBitmap.getType().getY());
            Allocation subtractBitmap = subtractBitmap(scriptC_pyramid_blending, allocation, expandBitmap);
            Log.d(TAG, "### createLaplacianPyramid: time after subtractBitmap for level " + i2 + ": " + (System.currentTimeMillis() - currentTimeMillis));
            arrayList.add(subtractBitmap);
            allocation.destroy();
            createGaussianPyramid.set(i2, null);
            expandBitmap.destroy();
            Log.d(TAG, "### createLaplacianPyramid: time after level " + i2 + ": " + (System.currentTimeMillis() - currentTimeMillis));
            i2 = i3;
        }
        arrayList.add(createGaussianPyramid.get(createGaussianPyramid.size() - 1));
        return arrayList;
    }

    private Bitmap collapseLaplacianPyramid(ScriptC_pyramid_blending scriptC_pyramid_blending, List<Allocation> list) {
        Log.d(TAG, "collapseLaplacianPyramid");
        boolean z = true;
        Allocation allocation = list.get(list.size() - 1);
        int size = list.size() - 2;
        while (size >= 0) {
            Allocation expandBitmap = expandBitmap(scriptC_pyramid_blending, allocation);
            if (!z) {
                allocation.destroy();
            }
            addBitmap(scriptC_pyramid_blending, expandBitmap, list.get(size));
            z = false;
            size--;
            allocation = expandBitmap;
        }
        Bitmap createBitmap = Bitmap.createBitmap(allocation.getType().getX(), allocation.getType().getY(), Bitmap.Config.ARGB_8888);
        allocation.copyTo(createBitmap);
        if (!z) {
            allocation.destroy();
        }
        return createBitmap;
    }

    private void mergePyramids(ScriptC_pyramid_blending scriptC_pyramid_blending0, List list0, List list1, int[] arr_v, int v) {
        float f6;
        float f3;
        float f2;
        int v1;
        int[] arr_v1;
        ScriptC_pyramid_blending scriptC_pyramid_blending1 = scriptC_pyramid_blending0;
        List list2 = list0;
        Log.d("PanoramaProcessor", "mergePyramids");
        if(arr_v == null) {
            arr_v1 = new int[1];
            v1 = 3;
            arr_v1[0] = 1;
        }
        else {
            arr_v1 = arr_v;
            v1 = v;
        }

        int v2;
        for(v2 = 0; v2 < arr_v1.length; ++v2) {
            Log.d("PanoramaProcessor", "best_path[" + v2 + "]: " + arr_v1[v2]);
        }

        int v3 = 0;
        int v4 = 0;
        while(v3 < list0.size()) {
            v4 = Math.max(v4, ((Allocation)list2.get(v3)).getType().getY());
            ++v3;
        }

        Allocation allocation0 = Allocation.createSized(this.rs, Element.I32(this.rs), v4);
        scriptC_pyramid_blending1.bind_interpolated_best_path(allocation0);
        int[] arr_v2 = new int[v4];
        int v5 = 0;
        while(v5 < list0.size()) {
            Allocation allocation1 = (Allocation)list2.get(v5);
            Allocation allocation2 = (Allocation)list1.get(v5);
            int v6 = allocation1.getType().getX();
            int v7 = allocation1.getType().getY();
            if(allocation2.getType().getX() == v6 && allocation2.getType().getY() == v7) {
                if(allocation1.getType().getElement().getDataType() == allocation2.getType().getElement().getDataType()) {
                    scriptC_pyramid_blending1.set_bitmap(allocation2);
                    int v8 = v6 / 2;
                    if(v5 != list0.size() - 1) {
                        int v9 = 2;
                        int v10;
                        for(v10 = 0; v10 < v5; ++v10) {
                            v9 *= 2;
                        }

                        v8 = Math.min(v9, v8);
                    }

                    float f = ((float)arr_v1.length) / ((float)v7);
                    int v11 = 0;
                    while(v11 < v7) {
                        int v12 = v7;
                        float f1 = (((float)v11) + 0.5f) * f;
                        if(f1 <= 0.5f) {
                            f2 = (float)arr_v1[0];
                            f3 = f;
                        }
                        else {
                            f3 = f;
                            if(f1 >= ((float)(arr_v1.length - 1)) + 0.5f) {
                                f2 = (float)arr_v1[arr_v1.length - 1];
                            }
                            else {
                                float f4 = f1 - 0.5f;
                                int v13 = (int)f4;
                                float f5 = f4 - ((float)v13);
                                if(f5 < 0.1f) {
                                    f6 = 0.0f;
                                }
                                else {
                                    f6 = f5 <= 0.9f ? (f5 - 0.1f) / 0.8f : 1.0f;
                                }

                                f2 = (1.0f - f6) * ((float)arr_v1[v13]) + f6 * ((float)arr_v1[v13 + 1]);
                            }
                        }

                        float f7 = f2 / (((float)v1) - 1.0f);
                        int v14 = (int)(((1.0f - f7) * 0.25f + f7 * 0.75f) * ((float)v6) + 0.5f);
                        arr_v2[v11] = v14;
                        int v15 = v8 / 2;
                        int[] arr_v3 = arr_v1;
                        int v16 = v1;
                        if(v14 - v15 >= 0) {
                            if(v14 + v15 <= v6) {
                                ++v11;
                                v7 = v12;
                                f = f3;
                                arr_v1 = arr_v3;
                                v1 = v16;
                                continue;
                            }

                            Log.e("PanoramaProcessor", "    interpolated_best_path[" + v11 + "]: " + arr_v2[v11]);
                            Log.e("PanoramaProcessor", "    blend_width: " + v8);
                            Log.e("PanoramaProcessor", "    width: " + v6);
                            throw new RuntimeException("blend window runs off right hand size");
                        }

                        Log.e("PanoramaProcessor", "    interpolated_best_path[" + v11 + "]: " + arr_v2[v11]);
                        Log.e("PanoramaProcessor", "    blend_width: " + v8);
                        Log.e("PanoramaProcessor", "    width: " + v6);
                        throw new RuntimeException("blend window runs off left hand size");
                    }

                    int[] arr_v4 = arr_v1;
                    int v17 = v1;
                    allocation0.copyFrom(arr_v2);
                    scriptC_pyramid_blending1.invoke_setBlendWidth(v8, v6);
                    if(allocation1.getType().getElement().getDataType() == Element.DataType.FLOAT_32) {
                        scriptC_pyramid_blending1.forEach_merge_f(allocation1, allocation1);
                    }
                    else {
                        scriptC_pyramid_blending1.forEach_merge(allocation1, allocation1);
                    }

                    ++v5;
                    list2 = list0;
                    arr_v1 = arr_v4;
                    v1 = v17;
                    continue;
                }

                Log.e("PanoramaProcessor", "allocations of different data types");
                throw new RuntimeException();
            }

            Log.e("PanoramaProcessor", "allocations of different dimensions");
            throw new RuntimeException();
        }

        allocation0.destroy();
    }
    private void saveBitmap(Bitmap bitmap, String str) {
        try {
            File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/" + str);
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            if (str.toLowerCase().endsWith(".png")) {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
            } else {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fileOutputStream);
            }
            fileOutputStream.close();
            ((CameraMainActivity) this.context).getStorageUtils().broadcastFile(file, true, false, true);
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    private void saveAllocation(String str, Allocation allocation) {
        Bitmap bitmap;
        int x = allocation.getType().getX();
        int y = allocation.getType().getY();
        Log.d(TAG, "count: " + allocation.getType().getCount());
        Log.d(TAG, "byte size: " + allocation.getType().getElement().getBytesSize());
        if (allocation.getType().getElement().getDataType() == Element.DataType.FLOAT_32) {
            int i = x * y;
            float[] fArr = new float[i * 4];
            allocation.copyTo(fArr);
            int[] iArr = new int[i];
            for (int i2 = 0; i2 < i; i2++) {
                int i3 = i2 * 4;
                iArr[i2] = Color.argb(255, Math.max(Math.min((int) ((((fArr[i3] / 510.0f) + 0.5f) * 255.0f) + 0.5f), 255), 0), Math.max(Math.min((int) ((((fArr[i3 + 1] / 510.0f) + 0.5f) * 255.0f) + 0.5f), 255), 0), Math.max(Math.min((int) ((((fArr[i3 + 2] / 510.0f) + 0.5f) * 255.0f) + 0.5f), 255), 0));
            }
            bitmap = Bitmap.createBitmap(iArr, x, y, Bitmap.Config.ARGB_8888);
        } else if (allocation.getType().getElement().getDataType() == Element.DataType.UNSIGNED_8) {
            int i4 = x * y;
            byte[] bArr = new byte[i4];
            allocation.copyTo(bArr);
            int[] iArr2 = new int[i4];
            for (int i5 = 0; i5 < i4; i5++) {
                int i6 = bArr[i5];
                if (i6 < 0) {
                    i6 += 255;
                }
                iArr2[i5] = Color.argb(255, i6, i6, i6);
            }
            bitmap = Bitmap.createBitmap(iArr2, x, y, Bitmap.Config.ARGB_8888);
        } else {
            Bitmap createBitmap = Bitmap.createBitmap(x, y, Bitmap.Config.ARGB_8888);
            allocation.copyTo(createBitmap);
            bitmap = createBitmap;
        }
        saveBitmap(bitmap, str);
        bitmap.recycle();
    }

    private static int getBlendDimension() {
        return (int) (Math.pow(2.0d, 4.0d) + 0.5d);
    }

    private Bitmap blendPyramids(Bitmap bitmap0, Bitmap bitmap1) {
        Bitmap bitmap4;
        long v = System.currentTimeMillis();
        if(this.pyramidBlendingScript == null) {
            this.pyramidBlendingScript = new ScriptC_pyramid_blending(this.rs);
        }

        Log.d("PanoramaProcessor", "### blendPyramids: time after creating ScriptC_pyramid_blending: " + (System.currentTimeMillis() - v));
        if(bitmap0.getWidth() == bitmap1.getWidth() && bitmap0.getHeight() == bitmap1.getHeight()) {
            int v1 = PanoramaProcessor.getBlendDimension();
            if(bitmap0.getWidth() % v1 == 0) {
                if(bitmap0.getHeight() % v1 == 0) {
                    int[] arr_v = new int[8];
                    Bitmap bitmap2 = Bitmap.createScaledBitmap(bitmap0, bitmap0.getWidth() / 4, bitmap0.getHeight() / 4, true);
                    Bitmap bitmap3 = Bitmap.createScaledBitmap(bitmap1, bitmap1.getWidth() / 4, bitmap1.getHeight() / 4, true);
                    Allocation allocation0 = Allocation.createFromBitmap(this.rs, bitmap2);
                    Allocation allocation1 = Allocation.createFromBitmap(this.rs, bitmap3);
                    int[] arr_v1 = new int[1];
                    Allocation allocation2 = Allocation.createSized(this.rs, Element.I32(this.rs), 1);
                    this.pyramidBlendingScript.bind_errors(allocation2);
                    Script.LaunchOptions script$LaunchOptions0 = new Script.LaunchOptions();
                    Log.d("PanoramaProcessor", "### blendPyramids: time after creating allocations for best path: " + (System.currentTimeMillis() - v));
                    this.pyramidBlendingScript.set_bitmap(allocation1);
                    int v2 = Math.max(2, bitmap2.getWidth() / 8);
                    long v3 = v;
                    int v4 = 0;
                    int v5 = 0;
                    while(v5 < 8) {
                        arr_v[v5] = -1;
                        int v6 = v5 + 1;
                        int v7 = bitmap2.getHeight() * v6 / 8;
                        script$LaunchOptions0.setY(v4, v7);
                        int v8 = -1;
                        int v9 = 0;
                        while(true) {
                            bitmap4 = bitmap3;
                            if(v9 >= 7) {
                                break;
                            }

                            float f = ((float)v9) / 6.0f;
                            int v10 = (int)(((1.0f - f) * 0.25f + f * 0.75f) * ((float)bitmap2.getWidth()) + 0.5f);
                            int v11 = v2 / 2;
                            int v12 = v2;
                            script$LaunchOptions0.setX(v10 - v11, v10 + v11);
                            this.pyramidBlendingScript.invoke_init_errors();
                            this.pyramidBlendingScript.forEach_compute_error(allocation0, script$LaunchOptions0);
                            allocation2.copyTo(arr_v1);
                            int v13 = arr_v1[0];
                            Script.LaunchOptions script$LaunchOptions1 = script$LaunchOptions0;
                            Log.d("PanoramaProcessor", "    best_path error[" + v9 + "][" + v5 + "]: " + v13);
                            if(arr_v[v5] == -1 || v13 < v8) {
                                arr_v[v5] = v9;
                                v8 = v13;
                            }

                            ++v9;
                            bitmap3 = bitmap4;
                            script$LaunchOptions0 = script$LaunchOptions1;
                            v2 = v12;
                        }

                        Log.d("PanoramaProcessor", "best_path [" + v5 + "]: " + arr_v[v5]);
                        v5 = v6;
                        v4 = v7;
                        bitmap3 = bitmap4;
                        v2 = v2;
                    }

                    Bitmap bitmap5 = bitmap3;
                    allocation0.destroy();
                    allocation1.destroy();
                    allocation2.destroy();
                    if(bitmap2 != bitmap0) {
                        bitmap2.recycle();
                    }

                    if(bitmap5 != bitmap1) {
                        bitmap5.recycle();
                    }

                    Log.d("PanoramaProcessor", "### blendPyramids: time after finding best path: " + (System.currentTimeMillis() - v3));
                    List list0 = this.createLaplacianPyramid(this.pyramidBlendingScript, bitmap0, 4, "lhs");
                    Log.d("PanoramaProcessor", "### blendPyramids: time after createLaplacianPyramid 1st call: " + (System.currentTimeMillis() - v3));
                    List list1 = this.createLaplacianPyramid(this.pyramidBlendingScript, bitmap1, 4, "rhs");
                    Log.d("PanoramaProcessor", "### blendPyramids: time after createLaplacianPyramid 2nd call: " + (System.currentTimeMillis() - v3));
                    this.mergePyramids(this.pyramidBlendingScript, list0, list1, arr_v, 7);
                    Log.d("PanoramaProcessor", "### blendPyramids: time after mergePyramids: " + (System.currentTimeMillis() - v3));
                    Bitmap bitmap6 = this.collapseLaplacianPyramid(this.pyramidBlendingScript, list0);
                    Log.d("PanoramaProcessor", "### blendPyramids: time after collapseLaplacianPyramid: " + (System.currentTimeMillis() - v3));
                    for(Object object0: list0) {
                        ((Allocation)object0).destroy();
                    }

                    for(Object object1: list1) {
                        ((Allocation)object1).destroy();
                    }

                    Log.d("PanoramaProcessor", "### blendPyramids: time taken: " + (System.currentTimeMillis() - v3));
                    return bitmap6;
                }

                Log.e("PanoramaProcessor", "bitmap height " + bitmap0.getHeight() + " not a multiple of " + v1);
                throw new RuntimeException();
            }

            Log.e("PanoramaProcessor", "bitmap width " + bitmap0.getWidth() + " not a multiple of " + v1);
            throw new RuntimeException();
        }

        Log.e("PanoramaProcessor", "lhs/rhs bitmaps of different dimensions");
        throw new RuntimeException();
    }
    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes3.dex */
    public static class FeatureMatch implements Comparable<FeatureMatch> {
        private float distance;
        private final int index0;
        private final int index1;

        private FeatureMatch(int i, int i2) {
            this.index0 = i;
            this.index1 = i2;
        }

        @Override // java.lang.Comparable
        public int compareTo(FeatureMatch featureMatch) {
            return Float.compare(this.distance, featureMatch.distance);
        }

        public boolean equals(Object obj) {
            return (obj instanceof FeatureMatch) && compareTo((FeatureMatch) obj) == 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void computeDistancesBetweenMatches(List<FeatureMatch> list, int i, int i2, int i3, List<Bitmap> list2, int[] iArr, int[] iArr2) {
        int i4 = i3;
        int i5 = (i4 * 2) + 1;
        int i6 = i5 * i5;
        int i7 = i;
        int i8 = i2;
        while (i7 < i8) {
            FeatureMatch featureMatch = list.get(i7);
            int i9 = featureMatch.index0 * i6;
            int i10 = featureMatch.index1 * i6;
            int i11 = -i4;
            int i12 = i11;
            float f = 0.0f;
            float f2 = 0.0f;
            float f3 = 0.0f;
            float f4 = 0.0f;
            float f5 = 0.0f;
            while (i12 <= i4) {
                int i13 = i11;
                while (i13 <= i4) {
                    int i14 = iArr[i9];
                    int i15 = iArr2[i10];
                    i9++;
                    i10++;
                    f2 += i14;
                    f += i14 * i14;
                    f4 += i15;
                    f3 += i15 * i15;
                    f5 += i14 * i15;
                    i13++;
                    i4 = i3;
                }
                i12++;
                i4 = i3;
            }
            float f6 = i6;
            float f7 = (f * f6) - (f2 * f2);
            float f8 = (f3 * f6) - (f4 * f4);
            float f9 = (f6 * f5) - (f2 * f4);
            featureMatch.distance = 1.0f - Math.abs(((f9 * f9) * (f7 == 0.0f ? 0.0f : 1.0f / f7)) * (f8 == 0.0f ? 0.0f : 1.0f / f8));
            i7++;
            i8 = i2;
            i4 = i3;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class ComputeDistancesBetweenMatchesThread extends Thread {
        private final List<Bitmap> bitmaps;
        private final int feature_descriptor_radius;
        private final List<FeatureMatch> matches;
        private final int nd_indx;
        private final int[] pixels0;
        private final int[] pixels1;
        private final int st_indx;

        ComputeDistancesBetweenMatchesThread(List<FeatureMatch> list, int i, int i2, int i3, List<Bitmap> list2, int[] iArr, int[] iArr2) {
            this.matches = list;
            this.st_indx = i;
            this.nd_indx = i2;
            this.feature_descriptor_radius = i3;
            this.bitmaps = list2;
            this.pixels0 = iArr;
            this.pixels1 = iArr2;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            PanoramaProcessor.computeDistancesBetweenMatches(this.matches, this.st_indx, this.nd_indx, this.feature_descriptor_radius, this.bitmaps, this.pixels0, this.pixels1);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes3.dex */
    public static class AutoAlignmentByFeatureResult {
        final int offset_x;
        final int offset_y;
        final float rotation;
        final float y_scale;

        AutoAlignmentByFeatureResult(int i, int i2, float f, float f2) {
            this.offset_x = i;
            this.offset_y = i2;
            this.rotation = f;
            this.y_scale = f2;
        }
    }

    private AutoAlignmentByFeatureResult autoAlignmentByFeature(int v, int v1, List list0, int v2) throws PanoramaProcessorException {
        float f40;
        ArrayList arrayList20;
        int v86;
        int v85;
        ArrayList arrayList18;
        float f17;
        int v71;
        int v70;
        String s19;
        String s18;
        ArrayList arrayList14;
        ArrayList arrayList13;
        String s16;
        String s15;
        int v69;
        String s8;
        ArrayList arrayList9;
        String s7;
        String s3;
        ArrayList arrayList3;
        int v20;
        int v10;
        PanoramaProcessor panoramaProcessor0 = this;
        int v3 = v;
        int v4 = v1;
        List list1 = list0;
        String s = "PanoramaProcessor";
        Log.d("PanoramaProcessor", "autoAlignmentByFeature");
        Log.d("PanoramaProcessor", "width: " + v3);
        Log.d("PanoramaProcessor", "height: " + v4);
        long v5 = System.currentTimeMillis();
        if(list0.size() == 2) {
            this.initRenderscript();
            Log.d("PanoramaProcessor", "### autoAlignmentByFeature: time after initRenderscript: " + (System.currentTimeMillis() - v5));
            int v6 = list0.size();
            Allocation[] arr_allocation = new Allocation[v6];
            int v7;
            for(v7 = 0; v7 < list0.size(); ++v7) {
                arr_allocation[v7] = Allocation.createFromBitmap(panoramaProcessor0.rs, ((Bitmap)list1.get(v7)));
            }

            Log.d("PanoramaProcessor", "### autoAlignmentByFeature: time after creating allocations: " + (System.currentTimeMillis() - v5));
            if(panoramaProcessor0.featureDetectorScript == null) {
                panoramaProcessor0.featureDetectorScript = new ScriptC_feature_detector(panoramaProcessor0.rs);
            }

            Log.d("PanoramaProcessor", "### autoAlignmentByFeature: time after create featureDetectorScript: " + (System.currentTimeMillis() - v5));
            Point[][] arr2_point = new Point[2][];
            int v8 = 0;
            while(v8 < list0.size()) {
                Log.d("PanoramaProcessor", "detect features for image: " + v8);
                Log.d("PanoramaProcessor", "convert to greyscale");
                Allocation allocation0 = Allocation.createTyped(panoramaProcessor0.rs, Type.createXY(panoramaProcessor0.rs, Element.U8(panoramaProcessor0.rs), v3, v4));
                panoramaProcessor0.featureDetectorScript.forEach_create_greyscale(arr_allocation[v8], allocation0);
                Log.d("PanoramaProcessor", "compute derivatives");
                Allocation allocation1 = Allocation.createTyped(panoramaProcessor0.rs, Type.createXY(panoramaProcessor0.rs, Element.U8(panoramaProcessor0.rs), v3, v4));
                Allocation allocation2 = Allocation.createTyped(panoramaProcessor0.rs, Type.createXY(panoramaProcessor0.rs, Element.U8(panoramaProcessor0.rs), v3, v4));
                panoramaProcessor0.featureDetectorScript.set_bitmap(allocation0);
                panoramaProcessor0.featureDetectorScript.set_bitmap_Ix(allocation1);
                panoramaProcessor0.featureDetectorScript.set_bitmap_Iy(allocation2);
                panoramaProcessor0.featureDetectorScript.forEach_compute_derivatives(allocation0);
                Log.d("PanoramaProcessor", "call corner detector script for image: " + v8);
                Allocation allocation3 = Allocation.createTyped(panoramaProcessor0.rs, Type.createXY(panoramaProcessor0.rs, Element.F32(panoramaProcessor0.rs), v3, v4));
                panoramaProcessor0.featureDetectorScript.set_bitmap(allocation0);
                panoramaProcessor0.featureDetectorScript.set_bitmap_Ix(allocation1);
                panoramaProcessor0.featureDetectorScript.set_bitmap_Iy(allocation2);
                panoramaProcessor0.featureDetectorScript.forEach_corner_detector(allocation0, allocation3);
                allocation1.destroy();
                allocation2.destroy();
                Log.d("PanoramaProcessor", "find local maxima for image: " + v8);
                panoramaProcessor0.featureDetectorScript.set_bitmap(allocation3);
                byte[] arr_b = new byte[v3 * v4];
                ArrayList arrayList0 = new ArrayList();
                Allocation[] arr_allocation1 = arr_allocation;
                int v9 = 0;
                while(true) {
                    v10 = v6;
                    if(v9 >= 2) {
                        break;
                    }

                    long v11 = v5;
                    Log.d("PanoramaProcessor", ">>> find corners, chunk " + v9 + " / " + 2);
                    int v12 = v9 * v4 / 2;
                    int v13 = v9 + 1;
                    int v14 = v13 * v4 / 2;
                    Log.d("PanoramaProcessor", "    start_y: " + v12);
                    Log.d("PanoramaProcessor", "    stop_y: " + v14);
                    int v15 = v8;
                    Point[][] arr2_point1 = arr2_point;
                    int v16 = v13;
                    float f = 0.0f;
                    float f1 = 5000000.0f;
                    float f2 = -1.0f;
                    int v17 = 0;
//                    while(true) {
                        ArrayList arrayList1 = arrayList0;
                        Log.d("PanoramaProcessor", "### attempt " + v17 + " try threshold: " + f1 + " [ " + f + " : " + f2 + " ]");
                        panoramaProcessor0.featureDetectorScript.set_corner_threshold(f1);
                        Script.LaunchOptions script$LaunchOptions0 = new Script.LaunchOptions();
                        script$LaunchOptions0.setX(0, v3);
                        script$LaunchOptions0.setY(v12, v14);
                        panoramaProcessor0.featureDetectorScript.forEach_local_maximum(allocation3, allocation0, script$LaunchOptions0);
                        allocation0.copyTo(arr_b);
                        ArrayList arrayList2 = new ArrayList();
                        int v18 = Math.max(v12, 3);
                        while(v18 < Math.min(v14, v4 - 3)) {
                            int v19 = 3;
                            while(true) {
                                v20 = v14;
                                if(v19 >= v3 - 3) {
                                    break;
                                }

                                if(arr_b[v18 * v3 + v19] != 0) {
                                    arrayList2.add(new Point(v19, v18));
                                }

                                ++v19;
                                v14 = v20;
                            }

                            ++v18;
                            v14 = v20;
                        }

                        int v21 = v14;
                        Log.d("PanoramaProcessor", "    " + arrayList2.size() + " points");
                        if(arrayList2.size() >= 50 && arrayList2.size() <= 100) {
                            arrayList3 = arrayList1;
                            arrayList3.addAll(arrayList2);
//                            label_368:
                            panoramaProcessor0 = this;
                            arrayList0 = arrayList3;
                            v6 = v10;
                            v5 = v11;
                            v9 = v16;
                            v8 = v15;
                            arr2_point = arr2_point1;
                            break;
                        }

                        arrayList3 = arrayList1;
                        if(arrayList2.size() < 50) {
                            if(f1 <= 1250000.0f) {
                                Log.d("PanoramaProcessor", "    hit minimum threshold: " + f1);
                                arrayList3.addAll(arrayList2);
//                                label_368:
                                panoramaProcessor0 = this;
                                arrayList0 = arrayList3;
                                v6 = v10;
                                v5 = v11;
                                v9 = v16;
                                v8 = v15;
                                arr2_point = arr2_point1;
                                break;
                            }

                            if(v17 + 1 == 10) {
                                Log.d("PanoramaProcessor", "    too few points but hit max iterations: " + arrayList2.size());
                                arrayList3.addAll(arrayList2);
//                                label_368:
                                panoramaProcessor0 = this;
                                arrayList0 = arrayList3;
                                v6 = v10;
                                v5 = v11;
                                v9 = v16;
                                v8 = v15;
                                arr2_point = arr2_point1;
                                break;
                            }

                            float f3 = (f + f1) * 0.5f;
                            Log.d("PanoramaProcessor", "    reduced threshold to: " + f3);
                            f2 = f1;
                            f1 = f3;
                        }
                        else {
                            if(v17 + 1 == 10) {
                                Log.d("PanoramaProcessor", "    too many points but hit max iterations: " + arrayList2.size());
                                arrayList2.subList(100, arrayList2.size()).clear();
                                arrayList3.addAll(arrayList2);
//                                label_368:
                                panoramaProcessor0 = this;
                                arrayList0 = arrayList3;
                                v6 = v10;
                                v5 = v11;
                                v9 = v16;
                                v8 = v15;
                                arr2_point = arr2_point1;
                                break;
                            }

                            float f4 = f2 >= 0.0f ? (f1 + f2) * 0.5f : 10.0f * f1;
                            Log.d("PanoramaProcessor", "    increased threshold to: " + f4);
                            float f5 = f1;
                            f1 = f4;
                            f = f5;
                        }

                        ++v17;
                        panoramaProcessor0 = this;
                        arrayList0 = arrayList3;
                        v14 = v21;
//                    }
                }

                arr2_point[v8] = (Point[])arrayList0.toArray(new Point[0]);
                Log.d("PanoramaProcessor", "### image: " + v8 + " has " + arr2_point[v8].length + " points");
                allocation3.destroy();
                allocation0.destroy();
                ++v8;
                panoramaProcessor0 = this;
                arr_allocation = arr_allocation1;
                v6 = v10;
            }

            Point[][] arr2_point2 = arr2_point;
            Allocation[] arr_allocation2 = arr_allocation;
            int v22 = v6;
            long v23 = v5;
            Log.d("PanoramaProcessor", "### autoAlignmentByFeature: time after feature detection: " + (System.currentTimeMillis() - v23));
            if(arr2_point2[0].length >= 10 && arr2_point2[1].length >= 10) {
                int v24 = v4 / 16;
                int v25 = v3 * v3 + v24 * v24;
                Log.d("PanoramaProcessor", "max_match_dist_x: " + v3);
                Log.d("PanoramaProcessor", "max_match_dist_y: " + v24);
                Log.d("PanoramaProcessor", "max_match_dist2: " + v25);
                ArrayList arrayList4 = new ArrayList();
                int v26;
                for(v26 = 0; true; ++v26) {
                    Point[] arr_point = arr2_point2[0];
                    if(v26 >= arr_point.length) {
                        break;
                    }

                    int v27 = arr_point[v26].x;
                    int v28 = arr2_point2[0][v26].y;
                    int v29;
                    for(v29 = 0; true; ++v29) {
                        Point[] arr_point1 = arr2_point2[1];
                        if(v29 >= arr_point1.length) {
                            break;
                        }

                        int v30 = arr_point1[v29].x - v27;
                        int v31 = arr2_point2[1][v29].y - v28;
                        if(v30 * v30 + v31 * v31 < v25) {
                            arrayList4.add(new FeatureMatch(v26, v29));
                        }
                    }
                }

                Log.d("PanoramaProcessor", "### possible matches: " + arrayList4.size());
                String s1 = "### autoAlignmentByFeature: time after finding possible matches: ";
                Log.d("PanoramaProcessor", "### autoAlignmentByFeature: time after finding possible matches: " + (System.currentTimeMillis() - v23));
                int v32 = arr2_point2[0].length * 49;
                int[] arr_v = new int[v32];
                int v33 = arr2_point2[1].length * 49;
                int[] arr_v1 = new int[v33];
                int v34;
                for(v34 = 0; true; ++v34) {
                    Point[] arr_point2 = arr2_point2[0];
                    if(v34 >= arr_point2.length) {
                        break;
                    }

                    int v35 = arr_point2[v34].x;
                    int v36 = arr2_point2[0][v34].y;
                    ((Bitmap)list0.get(0)).getPixels(arr_v, v34 * 49, 7, v35 - 3, v36 - 3, 7, 7);
                }

                List list2 = list0;
                int v37;
                for(v37 = 0; true; ++v37) {
                    Point[] arr_point3 = arr2_point2[1];
                    if(v37 >= arr_point3.length) {
                        break;
                    }

                    int v38 = arr_point3[v37].x;
                    int v39 = arr2_point2[1][v37].y;
                    ((Bitmap)list2.get(1)).getPixels(arr_v1, v37 * 49, 7, v38 - 3, v39 - 3, 7, 7);
                }

                int v40 = 0;
                while(v40 < v32) {
                    int v41 = arr_v[v40];
                    arr_v[v40] = (int)(((double)Color.red(v41)) * 0.3 + ((double)Color.green(v41)) * 0.59 + ((double)Color.blue(v41)) * 0.11);
                    ++v40;
                    s1 = s1;
                }

                String s2 = s1;
                int v42;
                for(v42 = 0; v42 < v33; ++v42) {
                    int v43 = arr_v1[v42];
                    arr_v1[v42] = (int)(((double)Color.red(v43)) * 0.3 + ((double)Color.green(v43)) * 0.59 + ((double)Color.blue(v43)) * 0.11);
                }

                int v44 = Math.min(arrayList4.size(), 2);
                Log.d("PanoramaProcessor", "n_threads: " + v44);
                ComputeDistancesBetweenMatchesThread[] arr_panoramaProcessor$ComputeDistancesBetweenMatchesThread = new ComputeDistancesBetweenMatchesThread[v44];
                int v45 = 0;
                int v46 = 0;
                while(true) {
                    s3 = " to ";
                    if(v46 >= v44) {
                        break;
                    }

                    int v47 = v46 + 1;
                    int v48 = arrayList4.size() * v47 / v44;
                    Log.d("PanoramaProcessor", "thread " + v46 + " from " + v45 + " to " + v48);
                    arr_panoramaProcessor$ComputeDistancesBetweenMatchesThread[v46] = new ComputeDistancesBetweenMatchesThread(arrayList4, v45, v48, 3, list0, arr_v, arr_v1);
                    v46 = v47;
                    arr_v1 = arr_v1;
                    v45 = v48;
                    arrayList4 = arrayList4;
                    arr_v = arr_v;
                    v22 = v22;
                    s2 = s2;
                }

                int v49 = v22;
                String s4 = s2;
                ArrayList arrayList5 = arrayList4;
                Log.d("PanoramaProcessor", "start threads");
                int v50;
                for(v50 = 0; v50 < v44; ++v50) {
                    arr_panoramaProcessor$ComputeDistancesBetweenMatchesThread[v50].start();
                }

                Log.d("PanoramaProcessor", "wait for threads to complete");
                int v51;
                for(v51 = 0; v51 < v44; ++v51) {
                    try {
                        arr_panoramaProcessor$ComputeDistancesBetweenMatchesThread[v51].join();
                    }
                    catch(InterruptedException interruptedException0) {
                        Log.e("PanoramaProcessor", "ComputeDistancesBetweenMatchesThread threads interrupted");
                        interruptedException0.printStackTrace();
                        Thread.currentThread().interrupt();
                        break;
                    }
                }

                Log.d("PanoramaProcessor", "threads completed");
                Log.d("PanoramaProcessor", "### autoAlignmentByFeature: time after computing match distances: " + (System.currentTimeMillis() - v23));
                Collections.sort(arrayList5);
                Log.d("PanoramaProcessor", "### autoAlignmentByFeature: time after sorting matches: " + (System.currentTimeMillis() - v23));
                ArrayList arrayList6 = arrayList5;
                FeatureMatch panoramaProcessor$FeatureMatch0 = (FeatureMatch)arrayList6.get(0);
                FeatureMatch panoramaProcessor$FeatureMatch1 = (FeatureMatch)arrayList6.get(arrayList6.size() - 1);
                String s5 = " and ";
                String s6 = " distance: ";
                Log.d("PanoramaProcessor", "best match between " + panoramaProcessor$FeatureMatch0.index0 + " and " + panoramaProcessor$FeatureMatch0.index1 + " distance: " + panoramaProcessor$FeatureMatch0.distance);
                Log.d("PanoramaProcessor", "worst match between " + panoramaProcessor$FeatureMatch1.index0 + " and " + panoramaProcessor$FeatureMatch1.index1 + " distance: " + panoramaProcessor$FeatureMatch1.distance);
                Point[] arr_point4 = arr2_point2[0];
                boolean[] arr_z = new boolean[arr_point4.length];
                boolean[] arr_z1 = new boolean[arr_point4.length];
                boolean[] arr_z2 = new boolean[arr2_point2[1].length];
                ArrayList arrayList7 = new ArrayList();
                int v52 = 0;
                while(v52 < arrayList6.size()) {
                    FeatureMatch panoramaProcessor$FeatureMatch2 = (FeatureMatch)arrayList6.get(v52);
                    if(!arr_z1[panoramaProcessor$FeatureMatch2.index0] && !arr_z2[panoramaProcessor$FeatureMatch2.index1]) {
                        Log.d("PanoramaProcessor", "    match between " + panoramaProcessor$FeatureMatch2.index0 + " and " + panoramaProcessor$FeatureMatch2.index1 + " distance: " + panoramaProcessor$FeatureMatch2.distance);
                        int v53 = v52 + 1;
                        int v54 = 0;
                        int v55 = 0;
                        while(v53 < arrayList6.size() && v54 == 0) {
                            FeatureMatch panoramaProcessor$FeatureMatch3 = (FeatureMatch)arrayList6.get(v53);
                            ArrayList arrayList8 = arrayList6;
                            int v56 = v54;
                            if(panoramaProcessor$FeatureMatch2.index0 == panoramaProcessor$FeatureMatch3.index0) {
                                float f6 = panoramaProcessor$FeatureMatch2.distance / panoramaProcessor$FeatureMatch3.distance;
                                s7 = s3;
                                Log.d("PanoramaProcessor", "        next best match for index0 " + panoramaProcessor$FeatureMatch2.index0 + " is with " + panoramaProcessor$FeatureMatch3.index1 + " distance: " + panoramaProcessor$FeatureMatch3.distance + " , ratio: " + f6);
                                if(((double)f6) + 0.00001 > 0.8) {
                                    Log.d("PanoramaProcessor", "        reject due to Lowe\'s test, ratio: " + f6);
                                    v54 = 1;
                                    v55 = 1;
                                }
                                else {
                                    v54 = 1;
                                }
                            }
                            else {
                                s7 = s3;
                                v54 = v56;
                            }

                            ++v53;
                            arrayList6 = arrayList8;
                            s3 = s7;
                        }

                        arrayList9 = arrayList6;
                        s8 = s3;
                        if(v55 == 0) {
                            arrayList7.add(panoramaProcessor$FeatureMatch2);
                            arr_z1[panoramaProcessor$FeatureMatch2.index0] = true;
                            arr_z2[panoramaProcessor$FeatureMatch2.index1] = true;
                        }
                        else {
                            arr_z1[panoramaProcessor$FeatureMatch2.index0] = true;
                            arr_z[panoramaProcessor$FeatureMatch2.index0] = true;
                        }
                    }
                    else {
                        arrayList9 = arrayList6;
                        s8 = s3;
                    }

                    ++v52;
                    arrayList6 = arrayList9;
                    s3 = s8;
                }

                String s9 = s3;
                Log.d("PanoramaProcessor", "### autoAlignmentByFeature: time after initial matching: " + (System.currentTimeMillis() - v23));
                Log.d("PanoramaProcessor", "### found: " + arrayList7.size() + " matches");
                Log.d("PanoramaProcessor", s4 + (System.currentTimeMillis() - v23));
                int v57 = Math.max(5, ((int)(((double)arrayList7.size()) * 0.4)) + 1);
                if(v57 < arrayList7.size()) {
                    arrayList7.subList(v57, arrayList7.size()).clear();
                }

                Log.d("PanoramaProcessor", "### resized to: " + arrayList7.size() + " actual matches");
                boolean[] arr_z3 = new boolean[arr2_point2[0].length];
                boolean[] arr_z4 = new boolean[arr2_point2[1].length];
                for(Object object0: arrayList7) {
                    FeatureMatch panoramaProcessor$FeatureMatch4 = (FeatureMatch)object0;
                    arr_z3[panoramaProcessor$FeatureMatch4.index0] = true;
                    arr_z4[panoramaProcessor$FeatureMatch4.index1] = true;
                    Log.d("PanoramaProcessor", "    actual match between " + panoramaProcessor$FeatureMatch4.index0 + " and " + panoramaProcessor$FeatureMatch4.index1 + " distance: " + panoramaProcessor$FeatureMatch4.distance);
                }

                Log.d("PanoramaProcessor", "### autoAlignmentByFeature: time after choosing best matches: " + (System.currentTimeMillis() - v23));
                if(arrayList7.size() == 0) {
                    Log.d("PanoramaProcessor", "no matches!");
                    int v58 = v49;
                    int v59;
                    for(v59 = 0; v59 < v58; ++v59) {
                        Allocation allocation4 = arr_allocation2[v59];
                        if(allocation4 != null) {
                            allocation4.destroy();
                            arr_allocation2[v59] = null;
                        }
                    }

                    return new AutoAlignmentByFeatureResult(0, 0, 0.0f, 1.0f);
                }

                int v60 = v49;
                float f7 = Math.max(5.0f, ((float)Math.max(v, v1)) / 4.0f);
                Log.d("PanoramaProcessor", "min_rotation_dist: " + f7);
                float f8 = f7 * f7;
                ArrayList arrayList10 = new ArrayList();
                ArrayList arrayList11 = new ArrayList();
                ArrayList arrayList12 = new ArrayList();
                float f9 = Math.max(5.01f, ((float)Math.max(v, v1)) / 100.0f);
                Log.d("PanoramaProcessor", "max_inlier_dist: " + f9);
                float f10 = f9 * f9;
                int v61 = 0;
                int v62 = 0;
                while(true) {
                    String s10 = " , ";
                    if(v62 >= arrayList7.size()) {
                        break;
                    }

                    FeatureMatch panoramaProcessor$FeatureMatch5 = (FeatureMatch)arrayList7.get(v62);
                    int v63 = arr2_point2[1][panoramaProcessor$FeatureMatch5.index1].x - arr2_point2[0][panoramaProcessor$FeatureMatch5.index0].x;
                    int v64 = v61;
                    int v65 = arr2_point2[1][panoramaProcessor$FeatureMatch5.index1].y - arr2_point2[0][panoramaProcessor$FeatureMatch5.index0].y;
                    arrayList12.clear();
                    Iterator iterator1 = arrayList7.iterator();
                    while(iterator1.hasNext()) {
                        Object object1 = iterator1.next();
                        Iterator iterator2 = iterator1;
                        FeatureMatch panoramaProcessor$FeatureMatch6 = (FeatureMatch)object1;
                        int v66 = v60;
                        int v67 = arr2_point2[0][panoramaProcessor$FeatureMatch6.index0].x;
                        String s11 = s6;
                        int v68 = arr2_point2[0][panoramaProcessor$FeatureMatch6.index0].y;
                        String s12 = s5;
                        String s13 = s10;
                        float f11 = (float)(v67 + v63 - arr2_point2[1][panoramaProcessor$FeatureMatch6.index1].x);
                        float f12 = (float)(v68 + v65 - arr2_point2[1][panoramaProcessor$FeatureMatch6.index1].y);
                        if(((double)(f11 * f11 + f12 * f12)) + 0.00001 <= ((double)f10)) {
                            arrayList12.add(panoramaProcessor$FeatureMatch6);
                        }

                        iterator1 = iterator2;
                        s6 = s11;
                        s10 = s13;
                        s5 = s12;
                        v60 = v66;
                    }

                    v69 = v60;
                    String s14 = s10;
                    s15 = s5;
                    s16 = s6;
                    String s17 = "all matches are inliers";
                    if(arrayList12.size() > arrayList11.size()) {
                        Log.d(s, "match " + v62 + " gives better translation model: " + arrayList12.size() + "::" + arrayList11.size());
                        arrayList10.clear();
                        arrayList10.add(panoramaProcessor$FeatureMatch5);
                        arrayList11.clear();
                        arrayList11.addAll(arrayList12);
                        if(arrayList11.size() == arrayList7.size()) {
                            Log.d(s, "all matches are inliers");
                            arrayList13 = arrayList10;
                            arrayList14 = arrayList11;
                            s18 = s;
                            s19 = s14;
                            v70 = 0;
//                            label_1842:
                            Log.d(s18, "### autoAlignmentByFeature: time after RANSAC: " + (System.currentTimeMillis() - v23));
                            for(Object object3: arrayList14) {
                                FeatureMatch panoramaProcessor$FeatureMatch13 = (FeatureMatch)object3;
                                Log.d(s18, "    after ransac: actual match between " + panoramaProcessor$FeatureMatch13.index0 + s15 + panoramaProcessor$FeatureMatch13.index1 + s16 + panoramaProcessor$FeatureMatch13.distance);
                            }
                        }

                        v71 = 0;
                    }
                    else {
                        v71 = v64;
                    }

                    int v72 = 0;
                    while(v72 < v62) {
                        FeatureMatch panoramaProcessor$FeatureMatch7 = (FeatureMatch)arrayList7.get(v72);
                        int v73 = (arr2_point2[0][panoramaProcessor$FeatureMatch5.index0].x + arr2_point2[0][panoramaProcessor$FeatureMatch7.index0].x) / 2;
                        int v74 = (arr2_point2[0][panoramaProcessor$FeatureMatch5.index0].y + arr2_point2[0][panoramaProcessor$FeatureMatch7.index0].y) / 2;
                        int v75 = v71;
                        int v76 = (arr2_point2[1][panoramaProcessor$FeatureMatch5.index1].x + arr2_point2[1][panoramaProcessor$FeatureMatch7.index1].x) / 2;
                        int v77 = v72;
                        int v78 = (arr2_point2[1][panoramaProcessor$FeatureMatch5.index1].y + arr2_point2[1][panoramaProcessor$FeatureMatch7.index1].y) / 2;
                        String s20 = s17;
                        float f13 = (float)(arr2_point2[0][panoramaProcessor$FeatureMatch5.index0].x - arr2_point2[0][panoramaProcessor$FeatureMatch7.index0].x);
                        ArrayList arrayList15 = arrayList10;
                        float f14 = (float)(arr2_point2[0][panoramaProcessor$FeatureMatch5.index0].y - arr2_point2[0][panoramaProcessor$FeatureMatch7.index0].y);
                        String s21 = s;
                        float f15 = (float)(arr2_point2[1][panoramaProcessor$FeatureMatch5.index1].x - arr2_point2[1][panoramaProcessor$FeatureMatch7.index1].x);
                        int v79 = v62;
                        float f16 = (float)(arr2_point2[1][panoramaProcessor$FeatureMatch5.index1].y - arr2_point2[1][panoramaProcessor$FeatureMatch7.index1].y);
                        if(f13 * f13 + f14 * f14 >= f8 && f15 * f15 + f16 * f16 >= f8) {
                            f17 = f8;
                            ArrayList arrayList16 = arrayList11;
                            float f18 = (float)v1;
                            float f19 = 0.3f * f18;
                            float f20 = f18 * 0.7f;
                            if(((float)arr2_point2[0][panoramaProcessor$FeatureMatch5.index0].y) >= f19 && ((float)arr2_point2[0][panoramaProcessor$FeatureMatch5.index0].y) <= f20 && ((float)arr2_point2[1][panoramaProcessor$FeatureMatch5.index1].y) >= f19 && ((float)arr2_point2[1][panoramaProcessor$FeatureMatch5.index1].y) <= f20 && ((float)arr2_point2[0][panoramaProcessor$FeatureMatch7.index0].y) >= f19 && ((float)arr2_point2[0][panoramaProcessor$FeatureMatch7.index0].y) <= f20 && ((float)arr2_point2[1][panoramaProcessor$FeatureMatch7.index1].y) >= f19 && ((float)arr2_point2[1][panoramaProcessor$FeatureMatch7.index1].y) <= f20) {
                                FeatureMatch panoramaProcessor$FeatureMatch8 = panoramaProcessor$FeatureMatch5;
                                int v80 = v78;
                                float f21 = f15;
                                FeatureMatch panoramaProcessor$FeatureMatch9 = panoramaProcessor$FeatureMatch7;
                                float f22 = (float)(Math.atan2(f16, f15) - Math.atan2(f14, f13));
                                double f23 = (double)f22;
                                if(f23 < -3.141593) {
                                    f22 = (float)(f23 + 6.283185);
                                }
                                else if(f23 > 3.141593) {
                                    f22 = (float)(f23 - 6.283185);
                                }

                                if(((double)Math.abs(f22)) > 0.523599) {
                                    panoramaProcessor$FeatureMatch5 = panoramaProcessor$FeatureMatch8;
//                                    label_1782:
                                    arrayList18 = arrayList7;
                                    arrayList14 = arrayList16;
                                }

                                arrayList12.clear();
                                Iterator iterator3 = arrayList7.iterator();
                                while(iterator3.hasNext()) {
                                    Object object2 = iterator3.next();
                                    FeatureMatch panoramaProcessor$FeatureMatch10 = (FeatureMatch)object2;
                                    Iterator iterator4 = iterator3;
                                    float f24 = f16;
                                    double f25 = (double)(arr2_point2[0][panoramaProcessor$FeatureMatch10.index0].x - v73);
                                    float f26 = f14;
                                    FeatureMatch panoramaProcessor$FeatureMatch11 = panoramaProcessor$FeatureMatch8;
                                    double f27 = (double)f22;
                                    ArrayList arrayList17 = arrayList7;
                                    double f28 = (double)(arr2_point2[0][panoramaProcessor$FeatureMatch10.index0].y - v74);
                                    int v81 = v73;
                                    int v82 = v74;
                                    float f29 = (float)(((int)(Math.cos(f27) * f25 - Math.sin(f27) * f28)) + v76 - arr2_point2[1][panoramaProcessor$FeatureMatch10.index1].x);
                                    float f30 = (float)(((int)(((float)(((int)(f25 * Math.sin(f27) + f28 * Math.cos(f27))))) * 1.0f)) + v80 - arr2_point2[1][panoramaProcessor$FeatureMatch10.index1].y);
                                    if(((double)(f29 * f29 + f30 * f30)) + 0.00001 <= ((double)f10)) {
                                        arrayList12.add(panoramaProcessor$FeatureMatch10);
                                    }

                                    f16 = f24;
                                    f14 = f26;
                                    iterator3 = iterator4;
                                    panoramaProcessor$FeatureMatch8 = panoramaProcessor$FeatureMatch11;
                                    arrayList7 = arrayList17;
                                    v73 = v81;
                                    v74 = v82;
                                }

                                float f31 = f14;
                                FeatureMatch panoramaProcessor$FeatureMatch12 = panoramaProcessor$FeatureMatch8;
                                arrayList18 = arrayList7;
                                float f32 = f16;
                                int v83 = v73;
                                int v84 = v74;
                                if(arrayList12.size() > arrayList16.size() && arrayList12.size() >= 5) {
                                    v85 = v79;
                                    s18 = s21;
                                    Log.d(s18, "match " + v85 + " gives better rotation model: " + arrayList12.size() + " inliers vs " + arrayList16.size());
                                    Log.d(s18, "    c0_x: " + v83 + " , c0_y: " + v84);
                                    Log.d(s18, "    c1_x: " + v76 + " , c1_y: " + v80);
                                    Log.d(s18, "    dx0: " + f13 + " , dy0: " + f31);
                                    Log.d(s18, "    dx1: " + f21 + " , dy1: " + f32);
                                    s19 = s14;
                                    Log.d(s18, "    rotate by " + f22 + " about: " + v83 + s19 + v84);
                                    Log.d(s18, "    y scale by " + 1.0f);
                                    Log.d(s18, "    translate by: " + (v76 - v83) + s19 + (v80 - v84));
                                    arrayList15.clear();
                                    arrayList13 = arrayList15;
                                    panoramaProcessor$FeatureMatch5 = panoramaProcessor$FeatureMatch12;
                                    arrayList13.add(panoramaProcessor$FeatureMatch5);
                                    arrayList13.add(panoramaProcessor$FeatureMatch9);
                                    arrayList16.clear();
                                    arrayList14 = arrayList16;
                                    arrayList14.addAll(arrayList12);
                                    if(arrayList14.size() == arrayList18.size()) {
                                        s17 = s20;
                                        Log.d(s18, s17);
                                        v61 = 1;
                                        if(arrayList14.size() == arrayList18.size()) {
                                            Log.d(s18, s17);
                                            v70 = v61;
//                        label_1842:
                                            Log.d(s18, "### autoAlignmentByFeature: time after RANSAC: " + (System.currentTimeMillis() - v23));
                                            for(Object object3: arrayList14) {
                                                FeatureMatch panoramaProcessor$FeatureMatch13 = (FeatureMatch)object3;
                                                Log.d(s18, "    after ransac: actual match between " + panoramaProcessor$FeatureMatch13.index0 + s15 + panoramaProcessor$FeatureMatch13.index1 + s16 + panoramaProcessor$FeatureMatch13.distance);
                                            }
                                        }

                                    }

                                    s17 = s20;
                                    v86 = 1;
//                                    label_1794:
                                    s14 = s19;
                                    v62 = v85;
                                    s = s18;
                                    f8 = f17;
                                    arrayList10 = arrayList13;
                                    arrayList11 = arrayList14;
                                    v71 = v86;
                                    v72 = v77 + 1;
                                    arrayList7 = arrayList18;
                                }

                                arrayList14 = arrayList16;
                                s19 = s14;
                                s17 = s20;
                                arrayList13 = arrayList15;
                                s18 = s21;
                                v85 = v79;
                                panoramaProcessor$FeatureMatch5 = panoramaProcessor$FeatureMatch12;
//                                label_1793:
                                v86 = v75;
                            }


                        }
                        else {
                            f17 = f8;
                            arrayList14 = arrayList11;
                            arrayList18 = arrayList7;
                        }

                        s19 = s14;
                        s17 = s20;
                        arrayList13 = arrayList15;
                        s18 = s21;
                        v85 = v79;
//                        label_1793:
//                        v86 = v75;
//                        label_1794:
//                        s14 = s19;
//                        v62 = v85;
//                        s = s18;
//                        f8 = f17;
//                        arrayList10 = arrayList13;
//                        arrayList11 = arrayList14;
//                        v71 = v86;
//                        v72 = v77 + 1;
//                        arrayList7 = arrayList18;
                    }

                    f17 = f8;
                    arrayList13 = arrayList10;
                    arrayList14 = arrayList11;
                    arrayList18 = arrayList7;
                    v85 = v62;
                    s18 = s;
                    s19 = s14;
                    v61 = v71;
//                    label_1814:
//                    if(arrayList14.size() == arrayList18.size()) {
//                        Log.d(s18, s17);
//                        v70 = v61;
////                        label_1842:
//                        Log.d(s18, "### autoAlignmentByFeature: time after RANSAC: " + (System.currentTimeMillis() - v23));
//                        for(Object object3: arrayList14) {
//                            FeatureMatch panoramaProcessor$FeatureMatch13 = (FeatureMatch)object3;
//                            Log.d(s18, "    after ransac: actual match between " + panoramaProcessor$FeatureMatch13.index0 + s15 + panoramaProcessor$FeatureMatch13.index1 + s16 + panoramaProcessor$FeatureMatch13.distance);
//                        }
//                    }

                    v62 = v85 + 1;
                    arrayList10 = arrayList13;
                    s = s18;
                    s6 = s16;
                    s5 = s15;
                    v60 = v69;
                    f8 = f17;
                    arrayList7 = arrayList18;
                    arrayList11 = arrayList14;
                }

                v69 = v60;
                s19 = " , ";
                arrayList13 = arrayList10;
                arrayList14 = arrayList11;
                s15 = s5;
                s16 = s6;
                s18 = s;
                v70 = v61;
//                label_1842:
//                Log.d(s18, "### autoAlignmentByFeature: time after RANSAC: " + (System.currentTimeMillis() - v23));
//                for(Object object3: arrayList14) {
//                    FeatureMatch panoramaProcessor$FeatureMatch13 = (FeatureMatch)object3;
//                    Log.d(s18, "    after ransac: actual match between " + panoramaProcessor$FeatureMatch13.index0 + s15 + panoramaProcessor$FeatureMatch13.index1 + s16 + panoramaProcessor$FeatureMatch13.distance);
//                }

                Point[] arr_point5 = new Point[2];
                int v87;
                for(v87 = 0; v87 < 2; ++v87) {
                    arr_point5[v87] = new Point();
                }

                for(Object object4: arrayList14) {
                    FeatureMatch panoramaProcessor$FeatureMatch14 = (FeatureMatch)object4;
                    arr_point5[0].x += arr2_point2[0][panoramaProcessor$FeatureMatch14.index0].x;
                    arr_point5[0].y += arr2_point2[0][panoramaProcessor$FeatureMatch14.index0].y;
                    arr_point5[1].x += arr2_point2[1][panoramaProcessor$FeatureMatch14.index1].x;
                    arr_point5[1].y += arr2_point2[1][panoramaProcessor$FeatureMatch14.index1].y;
                }

                int v88;
                for(v88 = 0; v88 < 2; ++v88) {
                    Point point0 = arr_point5[v88];
                    point0.x /= arrayList14.size();
                    Point point1 = arr_point5[v88];
                    point1.y /= arrayList14.size();
                }

                Log.d(s18, "centres[0]: " + arr_point5[0].x + s19 + arr_point5[0].y);
                Log.d(s18, "centres[1]: " + arr_point5[1].x + s19 + arr_point5[1].y);
                int v89 = arr_point5[1].x - arr_point5[0].x;
                int v90 = arr_point5[1].y - arr_point5[0].y;
                if(v70 == 0) {
                    arrayList20 = arrayList13;
                    f40 = 0.0f;
                }
                else {
                    Iterator iterator7 = arrayList14.iterator();
                    float f33 = 0.0f;
                    int v91 = 0;
                    while(iterator7.hasNext()) {
                        Object object5 = iterator7.next();
                        FeatureMatch panoramaProcessor$FeatureMatch15 = (FeatureMatch)object5;
                        float f34 = (float)(arr2_point2[0][panoramaProcessor$FeatureMatch15.index0].x - arr_point5[0].x);
                        float f35 = (float)(arr2_point2[0][panoramaProcessor$FeatureMatch15.index0].y - arr_point5[0].y);
                        float f36 = (float)(arr2_point2[1][panoramaProcessor$FeatureMatch15.index1].x - arr_point5[1].x);
                        float f37 = (float)(arr2_point2[1][panoramaProcessor$FeatureMatch15.index1].y - arr_point5[1].y);
                        ArrayList arrayList19 = arrayList13;
                        Iterator iterator8 = iterator7;
                        if(((double)(f34 * f34 + f35 * f35)) >= 0.00001 && ((double)(f36 * f36 + f37 * f37)) >= 0.00001) {
                            float f38 = (float)(Math.atan2(f37, f36) - Math.atan2(f35, f34));
                            double f39 = (double)f38;
                            if(f39 < -3.141593) {
                                f38 = (float)(f39 + 6.283185);
                            }
                            else if(f39 > 3.141593) {
                                f38 = (float)(f39 - 6.283185);
                            }

                            Log.d(s18, "    match has angle: " + f38);
                            f33 += f38;
                            ++v91;
                        }

                        iterator7 = iterator8;
                        arrayList13 = arrayList19;
                    }

                    arrayList20 = arrayList13;
                    f40 = v91 <= 0 ? 0.0f : f33 / ((float)v91);
                    double f41 = (double)f40;
                    float f42 = (float)(((double)arr_point5[0].x) * Math.cos(f41) - ((double)arr_point5[0].y) * Math.sin(f41));
                    float f43 = ((float)(((double)arr_point5[0].x) * Math.sin(f41) + ((double)arr_point5[0].y) * Math.cos(f41))) * 1.0f;
                    Log.d(s18, "offset_x before rotation: " + v89);
                    Log.d(s18, "offset_y before rotation: " + v90);
                    Log.d(s18, "rotated_centre: " + f42 + s19 + f43);
                    v89 = (int)(((float)v89) + (((float)arr_point5[0].x) - f42));
                    v90 = (int)(((float)v90) + (((float)arr_point5[0].y) - f43));
                }

                Log.d(s18, "### autoAlignmentByFeature: time after computing transformation: " + (System.currentTimeMillis() - v23));
                Log.d(s18, "offset_x: " + v89);
                Log.d(s18, "offset_y: " + v90);
                Log.d(s18, "rotation: " + f40);
                Log.d(s18, "y_scale: " + 1.0f);
                Log.d(s18, "ransac matches are:");
                for(Object object6: arrayList20) {
                    FeatureMatch panoramaProcessor$FeatureMatch16 = (FeatureMatch)object6;
                    int v92 = arr2_point2[0][panoramaProcessor$FeatureMatch16.index0].x;
                    int v93 = arr2_point2[0][panoramaProcessor$FeatureMatch16.index0].y;
                    int v94 = arr2_point2[1][panoramaProcessor$FeatureMatch16.index1].x;
                    int v95 = arr2_point2[1][panoramaProcessor$FeatureMatch16.index1].y;
                    Log.d(s18, "    index : " + panoramaProcessor$FeatureMatch16.index0 + s9 + panoramaProcessor$FeatureMatch16.index1);
                    Log.d(s18, ":::::" + v92 + s19 + v93 + s9 + v94 + s19 + v95);
                    Log.d(s18, "        distance: " + panoramaProcessor$FeatureMatch16.distance);
                }

                int v96 = v69;
                int v97;
                for(v97 = 0; v97 < v96; ++v97) {
                    Allocation allocation5 = arr_allocation2[v97];
                    if(allocation5 != null) {
                        allocation5.destroy();
                        arr_allocation2[v97] = null;
                    }
                }

                Log.d(s18, "### autoAlignmentByFeature: total time: " + (System.currentTimeMillis() - v23));
                return new AutoAlignmentByFeatureResult(v89, v90, f40, 1.0f);
            }

            int v98 = v22;
            Log.d("PanoramaProcessor", ":::");
            int v99;
            for(v99 = 0; v99 < v98; ++v99) {
                Allocation allocation6 = arr_allocation2[v99];
                if(allocation6 != null) {
                    allocation6.destroy();
                    arr_allocation2[v99] = null;
                }
            }

            return new AutoAlignmentByFeatureResult(0, 0, 0.0f, 1.0f);
        }

        Log.e("PanoramaProcessor", "must have 2 bitmaps");
        throw new PanoramaProcessorException(0);
    }
    private Bitmap blend_panorama_alpha(Bitmap bitmap, Bitmap bitmap2) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        if (width != bitmap2.getWidth()) {
            Log.e(TAG, "bitmaps have different widths");
            throw new RuntimeException();
        } else if (height != bitmap2.getHeight()) {
            Log.e(TAG, "bitmaps have different heights");
            throw new RuntimeException();
        } else {
            Paint paint = new Paint();
            Rect rect = new Rect();
            Bitmap createBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(createBitmap);
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
            int i = 0;
            while (i < width) {
                int i2 = i + 1;
                rect.set(i, 0, i2, height);
                float f = width - 1.0f;
                float f2 = i;
                paint.setAlpha((int) (((f - f2) / f) * 255.0f));
                canvas.drawBitmap(bitmap, rect, rect, paint);
                paint.setAlpha((int) ((f2 / f) * 255.0f));
                canvas.drawBitmap(bitmap2, rect, rect, paint);
                i = i2;
            }
            return createBitmap;
        }
    }

    private static int nextMultiple(int i, int i2) {
        int i3 = i % i2;
        return i3 > 0 ? i + (i2 - i3) : i;
    }

    private Bitmap createProjectedBitmap(Rect rect, Rect rect2, Bitmap bitmap, Paint paint, int i, int i2, double d, int i3) {
        int i4;
        int i5;
        int i6;
        Bitmap createBitmap = Bitmap.createBitmap(i, i2, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        int i7 = -1;
        int i8 = -1;
        int i9 = 0;
        int i10 = 0;
        while (i9 < i) {
            float f = i2;
            int i11 = i8;
            float cos = ((float) Math.cos(((float) ((i9 - ((i / 2) + i3)) * d)) / i)) * f;
            int i12 = (int) (((f - cos) / 2.0f) + 0.5f);
            int i13 = (int) (((f + cos) / 2.0f) + 0.5f);
            if (i9 == 0) {
                i11 = i13;
                i6 = i10;
                i4 = 0;
                i5 = i12;
            } else if (Math.abs(i12 - i7) > 1 || Math.abs(i13 - i11) > 1) {
                i4 = 0;
                rect.set(i10, 0, i9, i2);
                rect2.set(i10, i12, i9, i13);
                canvas.drawBitmap(bitmap, rect, rect2, paint);
                i11 = i13;
                i5 = i12;
                i6 = i9;
            } else {
                i6 = i10;
                i5 = i7;
                i4 = 0;
            }
            if (i9 == i - 1) {
                int i14 = i9 + 1;
                rect.set(i6, i4, i14, i2);
                rect2.set(i6, i12, i14, i13);
                canvas.drawBitmap(bitmap, rect, rect2, paint);
            }
            i9++;
            i7 = i5;
            i10 = i6;
            i8 = i11;
        }
        return createBitmap;
    }

    private void renderPanoramaImage(int i, int i2, Rect rect, Rect rect2, Bitmap bitmap, Paint paint, int i3, int i4, int i5, int i6, int i7, Bitmap bitmap2, Canvas canvas, int i8, int i9, int i10, int i11, int i12, int i13, int i14, double d, long j) {
        Rect rect3;
        Paint paint2;
        Canvas canvas2;
        int i15;
        String str;
        Rect rect4;
        int i16;
        Log.d(TAG, "    align_x: " + i10);
        Log.d(TAG, "    align_y: " + i11);
        Log.d(TAG, "    dst_offset_x: " + i12);
        Log.d(TAG, "    shift_stop_x: " + i13);
        Log.d(TAG, "### time before projection for " + i + "th bitmap: " + (System.currentTimeMillis() - j));
        Bitmap createProjectedBitmap = createProjectedBitmap(rect, rect2, bitmap, paint, i3, i4, d, i14);
        Log.d(TAG, "### time after projection for " + i + "th bitmap: " + (System.currentTimeMillis() - j));
        if (i <= 0 || i5 <= 0) {
            rect3 = rect;
            paint2 = paint;
            canvas2 = canvas;
            i15 = i;
            str = "th bitmap: ";
            rect4 = rect2;
            i16 = i10;
        } else {
            Log.d(TAG, "### time before blending for " + i + "th bitmap: " + (System.currentTimeMillis() - j));
            int blendDimension = getBlendDimension();
            int nextMultiple = nextMultiple(i5 * 2, blendDimension);
            int nextMultiple2 = nextMultiple(i4, blendDimension);
            Log.d(TAG, "blend_dimension: " + blendDimension);
            Log.d(TAG, "blend_hwidth: " + i5);
            Log.d(TAG, "bitmap_height: " + i4);
            Log.d(TAG, "blend_width: " + nextMultiple);
            Log.d(TAG, "blend_height: " + nextMultiple2);
            Bitmap createBitmap = Bitmap.createBitmap(nextMultiple, nextMultiple2, Bitmap.Config.ARGB_8888);
            Canvas canvas3 = new Canvas(createBitmap);
            int i17 = i7 + i12;
            int i18 = i17 - i5;
            rect3 = rect;
            rect3.set(i18, 0, i17 + i5, i4);
            rect3.offset(-i8, 0);
            rect4 = rect2;
            rect4.set(0, 0, nextMultiple, nextMultiple2);
            paint2 = paint;
            canvas3.drawBitmap(bitmap2, rect3, rect4, paint2);
            Bitmap createBitmap2 = Bitmap.createBitmap(nextMultiple, nextMultiple2, Bitmap.Config.ARGB_8888);
            Canvas canvas4 = new Canvas(createBitmap2);
            rect3.set(i7 - i5, 0, i7 + i5, i4);
            i16 = i10;
            rect3.offset(i16, i11);
            rect4.set(0, -i9, nextMultiple, nextMultiple2 - i9);
            canvas4.drawBitmap(createProjectedBitmap, rect3, rect4, paint2);
            Log.d(TAG, "lhs dimensions: " + createBitmap.getWidth() + " x " + createBitmap.getHeight());
            Log.d(TAG, "rhs dimensions: " + createBitmap2.getWidth() + " x " + createBitmap2.getHeight());
            Bitmap blendPyramids = blendPyramids(createBitmap, createBitmap2);
            float f = (float) (i18 - i8);
            canvas2 = canvas;
            canvas2.drawBitmap(blendPyramids, f, 0.0f, paint2);
            createBitmap.recycle();
            createBitmap2.recycle();
            blendPyramids.recycle();
            StringBuilder sb = new StringBuilder();
            sb.append("### time after blending for ");
            i15 = i;
            sb.append(i15);
            str = "th bitmap: ";
            sb.append(str);
            sb.append(System.currentTimeMillis() - j);
            Log.d(TAG, sb.toString());
        }
        int i19 = i6 + i5;
        int i20 = i15 == 0 ? -i7 : i5;
        if (i15 == i2 - 1) {
            i19 = (i6 + i7) - i16;
        }
        int i21 = i19 - i13;
        Log.d(TAG, "    offset_x: " + i7);
        Log.d(TAG, "    dst_offset_x: " + i12);
        Log.d(TAG, "    start_x: " + i20);
        Log.d(TAG, "    stop_x: " + i21);
        Log.d(TAG, "### time before drawing non-blended region for " + i15 + str + (System.currentTimeMillis() - j));
        rect3.set(i7 + i20, 0, i7 + i21, i4);
        rect3.offset(i16, i11);
        int i22 = i7 + i12;
        rect4.set((i20 + i22) - i8, -i9, (i22 + i21) - i8, i4 - i9);
        Log.d(TAG, "    src_rect_workspace: " + rect3);
        Log.d(TAG, "    dst_rect_workspace: " + rect4);
        canvas2.drawBitmap(createProjectedBitmap, rect3, rect4, paint2);
        Log.d(TAG, "### time after drawing non-blended region for " + i + str + (System.currentTimeMillis() - j));
        createProjectedBitmap.recycle();
    }

    private float adjustExposuresLocal(List<Bitmap> list, int i, int i2, int i3, long j) {
        HDRProcessor.HistogramInfo histogramInfo = null;
        List<Bitmap> list2 = list;
        int i4 = i / 10;
        int i5 = (i - i3) / 2;
        ArrayList arrayList = new ArrayList();
        arrayList.add(Float.valueOf(1.0f));
        String str = TAG;
        Log.d(TAG, "### time before computing brightnesses: " + (System.currentTimeMillis() - j));
        int i6 = 0;
        float f = 1.0f;
        float f2 = 1.0f;
        float f3 = 1.0f;
        while (i6 < list.size() - 1) {
            Bitmap bitmap = list2.get(i6);
            int i7 = i6 + 1;
            Bitmap bitmap2 = list2.get(i7);
            Log.d(str, "### time before cropping bitmaps: " + (System.currentTimeMillis() - j));
            Matrix matrix = new Matrix();
            matrix.postScale(0.5f, 0.5f);
            int i8 = i4 * 2;
            Bitmap createBitmap = Bitmap.createBitmap(bitmap, (i5 + i3) - i4, 0, i8, i2, matrix, true);
            Bitmap createBitmap2 = Bitmap.createBitmap(bitmap2, i5 - i4, 0, i8, i2, matrix, true);
            str = str;
            Log.d(str, "### time after cropping bitmaps: " + (System.currentTimeMillis() - j));
            HDRProcessor.HistogramInfo histogramInfo2 = this.hdrProcessor.getHistogramInfo(this.hdrProcessor.computeHistogram(createBitmap, false));
            HDRProcessor.HistogramInfo histogramInfo3 = this.hdrProcessor.getHistogramInfo(this.hdrProcessor.computeHistogram(createBitmap2, false));
            int i9 = i4;
            int i10 = i5;
            float max = Math.max(histogramInfo3.median_brightness, 1) / Math.max(histogramInfo2.median_brightness, 1);
            f3 *= max;
            Log.d(str, "compare brightnesses from images " + i6 + " to " + i7 + ":");
            StringBuilder sb = new StringBuilder();
            sb.append("    left median: ");
            sb.append(histogramInfo2.median_brightness);
            Log.d(str, sb.toString());
            Log.d(str, "    right median: " + histogramInfo3.median_brightness);
            Log.d(str, "    brightness_scale: " + max);
            Log.d(str, "    current_relative_brightness: " + f3);
            arrayList.add(Float.valueOf(f3));
            f2 = Math.min(f2, f3);
            f = Math.max(f, f3);
            if (createBitmap != list2.get(i6)) {
                createBitmap.recycle();
            }
            if (createBitmap2 != list2.get(i7)) {
                createBitmap2.recycle();
            }
            i6 = i7;
            i4 = i9;
            i5 = i10;
        }
        float f4 = f / f2;
        Log.d(str, "min_relative_brightness: " + f2);
        Log.d(str, "max_relative_brightness: " + f);
        Log.d(str, "ratio of max to min relative brightness: " + f4);
        Log.d(str, "### time after computing brightnesses: " + (System.currentTimeMillis() - j));
        ArrayList arrayList2 = new ArrayList();
        float f5 = 0.0f;
        float f6 = 0.0f;
        float f7 = 0.0f;
        for (int i11 = 0; i11 < list.size(); i11++) {
            arrayList2.add(this.hdrProcessor.getHistogramInfo(this.hdrProcessor.computeHistogram(list2.get(i11), false)));
            f6 += histogramInfo.median_brightness;
            float floatValue = histogramInfo.median_brightness / ((Float) arrayList.get(i11)).floatValue();
            f7 += floatValue;
            Log.d(str, "image " + i11 + " has median brightness " + histogramInfo.median_brightness);
            StringBuilder sb2 = new StringBuilder();
            sb2.append("    and equalised_brightness ");
            sb2.append(floatValue);
            Log.d(str, sb2.toString());
        }
        float size = f6 / list.size();
        float size2 = f7 / list.size();
        Log.d(str, "mean_median_brightness: " + size);
        Log.d(str, "mean_equalised_brightness: " + size2);
        float max2 = size / Math.max(size2, 1.0f);
        Log.d(str, "### time after computing global histograms: " + (System.currentTimeMillis() - j));
        int i12 = 0;
        float f8 = 1000.0f;
        while (i12 < list.size()) {
            Log.d(str, "    adjust exposure for image: " + i12);
            HDRProcessor.HistogramInfo histogramInfo4 = (HDRProcessor.HistogramInfo) arrayList2.get(i12);
            int min = Math.min(255, (int) (((((float) histogramInfo4.median_brightness) * max2) / ((Float) arrayList.get(i12)).floatValue()) + 0.1f));
            Log.d(str, "    image " + i12 + " has initial brightness_target: " + min);
            StringBuilder sb3 = new StringBuilder();
            sb3.append("    median_brightness: ");
            sb3.append(histogramInfo4.median_brightness);
            Log.d(str, sb3.toString());
            Log.d(str, "    relative_brightness: " + arrayList.get(i12));
            Log.d(str, "    avg_relative_brightness: " + max2);
            float f9 = (float) min;
            f8 = Math.min(f8, f9 / ((float) histogramInfo4.median_brightness));
            f5 = Math.max(f5, f9 / ((float) histogramInfo4.median_brightness));
            int min2 = Math.min(Math.max(min, (int) ((histogramInfo4.median_brightness * 0.5f) + 0.5f)), (int) ((histogramInfo4.median_brightness * 2.0f) + 0.5f));
            Log.d(str, "    brightness_target: " + min);
            Log.d(str, "    preferred brightness scale: " + (f9 / ((float) histogramInfo4.median_brightness)));
            Log.d(str, "    this_brightness_target: " + min2);
            Log.d(str, "    actual brightness scale: " + (((float) min2) / ((float) histogramInfo4.median_brightness)));
            this.hdrProcessor.brightenImage(list2.get(i12), histogramInfo4.median_brightness, histogramInfo4.max_brightness, min2);
            i12++;
            list2 = list;
        }
        Log.d(str, "min_preferred_scale: " + f8);
        Log.d(str, " " + f5);
        Log.d(str, "### time after adjusting brightnesses: " + (System.currentTimeMillis() - j));
        return f4;
    }

    private void adjustExposures(List<Bitmap> list, long j) {
        String str;
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        float f = 0.0f;
        int i = 0;
        float f2 = 0.0f;
        while (true) {
            int size = list.size();
            str = TAG;
            if (i >= size) {
                break;
            }
            HDRProcessor.HistogramInfo histogramInfo = this.hdrProcessor.getHistogramInfo(this.hdrProcessor.computeHistogram(list.get(i), false));
            arrayList.add(histogramInfo);
            f2 += histogramInfo.median_brightness;
            arrayList2.add(Integer.valueOf(histogramInfo.median_brightness));
            Log.d(str, "image " + i + " has median brightness " + histogramInfo.median_brightness);
            i++;
        }
        float size2 = f2 / list.size();
        int i2 = (int) (0.1f + size2);
        Log.d(str, "mean_median_brightness: " + size2);
        Log.d(str, "### time after computing brightnesses: " + (System.currentTimeMillis() - j));
        float f3 = 1000.0f;
        for (int i3 = 0; i3 < list.size(); i3++) {
            HDRProcessor.HistogramInfo histogramInfo2 = (HDRProcessor.HistogramInfo) arrayList.get(i3);
            Log.d(str, "    adjust exposure for image: " + i3);
            float f4 = (float) i2;
            f3 = Math.min(f3, f4 / ((float) histogramInfo2.median_brightness));
            f = Math.max(f, f4 / ((float) histogramInfo2.median_brightness));
            int min = Math.min(Math.max(i2, (int) (((histogramInfo2.median_brightness * 2.0f) / 3.0f) + 0.5f)), (int) ((histogramInfo2.median_brightness * 1.5f) + 0.5f));
            Log.d(str, "    brightness_target: " + i2);
            Log.d(str, "    preferred brightness scale: " + (f4 / ((float) histogramInfo2.median_brightness)));
            Log.d(str, "    this_brightness_target: " + min);
            Log.d(str, "    actual brightness scale: " + (((float) min) / ((float) histogramInfo2.median_brightness)));
            this.hdrProcessor.brightenImage(list.get(i3), histogramInfo2.median_brightness, histogramInfo2.max_brightness, min);
        }
        Log.d(str, "min_preferred_scale: " + f3);
        Log.d(str, "max_preferred_scale: " + f);
        Log.d(str, "### time after adjusting brightnesses: " + (System.currentTimeMillis() - j));
    }

    private void computePanoramaTransforms(List<Matrix> list, List<Integer> list2, List<Integer> list3, List<Bitmap> list4, int i, int i2, int i3, int i4, int i5, long j) throws PanoramaProcessorException {
        int i6;
        Matrix matrix;
        ArrayList arrayList;
        int i7;
        int i8;
        int i9;
        Matrix matrix2;
        List<Bitmap> list5 = list4;
        int i10 = i2;
        int i11 = i3;
        int i12 = i4;
        Matrix matrix3 = new Matrix();
        ArrayList arrayList2 = new ArrayList();
        int i13 = 0;
        int i14 = 0;
        int i15 = 0;
        while (i14 < list4.size()) {
            Log.d(TAG, "process bitmap: " + i14);
            if (i14 > 0) {
                ArrayList<Bitmap> arrayList3 = new ArrayList();
                Log.d(TAG, "    align_x: " + i13);
                Log.d(TAG, "    offset_x: " + i11);
                Log.d(TAG, "    slice_width: " + i12);
                StringBuilder sb = new StringBuilder();
                sb.append("    align_x+offset_x+slice_width-align_hwidth: ");
                int i16 = i13 + i11;
                int i17 = (i16 + i12) - i5;
                sb.append(i17);
                Log.d(TAG, sb.toString());
                StringBuilder sb2 = new StringBuilder();
                sb2.append("    bitmap(i-1) width: ");
                int i18 = i14 - 1;
                sb2.append(list5.get(i18).getWidth());
                Log.d(TAG, sb2.toString());
                float f = i10;
                float f2 = f / 520.0f;
                StringBuilder sb3 = new StringBuilder();
                i7 = i15;
                sb3.append("downscale by: ");
                sb3.append(f2);
                Log.d(TAG, sb3.toString());
                StringBuilder sb4 = new StringBuilder();
                sb4.append("### time before downscaling creating alignment bitmaps for ");
                sb4.append(i14);
                sb4.append("th bitmap: ");
                ArrayList arrayList4 = arrayList2;
                sb4.append(System.currentTimeMillis() - j);
                Log.d(TAG, sb4.toString());
                int i19 = 0;
                int i20 = 1;
                while (true) {
                    if (i19 > 4) {
                        matrix2 = matrix3;
                        arrayList = arrayList4;
                        break;
                    }
                    float f3 = i20;
                    arrayList = arrayList4;
                    matrix2 = matrix3;
                    double d = f3 / f2;
                    if (d >= 0.949999988079071d && d <= 1.0499999523162842d) {
                        Log.d(TAG, "snapped downscale to: " + f3);
                        f2 = f3;
                        break;
                    }
                    i19++;
                    i20 *= 2;
                    arrayList4 = arrayList;
                    matrix3 = matrix2;
                }
                int i21 = (i10 * 3) / 4;
                Log.d(TAG, "### time before creating alignment bitmaps for " + i14 + "th bitmap: " + (System.currentTimeMillis() - j));
                Matrix matrix4 = new Matrix();
                float f4 = 1.0f / f2;
                matrix4.postScale(f4, f4);
                int i22 = i16 - i5;
                int i23 = (i10 - i21) / 2;
                int i24 = i5 * 2;
                arrayList3.add(Bitmap.createBitmap(list5.get(i14), i22, i23, i24, i21, matrix4, true));
                arrayList3.add(Bitmap.createBitmap(list5.get(i18), i17, i23, i24, i21, matrix4, true));
                Log.d(TAG, "### time after creating alignment bitmaps for " + i14 + "th bitmap: " + (System.currentTimeMillis() - j));
                Log.d(TAG, "### time before auto-alignment for " + i14 + "th bitmap: " + (System.currentTimeMillis() - j));
                AutoAlignmentByFeatureResult autoAlignmentByFeature = autoAlignmentByFeature(arrayList3.get(0).getWidth(), arrayList3.get(0).getHeight(), arrayList3, i14);
                int i25 = autoAlignmentByFeature.offset_x;
                int i26 = autoAlignmentByFeature.offset_y;
                double d2 = (double) autoAlignmentByFeature.rotation;
                float f5 = autoAlignmentByFeature.y_scale;
                Log.d(TAG, "### time after auto-alignment for " + i14 + "th bitmap: " + (System.currentTimeMillis() - j));
                int i27 = (int) (((float) i25) * f2);
                int i28 = (int) (((float) i26) * f2);
                for (Bitmap bitmap : arrayList3) {
                    bitmap.recycle();
                }
                arrayList3.clear();
                Log.d(TAG, "    this_align_x: " + i27);
                Log.d(TAG, "    this_align_y: " + i28);
                Matrix matrix5 = new Matrix();
                matrix5.postRotate((float) Math.toDegrees(d2), (float) i22, 0.0f);
                matrix5.postScale(1.0f, f5);
                matrix5.postTranslate(i27, i28);
                i6 = i4;
                matrix = matrix2;
                matrix.preTranslate(i6, 0.0f);
                matrix.postTranslate(-i6, 0.0f);
                matrix.preConcat(matrix5);
                float f6 = i / 2.0f;
                float[] fArr = {f6, f / 2.0f};
                matrix.mapPoints(fArr);
                i9 = -((int) (fArr[0] - f6));
                Log.d(TAG, "    align_x is now: " + i9);
                StringBuilder sb5 = new StringBuilder();
                sb5.append("");
                i8 = 0;
                sb5.append(0);
                Log.d(TAG, sb5.toString());
            } else {
                i6 = i12;
                matrix = matrix3;
                arrayList = arrayList2;
                i7 = i15;
                i8 = 0;
                i9 = 0;
            }
            list2.add(Integer.valueOf(i9));
            ArrayList arrayList5 = arrayList;
            arrayList5.add(Integer.valueOf(i8));
            list3.add(Integer.valueOf(i7));
            list.add(new Matrix(matrix));
            int i29 = i7 + i6;
            Log.d(TAG, "    dst_offset_x is now: " + i29);
            Log.d(TAG, "### time after processing " + i14 + "th bitmap: " + (System.currentTimeMillis() - j));
            i14++;
            i12 = i6;
            matrix3 = matrix;
            arrayList2 = arrayList5;
            i13 = 0;
            list5 = list4;
            i11 = i3;
            i15 = i29;
            i10 = i2;
        }
    }

    private void adjustPanoramaTransforms(List<Bitmap> list, List<Matrix> list2, int i, int i2, int i3, int i4) {
        float[] fArr = new float[9];
        float f = 1000.0f;
        float f2 = -1000.0f;
        for (int i5 = 0; i5 < list.size(); i5++) {
            list2.get(i5).getValues(fArr);
            float degrees = (float) Math.toDegrees(Math.atan2(fArr[1], fArr[0]));
            Log.d(TAG, "bitmap " + i5 + " has rotation " + degrees + " degrees");
            f = Math.min(f, degrees);
            f2 = Math.max(f2, degrees);
        }
        Log.d(TAG, "min_rotation: " + f + " degrees");
        Log.d(TAG, "max_rotation: " + f2 + " degrees");
        float f3 = ((float) i4) / 2.0f;
        float[] fArr2 = {0.0f, f3};
        list2.get(0).mapPoints(fArr2);
        float f4 = fArr2[0];
        float f5 = fArr2[1];
        fArr2[0] = i3 - 1.0f;
        fArr2[1] = f3;
        list2.get(list2.size() - 1).mapPoints(fArr2);
        float size = fArr2[0] + ((list2.size() - 1) * i2);
        float f6 = fArr2[1];
        float f7 = size - f4;
        float f8 = f6 - f5;
        float f9 = -((float) Math.toDegrees(Math.atan2(f8, f7)));
        Log.d(TAG, "x0: " + f4);
        Log.d(TAG, "y0: " + f5);
        Log.d(TAG, "x1: " + size);
        Log.d(TAG, "y1: " + f6);
        Log.d(TAG, "dx: " + f7);
        Log.d(TAG, "dy: " + f8);
        Log.d(TAG, "mid_rotation: " + f9 + " degrees");
        float min = Math.min(Math.max(f9, f), f2);
        Log.d(TAG, "limited mid_rotation to: " + min + " degrees");
        for (int i6 = 0; i6 < list.size(); i6++) {
            list2.get(i6).postRotate(min, (i / 2.0f) - (i6 * i2), f3);
            list2.get(i6).getValues(fArr);
            Log.d(TAG, "bitmap " + i6 + " now has rotation " + ((float) Math.toDegrees(Math.atan2(fArr[1], fArr[0]))) + " degrees");
        }
    }

    private void renderPanorama(List<Bitmap> list, int i, int i2, List<Matrix> list2, List<Integer> list3, List<Integer> list4, int i3, int i4, int i5, Bitmap bitmap, int i6, int i7, double d, long j) {
        int i8;
        int i9;
        int i10;
        int i11 = i;
        int i12 = i2;
        List<Matrix> list5 = list2;
        List<Integer> list6 = list3;
        Rect rect = new Rect();
        Rect rect2 = new Rect();
        Paint paint = new Paint(2);
        Canvas canvas = new Canvas(bitmap);
        int i13 = 0;
        while (i13 < list.size()) {
            Log.d(TAG, "render bitmap: " + i13);
            Bitmap bitmap2 = list.get(i13);
            int intValue = list6.get(i13).intValue();
            int intValue2 = list4.get(i13).intValue();
            int i14 = -intValue;
            if (i13 != 0) {
                int intValue3 = list6.get(i13 - 1).intValue();
                i9 = intValue2 - intValue3;
                i10 = -intValue3;
                i8 = intValue - intValue3;
            } else {
                i8 = intValue;
                i9 = intValue2;
                i10 = 0;
            }
            if (i10 != 0) {
                float f = i11 / 2.0f;
                float[] fArr = {f, i12 / 2.0f};
                list5.get(i13).mapPoints(fArr);
                int i15 = (int) (fArr[0] - f);
                int i16 = -i10;
                if (i13 == list.size() - 1 && i15 < 0 && i16 + i15 > 0) {
                    i16 = -i15;
                }
                list5.get(i13).postTranslate(i16, 0.0f);
                i14 += i16;
                i10 += i16;
            }
            Bitmap createBitmap = Bitmap.createBitmap(i11, i12, Bitmap.Config.ARGB_8888);
            Canvas canvas2 = new Canvas(createBitmap);
            canvas2.save();
            canvas2.setMatrix(list5.get(i13));
            canvas2.drawBitmap(bitmap2, 0.0f, 0.0f, paint);
            canvas2.restore();
            int i17 = i13;
            Canvas canvas3 = canvas;
            renderPanoramaImage(i13, list.size(), rect, rect2, createBitmap, paint, i, i2, i3, i4, i5, bitmap, canvas3, i6, i7, i10, 0, i9, i8, i14, d, j);
            createBitmap.recycle();
            Log.d(TAG, "### time after rendering " + i17 + "th bitmap: " + (System.currentTimeMillis() - j));
            i13 = i17 + 1;
            i11 = i;
            i12 = i2;
            list5 = list2;
            list6 = list3;
            canvas = canvas3;
            paint = paint;
        }
    }

    public Bitmap panorama(List<Bitmap> list, float f, float f2, boolean z) throws PanoramaProcessorException {
        ArrayList arrayList;
        int i;
        float f3;
        int i2;
        int i3;
        int i4;
        Bitmap bitmap;
        Log.d(TAG, "panorama");
        Log.d(TAG, "camera_angle_y: " + f2);
        long currentTimeMillis = System.currentTimeMillis();
        char c = 0;
        int width = list.get(0).getWidth();
        int height = list.get(0).getHeight();
        Log.d(TAG, "bitmap_width: " + width);
        Log.d(TAG, "bitmap_height: " + height);
        for (int i5 = 1; i5 < list.size(); i5++) {
            Bitmap bitmap2 = list.get(i5);
            if (bitmap2.getWidth() != width || bitmap2.getHeight() != height) {
                Log.e(TAG, "bitmaps not of equal sizes");
                throw new PanoramaProcessorException(1);
            }
        }
        float f4 = width;
        int i6 = (int) (f4 / f);
        Log.d(TAG, "slice_width: " + i6);
        double radians = Math.toRadians((double) f2);
        Log.d(TAG, "camera_angle_y: " + f2);
        Log.d(TAG, "camera_angle: " + radians);
        int i7 = (width - i6) / 2;
        int nextMultiple = nextMultiple((int) ((f4 / 6.1f) + 0.5f), getBlendDimension() / 2);
        int i8 = width / 10;
        Log.d(TAG, "    blend_hwidth: " + nextMultiple);
        Log.d(TAG, "    align_hwidth: " + i8);
        ArrayList<Matrix> arrayList2 = new ArrayList();
        ArrayList<Integer> arrayList3 = new ArrayList();
        ArrayList<Integer> arrayList4 = new ArrayList();
        ArrayList<Matrix> arrayList5 = arrayList2;
        computePanoramaTransforms(arrayList2, arrayList3, arrayList4, list, width, height, i7, i6, i8, currentTimeMillis);
        int size = (list.size() * i6) + (i7 * 2);
        Log.d(TAG, "original panorama_width: " + size);
        adjustPanoramaTransforms(list, arrayList5, size, i6, width, height);
        Log.d(TAG, "### time after adjusting transforms: " + (System.currentTimeMillis() - currentTimeMillis));
        float adjustExposuresLocal = adjustExposuresLocal(list, width, height, i6, currentTimeMillis);
        if (z) {
            int i9 = width - 1;
            i = height;
            int i10 = i - 1;
            int i11 = i9;
            int i12 = 0;
            int i13 = 0;
            int i14 = 0;
            while (i12 < list.size()) {
                float[] fArr = new float[8];
                fArr[c] = 0.0f;
                fArr[1] = 0.0f;
                float f5 = f4 - 1.0f;
                fArr[2] = f5;
                fArr[3] = 0.0f;
                fArr[4] = 0.0f;
                float f6 = i - 1.0f;
                fArr[5] = f6;
                fArr[6] = f5;
                fArr[7] = f6;
                ArrayList<Matrix> arrayList6 = arrayList5;
                arrayList6.get(i12).mapPoints(fArr);
                i14 = Math.max(Math.max(i14, (int) fArr[1]), (int) fArr[3]);
                int min = Math.min(Math.min(i10, (int) fArr[5]), (int) fArr[7]);
                Log.d(TAG, "i: " + i12);
                Log.d(TAG, "    points[0]: " + fArr[0]);
                Log.d(TAG, "    points[1]: " + fArr[1]);
                Log.d(TAG, "    points[2]: " + fArr[2]);
                Log.d(TAG, "    points[3]: " + fArr[3]);
                Log.d(TAG, "    points[4]: " + fArr[4]);
                Log.d(TAG, "    points[5]: " + fArr[5]);
                Log.d(TAG, "    points[6]: " + fArr[6]);
                Log.d(TAG, "    points[7]: " + fArr[7]);
                if (i12 == 0) {
                    i13 = Math.max(Math.max(i13, (int) fArr[0]), (int) fArr[4]);
                }
                if (i12 == list.size() - 1) {
                    i11 = Math.min(Math.min(i11, (int) fArr[2]), (int) fArr[6]);
                }
                i12++;
                i10 = min;
                arrayList5 = arrayList6;
                c = 0;
            }
            arrayList = arrayList5;
            size = (size - (i9 - i11)) - i13;
            Log.d(TAG, "crop_x0: " + i13);
            Log.d(TAG, "crop_x1: " + i11);
            Log.d(TAG, "panorama_width: " + size);
            Log.d(TAG, "crop_y0: " + i14);
            Log.d(TAG, "crop_y1: " + i10);
            Log.d(TAG, "panorama_height: " + ((i10 - i14) + 1));
            float f7 = ((float) (((double) (width / 2)) * radians)) / f4;
            f3 = adjustExposuresLocal;
            float cos = (float) Math.cos((double) f7);
            Log.d(TAG, "theta: " + f7);
            Log.d(TAG, "yscale: " + cos);
            float f8 = ((float) i) / 2.0f;
            int i15 = (int) (((((float) i14) - f8) * cos) + f8 + 0.5f);
            int i16 = (int) (f8 + (cos * (((float) i10) - f8)) + 0.5f);
            i2 = (i16 - i15) + 1;
            Log.d(TAG, "crop_y0: " + i15);
            Log.d(TAG, "crop_y1: " + i16);
            Log.d(TAG, "panorama_height: " + i2);
            i3 = i13;
            i4 = i15;
        } else {
            arrayList = arrayList5;
            i = height;
            f3 = adjustExposuresLocal;
            i2 = i;
            i3 = 0;
            i4 = 0;
        }
        Bitmap createBitmap = Bitmap.createBitmap(size, i2, Bitmap.Config.ARGB_8888);
        Log.d(TAG, "### time before rendering bitmaps: " + (System.currentTimeMillis() - currentTimeMillis));
        float f9 = f3;
        renderPanorama(list, width, i, arrayList, arrayList3, arrayList4, nextMultiple, i6, i7, createBitmap, i3, i4, radians, currentTimeMillis);
        Log.d(TAG, "### time after rendering bitmaps: " + (System.currentTimeMillis() - currentTimeMillis));
        for (Bitmap bitmap3 : list) {
            bitmap3.recycle();
        }
        list.clear();
        if (f9 >= 3.0f) {
            Log.d(TAG, "apply contrast enhancement, ratio_brightnesses: " + f9);
            bitmap = createBitmap;
            Allocation createFromBitmap = Allocation.createFromBitmap(this.rs, bitmap);
            Log.d(TAG, "### time after creating allocation_out: " + (System.currentTimeMillis() - currentTimeMillis));
            this.hdrProcessor.adjustHistogram(createFromBitmap, createFromBitmap, bitmap.getWidth(), bitmap.getHeight(), 0.25f, 1, true, currentTimeMillis);
            Log.d(TAG, "### time after adjustHistogram: " + (System.currentTimeMillis() - currentTimeMillis));
            createFromBitmap.copyTo(bitmap);
            createFromBitmap.destroy();
            Log.d(TAG, "### time after copying to bitmap: " + (System.currentTimeMillis() - currentTimeMillis));
        } else {
            bitmap = createBitmap;
        }
        Log.d(TAG, "panorama complete!");
        freeScripts();
        Log.d(TAG, "### time taken: " + (System.currentTimeMillis() - currentTimeMillis));
        return bitmap;
    }
}
