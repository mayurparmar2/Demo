package com.live.gpsmap.camera.Camera.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.exifinterface.media.ExifInterface;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.live.gpsmap.camera.Camera.CameraMainActivity;
import com.live.gpsmap.camera.Camera.PreferenceKeys;
import com.live.gpsmap.camera.Camera.adapter.FlashAdapter;
import com.live.gpsmap.camera.Camera.adapter.GridAdapter;
import com.live.gpsmap.camera.Camera.onRecyclerClickListener;
import com.live.gpsmap.camera.Camera.preview.Preview;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.SP;

public class GridFragment extends Fragment implements View.OnClickListener {
    boolean camera_sound;
    int flashPos;
    String[] flash_entries;
    String[] flash_values;
    String focus_value;
    int gridPos;
    String[] grid_entries;
    String[] grid_values;
    RecyclerView mFlase;
    GridAdapter mGridAdapter;
    RecyclerView mGridRecycler;
    SP mSP;
    private RelativeLayout mToolbar_back;
    CameraMainActivity mainActivity;
    FlashAdapter mflashAdapter;
    String mirrorValue;
    private TextView mtv_toolbar_title;
    boolean oldcamera_sound;
    int oldflashPos;
    String oldfocus_value;
    int oldgridPos;
    String oldmirrorValue;
    String oldtimer;
    private Preview preview;
    SharedPreferences sharedPreferences;
    String timer;
    TextView tv_3sec;
    TextView tv_5sec;
    TextView tv_auto;
    TextView tv_mirr_off;
    TextView tv_mirr_on;
    TextView tv_off;
    TextView tv_sound_off;
    TextView tv_sound_on;
    TextView tv_touch;

    public GridFragment(CameraMainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.camera_setting, viewGroup, false);
    }

    @Override
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.mToolbar_back = (RelativeLayout) view.findViewById(R.id.toolbar_back);
        this.mtv_toolbar_title = (TextView) view.findViewById(R.id.tv_toolbar_title);
        this.tv_off = (TextView) view.findViewById(R.id.tv_off);
        this.tv_3sec = (TextView) view.findViewById(R.id.tv_3sec);
        this.tv_5sec = (TextView) view.findViewById(R.id.tv_5sec);
        this.tv_auto = (TextView) view.findViewById(R.id.tv_auto);
        this.tv_touch = (TextView) view.findViewById(R.id.tv_touch);
        this.tv_mirr_on = (TextView) view.findViewById(R.id.tv_mirr_on);
        this.tv_mirr_off = (TextView) view.findViewById(R.id.tv_mirr_off);
        this.tv_sound_on = (TextView) view.findViewById(R.id.tv_sound_on);
        this.tv_sound_off = (TextView) view.findViewById(R.id.tv_sound_off);
        this.mtv_toolbar_title.setText(getString(R.string.camera_setting));
        this.preview = this.mainActivity.getPreview();
        this.mSP = new SP(getActivity());
        this.gridPos = getGridPos();
        this.flashPos = getFlasPos();
        this.timer = getTimer();
        this.focus_value = getfocus();
        this.mirrorValue = getmirror();
        boolean z = getcamera_sound();
        this.camera_sound = z;
        this.oldgridPos = this.gridPos;
        this.oldflashPos = this.flashPos;
        this.oldtimer = this.timer;
        this.oldfocus_value = this.focus_value;
        this.oldmirrorValue = this.mirrorValue;
        this.oldcamera_sound = z;
        settimer();
        setfocus();
        setmirror();
        setcamra_sound();
        this.mGridRecycler = (RecyclerView) view.findViewById(R.id.grid_recyclerView);
        this.mFlase = (RecyclerView) view.findViewById(R.id.mflase);
        setAdapter();
        loadAds(view);
        onCliks();
    }

    private void setcamra_sound() {
        this.tv_sound_on.setBackground(getActivity().getResources().getDrawable(R.drawable.unselect_back));
        this.tv_sound_off.setBackground(getActivity().getResources().getDrawable(R.drawable.unselect_back));
        if (this.camera_sound) {
            this.tv_sound_on.setBackground(getActivity().getResources().getDrawable(R.drawable.selected_back));
        } else {
            this.tv_sound_off.setBackground(getActivity().getResources().getDrawable(R.drawable.selected_back));
        }
    }

    private boolean getcamera_sound() {
        return this.mainActivity.applicationInterface.getShutterSoundPref();
    }

    private void setmirror() {
        this.tv_mirr_on.setBackground(getActivity().getResources().getDrawable(R.drawable.unselect_back));
        this.tv_mirr_off.setBackground(getActivity().getResources().getDrawable(R.drawable.unselect_back));
        if (this.mirrorValue.equals("preference_front_camera_mirror_photo")) {
            this.tv_mirr_on.setBackground(getActivity().getResources().getDrawable(R.drawable.selected_back));
        } else {
            this.tv_mirr_off.setBackground(getActivity().getResources().getDrawable(R.drawable.selected_back));
        }
    }

    private String getmirror() {
        return this.mSP.getString(getActivity(), PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_no");
    }

    private void setfocus() {
        this.tv_touch.setBackground(getActivity().getResources().getDrawable(R.drawable.unselect_back));
        this.tv_auto.setBackground(getActivity().getResources().getDrawable(R.drawable.unselect_back));
        if (this.focus_value.equals("focus_mode_auto")) {
            this.tv_auto.setBackground(getActivity().getResources().getDrawable(R.drawable.selected_back));
        } else {
            this.tv_touch.setBackground(getActivity().getResources().getDrawable(R.drawable.selected_back));
        }
    }

    private String getfocus() {
        return this.mainActivity.applicationInterface.getFocusPref(false);
    }

    private void settimer() {
        this.tv_3sec.setBackground(getActivity().getResources().getDrawable(R.drawable.unselect_back));
        this.tv_5sec.setBackground(getActivity().getResources().getDrawable(R.drawable.unselect_back));
        this.tv_off.setBackground(getActivity().getResources().getDrawable(R.drawable.unselect_back));
        String str = this.timer;
        str.hashCode();
        char c = 65535;
        switch (str.hashCode()) {
            case 48:
                if (str.equals("nXtPBjQgziZk.fKkICQRcfoS")) {//Changed
                    c = 0;
                    break;
                }
                break;
            case 51:
                if (str.equals(ExifInterface.GPS_MEASUREMENT_3D)) {
                    c = 1;
                    break;
                }
                break;
            case 53:
                if (str.equals("5")) {
                    c = 2;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                this.tv_off.setBackground(getActivity().getResources().getDrawable(R.drawable.selected_back));
                return;
            case 1:
                this.tv_3sec.setBackground(getActivity().getResources().getDrawable(R.drawable.selected_back));
                return;
            case 2:
                this.tv_5sec.setBackground(getActivity().getResources().getDrawable(R.drawable.selected_back));
                return;
            default:
                return;
        }
    }

    private String getTimer() {
        return this.mSP.getString(getActivity(), PreferenceKeys.TimerPreferenceKey, /*YLpwb.XtXAo*/"");//Changed
    }

    private int getFlasPos() {
        return this.mSP.getInteger(getActivity(), PreferenceKeys.FLASH_POS, 0);
    }

    private void onCliks() {
        this.mToolbar_back.setOnClickListener(this);
        this.tv_3sec.setOnClickListener(this);
        this.tv_5sec.setOnClickListener(this);
        this.tv_off.setOnClickListener(this);
        this.tv_auto.setOnClickListener(this);
        this.tv_touch.setOnClickListener(this);
        this.tv_mirr_on.setOnClickListener(this);
        this.tv_mirr_off.setOnClickListener(this);
        this.tv_sound_on.setOnClickListener(this);
        this.tv_sound_off.setOnClickListener(this);
    }

    private void loadAds(View view) {
//        new Admob().loadAdaptive_banner(getActivity(), (RelativeLayout) view.findViewById(R.id.rel_adaptive_banner), getString(R.string.GMC_Banner_Details));
    }

    private int getGridPos() {
        return this.mSP.getInteger(getActivity(), PreferenceKeys.GRID_POS, 0);
    }

    private void setAdapter() {
        this.grid_values = getResources().getStringArray(R.array.preference_grid_values);
        this.grid_entries = getResources().getStringArray(R.array.preference_grid_entries);
        this.flash_values = getResources().getStringArray(R.array.flash_values);
        this.flash_entries = getResources().getStringArray(R.array.flash_entries);
        this.mGridRecycler.setLayoutManager(new LinearLayoutManager(getActivity(), RecyclerView.HORIZONTAL, false));
        GridAdapter gridAdapter = new GridAdapter(getActivity(), this.grid_entries, new onRecyclerClickListener() { // from class: com.live.gpsmap.camera.Camera.fragments.GridFragment.1
            @Override // com.live.gpsmap.camera.Camera.onRecyclerClickListener
            public void setOnItemClickListener(int i, View view) {
                if (i < 0 || i >= GridFragment.this.grid_values.length) {
                    return;
                }
                GridFragment.this.gridPos = i;
            }
        });
        this.mGridAdapter = gridAdapter;
        this.mGridRecycler.setAdapter(gridAdapter);
        this.mFlase.setLayoutManager(new LinearLayoutManager(getActivity(), RecyclerView.HORIZONTAL, false));
        FlashAdapter flashAdapter = new FlashAdapter(getActivity(), this.flash_entries, new onRecyclerClickListener() {
            @Override
            public void setOnItemClickListener(int i, View view) {
                if (i < 0 || i >= GridFragment.this.flash_values.length) {
                    return;
                }
                GridFragment.this.flashPos = i;
            }
        });
        this.mflashAdapter = flashAdapter;
        this.mFlase.setAdapter(flashAdapter);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.toolbar_back /* 2131362806 */:
                doBack();
                return;
            case R.id.toolbar_done /* 2131362807 */:
                saveData();
                return;
            case R.id.tv_3sec /* 2131362829 */:
                this.timer = ExifInterface.GPS_MEASUREMENT_3D;
                settimer();
                return;
            case R.id.tv_5sec /* 2131362830 */:
                this.timer = "5";
                settimer();
                return;
            case R.id.tv_auto /* 2131362834 */:
                this.focus_value = "focus_mode_auto";
                setfocus();
                return;
            case R.id.tv_mirr_off /* 2131362862 */:
                this.mirrorValue = "preference_front_camera_mirror_no";
                setmirror();
                return;
            case R.id.tv_mirr_on /* 2131362863 */:
                this.mirrorValue = "preference_front_camera_mirror_photo";
                setmirror();
                return;
            case R.id.tv_off /* 2131362865 */:
                this.timer = "0";
                settimer();
                return;
            case R.id.tv_sound_off /* 2131362871 */:
                this.camera_sound = false;
                setcamra_sound();
                return;
            case R.id.tv_sound_on /* 2131362872 */:
                this.camera_sound = true;
                setcamra_sound();
                return;
            case R.id.tv_touch /* 2131362877 */:
                this.focus_value = "";
                setfocus();
                return;
            default:
                return;
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        super.onAttach(context);
        if (getActivity() != null) {
            ((CameraMainActivity) getActivity()).hideUi();
            ((CameraMainActivity) getActivity()).lockDrawer();
            ((CameraMainActivity) getActivity()).setOnBackPressedListener(new CameraMainActivity.OnBackPressedListener() { // from class: com.live.gpsmap.camera.Camera.fragments.GridFragment.3
                @Override // com.live.gpsmap.camera.Camera.MainActivity.OnBackPressedListener
                public void onBackPressed() {
                    GridFragment.this.doBack();
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doBack() {
        if (isChanges()) {
            saveData();
        } else {
            getActivity().getSupportFragmentManager().popBackStack();
        }
    }

    private boolean isChanges() {
        return (this.gridPos == this.oldgridPos && this.flashPos == this.oldflashPos && this.timer.equals(this.oldtimer) && this.focus_value.equals(this.oldfocus_value) && this.mirrorValue.equals(this.oldmirrorValue) && this.camera_sound == this.oldcamera_sound) ? false : true;
    }

    @Override // androidx.fragment.app.Fragment
    public void onDetach() {
        super.onDetach();
        if (getActivity() != null) {
            ((CameraMainActivity) getActivity()).showUI();
            ((CameraMainActivity) getActivity()).unLockDrawer();
            ((CameraMainActivity) getActivity()).updateGrid();
            ((CameraMainActivity) getActivity()).setOnBackPressedListener(null);
        }
    }

    private void saveData() {
        this.mSP.setInteger(getActivity(), PreferenceKeys.GRID_POS, this.gridPos);
        this.mSP.setString(getActivity(), PreferenceKeys.ShowGridPreferenceKey, this.grid_values[this.gridPos]);
        this.mSP.setInteger(getActivity(), PreferenceKeys.FLASH_POS, this.flashPos);
        this.preview.updateFlash(this.flash_values[this.flashPos], true);
        this.mSP.setString(getActivity(), PreferenceKeys.TimerPreferenceKey, this.timer);
        if (this.focus_value.equals("focus_mode_auto")) {
            this.preview.updateFocus("focus_mode_auto", false, true);
        } else {
            this.preview.updateFocus("focus_mode_continuous_picture", false, true);
        }
        if (this.mirrorValue.equals("preference_front_camera_mirror_photo")) {
            this.mSP.setString(getActivity(), PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_photo");
        } else {
            this.mSP.setString(getActivity(), PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_no");
        }
        if (this.camera_sound) {
            this.mainActivity.applicationInterface.setShutterSoundPref(true);
        } else {
            this.mainActivity.applicationInterface.setShutterSoundPref(false);
        }
        if (((FragmentActivity) requireActivity()).isFinishing()) {
            return;
        }
        getActivity().getSupportFragmentManager().popBackStack();
    }
}
