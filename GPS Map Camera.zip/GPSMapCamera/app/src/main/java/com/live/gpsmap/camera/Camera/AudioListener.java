package com.live.gpsmap.camera.Camera;

import android.annotation.SuppressLint;
import android.media.AudioRecord;
import android.util.Log;

public class AudioListener {
    private static final String TAG = "AudioListener";
    private AudioRecord ar;
    private int buffer_size;
    private volatile boolean is_running = true;
    private Thread thread;

    /* loaded from: classes3.dex */
    public interface AudioListenerCallback {
        void onAudio(int i);
    }

    @SuppressLint("MissingPermission")
    AudioListener(final AudioListenerCallback audioListenerCallback) {
        this.buffer_size = -1;
        Log.d(TAG, "new AudioListener");
        try {
            this.buffer_size = AudioRecord.getMinBufferSize(8000, 16, 2);
            Log.d(TAG, "buffer_size: " + this.buffer_size);
            int i = this.buffer_size;
            if (i <= 0) {
                if (i == -1) {
                    Log.e(TAG, "getMinBufferSize returned ERROR");
                    return;
                } else if (i == -2) {
                    Log.e(TAG, "getMinBufferSize returned ERROR_BAD_VALUE");
                    return;
                } else {
                    return;
                }
            }
            synchronized (this) {
                this.ar = new AudioRecord(1, 8000, 16, 2, this.buffer_size);
                notifyAll();
            }
            synchronized (this) {
                if (this.ar.getState() == 1) {
                    Log.d(TAG, "audiorecord is initialised");
                    final short[] sArr = new short[this.buffer_size];
                    this.ar.startRecording();
                    this.thread = new Thread() { // from class: com.live.gpsmap.camera.Camera.AudioListener.1
                        @Override // java.lang.Thread, java.lang.Runnable
                        public void run() {
                            while (AudioListener.this.is_running) {
                                try {
                                    int read = AudioListener.this.ar.read(sArr, 0, AudioListener.this.buffer_size);
                                    if (read > 0) {
                                        int i2 = 0;
                                        int i3 = 0;
                                        for (int i4 = 0; i4 < read; i4++) {
                                            int abs = Math.abs((int) sArr[i4]);
                                            i2 += abs;
                                            i3 = Math.max(i3, abs);
                                        }
                                        audioListenerCallback.onAudio(i2 / read);
                                    } else {
                                        Log.d(AudioListener.TAG, "n_read: " + read);
                                        if (read == -3) {
                                            Log.e(AudioListener.TAG, "read returned ERROR_INVALID_OPERATION");
                                        } else if (read == -2) {
                                            Log.e(AudioListener.TAG, "read returned ERROR_BAD_VALUE");
                                        }
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    Log.e(AudioListener.TAG, "failed to read from audiorecord");
                                }
                            }
                            Log.d(AudioListener.TAG, "stopped running");
                            synchronized (AudioListener.this) {
                                Log.d(AudioListener.TAG, "release ar");
                                AudioListener.this.ar.release();
                                AudioListener.this.ar = null;
                                AudioListener.this.notifyAll();
                            }
                        }
                    };
                    return;
                }
                this.ar.release();
                this.ar = null;
                notifyAll();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG, "failed to create audiorecord");
        }
    }

    boolean status() {
        boolean z;
        synchronized (this) {
            z = this.ar != null;
        }
        return z;
    }

    void start() {
        Log.d(TAG, "start");
        Thread thread = this.thread;
        if (thread != null) {
            thread.start();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void release(boolean z) {
        Log.d(TAG, "release");
        Log.d(TAG, "wait_until_done: " + z);
        this.is_running = false;
        this.thread = null;
        if (z) {
            Log.d(TAG, "wait until audio listener is freed");
            synchronized (this) {
                while (this.ar != null) {
                    Log.d(TAG, "ar still not freed, so wait");
                    try {
                        wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        Log.e(TAG, "interrupted while waiting for audio recorder to be freed");
                    }
                }
            }
            Log.d(TAG, "audio listener is now freed");
        }
    }
}
