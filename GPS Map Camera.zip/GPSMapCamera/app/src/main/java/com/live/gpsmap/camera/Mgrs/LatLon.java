package com.live.gpsmap.camera.Mgrs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/* loaded from: classes.dex */
public class LatLon {
    public static final LatLon ZERO = new LatLon(Angle.ZERO, Angle.ZERO);
    public final Angle latitude;
    public final Angle longitude;

    public static LatLon fromRadians(double d, double d2) {
        return new LatLon(Math.toDegrees(d), Math.toDegrees(d2));
    }

    public static LatLon fromDegrees(double d, double d2) {
        return new LatLon(d, d2);
    }

    private LatLon(double d, double d2) {
        this.latitude = Angle.fromDegrees(d);
        this.longitude = Angle.fromDegrees(d2);
    }

    public LatLon(Angle angle, Angle angle2) {
        if (angle == null || angle2 == null) {
            throw new IllegalArgumentException("Latitude Or Longitude Is Null");
        }
        this.latitude = angle;
        this.longitude = angle2;
    }

    public LatLon(LatLon latLon) {
        if (latLon != null) {
            this.latitude = latLon.latitude;
            this.longitude = latLon.longitude;
            return;
        }
        throw new IllegalArgumentException("Lat Lon Is Null");
    }

    public final Angle getLatitude() {
        return this.latitude;
    }

    public final Angle getLongitude() {
        return this.longitude;
    }

    public double[] asDegreesArray() {
        return new double[]{getLatitude().degrees, getLongitude().degrees};
    }

    public double[] asRadiansArray() {
        return new double[]{getLatitude().radians, getLongitude().radians};
    }

    public static LatLon interpolate(double d, LatLon latLon, LatLon latLon2) {
        if (latLon == null || latLon2 == null) {
            throw new IllegalArgumentException("Lat Lon Is Null");
        }
        if (equals(latLon, latLon2)) {
            return latLon;
        }
        try {
            Vec4 pointAt = Line.fromSegment(new Vec4(latLon.getLongitude().radians, latLon.getLatitude().radians, 0.0d), new Vec4(latLon2.getLongitude().radians, latLon2.getLatitude().radians, 0.0d)).getPointAt(d);
            return fromRadians(pointAt.y(), pointAt.x);
        } catch (IllegalArgumentException unused) {
            return latLon;
        }
    }

    public static LatLon interpolateGreatCircle(double d, LatLon latLon, LatLon latLon2) {
        if (latLon == null || latLon2 == null) {
            throw new IllegalArgumentException("Lat Lon Is Null");
        }
        return equals(latLon, latLon2) ? latLon : greatCircleEndPosition(latLon, greatCircleAzimuth(latLon, latLon2), Angle.fromDegrees(WWMath.clamp(d, (double) 0.0d, 1.0d) * greatCircleDistance(latLon, latLon2).degrees));
    }

    public static LatLon interpolateRhumb(double d, LatLon latLon, LatLon latLon2) {
        if (latLon == null || latLon2 == null) {
            throw new IllegalArgumentException("Lat Lon Is Null");
        }
        return equals(latLon, latLon2) ? latLon : rhumbEndPosition(latLon, rhumbAzimuth(latLon, latLon2), Angle.fromDegrees(WWMath.clamp(d, (double) 0.0d, 1.0d) * rhumbDistance(latLon, latLon2).degrees));
    }

    public static Angle greatCircleDistance(LatLon latLon, LatLon latLon2) {
        if (latLon == null || latLon2 == null) {
            throw new IllegalArgumentException("Lat Lon Is Null");
        }
        double d = latLon.getLatitude().radians;
        double d2 = latLon.getLongitude().radians;
        double d3 = latLon2.getLatitude().radians;
        double d4 = latLon2.getLongitude().radians;
        if (d == d3 && d2 == d4) {
            return Angle.ZERO;
        }
        double sin = Math.sin((d3 - d) / 2.0d);
        double sin2 = Math.sin((d4 - d2) / 2.0d);
        double asin = Math.asin(Math.sqrt((sin * sin) + (Math.cos(d) * Math.cos(d3) * sin2 * sin2))) * 2.0d;
        return Double.isNaN(asin) ? Angle.ZERO : Angle.fromRadians(asin);
    }

    public static Angle greatCircleAzimuth(LatLon latLon, LatLon latLon2) {
        if (latLon == null || latLon2 == null) {
            throw new IllegalArgumentException("Lat Lon Is Null");
        }
        double d = latLon.getLatitude().radians;
        double d2 = latLon.getLongitude().radians;
        double d3 = latLon2.getLatitude().radians;
        double d4 = latLon2.getLongitude().radians;
        int i = (d > d3 ? 1 : (d == d3 ? 0 : -1));
        if (i == 0 && d2 == d4) {
            return Angle.ZERO;
        }
        if (d2 == d4) {
            return i > 0 ? Angle.POS180 : Angle.ZERO;
        }
        double d5 = d4 - d2;
        double atan2 = Math.atan2(Math.cos(d3) * Math.sin(d5), (Math.cos(d) * Math.sin(d3)) - ((Math.sin(d) * Math.cos(d3)) * Math.cos(d5)));
        return Double.isNaN(atan2) ? Angle.ZERO : Angle.fromRadians(atan2);
    }

    public static LatLon greatCircleEndPosition(LatLon latLon, Angle angle, Angle angle2) {
        if (latLon != null) {
            if (angle == null || angle2 == null) {
                throw new IllegalArgumentException("Angle Is Null");
            }
            double d = latLon.getLatitude().radians;
            double d2 = latLon.getLongitude().radians;
            double d3 = angle.radians;
            double d4 = angle2.radians;
            if (d4 == 0.0d) {
                return latLon;
            }
            double asin = Math.asin((Math.sin(d) * Math.cos(d4)) + (Math.cos(d) * Math.sin(d4) * Math.cos(d3)));
            double atan2 = d2 + Math.atan2(Math.sin(d4) * Math.sin(d3), (Math.cos(d) * Math.cos(d4)) - ((Math.sin(d) * Math.sin(d4)) * Math.cos(d3)));
            return (Double.isNaN(asin) || Double.isNaN(atan2)) ? latLon : new LatLon(Angle.fromRadians(asin).normalizedLatitude(), Angle.fromRadians(atan2).normalizedLongitude());
        }
        throw new IllegalArgumentException("Lat Lon Is Null");
    }

    public static LatLon greatCircleEndPosition(LatLon latLon, double d, double d2) {
        if (latLon != null) {
            return greatCircleEndPosition(latLon, Angle.fromRadians(d), Angle.fromRadians(d2));
        }
        throw new IllegalArgumentException("Lat Lon Is Null");
    }

    public static LatLon[] greatCircleExtremeLocations(LatLon latLon, Angle angle) {
        if (latLon != null) {
            if (angle != null) {
                double atan = Math.atan((-Math.tan(latLon.getLatitude().radians)) / Math.cos(angle.radians));
                return new LatLon[]{greatCircleEndPosition(latLon, angle, Angle.fromRadians(atan + 1.5707963267948966d)), greatCircleEndPosition(latLon, angle, Angle.fromRadians(atan - 1.5707963267948966d))};
            }
            throw new IllegalArgumentException("Azimuth Is Null");
        }
        throw new IllegalArgumentException("Location Is Null");
    }

    public static LatLon[] greatCircleArcExtremeLocations(LatLon latLon, LatLon latLon2) {
        if (latLon != null) {
            if (latLon2 != null) {
                double d = Angle.POS90.degrees;
                double d2 = Angle.NEG90.degrees;
                LatLon latLon3 = null;
                LatLon latLon4 = null;
                for (LatLon latLon5 : Arrays.asList(latLon, latLon2)) {
                    if (d >= latLon5.getLatitude().degrees) {
                        d = latLon5.getLatitude().degrees;
                        latLon3 = latLon5;
                    }
                    if (d2 <= latLon5.getLatitude().degrees) {
                        d2 = latLon5.getLatitude().degrees;
                        latLon4 = latLon5;
                    }
                }
                Angle greatCircleAzimuth = greatCircleAzimuth(latLon, latLon2);
                Angle greatCircleDistance = greatCircleDistance(latLon, latLon2);
                LatLon[] greatCircleExtremeLocations = greatCircleExtremeLocations(latLon, greatCircleAzimuth);
                int length = greatCircleExtremeLocations.length;
                int i = 0;
                while (i < length) {
                    LatLon latLon6 = greatCircleExtremeLocations[i];
                    Angle greatCircleAzimuth2 = greatCircleAzimuth(latLon, latLon6);
                    Angle greatCircleDistance2 = greatCircleDistance(latLon, latLon6);
                    LatLon[] latLonArr = greatCircleExtremeLocations;
                    int i2 = length;
                    LatLon latLon7 = latLon3;
                    if (Math.signum(greatCircleAzimuth2.degrees) != Math.signum(greatCircleAzimuth.degrees) || greatCircleDistance2.degrees < 0.0d || greatCircleDistance2.degrees > greatCircleDistance.degrees) {
                        latLon3 = latLon7;
                    } else {
                        if (d >= latLon6.getLatitude().degrees) {
                            d = latLon6.getLatitude().degrees;
                            latLon3 = latLon6;
                        } else {
                            latLon3 = latLon7;
                        }
                        if (d2 <= latLon6.getLatitude().degrees) {
                            d2 = latLon6.getLatitude().degrees;
                            latLon4 = latLon6;
                        }
                    }
                    i++;
                    greatCircleExtremeLocations = latLonArr;
                    length = i2;
                }
                return new LatLon[]{latLon3, latLon4};
            }
            throw new IllegalArgumentException("End Is Null");
        }
        throw new IllegalArgumentException("Begin Is Null");
    }

    public static LatLon[] greatCircleArcExtremeLocations(Iterable<? extends LatLon> iterable) {
        LatLon[] greatCircleArcExtremeLocations;
        if (iterable != null) {
            LatLon latLon = null;
            LatLon latLon2 = null;
            LatLon latLon3 = null;
            for (LatLon latLon4 : iterable) {
                if (latLon3 != null && (greatCircleArcExtremeLocations = greatCircleArcExtremeLocations(latLon3, latLon4)) != null) {
                    if (latLon == null || latLon.getLatitude().degrees > greatCircleArcExtremeLocations[0].getLatitude().degrees) {
                        latLon = greatCircleArcExtremeLocations[0];
                    }
                    if (latLon2 == null || latLon2.getLatitude().degrees < greatCircleArcExtremeLocations[1].getLatitude().degrees) {
                        latLon2 = greatCircleArcExtremeLocations[1];
                    }
                }
                latLon3 = latLon4;
            }
            return new LatLon[]{latLon, latLon2};
        }
        throw new IllegalArgumentException("Locations List Is Null");
    }

    public static Angle rhumbDistance(LatLon latLon, LatLon latLon2) {
        if (latLon == null || latLon2 == null) {
            throw new IllegalArgumentException("LatLon Is Null");
        }
        double d = latLon.getLatitude().radians;
        double d2 = latLon.getLongitude().radians;
        double d3 = latLon2.getLatitude().radians;
        double d4 = latLon2.getLongitude().radians;
        if (d == d3 && d2 == d4) {
            return Angle.ZERO;
        }
        double d5 = d3 - d;
        double d6 = d4 - d2;
        double log = Math.log(Math.tan((d3 / 2.0d) + 0.7853981633974483d) / Math.tan((d / 2.0d) + 0.7853981633974483d));
        double d7 = d5 / log;
        if (Double.isNaN(log) || Double.isNaN(d7)) {
            d7 = Math.cos(d);
        }
        if (Math.abs(d6) > 3.141592653589793d) {
            d6 = d6 > 0.0d ? -(6.283185307179586d - d6) : d6 + 6.283185307179586d;
        }
        double sqrt = Math.sqrt((d5 * d5) + (d7 * d7 * d6 * d6));
        return Double.isNaN(sqrt) ? Angle.ZERO : Angle.fromRadians(sqrt);
    }

    public static Angle rhumbAzimuth(LatLon latLon, LatLon latLon2) {
        if (latLon == null || latLon2 == null) {
            throw new IllegalArgumentException("LatLon Is Null");
        }
        double d = latLon.getLatitude().radians;
        double d2 = latLon.getLongitude().radians;
        double d3 = latLon2.getLatitude().radians;
        double d4 = latLon2.getLongitude().radians;
        if (d == d3 && d2 == d4) {
            return Angle.ZERO;
        }
        double d5 = d4 - d2;
        double log = Math.log(Math.tan((d3 / 2.0d) + 0.7853981633974483d) / Math.tan((d / 2.0d) + 0.7853981633974483d));
        if (Math.abs(d5) > 3.141592653589793d) {
            d5 = d5 > 0.0d ? -(6.283185307179586d - d5) : d5 + 6.283185307179586d;
        }
        double atan2 = Math.atan2(d5, log);
        return Double.isNaN(atan2) ? Angle.ZERO : Angle.fromRadians(atan2);
    }

    public static LatLon rhumbEndPosition(LatLon latLon, Angle angle, Angle angle2) {
        if (latLon != null) {
            if (angle == null || angle2 == null) {
                throw new IllegalArgumentException("Angle Is Null");
            }
            double d = latLon.getLatitude().radians;
            double d2 = latLon.getLongitude().radians;
            double d3 = angle.radians;
            double d4 = angle2.radians;
            if (d4 == 0.0d) {
                return latLon;
            }
            double cos = (Math.cos(d3) * d4) + d;
            double log = Math.log(Math.tan((cos / 2.0d) + 0.7853981633974483d) / Math.tan((d / 2.0d) + 0.7853981633974483d));
            double d5 = (cos - d) / log;
            if (Double.isNaN(log) || Double.isNaN(d5) || Double.isInfinite(d5)) {
                d5 = Math.cos(d);
            }
            double sin = (d4 * Math.sin(d3)) / d5;
            if (Math.abs(cos) > 1.5707963267948966d) {
                cos = cos > 0.0d ? 3.141592653589793d - cos : (-3.141592653589793d) - cos;
            }
            double d6 = (((d2 + sin) + 3.141592653589793d) % 6.283185307179586d) - 3.141592653589793d;
            return (Double.isNaN(cos) || Double.isNaN(d6)) ? latLon : new LatLon(Angle.fromRadians(cos).normalizedLatitude(), Angle.fromRadians(d6).normalizedLongitude());
        }
        throw new IllegalArgumentException("LatLon Is Null");
    }

    public static LatLon rhumbEndPosition(LatLon latLon, double d, double d2) {
        if (latLon != null) {
            return rhumbEndPosition(latLon, Angle.fromRadians(d), Angle.fromRadians(d2));
        }
        throw new IllegalArgumentException("LatLon Is Null");
    }

    public static Angle getAverageDistance(Iterable<? extends LatLon> iterable) {
        if (iterable != null) {
            double d = 0.0d;
            int i = 0;
            for (LatLon latLon : iterable) {
                for (LatLon latLon2 : iterable) {
                    if (latLon != latLon2) {
                        d += rhumbDistance(latLon, latLon2).radians;
                        i++;
                    }
                }
            }
            if (i == 0) {
                return Angle.ZERO;
            }
            double d2 = i;
            Double.isNaN(d2);
            return Angle.fromRadians(d / d2);
        }
        throw new IllegalArgumentException("Locations List Is Null");
    }

    public LatLon add(LatLon latLon) {
        if (latLon != null) {
            return new LatLon(Angle.normalizedLatitude(this.latitude.add(latLon.latitude)), Angle.normalizedLongitude(this.longitude.add(latLon.longitude)));
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public LatLon subtract(LatLon latLon) {
        if (latLon != null) {
            return new LatLon(Angle.normalizedLatitude(this.latitude.subtract(latLon.latitude)), Angle.normalizedLongitude(this.longitude.subtract(latLon.longitude)));
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public LatLon add(Position position) {
        if (position != null) {
            return new LatLon(Angle.normalizedLatitude(this.latitude.add(position.getLatitude())), Angle.normalizedLongitude(this.longitude.add(position.getLongitude())));
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public LatLon subtract(Position position) {
        if (position != null) {
            return new LatLon(Angle.normalizedLatitude(this.latitude.subtract(position.getLatitude())), Angle.normalizedLongitude(this.longitude.subtract(position.getLongitude())));
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public static boolean locationsCrossDateLine(Iterable<? extends LatLon> iterable) {
        if (iterable != null) {
            LatLon latLon = null;
            for (LatLon latLon2 : iterable) {
                if (latLon != null && Math.signum(latLon.getLongitude().degrees) != Math.signum(latLon2.getLongitude().degrees)) {
                    double abs = Math.abs(latLon.getLongitude().degrees - latLon2.getLongitude().degrees);
                    if (abs > 180.0d && abs < 360.0d) {
                        return true;
                    }
                }
                latLon = latLon2;
            }
            return false;
        }
        throw new IllegalArgumentException("Locations List Is Null");
    }

    public static boolean locationsCrossDateline(LatLon latLon, LatLon latLon2) {
        if (latLon == null || latLon2 == null) {
            throw new IllegalArgumentException("Location Is Null");
        }
        if (Math.signum(latLon.getLongitude().degrees) != Math.signum(latLon2.getLongitude().degrees)) {
            double abs = Math.abs(latLon.getLongitude().degrees - latLon2.getLongitude().degrees);
            return abs > 180.0d && abs < 360.0d;
        }
        return false;
    }

    public static List<LatLon> makeDatelineCrossingLocationsPositive(Iterable<? extends LatLon> iterable) {
        if (iterable == null) {
            throw new IllegalArgumentException("Locations List Is Null");
        }
        if (!iterable.iterator().hasNext()) {
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList();
        for (LatLon latLon : iterable) {
            if (latLon != null) {
                if (latLon.getLongitude().degrees < 0.0d) {
                    arrayList.add(fromDegrees(latLon.getLatitude().degrees, latLon.getLongitude().degrees + 360.0d));
                } else {
                    arrayList.add(latLon);
                }
            }
        }
        return arrayList;
    }

    public LatLon parseLatLon(String str) {
        if (str == null) {
            throw new IllegalArgumentException("String Is Null");
        }
        throw new UnsupportedOperationException();
    }

    public String toString() {
        String format = String.format("Lat %7.4f°", Double.valueOf(getLatitude().getDegrees()));
        String format2 = String.format("Lon %7.4f°", Double.valueOf(getLongitude().getDegrees()));
        return "(" + format + ", " + format2 + ")";
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        LatLon latLon = (LatLon) obj;
        return this.latitude.equals(latLon.latitude) && this.longitude.equals(latLon.longitude);
    }

    public static boolean equals(LatLon latLon, LatLon latLon2) {
        return latLon.getLatitude().equals(latLon2.getLatitude()) && latLon.getLongitude().equals(latLon2.getLongitude());
    }

    public int hashCode() {
        return (this.latitude.hashCode() * 29) + this.longitude.hashCode();
    }

    public static Angle ellipsoidalForwardAzimuth(LatLon latLon, LatLon latLon2, double d, double d2) {
        if (latLon == null || latLon2 == null) {
            throw new IllegalArgumentException("Position Is Null");
        }
        double d3 = (d - d2) / d;
        double d4 = 1.0d - d3;
        double atan = Math.atan(Math.tan(latLon.latitude.radians) * d4);
        double cos = Math.cos(atan);
        double sin = Math.sin(atan);
        double atan2 = Math.atan(d4 * Math.tan(latLon2.latitude.radians));
        double cos2 = Math.cos(atan2);
        double sin2 = Math.sin(atan2);
        double d5 = latLon2.longitude.subtract(latLon.longitude).radians;
        double sin3 = Math.sin(d5);
        double cos3 = Math.cos(d5);
        double d6 = Double.MAX_VALUE;
        int i = 0;
        double d7 = d5;
        while (Math.abs(d7 - d6) > 1.0E-12d) {
            int i2 = i + 1;
            if (i >= 100) {
                break;
            }
            double d8 = d5;
            double d9 = d3;
            double sqrt = Math.sqrt(Math.pow(cos2 * sin3, 2.0d) + Math.pow((cos * sin2) - ((sin * cos2) * cos3), 2.0d));
            double d10 = cos * cos2;
            double d11 = (sin * sin2) + (cos3 * d10);
            double atan22 = Math.atan2(sqrt, d11);
            double d12 = (d10 * sin3) / sqrt;
            double d13 = 1.0d - (d12 * d12);
            double d14 = Math.abs(d13) < 1.0E-6d ? 0.0d : d11 - (((sin * 2.0d) * sin2) / d13);
            double d15 = (d9 / 16.0d) * d13 * (((4.0d - (d13 * 3.0d)) * d9) + 4.0d);
            double d16 = d8 + ((1.0d - d15) * d9 * d12 * (atan22 + (sqrt * d15 * (d14 + (d15 * d11 * ((2.0d * d14) - 4.0d))))));
            sin3 = Math.sin(d16);
            cos3 = Math.cos(d16);
            i = i2;
            d3 = d9;
            d5 = d8;
            d6 = d7;
            d7 = d16;
        }
        return Angle.fromRadians(Math.atan2(sin3 * cos2, (cos * sin2) - ((sin * cos2) * cos3)));
    }

    public static double ellipsoidalDistance(LatLon latLon, LatLon latLon2, double d, double d2) {
        double d3 = (d - d2) / d;
        double d4 = 1.0d - d3;
        if (latLon == null || latLon2 == null) {
            throw new IllegalArgumentException("Position Is Null");
        }
        double d5 = latLon.getLatitude().radians;
        double d6 = latLon2.getLatitude().radians;
        double sin = (Math.sin(d5) * d4) / Math.cos(d5);
        double sin2 = (Math.sin(d6) * d4) / Math.cos(d6);
        double sqrt = 1.0d / Math.sqrt((sin * sin) + 1.0d);
        double d7 = sqrt * sin;
        double sqrt2 = 1.0d / Math.sqrt((sin2 * sin2) + 1.0d);
        double d8 = sqrt * sqrt2;
        double d9 = sin2 * d8;
        double d10 = sin * d9;
        double d11 = latLon.getLongitude().radians;
        double d12 = latLon2.getLongitude().radians;
        double d13 = d12 - d11;
        while (true) {
            double sin3 = Math.sin(d13);
            double cos = Math.cos(d13);
            double d14 = sqrt2 * sin3;
            double d15 = d9 - ((d7 * sqrt2) * cos);
            double d16 = (d14 * d14) + (d15 * d15);
            double d17 = d9;
            double sqrt3 = Math.sqrt(d16);
            double d18 = d7;
            double d19 = (cos * d8) + d10;
            double atan2 = Math.atan2(sqrt3, d19);
            double d20 = d8;
            double d21 = (sin3 * d8) / sqrt3;
            double d22 = sqrt2;
            double d23 = ((-d21) * d21) + 1.0d;
            double d24 = d11;
            double d25 = d10 + d10;
            if (d23 > 0.0d) {
                d25 = ((-d25) / d23) + d19;
            }
            double d26 = ((d25 * d25) * 2.0d) - 1.0d;
            double d27 = (((((((-3.0d) * d23) + 4.0d) * d3) + 4.0d) * d23) * d3) / 16.0d;
            double d28 = d19 * d26;
            double d29 = ((((1.0d - d27) * ((((((d28 * d27) + d25) * sqrt3) * d27) + atan2) * d21)) * d3) + d12) - d24;
            if (Math.abs(d13 - d29) <= 5.0E-14d) {
                double sqrt4 = Math.sqrt(((((1.0d / d4) / d4) - 1.0d) * d23) + 1.0d) + 1.0d;
                double d30 = (sqrt4 - 2.0d) / sqrt4;
                double d31 = (((0.375d * d30) * d30) - 1.0d) * d30;
                return (((((((((((((sqrt3 * sqrt3) * 4.0d) - 3.0d) * ((1.0d - d26) - d26)) * d25) * d31) / 6.0d) - d28) * d31) / 4.0d) + d25) * sqrt3 * d31) + atan2) * ((((d30 * d30) / 4.0d) + 1.0d) / (1.0d - d30)) * d * d4;
            }
            d13 = d29;
            sqrt2 = d22;
            d7 = d18;
            d9 = d17;
            d8 = d20;
            d11 = d24;
        }
    }

    public static List<LatLon> computeShiftedLocations(Position position, Position position2, Iterable<? extends LatLon> iterable) {
        if (position == null || position2 == null) {
            throw new IllegalArgumentException("Position Is Null");
        }
        if (iterable != null) {
            ArrayList arrayList = new ArrayList();
            for (LatLon latLon : iterable) {
                arrayList.add(Position.greatCircleEndPosition(position2, greatCircleAzimuth(position, latLon), greatCircleDistance(position, latLon)));
            }
            return arrayList;
        }
        throw new IllegalArgumentException("Positions List Is Null");
    }
}
