package com.live.gpsmap.camera.os_notifications;

import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import androidx.core.app.NotificationCompat;

import com.live.gpsmap.camera.R;
import com.onesignal.OSMutableNotification;
import com.onesignal.OSNotificationReceivedEvent;
import com.onesignal.OneSignal;

public class NotificationServiceExtension implements OneSignal.OSRemoteNotificationReceivedHandler {
    @Override
    public void remoteNotificationReceived(Context context, OSNotificationReceivedEvent oSNotificationReceivedEvent) {
        final int i;
        OSMutableNotification mutableCopy = oSNotificationReceivedEvent.getNotification().mutableCopy();
        if (Build.MANUFACTURER.equalsIgnoreCase("xiaomi")) {
            i = R.mipmap.ic_launcher_1;
        } else {
            i = R.mipmap.ic_launcher;
        }
        mutableCopy.setExtender(new NotificationCompat.Extender() {
            @Override
            public final NotificationCompat.Builder extend(NotificationCompat.Builder builder) {
                NotificationCompat.Builder smallIcon;
                smallIcon = builder.setColor(Color.parseColor("#455a64")).setSmallIcon(i);
                return smallIcon;
            }
        });
        oSNotificationReceivedEvent.complete(mutableCopy);
    }
}
