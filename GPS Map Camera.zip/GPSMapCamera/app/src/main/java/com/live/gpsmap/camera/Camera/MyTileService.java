package com.live.gpsmap.camera.Camera;

import android.content.Intent;
import android.service.quicksettings.TileService;
import android.util.Log;

public class MyTileService extends TileService {
    private static final String TAG = "MyTileService";
    public static final String TILE_ID = "net.sourceforge.opencamera.TILE_CAMERA";

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onTileAdded() {
        super.onTileAdded();
    }

    @Override
    public void onTileRemoved() {
        super.onTileRemoved();
    }

    @Override
    public void onStartListening() {
        super.onStartListening();
    }

    @Override
    public void onStopListening() {
        super.onStopListening();
    }

    @Override
    public void onClick() {
        Log.d(TAG, "onClick");
        super.onClick();
        Intent intent = new Intent(this, CameraMainActivity.class);
        intent.setFlags(335544320);
        intent.setAction(TILE_ID);
        startActivity(intent);
    }
}
