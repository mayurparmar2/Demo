package com.live.gpsmap.camera.Utils;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.exifinterface.media.ExifInterface;
import androidx.work.WorkRequest;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.SettingsClient;
import com.google.android.material.snackbar.Snackbar;
import com.live.gpsmap.camera.Database.DateTimeDB;
import com.live.gpsmap.camera.Model.DateTime;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Helper.SharePref;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
@SuppressWarnings("All")
public class CommonFunction {
    public static String BROADCAST_LOCATION = "android.intent.broadcast.location";
    public static final String Details_Native = "ca-app-pub-1531973473735447/8818925614";
    private static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = 900000;
    public static String ISDELETE_SIGNATURE = "is_deleteSignature";
    public static String ISEDIT_SIGNATURE = "is_editSignature";
    public static String ISSELECT_SIGNATURE = "is_selectSignature";
    private static final long UPDATE_INTERVAL_IN_MILLISECONDS = 900000;
    private Location mCurrentLocation;
    private FusedLocationProviderClient mFusedLocationClient;
    private LocationCallback mLocationCallback;
    private LocationRequest mLocationRequest;
    private LocationSettingsRequest mLocationSettingsRequest;
    private SettingsClient mSettingsClient;
    private TextView mTextViewRatingValue;
    public ProgressDialog pDownloadDialog;
    private RatingBar rating_bar;
//    public static String[] repeat = {"0", AppEventsConstants.EVENT_PARAM_VALUE_YES, ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9", "10"};
    private static String TAG = "CommonFunction";
    final int REQUEST_CHECK_SETTINGS = 1;
    public int progressTotal = -1;
    public Double tmp = Double.valueOf((double) 0.0d);
    String addressFull = "";
    String cityName = "";
    String area = "";
    String stateName = "";
    String countryName = "";

    public static void buildToast(Context context, String str) {
    }

    private static String getPermissionType(String str) {
        String str2 = (str.equals("android.permission.ACCESS_MOCK_LOCATION") || str.equals("android.permission.ACCESS_COARSE_LOCATION") || str.equals("android.permission.ACCESS_FINE_LOCATION") || str.equals("com.google.android.providers.gsf.permission.READ_GSERVICES")) ? "Gps Permission," : "";
        str2 = (str.equals("android.permission.READ_EXTERNAL_STORAGE") || str.equals("android.permission.WRITE_EXTERNAL_STORAGE")) ? "Storage Permission," : "Storage Permission,";
        if (str.equals("android.permission.CAMERA")) {
            str2 = "Camera Permission,";
        }
        return (str.equals("com.android.vending.CHECK_LICENSE") || str.equals("android.permission.ACCESS_NETWORK_STATE") || str.equals("android.permission.INTERNET") || str.equals("android.permission.ACCESS_WIFI_STATE") || str.equals("android.permission.SYSTEM_ALERT_WINDOW") || str.equals("android.permission.WAKE_LOCK") || str.equals("android.permission.WRITE_SETTINGS") || str.equals("com.android.vending.BILLING") || str.equals("com.ebizzinfotech.DateTimeSignatureStampOnPhotos.gcm.permission.C2D_MESSAGE") || str.equals("com.google.android.c2dm.permission.RECEIVE") || str.equals("com.autostamper.datetimestampphoto.permission.C2D_MESSAGE") || str.equals("android.permission.RECEIVE_BOOT_COMPLETED")) ? "Other App Capabilities," : str2;
    }

    public static void watchYoutubeVideo(Context context, String str) {
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("vnd.youtube:" + str));
        Intent intent2 = new Intent("android.intent.action.VIEW", Uri.parse("http://www.youtube.com/watch?v=" + str));
        try {
            context.startActivity(intent);
        } catch (ActivityNotFoundException unused) {
            context.startActivity(intent2);
        }
    }

//    public static void setFirebaseUserProperty(Context context, String str, String str2) {
//        if (context != null) {
//            FirebaseAnalytics.getInstance(context).setUserProperty(str, str2);
//        }
//    }
//
//    public static void setFirebaseEve(Context context, String str) {
//        if (context != null) {
//            FirebaseAnalytics firebaseAnalytics = FirebaseAnalytics.getInstance(context);
//            Bundle bundle = new Bundle();
//            bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, str);
//            firebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
//        }
//    }

    public void setLocale(int i, Activity activity) {
        String str;
        switch (i) {
            case 0:
                str = "en";
                break;
            case 1:
                str = "af";
                break;
            case 2:
                str = "in";
                break;
            case 3:
                str = "pt";
                break;
            case 4:
                str = "ru";
                break;
            case 5:
                str = "fr";
                break;
            case 6:
                str = "es";
                break;
            case 7:
                str = "de";
                break;
            case 8:
                str = "ms";
                break;
            case 9:
                str = "tr";
                break;
            case 10:
                str = "th";
                break;
            case 11:
                str = "vi";
                break;
            case 12:
                str = "ko";
                break;
            default:
                str = "";
                break;
        }
        Locale locale = new Locale(str);
        Locale.setDefault(locale);
        Configuration configuration = new Configuration();
        configuration.locale = locale;
        activity.getResources().updateConfiguration(configuration, activity.getResources().getDisplayMetrics());
        activity.onConfigurationChanged(configuration);
    }

    public void setTypefacefromassets(Context context, TextView textView, String str) {
        textView.setTypeface(Typeface.createFromAsset(context.getAssets(), str));
    }

    public void showSnackBar(View view, String str) {
        if (view != null) {
            try {
                Snackbar.make(view, "" + str, -1).show();
            } catch (IllegalArgumentException | IllegalStateException | NullPointerException unused) {
            }
        }
    }

    public boolean validateString(String str) {
        return (str == null || str.isEmpty() || str.length() <= 0 || str.equals("null")) ? false : true;
    }

    public Typeface setTypefaceFontStyle(Context context, String str) {
        File filesDir = context.getFilesDir();
        File file = new File(filesDir, "font/" + str);
        Typeface typeface = null;
        if (file.exists()) {
            try {
                typeface = Typeface.createFromFile(file);
            } catch (Exception unused) {
            }
            return typeface != null ? typeface : Typeface.createFromAsset(context.getAssets(), "ROBOTO_REGULAR.TTF");
        }
        return null;
    }

    public void copyAssets(Context context, String str) {
        try {
            String[] list = context.getAssets().list("");
            if (list != null) {
                for (String str2 : list) {
                    if (!new File(str, str2).exists()) {
                        copyFile(context, str2);
                    }
                }
            }
        } catch (IOException unused) {
        }
    }

    private void copyFile(Context context, String str) {
        try {
            InputStream open = context.getAssets().open(str);
            FileOutputStream fileOutputStream = new FileOutputStream(context.getFilesDir() + "/font/" + str);
            byte[] bArr = new byte[1024];
            while (true) {
                int read = open.read(bArr);
                if (read != -1) {
                    fileOutputStream.write(bArr, 0, read);
                } else {
                    open.close();
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    return;
                }
            }
        } catch (IOException unused) {
        }
    }

    public String setDateTimeFormatNew(Context context, int i, ArrayList<DateTime> arrayList) {
        Calendar calendar = Calendar.getInstance();
        if (arrayList.get(i).getDate_format().contains("ddth")) {
            return getThFormat(calendar.getTimeInMillis(), arrayList.get(i).getDate_format());
        }
        return new SimpleDateFormat(arrayList.get(i).getDate_format(), Locale.getDefault()).format(calendar.getTime());
    }

//    public String setDateTimeFormat(Context context, int i) {
//        ArrayList<DateTime> normalDates = new DateTimeDB(context).getNormalDates();
//        Calendar calendar = Calendar.getInstance();
//        if (i <= normalDates.size() - 1) {
//            if (normalDates.get(i).getDate_format().contains(ScTfbSqc.RgQTmrrTBMPv)) {
//                return getThFormat(calendar.getTimeInMillis(), normalDates.get(i).getDate_format());
//            }
//            return new SimpleDateFormat(normalDates.get(i).getDate_format(), Locale.getDefault()).format(calendar.getTime());
//        }
//        return "";
//    }

    private String addExtention(String str) {
        Calendar calendar = Calendar.getInstance();
        String[] split = str.split("th");
        StringBuilder sb = new StringBuilder();
        for (String str2 : split) {
            String format = new SimpleDateFormat(str2, Locale.getDefault()).format(calendar.getTime());
            char charAt = format.charAt(format.length() - 1);
            char charAt2 = format.charAt(format.length() - 2);
            char charAt3 = str2.charAt(str2.length() - 1);
            char charAt4 = str2.charAt(str2.length() - 2);
            if (charAt3 == 'd' && charAt4 == 'd') {
                if (charAt == '1' && (charAt2 == '0' || charAt2 == '2' || charAt2 == '3')) {
                    format = format + "st";
                } else if (charAt == '2' && (charAt2 == '0' || charAt2 == '2')) {
                    format = format + "nd";
                } else if (charAt == '3' && (charAt2 == '0' || charAt2 == '2')) {
                    format = format + "rd";
                } else if (charAt == '4' || charAt == '5' || charAt == '6' || charAt == '7' || charAt == '8' || charAt == '9' || charAt == '0') {
                    format = format + "th";
                }
            }
            sb.append(format);
        }
        return sb.toString();
    }

    private Bitmap createNewIcon(Bitmap bitmap, int i, int i2) {
        Matrix matrix = new Matrix();
        matrix.setRectToRect(new RectF(0.0f, 0.0f, bitmap.getWidth(), bitmap.getHeight()), new RectF(0.0f, 0.0f, i, i2), Matrix.ScaleToFit.CENTER);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    private Bitmap createBitmapImage(String str) {
        return BitmapFactory.decodeFile(str, new BitmapFactory.Options());
    }

    public Bitmap getResizedBitmap(Bitmap bitmap, int i, int i2) {
        return Bitmap.createScaledBitmap(bitmap, i, i2, false);
    }

    public void redirectToPlayStore(Activity activity) {
        String packageName = activity.getPackageName();
        try {
            activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + packageName)));
        } catch (ActivityNotFoundException unused) {
            activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + packageName)));
        }
    }

    public void showSimpleDialog(Context context, String str, String str2) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(str);
        builder.setMessage(str2);
        builder.create();
        builder.setPositiveButton(context.getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.setCancelable(true);
        builder.show();
    }

    private boolean checkPermission(Context context, String str) {
        return ContextCompat.checkSelfPermission(context, str) == 0;
    }

    private String getPermissions(String[] strArr) {
        String str = "";
        for (String str2 : strArr) {
            str = str + str2 + ",";
        }
        return str;
    }

    private Boolean isAnyPackagePurchased(Context context) {
        return false;
    }

    public String getLatLong(int i, double d, double d2, boolean z) {
        StringBuilder sb = new StringBuilder();
        StringBuilder sb2 = new StringBuilder();
        if (z && Double.compare(d, this.tmp.doubleValue()) == 0 && Double.compare(d2, this.tmp.doubleValue()) == 0) {
            return "0";
        }
        if (i == 0) {
            DecimalFormat decimalFormat = new DecimalFormat("###.#####");
            sb.append(decimalFormat.format(Math.abs(d)));
            sb.append("°");
            sb2.append(decimalFormat.format(Math.abs(d2)));
            sb2.append("°");
        } else if (i == 1) {
            String[] split = Location.convert(Math.abs(d), 1).split(":");
            String[] split2 = Location.convert(Math.abs(d2), 1).split(":");
            new DecimalFormat("###.###");
            sb.append(split[0]);
            sb.append("° ");
            sb.append(split[1]);
            sb.append("'");
            sb2.append(split2[0]);
            sb2.append("° ");
            sb2.append(split2[1]);
            sb2.append("'");
        } else if (i == 2) {
            String[] split3 = Location.convert(Math.abs(d), Location.FORMAT_SECONDS).split(":");
            String[] split4 = Location.convert(Math.abs(d2), Location.FORMAT_SECONDS).split(":");
            new DecimalFormat("###.#");
            sb.append(split3[0]);
            sb.append("° ");
            sb.append(split3[1]);
            sb.append("' ");
            sb.append(split3[2]);
            sb.append("\"");
            sb2.append(split4[0]);
            sb2.append("° ");
            sb2.append(split4[1]);
            sb2.append("' ");
            sb2.append(split4[2]);
            sb2.append("\"");
        } else {
            DecimalFormat decimalFormat2 = new DecimalFormat("###.#####");
            sb.append(decimalFormat2.format(Math.abs(d)));
            sb.append("°");
            sb2.append(decimalFormat2.format(Math.abs(d2)));
            sb2.append("°");
        }
        if (d < 0.0d) {
            sb.append(" S");
        } else {
            sb.append(" N");
        }
        if (d2 < 0.0d) {
            sb2.append(" W");
        } else {
            sb2.append(" E");
        }
        return ((Object) sb) + " " + ((Object) sb2);
    }

    String getDateTime(String str, String str2) {
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str);
            return simpleDateFormat.format(simpleDateFormat.parse(str2));
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String getThFormat(long j, String str) {
        String str2;
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(j);
        String dayNumberSuffix = getDayNumberSuffix(calendar.get(5));
        if (str.contains("ddth")) {
            str2 = str.replace("ddth", "d'" + dayNumberSuffix + "'");
        } else {
            str2 = "d'" + dayNumberSuffix + "'";
        }
        return new SimpleDateFormat(str2).format(calendar.getTime());
    }

    private String getDayNumberSuffix(int i) {
        if (i < 11 || i > 13) {
            int i2 = i % 10;
            return i2 != 1 ? i2 != 2 ? i2 != 3 ? "th" : "rd" : "nd" : "st";
        }
        return "th";
    }

    public String getDate(long j, String str) {
        if (str.contains("ddth")) {
            return getThFormat(System.currentTimeMillis(), str);
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str);
        System.out.println(j);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(j);
        return simpleDateFormat.format(calendar.getTime());
    }

    public String setdate(String str) {
        Log.e("LLLL 1", "" + str);
        Log.e("LLLL 2", "" + str.contains("th"));
        if (str.equals("CLEAR")) {
            return "";
        }
        if ((str.contains("th)") || str.contains("st)") || str.contains("nd)") || str.contains("rd)")) && !str.contains("MMMM(")) {
            return getThFormat(System.currentTimeMillis(), str);
        }
        if (str.equals("hh(12)")) {
            return getDate(System.currentTimeMillis(), "hh");
        }
        boolean equals = str.equals("hh(24)");
        String str2 = "hh(24)";
        if (equals) {
            return getDate(System.currentTimeMillis(), str2);
        }
        if (str.equals("") || str.equalsIgnoreCase("select one") || str.equalsIgnoreCase("select")) {
            return "";
        }
        if (str.equals("AM")) {
            return "AM";
        }
        if (str.equals("am")) {
            return "am";
        }
        if (str.equals("PM")) {
            return "PM";
        }
        if (str.equals("pm")) {
            return "pm";
        }
        if (str.equals(":")) {
            return ":";
        }
        if (str.equals("/")) {
            return "/";
        }
        if (str.equals(",")) {
            return ",";
        }
        if (str.equals(".")) {
            return ".";
        }
        if (str.equals("-")) {
            return "-";
        }
        if (str.contains("second(")) {
            return getDate(System.currentTimeMillis(), "ss");
        }
        if (str.contains("date(")) {
            return getDate(System.currentTimeMillis(), "dd");
        }
        if (str.contains("EEEE(")) {
            return getDate(System.currentTimeMillis(), "EEEE");
        }
        if (str.contains("EEE(")) {
            return getDate(System.currentTimeMillis(), "EEE");
        }
        if (str.contains("yyyy(")) {
            return getDate(System.currentTimeMillis(), "yyyy");
        }
        if (str.contains("yy(")) {
            return getDate(System.currentTimeMillis(), "yy");
        }
        if (str.contains("E(")) {
            return getDate(System.currentTimeMillis(), ExifInterface.LONGITUDE_EAST);
        }
        if (str.contains("MMMM(")) {
            return getDate(System.currentTimeMillis(), "MMMM");
        }
        if (str.contains("MMM(")) {
            return getDate(System.currentTimeMillis(), "MMM");
        }
        if (str.contains("MM(")) {
            return getDate(System.currentTimeMillis(), "MM");
        }
        if (str.equalsIgnoreCase("SPACE")) {
            return " ";
        }
        if (str.contains("Hour")) {
            return getDate(System.currentTimeMillis(), str2);
        }
        if (str.contains("hour")) {
            return getDate(System.currentTimeMillis(), "hh");
        }
        if (str.contains("Minute(")) {
            return getDate(System.currentTimeMillis(), "mm");
        }
        if (str.contains("a(")) {
            return getDate(System.currentTimeMillis(), "a");
        }
        return getDate(System.currentTimeMillis(), str);
    }

    public String getFormat(String str) {
        return str.equals("CLEAR") ? "" : str.equals(":") ? ":" : ((str.contains("th)") || str.contains("st)") || str.contains("nd)") || str.contains("rd)")) && !str.contains("MMMM(")) ? "ddth" : str.equals("/") ? "/" : str.equals(",") ? "," : str.equals(".") ? "." : str.equals("-") ? "-" : str.contains("date(") ? "dd" : str.equals("hh(12)") ? "hh" : str.equals("hh(24)") ? "HH" : (str.equals("") || str.equalsIgnoreCase("select one") || str.equalsIgnoreCase("")) ? "" : str.contains("second(") ? "ss" : str.equals("AM") ? "AM" : str.equals("am") ? "am" : str.equals("PM") ? "PM" : str.equals("pm") ? "pm" : str.contains("EEEE(") ? "EEEE" : str.contains("EEE(") ? "EEE" : str.contains("E(") ? ExifInterface.LONGITUDE_EAST : str.contains("yyyy(") ? "yyyy" : str.contains("yy(") ? "yy" : str.contains("MMMM(") ? "MMMM" : str.contains("MMM(") ? "MMM" : str.contains("MM(") ? "MM" : str.contains("Hour") ? "HH" : str.contains("hour") ? "hh" : str.contains("Minute(") ? "mm" : str.contains("a(") ? "a(" : str.equalsIgnoreCase(" ") ? " " : str;
    }

    public String stringWithTextNoSpace(int i, String str) {
        float f;
        String str2;
        String str3;
        String str4;
        String str5;
        String str6;
        String str7;
        String[] split = str.split("\n");
        if (split.length == 3) {
            float length = split[0].length();
            float length2 = split[1].length();
            float length3 = split[2].length();
            if (length > length2 && length > length3) {
                float f2 = (length - length3) / 2.0f;
                float f3 = (length - length2) / 2.0f;
                StringBuilder sb = new StringBuilder();
                StringBuilder sb2 = new StringBuilder();
                if (f3 == 0.5d) {
                    f3 = 0.0f;
                }
                f = ((double) f2) != 0.5d ? f2 : 0.0f;
                for (int i2 = 0; i2 < f3; i2++) {
                    sb2.append("");
                }
                for (int i3 = 0; i3 < f; i3++) {
                    sb.append("");
                }
                if (i == 0 || i == 2 || i == 5 || i == 6) {
                    str6 = sb2.toString() + split[1];
                    str7 = sb.toString() + split[2];
                } else {
                    str6 = split[1] + sb2.toString();
                    str7 = split[2] + sb.toString();
                }
                return split[0] + "\n" + str6 + "\n" + str7;
            } else if (length2 > length && length2 > length3) {
                float f4 = (length2 - length) / 2.0f;
                float f5 = (length2 - length3) / 2.0f;
                StringBuilder sb3 = new StringBuilder();
                StringBuilder sb4 = new StringBuilder();
                if (f4 == 0.5d) {
                    f4 = 0.0f;
                }
                f = ((double) f5) != 0.5d ? f5 : 0.0f;
                for (int i4 = 0; i4 < f4; i4++) {
                    sb3.append("");
                }
                for (int i5 = 0; i5 < f; i5++) {
                    sb4.append("");
                }
                if (i == 0 || i == 2 || i == 5 || i == 6) {
                    str4 = sb3.toString() + split[0];
                    str5 = sb4.toString() + split[2];
                } else {
                    str4 = split[0] + sb3.toString();
                    str5 = split[2] + sb4.toString();
                }
                return str4 + "\n" + split[1] + "\n" + str5;
            } else if (length3 <= length2 || length3 <= length) {
                return split[0] + "\n" + split[1] + "\n" + split[2];
            } else {
                float f6 = (length3 - length) / 2.0f;
                float f7 = (length3 - length2) / 2.0f;
                StringBuilder sb5 = new StringBuilder();
                StringBuilder sb6 = new StringBuilder();
                if (f6 == 0.5d) {
                    f6 = 0.0f;
                }
                f = ((double) f7) != 0.5d ? f7 : 0.0f;
                for (int i6 = 0; i6 < f6; i6++) {
                    sb5.append("");
                }
                for (int i7 = 0; i7 < f; i7++) {
                    sb6.append("");
                }
                if (i == 0 || i == 2 || i == 5 || i == 6) {
                    str2 = sb5.toString() + split[0];
                    str3 = sb6.toString() + split[1];
                } else {
                    str2 = split[0] + sb5.toString();
                    str3 = split[1] + sb6.toString();
                }
                return str2 + "\n" + str3 + "\n" + split[2];
            }
        } else if (split.length == 2) {
            float length4 = split[0].length();
            float length5 = split[1].length();
            if (length4 > length5) {
                float f8 = (length4 - length5) / 2.0f;
                f = ((double) f8) != 0.5d ? f8 : 0.0f;
                StringBuilder sb7 = new StringBuilder();
                for (int i8 = 0; i8 < f; i8++) {
                    sb7.append("");
                }
                return split[0] + "\n" + ((i == 0 || i == 2 || i == 5 || i == 6) ? sb7.toString() + split[1] : split[1] + sb7.toString());
            } else if (length5 > length4) {
                float f9 = (length5 - length4) / 2.0f;
                f = ((double) f9) != 0.5d ? f9 : 0.0f;
                StringBuilder sb8 = new StringBuilder();
                for (int i9 = 0; i9 < f; i9++) {
                    sb8.append("");
                }
                return ((i == 0 || i == 2 || i == 5 || i == 6) ? sb8.toString() + split[0] : split[0] + sb8.toString()) + "\n" + split[1];
            } else {
                return split[0] + "\n" + split[1];
            }
        } else {
            return str;
        }
    }

    public String stringWithText(int i, String str) {
        String str2;
        String str3;
        String str4;
        String str5;
        String str6;
        String str7;
        String str8;
        String str9;
        String str10;
        String str11;
        String str12;
        String str13;
        String[] split = str.split("\n");
        if (split.length == 3) {
            float length = split[0].length();
            float length2 = split[1].length();
            float length3 = split[2].length();
            int i2 = (length > length2 ? 1 : (length == length2 ? 0 : -1));
            if (i2 > 0 && length > length3) {
                float f = (length - length3) / 2.0f;
                float f2 = (length - length2) / 2.0f;
                StringBuilder sb = new StringBuilder();
                StringBuilder sb2 = new StringBuilder();
                if (f2 == 0.5d) {
                    f2 = 0.0f;
                }
                if (f == 0.5d) {
                    f = 0.0f;
                }
                for (int i3 = 0; i3 < f2; i3++) {
                    sb2.append("  ");
                }
                for (int i4 = 0; i4 < f; i4++) {
                    sb.append("  ");
                }
                if (i == 0 || i == 2 || i == 5 || i == 6) {
                    str12 = sb2.toString() + split[1];
                    str13 = sb.toString() + split[2];
                } else {
                    str12 = split[1] + sb2.toString();
                    str13 = split[2] + sb.toString();
                }
                return split[0] + "\n" + str12 + "\n" + str13;
            }
            int i5 = (length2 > length ? 1 : (length2 == length ? 0 : -1));
            if (i5 > 0 && length2 > length3) {
                float f3 = (length2 - length) / 2.0f;
                float f4 = (length2 - length3) / 2.0f;
                StringBuilder sb3 = new StringBuilder();
                StringBuilder sb4 = new StringBuilder();
                if (f3 == 0.5d) {
                    f3 = 0.0f;
                }
                if (f4 == 0.5d) {
                    f4 = 0.0f;
                }
                for (int i6 = 0; i6 < f3; i6++) {
                    sb3.append("  ");
                }
                for (int i7 = 0; i7 < f4; i7++) {
                    sb4.append("  ");
                }
                if (i == 0 || i == 2 || i == 5 || i == 6) {
                    str10 = sb3.toString() + split[0];
                    str11 = sb4.toString() + split[2];
                } else {
                    str10 = split[0] + sb3.toString();
                    str11 = split[2] + sb4.toString();
                }
                return str10 + "\n" + split[1] + "\n" + str11;
            } else if (length3 > length2 && length3 > length) {
                float f5 = (length3 - length) / 2.0f;
                float f6 = (length3 - length2) / 2.0f;
                StringBuilder sb5 = new StringBuilder();
                StringBuilder sb6 = new StringBuilder();
                if (f5 == 0.5d) {
                    f5 = 0.0f;
                }
                if (f6 == 0.5d) {
                    f6 = 0.0f;
                }
                for (int i8 = 0; i8 < f5; i8++) {
                    sb5.append("  ");
                }
                for (int i9 = 0; i9 < f6; i9++) {
                    sb6.append("  ");
                }
                if (i == 0 || i == 2 || i == 5 || i == 6) {
                    str8 = sb5.toString() + split[0];
                    str9 = sb6.toString() + split[1];
                } else {
                    str8 = split[0] + sb5.toString();
                    str9 = split[1] + sb6.toString();
                }
                return str8 + "\n" + str9 + "\n" + split[2];
            } else if (i2 == 0) {
                if (length > length3) {
                    float f7 = (length - length3) / 2.0f;
                    StringBuilder sb7 = new StringBuilder();
                    float f8 = ((double) f7) == 0.5d ? 0.0f : f7;
                    for (int i10 = 0; i10 < f8; i10++) {
                        sb7.append("  ");
                    }
                    return split[0] + "\n" + split[1] + "\n" + ((i == 0 || i == 2 || i == 5 || i == 6) ? sb7.toString() + split[2] : split[2] + sb7.toString());
                } else if (length3 > length) {
                    float f9 = (length3 - length) / 2.0f;
                    float f10 = (length3 - length2) / 2.0f;
                    StringBuilder sb8 = new StringBuilder();
                    StringBuilder sb9 = new StringBuilder();
                    if (f9 == 0.5d) {
                        f9 = 0.0f;
                    }
                    if (f10 == 0.5d) {
                        f10 = 0.0f;
                    }
                    for (int i11 = 0; i11 < f9; i11++) {
                        sb8.append("  ");
                    }
                    for (int i12 = 0; i12 < f10; i12++) {
                        sb9.append("  ");
                    }
                    if (i == 0 || i == 2 || i == 5 || i == 6) {
                        str6 = sb8.toString() + split[0];
                        str7 = sb9.toString() + split[1];
                    } else {
                        str6 = split[0] + sb8.toString();
                        str7 = split[1] + sb9.toString();
                    }
                    return str6 + "\n" + str7 + "\n" + split[2];
                }
            } else if (length2 == length3) {
                if (i5 > 0) {
                    float f11 = (length2 - length) / 2.0f;
                    StringBuilder sb10 = new StringBuilder();
                    float f12 = ((double) f11) == 0.5d ? 0.0f : f11;
                    for (int i13 = 0; i13 < f12; i13++) {
                        sb10.append("  ");
                    }
                    return ((i == 0 || i == 2 || i == 5 || i == 6) ? sb10.toString() + split[0] : split[0] + sb10.toString()) + "\n" + split[1] + "\n" + split[2];
                } else if (length2 < length) {
                    float f13 = (length - length3) / 2.0f;
                    float f14 = (length - length2) / 2.0f;
                    StringBuilder sb11 = new StringBuilder();
                    StringBuilder sb12 = new StringBuilder();
                    if (f14 == 0.5d) {
                        f14 = 0.0f;
                    }
                    if (f13 == 0.5d) {
                        f13 = 0.0f;
                    }
                    for (int i14 = 0; i14 < f14; i14++) {
                        sb12.append("  ");
                    }
                    for (int i15 = 0; i15 < f13; i15++) {
                        sb11.append("  ");
                    }
                    if (i == 0 || i == 2 || i == 5 || i == 6) {
                        str4 = sb12.toString() + split[1];
                        str5 = sb11.toString() + split[2];
                    } else {
                        str4 = split[1] + sb12.toString();
                        str5 = split[2] + sb11.toString();
                    }
                    return split[0] + "\n" + str4 + "\n" + str5;
                }
            } else if (length != length3) {
                return str;
            } else {
                if (i2 > 0) {
                    float f15 = (length - length2) / 2.0f;
                    StringBuilder sb13 = new StringBuilder();
                    float f16 = ((double) f15) == 0.5d ? 0.0f : f15;
                    for (int i16 = 0; i16 < f16; i16++) {
                        sb13.append("  ");
                    }
                    return split[0] + "\n" + ((i == 0 || i == 2 || i == 5 || i == 6) ? sb13.toString() + split[1] : split[1] + sb13.toString()) + "\n" + split[2];
                } else if (i5 > 0) {
                    float f17 = (length2 - length) / 2.0f;
                    float f18 = (length2 - length3) / 2.0f;
                    StringBuilder sb14 = new StringBuilder();
                    StringBuilder sb15 = new StringBuilder();
                    if (f17 == 0.5d) {
                        f17 = 0.0f;
                    }
                    if (f18 == 0.5d) {
                        f18 = 0.0f;
                    }
                    for (int i17 = 0; i17 < f17; i17++) {
                        sb14.append("  ");
                    }
                    for (int i18 = 0; i18 < f18; i18++) {
                        sb15.append("  ");
                    }
                    if (i == 0 || i == 2 || i == 5 || i == 6) {
                        str2 = sb14.toString() + split[0];
                        str3 = sb15.toString() + split[2];
                    } else {
                        str2 = split[0] + sb14.toString();
                        str3 = split[2] + sb15.toString();
                    }
                    return str2 + "\n" + split[1] + "\n" + str3;
                }
            }
        } else if (split.length != 2) {
            return str;
        } else {
            float length4 = split[0].length();
            float length5 = split[1].length();
            int i19 = (length4 > length5 ? 1 : (length4 == length5 ? 0 : -1));
            if (i19 > 0) {
                float f19 = (length4 - length5) / 2.0f;
                float f20 = ((double) f19) == 0.5d ? 0.0f : f19;
                StringBuilder sb16 = new StringBuilder();
                for (int i20 = 0; i20 < f20; i20++) {
                    sb16.append("  ");
                }
                return split[0] + "\n" + ((i == 0 || i == 2 || i == 5 || i == 6) ? sb16.toString() + split[1] : split[1] + sb16.toString());
            } else if (length5 > length4) {
                float f21 = (length5 - length4) / 2.0f;
                if (f21 == 0.5d) {
                    f21 = 0.0f;
                }
                StringBuilder sb17 = new StringBuilder();
                for (int i21 = 0; i21 < f21; i21++) {
                    sb17.append("  ");
                }
                return ((i == 0 || i == 2 || i == 5 || i == 6) ? sb17.toString() + split[0] : split[0] + sb17.toString()) + "\n" + split[1];
            } else if (i19 == 0) {
                return str;
            }
        }
        return "";
    }

    public String stringWithTextSingleSpace(int i, String str) {
        String str2;
        String str3;
        String str4;
        String str5;
        String str6;
        String str7;
        String str8;
        String str9;
        String str10;
        String str11;
        String str12;
        String str13;
        String str14;
        String[] split = str.split("\n");
        if (split.length == 3) {
            float length = split[0].length();
            float length2 = split[1].length();
            float length3 = split[2].length();
            int i2 = (length > length2 ? 1 : (length == length2 ? 0 : -1));
            if (i2 <= 0 || length <= length3) {
                int i3 = (length2 > length ? 1 : (length2 == length ? 0 : -1));
                if (i3 > 0 && length2 > length3) {
                    float f = (length2 - length) / 2.0f;
                    float f2 = (length2 - length3) / 2.0f;
                    StringBuilder sb = new StringBuilder();
                    StringBuilder sb2 = new StringBuilder();
                    if (f == 0.5d) {
                        f = 0.0f;
                    }
                    float f3 = ((double) f2) == 0.5d ? 0.0f : f2;
                    for (int i4 = 0; i4 < f; i4++) {
                        sb.append(" ");
                    }
                    for (int i5 = 0; i5 < f3; i5++) {
                        sb2.append(" ");
                    }
                    if (i == 0 || i == 2 || i == 5 || i == 6) {
                        str11 = sb.toString() + split[0];
                        str12 = sb2.toString() + split[2];
                    } else {
                        str11 = split[0] + sb.toString();
                        str12 = split[2] + sb2.toString();
                    }
                    str4 = str11 + "\n" + split[1] + "\n" + str12;
                } else if (length3 > length2 && length3 > length) {
                    float f4 = (length3 - length) / 2.0f;
                    float f5 = (length3 - length2) / 2.0f;
                    StringBuilder sb3 = new StringBuilder();
                    StringBuilder sb4 = new StringBuilder();
                    if (f4 == 0.5d) {
                        f4 = 0.0f;
                    }
                    if (f5 == 0.5d) {
                        f5 = 0.0f;
                    }
                    for (int i6 = 0; i6 < f4; i6++) {
                        sb3.append(" ");
                    }
                    for (int i7 = 0; i7 < f5; i7++) {
                        sb4.append(" ");
                    }
                    if (i == 0 || i == 2 || i == 5 || i == 6) {
                        str9 = sb3.toString() + split[0];
                        str10 = sb4.toString() + split[1];
                    } else {
                        str9 = split[0] + sb3.toString();
                        str10 = split[1] + sb4.toString();
                    }
                    str4 = str9 + "\n" + str10 + "\n" + split[2];
                } else if (i2 == 0) {
                    if (length > length3) {
                        float f6 = (length - length3) / 2.0f;
                        StringBuilder sb5 = new StringBuilder();
                        float f7 = ((double) f6) == 0.5d ? 0.0f : f6;
                        for (int i8 = 0; i8 < f7; i8++) {
                            sb5.append(" ");
                        }
                        str4 = split[0] + "\n" + split[1] + "\n" + ((i == 0 || i == 2 || i == 5 || i == 6) ? sb5.toString() + split[2] : split[2] + sb5.toString());
                    } else if (length3 <= length) {
                        return null;
                    } else {
                        float f8 = (length3 - length) / 2.0f;
                        float f9 = (length3 - length2) / 2.0f;
                        StringBuilder sb6 = new StringBuilder();
                        StringBuilder sb7 = new StringBuilder();
                        if (f8 == 0.5d) {
                            f8 = 0.0f;
                        }
                        if (f9 == 0.5d) {
                            f9 = 0.0f;
                        }
                        for (int i9 = 0; i9 < f8; i9++) {
                            sb6.append(" ");
                        }
                        for (int i10 = 0; i10 < f9; i10++) {
                            sb7.append(" ");
                        }
                        if (i == 0 || i == 2 || i == 5 || i == 6) {
                            str7 = sb6.toString() + split[0];
                            str8 = sb7.toString() + split[1];
                        } else {
                            str7 = split[0] + sb6.toString();
                            str8 = split[1] + sb7.toString();
                        }
                        str4 = str7 + "\n" + str8 + "\n" + split[2];
                    }
                } else if (length2 == length3) {
                    if (i3 > 0) {
                        float f10 = (length2 - length) / 2.0f;
                        StringBuilder sb8 = new StringBuilder();
                        float f11 = ((double) f10) == 0.5d ? 0.0f : f10;
                        for (int i11 = 0; i11 < f11; i11++) {
                            sb8.append(" ");
                        }
                        str4 = ((i == 0 || i == 2 || i == 5 || i == 6) ? sb8.toString() + split[0] : split[0] + sb8.toString()) + "\n" + split[1] + "\n" + split[2];
                    } else if (length2 >= length) {
                        return null;
                    } else {
                        float f12 = (length - length3) / 2.0f;
                        float f13 = (length - length2) / 2.0f;
                        StringBuilder sb9 = new StringBuilder();
                        StringBuilder sb10 = new StringBuilder();
                        if (f13 == 0.5d) {
                            f13 = 0.0f;
                        }
                        if (f12 == 0.5d) {
                            f12 = 0.0f;
                        }
                        for (int i12 = 0; i12 < f13; i12++) {
                            sb10.append(" ");
                        }
                        for (int i13 = 0; i13 < f12; i13++) {
                            sb9.append(" ");
                        }
                        if (i == 0 || i == 2 || i == 5 || i == 6) {
                            str5 = sb10.toString() + split[1];
                            str6 = sb9.toString() + split[2];
                        } else {
                            str5 = split[1] + sb10.toString();
                            str6 = split[2] + sb9.toString();
                        }
                        str4 = split[0] + "\n" + str5 + "\n" + str6;
                    }
                } else if (length != length3) {
                    return null;
                } else {
                    if (i2 > 0) {
                        float f14 = (length - length2) / 2.0f;
                        StringBuilder sb11 = new StringBuilder();
                        float f15 = ((double) f14) == 0.5d ? 0.0f : f14;
                        for (int i14 = 0; i14 < f15; i14++) {
                            sb11.append(" ");
                        }
                        str4 = split[0] + "\n" + ((i == 0 || i == 2 || i == 5 || i == 6) ? sb11.toString() + split[1] : split[1] + sb11.toString()) + "\n" + split[2];
                    } else if (i3 <= 0) {
                        return null;
                    } else {
                        float f16 = (length2 - length) / 2.0f;
                        float f17 = (length2 - length3) / 2.0f;
                        StringBuilder sb12 = new StringBuilder();
                        StringBuilder sb13 = new StringBuilder();
                        if (f16 == 0.5d) {
                            f16 = 0.0f;
                        }
                        float f18 = ((double) f17) == 0.5d ? 0.0f : f17;
                        for (int i15 = 0; i15 < f16; i15++) {
                            sb12.append(" ");
                        }
                        for (int i16 = 0; i16 < f18; i16++) {
                            sb13.append(" ");
                        }
                        if (i == 0 || i == 2 || i == 5 || i == 6) {
                            str2 = sb12.toString() + split[0];
                            str3 = sb13.toString() + split[2];
                        } else {
                            str2 = split[0] + sb12.toString();
                            str3 = split[2] + sb13.toString();
                        }
                        str4 = str2 + "\n" + split[1] + "\n" + str3;
                    }
                }
            } else {
                float f19 = (length - length3) / 2.0f;
                float f20 = (length - length2) / 2.0f;
                StringBuilder sb14 = new StringBuilder();
                StringBuilder sb15 = new StringBuilder();
                if (f20 == 0.5d) {
                    f20 = 0.0f;
                }
                if (f19 == 0.5d) {
                    f19 = 0.0f;
                }
                for (int i17 = 0; i17 < f20; i17++) {
                    sb15.append(" ");
                }
                for (int i18 = 0; i18 < f19; i18++) {
                    sb14.append(" ");
                }
                if (i == 0 || i == 2 || i == 5 || i == 6) {
                    str13 = sb15.toString() + split[1];
                    str14 = sb14.toString() + split[2];
                } else {
                    str13 = split[1] + sb15.toString();
                    str14 = split[2] + sb14.toString();
                }
                str4 = split[0] + "\n" + str13 + "\n" + str14;
            }
            return str4;
        } else if (split.length == 2) {
            float length4 = split[0].length();
            float length5 = split[1].length();
            int i19 = (length4 > length5 ? 1 : (length4 == length5 ? 0 : -1));
            if (i19 > 0) {
                float f21 = (length4 - length5) / 2.0f;
                float f22 = ((double) f21) == 0.5d ? 0.0f : f21;
                StringBuilder sb16 = new StringBuilder();
                for (int i20 = 0; i20 < f22; i20++) {
                    sb16.append(" ");
                }
                return split[0] + "\n" + ((i == 0 || i == 2 || i == 5 || i == 6) ? sb16.toString() + split[1] : split[1] + sb16.toString());
            } else if (length5 <= length4) {
                if (i19 == 0) {
                    return str;
                }
                return null;
            } else {
                float f23 = (length5 - length4) / 2.0f;
                if (f23 == 0.5d) {
                    f23 = 0.0f;
                }
                StringBuilder sb17 = new StringBuilder();
                for (int i21 = 0; i21 < f23; i21++) {
                    sb17.append(" ");
                }
                return ((i == 0 || i == 2 || i == 5 || i == 6) ? sb17.toString() + split[0] : split[0] + sb17.toString()) + "\n" + split[1];
            }
        } else {
            return str;
        }
    }

    public String getDeviceName() {
        String str = Build.MANUFACTURER;
        String str2 = Build.MODEL;
        if (str2.startsWith(str)) {
            return capitalize(str2);
        }
        return capitalize(str) + " " + str2;
    }

    private String capitalize(String str) {
        if (TextUtils.isEmpty(str)) {
            return str;
        }
        char[] charArray = str.toCharArray();
        StringBuilder sb = new StringBuilder();
        boolean z = true;
        for (char c : charArray) {
            if (z && Character.isLetter(c)) {
                sb.append(Character.toUpperCase(c));
                z = false;
            } else {
                if (Character.isWhitespace(c)) {
                    z = true;
                }
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public ArrayList<DateTime> getDatearray(Context context) {
        return new SharePref(context).getDates(context, SharePref.arryDates);
    }

    public ArrayList<DateTime> getDatearrayHorizontal(Context context) {
        return new SharePref(context).getDates(context, SharePref.arryDates_horizontal);
    }

//    private AdSize getAdSize(Activity activity, FrameLayout frameLayout) {
//        Display defaultDisplay = activity.getWindowManager().getDefaultDisplay();
//        DisplayMetrics displayMetrics = new DisplayMetrics();
//        defaultDisplay.getMetrics(displayMetrics);
//        float f = displayMetrics.density;
//        float width = frameLayout.getWidth();
//        if (width == 0.0f) {
//            width = displayMetrics.widthPixels;
//        }
//        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, (int) (width / f));
//    }

    public long dateDiffenceday(Date date, Date date2) {
        long time = date2.getTime() - date.getTime();
        long j = (time / 1000) % 60;
        long j2 = (time / 60000) % 60;
        long j3 = time / 3600000;
        return (int) ((date2.getTime() - date.getTime()) / 86400000);
    }

    public String getCalculatedDate(String str, int i) {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str);
        calendar.add(6, i);
        return simpleDateFormat.format(new Date(calendar.getTimeInMillis()));
    }

    public void stopLocationUpdates() {
        LocationCallback locationCallback;
        FusedLocationProviderClient fusedLocationProviderClient = this.mFusedLocationClient;
        if (fusedLocationProviderClient == null || (locationCallback = this.mLocationCallback) == null) {
            return;
        }
        fusedLocationProviderClient.removeLocationUpdates(locationCallback);
    }

    public void displayLocationSettingsRequest(final Context context) {
        GoogleApiClient build = new GoogleApiClient.Builder(context).addApi(LocationServices.API).build();
        build.connect();
        LocationRequest create = LocationRequest.create();
        create.setPriority(100);
        create.setInterval(WorkRequest.MIN_BACKOFF_MILLIS);
        create.setFastestInterval(5000L);
        LocationSettingsRequest.Builder addLocationRequest = new LocationSettingsRequest.Builder().addLocationRequest(create);
        addLocationRequest.setAlwaysShow(true);
        LocationServices.SettingsApi.checkLocationSettings(build, addLocationRequest.build()).setResultCallback(new ResultCallback<LocationSettingsResult>() { // from class: com.gpsmapcamera.geotagginglocationonphoto.helper.CommonFunction.2
            @Override // com.google.android.gms.common.api.ResultCallback
            public void onResult(LocationSettingsResult locationSettingsResult) {
                Status status = locationSettingsResult.getStatus();
                int statusCode = status.getStatusCode();
                if (statusCode == 0) {
                    Log.i(CommonFunction.TAG, "All location settings are satisfied.");
                } else if (statusCode != 6) {
                    if (statusCode != 8502) {
                        return;
                    }
                    Log.i(CommonFunction.TAG, "Location settings are inadequate, and cannot be fixed here. Dialog not created.");
                } else {
                    Log.i(CommonFunction.TAG, "Location settings are not satisfied. Show the user a dialog to upgrade location settings ");
                    try {
                        status.startResolutionForResult((Activity) context, 1);
                    } catch (IntentSender.SendIntentException unused) {
                        Log.i(CommonFunction.TAG, "PendingIntent unable to execute request.");
                    }
                }
            }
        });
    }

    public int getLocationMode(Context context) {
        if (context != null) {
            if (Build.VERSION.SDK_INT >= 19) {
                try {
                    return Settings.Secure.getInt(context.getContentResolver(), "location_mode");
                } catch (Settings.SettingNotFoundException e) {
                    e.printStackTrace();
                    return 0;
                }
            }
            try {
                String string = Settings.Secure.getString(context.getContentResolver(), "location_providers_allowed");
                if (TextUtils.isEmpty(string)) {
                    return 0;
                }
                if (string.contains("gps") && string.contains("network")) {
                    return 3;
                }
                if (string.contains("gps")) {
                    return 1;
                }
                return string.contains("network") ? 2 : 0;
            } catch (Exception unused) {
                return 0;
            }
        }
        return 0;
    }
}