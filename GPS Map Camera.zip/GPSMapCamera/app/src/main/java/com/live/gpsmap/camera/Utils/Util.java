package com.live.gpsmap.camera.Utils;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ShareCompat;
import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.BaseRequestOptions;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.live.gpsmap.camera.Mgrs.Angle;
import com.live.gpsmap.camera.Mgrs.MGRSCoord;
import com.live.gpsmap.camera.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.regex.Pattern;

@SuppressWarnings("All")
public class Util {

    private static Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
    public static void hideSoftKeyboard(Activity activity, View view) {
        ((InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static String encodeTobase64(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 60, byteArrayOutputStream);
        return Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0);
    }
    public static boolean isNumeric(String str) {
        if (str == null) {
            return false;
        }
        return pattern.matcher(str).matches();
    }

    public static String loction_latlng(String str, String str2) {
        if (!TextUtils.isEmpty(str) && !TextUtils.isEmpty(str2) && isNumeric(str) && isNumeric(str2)) {
            double parseDouble = Double.parseDouble(str);
            double parseDouble2 = Double.parseDouble(str2);
            String replaceDelimiters = replaceDelimiters(Location.convert(parseDouble, 2), 8);
            String str3 = (parseDouble >= 0.0d ? 'N' : 'S') + " " + replaceDelimiters;
            String replaceDelimiters2 = replaceDelimiters(Location.convert(parseDouble2, 2), 8);
            str2 = (parseDouble2 >= 0.0d ? 'E' : 'W') + " " + replaceDelimiters2;
            str = str3;
        }
        return str + "_" + str2;
    }

    private static ProgressDialog mProgressDialog;

    public static void dismissProgressDialog() {
        try {
            ProgressDialog progressDialog = mProgressDialog;
            if (progressDialog == null || !progressDialog.isShowing()) {
                return;
            }
            mProgressDialog.dismiss();
            mProgressDialog = null;
        } catch (Exception unused) {
        }
    }
    public static void showDialog(Context context, String str, String str2) {
        if (context != null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle(str);
            builder.setMessage(str2);
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            builder.create().show();
        }
    }



    public final boolean isOnline(Context ctx) {
        NetworkCapabilities networkCapabilities;
        Object systemService = ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
        ConnectivityManager connectivityManager = (ConnectivityManager) systemService;
        if (Build.VERSION.SDK_INT>=23) {
            Network activeNetwork = connectivityManager.getActiveNetwork();
            if (activeNetwork == null || (networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork)) == null) {
                return false;
            }
            return networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) || networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) || networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH);
        }
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        if (activeNetworkInfo != null) {
            return activeNetworkInfo.isConnected();

        }
        return false;
    }

    public static String getAccuracy(Context context, int i) {
        double d = new SP(context).getFloat(context, SP.ACCURACY_VALUE);
        if (i == 0) {
            return new DecimalFormat("##.##").format(d) + " m";
        } else if (i != 1) {
            return "";
        } else {
            double d2 = d * 39.370078d;
            return (((int) (d2 - (((int) (d2 / 63360.0d)) * 63360))) / 12) + " ft";
        }
    }

    public static String dms_latlng(Context context) {
        SP sp = new SP(context);
        String string = sp.getString(context, SP.LATITUDE, "");
        String string2 = sp.getString(context, SP.LONGITUDE, "");
        Double.valueOf((double) 0.0d);
        Double.valueOf((double) 0.0d);
        if (string != null && !string.isEmpty() && string2 != null && !string2.isEmpty()) {
            Double valueOf = Double.valueOf(string);
            Double valueOf2 = Double.valueOf(string2);
            String replaceDelimiters = replaceDelimiters(Location.convert(valueOf.doubleValue(), Location.FORMAT_SECONDS), 8);
            String str = (valueOf.doubleValue()>=0.0d ? 'N' : 'S') + " " + replaceDelimiters;
            String replaceDelimiters2 = replaceDelimiters(Location.convert(valueOf2.doubleValue(), Location.FORMAT_SECONDS), 8);
            string2 = (valueOf2.doubleValue()>=0.0d ? 'E' : 'W') + " " + replaceDelimiters2;
            string = str;
        }
        return string + "_" + string2;
    }


    public static void SetLanguage(Activity activity) {
        String string = new SP(activity).getString(activity, SP.SELECTED_LANGUAGE, "English");
        String str = "en";
        if (!string.equals("English")) {
            if (string.equals("bahasa Indonesia (Indonesian)")) {
                str = "in";
            } else if (string.equals("Española (Spanish)")) {
                str = "sn"; //Changed
            } else if (string.equals("Tiếng Việt (Vietnamese)")) {
                str = "vi";
            } else if (string.equals("ไทย (Thai)")) {
                str = "th";
            } else if (string.equals("Português (Portuguese)")) {
                str = "pt";
            } else if (string.equals("Русский (Russian)")) {
                str = "ru";
            } else if (string.equals("Français (French)")) {
                str = "fr";
            } else if (string.equals("한국인 (Korean)")) {
                str = "ko";
            } else if (string.equals("हिन्दी (Hindi)")) {
                str = "hi";
            }
        }
        Locale locale = new Locale(str);
        Locale.setDefault(locale);
        Configuration configuration = new Configuration();
        configuration.locale = locale;
        activity.getResources().updateConfiguration(configuration, activity.getResources().getDisplayMetrics());
    }

//    public static String getLatLong(Context context, int i) {
//        char c;
//        String[] split = new String[0];
//        SP sp = new SP(context);
//        String string = sp.getString(context, SP.LATITUDE, "");
//        String string2 = sp.getString(context, SP.LONGITUDE, "");
//        Double.valueOf((double) 0.0d);
//        Double.valueOf((double) 0.0d);
//        if (string != null && !string.isEmpty() && string2 != null && !string2.isEmpty()) {
//            if (string.contains(",")) {
//                string = string.replace(",", ".");
//            }
//            if (string2.contains(",")) {
//                string2 = string2.replace(",", ".");
//            }
//            Double valueOf = Double.valueOf(string);
//            Double valueOf2 = Double.valueOf(string2);
//            if (valueOf.doubleValue() != 0.0d && valueOf2.doubleValue() != 0.0d) {
//                switch (i) {
//                    case 0:
//                        return "Lat " + string + " Long " + string2;
//                    case 1:
//                        return "Lat " + (string + "°") + " Long " + (string2 + "°");
//                    case 2:
//                        return "Lat " + (string + " " + (valueOf.doubleValue()>=0.0d ? 'N' : 'S')) + " Long " + (string2 + " " + (valueOf2.doubleValue()>=0.0d ? 'E' : 'W'));
//                    case 3:
//                        return "Lat " + replaceDelimins(Location.convert(valueOf.doubleValue(), Location.FORMAT_MINUTES), 8) + " Long " + replaceDelimins(Location.convert(valueOf2.doubleValue(), Location.FORMAT_MINUTES), 8);
//                    case 4:
//                        String replaceDelimiters = replaceDelimiters(Location.convert(valueOf.doubleValue(), Location.FORMAT_SECONDS), 8);
//                        String str = (valueOf.doubleValue()>=0.0d ? 'N' : 'S') + " " + replaceDelimiters;
//                        String replaceDelimiters2 = replaceDelimiters(Location.convert(valueOf2.doubleValue(), Location.FORMAT_SECONDS), 8);
//                        return "Lat " + str + " Long " + ((valueOf2.doubleValue()>=0.0d ? 'E' : 'W') + " " + replaceDelimiters2);
//                    case 5:
//                        String str2 = replaceDelimiterss(Location.convert(valueOf.doubleValue(), Location.FORMAT_SECONDS), 8) + " " + (valueOf.doubleValue()>=0.0d ? 'N' : 'S');
//                        String convert = Location.convert(valueOf2.doubleValue(), Location.FORMAT_SECONDS);
//                        char c2 = valueOf2.doubleValue()>=0.0d ? 'E' : 'W';
//                        return "Lat " + str2 + " Long " + (replaceDelimiterss(convert, 8) + " " + c2);
//                    case 6:
//                        int floor = (int) Math.floor((valueOf2.doubleValue() / 6.0d) + 31.0d);
//                        if (valueOf.doubleValue()<-72.0d) {
//                            c = 'C';
//                        } else if (valueOf.doubleValue()<-64.0d) {
//                            c = 'D';
//                        } else if (valueOf.doubleValue()<-56.0d) {
//                            c = 'E';
//                        } else if (valueOf.doubleValue()<-48.0d) {
//                            c = 'F';
//                        } else if (valueOf.doubleValue()<-40.0d) {
//                            c = 'G';
//                        } else if (valueOf.doubleValue()<-32.0d) {
//                            c = 'H';
//                        } else if (valueOf.doubleValue()<-24.0d) {
//                            c = 'J';
//                        } else if (valueOf.doubleValue()<-16.0d) {
//                            c = 'K';
//                        } else if (valueOf.doubleValue()<-8.0d) {
//                            c = 'L';
//                        } else if (valueOf.doubleValue()<0.0d) {
//                            c = 'M';
//                        } else if (valueOf.doubleValue()<8.0d) {
//                            c = 'N';
//                        } else if (valueOf.doubleValue()<16.0d) {
//                            c = 'P';
//                        } else if (valueOf.doubleValue()<24.0d) {
//                            c = 'Q';
//                        } else if (valueOf.doubleValue()<32.0d) {
//                            c = 'R';
//                        } else if (valueOf.doubleValue()<40.0d) {
//                            c = 'S';
//                        } else if (valueOf.doubleValue()<48.0d) {
//                            c = 'T';
//                        } else if (valueOf.doubleValue()<56.0d) {
//                            c = 'U';
//                        } else if (valueOf.doubleValue()<64.0d) {
//                            c = 'V';
//                        } else {
//                            c = valueOf.doubleValue()<72.0d ? 'W' : 'X';
//                        }
//                        double d = (((floor * 6) - 183) * 3.141592653589793d) / 180.0d;
//                        double round = Math.round(((((((Math.log(((Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) * Math.sin(((valueOf2.doubleValue() * 3.141592653589793d) / 180.0d) - d)) + 1.0d) / (1.0d - (Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) * Math.sin(((valueOf2.doubleValue() * 3.141592653589793d) / 180.0d) - d)))) * 0.5d) * 0.9996d) * 6399593.62d) / Math.pow((Math.pow(0.0820944379d, 2.0d) * Math.pow(Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d), 2.0d)) + 1.0d, 0.5d)) * (((((Math.pow(0.0820944379d, 2.0d) / 2.0d) * Math.pow(Math.log(((Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) * Math.sin(((valueOf2.doubleValue() * 3.141592653589793d) / 180.0d) - d)) + 1.0d) / (1.0d - (Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) * Math.sin(((valueOf2.doubleValue() * 3.141592653589793d) / 180.0d) - d)))) * 0.5d, 2.0d)) * Math.pow(Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d), 2.0d)) / 3.0d) + 1.0d)) + 500000.0d) * 100.0d) * 0.01d;
//                        double atan = (((((Math.atan(Math.tan((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) / Math.cos(((valueOf2.doubleValue() * 3.141592653589793d) / 180.0d) - d)) - ((valueOf.doubleValue() * 3.141592653589793d) / 180.0d)) * 0.9996d) * 6399593.625d) / Math.sqrt((Math.pow(Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d), 2.0d) * 0.006739496742d) + 1.0d)) * ((Math.pow(Math.log(((Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) * Math.sin(((valueOf2.doubleValue() * 3.141592653589793d) / 180.0d) - d)) + 1.0d) / (1.0d - (Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) * Math.sin(((valueOf2.doubleValue() * 3.141592653589793d) / 180.0d) - d)))) * 0.5d, 2.0d) * 0.003369748371d * Math.pow(Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d), 2.0d)) + 1.0d)) + ((((((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) - ((((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) + (Math.sin(((valueOf.doubleValue() * 2.0d) * 3.141592653589793d) / 180.0d) / 2.0d)) * 0.005054622556d)) + (((((((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) + (Math.sin(((valueOf.doubleValue() * 2.0d) * 3.141592653589793d) / 180.0d) / 2.0d)) * 3.0d) + (Math.sin(((valueOf.doubleValue() * 2.0d) * 3.141592653589793d) / 180.0d) * Math.pow(Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d), 2.0d))) * 4.258201531E-5d) / 4.0d)) - ((((((((((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) + (Math.sin(((valueOf.doubleValue() * 2.0d) * 3.141592653589793d) / 180.0d) / 2.0d)) * 3.0d) + (Math.sin(((valueOf.doubleValue() * 2.0d) * 3.141592653589793d) / 180.0d) * Math.pow(Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d), 2.0d))) * 5.0d) / 4.0d) + ((Math.sin(((valueOf.doubleValue() * 2.0d) * 3.141592653589793d) / 180.0d) * Math.pow(Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d), 2.0d)) * Math.pow(Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d), 2.0d))) * 1.674057895E-7d) / 3.0d)) * 6397033.7875500005d);
//                        if (c<'M') {
//                            atan += 1.0E7d;
//                        }
//                        double round2 = Math.round(atan * 100.0d) * 0.01d;
//                        char c3 = valueOf.doubleValue()>=0.0d ? 'N' : 'S';
//                        String str3 = round + " " + c3;
//                        return floor + "" + c + "  " + (String.valueOf(round2) + " " + (valueOf2.doubleValue()>=0.0d ? 'E' : 'W')) + " " + str3;
//                    case 7:
//                        String mGRSCoord = MGRSCoord.fromLatLon(Angle.fromDegrees(valueOf.doubleValue()), Angle.fromDegrees(valueOf2.doubleValue())).toString();
//                        if (mGRSCoord.split(" ").length>2) {
//                            return split[0] + " " + split[1] + " " + split[2];
//                        }
//                        return mGRSCoord;
//                }
//            }
//        }
//        return null;
//    }

    public static String getLatLong(Context context0, int v) {
        int v2;
        SP sP0 = new SP(context0);
        String s = sP0.getString(context0, "latitude_1", "");
        String s1 = sP0.getString(context0, "longitude_1", "");
        if(s != null && !s.isEmpty() && s1 != null && !s1.isEmpty()) {
            if(s.contains(",")) {
                s = s.replace(",", ".");
            }

            if(s1.contains(",")) {
                s1 = s1.replace(",", ".");
            }

            Double double0 = Double.valueOf(s);
            Double double1 = Double.valueOf(s1);
            if(((double)double0) != 0.0 && ((double)double1) != 0.0) {
                switch(v) {
                    case 0: {
                        return "Lat " + s + " Long " + s1;
                    }
                    case 1: {
                        return "Lat " + (s + "°") + " Long " + (s1 + "°");
                    }
                    case 2: {
                        String s2 = s + " " + ((char)(((double)double0) < 0.0 ? 83 : 78));
                        return ((double)double1) < 0.0 ? "Lat " + s2 + " Long " + (s1 + " " + 'W') : "Lat " + s2 + " Long " + (s1 + " " + 'E');
                    }
                    case 3: {
                        return "Lat " + replaceDelimins(Location.convert(double0.doubleValue(), 1), 8) + " Long " + replaceDelimins(Location.convert(double1.doubleValue(), 1), 8);
                    }
                    case 4: {
                        String s3 = ((char)(((double)double0) < 0.0 ? 83 : 78)) + " " + replaceDelimiters(Location.convert(double0.doubleValue(), 2), 8);
                        String s4 = replaceDelimiters(Location.convert(double1.doubleValue(), 2), 8);
                        return ((double)double1) < 0.0 ? "Lat " + s3 + " Long " + ('W' + " " + s4) : "Lat " + s3 + " Long " + ('E' + " " + s4);
                    }
                    case 5: {
                        String s5 = replaceDelimiterss(Location.convert(double0.doubleValue(), 2), 8) + " " + ((char)(((double)double0) < 0.0 ? 83 : 78));
                        String s6 = Location.convert(double1.doubleValue(), 2);
                        return ((double)double1) < 0.0 ? "Lat " + s5 + " Long " + (replaceDelimiterss(s6, 8) + " " + 'W') : "Lat " + s5 + " Long " + (replaceDelimiterss(s6, 8) + " " + 'E');
                    }
                    case 6: {
                        int v1 = (int)Math.floor(((double)double1) / 6.0 + 31.0);
                        if(((double)double0) < -72.0) {
                            v2 = 67;
                        }
                        else if(((double)double0) < -64.0) {
                            v2 = 68;
                        }
                        else if(((double)double0) < -56.0) {
                            v2 = 69;
                        }
                        else if(((double)double0) < -48.0) {
                            v2 = 70;
                        }
                        else if(((double)double0) < -40.0) {
                            v2 = 71;
                        }
                        else if(((double)double0) < -32.0) {
                            v2 = 72;
                        }
                        else if(((double)double0) < -24.0) {
                            v2 = 74;
                        }
                        else if(((double)double0) < -16.0) {
                            v2 = 75;
                        }
                        else if(((double)double0) < -8.0) {
                            v2 = 76;
                        }
                        else if(((double)double0) < 0.0) {
                            v2 = 77;
                        }
                        else if(((double)double0) < 8.0) {
                            v2 = 78;
                        }
                        else if(((double)double0) < 16.0) {
                            v2 = 80;
                        }
                        else if(((double)double0) < 24.0) {
                            v2 = 81;
                        }
                        else if(((double)double0) < 32.0) {
                            v2 = 82;
                        }
                        else if(((double)double0) < 40.0) {
                            v2 = 83;
                        }
                        else if(((double)double0) < 48.0) {
                            v2 = 84;
                        }
                        else if(((double)double0) < 56.0) {
                            v2 = 85;
                        }
                        else if(((double)double0) < 64.0) {
                            v2 = 86;
                        }
                        else {
                            v2 = ((double)double0) >= 72.0 ? 88 : 87;
                        }

                        double f = ((double)(v1 * 6 - 0xB7)) * 3.141593 / 180.0;
                        double f1 = ((double)Math.round((Math.log((Math.cos(((double)double0) * 3.141593 / 180.0) * Math.sin(((double)double1) * 3.141593 / 180.0 - f) + 1.0) / (1.0 - Math.cos(((double)double0) * 3.141593 / 180.0) * Math.sin(((double)double1) * 3.141593 / 180.0 - f))) * 0.5 * 0.9996 * 6399593.62 / Math.pow(0.006739 * Math.pow(Math.cos(((double)double0) * 3.141593 / 180.0), 2.0) + 1.0, 0.5) * (0.00337 * Math.pow(Math.log((Math.cos(((double)double0) * 3.141593 / 180.0) * Math.sin(((double)double1) * 3.141593 / 180.0 - f) + 1.0) / (1.0 - Math.cos(((double)double0) * 3.141593 / 180.0) * Math.sin(((double)double1) * 3.141593 / 180.0 - f))) * 0.5, 2.0) * Math.pow(Math.cos(((double)double0) * 3.141593 / 180.0), 2.0) / 3.0 + 1.0) + 500000.0) * 100.0)) * 0.01;
                        double f2 = (Math.atan(Math.tan(((double)double0) * 3.141593 / 180.0) / Math.cos(((double)double1) * 3.141593 / 180.0 - f)) - ((double)double0) * 3.141593 / 180.0) * 0.9996 * 6399593.625 / Math.sqrt(Math.pow(Math.cos(((double)double0) * 3.141593 / 180.0), 2.0) * 0.006739 + 1.0) * (Math.pow(Math.log((Math.cos(((double)double0) * 3.141593 / 180.0) * Math.sin(((double)double1) * 3.141593 / 180.0 - f) + 1.0) / (1.0 - Math.cos(((double)double0) * 3.141593 / 180.0) * Math.sin(((double)double1) * 3.141593 / 180.0 - f))) * 0.5, 2.0) * 0.00337 * Math.pow(Math.cos(((double)double0) * 3.141593 / 180.0), 2.0) + 1.0) + (((double)double0) * 3.141593 / 180.0 - (((double)double0) * 3.141593 / 180.0 + Math.sin(((double)double0) * 2.0 * 3.141593 / 180.0) / 2.0) * 0.005055 + ((((double)double0) * 3.141593 / 180.0 + Math.sin(((double)double0) * 2.0 * 3.141593 / 180.0) / 2.0) * 3.0 + Math.sin(((double)double0) * 2.0 * 3.141593 / 180.0) * Math.pow(Math.cos(((double)double0) * 3.141593 / 180.0), 2.0)) * 0.000043 / 4.0 - (((((double)double0) * 3.141593 / 180.0 + Math.sin(((double)double0) * 2.0 * 3.141593 / 180.0) / 2.0) * 3.0 + Math.sin(((double)double0) * 2.0 * 3.141593 / 180.0) * Math.pow(Math.cos(((double)double0) * 3.141593 / 180.0), 2.0)) * 5.0 / 4.0 + Math.sin(((double)double0) * 2.0 * 3.141593 / 180.0) * Math.pow(Math.cos(((double)double0) * 3.141593 / 180.0), 2.0) * Math.pow(Math.cos(((double)double0) * 3.141593 / 180.0), 2.0)) * 1.674058E-07 / 3.0) * 6397033.78755;
                        if(v2 < 77) {
                            f2 += 10000000.0;
                        }

                        double f3 = ((double)Math.round(f2 * 100.0)) * 0.01;
                        int v3 = ((double)double0) < 0.0 ? 83 : 78;
                        return ((double)double1) < 0.0 ? v1 + "" + ((char)v2) + "  " + (String.valueOf(f3) + " " + 'W') + " " + (f1 + " " + ((char)v3)) : v1 + "" + ((char)v2) + "  " + (String.valueOf(f3) + " " + 'E') + " " + (f1 + " " + ((char)v3));
                    }
                    case 7: {
                        break;
                    }
                    default: {
                        return null;
                    }
                }

                String s7 = MGRSCoord.fromLatLon(Angle.fromDegrees(double0.doubleValue()), Angle.fromDegrees(double1.doubleValue())).toString();
                String[] arr_s = s7.split(" ");
                return arr_s.length <= 2 ? s7 : arr_s[0] + " " + arr_s[1] + " " + arr_s[2];
            }
        }

        return null;
    }
    private static String replaceDelimins(String str, int i) {
        String replaceFirst = str.replaceFirst(":", "");
        int indexOf = replaceFirst.indexOf(".") + 1 + i;
        return indexOf<replaceFirst.length() ? replaceFirst.substring(0, indexOf) : replaceFirst;
    }

    private static String replaceDelimiterss(String str, int i) {
        String replaceFirst = str.replaceFirst(":", "").replaceFirst(":", "");
        int indexOf = replaceFirst.indexOf(".") + 1 + i;
        return indexOf<replaceFirst.length() ? replaceFirst.substring(0, indexOf) : replaceFirst;
    }

    private static String replaceDelimiters(String str, int i) {
        String replaceFirst = str.replaceFirst(":", "° ").replaceFirst(":", "' ");
        int indexOf = replaceFirst.indexOf(".") + 1 + i;
        if (indexOf<replaceFirst.length()) {
            replaceFirst = replaceFirst.substring(0, indexOf);
        }
        return replaceFirst + "\"";
    }

    public static void showShareDialog(final Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(context.getResources().getString(R.string.alert_share_title));
        builder.setMessage(context.getResources().getString(R.string.alert_share_dialog_mesg)).setCancelable(false).
                setNeutralButton(context.getResources().getString(R.string.alert_share_btn_neutral), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).setPositiveButton(context.getResources().getString(R.string.alert_share_btn_negative), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                new SP(context).setBoolean(context, "share", true);
            }
        }).setNegativeButton(context.getResources().getString(R.string.alert_share_btn_positive), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Util.shareApp(context);
                new SP(context).setBoolean(context, "share", true);
            }
        });
        builder.create().show();
    }

    public static void shareApp(final Context context) {
        Glide.with(context).asBitmap().load(Integer.valueOf((int) R.drawable.gps_map_camera_share_image)).apply((BaseRequestOptions<?>) new RequestOptions().override(1024, 1000)).listener(new RequestListener<Bitmap>() {
            @Override
            public boolean onLoadFailed(GlideException glideException, Object obj, Target<Bitmap> target, boolean z) {
                return false;
            }

            @Override
            public boolean onResourceReady(Bitmap bitmap, Object obj, Target<Bitmap> target, DataSource dataSource, boolean z) {
                Context context2 = context;
                Util.shareImage(context2, bitmap, context2.getString(R.string.app_name), (context.getResources().getString(R.string.app_name) + "\n\n" + context.getString(R.string.share_app_desc)) + "\n" + context.getString(R.string.share_link));
                return false;
            }
        }).submit();
    }
    public static void shareImage(Context context, Bitmap bitmap, String str, String str2) {
        Uri saveImageExternal = saveImageExternal(context, bitmap, str);
        context.startActivity(ShareCompat.IntentBuilder.from((Activity) context).setStream(saveImageExternal).setType("image/*").setText(str2).getIntent().setAction("android.intent.action.SEND").setDataAndType(saveImageExternal, "image/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
    }


    public static Uri saveImageExternal(Context context, Bitmap bitmap, String str) {
        try {
            File externalFilesDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            File file = new File(externalFilesDir, str + " .png");
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.PNG, 90, fileOutputStream);
            fileOutputStream.close();
            return FileProvider.getUriForFile(context, context.getPackageName() + ".provider", file);
        } catch (IOException e) {
            Log.d("TAG", "IOException while trying to write file for sharing: " + e.getMessage());
            return null;
        }
    }
    public static int dpToPx(Context context, int i) {
        return Math.round(i * (context.getResources().getDisplayMetrics().xdpi / 160.0f));
    }
    public static String getAltitudeconvert(Context context, int i) {
        double d = new SP(context).getFloat(context, SP.ALTITUDE_VALUE);
        if (i == 0) {
            return new DecimalFormat("##.##").format(d) + " m";
        } else if (i != 1) {
            return "";
        } else {
            double d2 = d * 39.370078d;
            return (((int) (d2 - (((int) (d2 / 63360.0d)) * 63360))) / 12) + " ";
        }
    }
    public static Bitmap decodeBase64(String str) {
        byte[] decode = Base64.decode(str, 0);
        return BitmapFactory.decodeByteArray(decode, 0, decode.length);
    }
    public static String setDateTimeFormat(String str) {
        String format;
        Calendar calendar = Calendar.getInstance();
        if (str.contains("ddth")) {
            format = addExtention(str);
        } else {
            format = new SimpleDateFormat(str, Locale.getDefault()).format(calendar.getTime());
        }
        return format.replace("am", "AM").replace("pm", "PM");
    }

    private static String addExtention(String str) {
        String str2;
        Calendar calendar = Calendar.getInstance();
        String[] split = str.split("th");
        String format = new SimpleDateFormat(split[0], Locale.getDefault()).format(calendar.getTime());
        char charAt = format.charAt(format.length() - 1);
        if (format.substring(format.length() - 2).equalsIgnoreCase("13") || format.equalsIgnoreCase("13") || format.substring(format.length() - 2).equalsIgnoreCase("12") || format.equalsIgnoreCase("12") || format.substring(format.length() - 2).equalsIgnoreCase("11") || format.equalsIgnoreCase("11")) {
            str2 = format + "th";
        } else if (charAt == '1') {
            str2 = format + "st";
        } else if (charAt == '2') {
            str2 = format + "nd";
        } else if (charAt == '3') {
            str2 = format + "rd";
        } else {
            str2 = format + "th";
        }
        if (split.length == 1) {
            new SimpleDateFormat(split[0], Locale.getDefault());
            return str2;
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(split[1], Locale.getDefault());
        return str2 + simpleDateFormat.format(calendar.getTime());
    }

    public static String getCelcius(float f2) {
        return "" + f2 + "° C";
    }

    public static String getFahrenheit(float f2) {
        return "" + (((Math.round(f2) * 9) / 5) + 32) + "° F";
    }

    public static String getwindConvert(Context context, int i) {
        double d = new SP(context).getFloat(context, SP.WIND_VALUE);
        String str = "";
        if (i == 0) {
            return new DecimalFormat(str).format(d * 3.6d) + " km/h";
        } else if (i == 1) {
            return new DecimalFormat(str).format(d * 2.23694d) + " mph";
        } else if (i == 2) {
            return new DecimalFormat(str).format(d) + " m/s";
        } else if (i != 3) {
            return "";
        } else {
            return new DecimalFormat(str).format(d * 1.94384d) + " kt";
        }
    }
    public static String getpressureConvert(Context context, int i) {
        double d = new SP(context).getFloat(context, SP.PRESSURE_VALUE);
        if (i == 0) {
            return new DecimalFormat("##.##").format(d) + " hpa";
        } else if (i == 1) {
            return new DecimalFormat("##.##").format(d * 0.75d) + " mmhg";
        } else if (i != 2) {
            return "";
        } else {
            return new DecimalFormat("##.##").format(d * 0.03d) + " inHg";
        }
    }
    public static Typeface getFontStyle(Context context0, String str) {
        File file0 = new File(context0.getFilesDir(), "font/" + str);
        if(file0.exists()) {
            try {
                return Typeface.createFromFile(file0);
            }
            catch(Exception unused_ex) {
                return Typeface.createFromAsset(context0.getResources().getAssets(), "sfuitext_regular.otf");
            }
        }

        return Typeface.createFromAsset(context0.getResources().getAssets(), str);
    }




}
