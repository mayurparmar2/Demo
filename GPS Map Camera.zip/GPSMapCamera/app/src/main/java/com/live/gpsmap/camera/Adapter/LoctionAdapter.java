package com.live.gpsmap.camera.Adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.live.gpsmap.camera.Interface.OnRecyclerItemClickListener;
import com.live.gpsmap.camera.Model.LoctionModel;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Helper.SingleClickListener;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.Utils.Util;

import java.util.ArrayList;

public class LoctionAdapter extends RecyclerView.Adapter<LoctionAdapter.Holder> {
    Activity mContext;
    ArrayList<LoctionModel> mList;
    OnRecyclerItemClickListener mOnRecyclerItemClickListener;
    SP mSP;

    public LoctionAdapter(Activity activity, ArrayList<LoctionModel> arrayList, OnRecyclerItemClickListener onRecyclerItemClickListener) {
        new ArrayList();
        this.mContext = activity;
        this.mList = arrayList;
        this.mOnRecyclerItemClickListener = onRecyclerItemClickListener;
        this.mSP = new SP(this.mContext);
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.loction_adapter, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(Holder holder, int i) {
        LoctionModel loctionModel = this.mList.get(i);
        holder.initializeMapView(i, loctionModel);
        holder.tv_title.setText(loctionModel.getTitle());
        holder.tv_latlog.setText(Util.loction_latlng(loctionModel.getLatitude(), loctionModel.getLongitude()));
        holder.tv_address.setText(loctionModel.getLoc_line_1());
        if (loctionModel.getSelection() == 1) {
            holder.tv_title.setTextColor(this.mContext.getResources().getColor(R.color._ffcc00));
        } else {
            holder.tv_title.setTextColor(this.mContext.getResources().getColor(R.color._3D3D3D));
        }
    }

    @Override
    public int getItemCount() {
        return this.mList.size();
    }

    public void refreceadpter(ArrayList<LoctionModel> arrayList) {
        this.mList = arrayList;
        notifyDataSetChanged();
    }

    public class Holder extends RecyclerView.ViewHolder implements OnMapReadyCallback {
        boolean isMapReady;
        LinearLayout lin_main;
        LoctionModel loctionModel;
        GoogleMap map;
        MapView map_view;
        int position;
        TextView tv_address;
        TextView tv_latlog;
        TextView tv_title;

        public Holder(final View view) {
            super(view);
            this.isMapReady = false;
            this.lin_main = (LinearLayout) view.findViewById(R.id.lin_main);
            this.tv_title = (TextView) view.findViewById(R.id.txt_title);
            this.tv_address = (TextView) view.findViewById(R.id.txt_address);
            this.tv_latlog = (TextView) view.findViewById(R.id.txt_latlog);
            this.map_view = (MapView) view.findViewById(R.id.map);
            this.lin_main.setOnClickListener(new SingleClickListener() {
                @Override
                public void performClick(View view2) {
                    if (Holder.this.getAdapterPosition() < 0 || view == null || LoctionAdapter.this.mOnRecyclerItemClickListener == null) {
                        return;
                    }
                    LoctionAdapter.this.mOnRecyclerItemClickListener.OnClick_(Holder.this.getAdapterPosition(), view);
                }
            });
            this.lin_main.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view2) {
                    if (Holder.this.getAdapterPosition() < 0 || view == null || LoctionAdapter.this.mOnRecyclerItemClickListener == null) {
                        return false;
                    }
                    LoctionAdapter.this.mOnRecyclerItemClickListener.OnLongClick_(Holder.this.getAdapterPosition(), view);
                    return false;
                }
            });
        }

        @Override
        public void onMapReady(GoogleMap googleMap) {
            MapsInitializer.initialize(LoctionAdapter.this.mContext);
            this.map = googleMap;
            this.isMapReady = true;
            googleMap.getUiSettings().setMapToolbarEnabled(false);
            if (this.map_view.getViewTreeObserver().isAlive()) {
                this.map_view.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        if (Build.VERSION.SDK_INT < 16) {
                            Holder.this.map_view.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                        } else {
                            Holder.this.map_view.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                        }
                    }
                });
            }
            try {
                setMapData(new LatLng(Double.parseDouble(this.loctionModel.getLatitude()), Double.parseDouble(this.loctionModel.getLongitude())));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public void setMapData(LatLng latLng) {
            GoogleMap googleMap = this.map;
            if (googleMap != null) {
                googleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                this.map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 14.0f));
                if (LoctionAdapter.this.mContext.getResources().getBoolean(R.bool.isTablet)) {
                    this.map.addMarker(new MarkerOptions().position(latLng).flat(true).draggable(false).anchor(0.5f, 0.5f).icon(BitmapFromVector(LoctionAdapter.this.mContext, R.drawable.google_map_pin, 20, 35)));
                } else {
                    this.map.addMarker(new MarkerOptions().position(latLng).flat(true).draggable(false).anchor(0.5f, 0.5f).icon(BitmapFromVector(LoctionAdapter.this.mContext, R.drawable.google_map_pin, 35, 60)));
                }
                this.map.setMapType(1);
                return;
            }
            Log.e("Map", "Map null");
        }

        private BitmapDescriptor BitmapFromVector(Context context, int i, int i2, int i3) {
            Drawable drawable = ContextCompat.getDrawable(context, i);
            drawable.setBounds(0, 0, i2, i3);
            Bitmap createBitmap = Bitmap.createBitmap(i2, i3, Bitmap.Config.ARGB_8888);
            drawable.draw(new Canvas(createBitmap));
            return BitmapDescriptorFactory.fromBitmap(createBitmap);
        }

        public void initializeMapView(int i, LoctionModel loctionModel) {
            try {
                this.position = i;
                this.loctionModel = loctionModel;
                MapView mapView = this.map_view;
                if (mapView != null) {
                    mapView.onCreate(null);
                    this.map_view.onResume();
                    this.map_view.getMapAsync(this);
                } else {
                    Log.e("Map", "Mapview null");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}