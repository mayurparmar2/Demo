package com.live.gpsmap.camera.Receiver;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Build;
import android.os.PowerManager;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.live.gpsmap.camera.Activity.ActivitySplash;
import com.live.gpsmap.camera.BuildConfig;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Default;
import com.live.gpsmap.camera.Utils.SP;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

@SuppressWarnings("All")
public class AlarmReceiver extends BroadcastReceiver {
    public static final int ALARM_REQUEST_CODE_100PHOTOS = 55;
    public static final int ALARM_REQUEST_CODE_10TIMES_OPEN = 52;
    public static final int ALARM_REQUEST_CODE_15DAYS = 51;
    public static final int ALARM_REQUEST_CODE_2ND_DAY = 57;
    public static final int ALARM_REQUEST_CODE_3_TIME_NO_BUY = 65;
    public static final int ALARM_REQUEST_CODE_3_TIME_NO_BUY_STAN = 66;
    public static final int ALARM_REQUEST_CODE_45PHOTOS = 53;
    public static final int ALARM_REQUEST_CODE_500PHOTOS = 56;
    public static final int ALARM_REQUEST_CODE_50PHOTOS_PRO = 54;
    public static final int ALARM_REQUEST_CODE_CAMSET_OPEN_TIME = 59;
    public static final int ALARM_REQUEST_CODE_FILE_OPEN_TIME = 61;
    public static final int ALARM_REQUEST_CODE_FOLD_OPEN_TIME = 60;
    public static final int ALARM_REQUEST_CODE_FONT_OPEN_TIME = 63;
    public static final int ALARM_REQUEST_CODE_MAP_OPEN_TIME = 58;
    public static final int ALARM_REQUEST_CODE_STAMPPOS_OPEN_TIME = 64;
    public static final int ALARM_REQUEST_CODE_TEMP_OPEN_TIME = 62;
    public static final int NID_100PHOTOS = 5;
    public static final int NID_10TIMES_OPEN = 2;
    public static final int NID_15DAYS = 1;
    public static final int NID_2ND_DAY = 7;
    public static final int NID_3_TIME_NO_BUY = 15;
    public static final int NID_3_TIME_NO_BUY_STAN = 16;
    public static final int NID_45PHOTOS = 3;
    public static final int NID_500PHOTOS = 6;
    public static final int NID_50PHOTOS_PRO = 4;
    public static final int NID_CAMSET_OPEN_TIME = 9;
    public static final int NID_FILE_OPEN_TIME = 11;
    public static final int NID_FOLD_OPEN_TIME = 10;
    public static final int NID_FONT_OPEN_TIME = 13;
    public static final int NID_MAP_OPEN_TIME = 8;
    public static final int NID_STAMPPOS_OPEN_TIME = 14;
    public static final int NID_TEMP_OPEN_TIME = 12;
    public static final String SCREEN_FOLDER = "screen_folder";
    public static final String SCREEN_IN_APP = "screen_in_app";
    public static final String SCREEN_LOCATION = "screen_location";
    public static final String SCREEN_SPLASH = "screen_splash";
    private String app_running;
    boolean isAppRunning = false;
    NotificationManagerCompat notificationManager;

    @SuppressLint("MissingPermission")
    @Override
    public void onReceive(Context context, Intent intent) {
        PowerManager.WakeLock newWakeLock = ((PowerManager) context.getSystemService(Context.POWER_SERVICE)).newWakeLock(1, ":AlarmService");
        newWakeLock.acquire(600000);
        context.getPackageManager().setComponentEnabledSetting(new ComponentName(context, ActivitySplash.class), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
        this.notificationManager = NotificationManagerCompat.from(context);
        if (Build.VERSION.SDK_INT >= 26) {
            String string = context.getString(R.string.app_name);
            String string2 = context.getString(R.string.app_name);
            NotificationChannel notificationChannel = new NotificationChannel(context.getString(R.string.app_name), string, NotificationManager.IMPORTANCE_DEFAULT);
            notificationChannel.setDescription(string2);
            this.notificationManager.createNotificationChannel(notificationChannel);
        }
        setLanguage(context);
        List<ActivityManager.RunningTaskInfo> runningTasks = ((ActivityManager) Objects.requireNonNull((ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE))).getRunningTasks(Integer.MAX_VALUE);
        for (int i = 0; i < runningTasks.size(); i++) {
            if (runningTasks.get(i).baseActivity.toShortString().contains(BuildConfig.APPLICATION_ID)) {
                this.isAppRunning = true;
            }
        }
        int intExtra = intent.getIntExtra("alarmId", 0);
        SP sp = new SP(context);
        if (!AlarmTimingUtils.isWithin15Days(context) && intExtra == 51) {
            if (!this.isAppRunning) {
                cancelAlarm(context, intExtra);
                this.notificationManager.notify(1, BuildNotificationUtils.buildNotification(context, 51));
//                FBAnalyticsEventUtils.registerEvent(context, context.getString(R.string.show_15th_day_app_open), context.getString(R.string.show_15th_day_app_open), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
            }
            setNextNotification(context, intent);
        }
        if (intExtra == 52) {
            if (!this.isAppRunning) {
                this.notificationManager.notify(2, BuildNotificationUtils.buildNotification(context, 52));
//                FBAnalyticsEventUtils.registerEvent(context, context.getString(R.string.show_10_time_open_45_pics), context.getString(R.string.show_10_time_open_45_pics), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 53) {
            if (!this.isAppRunning) {
                this.notificationManager.notify(3, BuildNotificationUtils.buildNotification(context, 53));
//                FBAnalyticsEventUtils.registerEvent(context, context.getString(R.string.show_10_time_open_45_pics), context.getString(R.string.show_10_time_open_45_pics), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 54) {
            if (!this.isAppRunning && !sp.getBoolean(context, "isPurcheshOrNot")) {
                this.notificationManager.notify(4, BuildNotificationUtils.buildNotification(context, 54));
//                FBAnalyticsEventUtils.registerEvent(context, context.getString(R.string.show_50_times_photo_click_pro_screen), context.getString(R.string.show_50_times_photo_click_pro_screen), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 55) {
            if (!this.isAppRunning) {
                this.notificationManager.notify(5, BuildNotificationUtils.buildNotification(context, 55));
//                FBAnalyticsEventUtils.registerEvent(context, context.getString(R.string.show_100_times_photo_click), context.getString(R.string.show_100_times_photo_click), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 56) {
            if (!this.isAppRunning) {
                this.notificationManager.notify(6, BuildNotificationUtils.buildNotification(context, 56));
//                FBAnalyticsEventUtils.registerEvent(context, context.getString(R.string.show_100_times_photo_click), context.getString(R.string.show_100_times_photo_click), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 57) {
            if (!this.isAppRunning) {
                this.notificationManager.notify(7, BuildNotificationUtils.buildNotification(context, 57));
//                FBAnalyticsEventUtils.registerEvent(context, context.getString(R.string.show_2nd_day_app_open), context.getString(R.string.show_2nd_day_app_open), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 58) {
            if (!this.isAppRunning) {
                this.notificationManager.notify(8, BuildNotificationUtils.buildNotification(context, 58));
//                FBAnalyticsEventUtils.registerEvent(context, context.getString(R.string.show_map_open_time), context.getString(R.string.show_map_open_time), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 59) {
            if (!this.isAppRunning) {
                this.notificationManager.notify(9, BuildNotificationUtils.buildNotification(context, 59));
//                FBAnalyticsEventUtils.registerEvent(context, context.getString(R.string.show_camset_open_time), context.getString(R.string.show_camset_open_time), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 60) {
            if (!this.isAppRunning) {
                this.notificationManager.notify(10, BuildNotificationUtils.buildNotification(context, 60));
//                FBAnalyticsEventUtils.registerEvent(context, context.getString(R.string.show_fold_open_time), context.getString(R.string.show_fold_open_time), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 61) {
            if (!this.isAppRunning) {
                this.notificationManager.notify(11, BuildNotificationUtils.buildNotification(context, 61));
//                FBAnalyticsEventUtils.registerEvent(context, context.getString(R.string.show_file_open_time), context.getString(R.string.show_file_open_time), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 62) {
            if (!this.isAppRunning) {
                this.notificationManager.notify(12, BuildNotificationUtils.buildNotification(context, 62));
//                FBAnalyticsEventUtils.registerEvent(context, context.getString(R.string.show_temp_open_time), context.getString(R.string.show_temp_open_time), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 63) {
            if (!this.isAppRunning) {
                this.notificationManager.notify(13, BuildNotificationUtils.buildNotification(context, 63));
//                FBAnalyticsEventUtils.registerEvent(context, context.getString(R.string.show_font_open_time), context.getString(R.string.show_font_open_time), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 64) {
            if (!this.isAppRunning) {
                this.notificationManager.notify(14, BuildNotificationUtils.buildNotification(context, 64));
//                FBAnalyticsEventUtils.registerEvent(context, context.getString(R.string.show_stamppos_open_time), context.getString(R.string.show_stamppos_open_time), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 65) {
            if (!this.isAppRunning) {
                this.notificationManager.notify(15, BuildNotificationUtils.buildNotification(context, 65));
//                FBAnalyticsEventUtils.registerEvent(context, context.getString(R.string.show_3_time_no_buy), context.getString(R.string.show_3_time_no_buy), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 66) {
            if (!this.isAppRunning) {
                this.notificationManager.notify(16, BuildNotificationUtils.buildNotification(context, 66));
//                FBAnalyticsEventUtils.registerEvent(context, context.getString(R.string.show_3_time_no_buy_stan), context.getString(R.string.show_3_time_no_buy_stan), ServerProtocol.DIALOG_RETURN_SCOPES_TRUE);
            } else {
                setNextNotification(context, intent);
            }
        }
        newWakeLock.release();
    }

    private void setLanguage(Context context) {
        Locale locale = new Locale(new SP(context).getString(context, SP.SELECTED_LANGUAGE, Default.LANGUAGE));
        Locale.setDefault(locale);
        Configuration configuration = new Configuration();
        configuration.locale = locale;
        context.getResources().updateConfiguration(configuration, context.getResources().getDisplayMetrics());
    }

    private void setNextNotification(Context context, Intent intent) {
        int intExtra = intent.getIntExtra("alarmId", 0);
        Calendar calendar = Calendar.getInstance();
        if (intExtra == 51) {
            calendar.set(11, 21);
            calendar.set(12, 0);
            calendar.set(13, 0);
            calendar.set(14, 0);
            calendar.add(5, 15);
        } else {
            calendar.set(11, 21);
            calendar.set(12, 0);
            calendar.set(13, 0);
            calendar.set(14, 0);
            calendar.add(5, 1);
        }
        setAlarm(context, calendar.getTimeInMillis(), intExtra);
    }

    public void setAlarm(Context context, long j, int i) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(j);
        calendar.set(11, 21);
        calendar.set(12, 0);
        calendar.set(13, 0);
        calendar.set(14, 0);
        SP sp = new SP(context);
        if (i == 51) {
            sp.setLong(context, SP.ALARM_TIME_15_DAYS, j);
        } else if (i == 52) {
            sp.setLong(context, SP.ALARM_TIME_10_TIMES_OPEN, calendar.getTimeInMillis());
        } else if (i == 53) {
            sp.setLong(context, SP.ALARM_TIME_45_PHOTOS, calendar.getTimeInMillis());
        } else if (i == 54) {
            sp.setLong(context, SP.ALARM_TIME_50_PHOTOS_PRO, calendar.getTimeInMillis());
        } else if (i == 55) {
            sp.setLong(context, SP.ALARM_TIME_100_PHOTOS, calendar.getTimeInMillis());
        } else if (i == 56) {
            sp.setLong(context, SP.ALARM_TIME_500_PHOTOS, calendar.getTimeInMillis());
        } else if (i == 57) {
            sp.setLong(context, SP.ALARM_TIME_2ND_DAY, calendar.getTimeInMillis());
        } else if (i == 58) {
            sp.setLong(context, SP.ALARM_TIME_MAP_OPEN_TIME, calendar.getTimeInMillis());
        } else if (i == 59) {
            sp.setLong(context, SP.ALARM_TIME_CAMSET_OPEN_TIME, calendar.getTimeInMillis());
        } else if (i == 60) {
            sp.setLong(context, SP.ALARM_TIME_FOLD_OPEN_TIME, calendar.getTimeInMillis());
        } else if (i == 61) {
            sp.setLong(context, SP.ALARM_TIME_FILE_OPEN_TIME, calendar.getTimeInMillis());
        } else if (i == 62) {
            sp.setLong(context, SP.ALARM_TIME_TEMP_OPEN_TIME, calendar.getTimeInMillis());
        } else if (i == 63) {
            sp.setLong(context, SP.ALARM_TIME_FONT_OPEN_TIME, calendar.getTimeInMillis());
        } else if (i == 64) {
            sp.setLong(context, SP.ALARM_TIME_STAMPPOS_OPEN_TIME, calendar.getTimeInMillis());
        } else if (i == 65) {
            sp.setLong(context, SP.ALARM_TIME_3_TIME_NO_BUY, calendar.getTimeInMillis());
        } else if (i == 66) {
            sp.setLong(context, SP.ALARM_TIME_3_TIME_NO_BUY_STAN, calendar.getTimeInMillis());
        }
        try {
            setExactIdleAlarm(context, i);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setExactIdleAlarm(Context context, int i) {
        PendingIntent broadcast;
        AlarmManager.AlarmClockInfo alarmClockInfo;
        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("alarmId", i);
        if (Build.VERSION.SDK_INT >= 31) {
            broadcast = PendingIntent.getBroadcast(context, i, intent, 201326592);
        } else {
            broadcast = PendingIntent.getBroadcast(context, i, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        }
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        switch (i) {
            case 51:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_15_DAYS, System.currentTimeMillis()), broadcast);
                break;
            case 52:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_10_TIMES_OPEN, System.currentTimeMillis()), broadcast);
                break;
            case 53:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_45_PHOTOS, System.currentTimeMillis()), broadcast);
                break;
            case 54:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_50_PHOTOS_PRO, System.currentTimeMillis()), broadcast);
                break;
            case 55:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_100_PHOTOS, System.currentTimeMillis()), broadcast);
                break;
            case 56:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_500_PHOTOS, System.currentTimeMillis()), broadcast);
                break;
            case 57:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_2ND_DAY, System.currentTimeMillis()), broadcast);
                break;
            case 58:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_MAP_OPEN_TIME, System.currentTimeMillis()), broadcast);
                break;
            case 59:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_CAMSET_OPEN_TIME, System.currentTimeMillis()), broadcast);
                break;
            case 60:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_FOLD_OPEN_TIME, System.currentTimeMillis()), broadcast);
                break;
            case 61:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_FILE_OPEN_TIME, System.currentTimeMillis()), broadcast);
                break;
            case 62:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_TEMP_OPEN_TIME, System.currentTimeMillis()), broadcast);
                break;
            case 63:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_FONT_OPEN_TIME, System.currentTimeMillis()), broadcast);
                break;
            case 64:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_STAMPPOS_OPEN_TIME, System.currentTimeMillis()), broadcast);
                break;
            case 65:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_3_TIME_NO_BUY, System.currentTimeMillis()), broadcast);
                break;
            case 66:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_3_TIME_NO_BUY_STAN, System.currentTimeMillis()), broadcast);
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + i);
        }
        alarmManager.setAlarmClock(alarmClockInfo, broadcast);
    }

    public void cancelAlarm(Context context, int i) {
        PendingIntent broadcast;
        Intent intent = new Intent(context, AlarmReceiver.class);
        if (Build.VERSION.SDK_INT >= 31) {
            broadcast = PendingIntent.getBroadcast(context, i, intent, 201326592);
        } else {
            broadcast = PendingIntent.getBroadcast(context, i, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        }
        ((AlarmManager) context.getSystemService(Context.ALARM_SERVICE)).cancel(broadcast);
    }
}