package com.live.gpsmap.camera.Fragment;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.live.gpsmap.camera.Activity.FolderActivity;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Default;
import com.live.gpsmap.camera.Utils.Helper.SingleClickListener;
import com.live.gpsmap.camera.Utils.Util;

import java.io.File;
import java.util.regex.Pattern;

public class FolderaddBottomsheetfragment extends BottomSheetDialogFragment {
    public static final String TAG = "FolderaddBottomsheetfragment";
    FolderActivity folderActivity;
    OnAddFolder onAddFolder;

    /* loaded from: classes2.dex */
    public interface OnAddFolder {
        void OnAdd(File file);
    }

    public void setOnAddFolder(OnAddFolder onAddFolder) {
        this.onAddFolder = onAddFolder;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.dialog_add_folder, viewGroup, false);
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(final View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        final EditText editText = (EditText) view.findViewById(R.id.edAddFolder);
        this.folderActivity = new FolderActivity();
        editText.addTextChangedListener(new TextWatcher() { // from class: com.gpsmapcamera.geotagginglocationonphoto.fragment.FolderaddBottomsheetfragment.1
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                if (charSequence.toString().length() == 30) {
                    Util.hideSoftKeyboard(FolderaddBottomsheetfragment.this.getActivity(), editText);
                    View view2 = view;
                    Snackbar.make(view2, "" + FolderaddBottomsheetfragment.this.getString(R.string.max_length_msg), BaseTransientBottomBar.LENGTH_INDEFINITE).show();
                }
            }
        });
        ((ImageView) view.findViewById(R.id.btn_close)).setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View view2) {
                editText.setText("");
            }
        });
        ((TextView) view.findViewById(R.id.tv_ok)).setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View view2) {
                String trim = editText.getText().toString().trim();
                if (Pattern.compile("^([a-zA-Z0-9][^*/><?\"|:]*)$").matcher(trim).matches()) {
                    File file = new File(Default.PARENT_FOLDER_PATH + trim);
                    if (!file.exists()) {
                        FolderaddBottomsheetfragment.this.onAddFolder.OnAdd(file);
                        FolderaddBottomsheetfragment.this.dismiss();
                        return;
                    }
                    View view3 = view;
                    Snackbar.make(view3, "" + FolderaddBottomsheetfragment.this.getString(R.string.dummy_folder_empty_msg), BaseTransientBottomBar.LENGTH_INDEFINITE).show();
                    return;
                }
                View view4 = view;
                Snackbar.make(view4, "" + FolderaddBottomsheetfragment.this.getString(R.string.add_folder_empty_msg), BaseTransientBottomBar.LENGTH_INDEFINITE).show();
            }
        });
    }
}