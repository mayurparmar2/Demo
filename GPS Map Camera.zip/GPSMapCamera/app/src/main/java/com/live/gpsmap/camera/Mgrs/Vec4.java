package com.live.gpsmap.camera.Mgrs;



/* loaded from: classes.dex */
public class Vec4 {
    private int hashCode;
    public final double w;
    public final double x;
    public final double y;
    public final double z;
    public static final Vec4 INFINITY = new Vec4(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, 0.0d);
    private static final double DEFAULT_W = 1.0d;
    public static final Vec4 ZERO = new Vec4(0.0d, 0.0d, 0.0d, DEFAULT_W);
    public static final Vec4 ONE = new Vec4(DEFAULT_W, DEFAULT_W, DEFAULT_W, DEFAULT_W);
    public static final Vec4 UNIT_X = new Vec4(DEFAULT_W, 0.0d, 0.0d, 0.0d);
    public static final Vec4 UNIT_NEGATIVE_X = new Vec4(-1.0d, 0.0d, 0.0d, 0.0d);
    public static final Vec4 UNIT_Y = new Vec4(0.0d, DEFAULT_W, 0.0d, 0.0d);
    public static final Vec4 UNIT_NEGATIVE_Y = new Vec4(0.0d, -1.0d, 0.0d, 0.0d);
    public static final Vec4 UNIT_Z = new Vec4(0.0d, 0.0d, DEFAULT_W, 0.0d);
    public static final Vec4 UNIT_NEGATIVE_Z = new Vec4(0.0d, 0.0d, -1.0d, 0.0d);
    public static final Vec4 UNIT_W = new Vec4(0.0d, 0.0d, 0.0d, DEFAULT_W);
    public static final Vec4 UNIT_NEGATIVE_W = new Vec4(0.0d, 0.0d, 0.0d, -1.0d);

    public Vec4(double d) {
        this(d, d, d);
    }

    public Vec4(double d, double d2) {
        this(d, d2, 0.0d, DEFAULT_W);
    }

    public Vec4(double d, double d2, double d3) {
        this(d, d2, d3, DEFAULT_W);
    }

    public Vec4(double d, double d2, double d3, double d4) {
        this.x = d;
        this.y = d2;
        this.z = d3;
        this.w = d4;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        Vec4 vec4 = (Vec4) obj;
        return this.x == vec4.x && this.y == vec4.y && this.z == vec4.z && this.w == vec4.w;
    }

    public final int hashCode() {
        if (this.hashCode == 0) {
            long doubleToLongBits = Double.doubleToLongBits(this.x);
            long doubleToLongBits2 = Double.doubleToLongBits(this.y);
            long doubleToLongBits3 = Double.doubleToLongBits(this.z);
            long doubleToLongBits4 = Double.doubleToLongBits(this.w);
            this.hashCode = (((((((int) (doubleToLongBits ^ (doubleToLongBits >>> 32))) * 29) + ((int) (doubleToLongBits2 ^ (doubleToLongBits2 >>> 32)))) * 29) + ((int) (doubleToLongBits3 ^ (doubleToLongBits3 >>> 32)))) * 29) + ((int) ((doubleToLongBits4 >>> 32) ^ doubleToLongBits4));
        }
        return this.hashCode;
    }

    public static Vec4 fromDoubleArray(double[] dArr, int i, int i2) {
        if (dArr != null) {
            if (i >= 0) {
                if (i2 < 1) {
                    throw new IllegalArgumentException("Length Is Invalid");
                }
                if (dArr.length >= i + i2) {
                    if (i2 == 1) {
                        return new Vec4(dArr[i], 0.0d);
                    }
                    if (i2 == 2) {
                        return new Vec4(dArr[i], dArr[i + 1]);
                    }
                    if (i2 == 3) {
                        return new Vec4(dArr[i], dArr[i + 1], dArr[i + 2]);
                    }
                    return new Vec4(dArr[i], dArr[i + 1], dArr[i + 2], dArr[i + 3]);
                }
                throw new IllegalArgumentException("Array Invalid Length");
            }
            throw new IllegalArgumentException("Offset Is Invalid");
        }
        throw new IllegalArgumentException("Array Is Null");
    }

    public static Vec4 fromFloatArray(float[] fArr, int i, int i2) {
        if (fArr != null) {
            if (i >= 0) {
                if (i2 < 1) {
                    throw new IllegalArgumentException("Length Is Invalid");
                }
                if (fArr.length >= i + i2) {
                    if (i2 == 2) {
                        return new Vec4(fArr[i], fArr[i + 1], 0.0d);
                    }
                    if (i2 == 3) {
                        return new Vec4(fArr[i], fArr[i + 1], fArr[i + 2]);
                    }
                    return new Vec4(fArr[i], fArr[i + 1], fArr[i + 2], fArr[i + 3]);
                }
                throw new IllegalArgumentException("Array Invalid Length");
            }
            throw new IllegalArgumentException("Offset Is Invalid");
        }
        throw new IllegalArgumentException("Array Is Null");
    }

    public static Vec4 fromArray2(double[] dArr, int i) {
        if (dArr != null) {
            return fromDoubleArray(dArr, i, 2);
        }
        throw new IllegalArgumentException("Array Is Null");
    }

    public static Vec4 fromArray3(double[] dArr, int i) {
        if (dArr != null) {
            return fromDoubleArray(dArr, i, 3);
        }
        throw new IllegalArgumentException("Array Is Null");
    }

    public static Vec4 fromArray4(double[] dArr, int i) {
        if (dArr != null) {
            return fromDoubleArray(dArr, i, 4);
        }
        throw new IllegalArgumentException("Array Is Null");
    }

    public final double[] toDoubleArray(double[] dArr, int i, int i2) {
        if (dArr != null) {
            if (i >= 0) {
                if (i2 < 1) {
                    throw new IllegalArgumentException("Length Is Invalid");
                }
                if (dArr.length >= i + i2) {
                    dArr[i] = this.x;
                    if (i2 > 1) {
                        dArr[i + 1] = this.y;
                    }
                    if (i2 > 2) {
                        dArr[i + 2] = this.z;
                    }
                    if (i2 > 3) {
                        dArr[i + 3] = this.w;
                    }
                    return dArr;
                }
                throw new IllegalArgumentException("Array Invalid Length");
            }
            throw new IllegalArgumentException("Offset Is Invalid");
        }
        throw new IllegalArgumentException("Array Is Null");
    }

    public final float[] toFloatArray(float[] fArr, int i, int i2) {
        if (fArr != null) {
            if (i >= 0) {
                if (i2 < 1) {
                    throw new IllegalArgumentException("Length Is Invalid");
                }
                if (fArr.length >= i + i2) {
                    fArr[i] = (float) this.x;
                    fArr[i + 1] = (float) this.y;
                    if (i2 > 2) {
                        fArr[i + 2] = (float) this.z;
                    }
                    if (i2 > 3) {
                        fArr[i + 3] = (float) this.w;
                    }
                    return fArr;
                }
                throw new IllegalArgumentException("Array Invalid Length");
            }
            throw new IllegalArgumentException("Offset Is Invalid");
        }
        throw new IllegalArgumentException("Array Is Null");
    }

    public final double[] toArray2(double[] dArr, int i) {
        if (dArr != null) {
            return toDoubleArray(dArr, i, 2);
        }
        throw new IllegalArgumentException("Array Is Null");
    }

    public final double[] toArray3(double[] dArr, int i) {
        if (dArr != null) {
            return toDoubleArray(dArr, i, 3);
        }
        throw new IllegalArgumentException("Array Is Null");
    }

    public final double[] toArray4(double[] dArr, int i) {
        if (dArr != null) {
            return toDoubleArray(dArr, i, 4);
        }
        throw new IllegalArgumentException("Array Is Null");
    }

    public Vec4 toHomogeneousPoint3() {
        return this.w == DEFAULT_W ? this : new Vec4(this.x, this.y, this.z, DEFAULT_W);
    }

    public Vec4 toHomogeneousDirection3() {
        return this.w == 0.0d ? this : new Vec4(this.x, this.y, this.z, 0.0d);
    }

    public final String toString() {
        return "(" + this.x + ", " + this.y + ", " + this.z + ", " + this.w + ")";
    }

    public final double getX() {
        return this.x;
    }

    public final double getY() {
        return this.y;
    }

    public final double getZ() {
        return this.z;
    }

    public final double getW() {
        return this.w;
    }

    public final double x() {
        return this.x;
    }

    public final double y() {
        return this.y;
    }

    public final double z() {
        return this.z;
    }

    public final double w() {
        return this.w;
    }

    public static Vec4 fromLine3(Vec4 vec4, double d, Vec4 vec42) {
        if (vec4 == null || vec42 == null) {
            throw new IllegalArgumentException("Vec4 Is Null");
        }
        return new Vec4(vec4.x + (vec42.x * d), vec4.y + (vec42.y * d), vec4.z + (vec42.z * d));
    }

    public final Vec4 add3(Vec4 vec4) {
        if (vec4 != null) {
            return new Vec4(this.x + vec4.x, this.y + vec4.y, this.z + vec4.z, this.w);
        }
        throw new IllegalArgumentException("Vec4 Is Null");
    }

    public final Vec4 add3(double d, double d2, double d3) {
        return new Vec4(this.x + d, this.y + d2, this.z + d3, this.w);
    }

    public final Vec4 subtract3(Vec4 vec4) {
        if (vec4 != null) {
            return new Vec4(this.x - vec4.x, this.y - vec4.y, this.z - vec4.z, this.w);
        }
        throw new IllegalArgumentException("Vec4 Is Null");
    }

    public final Vec4 subtract3(double d, double d2, double d3) {
        return new Vec4(this.x - d, this.y - d2, this.z - d3, this.w);
    }

    public final Vec4 multiply3(double d) {
        return new Vec4(this.x * d, this.y * d, this.z * d, this.w);
    }

    public final Vec4 multiply3(Vec4 vec4) {
        if (vec4 != null) {
            return new Vec4(this.x * vec4.x, this.y * vec4.y, this.z * vec4.z, this.w);
        }
        throw new IllegalArgumentException("Vec4 Is Null");
    }

    public final Vec4 divide3(double d) {
        if (d != 0.0d) {
            return new Vec4(this.x / d, this.y / d, this.z / d, this.w);
        }
        throw new IllegalArgumentException("Argument Out Of Range");
    }

    public final Vec4 divide3(Vec4 vec4) {
        if (vec4 != null) {
            return new Vec4(this.x / vec4.x, this.y / vec4.y, this.z / vec4.z, this.w);
        }
        throw new IllegalArgumentException("Vec4 Is Null");
    }

    public final Vec4 getNegative3() {
        return new Vec4(0.0d - this.x, 0.0d - this.y, 0.0d - this.z, this.w);
    }

    public final Vec4 getAbs3() {
        return new Vec4(Math.abs(this.x), Math.abs(this.y), Math.abs(this.z));
    }

    public final double getLength3() {
        return Math.sqrt(getLengthSquared3());
    }

    public final double getLengthSquared3() {
        double d = this.x;
        double d2 = this.y;
        double d3 = (d * d) + (d2 * d2);
        double d4 = this.z;
        return d3 + (d4 * d4);
    }

    public final Vec4 normalize3() {
        double length3 = getLength3();
        return length3 == 0.0d ? this : new Vec4(this.x / length3, this.y / length3, this.z / length3);
    }

    public final double distanceTo2(Vec4 vec4) {
        if (vec4 != null) {
            double d = vec4.x - this.x;
            double d2 = vec4.y - this.y;
            return Math.sqrt((d * d) + (d2 * d2));
        }
        throw new IllegalArgumentException("Vec4 Is Null");
    }

    public final double distanceTo3(Vec4 vec4) {
        if (vec4 != null) {
            return Math.sqrt(distanceToSquared3(vec4));
        }
        throw new IllegalArgumentException("Vec4 Is Null");
    }

    public final double distanceToSquared3(Vec4 vec4) {
        if (vec4 != null) {
            double d = this.x - vec4.x;
            double d2 = this.y - vec4.y;
            double d3 = (d * d) + 0.0d + (d2 * d2);
            double d4 = this.z - vec4.z;
            return d3 + (d4 * d4);
        }
        throw new IllegalArgumentException("Vec4 Is Null");
    }

    public final double dot3(Vec4 vec4) {
        if (vec4 != null) {
            return (this.x * vec4.x) + (this.y * vec4.y) + (this.z * vec4.z);
        }
        throw new IllegalArgumentException("Vec4 Is Null");
    }

    public final double dot4(Vec4 vec4) {
        if (vec4 != null) {
            return (this.x * vec4.x) + (this.y * vec4.y) + (this.z * vec4.z) + (this.w * vec4.w);
        }
        throw new IllegalArgumentException("Vec4 Is Null");
    }

    public final double dotSelf3() {
        return dot3(this);
    }

    public final double dotSelf4() {
        return dot4(this);
    }

    public final Vec4 cross3(Vec4 vec4) {
        if (vec4 != null) {
            double d = this.y;
            double d2 = vec4.z;
            double d3 = this.z;
            double d4 = vec4.y;
            double d5 = (d * d2) - (d3 * d4);
            double d6 = vec4.x;
            double d7 = this.x;
            return new Vec4(d5, (d3 * d6) - (d2 * d7), (d7 * d4) - (d * d6));
        }
        throw new IllegalArgumentException("Vec4 Is Null");
    }

    public final Angle angleBetween3(Vec4 vec4) {
        if (vec4 != null) {
            double dot3 = dot3(vec4);
            double length3 = getLength3() * vec4.getLength3();
            double d = DEFAULT_W;
            if (length3 != 0.0d && length3 != DEFAULT_W) {
                dot3 /= length3;
            }
            if (dot3 < -1.0d) {
                d = -1.0d;
            } else if (dot3 <= DEFAULT_W) {
                d = dot3;
            }
            return Angle.fromRadians(Math.acos(d));
        }
        throw new IllegalArgumentException("Vec4 Is Null");
    }

    public static Angle axisAngle(Vec4 vec4, Vec4 vec42, Vec4[] vec4Arr) {
        if (vec4 == null || vec42 == null) {
            throw new IllegalArgumentException("Vec4 Is Null");
        }
        if (vec4Arr != null) {
            Vec4 normalize3 = vec4.normalize3();
            Vec4 normalize32 = vec42.normalize3();
            Angle fromRadians = Angle.fromRadians(Math.acos((normalize32.x * normalize3.x) + (normalize32.y * normalize3.y) + (normalize32.z * normalize3.z)));
            double d = normalize32.y;
            double d2 = normalize3.z;
            double d3 = normalize32.z;
            double d4 = normalize3.y;
            double d5 = (d * d2) - (d3 * d4);
            double d6 = normalize3.x;
            double d7 = normalize32.x;
            double d8 = (d3 * d6) - (d2 * d7);
            double d9 = (d7 * d4) - (d * d6);
            double sqrt = Math.sqrt((d5 * d5) + (d8 * d8) + (d9 * d9));
            vec4Arr[0] = new Vec4(d5 / sqrt, d8 / sqrt, d9 / sqrt);
            return fromRadians;
        }
        throw new IllegalArgumentException("Array Is Null");
    }

    public final Vec4 projectOnto3(Vec4 vec4) {
        if (vec4 != null) {
            double dot3 = dot3(vec4);
            double length3 = vec4.getLength3();
            if (length3 != 0.0d && length3 != DEFAULT_W) {
                dot3 /= length3 * length3;
            }
            return vec4.multiply3(dot3);
        }
        throw new IllegalArgumentException("Vec4 Is Null");
    }

    public final Vec4 perpendicularTo3(Vec4 vec4) {
        if (vec4 != null) {
            return subtract3(projectOnto3(vec4));
        }
        throw new IllegalArgumentException("Vec4 Is Null");
    }

    public Vec4[] perpendicularVectors() {
        double d = this.x;
        double d2 = this.y;
        Vec4 normalize3 = cross3((d > d2 || d > this.z) ? (d2 > d || d2 > this.z) ? UNIT_Z : UNIT_Y : UNIT_X).normalize3();
        return new Vec4[]{normalize3, cross3(normalize3).normalize3()};
    }

    public final Vec4 transformBy3(Matrix matrix) {
        if (matrix != null) {
            return new Vec4((matrix.m11 * this.x) + (matrix.m12 * this.y) + (matrix.m13 * this.z), (matrix.m21 * this.x) + (matrix.m22 * this.y) + (matrix.m23 * this.z), (matrix.m31 * this.x) + (matrix.m32 * this.y) + (matrix.m33 * this.z));
        }
        throw new IllegalArgumentException("Matrix Is Null");
    }

    public final Vec4 transformBy3(Quaternion quaternion) {
        if (quaternion != null) {
            Quaternion multiply = quaternion.multiply(new Quaternion(this.x, this.y, this.z, 0.0d)).multiply(quaternion.getInverse());
            return new Vec4(multiply.x, multiply.y, multiply.z, 0.0d);
        }
        throw new IllegalArgumentException("Quaternion Is Null");
    }

    public final Vec4 transformBy4(Matrix matrix) {
        if (matrix != null) {
            return new Vec4((matrix.m11 * this.x) + (matrix.m12 * this.y) + (matrix.m13 * this.z) + (matrix.m14 * this.w), (matrix.m21 * this.x) + (matrix.m22 * this.y) + (matrix.m23 * this.z) + (matrix.m24 * this.w), (matrix.m31 * this.x) + (matrix.m32 * this.y) + (matrix.m33 * this.z) + (matrix.m34 * this.w), (matrix.m41 * this.x) + (matrix.m42 * this.y) + (matrix.m43 * this.z) + (matrix.m44 * this.w));
        }
        throw new IllegalArgumentException("Matrix Is Null");
    }

    public static Vec4 min3(Vec4 vec4, Vec4 vec42) {
        if (vec4 == null || vec42 == null) {
            throw new IllegalArgumentException("Vec4 Is Null");
        }
        double d = vec4.x;
        double d2 = vec42.x;
        double d3 = d < d2 ? d : d2;
        double d4 = vec4.y;
        double d5 = vec42.y;
        if (d4 >= d5) {
            d4 = d5;
        }
        double d6 = vec4.z;
        double d7 = vec42.z;
        if (d6 >= d7) {
            d6 = d7;
        }
        return new Vec4(d3, d4, d6);
    }

    public static Vec4 max3(Vec4 vec4, Vec4 vec42) {
        if (vec4 == null || vec42 == null) {
            throw new IllegalArgumentException("Vec4 Is Null");
        }
        double d = vec4.x;
        double d2 = vec42.x;
        double d3 = d > d2 ? d : d2;
        double d4 = vec4.y;
        double d5 = vec42.y;
        if (d4 <= d5) {
            d4 = d5;
        }
        double d6 = vec4.z;
        double d7 = vec42.z;
        if (d6 <= d7) {
            d6 = d7;
        }
        return new Vec4(d3, d4, d6);
    }

    public static Vec4 clamp3(Vec4 vec4, double d, double d2) {
        double d3;
        if (vec4 != null) {
            double d4 = vec4.x;
            double d5 = d4 < d ? d : d4 > d2 ? d2 : d4;
            double d6 = vec4.y;
            double d7 = d6 < d ? d : d6 > d2 ? d2 : d6;
            double d8 = vec4.z;
            if (d8 < d) {
                d3 = d;
            } else if (d8 > d2) {
                return new Vec4(d5, d7, d2);
            } else {
                d3 = d8;
            }
            return new Vec4(d5, d7, d3);
        }
        throw new IllegalArgumentException("Vec4 Is Null");
    }

    public static Vec4 mix3(double d, Vec4 vec4, Vec4 vec42) {
        if (vec4 == null || vec42 == null) {
            throw new IllegalArgumentException("Vec4 Is Null");
        }
        if (d < 0.0d) {
            return vec4;
        }
        if (d > DEFAULT_W) {
            return vec42;
        }
        double d2 = DEFAULT_W - d;
        return new Vec4((vec4.x * d2) + (vec42.x * d), (vec4.y * d2) + (vec42.y * d), (vec4.z * d2) + (vec42.z * d));
    }

    public static Vec4 computeAveragePoint(Iterable<? extends Vec4> iterable) {
        if (iterable != null) {
            int i = 0;
            double d = 0.0d;
            double d2 = 0.0d;
            double d3 = 0.0d;
            double d4 = 0.0d;
            for (Vec4 vec4 : iterable) {
                if (vec4 != null) {
                    i++;
                    d += vec4.x;
                    d2 += vec4.y;
                    d3 += vec4.z;
                    d4 += vec4.w;
                }
            }
            if (i == 0) {
                return null;
            }
            double d5 = i;
            Double.isNaN(d5);
            Double.isNaN(d5);
            Double.isNaN(d5);
            Double.isNaN(d5);
            return new Vec4(d / d5, d2 / d5, d3 / d5, d4 / d5);
        }
        throw new IllegalArgumentException("Point List Is Null");
    }

    public static double getAverageDistance(Iterable<? extends Vec4> iterable) {
        if (iterable != null) {
            int i = 0;
            double d = 0.0d;
            for (Vec4 vec4 : iterable) {
                for (Vec4 vec42 : iterable) {
                    if (vec4 != vec42) {
                        d += vec4.distanceTo3(vec42);
                        i++;
                    }
                }
            }
            if (i == 0) {
                return 0.0d;
            }
            double d2 = i;
            Double.isNaN(d2);
            return d / d2;
        }
        throw new IllegalArgumentException("Point List Is Null");
    }

    public static Vec4[] computeExtrema(Vec4[] vec4Arr) {
        if (vec4Arr == null) {
            throw new IllegalArgumentException("Points Array Is Null");
        }
        if (vec4Arr.length == 0) {
            return null;
        }
        Vec4 vec4 = vec4Arr[0];
        double d = vec4.x;
        double d2 = vec4.y;
        double d3 = vec4.z;
        double d4 = d3;
        double d5 = d2;
        double d6 = d;
        for (int i = 1; i < vec4Arr.length; i++) {
            Vec4 vec42 = vec4Arr[i];
            double d7 = vec42.x;
            if (d7 > d6) {
                d6 = d7;
            } else if (d7 < d) {
                d = d7;
            }
            double d8 = vec42.y;
            if (d8 > d5) {
                d5 = d8;
            } else if (d8 < d2) {
                d2 = d8;
            }
            double d9 = vec42.z;
            if (d9 > d4) {
                d4 = d9;
            } else if (d9 < d3) {
                d3 = d9;
            }
        }
        return new Vec4[]{new Vec4(d, d2, d3), new Vec4(d6, d5, d4)};
    }

    public static boolean areColinear(Vec4 vec4, Vec4 vec42, Vec4 vec43) {
        if (vec4 == null || vec42 == null || vec43 == null) {
            throw new IllegalArgumentException("Vec4 Is Null");
        }
        return Math.abs(vec42.subtract3(vec4).normalize3().dot3(vec43.subtract3(vec42).normalize3())) > 0.999d;
    }
}
