package com.live.gpsmap.camera.Camera.preview.camerasurface;

import android.graphics.Matrix;
import android.media.MediaRecorder;
import android.view.View;
import com.live.gpsmap.camera.Camera.cameracontroller.CameraController;

/* loaded from: classes3.dex */
public interface CameraSurface {
    View getView();

    void onPause();

    void onResume();

    void setPreviewDisplay(CameraController cameraController);

    void setTransform(Matrix matrix);

    void setVideoRecorder(MediaRecorder mediaRecorder);
}
