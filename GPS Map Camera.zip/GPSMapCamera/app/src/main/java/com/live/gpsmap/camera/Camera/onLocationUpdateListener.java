package com.live.gpsmap.camera.Camera;

import android.location.Location;


public interface onLocationUpdateListener {
    void setOnLocationUpdate(Location location);
}
