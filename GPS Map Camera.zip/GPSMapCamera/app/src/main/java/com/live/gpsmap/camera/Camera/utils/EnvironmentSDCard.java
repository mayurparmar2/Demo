package com.live.gpsmap.camera.Camera.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.util.Log;
import androidx.core.content.ContextCompat;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
@SuppressWarnings("All")
public class EnvironmentSDCard {
    private static final String TAG = "EnvironmentSDCard";
    public static final String TYPE_INTERNAL = "intern";
    public static final String TYPE_PRIMARY = "primär";
    public static final String TYPE_SD = "MicroSD";
    public static final String TYPE_UNKNOWN = "unbekannt";
    public static final String TYPE_USB = "USB";
    public static final String WRITE_APPONLY = "apponly";
    public static final String WRITE_FULL = "readwrite";
    public static final String WRITE_NONE = "none";
    public static final String WRITE_READONLY = "readonly";
//    private static Device[] devices = null;
//    private static Device[] externalstorage = null;
    private static BroadcastReceiver receiver = null;
//    private static Device[] storage = null;
    private static boolean useReceiver = true;
    private static String userDir;

//    public static Device[] getDevices(Context context) {
//        if (devices == null) {
//            initDevices(context);
//        }
//        return devices;
//    }
//
//    public static Device[] getExternalStorage(Context context) {
//        if (devices == null) {
//            initDevices(context);
//        }
//        return externalstorage;
//    }
//
//    public static Device[] getStorage(Context context) {
//        if (devices == null) {
//            initDevices(context);
//        }
//        return storage;
//    }
//
    public static boolean isSDCardAvailable(Context context) {
        File[] externalFilesDirs = ContextCompat.getExternalFilesDirs(context, null);
        return (externalFilesDirs.length <= 1 || externalFilesDirs[0] == null || externalFilesDirs[1] == null) ? false : true;
    }
//
//    public static IntentFilter getRescanIntentFilter() {
//        IntentFilter intentFilter = new IntentFilter();
//        intentFilter.addAction("android.intent.action.MEDIA_BAD_REMOVAL");
//        intentFilter.addAction("android.intent.action.MEDIA_MOUNTED");
//        intentFilter.addAction("android.intent.action.MEDIA_REMOVED");
//        intentFilter.addAction("android.intent.action.MEDIA_SHARED");
//        intentFilter.addDataScheme("file");
//        return intentFilter;
//    }
//
//    public static void setUseReceiver(Context context, boolean z) {
//        BroadcastReceiver broadcastReceiver;
//        if (z && receiver == null) {
//            BroadcastReceiver broadcastReceiver2 = new BroadcastReceiver() { // from class: com.live.gpsmap.camera.Camera.utils.EnvironmentSDCard.1
//                @Override // android.content.BroadcastReceiver
//                public void onReceive(Context context2, Intent intent) {
//                    Log.i(EnvironmentSDCard.TAG, "Storage " + intent.getAction() + "-" + intent.getData());
//                    EnvironmentSDCard.initDevices(context2);
//                }
//            };
//            receiver = broadcastReceiver2;
//            context.registerReceiver(broadcastReceiver2, getRescanIntentFilter());
//        } else if (!z && (broadcastReceiver = receiver) != null) {
//            context.unregisterReceiver(broadcastReceiver);
//            receiver = null;
//        }
//        useReceiver = z;
//    }
//
//    public static void initDevices(Context context) {
//        if (userDir == null) {
//            userDir = "/Android/data/" + context.getPackageName();
//        }
//        setUseReceiver(context, useReceiver);
//        StorageManager storageManager = (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
//        try {
//            Object[] objArr = (Object[]) storageManager.getClass().getMethod("getVolumeList", null).invoke(storageManager, null);
//            int length = objArr.length;
//            Device[] deviceArr = new Device[length];
//            for (int i = 0; i < objArr.length; i++) {
//                deviceArr[i] = new Device(objArr[i]);
//            }
//            Device device = null;
//            for (int i2 = 0; i2 < length; i2++) {
//                Device device2 = deviceArr[i2];
//                if (device2.mPrimary) {
//                    device = device2;
//                }
//            }
//            if (device == null) {
//                int i3 = 0;
//                while (true) {
//                    if (i3 >= length) {
//                        break;
//                    }
//                    Device device3 = deviceArr[i3];
//                    if (!device3.mRemovable) {
//                        device3.mPrimary = true;
//                        device = device3;
//                        break;
//                    }
//                    i3++;
//                }
//            }
//            if (device == null) {
//                device = deviceArr[0];
//                device.mPrimary = true;
//            }
//            File[] externalFilesDirs = ContextCompat.getExternalFilesDirs(context, null);
//            File[] externalCacheDirs = ContextCompat.getExternalCacheDirs(context);
//            for (int i4 = 0; i4 < length; i4++) {
//                Device device4 = deviceArr[i4];
//                if (externalFilesDirs != null) {
//                    for (File file : externalFilesDirs) {
//                        if (file != null && file.getAbsolutePath().startsWith(device4.getAbsolutePath())) {
//                            device4.mFiles = file;
//                        }
//                    }
//                }
//                if (externalCacheDirs != null) {
//                    for (File file2 : externalCacheDirs) {
//                        if (file2 != null && file2.getAbsolutePath().startsWith(device4.getAbsolutePath())) {
//                            device4.mCache = file2;
//                        }
//                    }
//                }
//            }
//            ArrayList arrayList = new ArrayList(10);
//            ArrayList arrayList2 = new ArrayList(10);
//            ArrayList arrayList3 = new ArrayList(10);
//            for (int i5 = 0; i5 < length; i5++) {
//                Device device5 = deviceArr[i5];
//                arrayList.add(device5);
//                if (device5.isAvailable()) {
//                    arrayList3.add(device5);
//                    arrayList2.add(device5);
//                }
//            }
//            Device device6 = new Device(context);
//            arrayList2.add(0, device6);
//            if (!device.mEmulated) {
//                arrayList.add(0, device6);
//            }
//            devices = (Device[]) arrayList.toArray(new Device[arrayList.size()]);
//            storage = (Device[]) arrayList2.toArray(new Device[arrayList2.size()]);
//            externalstorage = (Device[]) arrayList3.toArray(new Device[arrayList3.size()]);
//        } catch (Exception unused) {
//        }
//    }
//    public static class Device extends File {
//        boolean mAllowMassStorage;
//        File mCache;
//        boolean mEmulated;
//        File mFiles;
//        long mMaxFileSize;
//        boolean mPrimary;
//        boolean mRemovable;
//        String mState;
//        String mType;
//        String mUserLabel;
//        String mUuid;
//        String mWriteState;
//
//        Device(Context context0) {
//            super(Environment.getDataDirectory().getAbsolutePath());
//            this.mState = "mounted";
//            this.mFiles = context0.getFilesDir();
//            this.mCache = context0.getCacheDir();
//            this.mType = "intern";
//            this.mWriteState = "apponly";
//        }
//
//        Device(Object object0) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
//            super(((String)object0.getClass().getMethod("getPath", null).invoke(object0, null)));
//            Method[] arr_method = object0.getClass().getMethods();
//            int v;
//            for(v = 0; v < arr_method.length; ++v) {
//                Method method0 = arr_method[v];
//                if((method0.getName().equals("getUserLabel")) && method0.getParameterTypes().length == 0 && method0.getReturnType() == String.class) {
//                    this.mUserLabel = (String)method0.invoke(object0, null);
//                }
//
//                if((method0.getName().equals("getUuid")) && method0.getParameterTypes().length == 0 && method0.getReturnType() == String.class) {
//                    this.mUuid = (String)method0.invoke(object0, null);
//                }
//
//                if((method0.getName().equals("getState")) && method0.getParameterTypes().length == 0 && method0.getReturnType() == String.class) {
//                    this.mState = (String)method0.invoke(object0, null);
//                }
//
//                if((method0.getName().equals("isRemovable")) && method0.getParameterTypes().length == 0 && method0.getReturnType() == Boolean.TYPE) {
//                    this.mRemovable = ((Boolean)method0.invoke(object0, null)).booleanValue();
//                }
//
//                if((method0.getName().equals("isPrimary")) && method0.getParameterTypes().length == 0 && method0.getReturnType() == Boolean.TYPE) {
//                    this.mPrimary = ((Boolean)method0.invoke(object0, null)).booleanValue();
//                }
//
//                if((method0.getName().equals("isEmulated")) && method0.getParameterTypes().length == 0 && method0.getReturnType() == Boolean.TYPE) {
//                    this.mEmulated = ((Boolean)method0.invoke(object0, null)).booleanValue();
//                }
//
//                if((method0.getName().equals("allowMassStorage")) && method0.getParameterTypes().length == 0 && method0.getReturnType() == Boolean.TYPE) {
//                    this.mAllowMassStorage = ((Boolean)method0.invoke(object0, null)).booleanValue();
//                }
//
//                if((method0.getName().equals("getMaxFileSize")) && method0.getParameterTypes().length == 0 && method0.getReturnType() == Long.TYPE) {
//                    this.mMaxFileSize = (long)(((Long)method0.invoke(object0, null)));
//                }
//            }
//
//            if(this.mState == null) {
//                this.mState = this.getState();
//            }
//
//            if(this.mPrimary) {
//                this.mType = "primär";
//                return;
//            }
//
//            String s = this.getAbsolutePath().toLowerCase();
//            if(s.indexOf("sd") > 0) {
//                this.mType = "MicroSD";
//                return;
//            }
//
//            if(s.indexOf("usb") > 0) {
//                this.mType = "USB";
//                return;
//            }
//
//            this.mType = "unbekannt " + this.getAbsolutePath();
//        }
//
//        public String getAccess() {
//            if(this.mWriteState == null) {
//                try {
//                    this.mWriteState = "none";
//                    File[] arr_file = this.listFiles();
//                    if(arr_file != null && arr_file.length != 0) {
//                        this.mWriteState = "readonly";
//                        File.createTempFile("jow", null, this.getFilesDir()).delete();
//                        this.mWriteState = "apponly";
//                        File.createTempFile("jow", null, this).delete();
//                        this.mWriteState = "readwrite";
//                        return this.mWriteState;
//                    }
//
//                    throw new IOException("root empty/unreadable");
//                }
//                catch(IOException iOException0) {
//                    Log.v("EnvironmentSDCard", "test " + this.getAbsolutePath() + " ->" + this.mWriteState + "<- " + iOException0.getMessage());
//                }
//            }
//
//            return this.mWriteState;
//        }
//
//        public File getCacheDir() {
//            if(this.mCache == null) {
//                File file0 = new File(this, EnvironmentSDCard.userDir + "/cache");
//                this.mCache = file0;
//                if(!file0.isDirectory()) {
//                    this.mCache.mkdirs();
//                }
//            }
//
//            return this.mCache;
//        }
//
//        public File getFilesDir() {
//            if(this.mFiles == null) {
//                File file0 = new File(this, EnvironmentSDCard.userDir + "/files");
//                this.mFiles = file0;
//                if(!file0.isDirectory()) {
//                    this.mFiles.mkdirs();
//                }
//            }
//
//            return this.mFiles;
//        }
//
//        public long getMaxFileSize() {
//            return this.mMaxFileSize;
//        }
//
//        public String getState() {
//            if((this.mRemovable) || this.mState == null) {
//                if(Build.VERSION.SDK_INT >= 21) {
//                    this.mState = Environment.getExternalStorageState(this);
//                    return this.mState;
//                }
//
//                if(Build.VERSION.SDK_INT >= 19) {
//                    this.mState = Environment.getStorageState(this);
//                    return this.mState;
//                }
//
//                if((this.canRead()) && this.getTotalSpace() > 0L) {
//                    this.mState = "mounted";
//                    return this.mState;
//                }
//
//                if(this.mState == null || ("mounted".equals(this.mState))) {
//                    this.mState = "unknown";
//                }
//            }
//
//            return this.mState;
//        }
//
//        public String getType() {
//            return this.mType;
//        }
//
//        public String getUserLabel() {
//            return this.mUserLabel;
//        }
//
//        public String getUuid() {
//            return this.mUuid;
//        }
//
//        public boolean isAllowMassStorage() {
//            return this.mAllowMassStorage;
//        }
//
//        public boolean isAvailable() {
//            String s = this.getState();
//            return ("mounted".equals(s)) || ("mounted_ro".equals(s));
//        }
//
//        public boolean isEmulated() {
//            return this.mEmulated;
//        }
//
//        public boolean isPrimary() {
//            return this.mPrimary;
//        }
//
//        public boolean isRemovable() {
//            return this.mRemovable;
//        }
//    }

}
