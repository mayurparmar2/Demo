package com.live.gpsmap.camera.Camera.remotecontrol;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.util.Log;
import com.live.gpsmap.camera.Camera.CameraMainActivity;
import com.live.gpsmap.camera.Camera.MyApplicationInterface;
import com.live.gpsmap.camera.Camera.PreferenceKeys;
import com.live.gpsmap.camera.Camera.ui.MainUI;


public class BluetoothRemoteControl {
    private static final String TAG = "BluetoothRemoteControl";
    private BluetoothLeService bluetoothLeService;
    private boolean is_connected;
    private final CameraMainActivity main_activity;
    private String remoteDeviceAddress;
    private String remoteDeviceType;
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            Log.d(BluetoothRemoteControl.TAG, "onServiceConnected");
            if (Build.VERSION.SDK_INT < 18) {
                return;
            }
            if (BluetoothRemoteControl.this.main_activity.isAppPaused()) {
                Log.d(BluetoothRemoteControl.TAG, "but app is now paused");
                return;
            }
            BluetoothRemoteControl.this.bluetoothLeService = ((BluetoothLeService.LocalBinder) iBinder).getService();
            if (!BluetoothRemoteControl.this.bluetoothLeService.initialize()) {
                Log.e(BluetoothRemoteControl.TAG, "Unable to initialize Bluetooth");
                BluetoothRemoteControl.this.stopRemoteControl();
            }
            BluetoothRemoteControl.this.bluetoothLeService.connect(BluetoothRemoteControl.this.remoteDeviceAddress);
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            Log.d(BluetoothRemoteControl.TAG, "onServiceDisconnected");
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (Build.VERSION.SDK_INT >= 18) {
                        BluetoothRemoteControl.this.bluetoothLeService.connect(BluetoothRemoteControl.this.remoteDeviceAddress);
                    }
                }
            }, 5000L);
        }
    };
    private final BroadcastReceiver remoteControlCommandReceiver = new BroadcastReceiver() { // from class: com.live.gpsmap.camera.Camera.remotecontrol.BluetoothRemoteControl.2
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (Build.VERSION.SDK_INT < 18) {
                return;
            }
            String action = intent.getAction();
            MyApplicationInterface applicationInterface = BluetoothRemoteControl.this.main_activity.getApplicationInterface();
            MainUI mainUI = BluetoothRemoteControl.this.main_activity.getMainUI();
            if (BluetoothLeService.ACTION_GATT_CONNECTED.equals(action)) {
                Log.d(BluetoothRemoteControl.TAG, "Remote connected");
                BluetoothRemoteControl.this.bluetoothLeService.setRemoteDeviceType(BluetoothRemoteControl.this.remoteDeviceType);
                BluetoothRemoteControl.this.main_activity.setBrightnessForCamera(false);
            } else if (BluetoothLeService.ACTION_GATT_DISCONNECTED.equals(action)) {
                Log.d(BluetoothRemoteControl.TAG, "Remote disconnected");
                BluetoothRemoteControl.this.is_connected = false;
                applicationInterface.getDrawPreview().onExtraOSDValuesChanged("-- °C", "-- m");
                mainUI.updateRemoteConnectionIcon();
                BluetoothRemoteControl.this.main_activity.setBrightnessToMinimumIfWanted();
                if (mainUI.isExposureUIOpen()) {
                    mainUI.toggleExposureUI();
                }
            } else if (BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED.equals(action)) {
                Log.d(BluetoothRemoteControl.TAG, "Remote services discovered");
                BluetoothRemoteControl.this.is_connected = true;
                mainUI.updateRemoteConnectionIcon();
            } else if (BluetoothLeService.ACTION_SENSOR_VALUE.equals(action)) {
                double doubleExtra = intent.getDoubleExtra(BluetoothLeService.SENSOR_TEMPERATURE, -1.0d);
                double round = Math.round((intent.getDoubleExtra(BluetoothLeService.SENSOR_DEPTH, -1.0d) / BluetoothRemoteControl.this.main_activity.getWaterDensity()) * 10.0d) / 10.0d;
                Log.d(BluetoothRemoteControl.TAG, "Sensor values: depth: " + round + " - temp: " + doubleExtra);
                StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(doubleExtra);
                sb.append(" °C");
                String sb2 = sb.toString();
                applicationInterface.getDrawPreview().onExtraOSDValuesChanged(sb2, "" + round + " m");
            } else if (BluetoothLeService.ACTION_REMOTE_COMMAND.equals(action)) {
                int intExtra = intent.getIntExtra(BluetoothLeService.EXTRA_DATA, -1);
                if (intExtra == 16) {
                    if (mainUI.popupIsOpen()) {
                        mainUI.togglePopupSettings();
                    } else if (mainUI.isExposureUIOpen()) {
                        mainUI.toggleExposureUI();
                    } else {
                        BluetoothRemoteControl.this.main_activity.clickedSwitchVideo(null);
                    }
                } else if (intExtra == 32) {
                    BluetoothRemoteControl.this.main_activity.takePicture(false);
                } else if (intExtra == 48) {
                    if (!mainUI.popupIsOpen()) {
                        if (!mainUI.isExposureUIOpen()) {
                            mainUI.toggleExposureUI();
                            return;
                        } else {
                            mainUI.commandMenuExposure();
                            return;
                        }
                    }
                    mainUI.commandMenuPopup();
                } else if (intExtra == 64) {
                    if (mainUI.processRemoteUpButton()) {
                        return;
                    }
                    if (BluetoothRemoteControl.this.main_activity.getPreview().getCurrentFocusValue() != null && BluetoothRemoteControl.this.main_activity.getPreview().getCurrentFocusValue().equals("focus_mode_manual2")) {
                        BluetoothRemoteControl.this.main_activity.changeFocusDistance(-25, false);
                    } else {
                        BluetoothRemoteControl.this.main_activity.zoomIn();
                    }
                } else if (intExtra != 80) {
                    if (intExtra != 97) {
                        return;
                    }
                    mainUI.togglePopupSettings();
                } else if (mainUI.processRemoteDownButton()) {
                } else {
                    if (BluetoothRemoteControl.this.main_activity.getPreview().getCurrentFocusValue() != null && BluetoothRemoteControl.this.main_activity.getPreview().getCurrentFocusValue().equals("focus_mode_manual2")) {
                        BluetoothRemoteControl.this.main_activity.changeFocusDistance(25, false);
                    } else {
                        BluetoothRemoteControl.this.main_activity.zoomOut();
                    }
                }
            } else {
                Log.d(BluetoothRemoteControl.TAG, "Other remote event");
            }
        }
    };

    public BluetoothRemoteControl(CameraMainActivity mainActivity) {
        this.main_activity = mainActivity;
    }

    public boolean remoteConnected() {
        return this.is_connected;
    }

    private static IntentFilter makeRemoteCommandIntentFilter() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
        intentFilter.addAction(BluetoothLeService.ACTION_REMOTE_COMMAND);
        intentFilter.addAction(BluetoothLeService.ACTION_SENSOR_VALUE);
        return intentFilter;
    }

    public void startRemoteControl() {
        Log.d(TAG, "BLE Remote control service start check...");
        if (Build.VERSION.SDK_INT < 18) {
            return;
        }
        Intent intent = new Intent(this.main_activity, BluetoothLeService.class);
        if (!this.main_activity.isAppPaused() && remoteEnabled()) {
            Log.d(TAG, "Remote enabled, starting service");
            this.main_activity.bindService(intent, this.mServiceConnection, Context.BIND_AUTO_CREATE);
            this.main_activity.registerReceiver(this.remoteControlCommandReceiver, makeRemoteCommandIntentFilter());
            return;
        }
        Log.d(TAG, "Remote disabled, stopping service");
        try {
            this.main_activity.unregisterReceiver(this.remoteControlCommandReceiver);
            this.main_activity.unbindService(this.mServiceConnection);
            this.is_connected = false;
            this.main_activity.getMainUI().updateRemoteConnectionIcon();
        } catch (IllegalArgumentException unused) {
            Log.d(TAG, "Remote Service was not running, that's fine");
        }
    }

    public void stopRemoteControl() {
        Log.d(TAG, "BLE Remote control service shutdown...");
        if (remoteEnabled()) {
            try {
                this.main_activity.unregisterReceiver(this.remoteControlCommandReceiver);
                this.main_activity.unbindService(this.mServiceConnection);
                this.is_connected = false;
                this.main_activity.getMainUI().updateRemoteConnectionIcon();
            } catch (IllegalArgumentException e) {
                Log.e(TAG, "Remote Service was not running, that's strange");
                e.printStackTrace();
            }
        }
    }

    public boolean remoteEnabled() {
        if (Build.VERSION.SDK_INT < 18) {
            return false;
        }
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.main_activity);
        boolean z = defaultSharedPreferences.getBoolean(PreferenceKeys.EnableRemote, false);
        this.remoteDeviceType = defaultSharedPreferences.getString(PreferenceKeys.RemoteType, "undefined");
        String string = defaultSharedPreferences.getString(PreferenceKeys.RemoteName, "undefined");
        this.remoteDeviceAddress = string;
        return z && !string.equals("undefined");
    }
}
