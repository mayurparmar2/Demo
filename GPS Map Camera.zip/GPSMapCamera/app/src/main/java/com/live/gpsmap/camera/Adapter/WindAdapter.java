package com.live.gpsmap.camera.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.live.gpsmap.camera.Interface.OnRecyclerItemClickListener;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.SP;
import com.live.gpsmap.camera.Utils.Util;

public class WindAdapter extends RecyclerView.Adapter<WindAdapter.Holder> {
    Context mContext;
    String[] mList;
    OnRecyclerItemClickListener mOnRecyclerItemClickListener;
    SP mSP;
    int selected_pos;
    int type;

    public WindAdapter(Context context, String[] strArr, int i, OnRecyclerItemClickListener onRecyclerItemClickListener) {
        this.type = 0;
        this.mContext = context;
        this.mList = strArr;
        this.mOnRecyclerItemClickListener = onRecyclerItemClickListener;
        SP sp = new SP(this.mContext);
        this.mSP = sp;
        this.type = i;
        if (i == 1) {
            this.selected_pos = sp.getInteger(context, "wind_postion", 0);
        } else if (i == 2) {
            this.selected_pos = sp.getInteger(context, "pressure_postion", 0);
        } else if (i == 3) {
            this.selected_pos = sp.getInteger(context, "altitude_position", 0);
        } else if (i == 4) {
            this.selected_pos = sp.getInteger(context, "accuracy_position", 0);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(viewGroup.getContext()).inflate(com.live.gpsmap.camera.R.layout.cell_date_time_adapter, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(Holder holder, int i) {
        int i2 = this.type;
        if (i2 == 1) {
            holder.tv_dateFormat.setText(Util.getwindConvert(this.mContext, i));
        } else if (i2 == 2) {
            holder.tv_dateFormat.setText(Util.getpressureConvert(this.mContext, i));
        } else if (i2 == 3) {
            holder.tv_dateFormat.setText(Util.getAltitudeconvert(this.mContext, i));
        } else if (i2 == 4) {
            holder.tv_dateFormat.setText(Util.getAccuracy(this.mContext, i));
        }
        if (this.selected_pos == i) {
            holder.img_selection.setVisibility(View.VISIBLE);
        } else {
            holder.img_selection.setVisibility(View.GONE);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.mList.length;
    }

    /* loaded from: classes2.dex */
    public class Holder extends RecyclerView.ViewHolder {
        LinearLayout date_main_lay;
        ImageView img_selection;
        TextView tv_dateFormat;

        public Holder(View view) {
            super(view);
            this.tv_dateFormat = (TextView) view.findViewById(R.id.tv_temp_name);
            this.date_main_lay = (LinearLayout) view.findViewById(R.id.dt_main_lay);
            this.img_selection = (ImageView) view.findViewById(R.id.img_selection);
            this.date_main_lay.setOnClickListener(new View.OnClickListener() { // from class: com.gpsmapcamera.geotagginglocationonphoto.adapter.WindAdapter.Holder.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    if (Holder.this.getAdapterPosition() < 0 || WindAdapter.this.mOnRecyclerItemClickListener == null) {
                        return;
                    }
                    WindAdapter.this.mOnRecyclerItemClickListener.OnClick_(Holder.this.getAdapterPosition(), view2);
                }
            });
        }
    }
}