package com.gpsvideocamera.videotimestamp.Fragment;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gpsvideocamera.videotimestamp.Adapter.GPSCoordinatesAdapter;
import com.live.gpsmap.camera.Interface.OnRecyclerItemClickListener;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import com.live.gpsmap.camera.R;


public class GPS_Coordinates_Fragment extends Fragment {
    OnLatLngListener callBack;
    private GPSCoordinatesAdapter mAdapter;
    String[] mGPS_Coordinates_array;
    private RecyclerView mRecyclerview;
    SP mSP;

    
    interface OnLatLngListener {
        void onLatLngType();
    }

    public void setOnLatLngListener(OnLatLngListener onLatLngListener) {
        this.callBack = onLatLngListener;
    }

    @Override 
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_template, viewGroup, false);
    }

    @Override 
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.mSP = new SP(getActivity());
        this.mRecyclerview = (RecyclerView) view.findViewById(R.id.fragment_recyclerview);
        this.mGPS_Coordinates_array = getResources().getStringArray(R.array.gps_coordinates_array);
        setAdapter();
    }

    private void setAdapter() {
        this.mRecyclerview.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        GPSCoordinatesAdapter gPSCoordinatesAdapter = new GPSCoordinatesAdapter(getContext(), this.mGPS_Coordinates_array, new OnRecyclerItemClickListener() { 
            @Override 
            public void OnLongClick_(int i, View view) {
            }

            @Override 
            public void OnClick_(final int i, View view) {
                GPS_Coordinates_Fragment.this.mSP.setInteger(GPS_Coordinates_Fragment.this.getContext(), "lat_lng_type_temp_1", Integer.valueOf(i));
                new Handler().postDelayed(new Runnable() { 
                    @Override 
                    public void run() {
                        if (GPS_Coordinates_Fragment.this.mAdapter != null) {
                            GPS_Coordinates_Fragment.this.mAdapter.refAdapter(i);
                        }
                        if (GPS_Coordinates_Fragment.this.callBack != null) {
                            GPS_Coordinates_Fragment.this.callBack.onLatLngType();
                        }
                    }
                }, 50);
            }
        });
        this.mAdapter = gPSCoordinatesAdapter;
        this.mRecyclerview.setAdapter(gPSCoordinatesAdapter);
    }
}
