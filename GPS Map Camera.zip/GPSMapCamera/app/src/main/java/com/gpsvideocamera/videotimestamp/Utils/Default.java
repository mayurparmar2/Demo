package com.gpsvideocamera.videotimestamp.Utils;

import android.os.Environment;


public class Default {
    public static int FILTERPOSITION = 0;


    public static final String AUTOMATIC = "Automatic";
    public static final String CUSTUM_NAME_1_VALUE = "ByGPSVideoCamera";
    public static final int DEFAULT_COLOR = -769226;
    public static final String DEFAULT_DATE_FORMAT = "dd/MM/yy hh:mm:ss a";
    public static final int DEFAULT_DATE_POS = 5;
    public static final String DEFAULT_FOLDER_NAME = "Default";
    public static final int DEFAULT_FONT_SIZE = 4;
    public static final int DEFAULT_FONT_SIZE_POS = 6;
    public static final int DEFAULT_LOC_POS = 4;
    public static final int DEFAULT_LOGO_POS = 1;
    public static final int DEFAULT_LOGO_SIZE = 15;
    public static final int DEFAULT_LOGO_TRANSPARENCY = 100;
    public static final int DEFAULT_SIGN_POS = 0;
    public static final String DEFULT_FONT = "Roboto Regular.ttf";
    public static final String HYBRID_4 = "hybrid";
    public static final String LANGUAGE = "English";
    public static final int LAT_LNG_TYPE = 1;
    public static final String MANUAL = "Manual";
    public static final String NORMAL_1 = "roadmap";
    public static final String SETELLITE_2 = "satellite";
    public static final String SITE_1 = "Site 1";
    public static final String SITE_2 = "Site 2";
    public static final int STAMP_BACKGROUND_COLOR_INDEX = 3;
    public static final int STAMP_COLOR_INDEX = 4;
    public static final int STAMP_INDEX = 0;
    public static final int STAMP_POSITION_INDEX = 5;
    public static final int STAMP_STYLE_INDEX = 2;
    public static final int STAM_SIZE_INDEX = 1;
    public static final String TERRAIN_3 = "terrain";
    public static final String CAMERA_FOLDER = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).toString() + "/Camera";
    public static final String DIR_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).toString() + "/";
    public static final String PARENT_FOLDER_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).toString() + "/GPS video camera/";
    public static final String DEFAULT_FOLDER_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).toString() + "/Camera";
    public static final Boolean IS_MAP = true;
    public static final Boolean IS_ADDRESS = true;
    public static final Boolean IS_LAT_LNG_TEMPLATE = true;
    public static final Boolean IS_WEATHER = false;
    public static final Boolean IS_MAGNETIC_FIELD = false;
    public static final Boolean IS_COMPASS = false;
    public static final Boolean IS_MAIN_DT_FILE = true;
    public static final Boolean IS_SEQUENCE_FILE = false;
    public static final Boolean IS_CUS_1 = true;
    public static final Boolean IS_CUS_2 = false;
    public static final Boolean IS_CUS_3 = false;
    public static final Boolean IS_LAT_LONG_FILE_NAME = false;
    public static final Boolean IS_MAIN_ADDRESS_FILE_NAME = false;
    public static final Boolean IS_DATE_TIME = true;
}
