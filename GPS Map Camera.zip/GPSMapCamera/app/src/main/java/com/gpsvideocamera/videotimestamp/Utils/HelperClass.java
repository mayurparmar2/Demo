package com.gpsvideocamera.videotimestamp.Utils;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.billingclient.api.Purchase;
import com.live.gpsmap.camera.Mgrs.Angle;
import com.live.gpsmap.camera.Mgrs.MGRSCoord;
import com.live.gpsmap.camera.R;
import com.otaliastudios.cameraview.size.AspectRatio;
import com.otaliastudios.cameraview.size.Size;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;


public class HelperClass {
    public static String COUNTADS = "counts_ads";
    public static String Client_id = "";
    public static String Client_secret = "";
    public static final int DECIMAL = 0;
    public static final int DEC_DEGS = 1;
    public static final int DEC_DEGS_MICRO = 2;
    public static final int DEC_MIN = 3;
    public static final int DEC_MIN_SEC = 5;
    public static final int DEG_MIN_SEC = 4;
    public static boolean IS_ADS = false;
    public static String IS_FROM_NOTIFICATION = "isfromnotification";
    public static String IS_FROM_NOTIFICATION_MESSAGE = "isfromnotificationmessage";
    public static String IS_FROM_NOTIFICATION_type = "isfromnotificationtype";
    public static String IS_PURCHESH_OR_NOT = "isPurcheshOrNot";
    public static final int MGRS_USNG = 7;
    public static final String PURCHASE_3_TIME_CLICK = "PURCHASE_3_TIME_CLICK";
    public static final String PURCHASE_3_TIME_SHOWN = "PURCHASE_3_TIME_SHOWN";
    public static String RATE = "rate";
    public static String Refersh_token = "";
    public static String SHARE = "share";
    public static final String TOTAL_TIME_APP_OPEN = "TOTAL_TIME_APP_OPEN";
    public static final int UTM = 6;
    public static String deviceConnectiontype = "Mobile";
    private static Typeface face = null;
    public static String grant_type = "";
    private static ProgressDialog mProgressDialog;
    public static ProgressDialog pDownloadDialog;
    public static List<Purchase> purchaseHistory;
    private static int rate;
    private static ImageView rate_main;
    private static TextView txt_rate;
    private static TextView txt_rate_message;
    private static TextView txt_rate_title;
    private static int val;
    static Boolean isInternetPresent = false;
    public static String KEY_NOTIFICATION = "notification";
    public static String KEY_NOTIFY_ME = "notify_me";
    public static String KEY_ID = "id";
    public static String KEY_COUNT = "appCount";
    public static String PATH_MAIN = Environment.getExternalStoragePublicDirectory("/DCIM/Camera/").getPath();
    public static ArrayList<String> f = new ArrayList<>();
    public static File[] listFile = null;
    public String web_url = "https://sites.google.com/view/allexcellentapps/home";
    AlertDialog alertSimpleDialog = null;

//    public void createRestartDialog(Activity activity) {
//    }

    public String setDateTimeFormat(Context context, int i) {
        return null;
    }
//
//    public void showSimpleDialog(Activity activity) {
//    }
//
//    public Boolean checkpackgename(Context context, String str) {
//        for (ApplicationInfo applicationInfo : context.getPackageManager().getInstalledApplications(PackageManager.GET_META_DATA)) {
//            if (str.equals(applicationInfo.packageName)) {
//                return true;
//            }
//        }
//        return false;
//    }

    public static Boolean check_internet(Context context) {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

//
//    public static void createDownloadDialog(Context context) {
//        ProgressDialog progressDialog = new ProgressDialog(context);
//        pDownloadDialog = progressDialog;
//        progressDialog.setTitle("Downloading...");
//        pDownloadDialog.setIndeterminate(false);
//        pDownloadDialog.setMax(100);
//        pDownloadDialog.setProgressStyle(1);
//        pDownloadDialog.setCancelable(false);
//    }
//
//    public static void setTypeface(Context context, TextView textView, String str) {
//        Typeface createFromAsset = Typeface.createFromAsset(context.getAssets(), str);
//        face = createFromAsset;
//        textView.setTypeface(createFromAsset);
//    }
//
//    public static void showSnackBar(View view, String str) {
//        Snackbar.make(view, "" + str, -Toast.LENGTH_LONG).show();
//    }
//
//    public static void showDialog(Context context, String str, String str2) {
//        AlertDialog.Builder builder = new AlertDialog.Builder(context);
//        builder.setTitle(str);
//        builder.setMessage(str2);
//        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialogInterface, int i) {
//                dialogInterface.dismiss();
//            }
//        });
//        builder.create().show();
//    }
//
//    public static Bitmap setWaterMarkImage(Context context, File file, int i, float f2, int i2) {
//        Bitmap bitmap;
//        StrictMode.ThreadPolicy allowThreadDiskReads = StrictMode.allowThreadDiskReads();
//        try {
//            if (file.exists()) {
//                FileInputStream fileInputStream = new FileInputStream(file);
//                bitmap = BitmapFactory.decodeStream(fileInputStream);
//                fileInputStream.close();
//                if (bitmap != null) {
//                    int i3 = (int) f2;
//                    bitmap = createNewIcon(bitmap, i3, i3);
//                }
//            } else {
//                bitmap = null;
//            }
//            Bitmap createBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
//            Canvas canvas = new Canvas(createBitmap);
//            Paint paint = new Paint();
//            paint.setAlpha(i);
//            canvas.drawBitmap(bitmap, 0.0f, 0.0f, paint);
//            return createBitmap;
//        } catch (IOException unused) {
//            return null;
//        } finally {
//            StrictMode.setThreadPolicy(allowThreadDiskReads);
//        }
//    }

    public String getLatLong(Context context, int i) {
        char c;
        SP sp = new SP(context);
        String string = sp.getString(context, SP.LATITUDE, "");
        String string2 = sp.getString(context, SP.LONGITUDE, "");
        Double.valueOf((double) 0.0d);
        Double.valueOf((double) 0.0d);
        if (string != null && !string.isEmpty() && string2 != null && !string2.isEmpty()) {
            if (string.contains(",")) {
                string = string.replace(",", ".");
            }
            if (string2.contains(",")) {
                string2 = string2.replace(",", ".");
            }
            Double valueOf = Double.valueOf(string);
            Double valueOf2 = Double.valueOf(string2);
            if (!(valueOf.doubleValue() == 0.0d || valueOf2.doubleValue() == 0.0d)) {
                switch (i) {
                    case 0:
                        return "Lat " + string + " Long " + string2;
                    case 1:
                        return "Lat " + (string + "°") + " Long " + (string2 + "°");
                    case 2:
                        return "Lat " + (string + " " + (valueOf.doubleValue() >= 0.0d ? 'N' : 'S')) + " Long " + (string2 + " " + (valueOf2.doubleValue() >= 0.0d ? 'E' : 'W'));
                    case 3:
                        return "Lat " + replaceDelimins(Location.convert(valueOf.doubleValue(), Location.FORMAT_MINUTES), 8) + " Long " + replaceDelimins(Location.convert(valueOf2.doubleValue(), Location.FORMAT_MINUTES), 8);
                    case 4:
                        String replaceDelimiters = replaceDelimiters(Location.convert(valueOf.doubleValue(), Location.FORMAT_SECONDS), 8);
                        String str = (valueOf.doubleValue() >= 0.0d ? 'N' : 'S') + " " + replaceDelimiters;
                        String replaceDelimiters2 = replaceDelimiters(Location.convert(valueOf2.doubleValue(), Location.FORMAT_SECONDS), 8);
                        return "Lat " + str + " Long " + ((valueOf2.doubleValue() >= 0.0d ? 'E' : 'W') + " " + replaceDelimiters2);
                    case 5:
                        String str2 = replaceDelimiterss(Location.convert(valueOf.doubleValue(), Location.FORMAT_SECONDS), 8) + " " + (valueOf.doubleValue() >= 0.0d ? 'N' : 'S');
                        String convert = Location.convert(valueOf2.doubleValue(), Location.FORMAT_SECONDS);
                        char c2 = valueOf2.doubleValue() >= 0.0d ? 'E' : 'W';
                        return "Lat " + str2 + " Long " + (replaceDelimiterss(convert, 8) + " " + c2);
                    case 6:
                        int floor = (int) Math.floor((valueOf2.doubleValue() / 6.0d) + 31.0d);
                        if (valueOf.doubleValue() < -72.0d) {
                            c = 'C';
                        } else if (valueOf.doubleValue() < -64.0d) {
                            c = 'D';
                        } else if (valueOf.doubleValue() < -56.0d) {
                            c = 'E';
                        } else if (valueOf.doubleValue() < -48.0d) {
                            c = 'F';
                        } else if (valueOf.doubleValue() < -40.0d) {
                            c = 'G';
                        } else if (valueOf.doubleValue() < -32.0d) {
                            c = 'H';
                        } else if (valueOf.doubleValue() < -24.0d) {
                            c = 'J';
                        } else if (valueOf.doubleValue() < -16.0d) {
                            c = 'K';
                        } else if (valueOf.doubleValue() < -8.0d) {
                            c = 'L';
                        } else if (valueOf.doubleValue() < 0.0d) {
                            c = 'M';
                        } else if (valueOf.doubleValue() < 8.0d) {
                            c = 'N';
                        } else if (valueOf.doubleValue() < 16.0d) {
                            c = 'P';
                        } else if (valueOf.doubleValue() < 24.0d) {
                            c = 'Q';
                        } else if (valueOf.doubleValue() < 32.0d) {
                            c = 'R';
                        } else if (valueOf.doubleValue() < 40.0d) {
                            c = 'S';
                        } else if (valueOf.doubleValue() < 48.0d) {
                            c = 'T';
                        } else if (valueOf.doubleValue() < 56.0d) {
                            c = 'U';
                        } else if (valueOf.doubleValue() < 64.0d) {
                            c = 'V';
                        } else {
                            c = valueOf.doubleValue() < 72.0d ? 'W' : 'X';
                        }
                        double d = (((double) ((floor * 6) - 183)) * 3.141592653589793d) / 180.0d;
                        double round = ((double) Math.round(((((((Math.log(((Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) * Math.sin(((valueOf2.doubleValue() * 3.141592653589793d) / 180.0d) - d)) + 1.0d) / (1.0d - (Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) * Math.sin(((valueOf2.doubleValue() * 3.141592653589793d) / 180.0d) - d)))) * 0.5d) * 0.9996d) * 6399593.62d) / Math.pow((Math.pow(0.0820944379d, 2.0d) * Math.pow(Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d), 2.0d)) + 1.0d, 0.5d)) * (((((Math.pow(0.0820944379d, 2.0d) / 2.0d) * Math.pow(Math.log(((Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) * Math.sin(((valueOf2.doubleValue() * 3.141592653589793d) / 180.0d) - d)) + 1.0d) / (1.0d - (Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) * Math.sin(((valueOf2.doubleValue() * 3.141592653589793d) / 180.0d) - d)))) * 0.5d, 2.0d)) * Math.pow(Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d), 2.0d)) / 3.0d) + 1.0d)) + 500000.0d) * 100.0d)) * 0.01d;
                        double atan = (((((Math.atan(Math.tan((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) / Math.cos(((valueOf2.doubleValue() * 3.141592653589793d) / 180.0d) - d)) - ((valueOf.doubleValue() * 3.141592653589793d) / 180.0d)) * 0.9996d) * 6399593.625d) / Math.sqrt((Math.pow(Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d), 2.0d) * 0.006739496742d) + 1.0d)) * ((Math.pow(Math.log(((Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) * Math.sin(((valueOf2.doubleValue() * 3.141592653589793d) / 180.0d) - d)) + 1.0d) / (1.0d - (Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) * Math.sin(((valueOf2.doubleValue() * 3.141592653589793d) / 180.0d) - d)))) * 0.5d, 2.0d) * 0.003369748371d * Math.pow(Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d), 2.0d)) + 1.0d)) + ((((((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) - ((((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) + (Math.sin(((valueOf.doubleValue() * 2.0d) * 3.141592653589793d) / 180.0d) / 2.0d)) * 0.005054622556d)) + (((((((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) + (Math.sin(((valueOf.doubleValue() * 2.0d) * 3.141592653589793d) / 180.0d) / 2.0d)) * 3.0d) + (Math.sin(((valueOf.doubleValue() * 2.0d) * 3.141592653589793d) / 180.0d) * Math.pow(Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d), 2.0d))) * 4.258201531E-5d) / 4.0d)) - ((((((((((valueOf.doubleValue() * 3.141592653589793d) / 180.0d) + (Math.sin(((valueOf.doubleValue() * 2.0d) * 3.141592653589793d) / 180.0d) / 2.0d)) * 3.0d) + (Math.sin(((valueOf.doubleValue() * 2.0d) * 3.141592653589793d) / 180.0d) * Math.pow(Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d), 2.0d))) * 5.0d) / 4.0d) + ((Math.sin(((valueOf.doubleValue() * 2.0d) * 3.141592653589793d) / 180.0d) * Math.pow(Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d), 2.0d)) * Math.pow(Math.cos((valueOf.doubleValue() * 3.141592653589793d) / 180.0d), 2.0d))) * 1.674057895E-7d) / 3.0d)) * 6397033.7875500005d);
                        if (c < 'M') {
                            atan += 1.0E7d;
                        }
                        double round2 = ((double) Math.round(atan * 100.0d)) * 0.01d;
                        char c3 = valueOf.doubleValue() >= 0.0d ? 'N' : 'S';
                        String str3 = round + " " + c3;
                        return floor + "" + c + "   Long " + (String.valueOf(round2) + " " + (valueOf2.doubleValue() >= 0.0d ? 'E' : 'W')) + "  Lat " + str3;
                    case 7:
                        String mGRSCoord = MGRSCoord.fromLatLon(Angle.fromDegrees(valueOf.doubleValue()), Angle.fromDegrees(valueOf2.doubleValue())).toString();
                        String[] split = mGRSCoord.split(" ");
                        if (split.length > 2) {
                            return split[0] + " LatLong " + split[1] + " " + split[2];
                        }
                        return "LatLong " + mGRSCoord;
                }
            }
        }
        return null;
    }

    private static String replaceDelimins(String str, int i) {
        String replaceFirst = str.replaceFirst(":", "");
        int indexOf = replaceFirst.indexOf(".") + 1 + i;
        return indexOf < replaceFirst.length() ? replaceFirst.substring(0, indexOf) : replaceFirst;
    }

//    private static Bitmap createNewIcon(Bitmap bitmap, int i, int i2) {
//        Matrix matrix = new Matrix();
//        matrix.setRectToRect(new RectF(0.0f, 0.0f, (float) bitmap.getWidth(), (float) bitmap.getHeight()), new RectF(0.0f, 0.0f, (float) i, (float) i2), Matrix.ScaleToFit.CENTER);
//        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
//    }
//
//    public static void reportBug(Context context, String str, String str2, String str3, boolean z) {
//        PackageInfo packageInfo;
//        String str4;
//        int i;
//        int i2 = 0;
//        String str5;
//        Context context2;
//        Intent intent = null;
//        try {
//            packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
//        } catch (PackageManager.NameNotFoundException e) {
//            e.printStackTrace();
//            packageInfo = null;
//        }
//        if (packageInfo != null) {
//            try {
//                str4 = packageInfo.versionName;
//            } catch (Exception unused) {
//                str4 = "";
//            }
//        } else {
//            str4 = "1.0";
//        }
//        if (packageInfo != null) {
//            try {
//                i2 = packageInfo.versionCode;
//            } catch (Exception unused2) {
//                i = 0;
//            }
//        } else {
//            i2 = 1;
//        }
//        i = i2;
//        String str6 = Build.MANUFACTURER + " " + Build.MODEL;
//        String str7 = Build.VERSION.RELEASE;
//        int i3 = Build.VERSION.SDK_INT;
//        try {
//            str5 = new Locale("", ((TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE)).getNetworkCountryIso()).getDisplayCountry();
//        } catch (Exception e2) {
//            e2.printStackTrace();
//            str5 = "";
//        }
//        String str8 = str2 + ":" + context.getResources().getString(R.string.app_name);
//        StringBuilder sb = new StringBuilder(IOUtils.LINE_SEPARATOR_UNIX);
//        SP sp = new SP(context);
//        boolean booleanValue = sp.getBoolean(context, SP.IS_MAP, Default.IS_MAP).booleanValue();
//        boolean booleanValue2 = sp.getBoolean(context, SP.IS_ADDRESS, Default.IS_ADDRESS).booleanValue();
//        boolean booleanValue3 = sp.getBoolean(context, SP.IS_LAT_LNG_TEMPLATE, Default.IS_LAT_LNG_TEMPLATE).booleanValue();
//        boolean booleanValue4 = sp.getBoolean(context, SP.IS_WEATHER, Default.IS_WEATHER).booleanValue();
//        boolean booleanValue5 = sp.getBoolean(context, SP.IS_DATE_TIME, Default.IS_DATE_TIME).booleanValue();
//        boolean booleanValue6 = sp.getBoolean(context, SP.IS_MAGNETIC_FIELD, Default.IS_MAGNETIC_FIELD).booleanValue();
//        boolean booleanValue7 = sp.getBoolean(context, SP.IS_COMPASS, Default.IS_COMPASS).booleanValue();
//        boolean booleanValue8 = sp.getBoolean(context, SP.COMPASS_FOUND, false).booleanValue();
//        String string = sp.getString(context, SP.DATE_FORMAT, Default.DEFAULT_DATE_FORMAT);
//        int intValue = sp.getInteger(context, SP.LAT_LNG_TYPE, 1).intValue();
//        String str9 = "Your Message\n==========================\n" + str3 + "\n\nApp Information -\n==========================\nVersion : " + str4 + "(" + i + ")\nisMap : " + booleanValue + "\nisAddress : " + booleanValue2 + "\nisLatLng : " + booleanValue3 + "\nisWeather : " + booleanValue4 + "\nisDateTime : " + booleanValue5 + "\nisMagneticField : " + booleanValue6 + "\nisCompass : " + booleanValue7 + "\nisCompassFound : " + booleanValue8 + "\nDate Format : " + string + "\nTemprature Type : " + sp.getString(context, SP.TEMPRATURE_TYPE, "Celsius") + "\nTemprature_value : " + sp.getFloat(context, SP.TEMPRETURE_VALUE) + "\nLatLng Type : " + intValue + "\nLatitude : " + sp.getString(context, SP.LATITUDE, "") + "\nLongitude : " + sp.getString(context, SP.LONGITUDE, "") + "\nAddress Line 1 : " + sp.getString(context, SP.LOC_LINE_1_ADDRESS, "").trim() + "\nCity : " + sp.getString(context, SP.LOC_LINE_2_CITY, "").trim() + "\nState : " + sp.getString(context, SP.LOC_LINE_3_STATE, "").trim() + "\nCountry Address : " + sp.getString(context, SP.LOC_LINE_4_COUNTRY, "").trim() + IOUtils.LINE_SEPARATOR_UNIX + ((Object) sb) + "\n\nDevice Information-\n==========================\nDevice Name : " + str6 + "\nAndroid API : " + i3 + "\nAndroid Version : " + str7 + "\nCountry : " + str5 + IOUtils.LINE_SEPARATOR_UNIX;
//        try {
//            intent = new Intent("android.intent.action.SEND");
//            intent.setType("message/rfc822");
//            intent.putExtra("android.intent.extra.EMAIL", new String[]{"" + str});
//            intent.putExtra("android.intent.extra.SUBJECT", str8);
//            intent.putExtra("android.intent.extra.TEXT", str9);
//            context2 = context;
//        } catch (ActivityNotFoundException unused3) {
//            context2 = context;
//        }
//        try {
//            context2.startActivity(Intent.createChooser(intent, context2.getString(R.string.email_choose_from_client)));
//        } catch (ActivityNotFoundException unused4) {
//            showDialog(context2, "", context.getResources().getString(R.string.email_no_client));
//        }
//    }
//
//    public static void shareApp(Context context) {
//        Intent intent = new Intent("android.intent.action.SEND");
//        intent.setType("text/plain");
//        intent.putExtra("android.intent.extra.SUBJECT", context.getResources().getString(R.string.app_name));
//        intent.putExtra("android.intent.extra.TEXT", (context.getResources().getString(R.string.app_name) + "\n\n" + context.getString(R.string.share_app_desc)) + IOUtils.LINE_SEPARATOR_UNIX + context.getString(R.string.share_link));
//        context.startActivity(Intent.createChooser(intent, context.getResources().getString(R.string.share_intentName)));
//    }
//
//    public static void showSayThanksDialog(final Context context) {
//        val = 0;
//        try {
//            final View inflate = View.inflate(context, R.layout.dialog_say_thanks, null);
//            final AlertDialog create = new AlertDialog.Builder(context).setView(inflate).setCancelable(true).create();
//            Button button = (Button) inflate.findViewById(R.id.btn_rate_now);
//            Button button2 = (Button) inflate.findViewById(R.id.btn_later);
//            final ImageView imageView = (ImageView) inflate.findViewById(R.id.star1);
//            final ImageView imageView2 = (ImageView) inflate.findViewById(R.id.star2);
//            final ImageView imageView3 = (ImageView) inflate.findViewById(R.id.star3);
//            final ImageView imageView4 = (ImageView) inflate.findViewById(R.id.star4);
//            final ImageView imageView5 = (ImageView) inflate.findViewById(R.id.star5);
//            rate_main = (ImageView) inflate.findViewById(R.id.img_gif);
//            txt_rate = (TextView) inflate.findViewById(R.id.txt_rate);
//            txt_rate_title = (TextView) inflate.findViewById(R.id.txt_rate_title);
//            txt_rate_message = (TextView) inflate.findViewById(R.id.txt_rate_message);
//            Glide.with(context).asGif().load(Integer.valueOf((int) R.drawable.hand)).into(rate_main);
//            imageView.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    imageView.setImageResource(R.drawable.ic_star_fill);
//                    imageView2.setImageResource(R.drawable.non_fillstar);
//                    imageView3.setImageResource(R.drawable.non_fillstar);
//                    imageView4.setImageResource(R.drawable.non_fillstar);
//                    imageView5.setImageResource(R.drawable.non_fillstar);
//                    HelperClass.val = 1;
//                    HelperClass.rate = 1;
//                    HelperClass.chngeVal();
//                    HelperClass.txt_rate.setText(context.getResources().getString(R.string.hated_it));
//                }
//            });
//            imageView2.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    imageView.setImageResource(R.drawable.ic_star_fill);
//                    imageView2.setImageResource(R.drawable.ic_star_fill);
//                    imageView3.setImageResource(R.drawable.non_fillstar);
//                    imageView4.setImageResource(R.drawable.non_fillstar);
//                    imageView5.setImageResource(R.drawable.non_fillstar);
//                    HelperClass.val = 1;
//                    HelperClass.rate = 2;
//                    HelperClass.chngeVal();
//                    HelperClass.txt_rate.setText(context.getResources().getString(R.string.dislike_it));
//                }
//            });
//            imageView3.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Utils.HelperClass.4
//                @Override // android.view.View.OnClickListener
//                public void onClick(View view) {
//                    imageView.setImageResource(R.drawable.ic_star_fill);
//                    imageView2.setImageResource(R.drawable.ic_star_fill);
//                    imageView3.setImageResource(R.drawable.ic_star_fill);
//                    imageView4.setImageResource(R.drawable.non_fillstar);
//                    imageView5.setImageResource(R.drawable.non_fillstar);
//                    HelperClass.val = 1;
//                    HelperClass.rate = 3;
//                    HelperClass.chngeVal();
//                    HelperClass.txt_rate.setText(context.getResources().getString(R.string.its_ok));
//                }
//            });
//            imageView4.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Utils.HelperClass.5
//                @Override // android.view.View.OnClickListener
//                public void onClick(View view) {
//                    imageView.setImageResource(R.drawable.ic_star_fill);
//                    imageView2.setImageResource(R.drawable.ic_star_fill);
//                    imageView3.setImageResource(R.drawable.ic_star_fill);
//                    imageView4.setImageResource(R.drawable.ic_star_fill);
//                    imageView5.setImageResource(R.drawable.non_fillstar);
//                    HelperClass.val = 1;
//                    HelperClass.rate = 4;
//                    HelperClass.chngeVal();
//                    HelperClass.txt_rate.setText(context.getResources().getString(R.string.liked_it));
//                }
//            });
//            imageView5.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Utils.HelperClass.6
//                @Override // android.view.View.OnClickListener
//                public void onClick(View view) {
//                    imageView.setImageResource(R.drawable.ic_star_fill);
//                    imageView2.setImageResource(R.drawable.ic_star_fill);
//                    imageView3.setImageResource(R.drawable.ic_star_fill);
//                    imageView4.setImageResource(R.drawable.ic_star_fill);
//                    imageView5.setImageResource(R.drawable.ic_star_fill);
//                    HelperClass.val = 2;
//                    HelperClass.chngeVal();
//                    HelperClass.txt_rate.setText(context.getResources().getString(R.string.loved_it));
//                }
//            });
//            button.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Utils.HelperClass.7
//                @Override // android.view.View.OnClickListener
//                public void onClick(View view) {
//                    if (HelperClass.val == 2) {
//                        HelperClass.showRateDialog(context);
//                        create.dismiss();
//                    } else if (HelperClass.val == 1) {
//                        create.dismiss();
//                        new SP(context).setBoolean(context, HelperClass.RATE, true);
//                        create.dismiss();
//                        AlertDialog.Builder builder = new AlertDialog.Builder(context);
//                        builder.setMessage(context.getString(R.string.thanks_for_rate));
//                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Utils.HelperClass.7.1
//                            @Override // android.content.DialogInterface.OnClickListener
//                            public void onClick(DialogInterface dialogInterface, int i) {
//                                dialogInterface.dismiss();
//                            }
//                        });
//                        final AlertDialog create2 = builder.create();
//                        create2.setOnShowListener(new DialogInterface.OnShowListener() { // from class: com.gpsvideocamera.videotimestamp.Utils.HelperClass.7.2
//                            @Override // android.content.DialogInterface.OnShowListener
//                            public void onShow(DialogInterface dialogInterface) {
//                                create2.getButton(-1).setTextColor(context.getResources().getColor(R.color._0b2528));
//                                create2.getButton(-1).setBackgroundResource(R.drawable.black_ripple_custom);
//                            }
//                        });
//                        create2.show();
//                    } else {
//                        Snackbar.make(inflate, context.getString(R.string.rate_app_zero_star_error), -Toast.LENGTH_LONG).show();
//                    }
//                }
//            });
//            button2.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Utils.HelperClass.8
//                @Override // android.view.View.OnClickListener
//                public void onClick(View view) {
//                    create.dismiss();
//                }
//            });
//            create.show();
//        } catch (Exception unused) {
//        }
//    }
//
//    public static void hideSoftKeyboard(Activity activity, View view) {
//        ((InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(view.getWindowToken(), 0);
//    }

    public String dms_latlng(Context context) {
        SP sp = new SP(context);
        String string = sp.getString(context, SP.LATITUDE, "");
        String string2 = sp.getString(context, SP.LONGITUDE, "");
        Double.valueOf((double) 0.0d);
        Double.valueOf((double) 0.0d);
        if (string != null && !string.isEmpty() && string2 != null && !string2.isEmpty()) {
            Double valueOf = Double.valueOf(string);
            Double valueOf2 = Double.valueOf(string2);
            String replaceDelimiters = replaceDelimiters(Location.convert(valueOf.doubleValue(), 2), 8);
            String str = (valueOf.doubleValue() >= 0.0d ? 'N' : 'S') + " " + replaceDelimiters;
            String replaceDelimiters2 = replaceDelimiters(Location.convert(valueOf2.doubleValue(), 2), 8);
            string2 = (valueOf2.doubleValue() >= 0.0d ? 'E' : 'W') + " " + replaceDelimiters2;
            string = str;
        }
        return string + "_" + string2;
    }

    public static String getCelcius(float f2) {
        return "" + f2 + "° C";
    }

    public static String getFahrenheit(float f2) {
        return "" + (((Math.round(f2) * 9) / 5) + 32) + "° F";
    }

    private static String replaceDelimiterss(String str, int i) {
        String replaceFirst = str.replaceFirst(":", "").replaceFirst(":", "");
        int indexOf = replaceFirst.indexOf(".") + 1 + i;
        return indexOf < replaceFirst.length() ? replaceFirst.substring(0, indexOf) : replaceFirst;
    }

    private static String replaceDelimiters(String str, int i) {
        String replaceFirst = str.replaceFirst(":", "° ").replaceFirst(":", "' ");
        int indexOf = replaceFirst.indexOf(".") + 1 + i;
        if (indexOf < replaceFirst.length()) {
            replaceFirst = replaceFirst.substring(0, indexOf);
        }
        return replaceFirst + "\"";
    }

    public Integer setposratio(Context context, List<Size> list) {
        Integer i = 0;
        if (list != null) {
            int i2 = 20;
            for (int i3 = 0; i3 < list.size(); i3++) {
                if (getAspectRatioMPString(context.getResources(), list.get(i3).getWidth(), list.get(i3).getHeight(), true, 0).contains("4:3")) {
                    i2 = i3;
                }
            }
            i = i2;
        }
        return i == 20 ? list.size() - 1 : i;
    }

//
//    public static void chngeVal() {
//        rate_main.setVisibility(View.GONE);
//        txt_rate_title.setVisibility(View.GONE);
//        txt_rate.setVisibility(View.VISIBLE);
//        txt_rate_message.setVisibility(View.INVISIBLE);
//    }
//
//    public static void showRateDialog(final Context context) {
//        new SP(context).setBoolean(context, RATE, true);
//        View inflate = View.inflate(context, R.layout.play_store_dialog, null);
//        final AlertDialog create = new AlertDialog.Builder(context).setView(inflate).setCancelable(true).create();
//        ((Button) inflate.findViewById(R.id.btn_rate_now)).setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Utils.HelperClass.9
//            @Override // android.view.View.OnClickListener
//            public void onClick(View view) {
//                create.dismiss();
//                try {
//                    Context context2 = context;
//                    context2.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + context.getPackageName())));
//                } catch (ActivityNotFoundException unused) {
//                    Context context3 = context;
//                    context3.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + context.getPackageName())));
//                }
//            }
//        });
//        ((Button) inflate.findViewById(R.id.btn_later)).setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Utils.HelperClass.10
//            @Override // android.view.View.OnClickListener
//            public void onClick(View view) {
//                create.dismiss();
//            }
//        });
//        create.show();
//    }
//    public static boolean isGpsEnable(Context context) {
//        try {
//            return ((LocationManager) context.getSystemService(Context.LOCATION_SERVICE)).isProviderEnabled("gps");
//        } catch (Exception unused) {
//            return false;
//        }
//    }
//
//    public int converfeet(float f2) {
//        double d = ((double) f2) * 39.370078d;
//        return ((int) (d - ((double) (((int) (d / 63360.0d)) * 63360)))) / 12;
//    }
//
//    public static void showProgressDialog(Context context, String str) {
//        try {
//            ProgressDialog progressDialog = new ProgressDialog(context);
//            mProgressDialog = progressDialog;
//            progressDialog.setMessage(str);
//            mProgressDialog.setCancelable(false);
//            ProgressDialog progressDialog2 = mProgressDialog;
//            if (progressDialog2 != null && !progressDialog2.isShowing()) {
//                mProgressDialog.show();
//            }
//        } catch (Exception unused) {
//        }
//    }

    public static void dismissProgressDialog() {
        try {
            ProgressDialog progressDialog = mProgressDialog;
            if (progressDialog != null && progressDialog.isShowing()) {
                mProgressDialog.dismiss();
                mProgressDialog = null;
            }
        } catch (Exception unused) {
        }
    }

    public static float getLogoSize(Activity activity) {
        int i;
        DisplayMetrics displayMetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int i2 = displayMetrics.heightPixels;
        int i3 = displayMetrics.widthPixels;
        int intValue = new SP(activity).getInteger(activity, SP.LOGO_SIZE, 15).intValue();
        if (i3 > i2) {
            i = (intValue * i2) / 100;
        } else {
            i = (intValue * i3) / 100;
        }
        return (float) ((int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_PX, (float) i, activity.getResources().getDisplayMetrics()));
    }
//
//
//
//    private void copyFile(Context context, String str) {
//        try {
//            InputStream open = context.getAssets().open(str);
//            FileOutputStream fileOutputStream = new FileOutputStream(context.getFilesDir() + "/font/" + str);
//            byte[] bArr = new byte[1024];
//            while (true) {
//                int read = open.read(bArr);
//                if (read != -1) {
//                    fileOutputStream.write(bArr, 0, read);
//                } else {
//                    open.close();
//                    fileOutputStream.flush();
//                    fileOutputStream.close();
//                    return;
//                }
//            }
//        } catch (IOException unused) {
//        }
//    }
//
//    public Typeface setTypefacefromassets(Context context, String str) {
//        return Typeface.createFromAsset(context.getAssets(), str);
//    }

    public static String setDateTimeFormat(String str) {
        String str2;
        Calendar instance = Calendar.getInstance();
        if (str.contains("ddth")) {
            str2 = addExtention(str);
        } else {
            str2 = new SimpleDateFormat(str, Locale.getDefault()).format(instance.getTime());
        }
        return str2.replace("am", "AM").replace("pm", "PM");
    }

    private static String addExtention(String str) {
        String str2;
        Calendar instance = Calendar.getInstance();
        String[] split = str.split("th");
        String format = new SimpleDateFormat(split[0], Locale.getDefault()).format(instance.getTime());
        char charAt = format.charAt(format.length() - 1);
        if (format.substring(format.length() - 2).equalsIgnoreCase("13") || format.equalsIgnoreCase("13") || format.substring(format.length() - 2).equalsIgnoreCase("12") || format.equalsIgnoreCase("12") || format.substring(format.length() - 2).equalsIgnoreCase("11") || format.equalsIgnoreCase("11")) {
            str2 = format + "th";
        } else if (charAt == '1') {
            str2 = format + "st";
        } else if (charAt == '2') {
            str2 = format + "nd";
        } else if (charAt == '3') {
            str2 = format + "rd";
        } else {
            str2 = format + "th";
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(split[1], Locale.getDefault());
        return str2 + simpleDateFormat.format(instance.getTime());
    }
//
//    public int addAlpha(int i, int i2) {
//        return ColorUtils.setAlphaComponent(i, Math.round((float) (i2 * 255)) / 100);
//    }
//
//    public void SetLanguage(Activity activity) {
//        Locale locale = new Locale(new SP(activity).getString(activity, SP.SELECTED_LANGUAGE, "en"));
//        Locale.setDefault(locale);
//        Configuration configuration = new Configuration();
//        configuration.locale = locale;
//        activity.getResources().updateConfiguration(configuration, activity.getResources().getDisplayMetrics());
//    }
//
//    public String setDateTime(String str) {
//        return new SimpleDateFormat(str, Locale.getDefault()).format(Calendar.getInstance().getTime());
//    }
//
//    public GradientDrawable drawCircle(int i) {
//        GradientDrawable gradientDrawable = new GradientDrawable();
//        gradientDrawable.setShape(GradientDrawable.RECTANGLE);
//        gradientDrawable.setCornerRadii(new float[]{10.0f, 10.0f, 10.0f, 10.0f, 10.0f, 10.0f, 10.0f, 10.0f});
//        gradientDrawable.setColor(i);
//        return gradientDrawable;
//    }
//
//    public Typeface getFontStyle(Context context, String str) {
//        File filesDir = context.getFilesDir();
//        File file = new File(filesDir, "font/" + str);
//        if (!file.exists()) {
//            return Typeface.createFromAsset(context.getResources().getAssets(), str);
//        }
//        try {
//            return Typeface.createFromFile(file);
//        } catch (Exception unused) {
//            return Typeface.createFromAsset(context.getResources().getAssets(), Default.DEFULT_FONT);
//        }
//    }
//
//    public int getDateFontSize(Context context) {
//        return new SP(context).getInteger(context, SP.DATE_SIZE, 6).intValue() + 4;
//    }
//
//    public int getLocFontSize(Context context) {
//        return new SP(context).getInteger(context, SP.LOCATION_SIZE, 6).intValue() + 4;
//    }
//
//    public int getSignFontSize(Context context) {
//        return new SP(context).getInteger(context, SP.SIGN_SIZE, 6).intValue() + 4;
//    }
//
    private static String getMPString(int i, int i2) {
        return formatFloatToString(((float) (i * i2)) / 1000000.0f) + "MP";
    }

    private static String formatFloatToString(float f2) {
        int i = (int) f2;
        if (f2 == ((float) i)) {
            return Integer.toString(i);
        }
        return String.format(Locale.getDefault(), "%.2f", Float.valueOf(f2));
    }

    private static String getBurstString(Resources resources, boolean z) {
        if (z) {
            return "";
        }
        return ", " + resources.getString(R.string.no_burst);
    }

    public static String getAspectRatioMPString(Resources resources, int i, int i2, boolean z, int i3) {
        if (i3 == 1) {
            return AspectRatio.of(i, i2).flip() + "|" + getMPString(i, i2) + getBurstString(resources, z);
        }
        return AspectRatio.of(i, i2).flip() + "";
    }

    public void setWatermarkLayoutParams(Activity activity, int i, LinearLayout linearLayout, RelativeLayout relativeLayout) {
        getLogoSize(activity);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-1, -2);
        if (i == 0) {
            layoutParams.addRule(10);
            linearLayout.setRotation(0.0f);
        } else if (i == 1) {
            layoutParams.addRule(12);
            linearLayout.setRotation(0.0f);
        }
        linearLayout.setLayoutParams(layoutParams2);
        relativeLayout.setLayoutParams(layoutParams);
    }
//
//    public void showKeyboard(Context context) {
//        ((InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE)).toggleSoftInput(2, 0);
//    }
//
//    public void closeKeyboard(Context context) {
//        ((InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE)).toggleSoftInput(1, 0);
//    }
}
