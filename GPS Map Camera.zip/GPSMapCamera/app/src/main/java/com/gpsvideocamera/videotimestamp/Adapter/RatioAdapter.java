package com.gpsvideocamera.videotimestamp.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.live.gpsmap.camera.Camera.onRecyclerClickListener;
import com.live.gpsmap.camera.R;
import com.gpsvideocamera.videotimestamp.Utils.HelperClass;
import com.live.gpsmap.camera.Utils.SP;
import com.otaliastudios.cameraview.CameraView;
import com.otaliastudios.cameraview.size.Size;

import java.util.List;


public class RatioAdapter extends RecyclerView.Adapter<RatioAdapter.MyViewHolder> {
    HelperClass helperClass = new HelperClass();
    Context mContext;
    onRecyclerClickListener mOnRecyclerClickListener;
    List<Size> mRatio_entries;
    SP mSP;
    int selctedPos;

    public RatioAdapter(Context context, CameraView cameraView, List<Size> list, onRecyclerClickListener onrecyclerclicklistener) {
        this.mContext = context;
        this.mRatio_entries = list;
        SP sp = new SP(context);
        this.mSP = sp;
        this.mOnRecyclerClickListener = onrecyclerclicklistener;
        this.selctedPos = sp.getInteger(context, SP.getRatioPos_Key(cameraView.getCameraId()), this.helperClass.setposratio(context, list));
    }

    public void refreshAdapter(int i) {
        this.selctedPos = i;
        notifyDataSetChanged();
    }

    @Override 
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_ratio_dialog, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, @SuppressLint("RecyclerView") final int i) {
        if (myViewHolder instanceof MyViewHolder) {
            myViewHolder.tv_ratio.setText(HelperClass.getAspectRatioMPString(this.mContext.getResources(), this.mRatio_entries.get(i).getWidth(), this.mRatio_entries.get(i).getHeight(), true, 0) + " ");
            if (this.selctedPos == i) {
                myViewHolder.main_layout.setBackground(this.mContext.getResources().getDrawable(R.drawable.select_circle_back));
            } else {
                myViewHolder.main_layout.setBackground(this.mContext.getResources().getDrawable(R.drawable.unselected_circle_back));
            }
            myViewHolder.main_layout.setOnClickListener(new View.OnClickListener() { 
                @Override 
                public void onClick(View view) {
                    if (RatioAdapter.this.mOnRecyclerClickListener != null) {
                        RatioAdapter.this.mOnRecyclerClickListener.setOnItemClickListener(i, view);
                    }
                }
            });
        }
    }

    @Override 
    public int getItemCount() {
        return this.mRatio_entries.size();
    }

    
    public class MyViewHolder extends RecyclerView.ViewHolder {
        LinearLayout main_layout;
        TextView tv_ratio;

        public MyViewHolder(View view) {
            super(view);
            this.tv_ratio = (TextView) view.findViewById(R.id.tv_value);
            this.main_layout = (LinearLayout) view.findViewById(R.id.lin_click);
        }
    }
}
