package com.gpsvideocamera.videotimestamp.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import com.gpsvideocamera.videotimestamp.Model.PostionModel;
import com.live.gpsmap.camera.R;

import java.util.ArrayList;


public class FunactionalAdapter extends RecyclerView.Adapter<FunactionalAdapter.FunactionalViewHolder> {
    ArrayList<PostionModel> Timer_list;
    Context context;
    Onselected onselected;


    public interface Onselected {
        void Onsetlect(PostionModel postionModel, int i);
    }

    public void setOnselected(Onselected onselected) {
        this.onselected = onselected;
    }

    public FunactionalAdapter(Context context, ArrayList<PostionModel> arrayList) {
        new ArrayList();
        this.context = context;
        this.Timer_list = arrayList;
    }

    @Override 
    public FunactionalViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {


        return new FunactionalViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_ratio_dialog, viewGroup, false));
    }

    public void onBindViewHolder(FunactionalViewHolder funactionalViewHolder, @SuppressLint("RecyclerView") final int i) {
        final PostionModel postionModel = this.Timer_list.get(i);
        if (postionModel.getSelected() == 1) {
            funactionalViewHolder.btn_click.setBackground(this.context.getResources().getDrawable(R.drawable.select_circle_back));
        } else {
            funactionalViewHolder.btn_click.setBackground(this.context.getResources().getDrawable(R.drawable.unselected_circle_back));
        }
        funactionalViewHolder.txt_size.setText(postionModel.getPostion());
        funactionalViewHolder.btn_click.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public void onClick(View view) {
                FunactionalAdapter.this.onselected.Onsetlect(postionModel, i);
            }
        });
    }

    @Override 
    public int getItemCount() {
        return this.Timer_list.size();
    }

    public void refrecedata(ArrayList<PostionModel> arrayList) {
        this.Timer_list = arrayList;
        notifyDataSetChanged();
    }

    
    
    public class FunactionalViewHolder extends RecyclerView.ViewHolder {
        LinearLayout btn_click;
        TextView txt_size;

        public FunactionalViewHolder(View view) {
            super(view);
            this.txt_size = (TextView) view.findViewById(R.id.tv_value);
            this.btn_click = (LinearLayout) view.findViewById(R.id.lin_click);
        }
    }
}
