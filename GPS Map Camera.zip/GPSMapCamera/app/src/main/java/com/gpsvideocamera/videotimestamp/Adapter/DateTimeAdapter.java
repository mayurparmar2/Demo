package com.gpsvideocamera.videotimestamp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.gpsvideocamera.videotimestamp.Utils.Default;
import com.gpsvideocamera.videotimestamp.Utils.HelperClass;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import com.live.gpsmap.camera.Interface.OnRecyclerItemClickListener;
import com.live.gpsmap.camera.R;


public class DateTimeAdapter extends RecyclerView.Adapter<DateTimeAdapter.Holder> {
    Context mContext;
    String[] mList;
    OnRecyclerItemClickListener mOnRecyclerItemClickListener;
    SP mSP;
    String selected_pos;

    public DateTimeAdapter(Context context, String[] strArr, OnRecyclerItemClickListener onRecyclerItemClickListener) {
        this.mContext = context;
        this.mList = strArr;
        this.mOnRecyclerItemClickListener = onRecyclerItemClickListener;
        SP sp = new SP(this.mContext);
        this.mSP = sp;
        this.selected_pos = sp.getString(this.mContext, "date_format_temp", Default.DEFAULT_DATE_FORMAT);
    }

    @Override 
    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_date_time2, viewGroup, false));
    }

    public void onBindViewHolder(Holder holder, int i) {
        holder.tv_dateFormat.setText(HelperClass.setDateTimeFormat(this.mList[i]));
        if (this.mList[i].equals(this.selected_pos)) {
            holder.img_selection.setImageResource(R.drawable.ic_radiobtn);
        } else {
            holder.img_selection.setImageResource(R.drawable.ic_radio_btn_white);
        }
    }

    @Override 
    public int getItemCount() {
        return this.mList.length;
    }

    public void refAdapter(String str) {
        this.selected_pos = str;
        notifyDataSetChanged();
    }

    
    public class Holder extends RecyclerView.ViewHolder {
        LinearLayout date_main_lay;
        ImageView img_selection;
        TextView tv_dateFormat;

        public Holder(View view) {
            super(view);
            this.tv_dateFormat = (TextView) view.findViewById(R.id.tv_temp_name);
            this.date_main_lay = (LinearLayout) view.findViewById(R.id.dt_main_lay);
            this.img_selection = (ImageView) view.findViewById(R.id.img_selection);
            this.date_main_lay.setOnClickListener(new View.OnClickListener() {
                @Override 
                public void onClick(View view2) {
                    if (Holder.this.getAdapterPosition() >= 0 && DateTimeAdapter.this.mOnRecyclerItemClickListener != null) {
                        DateTimeAdapter.this.mOnRecyclerItemClickListener.OnClick_(Holder.this.getAdapterPosition(), view2);
                    }
                }
            });
        }
    }
}
