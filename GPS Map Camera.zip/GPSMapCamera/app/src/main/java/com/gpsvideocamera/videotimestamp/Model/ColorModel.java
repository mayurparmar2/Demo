package com.gpsvideocamera.videotimestamp.Model;


public class ColorModel {
    int color;
    String spKey;
    String title;

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public int getColor() {
        return this.color;
    }

    public void setColor(int i) {
        this.color = i;
    }

    public String getSpKey() {
        return this.spKey;
    }

    public void setSpKey(String str) {
        this.spKey = str;
    }
}
