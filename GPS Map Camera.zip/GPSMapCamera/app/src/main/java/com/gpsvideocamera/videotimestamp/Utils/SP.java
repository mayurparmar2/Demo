package com.gpsvideocamera.videotimestamp.Utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.StrictMode;
import android.preference.PreferenceManager;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.gpsvideocamera.videotimestamp.Model.ViewModel;

import java.util.ArrayList;
import java.util.List;


public class SP {
    public static final String ADDRESS_COLOR = "ADDRESS_COLOR";
    public static final String ADDRESS_INDEX = "address_index";
    public static final String ADS_STATUS = "ads_status";
    public static final String ALARM_TIME_100_PHOTOS = "alarm_time_100_photos";
    public static final String ALARM_TIME_10_TIMES_OPEN = "alarm_time_10_times_open";
    public static final String ALARM_TIME_15_DAYS = "alarm_time_15_days";
    public static final String ALARM_TIME_2ND_DAY = "alarm_time_2nd_day";
    public static final String ALARM_TIME_3_TIME_NO_BUY = "alarm_time_3_time_no_buy";
    public static final String ALARM_TIME_3_TIME_NO_BUY_STAN = "alarm_time_3_time_no_buy_stan";
    public static final String ALARM_TIME_45_PHOTOS = "alarm_time_45_photos";
    public static final String ALARM_TIME_500_PHOTOS = "alarm_time_500_photos";
    public static final String ALARM_TIME_50_PHOTOS_PRO = "alarm_time_50_photos_pro";
    public static final String ALARM_TIME_CAMSET_OPEN_TIME = "alarm_time_camset_open_time";
    public static final String ALARM_TIME_FILE_OPEN_TIME = "alarm_time_file_open_time";
    public static final String ALARM_TIME_FOLD_OPEN_TIME = "alarm_time_fold_open_time";
    public static final String ALARM_TIME_FONT_OPEN_TIME = "alarm_time_font_open_time";
    public static final String ALARM_TIME_MAP_OPEN_TIME = "alarm_time_map_open_time";
    public static final String ALARM_TIME_STAMPPOS_OPEN_TIME = "alarm_time_stamppos_open_time";
    public static final String ALARM_TIME_TEMP_OPEN_TIME = "alarm_time_temp_open_time";
    public static final String ALL_FONT_DOWNLODED = "all_font_downloaded";
    public static final String APP_COUNT = "app_count";
    public static final String BACKGROUND_COLOR = "BACKGROUND_COLOR";
    public static final String BACK_DT_COLOR_ALPHA = "back_dt_color_alpha";
    public static final String BACK_LOC_COLOR_ALPHA = "back_loc_color_alpha";
    public static final String BACK_SIGN_COLOR_ALPHA = "back_sign_color_alpha";
    public static final String CAMERA_FACING = "camera_facing";
    public static final String COMPASS_COLOR = "COMPASS_COLOR";
    public static final String COMPASS_FOUND = "compass_found";
    public static final String COMPASS_VALUE = "compass_value";
    public static final String CUS_1_INDEX = "cus_1_index";
    public static final String CUS_2_INDEX = "cus_2_index";
    public static final String CUS_3_INDEX = "cus_3_index";
    public static final String CUS_VALUE_1 = "cus_1_value";
    public static final String CUS_VALUE_2 = "cus_2_value";
    public static final String CUS_VALUE_3 = "cus_3_value";
    public static final String C_DHP = "C_DHP";
    public static final String C_DVP = "C_DVP";
    public static final String C_LHP = "C_LHP";
    public static final String C_LOHP = "C_LOHP";
    public static final String C_LOVP = "C_LOVP";
    public static final String C_LVP = "C_LVP";
    public static final String C_SHP = "C_SHP";
    public static final String C_SVP = "C_SVP";
    public static final String DATE_COLOR = "time_color";
    public static final String DATE_COLOR_POS = "time_color_pos";
    public static final String DATE_FORMAT = "date_format";
    public static final String DATE_HP = "DHP";
    public static final String DATE_POS = "date_pos";
    public static final String DATE_POS_VALUE = "date_pos_short";
    public static final String DATE_SIZE = "date_size";
    public static final String DATE_TIME_COLOR = "DATE_TIME_COLOR";
    public static final String DATE_TIME_INDEX = "dt_index";
    public static final String DATE_TYPEFACE = "font_face_date";
    public static final String DATE_VP = "DVP";
    public static final String DT_BACKGROUND_COLOR = "date_back_color";
    public static final String DT_BACKGROUND_COLOR_POS = "date_back_color_pos";
    public static final String DT_COLOR_ALPHA = "dt_color_alpha";
    public static final String DT_SHADOW_TOGGLE = "dt_shadow_toggle";
    public static final String FILE_ARRAY_LIST = "file_array_list";
    public static final String FLASH = "flash_value";
    public static final String FOLDER_NAME = "folder_name";
    public static final String FOLDER_PATH = "folder_path";
    public static final String FOLDER_SD_NAME = "folder_SD_name";
    public static final String FONT_USER_PROPERTY = "header_show";
    public static final String FULL_FILE_NAME = "full_file_name";
    public static final String HEADER_USER_PROPERTY = "header_show";
    public static final String IS_24HR = "is_24hr";
    public static final String IS_ADDRESS = "is_address";
    public static final String IS_AREA = "is_area";
    public static final String IS_CALL_WEATHER_API = "is_weather_once";
    public static final String IS_CITY = "is_city";
    public static final String IS_COMPASS = "is_compass";
    public static final String IS_COUNTRY = "is_country";
    public static final String IS_CUSTOM = "is_custom";
    public static final String IS_CUS_1 = "is_cus_1";
    public static final String IS_CUS_2 = "is_cus_2";
    public static final String IS_CUS_3 = "is_cus_3";
    public static final String IS_DATE_STAMP = "isdatestamp";
    public static final String IS_DATE_TIME = "is_date_time";
    public static final String IS_DECIMAL_FILE = "is_decimal_file";
    public static final String IS_DISPLAY_FOLDER_NAME = "is_display_folder_name";
    public static final String IS_DMS_FILE = "is_dms_file";
    public static final String IS_DT = "is_dt";
    public static final String IS_FILE_DATE_TIME = "is_main_dt";
    public static final String IS_HR_MIN_SEC = "is_hr_min_sec";
    public static final String IS_LAT_LNG = "is_lat_lng";
    public static final String IS_LAT_LNG_TEMPLATE = "is_lat_lng_template";
    public static final String IS_LAT_LONG_1 = "is_lat_long_1";
    public static final String IS_LAT_LONG_2 = "is_lat_long_2";
    public static final String IS_LAT_LONG_3 = "is_lat_long_3";
    public static final String IS_LINE_1 = "is_line_1";
    public static final String IS_LINE_2 = "is_line_2";
    public static final String IS_LINE_3 = "is_line_3";
    public static final String IS_LINE_4 = "is_line_4";
    public static final String IS_LOCATION_CHANGED = "is_location_chnaged";
    public static final String IS_LOCATION_STAMP = "is_location_stamp";
    public static final String IS_LOGO_STAMP = "islogostamp";
    public static final String IS_MAGNETIC_FIELD = "is_magnetic_field";
    public static final String IS_MAIN_ADDRESS = "is_main_address";
    public static final String IS_MAP = "is_map";
    public static final String IS_SEQUENCE = "is_sequence";
    public static final String IS_SIGNATURE_STAMP = "issignaturestamp";
    public static final String IS_STATE = "is_state";
    public static final String IS_WEATHER = "is_weather";
    public static final String IS_WEEK = "is_week";
    private static String KEY_DATE_FONT_LIST = "keysigndatelist";
    private static String KEY_SIGN_LIST = "keysignlist";
    public static final String LANGUAGE_COUNT = "language_count";
    public static final String LANGUAGE_POS = "language_pos";
    public static final String LATITUDE = "latitude_1";
    public static final String LAT_LNG_COLOR = "LAT_LNG_COLOR";
    public static final String LAT_LNG_INDEX = "lat_lng_index";
    public static final String LAT_LNG_TYPE = "lat_lng_type_1";
    public static final String LHP = "LHP";
    public static final String LOCATION_BACKGROUND_COLOR = "location_background_color";
    public static final String LOCATION_BACKGROUND_COLOR_POS = "location_background_color_pos";
    public static final String LOCATION_COLOR = "location_color";
    public static final String LOCATION_COLOR_POS = "location_color_pos";
    public static final String LOCATION_FONT = "location_font";
    public static final String LOCATION_FONT_NEW = "location_font_new";
    public static final String LOCATION_POS_SHORT = "location_pos_short";
    public static final String LOCATION_SIZE = "location_size";
    public static final String LOCATION_TYPE = "location_type";
    public static final String LOCATION_VALUE = "location_format";
    public static final String LOC_COLOR_ALPHA = "loc_color_alpha";
    public static final String LOC_LINE_1_ADDRESS = "loc_address_line_1";
    public static final String LOC_LINE_2_CITY = "loc_city";
    public static final String LOC_LINE_3_STATE = "loc_state";
    public static final String LOC_LINE_4_COUNTRY = "loc_country";
    public static final String LOC_SHADOW_TOGGLE = "loc_shadow_toggle";
    public static final String LOGO_POS = "logo_pos";
    public static final String LOGO_POS_VALUE = "logo_pos_short";
    public static final String LOGO_SIZE = "logosize";
    public static final String LOGO_TRANSPARENCY = "logotransp";
    public static final String LOGO_VP = "LVP";
    public static final String LOHP = "LOHP";
    public static final String LONGITUDE = "longitude_1";
    public static final String LOVP = "LOVP";
    public static final String MAGNETIC_FIELD_COLOR = "MAGNETIC_FIELD_COLOR";
    public static final String MAGNETIC_FIELD_VALUE = "magnetic_field_value";
    public static final String MAP_POS = "map_pos";
    public static final String MAP_TYPE = "map_type";
    public static final String MAP_TYPE_TEMPLATE = "map_type_template";
    public static final String OPEN_TIME = "open_time";
    public static final String SELECTED_LANGUAGE = "selected_language";
    public static final String SELECTED_LOC_POS = "location_pos";
    public static final String SELECTED_LOGO_POS = "logopos";
    public static final String SEQUENCE_INDEX = "sn_index";
    public static final String SEQUENCE_VALUE = "sequence_value";
    public static final String SIGNATURE = "singature";
    public static final String SIGNATURE_BACKGROUND_COLOR = "signature_background_color";
    public static final String SIGNATURE_BACKGROUND_COLOR_POS = "signature_background_color_pos";
    public static final String SIGN_COLOR = "sign_color";
    public static final String SIGN_COLOR_ALPHA = "sign_color_alpha";
    public static final String SIGN_COLOR_POS = "sign_color_pos";
    public static final String SIGN_HP = "SHP";
    public static final String SIGN_POS = "sign_pos";
    public static final String SIGN_POS_VALUE = "sign_pos_short";
    public static final String SIGN_SHADOW_TOGGLE = "sign_shadow_toggle";
    public static final String SIGN_SIZE = "sign_size";
    public static final String SIGN_TYPEFACE = "font_face_sign";
    public static final String SIGN_VP = "SVP";
    public static final String STAMP_POS = "stamp_pos";
    public static final String TEMPRATURE_TYPE = "temprature_type";
    public static final String TEMPRETURE_VALUE = "temprature_value";
    public static final String WEATHER_COLOR = "WEATHER_COLOR";
    public static final String WEATHER_ICON = "weather_icon";
    SharedPreferences myPreference;

    public static String getFlashPreferenceKey(String str) {
        return "flash_value_" + str;
    }

    public SP(Context context) {
        StrictMode.ThreadPolicy allowThreadDiskReads = StrictMode.allowThreadDiskReads();
        if (context != null) {
            try {
                this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
            } finally {
                StrictMode.setThreadPolicy(allowThreadDiskReads);
            }
        }
    }

    public void saveArrayList(Context context, ArrayList<ViewModel> arrayList) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        SharedPreferences.Editor edit = this.myPreference.edit();
        edit.putString(FILE_ARRAY_LIST, new Gson().toJson(arrayList));
        edit.commit();
    }

    public ArrayList<ViewModel> getArrayList(Context context) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        return (ArrayList) new Gson().fromJson(this.myPreference.getString(FILE_ARRAY_LIST, ""), new TypeToken<List<ViewModel>>() {
        }.getType());
    }

    public static String getRatioPos_Key(String str) {
        return "resolution_pos" + str;
    }

    public static String getRatio_Key(String str) {
        return "camera_resolution_" + str;
    }

    public void saveWordList(Context context, ArrayList<String> arrayList) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        SharedPreferences.Editor edit = this.myPreference.edit();
        edit.putString(KEY_SIGN_LIST, new Gson().toJson(arrayList));
        edit.apply();
    }

    public ArrayList<String> getWordList(Context context) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        return (ArrayList) new Gson().fromJson(this.myPreference.getString(KEY_SIGN_LIST, null), new TypeToken<ArrayList<String>>() { 
        }.getType());
    }

    public void saveFontList(Context context, ArrayList<String> arrayList) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        SharedPreferences.Editor edit = this.myPreference.edit();
        edit.putString(KEY_DATE_FONT_LIST, new Gson().toJson(arrayList));
        edit.apply();
    }
//
//    public ArrayList<String> getFontList(Context context) {
//        if (this.myPreference == null) {
//            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
//        }
//        ArrayList<String> arrayList = (ArrayList) new Gson().fromJson(this.myPreference.getString(KEY_DATE_FONT_LIST, null), new TypeToken<ArrayList<String>>() {
//        }.getType());
//        if (arrayList == null) {
//            ArrayList<String> arrayList2 = new ArrayList<>();
//            arrayList2.add(Default.DEFULT_FONT);
//            return arrayList2;
//        } else if (arrayList.size() != 0) {
//            return arrayList;
//        } else {
//            arrayList.add(Default.DEFULT_FONT);
//            return arrayList;
//        }
//    }

    public void setString(Context context, String str, String str2) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        SharedPreferences.Editor edit = this.myPreference.edit();
        edit.putString(str, str2);
        edit.apply();
    }

    public String getString(Context context, String str, String str2) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        return this.myPreference.getString(str, str2);
    }

    public void setInteger(Context context, String str, Integer num) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        SharedPreferences.Editor edit = this.myPreference.edit();
        edit.putInt(str, num.intValue());
        edit.apply();
    }

    public Integer getInteger(Context context, String str) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        return Integer.valueOf(this.myPreference.getInt(str, 0));
    }

    public void setFloat(Context context, String str, Float f) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        SharedPreferences.Editor edit = this.myPreference.edit();
        edit.putFloat(str, f.floatValue());
        edit.apply();
    }

    public Float getFloat(Context context, String str) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        return Float.valueOf(this.myPreference.getFloat(str, 0.0f));
    }

    public Integer getInteger(Context context, String str, int i) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        return Integer.valueOf(this.myPreference.getInt(str, i));
    }

    public void setBoolean(Context context, String str, Boolean bool) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        SharedPreferences.Editor edit = this.myPreference.edit();
        edit.putBoolean(str, bool.booleanValue());
        edit.apply();
    }

    public Boolean getBoolean(Context context, String str) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        return Boolean.valueOf(this.myPreference.getBoolean(str, false));
    }

    public Boolean getBoolean(Context context, String str, Boolean bool) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        return Boolean.valueOf(this.myPreference.getBoolean(str, bool.booleanValue()));
    }

    public void setLong(Context context, String str, long j) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        SharedPreferences.Editor edit = this.myPreference.edit();
        edit.putLong(str, j);
        edit.apply();
    }

    public long getLong(Context context, String str, long j) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        return this.myPreference.getLong(str, j);
    }

    public void clearSharedPreferences(Context context) {
        if (this.myPreference == null) {
            this.myPreference = PreferenceManager.getDefaultSharedPreferences(context);
        }
        SharedPreferences.Editor edit = this.myPreference.edit();
        edit.clear();
        edit.apply();
    }
}
