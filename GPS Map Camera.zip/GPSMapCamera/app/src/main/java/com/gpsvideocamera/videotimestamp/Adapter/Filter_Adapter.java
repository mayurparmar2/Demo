package com.gpsvideocamera.videotimestamp.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.gpsvideocamera.videotimestamp.VideoCameraActivity;
import com.gpsvideocamera.videotimestamp.Utils.Default;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import com.gpsvideocamera.videotimestamp.Utils.SP_Keys;
import com.live.gpsmap.camera.R;
import com.otaliastudios.cameraview.CameraView;
import com.otaliastudios.cameraview.filter.Filters;
import java.util.ArrayList;
import java.util.HashMap;

/* loaded from: classes2.dex */
public class Filter_Adapter extends RecyclerView.Adapter<Filter_Adapter.MyViewHolder> {
    CameraView camera;
    VideoCameraActivity cameraActivity;
    private Context context;
    private ArrayList<HashMap<String, String>> mFilterlist;
    SP mSP;
    private int[] selectedItems;

    public Filter_Adapter(Context context, ArrayList<HashMap<String, String>> arrayList, CameraView cameraView) {
        new ArrayList();
        this.context = context;
        this.mFilterlist = arrayList;
        this.camera = cameraView;
        this.cameraActivity = new VideoCameraActivity();
        this.selectedItems = new int[this.mFilterlist.size()];
        this.mSP = new SP(context);
    }

    private void initializeSeledtedItems() {
        int[] iArr;
        for (int i : this.selectedItems) {
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_filters2, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(MyViewHolder myViewHolder, @SuppressLint("RecyclerView") final int i) {
        switch (i) {
            case 0:
                myViewHolder.filter_img.setImageResource(R.drawable.back_filter_none);
                myViewHolder.filtername.setText(R.string.filter_none);
                break;
            case 1:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_auto_fix);
                myViewHolder.filtername.setText(R.string.filter_autofix);
                break;
            case 2:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_brightness);
                myViewHolder.filtername.setText(R.string.filter_brightness);
                break;
            case 3:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_contrast);
                myViewHolder.filtername.setText(R.string.filter_contrast);
                break;
            case 4:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_documentary);
                myViewHolder.filtername.setText(R.string.filter_documentry);
                break;
            case 5:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_hue);
                myViewHolder.filtername.setText(R.string.filter_hue);
                break;
            case 6:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_lemoish);
                myViewHolder.filtername.setText(R.string.filter_lomoish);
                break;
            case 7:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_gamma);
                myViewHolder.filtername.setText(R.string.filter_gamma);
                break;
            case 8:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_grain);
                myViewHolder.filtername.setText(R.string.filter_grain);
                break;
            case 9:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_temprature);
                myViewHolder.filtername.setText(R.string.filter_temperature);
                break;
            case 10:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_tint);
                myViewHolder.filtername.setText(R.string.filter_tint);
                break;
            case 11:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_vignate);
                myViewHolder.filtername.setText(R.string.filter_vignette);
                break;
            case 12:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_bw);
                myViewHolder.filtername.setText(R.string.filter_bnw);
                break;
            case 13:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_fill_light);
                myViewHolder.filtername.setText(R.string.filter_filllight);
                break;
            case 14:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_grey_scale);
                myViewHolder.filtername.setText(R.string.filter_grayscale);
                break;
            case 15:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_invert);
                myViewHolder.filtername.setText(R.string.filter_invert);
                break;
            case 16:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_posterize);
                myViewHolder.filtername.setText(R.string.filter_posterize);
                break;
            case 17:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_sepia);
                myViewHolder.filtername.setText(R.string.filter_sepia);
                break;
            case 18:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_sharness);
                myViewHolder.filtername.setText(R.string.filter_sharpness);
                break;
            case 19:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_due_tone);
                myViewHolder.filtername.setText(R.string.filter_duotone);
                break;
            case 20:
                myViewHolder.filter_img.setImageResource(R.drawable.camera_cross_process);
                myViewHolder.filtername.setText(R.string.filter_crossprocess);
                break;
        }
        this.mFilterlist.get(i);
        setSelectedItem(Default.FILTERPOSITION);
        if (this.selectedItems[i] == 1) {
            myViewHolder.highlightcard.setVisibility(View.VISIBLE);
            myViewHolder.highlightcard_2.setVisibility(View.GONE);
            myViewHolder.filtername.setBackgroundColor(Color.parseColor("#2BACFC"));
            myViewHolder.filtername.setTextColor(-1);
        } else {
            myViewHolder.highlightcard.setVisibility(View.GONE);
            myViewHolder.highlightcard_2.setVisibility(View.VISIBLE);
            myViewHolder.filtername.setBackgroundColor(Color.parseColor("#3D3D3D"));
            myViewHolder.filtername.setTextColor(-1);
        }
        myViewHolder.filter_img.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Adapter.Filter_Adapter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                int i2 = i;
                if (i2 != -1) {
                    Filter_Adapter.this.setSelectedItem(i2);
                    Filter_Adapter.this.notifyItemChanged(Default.FILTERPOSITION);
                    Filter_Adapter.this.notifyItemChanged(i);
                }
                Default.FILTERPOSITION = i;
                Filter_Adapter.this.mSP.setInteger(Filter_Adapter.this.context, SP_Keys.FILTER_POS, Integer.valueOf(Default.FILTERPOSITION));
                VideoCameraActivity.Currentfilter = i;
                switch (i) {
                    case 0:
                        Filter_Adapter.this.camera.setFilter(Filters.NONE.newInstance());
                        return;
                    case 1:
                        Filter_Adapter.this.camera.setFilter(Filters.AUTO_FIX.newInstance());
                        return;
                    case 2:
                        Filter_Adapter.this.camera.setFilter(Filters.BRIGHTNESS.newInstance());
                        return;
                    case 3:
                        Filter_Adapter.this.camera.setFilter(Filters.CONTRAST.newInstance());
                        return;
                    case 4:
                        Filter_Adapter.this.camera.setFilter(Filters.DOCUMENTARY.newInstance());
                        return;
                    case 5:
                        Filter_Adapter.this.camera.setFilter(Filters.HUE.newInstance());
                        return;
                    case 6:
                        Filter_Adapter.this.camera.setFilter(Filters.LOMOISH.newInstance());
                        return;
                    case 7:
                        Filter_Adapter.this.camera.setFilter(Filters.GAMMA.newInstance());
                        return;
                    case 8:
                        Filter_Adapter.this.camera.setFilter(Filters.GRAIN.newInstance());
                        return;
                    case 9:
                        Filter_Adapter.this.camera.setFilter(Filters.TEMPERATURE.newInstance());
                        return;
                    case 10:
                        Filter_Adapter.this.camera.setFilter(Filters.TINT.newInstance());
                        return;
                    case 11:
                        Filter_Adapter.this.camera.setFilter(Filters.VIGNETTE.newInstance());
                        return;
                    case 12:
                        Filter_Adapter.this.camera.setFilter(Filters.BLACK_AND_WHITE.newInstance());
                        return;
                    case 13:
                        Filter_Adapter.this.camera.setFilter(Filters.FILL_LIGHT.newInstance());
                        return;
                    case 14:
                        Filter_Adapter.this.camera.setFilter(Filters.GRAYSCALE.newInstance());
                        return;
                    case 15:
                        Filter_Adapter.this.camera.setFilter(Filters.INVERT_COLORS.newInstance());
                        return;
                    case 16:
                        Filter_Adapter.this.camera.setFilter(Filters.POSTERIZE.newInstance());
                        return;
                    case 17:
                        Filter_Adapter.this.camera.setFilter(Filters.SEPIA.newInstance());
                        return;
                    case 18:
                        Filter_Adapter.this.camera.setFilter(Filters.SHARPNESS.newInstance());
                        return;
                    case 19:
                        Filter_Adapter.this.camera.setFilter(Filters.DUOTONE.newInstance());
                        return;
                    case 20:
                        Filter_Adapter.this.camera.setFilter(Filters.CROSS_PROCESS.newInstance());
                        return;
                    default:
                        return;
                }
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setSelectedItem(int i) {
        int i2 = 0;
        while (true) {
            int[] iArr = this.selectedItems;
            if (i2 >= iArr.length) {
                return;
            }
            if (i2 == i) {
                iArr[i2] = 1;
            } else {
                iArr[i2] = 0;
            }
            i2++;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.mFilterlist.size();
    }

    /* loaded from: classes3.dex */
    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView filter_img;
        TextView filtername;
        CardView highlightcard;
        CardView highlightcard_2;

        public MyViewHolder(View view) {
            super(view);
            this.filter_img = (ImageView) view.findViewById(R.id.filter_img);
            this.filtername = (TextView) view.findViewById(R.id.txt_filter_name);
            this.highlightcard = (CardView) view.findViewById(R.id.highlightcard);
            this.highlightcard_2 = (CardView) view.findViewById(R.id.highlightcard_2);
        }
    }
}