package com.gpsvideocamera.videotimestamp.Fragment;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;

import com.android.billingclient.BuildConfig;
import com.gpsvideocamera.videotimestamp.VideoCameraActivity;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import com.gpsvideocamera.videotimestamp.Utils.SP_Keys;
import com.live.gpsmap.camera.Camera.utils.EnvironmentSDCard;
import com.live.gpsmap.camera.R;
import com.live.gpsmap.camera.Utils.Default;

import java.io.File;


public class SettingFragment extends Fragment implements View.OnClickListener {
    private static final int CHOOSE_SAVE_FOLDER_SAF_CODE = 42;
    AlertDialog alertNoIntentDialog;
    private boolean isSDCardPermission;
    private boolean isSDCardStorageEnabled;
    LinearLayout lin_language;
    LinearLayout lin_main;
    LinearLayout lin_ourapp;
    LinearLayout lin_police;
    LinearLayout lin_rate;
    LinearLayout lin_sdcard;
    LinearLayout lin_senderror;
    LinearLayout lin_share;
    SP mSP;
    private RelativeLayout mToolbar_back;
    TextView mtv_toolbar_title;
    SwitchCompat sw_sdcard;
    LinearLayout toolbar_menu;
    TextView tv_language;
    TextView tv_sd_path;
    TextView tv_version;
    AlertDialog alertSDPermissionDialog = null;
    AlertDialog alertHintDialog = null;
    private long mLastClickTime = 0;

    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override 
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_setting, viewGroup, false);
    }

    @Override 
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        init(view);
        onCliks();
    }

    private void init(View view) {
        this.lin_language = (LinearLayout) view.findViewById(R.id.lin_changeLG);
        this.lin_ourapp = (LinearLayout) view.findViewById(R.id.lin_ourapp);
        this.lin_police = (LinearLayout) view.findViewById(R.id.lin_privacy);
        this.lin_rate = (LinearLayout) view.findViewById(R.id.lin_rate);
        this.lin_sdcard = (LinearLayout) view.findViewById(R.id.lin_sdcard);
        this.lin_senderror = (LinearLayout) view.findViewById(R.id.lin_send_error);
        this.lin_share = (LinearLayout) view.findViewById(R.id.lin_share);
        this.tv_language = (TextView) view.findViewById(R.id.tv_laguage);
        this.tv_sd_path = (TextView) view.findViewById(R.id.tv_sdC_path);
        this.tv_version = (TextView) view.findViewById(R.id.tv_version);
        this.sw_sdcard = (SwitchCompat) view.findViewById(R.id.sw_sdcard);
        this.mToolbar_back = (RelativeLayout) view.findViewById(R.id.toolbar_back);
        this.mtv_toolbar_title = (TextView) view.findViewById(R.id.tv_toolbar_title);
        this.toolbar_menu = (LinearLayout) view.findViewById(R.id.toolbar_menu);
        this.lin_main = (LinearLayout) view.findViewById(R.id.lin_main);
        this.toolbar_menu.setEnabled(false);
        this.tv_version.setText(BuildConfig.VERSION_NAME);
        this.mSP = new SP(getActivity());
        if (EnvironmentSDCard.isSDCardAvailable(getActivity())) {
            this.lin_sdcard.setEnabled(true);
            this.lin_sdcard.setAlpha(1.0f);
            this.isSDCardStorageEnabled = this.mSP.getBoolean(getActivity(), SP_Keys.IS_SD_CARD, false).booleanValue();
            if (this.mSP.getString(getActivity(), SP.FOLDER_SD_NAME, Default.DEFAULT_FOLDER_NAME).equals(Default.DEFAULT_FOLDER_NAME)) {
                this.isSDCardPermission = false;
            } else {
                this.isSDCardPermission = true;
            }
            if (this.isSDCardPermission) {
                setloactio();
            }
            switchSDChecked();
        } else {
            this.lin_sdcard.setEnabled(false);
            this.lin_sdcard.setAlpha(0.4f);
            setloactio();
        }
    }


    private void onCliks() {
        this.lin_share.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                SettingFragment.this.onClick(view);
            }
        });
        this.lin_language.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                SettingFragment.this.onClick(view);
            }
        });
        this.lin_sdcard.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                SettingFragment.this.onClick(view);
            }
        });
        this.lin_senderror.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                SettingFragment.this.onClick(view);
            }
        });
        this.lin_rate.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                SettingFragment.this.onClick(view);
            }
        });
        this.lin_police.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                SettingFragment.this.onClick(view);
            }
        });
        this.lin_ourapp.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                SettingFragment.this.onClick(view);
            }
        });
        this.mToolbar_back.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                SettingFragment.this.onClick(view);
            }
        });
    }

    private void switchSDChecked() {
        this.sw_sdcard.setChecked(this.isSDCardStorageEnabled);
    }

    @Override 
    public void onClick(View view) {
        if (SystemClock.elapsedRealtime() - this.mLastClickTime >= 1000) {
            this.mLastClickTime = SystemClock.elapsedRealtime();
            int id = view.getId();
            if (id == R.id.lin_changeLG) {
//                startActivity(new Intent(getActivity(), LanguageSelectionActivity.class));
            } else if (id != R.id.toolbar_back) {
                switch (id) {
                    case R.id.lin_privacy :
//                        if (HelperClass.check_internet(getActivity())) {
//                            startActivity(new Intent(getActivity(), Privacy_Policy.class));
//                            return;
//                        }
//                        LinearLayout linearLayout2 = this.lin_main;
//                        Snackbar.make(linearLayout2, "" + getString(R.string.no_internet_msg), -Toast.LENGTH_LONG).show();
//                        return;
                    case R.id.lin_rate :
//                        HelperClass.showSayThanksDialog(getActivity());
                        return;
                    case R.id.lin_sdcard :
                        if (this.isSDCardStorageEnabled) {
                            this.isSDCardStorageEnabled = false;
                            this.mSP.setBoolean(getActivity(), SP_Keys.IS_SD_CARD, Boolean.valueOf(this.isSDCardStorageEnabled));
                            switchSDChecked();
                            setloactio();
                            return;
                        } else if (!EnvironmentSDCard.isSDCardAvailable(getActivity())) {
                            return;
                        } else {
                            if (!this.isSDCardPermission) {
                                giveSDCardPermission();
                                return;
                            }
                            this.isSDCardStorageEnabled = true;
                            this.mSP.setBoolean(getActivity(), SP_Keys.IS_SD_CARD, Boolean.valueOf(this.isSDCardStorageEnabled));
                            setloactio();
                            switchSDChecked();
                            return;
                        }
                    case R.id.lin_send_error :
                        senderrordiolog();
                        return;
                    case R.id.lin_share :
//                        HelperClass.shareApp(getActivity());
                        return;
                    default:
                        return;
                }
            } else {
                doBack();
            }
        }
    }

    private void senderrordiolog() {
//        View inflate = View.inflate(getActivity(), R.layout.send_error_dialog, null);
//        final AlertDialog create = new AlertDialog.Builder(getActivity()).setView(inflate).setCancelable(true).create();
//        final EditText editText = (EditText) inflate.findViewById(R.id.ed_errormsg);
//        ((TextView) inflate.findViewById(R.id.btn_ok)).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                ((InputMethodManager) SettingFragment.this.getActivity().getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(view.getWindowToken(), 0);
//                if (editText.getText().toString().trim().length() < 30) {
//                    Snackbar.make(view, SettingFragment.this.getString(R.string.txt_send_error_message), -Toast.LENGTH_LONG).show();
//                } else if (HelperClass.check_internet(SettingFragment.this.getActivity())) {
//                    HelperClass.reportBug(SettingFragment.this.getActivity(), SettingFragment.this.getString(R.string.app_recipient), SettingFragment.this.getResources().getString(R.string.app_error_report), editText.getText().toString(), false);
//                    create.dismiss();
//                } else {
//                    Snackbar.make(view, SettingFragment.this.getResources().getString(R.string.no_internet_msg), Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
//        ((TextView) inflate.findViewById(R.id.btn_cancel)).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                create.dismiss();
//            }
//        });
//        create.show();
    }

    public void doBack() {
        getActivity().getSupportFragmentManager().popBackStackImmediate();
    }

    @Override 
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        if (getActivity() != null) {
            ((VideoCameraActivity) getActivity()).setOnBackPressedListener(new VideoCameraActivity.OnBackPressedListener() {
                @Override 
                public void onBackPressed() {
                    SettingFragment.this.doBack();
                }
            });
        }
    }

    public void giveSDCardPermission() {
        try {
            AlertDialog alertDialog = this.alertSDPermissionDialog;
            if (alertDialog == null || this.alertHintDialog != null) {
                if (!getActivity().isFinishing()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle(getResources().getString(R.string.give_seconday_permission_title));
                    builder.setMessage(getResources().getString(R.string.give_seconday_permission_message)).setCancelable(false).setPositiveButton(getResources().getString(R.string.give_seconday_permission_btn), new DialogInterface.OnClickListener() { 
                        @Override 
                        public void onClick(DialogInterface dialogInterface, int i) {
                            if (SettingFragment.this.alertSDPermissionDialog != null) {
                                SettingFragment.this.alertSDPermissionDialog.dismiss();
                            }
                            SettingFragment.this.alertSDPermissionDialog = null;
                            SettingFragment.this.openStoragePermissionHintDialog();
                        }
                    }).setNegativeButton(getResources().getString(R.string.skip), new DialogInterface.OnClickListener() { 
                        @Override 
                        public void onClick(DialogInterface dialogInterface, int i) {
                            if (SettingFragment.this.alertSDPermissionDialog != null) {
                                SettingFragment.this.alertSDPermissionDialog.dismiss();
                            }
                            SettingFragment.this.alertSDPermissionDialog = null;
                        }
                    });
                    AlertDialog create = builder.create();
                    this.alertSDPermissionDialog = create;
                    if (this.alertHintDialog == null) {
                        create.show();
                    }
                }
            } else if (!alertDialog.isShowing()) {
                this.alertSDPermissionDialog.show();
            }
        } catch (Exception unused) {
            this.alertSDPermissionDialog = null;
        }
    }

    public void refrese() {
        this.isSDCardStorageEnabled = this.mSP.getBoolean(getActivity(), SP_Keys.IS_SD_CARD, false).booleanValue();
        setloactio();
        switchSDChecked();
    }

    public void openStoragePermissionHintDialog() {
        try {
            AlertDialog alertDialog = this.alertHintDialog;
            if (alertDialog != null) {
                if (!alertDialog.isShowing()) {
                    this.alertHintDialog.show();
                }
            } else if (!getActivity().isFinishing()) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Hint");
                builder.setCancelable(false);
                LayoutInflater layoutInflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View inflate = LayoutInflater.from(getActivity()).inflate(R.layout.hint_dialog, (ViewGroup) null);
                builder.setView(inflate);
                ((LinearLayout) inflate.findViewById(R.id.btn_ok)).setOnClickListener(new View.OnClickListener() { 
                    @Override 
                    public void onClick(View view) {
                        Intent intent;
                        try {
                            if (Build.VERSION.SDK_INT >= 21) {
                                intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
                                intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                                intent.addFlags(android.content.Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                                intent.addFlags(Intent.FLAG_EXCLUDE_STOPPED_PACKAGES);
                            } else {
                                intent = new Intent();
                                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                            }
                            if (SettingFragment.this.alertHintDialog != null) {
                                SettingFragment.this.alertHintDialog.dismiss();
                            }
                            SettingFragment.this.alertHintDialog = null;
                            SettingFragment.this.getActivity().startActivityForResult(intent, 42);
                        } catch (ActivityNotFoundException unused) {
                            SettingFragment.this.openNoIntentAvailableDialog();
                            SettingFragment.this.alertHintDialog = null;
                        }
                    }
                });
                AlertDialog create = builder.create();
                this.alertHintDialog = create;
                create.show();
            }
        } catch (Exception unused) {
        }
    }

    @SuppressLint("WrongConstant")
    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 42 && i2 == -1 && intent != null) {
            Uri data = intent.getData();
            try {
                getActivity().getContentResolver().takePersistableUriPermission(data, intent.getFlags() & 3);
                this.sw_sdcard.setChecked(true);
                this.isSDCardStorageEnabled = true;
                this.mSP.setBoolean(getActivity(), SP_Keys.IS_SD_CARD, true);
                this.mSP.setString(getActivity(), SP.FOLDER_SD_NAME, data.toString());
                setloactio();
            } catch (SecurityException e) {
                e.printStackTrace();
            }
        }
    }

    private void setloactio() {
        String str;
        if (this.mSP.getBoolean(getActivity(), SP_Keys.IS_SD_CARD, false).booleanValue()) {
            this.sw_sdcard.setChecked(true);
            String[] split = new File(Uri.parse(this.mSP.getString(getActivity(), SP.FOLDER_SD_NAME, Default.DEFAULT_FOLDER_NAME)).getPath()).getAbsolutePath().split("/");
            str = "";
            for (String str2 : split) {
                if (str2.equals("tree")) {
                    str = str + "storage/";
                } else {
                    str = str + str2.replace(":", "/") + "/";
                }
            }
        } else {
            this.sw_sdcard.setChecked(false);
            str = "Disable";
        }
        this.tv_sd_path.setText(str);
    }

    public void openNoIntentAvailableDialog() {
        if (!getActivity().isFinishing()) {
            AlertDialog alertDialog = this.alertNoIntentDialog;
            if (alertDialog == null) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle(getResources().getString(R.string.external_sdcard_write_permission));
                builder.setMessage(getResources().getString(R.string.sdcard_not_root_device)).setCancelable(false).setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() { 
                    @Override 
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (SettingFragment.this.alertNoIntentDialog != null) {
                            SettingFragment.this.alertNoIntentDialog.dismiss();
                        }
                        SettingFragment.this.alertNoIntentDialog = null;
                    }
                });
                AlertDialog create = builder.create();
                this.alertNoIntentDialog = create;
                create.show();
            } else if (!alertDialog.isShowing()) {
                this.alertNoIntentDialog.show();
            }
        }
    }
}
