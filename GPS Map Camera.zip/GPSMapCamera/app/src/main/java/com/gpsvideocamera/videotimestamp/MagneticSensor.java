package com.gpsvideocamera.videotimestamp;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.preference.PreferenceManager;

import com.gpsvideocamera.videotimestamp.Utils.SP_Keys;
import com.live.gpsmap.camera.R;


public class MagneticSensor {
    private static final String TAG = "MagneticSensor";
    private Sensor mSensorMagnetic;
    private boolean magneticListenerIsRegistered;
    private AlertDialog magnetic_accuracy_dialog;
    private final VideoCameraActivity main_activity;
    private int magnetic_accuracy = -1;
    private final SensorEventListener magneticListener = new SensorEventListener() { 
        @Override 
        public void onSensorChanged(SensorEvent sensorEvent) {
        }

        @Override 
        public void onAccuracyChanged(Sensor sensor, int i) {
            MagneticSensor.this.magnetic_accuracy = i;
            MagneticSensor.this.setMagneticAccuracyDialogText();
            MagneticSensor.this.checkMagneticAccuracy();
        }
    };
    private boolean shown_magnetic_accuracy_dialog = false;

    
    public MagneticSensor(VideoCameraActivity cameraActivity) {
        this.main_activity = cameraActivity;
    }

    
    public void initSensor(SensorManager sensorManager) {
        if (sensorManager.getDefaultSensor(2) != null) {
            this.mSensorMagnetic = sensorManager.getDefaultSensor(2);
        }
    }

    
    public void registerMagneticListener(SensorManager sensorManager) {
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.main_activity);
        if (!this.magneticListenerIsRegistered) {
            if (needsMagneticSensor(defaultSharedPreferences)) {
                sensorManager.registerListener(this.magneticListener, this.mSensorMagnetic, 3);
                this.magneticListenerIsRegistered = true;
            }
        } else if (!needsMagneticSensor(defaultSharedPreferences)) {
            sensorManager.unregisterListener(this.magneticListener);
            this.magneticListenerIsRegistered = false;
        }
    }

    
    public void unregisterMagneticListener(SensorManager sensorManager) {
        if (this.magneticListenerIsRegistered) {
            sensorManager.unregisterListener(this.magneticListener);
            this.magneticListenerIsRegistered = false;
        }
    }

    
    public void setMagneticAccuracyDialogText() {
        String str;
        if (this.magnetic_accuracy_dialog != null) {
            String str2 = this.main_activity.getResources().getString(R.string.magnetic_accuracy_info) + " ";
            int i = this.magnetic_accuracy;
            if (i == 0) {
                str = str2 + this.main_activity.getResources().getString(R.string.accuracy_unreliable);
            } else if (i == 1) {
                str = str2 + this.main_activity.getResources().getString(R.string.accuracy_low);
            } else if (i == 2) {
                str = str2 + this.main_activity.getResources().getString(R.string.accuracy_medium);
            } else if (i != 3) {
                str = str2 + this.main_activity.getResources().getString(R.string.accuracy_unknown);
            } else {
                str = str2 + this.main_activity.getResources().getString(R.string.accuracy_high);
            }
            this.magnetic_accuracy_dialog.setMessage(str);
        }
    }

    void checkMagneticAccuracy() {
        int i = this.magnetic_accuracy;
        if ((i == 0 || i == 1) && !this.shown_magnetic_accuracy_dialog) {
            SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.main_activity);
            if (needsMagneticSensor(defaultSharedPreferences)) {
                if (defaultSharedPreferences.contains(SP_Keys.MagneticAccuracyPreferenceKey)) {
                    this.shown_magnetic_accuracy_dialog = true;
                    return;
                }
                this.shown_magnetic_accuracy_dialog = true;
                setMagneticAccuracyDialogText();
            }
        }
    }

    private boolean needsMagneticSensor(SharedPreferences sharedPreferences) {
        if (sharedPreferences.getBoolean(SP_Keys.ShowGeoDirectionLinesPreferenceKey, false) || sharedPreferences.getBoolean(SP_Keys.ShowGeoDirectionPreferenceKey, false)) {
            return true;
        }
        return false;
    }

    int getMagneticAccuracy() {
        return this.magnetic_accuracy;
    }

    
    public void clearDialog() {
        this.magnetic_accuracy_dialog = null;
    }
}
