#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
import android.content.Context;
import android.content.SharedPreferences;
import com.demo.example.model.Users;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
public class ${NAME} {

    private static final String PREF_NAME = "my_pref";
    private static final String KEY_LIST = "${Model}_list";

    private SharedPreferences sharedPreferences;
    private Gson gson;

    public ${NAME}(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
    }

    public List<${Model}> get${Model}List() {
        String json = sharedPreferences.getString(KEY_LIST, null);
        Type type = new TypeToken<List<${Model}>>(){}.getType();
        return gson.fromJson(json, type);
    }

    public void insert${Model}(${Model} m${Model}) {
        List<${Model}> m${Model}List = get${Model}List();
        if (m${Model}List == null) {
            m${Model}List = new ArrayList<>();
        }
        m${Model}List.add(m${Model});
        save${Model}List(m${Model}List);
    }

    public void update${Model}(${Model} updated${Model}) {
        List<${Model}> m${Model}List = get${Model}List();
        if (m${Model}List != null) {
            for (int i = 0; i < m${Model}List.size(); i++) {
                if (m${Model}List.get(i).getId() == updated${Model}.getId()) {
                    m${Model}List.set(i, updated${Model});
                    save${Model}List(m${Model}List);
                    return;
                }
            }
        }
    }

    public void delete${Model}(int m${Model}Id) {
        List<${Model}> m${Model}List = get${Model}List();
        if (m${Model}List != null) {
            for (int i = 0; i < m${Model}List.size(); i++) {
                if (m${Model}List.get(i).getId() == m${Model}Id) {
                    m${Model}List.remove(i);
                    save${Model}List(m${Model}List);
                    return;
                }
            }
        }
    }

    private void save${Model}List(List<${Model}> m${Model}List) {
        String json = gson.toJson(m${Model}List);
        sharedPreferences.edit().putString(KEY_LIST, json).apply();
    }
}

