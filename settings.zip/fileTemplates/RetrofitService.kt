#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
import retrofit2.http.GET
#parse("File Header.java")
interface ${NAME} {
    @GET("/")
    suspend fun get${Model}(): ${Model}

  //  @POST("/your-endpoint-here")
  //  suspend fun post${Model}(@Body requestBody: RequestBody): ${Model} // Change RequestBody and ResponseData to your actual request and response models
}
