import 'package:flutter/material.dart';
class ${NAME} extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DemoClass',
      home: DemoClass(),
    );
  }
}

