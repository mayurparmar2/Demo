package com.maps.radar.trafficappfordriving.ui.splash;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.TypedValue;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import com.airbnb.lottie.LottieAnimationView;
import com.demo.radar.trafficappfordriving2.R;
import com.demo.radar.trafficappfordriving2.databinding.NazActivitySplashBinding;
import com.maps.radar.trafficappfordriving.ui.main.MainActivity;
import com.maps.radar.trafficappfordriving.ui.base.BaseActivity;

public class SplashActivity extends BaseActivity<NazActivitySplashBinding> {
    private final String TAG = "SplashActivity";
    NazActivitySplashBinding binding;
    Integer[] imageList = new Integer[]{
            Integer.valueOf(R.drawable.img_question)
            , Integer.valueOf(R.drawable.img_speed)
            , Integer.valueOf(R.drawable.img_car)
            , Integer.valueOf(R.drawable.img_radar)
            , Integer.valueOf(R.drawable.img_traffic_rules)
            , Integer.valueOf(R.drawable.img_display)
            , Integer.valueOf(R.drawable.img_head_up_display)
            , Integer.valueOf(R.drawable.shutterstock_1700869615)
            , Integer.valueOf(R.drawable.img_phone)
            , Integer.valueOf(R.drawable.img_traffic_lamp)
    };

    @Override
    public NazActivitySplashBinding getViewBinding() {
        binding = NazActivitySplashBinding.inflate(getLayoutInflater());
        return binding;
    }

    @Override
    public void initView(NazActivitySplashBinding binding) {
        binding.getRoot().setBackgroundColor(ContextCompat.getColor(this, R.color.blue));
        binding.appName.setText(getApplicationInfo().loadLabel(getPackageManager()).toString());
        int textColor = ContextCompat.getColor(this, R.color.white);
        binding.appName.setTextColor(textColor);
        binding.company.setTextColor(textColor);

        ImageView[] imageViews = {
                binding.img1, binding.img2, binding.img3, binding.img4, binding.img5,
                binding.img6, binding.img7, binding.img8, binding.img9, binding.img10
        };
        for (int i = 0; i < imageViews.length; i++) {
            if (i < imageList.length) {
                imageViews[i].setImageResource(imageList[i]);
            }
        }
        Drawable applicationIcon = getPackageManager().getApplicationIcon(getApplicationInfo());
        binding.appIcon.setImageDrawable(applicationIcon);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(SplashActivity.this, MainActivity.class));
            }
        }, 1000);

    }


    @Override
    public void onStart() {
        super.onStart();
        int applyDimension = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 150.0f, getResources().getDisplayMetrics());
        LottieAnimationView lottieAnimationView = binding.loading;
        lottieAnimationView.setAnimation(R.raw.splash_loading);
        ViewGroup.LayoutParams layoutParams = lottieAnimationView.getLayoutParams();
        if (layoutParams != null) {
            ConstraintLayout.LayoutParams layoutParams2 = (ConstraintLayout.LayoutParams) layoutParams;
            ((ViewGroup.MarginLayoutParams) layoutParams2).width = applyDimension;
            ((ViewGroup.MarginLayoutParams) layoutParams2).height = applyDimension;
            lottieAnimationView.setLayoutParams(layoutParams2);
            return;
        }
        throw new NullPointerException("null cannot be cast to non-null type androidx.constraintlayout.widget.ConstraintLayout.LayoutParams");
    }

}
