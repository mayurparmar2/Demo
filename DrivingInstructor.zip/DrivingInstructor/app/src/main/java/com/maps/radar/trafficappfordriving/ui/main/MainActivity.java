package com.maps.radar.trafficappfordriving.ui.main;

import com.demo.radar.trafficappfordriving2.databinding.ActivityMainBinding;
import com.maps.radar.trafficappfordriving.ui.base.BaseActivity;
import com.maps.radar.trafficappfordriving.utils.RemoteConfigUtils;

public class MainActivity extends BaseActivity<ActivityMainBinding> {
    private final String TAG = "MainActivity";
    ActivityMainBinding binding;

    @Override
    public ActivityMainBinding getViewBinding() {
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        return binding;
    }

    @Override
    public void initView(ActivityMainBinding binding) {
        RemoteConfigUtils remoteConfigUtils = RemoteConfigUtils.f5880a;

    }

}
