package com.maps.radar.trafficappfordriving.offlinemap.fragments

import android.view.MotionEvent
import android.view.View
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.FragmentOsmdroidBinding
import com.maps.radar.trafficappfordriving.offlinemap.model.MapType
import org.osmdroid.events.DelayedMapListener
import org.osmdroid.events.MapListener
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.tileprovider.cachemanager.CacheManager
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.Polygon


class OfflineMapsFragment: BaseMapFragment() {
    private var cacheManager: CacheManager? = null
    private val points: ArrayList<GeoPoint>? = null


    override fun getMapType(): MapType {
        return MapType.OFFLINE_MAPS;
    }
    override fun getPageTitle(): String {
        val string = getString(R.string.offline_maps_map)
        return string
    }

    override fun setupViews(): FragmentOsmdroidBinding {
        val binding = super.setupViews()
        this.cacheManager =  CacheManager(binding.mapview)
        binding.circleLayout2.visibility = View.GONE
        binding.btnMapDownload.setOnClickListener(this)
        binding.mapview.addMapListener(DelayedMapListener(object : MapListener{
            override fun onScroll(event: ScrollEvent?): Boolean {
                setZoomLevel(binding.mapview.zoomLevelDouble);
                removeSelectedPolygon();
                return false
            }
            override fun onZoom(event: ZoomEvent?): Boolean {
                if (event != null) {
                    setZoomLevel(event.zoomLevel);
                }
                removeSelectedPolygon();
                return false;
            }
        }, 100L))



        binding.mapview.getOverlays().add(object : Overlay() {
            override fun onShowPress(pEvent: MotionEvent?, pMapView: MapView?) {
//                handleMapClick()
                super.onShowPress(pEvent, pMapView)
            }
        })
        return binding


    }

    private var selectedBoundingBox: Polygon? = null

    fun removeSelectedPolygon() {
        if (checkIfFragmentAttached(this) && this.selectedBoundingBox != null) {
            requireActivity().runOnUiThread(object : Runnable {
                override fun run() {
                    binding?.mapview?.overlays?.remove(selectedBoundingBox)
                    points?.clear()
                    selectedBoundingBox = null
                    binding?.btnMapDownload?.visibility = View.GONE
                    binding?.mapview?.invalidate()

                }
            })
        }
    }

}



