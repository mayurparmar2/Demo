package com.maps.radar.trafficappfordriving.ui.guide

import android.content.Context
import android.content.SharedPreferences

class GuideLikePref private constructor(private val preferences: SharedPreferences) {

    companion object {
        private const val PREF_NAME = "GUIDE_LIKE_PREF"
        private var instance: GuideLikePref? = null

        fun getInstance(context: Context): GuideLikePref {
            return instance ?: synchronized(this) {
                instance ?: GuideLikePref(
                    context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                ).also { instance = it }
            }
        }

        private fun getKey(groupId: Int, id: Int) = "fav_group_${groupId}_$id"
    }

    fun isLiked(groupId: Int, id: Int): Boolean {
        return preferences.getBoolean(getKey(groupId, id), false)
    }

    fun getLikedItems(groupId: Int): List<Int> {
        return preferences.all
            .filterKeys { it.startsWith("fav_group_$groupId") }
            .filterValues { it == true }
            .mapNotNull { it.key.split("_").getOrNull(2)?.toIntOrNull() }
    }

    fun setLiked(groupId: Int, id: Int, liked: Boolean) {
        preferences.edit().putBoolean(getKey(groupId, id), liked).apply()
    }
}
