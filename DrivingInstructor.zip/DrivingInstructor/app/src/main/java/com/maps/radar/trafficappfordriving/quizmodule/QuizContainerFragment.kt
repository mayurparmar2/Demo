package com.maps.radar.trafficappfordriving.quizmodule

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.LiveData
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.FragmentQuizContainerBinding
import com.maps.radar.trafficappfordriving.model.QuizMain
import com.maps.radar.trafficappfordriving.quizmodule.Adapter.QuizPagerAdapter
import com.maps.radar.trafficappfordriving.quizmodule.dialog.CustomDialogFinish
import com.maps.radar.trafficappfordriving.quizmodule.dialog.ProgressDialog


class QuizContainerFragment : Fragment() {

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentQuizContainerBinding.inflate(inflater, container, false)
        return binding.root
    }

    private var _binding: FragmentQuizContainerBinding? = null
    private val binding get() = _binding!!


    private var index = 0
    private var contentList: List<QuizMain.All>? = null
    private var notShowStreak = false
    private var subCount = 0


    // androidx.fragment.app.Fragment
    override fun onCreate(bundle: Bundle?) {
        super.onCreate(bundle)
        this.index = requireArguments().getInt("index")
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.quizPager.setUserInputEnabled(false)

        val textView: TextView? = requireActivity().findViewById(R.id.total_point)
        val textView2: TextView? = requireActivity().findViewById(R.id.current_point)

        if (activity is QuizMainActivity) {
            val quizMainActivity = activity as QuizMainActivity
            quizMainActivity.binding.headerText.setText(
                requireActivity().getString(R.string.hunter_quiz_quiz) + ' ' + (this.index + 1))
            quizMainActivity.viewModelDb.startTest(index)

//            if (!quizMainActivity.checkForInternet(requireContext())) {
//                return
//            }


            val shuffleList: LiveData<List<QuizMain>> = quizMainActivity.baseViewModel.shuffleList

            Log.e("TAG", "onViewCreated shuffleList: ${shuffleList.value?.size}")
            shuffleList.observe(viewLifecycleOwner) { list ->

                Log.e("TAG", "onViewCreated: $list")


                if (list == null || list.isEmpty()) {
                    return@observe
                }
                subCount = list[0].list_of_img.size
                val contentSize: Int = list[0].content.size
                val startIndex: Int = (contentSize / subCount) * index
                val endIndex: Int = (index + 1) * (contentSize / subCount)
                contentList = list[0].content.subList(startIndex, endIndex)
                contentList?.let {
                    binding.quizPager.setAdapter(
                        QuizPagerAdapter(
                            this@QuizContainerFragment,
                            contentList!!,
                            index,
                            (100 / (subCount - index).toFloat())
                        )
                    )
                }
            }
            quizMainActivity.allViewModel.getSelectIndex().observe(viewLifecycleOwner) {
                binding.quizPager.setCurrentItem(it, true)
                binding.fiftyJokerLayout.isClickable = true
                val list = contentList ?: return@observe
                binding.textIndicator.text = "${it + 1}/${list.size}"
                if (list.size - 1 == it) {
                    notShowStreak = true
                }
                if (list.size == it && activity != null) {
                    CustomDialogFinish.show(requireActivity(), subCount, binding)
                }
                if (it % 3 == 0) {
                    binding.adContainerQuizStatic.visibility = View.VISIBLE
                } else {
                    binding.adContainerQuizStatic.visibility = View.GONE
                }
            }
            quizMainActivity.allViewModel.getSkipJoker().observe(viewLifecycleOwner) {
                binding.skippJokerLayout.isSelected = it > 0
                val textView = requireActivity().findViewById<TextView>(R.id.pass_joker)
                textView?.text = "($it)"
            }

            quizMainActivity.allViewModel.getFiftyJoker().observe(viewLifecycleOwner) {
                binding.fiftyJokerLayout.isClickable = it != null && it == 2
                binding.fiftyJokerLayout.isSelected = it != null && it > 0
                val textView = requireActivity().findViewById<TextView>(R.id.fifty_joker)
                textView?.text = if (it != null) "($it)" else null
            }

            quizMainActivity.allViewModel.getPoint().observe(viewLifecycleOwner) {
                textView?.setText(it.toString())
                textView2?.setText(it.toString())
            }

            quizMainActivity.allViewModel.getStrikeCount().observe(viewLifecycleOwner) {
                if (notShowStreak) return@observe
                require(it != null)
                when {
                    it < 0 && it % 3 == 0 -> ProgressDialog.show(requireActivity(), 1)
                    it > 0 && it % 10 == 0 -> ProgressDialog.show(requireActivity(), 2)
                    it > 0 && it % 5 == 0 -> ProgressDialog.show(requireActivity(), 0)
                }
            }


            binding.fiftyJokerLayout.setOnClickListener(View.OnClickListener { view2 ->
                val value: Int? = quizMainActivity.allViewModel.getFiftyJoker().getValue()
                if (value != null) {
                    if (value > 0) {
                        val childFragmentManager: FragmentManager = getChildFragmentManager()
                        val sb2 = StringBuilder()
                        sb2.append('f')
                        sb2.append(binding.quizPager.getCurrentItem())
                        val findFragmentByTag: Fragment? =
                            childFragmentManager.findFragmentByTag(sb2.toString())
                        (findFragmentByTag as QuizFragment).fiftyJokerApply()
                    }
                }
            })

        }
    }
}