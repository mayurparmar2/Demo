package com.maps.radar.trafficappfordriving.offlinemap.model;

import com.google.gson.Gson;
import com.maps.radar.trafficappfordriving.offlinemap.model.PoiParserDatas;

import java.util.ArrayList;
import java.util.Iterator;

import org.osmdroid.bonuspack.utils.BonusPackHelper;
import org.osmdroid.util.GeoPoint;

public final class PoiProvider {

    /* renamed from: a */
    public static final PoiProvider f7326a = new PoiProvider();

//    public final ArrayList<PoiParserDatas> a(String url, String userAgent) {
//        ArrayList<PoiParserDatas> arrayList;
//        ArrayList<Double> arrayList2;
//        String str;
//        String str2;
//        String str3;
//        String str4;
//        String str5;
//        String str6;
//        String str7;
//        String str8;
//        String str9;
//        Double valueOf;
//        Double valueOf2;
//        String e10;
//        String g10;
//        String b10;
//        String h10;
//        String a10;
//        String c10;
//        String i10;
//        String d10;
//        String f10;
//        try {
//            PoiParserDatasRes c1534f = (PoiParserDatasRes) new Gson().fromJson(BonusPackHelper.requestStringFromUrl(url, userAgent), PoiParserDatasRes.class);
//            ArrayList<PoiParserDatas> arrayList3 = new ArrayList<>();
//            if (c1534f != null) {
//                arrayList = c1534f.getFeatures();
//            } else {
//                arrayList = null;
//            }
//            if (arrayList != null) {
//                for (Iterator it = c1534f.getFeatures().iterator(); it.hasNext(); it = it) {
//                    PoiParserDatas poiParserDatas = (PoiParserDatas) it.next();
//                    C1535g a11 = poiParserDatas.a();
//                    if (a11 != null) {
//                        arrayList2 = a11.a();
//                    } else {
//                        arrayList2 = null;
//                    }
//                    C1536h b11 = poiParserDatas.b();
//                    if (b11 == null || (f10 = b11.f()) == null) {
//                        str = "";
//                    } else {
//                        str = f10;
//                    }
//                    if (b11 == null || (d10 = b11.d()) == null) {
//                        str2 = "";
//                    } else {
//                        str2 = d10;
//                    }
//                    if (b11 == null || (i10 = b11.i()) == null) {
//                        str3 = "";
//                    } else {
//                        str3 = i10;
//                    }
//                    if (b11 == null || (c10 = b11.c()) == null) {
//                        str4 = "";
//                    } else {
//                        str4 = c10;
//                    }
//                    if (b11 == null || (a10 = b11.a()) == null) {
//                        str5 = "";
//                    } else {
//                        str5 = a10;
//                    }
//                    if (b11 == null || (h10 = b11.h()) == null) {
//                        str6 = "";
//                    } else {
//                        str6 = h10;
//                    }
//                    if (b11 == null || (b10 = b11.b()) == null) {
//                        str7 = "";
//                    } else {
//                        str7 = b10;
//                    }
//                    if (b11 == null || (g10 = b11.g()) == null) {
//                        str8 = "";
//                    } else {
//                        str8 = g10;
//                    }
//                    if (b11 == null || (e10 = b11.e()) == null) {
//                        str9 = "";
//                    } else {
//                        str9 = e10;
//                    }
//                    if (arrayList2 == null || (valueOf = arrayList2.get(1)) == null) {
//                        valueOf = Double.valueOf(0.0d);
//                    }
//                    double doubleValue = valueOf.doubleValue();
//                    if (arrayList2 == null || (valueOf2 = arrayList2.get(0)) == null) {
//                        valueOf2 = Double.valueOf(0.0d);
//                    }
//                    ArrayList<PoiParserDatas> arrayList4 = arrayList3;
//                    arrayList4.add(new PoiParserDatas(str, str2, str3, str4, str5, str6, str7, str8, new GeoPoint(doubleValue, valueOf2.doubleValue()), str9));
//                    arrayList3 = arrayList4;
//                }
//                ArrayList<PoiParserDatas> arrayList5 = arrayList3;
//                Iterator<PoiParserDatas> it2 = arrayList5.iterator();
//                return arrayList5;
//            }
//            return arrayList3;
//        } catch (Exception e11) {
//            return new ArrayList<>();
//        }
//    }
}