package com.maps.radar.trafficappfordriving.ui.base

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.CallSuper
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import androidx.viewbinding.ViewBinding
import com.demo.radar.trafficappfordriving2.R
import kotlinx.coroutines.launch
import kotlin.reflect.KFunction3

abstract class BaseFragment<VB : ViewBinding>(
    private val inflater: KFunction3<LayoutInflater, ViewGroup, Boolean, VB>,
) : Fragment() {

    var binding: VB? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        binding = this.inflater.invoke(inflater, container!!, false)
        return binding?.root
    }

    @CallSuper
    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }

    fun attachRecyclerView(
        recyclerView: RecyclerView,
        adapter: RecyclerView.Adapter<*>,
        layoutManager: RecyclerView.LayoutManager,
    ) {
        recyclerView.adapter = adapter
        recyclerView.layoutManager = layoutManager
    }

    fun attachBackButton(back: View) {
        back.setOnClickListener {
            Navigation.findNavController(back).popBackStack()
        }
    }

    fun attachToolbarButton(back: View, home: View) {
        back.setOnClickListener {
            Navigation.findNavController(back).popBackStack()
        }
        home.setOnClickListener {
            Navigation.findNavController(home).popBackStack(R.id.homeFragment, false)
        }
    }

    fun withBinding(block: (VB) -> Unit) {
        binding?.let { block(it) }
    }

    fun detachRecyclerView(recyclerView: RecyclerView) {
        recyclerView.adapter = null
        recyclerView.layoutManager = null
    }

//    fun <T> observeCurrentBackStackKey(key: String, initial: T, observer: (T) -> Unit) {
//        lifecycleScope.launch {
//            val currentBackStackEntry = findNavController().currentBackStackEntry
//            val savedStateHandle = currentBackStackEntry?.savedStateHandle
//            val stateFlow = savedStateHandle?.getStateFlow(key, initial)
//            stateFlow?.collect { value ->
//                observer(value)
//            }
//        }
//    }

    fun <T> observeFlow(flow: kotlinx.coroutines.flow.Flow<T>, observer: (T) -> Unit) {
        lifecycleScope.launch {
            flow.collect { value ->
                observer(value)
            }
        }
    }
}
