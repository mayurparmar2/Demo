package com.maps.radar.trafficappfordriving
import android.app.Application
public  class App : Application() {



    companion object {
        val appInstance: App get() = App()
    }
}