package com.maps.radar.trafficappfordriving.ui.guide

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation.findNavController
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.FragmentGuideDetailBinding
import com.maps.radar.trafficappfordriving.model.GuideItem
import com.maps.radar.trafficappfordriving.ui.guide.model.Guide

class GuideDetailFragment : Fragment() {

    private var _binding: FragmentGuideDetailBinding? = null
    private val binding get() = _binding!!


    var items: GuideItem? = null
    var groupId: Int? = 0


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentGuideDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        items = arguments?.getParcelable<GuideItem>("guideId")
        groupId = arguments?.getInt("groupId")
        updateFavIcon()


        val adapter = GuideDetailAdapter(groupId!!, id)
        binding.items.adapter = adapter
        items?.let {
            binding.name.text = items!!.name.toString()
            binding.title.text = items!!.title.toString()
            if (items!!.getGuides().isNotEmpty()) {
                adapter.submitList(items?.getGuides())
            }
        }




        binding.apply {
            back.setOnClickListener {
                findNavController(it).popBackStack()
            }
            like.setOnClickListener { toggleLike() }
            share.setOnClickListener { shareApp() }
//            binding.items.adapter = adapter
        }
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }


    private fun toggleLike() {
        val isLiked = GuideLikePref.getInstance(requireContext()).isLiked(groupId!!, items!!.id)
        GuideLikePref.getInstance(requireContext()).setLiked(groupId!!, items!!.id, !isLiked)
        updateFavIcon()
    }

    private fun updateFavIcon() {
        val iconRes =
            if (GuideLikePref.getInstance(requireContext()).isLiked(groupId!!, items!!.id)) {
                R.drawable.ic_guide_liked
            } else {
                R.drawable.ic_guide_like_btn
            }
        binding.like.setImageResource(iconRes)
    }

    private fun shareApp() {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(
                Intent.EXTRA_TEXT,
                "https://play.google.com/store/apps/details?id=${requireContext().packageName}"
            )
        }
        startActivity(Intent.createChooser(intent, null))
    }

}