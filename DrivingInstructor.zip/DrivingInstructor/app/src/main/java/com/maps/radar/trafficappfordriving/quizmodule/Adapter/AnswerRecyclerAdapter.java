package com.maps.radar.trafficappfordriving.quizmodule.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.demo.radar.trafficappfordriving2.databinding.AnswerLayoutImageBinding;
import com.demo.radar.trafficappfordriving2.databinding.AnswerLayoutSoundBinding;
import com.demo.radar.trafficappfordriving2.databinding.AnswerLayoutTextBinding;
import com.maps.radar.trafficappfordriving.model.QuizMain;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AnswerRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<QuizMain.QuestionAns> listOfAnswer;
    private ItemClickListener listener;
    private OnPlayClickListener onPlayListener;
    private String listOfElements = "ABCDEFGHIJKLMNOPRSTYUVYZ";

    public AnswerRecyclerAdapter(ItemClickListener listener, int itemCount) {
        this.listener = listener;
        this.listOfAnswer = new ArrayList<>();
    }

    @Override
    public int getItemCount() {
        return listOfAnswer.size();
    }

    @Override
    public int getItemViewType(int position) {
        String type = listOfAnswer.get(position).getType();
        if (type.equals("TEXT")) {
            return 0;
        } else if (type.equals("IMAGE")) {
            return 1;
        } else if (type.equals("AUDIO")) {
            return 2;
        } else {
            return -1;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        if (viewType == 0) {
            AnswerLayoutTextBinding binding = AnswerLayoutTextBinding.inflate(inflater, parent, false);
            binding.getRoot().getLayoutParams().height = parent.getHeight() / listOfAnswer.size();
            binding.getRoot().requestLayout();
            return new TextViewHolder(binding);
        } else if (viewType == 1) {
            AnswerLayoutImageBinding binding = AnswerLayoutImageBinding.inflate(inflater, parent, false);
            return new ImageViewHolder(binding);
        } else if (viewType == 2) {
            AnswerLayoutSoundBinding binding = AnswerLayoutSoundBinding.inflate(inflater, parent, false);
            return new SoundViewHolder(binding);
        } else {
            throw new IllegalArgumentException("Invalid type");
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        QuizMain.QuestionAns question = listOfAnswer.get(position);
        if (holder instanceof TextViewHolder) {
            ((TextViewHolder) holder).bind(question);
        } else if (holder instanceof ImageViewHolder) {
            ((ImageViewHolder) holder).bind(question, listener);
        } else if (holder instanceof SoundViewHolder) {
            ((SoundViewHolder) holder).bind(question, listener, onPlayListener);
        }
    }

    public void setData(List<QuizMain.QuestionAns> data) {
        listOfAnswer = data;
        notifyDataSetChanged();
    }

    public void setOnPlayListener(OnPlayClickListener onPlayClickListener) {
        onPlayListener = onPlayClickListener;
    }

    private class TextViewHolder extends RecyclerView.ViewHolder {
        private AnswerLayoutTextBinding binding;

        public TextViewHolder(AnswerLayoutTextBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
            binding.rootBg.setOnClickListener(v -> {
                listener.onItemClick(getAdapterPosition());
            });
//            binding.answerLayoutText.setOnClickListener(v -> {
//
//                listener.onItemClick(getAdapterPosition());
//            });
        }

        public void bind(QuizMain.QuestionAns question) {
            binding.answerLayoutText.setText(question.getContent().getText());
            if (Locale.getDefault().getLanguage().equals("en")) {
                binding.answerLayoutText.setText(question.getContent().getText());
                return;
            }
            String text;
            Map<String, String> text_map = question.getContent().getText_map();
            if (text_map == null || (text = text_map.get(Locale.getDefault().getLanguage())) == null) {
                text = question.getContent().getText();
            }
            binding.answerLayoutText.setText(text);



        }
    }

    private class ImageViewHolder extends RecyclerView.ViewHolder {
        private AnswerLayoutImageBinding binding;

        public ImageViewHolder(AnswerLayoutImageBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(QuizMain.QuestionAns question, ItemClickListener listener) {
            Glide.with(binding.answerLayoutImage.getContext()).load(question.getContent().getImage_url()).into(binding.answerLayoutImage);
            binding.answerBoxesOpt.setText(String.valueOf(listOfElements.charAt(getAdapterPosition())));
            itemView.setOnClickListener(v -> listener.onItemClick(getAdapterPosition()));
        }
    }

    private class SoundViewHolder extends RecyclerView.ViewHolder {
        private AnswerLayoutSoundBinding binding;

        public SoundViewHolder(AnswerLayoutSoundBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(QuizMain.QuestionAns question, ItemClickListener listener, OnPlayClickListener onPlayClickListener) {
            binding.answerBoxesOpt.setText(String.valueOf(listOfElements.charAt(getAdapterPosition())));
            binding.answerPlayBtnSound.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    onPlayClickListener.onPlay(binding.answerPlayBtnSound, question.getContent().getAudio_url(), true);
                } else {
                    onPlayClickListener.onPlay(binding.answerPlayBtnSound, question.getContent().getAudio_url(), false);
                }
            });
            itemView.setOnClickListener(v -> listener.onItemClick(getAdapterPosition()));
        }
    }
}