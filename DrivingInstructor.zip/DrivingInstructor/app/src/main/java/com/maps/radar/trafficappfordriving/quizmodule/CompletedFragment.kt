package com.maps.radar.trafficappfordriving.quizmodule

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.FragmentCompletedBinding
import com.maps.radar.trafficappfordriving.quizmodule.Adapter.ProgressRecyclerAdapter


class CompletedFragment : Fragment() {
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentCompletedBinding.inflate(inflater, container, false)
        return binding.root
    }

    private var _binding: FragmentCompletedBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        val adapter = ProgressRecyclerAdapter(ProgressRecyclerAdapter.OnItemClickListener { index ->
            val bundle = Bundle()
            bundle.putInt("index",index)
            findNavController(binding.root).navigate(R.id.action_completedFragment_to_quiz_ContainerFragment, bundle)
        })

        QuizMainActivity.instance.viewModelDb.allDoneData.observe(viewLifecycleOwner) { items ->
            Log.e("TAG", "onViewCreated allProgressItem: $items")

            if (items.isEmpty()) {
                binding.noContentView.visibility = View.VISIBLE
                binding.progressRw.visibility = View.GONE
            } else {
                adapter.setData(items)
                binding.noContentView.visibility = View.GONE
                binding.progressRw.visibility = View.VISIBLE
            }
        }

        binding.progressRw.adapter = adapter
        binding.noTestBtn.setOnClickListener { v ->
            NavHostFragment.findNavController(this).navigateUp()
        }
    }


}