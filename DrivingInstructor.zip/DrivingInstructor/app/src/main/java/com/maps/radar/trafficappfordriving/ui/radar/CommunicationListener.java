package com.maps.radar.trafficappfordriving.ui.radar;

/* compiled from: CommunicationListener.kt */
/* loaded from: classes4.dex */
public interface CommunicationListener {
    void locationPermission(boolean z10);

    void onServiceClosed();
}