package com.maps.radar.trafficappfordriving.quizmodule.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.demo.radar.trafficappfordriving2.databinding.AnswerLayoutImageBinding
import com.demo.radar.trafficappfordriving2.databinding.AnswerLayoutSoundBinding
import com.demo.radar.trafficappfordriving2.databinding.AnswerLayoutTextBinding
import com.maps.radar.trafficappfordriving.model.QuizMain
import java.util.Locale

class OrderAnswerRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    public val answers = mutableListOf<QuizMain.QuestionAns>()
    private val correctAnswers = mutableMapOf<Int, RecyclerView.ViewHolder>()
    private var playClickListener: OnPlayClickListener? = null

    override fun getItemCount() = answers.size

    override fun getItemViewType(position: Int): Int {
        return when (answers[position].type) {
            "TEXT" -> TYPE_TEXT
            "AUDIO" -> TYPE_SOUND
            "IMAGE" -> TYPE_IMAGE
            else -> -1
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            TYPE_TEXT -> TextViewHolder(AnswerLayoutTextBinding.inflate(LayoutInflater.from(parent.context), parent, false))
            TYPE_IMAGE -> ImageViewHolder(AnswerLayoutImageBinding.inflate(LayoutInflater.from(parent.context), parent, false))
            TYPE_SOUND -> SoundViewHolder(AnswerLayoutSoundBinding.inflate(LayoutInflater.from(parent.context), parent, false))
            else -> throw IllegalArgumentException("Invalid type")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val question = answers[position]
        when (holder) {
            is TextViewHolder -> holder.bind(question)
            is ImageViewHolder -> holder.bind(question)
            is SoundViewHolder -> holder.bind(question, playClickListener)
        }
        holder.itemView.tag = holder
    }

    fun setData(data: List<QuizMain.QuestionAns>) {
        answers.apply {
            clear()
            addAll(data)
        }
        notifyDataSetChanged()
    }

    fun setOnPlayListener(listener: OnPlayClickListener) {
        playClickListener = listener
    }

    fun swapItems(from: Int, to: Int) {
        answers.add(to, answers.removeAt(from))
        notifyItemMoved(from, to)
    }

    private inner class TextViewHolder(private val binding: AnswerLayoutTextBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(question: QuizMain.QuestionAns) {
            binding.answerLayoutText.text = question.content.text_map?.get(Locale.getDefault().language)
                ?: question.content.text
            binding.orderIcon.visibility = View.VISIBLE
            correctAnswers[adapterPosition] = this
        }
    }

    private inner class ImageViewHolder(private val binding: AnswerLayoutImageBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(question: QuizMain.QuestionAns) {
            Glide.with(binding.answerLayoutImage.context)
                .load(question.content.image_url)
                .into(binding.answerLayoutImage)
            binding.answerBoxesOpt.visibility = View.GONE
            binding.orderIcon.visibility = View.VISIBLE
            correctAnswers[adapterPosition] = this
        }
    }

    private inner class SoundViewHolder(private val binding: AnswerLayoutSoundBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(question: QuizMain.QuestionAns, listener: OnPlayClickListener?) {
            binding.answerPlayBtnSound.setOnCheckedChangeListener { button, isChecked ->
                listener?.let { listener ->
                    val url = question.content.audio_url
                    if (isChecked) listener.onPlay(button, url, false) else listener.onPlay(button, url, true)
                }
            }
            binding.answerBoxesOpt.visibility = View.GONE
            binding.orderIcon.visibility = View.VISIBLE
            correctAnswers[adapterPosition] = this
        }
    }



    companion object {
        private const val TYPE_TEXT = 0
        private const val TYPE_IMAGE = 1
        private const val TYPE_SOUND = 2
    }
}
