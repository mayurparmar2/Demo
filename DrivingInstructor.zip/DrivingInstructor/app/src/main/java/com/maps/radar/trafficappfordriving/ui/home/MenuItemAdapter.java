package com.maps.radar.trafficappfordriving.ui.home;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.DrawableRes;
import androidx.annotation.StringRes;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.demo.radar.trafficappfordriving2.R;
import com.demo.radar.trafficappfordriving2.databinding.ListItemHomeBinding;

import java.util.Arrays;
import java.util.List;

public class MenuItemAdapter extends RecyclerView.Adapter<MenuItemAdapter.MenuItemViewHolder> {
    private List<MenuItem> items;
    private final OnItemClickListener listener;

    public MenuItemAdapter(OnItemClickListener listener) {
        this.listener = listener;
        this.items = getMenuList();
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    @Override
    public void onBindViewHolder(MenuItemViewHolder holder, int position) {
        holder.bind(items.get(position));
    }

    @Override
    public MenuItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        ListItemHomeBinding binding = ListItemHomeBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new MenuItemViewHolder(this, binding);
    }


    public final List<MenuItem> getMenuList() {
        return Arrays.asList(
                new MenuItem(EnumMenuItem.DRIVING_TEST, R.drawable.drivingimg_driving_test, R.string.driving_test_questions, EnumPosition.START),
                new MenuItem(EnumMenuItem.TRAFFIC_SIGN, R.drawable.drivingimg_traffic_sign, R.string.traffic_sign, EnumPosition.START),
                new MenuItem(EnumMenuItem.CAR_CONTROL, R.drawable.drivingimg_car_control, R.string.car_controls, EnumPosition.START),
                new MenuItem(EnumMenuItem.DRIVING_TIPS_TRICKS, R.drawable.drivingimg_tips, R.string.driving_tips_and_tricks, EnumPosition.START),
                new MenuItem(EnumMenuItem.DRIVING_GUIDELINE, R.drawable.drivingimg_driving_guideline, R.string.driving_guideline, EnumPosition.START),
                new MenuItem(EnumMenuItem.RADAR_DETECTOR, R.drawable.drivingimg_camera, R.string.radar_camera_detector, EnumPosition.START),
                new MenuItem(EnumMenuItem.HUD, R.drawable.drivingimg_hup, R.string.head_up_display, EnumPosition.START),
                new MenuItem(EnumMenuItem.OFFLINE_MAPS, R.drawable.drivingimg_offline_maps, R.string.offline_maps, EnumPosition.START),
                new MenuItem(EnumMenuItem.POLICE_SIGN, R.drawable.drivingimg_police, R.string.police_sign, EnumPosition.END),
                new MenuItem(EnumMenuItem.INDICATORS, R.drawable.drivingimg_indicators, R.string.driving_indicators, EnumPosition.START),
                new MenuItem(EnumMenuItem.DRIVING_LICENSES, R.drawable.drivingimg_driving_licenses, R.string.driving_licenses, EnumPosition.START),
                new MenuItem(EnumMenuItem.HOW_TO_DO, R.drawable.drivingimg_how_to_do, R.string.driving_how_to_do, EnumPosition.START)
        );
    }


    public static class MenuItemViewHolder extends RecyclerView.ViewHolder {
        private final ListItemHomeBinding binding;
        private final MenuItemAdapter adapter;

        public MenuItemViewHolder(MenuItemAdapter adapter, ListItemHomeBinding binding) {
            super(binding.getRoot());
            this.adapter = adapter;
            this.binding = binding;
        }

        public void bind(MenuItem item) {
            binding.getRoot().setOnClickListener(v -> adapter.listener.onItemClick(item));
            binding.icon.setImageResource(item.getIconRes());
//            binding.icon.setLayoutParams(getLayoutParams(item.getPosition()));
            binding.menuName.setText(item.getNameRes());
        }

        private ConstraintLayout.LayoutParams getLayoutParams(EnumPosition position) {
            ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.horizontalBias = position.getHorizontalBias();
            return params;
        }
    }

    public interface OnItemClickListener {
        void onItemClick(MenuItem item);
    }

    public static class MenuItem {
        public EnumMenuItem enumMenuItem ;
        private int iconRes;
        private int nameRes;
        private EnumPosition position;

        public MenuItem(EnumMenuItem menu, @DrawableRes int iconRes, @StringRes int nameRes, EnumPosition position) {
            this.enumMenuItem  = menu;
            this.iconRes = iconRes;
            this.nameRes = nameRes;
            this.position = position;
        }

        public int getIconRes() {
            return iconRes;
        }

        public int getNameRes() {
            return nameRes;
        }

        public EnumPosition getPosition() {
            return position;
        }
    }

    public enum EnumMenuItem {
        DRIVING_TEST,
        TRAFFIC_SIGN,
        CAR_CONTROL,
        DRIVING_TIPS_TRICKS,
        DRIVING_GUIDELINE,
        RADAR_DETECTOR,
        HUD,
        OFFLINE_MAPS,
        POLICE_SIGN,
        INDICATORS,
        DRIVING_LICENSES,
        HOW_TO_DO

    }

    public enum EnumPosition {
        START(0.0f),
        END(1.0f);

        private final float horizontalBias;

        EnumPosition(float horizontalBias) {
            this.horizontalBias = horizontalBias;
        }

        public float getHorizontalBias() {
            return horizontalBias;
        }
    }
}