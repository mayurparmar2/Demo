package com.maps.radar.trafficappfordriving.ui.hupd;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public final class LocationUpdatesService extends Service {

    private static final String CHANNEL_ID = "VERBOSE_NOTIFICATION";
    private static final String TAG = "LocationUpdatesService";
    private static final long LOCATION_INTERVAL = 2000;
    private static final float LOCATION_DISTANCE = 20.0f;
    private static final String NOTIFICATION_TITLE = String.format(Locale.ENGLISH, "Radar : %s", DateFormat.getDateInstance().format(new Date()));


    private LocationManager locationManager;
    private NotificationManager notificationManager;
    private Location currentLocation;
    private final IBinder binder = new LocationBinder();
    private final ArrayList<LocationUpdateListener> listenerArrayList = new ArrayList<>();
    private final LocationListener[] locationListeners = new LocationListener[]{
            new SimpleLocationListener("gps"),
            new SimpleLocationListener("network")
    };

    public class LocationBinder extends Binder {
        public LocationUpdatesService getService() {
            return LocationUpdatesService.this;
        }
    }

    private class SimpleLocationListener implements LocationListener {
        private final String provider;

        SimpleLocationListener(String provider) {
            this.provider = provider;
        }

        @Override
        public void onLocationChanged(Location location) {
            currentLocation = location;
            for (LocationUpdateListener listener : listenerArrayList) {
                listener.onLocationChanged(location);
            }
        }

        @Override
        public void onProviderDisabled(String provider) {
            Log.d(TAG, provider + " disabled");
        }

        @Override
        public void onProviderEnabled(String provider) {
            Log.d(TAG, provider + " enabled");
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
            Log.d(TAG, provider + " status changed: " + status);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopLocationUpdates();
        listenerArrayList.clear();
        notificationManager = null;
    }

    @SuppressLint("MissingPermission")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        initializeLocationManager();
        requestLocationUpdates();
        startForeground(161234, createNotification());
        return START_STICKY;
    }

    private void initializeLocationManager() {
        if (locationManager == null) {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        }
    }

    @SuppressLint("MissingPermission")
    private void requestLocationUpdates() {
        try {
            locationManager.requestLocationUpdates("gps", LOCATION_INTERVAL, LOCATION_DISTANCE, locationListeners[0]);
            locationManager.requestLocationUpdates("network", LOCATION_INTERVAL, LOCATION_DISTANCE, locationListeners[1]);
        } catch (IllegalArgumentException e) {
            Log.e(TAG, "Network provider does not exist: " + e.getMessage());
        } catch (SecurityException e) {
            Log.e(TAG, "Failed to request location updates", e);
        }
    }

    private void stopLocationUpdates() {
        if (locationManager != null) {
            for (LocationListener listener : locationListeners) {
                if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0 ||
                        ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
                    locationManager.removeUpdates(listener);
                }
            }
        }
    }


    public final void c(LocationUpdateListener listener) {
        if (this.currentLocation != null) {
            listener.onLocationChanged(this.currentLocation);
        }
        this.listenerArrayList.add(listener);
    }

    public final void h() {
        startService(new Intent(getApplicationContext(), (Class<?>) LocationUpdatesService.class));
        i();
    }

    public final void i() {
        if (this.notificationManager == null) {
            this.notificationManager  = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel notificationChannel = new NotificationChannel("VERBOSE_NOTIFICATION",
                        this.NOTIFICATION_TITLE, NotificationManager.IMPORTANCE_LOW);
                notificationChannel.setSound(null, null);
                notificationChannel.enableVibration(false);
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }
        startForeground(161234, d(this));
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(161234, d(this), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(161234, d(this));
        }
        f6171m = true;
    }
    public String f6178f;
    public static boolean f6171m;


    public  Notification d(Context context) {
        Intent intent = new Intent();
        @SuppressLint("WrongConstant") NotificationCompat.Builder when = new NotificationCompat.
                Builder(context, "VERBOSE_NOTIFICATION")
                .setContentText(this.f6178f)
                .setContentTitle(NOTIFICATION_TITLE)
                .setOngoing(true
                ).setSilent(true)
                .setContentIntent(PendingIntent.getActivity(context, 0, intent, 201326592))
                .setPriority(-1)
                .setTicker(this.f6178f)
                .setDefaults(4)
                .setWhen(System.currentTimeMillis());

        when.setChannelId("VERBOSE_NOTIFICATION");
        Notification build = when.build();
        return build;
    }

    private Notification createNotification() {
        if (notificationManager == null) {
            notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, NOTIFICATION_TITLE, NotificationManager.IMPORTANCE_LOW);
                channel.setSound(null, null);
                channel.enableVibration(false);
                notificationManager.createNotificationChannel(channel);
            }
        }
        Intent intent = new Intent();
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(NOTIFICATION_TITLE)
                .setContentText("Location service running")
                .setOngoing(true)
                .setSilent(true)
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setWhen(System.currentTimeMillis())
                .build();
    }


    public final void j() {
        this.currentLocation = null;
        this.listenerArrayList.clear();
        stopForeground(Service.STOP_FOREGROUND_REMOVE);
        onDestroy();
    }

}
