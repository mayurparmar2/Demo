package com.maps.radar.trafficappfordriving.ui.radar.viewmodel


import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

class AppDataStore(private val context: Context) {

    private val Context.dataStore by preferencesDataStore(name = "app_preferences")

    suspend fun get(key: String): String? {
        val preferencesKey = stringPreferencesKey(key)
        val preferences = context.dataStore.data.first()
        return preferences[preferencesKey]
    }

    suspend fun isDataLoaded(): Boolean {
        val preferences = context.dataStore.data.first()
        return preferences.contains(stringPreferencesKey("APP_INIT"))
    }

    suspend fun save(key: String, value: String) {
        context.dataStore.edit { preferences ->
            preferences[stringPreferencesKey(key)] = value
        }
    }

    suspend fun save(key: String, value: Int?) {
        context.dataStore.edit { preferences ->
            value?.let { preferences[intPreferencesKey(key)] = it }
        }
    }

    suspend fun initialize() {
        context.dataStore.edit { preferences ->
            preferences[booleanPreferencesKey("APP_INIT")] = true
        }
    }
}


//
//class AppDataStore(private val context: Context) {
//
//    companion object {
//        private val Context.dataStore by preferencesDataStore("settings_data_store")
//        val APP_INIT_KEY = booleanPreferencesKey("APP_INIT")
//    }
//
//    suspend fun isInitialized(): Boolean {
//        return context.dataStore.data.map { preferences ->
//            preferences[APP_INIT_KEY] ?: false
//        }.first()
//    }
//
//    suspend fun saveBooleanValue(key: Preferences.Key<Boolean>, value: Boolean) {
//        context.dataStore.edit { preferences ->
//            preferences[key] = value
//        }
//    }
//
//    suspend fun getStringValue(key: Preferences.Key<String>): String? {
//        return context.dataStore.data.map { preferences ->
//            preferences[key]
//        }.first()
//    }
//
//    suspend fun saveStringValue(key: Preferences.Key<String>, value: String) {
//        context.dataStore.edit { preferences ->
//            preferences[key] = value
//        }
//    }
//
//    suspend fun saveIntValue(key: Preferences.Key<Int>, value: Int) {
//        context.dataStore.edit { preferences ->
//            preferences[key] = value
//        }
//    }
//}
