package com.maps.radar.trafficappfordriving.utils;

public class RemoteConfigUtils {
    public static final RemoteConfigUtils f5880a = new RemoteConfigUtils();
    private final String TAG = "RemoteConfigUtils";



}
