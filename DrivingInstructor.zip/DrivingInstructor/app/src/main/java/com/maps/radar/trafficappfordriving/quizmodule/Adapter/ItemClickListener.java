package com.maps.radar.trafficappfordriving.quizmodule.Adapter;

/* compiled from: ItemClickListener.kt */
/* loaded from: classes2.dex */
public interface ItemClickListener {
    void onItemClick(int i10);
}