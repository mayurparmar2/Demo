package com.maps.radar.trafficappfordriving.offlinemap;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.demo.radar.trafficappfordriving2.databinding.OfflineMapsFragmentItemBinding;
import com.maps.radar.trafficappfordriving.offlinemap.model.PlaceholderContent.PlaceholderItem;

import java.util.List;

public final class CategoryPoiAdapter extends RecyclerView.Adapter<CategoryPoiAdapter.ViewHolder> {
    private final List<PlaceholderItem> values;
    private final OnItemClickListener onItemClick;

    public CategoryPoiAdapter(List<PlaceholderItem> values, OnItemClickListener onItemClick) {
        this.values = values;
        this.onItemClick = onItemClick;
    }

    public interface OnItemClickListener {
        void onItemClick(String category, int iconResId);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final OfflineMapsFragmentItemBinding binding;

        public ViewHolder(OfflineMapsFragmentItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public OfflineMapsFragmentItemBinding getBinding() {
            return binding;
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        OfflineMapsFragmentItemBinding binding = OfflineMapsFragmentItemBinding.inflate(inflater, parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PlaceholderItem item = values.get(position);
        holder.getBinding().itemPoiImage.setImageResource(item.getImageResource());
        holder.getBinding().title.setText(holder.itemView.getContext().getString(item.getTitleResource()));
        holder.itemView.setOnClickListener(view -> onItemClick(item, position));
    }

    private void onItemClick(PlaceholderItem item, int position) {
        String category;
        switch (position) {
            case 2: category = "shop:coffee"; break;
            case 4: category = "shop:supermarket"; break;
            case 6: category = "tourism:hotel"; break;
            case 10: category = "amenity:bus_station"; break;
            case 11: category = "amenity:internet_cafe"; break;
            default: category = "amenity:" + item.getAmenity(); break;
        }
        onItemClick.onItemClick(category, item.getImageResource());
    }

    @Override
    public int getItemCount() {
        return values.size();
    }
}
