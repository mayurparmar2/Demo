package com.maps.radar.trafficappfordriving.ui.guide

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.FragmentDrivingGuideBinding
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import com.google.gson.reflect.TypeToken
import com.maps.radar.trafficappfordriving.model.GuideGroup
import java.io.IOException

class GuideFragment : Fragment() {
    private var _binding: FragmentDrivingGuideBinding? = null
    private val binding get() = _binding!!




    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDrivingGuideBinding.inflate(inflater, container, false)
        return binding.root
    }
    var groupId:Int = -1

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val nav = NavHostFragment.findNavController(this)

        binding.back.setOnClickListener(View.OnClickListener { view2 ->
            findNavController(view2).popBackStack()
        })
        groupId = requireArguments().getInt("groupId")

        try {
            val gson = Gson()
            val jsonString = readJsonFromAssets(requireContext(), "driving_guide.json5")
            val type = object : TypeToken<List<GuideGroup>>() {}.type
            val guideGroup = gson.fromJson<List<GuideGroup>>(jsonString, type)
            Log.e("TAG", "onViewCreated: $guideGroup")
            Log.e("TAG", "onViewCreated: ${guideGroup.get(groupId).items.toString()}")
            val adapter =  GuideGroupAdapter(guideGroup.get(groupId).groupId, listener = {item->
                val bundle = Bundle()
                bundle.putParcelable("guideId", item)
                bundle.putInt("groupId", guideGroup.get(groupId).groupId)
                nav.navigate(R.id.guideDetailFragment, bundle)
            })
            binding.items.setAdapter(adapter)
            adapter.submitList(guideGroup.get(groupId).items)
        } catch (e: JsonSyntaxException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    fun readJsonFromAssets(context: Context, fileName: String): String? {
        return try {
            context.assets.open(fileName).bufferedReader().use { it.readText() }
        } catch (e: IOException) {
            e.printStackTrace()
            Log.e("TAG", "readJsonFromAssets IOException: ${e.message}")
            null
        }
    }


}