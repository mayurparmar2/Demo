package com.maps.radar.trafficappfordriving.Db

import androidx.annotation.Keep
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Keep
@Entity(indices = [Index(unique = true, value = ["index"])], tableName = "quiz_progress_table")
data class QuizProgressItem(
    @PrimaryKey(autoGenerate = false) val index: Int,
    val progress: Float,
    val icon: String,
    val title: String
)