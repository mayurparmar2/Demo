package com.maps.radar.trafficappfordriving.ui.guide.model

import com.maps.radar.trafficappfordriving.model.GuideTextItemRes

open class Guide(val id: Int) {
    class ImageGuide(id: Int, val bodyImage: String?, val imageUrl: String?) : Guide(id)
//    class TextGuide(id: Int, val title: String, val lines: List<String>?, val hasBullet: Boolean) : Guide(id)
    class TextGuide(id: Int, val item: GuideTextItemRes) : Guide(id)
    class VideoGuide(id: Int, val videoUrl: String) : Guide(id)
}