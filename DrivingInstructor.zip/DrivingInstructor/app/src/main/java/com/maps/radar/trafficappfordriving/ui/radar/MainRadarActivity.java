package com.maps.radar.trafficappfordriving.ui.radar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import com.demo.radar.trafficappfordriving2.R;
import com.demo.radar.trafficappfordriving2.databinding.RadarActivityMainBinding;

public final class MainRadarActivity extends AppCompatActivity {
    private RadarActivityMainBinding binding;
    private FragmentBridgeViewModel fragmentBridgeViewModel;
    private NavController navController;
    private CommunicationListener communicationListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = RadarActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        fragmentBridgeViewModel = new ViewModelProvider(this).get(FragmentBridgeViewModel.class);
        navController = ((NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.nav_host_fragment_activity_main))
                .getNavController();
    }

    public void setCommunicationListener(CommunicationListener listener) {
        this.communicationListener = listener;
    }
}
