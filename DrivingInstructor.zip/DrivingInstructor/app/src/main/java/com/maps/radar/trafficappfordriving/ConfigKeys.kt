package com.maps.radar.trafficappfordriving

import android.os.Parcel
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class ConfigKeys(
    var bannerEnableKey: String,
    var interstitialEnableKey: String,
    var nativeEnableKey: String
) : Parcelable {

    companion object {
        const val EXTRA_KEY = "config_keys"
    }
}