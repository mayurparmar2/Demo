package com.maps.radar.trafficappfordriving.ui.hupd.fragment;

import android.annotation.SuppressLint;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import com.demo.radar.trafficappfordriving2.databinding.HupdFragmentHudPagerBinding;
import com.google.android.material.tabs.TabLayoutMediator;
import com.maps.radar.trafficappfordriving.ui.hupd.PagerAdapter;

public final class HeadUpDisplayPagerFragment extends Fragment {

    private HupdFragmentHudPagerBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = HupdFragmentHudPagerBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

       PagerAdapter adapter = new PagerAdapter(this);
        binding.viewPager.setAdapter(adapter);
        binding.viewPager.setOffscreenPageLimit(2);
//
//        new TabLayoutMediator(binding.intoTabLayout, binding.viewPager, (tab, position) -> {
//            // Customize tabs if needed
//        }).attach();
    }

    @Override
    public void onStart() {
        super.onStart();
        FragmentActivity activity = getActivity();
        if (activity != null) {
            activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }
    }

    @SuppressLint("WrongConstant")
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding.viewPager.setAdapter(null);
        binding = null;
    }
}
