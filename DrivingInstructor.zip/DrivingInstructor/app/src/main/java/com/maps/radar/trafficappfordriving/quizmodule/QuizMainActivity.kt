package com.maps.radar.trafficappfordriving.quizmodule

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavController
import androidx.navigation.NavDestination
import androidx.navigation.fragment.NavHostFragment
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.ActivityQuizMainBinding
import com.maps.radar.trafficappfordriving.Db.AllViewModel
import com.maps.radar.trafficappfordriving.Db.BaseViewModel
import com.maps.radar.trafficappfordriving.Db.ImplRepository
import com.maps.radar.trafficappfordriving.Db.QuizProgressViewModel
import java.util.concurrent.TimeUnit


class QuizMainActivity : AppCompatActivity(), NavController.OnDestinationChangedListener {
//    val mContext by lazy { this@QuizMainActivity }

    companion object {
        lateinit var instance: QuizMainActivity
    }


    val baseViewModel by lazy { ViewModelProvider(this).get(BaseViewModel::class.java) }
    lateinit var allViewModel :AllViewModel
    val viewModelDb by lazy { ViewModelProvider(this).get(QuizProgressViewModel::class.java) }


    val binding by lazy { ActivityQuizMainBinding.inflate(layoutInflater) }
     var endPointName: String? = null
    private var projectId: String? = null
    private lateinit var navController: NavController

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        instance = this
        allViewModel = ViewModelProvider(this).get(AllViewModel::class.java)

        projectId = intent.getStringExtra("projectId")!!
        endPointName = intent.getStringExtra("endPointId")!!


        val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment_content_quiz_main) as NavHostFragment
        navController = navHostFragment.navController
        navController.addOnDestinationChangedListener(this)


        binding.quizBack.setOnClickListener { onBackPressed() }
        viewModelDb.allProgressItem.observe(this) {
            setAlarm()
        }
    }

    override fun onDestinationChanged(
        controller: NavController,
        destination: NavDestination,
        arguments: Bundle?,
    ) {

        val totalCorrectProgress = ImplRepository.getInstance(this).getProgress2("total_correct_progress")
        val totalProgress = ImplRepository.getInstance(this).getProgress2("total_progress")

        binding.totalCorrectQuizProgress.text = "$totalCorrectProgress%"
        binding.totalQuizProgress.text = "$totalProgress%"

        when (destination.id) {
            R.id.quiz_ContainerFragment -> {
                binding.totalCorrectQuizProgress.visibility = View.GONE
                binding.totalQuizProgress.visibility = View.GONE
                binding.quizBack.visibility = View.VISIBLE
            }
            else -> {
                binding.totalCorrectQuizProgress.visibility = View.VISIBLE
                binding.totalQuizProgress.visibility = View.VISIBLE
                binding.quizBack.visibility = View.GONE
            }
        }

    }

    private fun setAlarm() {
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, QuizReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            this, 109, intent,
            PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            System.currentTimeMillis() + TimeUnit.DAYS.toMillis(1L), pendingIntent
        )
    }
    fun checkForInternet(context: Context): Boolean {
        val connectivityManager =
            context.getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val capabilities = connectivityManager.getNetworkCapabilities(
            connectivityManager.activeNetwork
        )
        return capabilities != null && (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR))
    }

}