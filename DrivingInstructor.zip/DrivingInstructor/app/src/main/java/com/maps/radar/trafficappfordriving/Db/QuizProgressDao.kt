package com.maps.radar.trafficappfordriving.Db

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

//@Dao
//interface QuizProgressDao {
//
//    @Insert(onConflict = OnConflictStrategy.REPLACE)
//    fun addProgressItem(quizProgressItem: QuizProgressItem)
//
//    @Query("SELECT * FROM quiz_progress_table")
//    fun getAllProgressItem(): LiveData<List<QuizProgressItem>>
//
//    @Query("SELECT * FROM quiz_progress_table WHERE is_done = 1")
//    fun getAllDoneData(): LiveData<List<QuizProgressItem>>
//
//    @Query("UPDATE quiz_progress_table SET is_started = 1 WHERE id = :id")
//    fun startTest(id: Int)
//
//    @Query("UPDATE quiz_progress_table SET progress = :progress WHERE id = :id")
//    fun updateProgressItem(id: Int, progress: Float)
//}

@Dao
interface QuizProgressDao {

    //a
    @Query("SELECT * FROM quiz_progress_table WHERE progress = 100")
    fun getAllProgressItem(): LiveData<List<QuizProgressItem>>

    //f
    @Query("SELECT * FROM quiz_progress_table WHERE progress > 0")
    fun getAllDoneData(): LiveData<List<QuizProgressItem>>


    @Query("SELECT COUNT(*) FROM quiz_progress_table WHERE progress > 0")
    fun getCountOfProgress(): Int

    //c
    @Insert(onConflict = 5)
    suspend fun addProgressItem(quizProgressItem: QuizProgressItem)

    //d
    @Query("UPDATE quiz_progress_table SET progress = progress + :newProgress WHERE `index`=:index ")
    suspend fun updateProgressItem(newProgress: Float, index: Int)

    @Query("UPDATE quiz_progress_table SET progress = 0 WHERE `index`=:index ")
    suspend fun startTest(index: Int)
}