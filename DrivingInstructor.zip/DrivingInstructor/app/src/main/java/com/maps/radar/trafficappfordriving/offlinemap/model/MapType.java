package com.maps.radar.trafficappfordriving.offlinemap.model;

import androidx.annotation.Keep;
@Keep
public enum MapType {
    OFFLINE_MAPS,
    MY_LOCATION,
    TRAVEL_GUIDE,
    MAP_LIST
}