package com.maps.radar.trafficappfordriving.Db
import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.maps.radar.trafficappfordriving.model.QuizMain
import com.maps.radar.trafficappfordriving.network.Apis
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class BaseViewModel(app: Application) : AndroidViewModel(app) {

    val _shuffleList = MutableLiveData<List<QuizMain>>()
    val shuffleList: LiveData<List<QuizMain>> get() = _shuffleList



    val correctProgress = getProgress("total_correct_progress").asLiveData()
    val totalProgress = getProgress("total_progress").asLiveData()

    private val apiService = Apis.getInstance()

    fun getShuffle(endPointName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                apiService.getShuffle("64fb2e37aa125e0001bcaeeb").enqueue(object : Callback<List<QuizMain>> {
                    override fun onResponse(call: Call<List<QuizMain>>, response: Response<List<QuizMain>>) {
                        Log.e("TAG", "BaseViewModel :onResponse : "+response.body())
                        response.body()?.let { _shuffleList.postValue(it) }
                    }
                    override fun onFailure(call: Call<List<QuizMain>>, t: Throwable) {
                        Log.e("TAG", "BaseViewModel :onFailure : "+t.message)
                        // Handle error
                    }
                })
            } catch (e: Exception) {
                e.printStackTrace()
                Log.e("TAG", "BaseViewModel :onFailure : "+e.message)
                // Handle exception
            }
        }
    }

    fun saveCorrectProgress(progress: Int) {
        saveProgress("total_correct_progress", progress)
    }

    fun saveTotalProgress(progress: Int) {
        saveProgress("total_progress", progress)
    }

    private fun getProgress(key: String): Flow<Int> {
        return ImplRepository.getInstance(getApplication()).getProgress(key)
//        return FlowLiveDataConversions.asLiveData(getImplRepositoryImpl().getProgress(key))
    }

    private fun saveProgress(key: String, progress: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            ImplRepository.getInstance(getApplication()).saveProgress(key, progress)
        }
    }
}

