package com.maps.radar.trafficappfordriving.ui.hupd;

import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.maps.radar.trafficappfordriving.ui.hupd.fragment.HeadUpDisplayAlternativeFragment;
import com.maps.radar.trafficappfordriving.ui.hupd.fragment.HeadUpDisplayFragment;

public final class PagerAdapter extends FragmentStateAdapter {
    public PagerAdapter(Fragment fr) {
        super(fr);
    }
    @Override
    public Fragment createFragment(int i10) {
        if (i10 != 0) {
            if (i10 == 1) {
                return new HeadUpDisplayAlternativeFragment();
            }
            throw new IllegalArgumentException();
        }
        return new HeadUpDisplayFragment();
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}