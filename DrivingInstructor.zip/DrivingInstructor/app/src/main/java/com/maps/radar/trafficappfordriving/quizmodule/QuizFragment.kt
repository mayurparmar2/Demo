package com.maps.radar.trafficappfordriving.quizmodule

import android.annotation.SuppressLint
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.FragmentQuizBinding
import com.example.quizmodule.adapters.QuestionRecyclerAdapter
import com.maps.radar.trafficappfordriving.model.QuizMain
import com.maps.radar.trafficappfordriving.quizmodule.Adapter.AnswerRecyclerAdapter
import com.maps.radar.trafficappfordriving.quizmodule.Adapter.DragManageAdapter
import com.maps.radar.trafficappfordriving.quizmodule.Adapter.ItemClickListener
import com.maps.radar.trafficappfordriving.quizmodule.Adapter.OnPlayClickListener
import com.maps.radar.trafficappfordriving.quizmodule.Adapter.OrderAnswerRecyclerAdapter
import com.maps.radar.trafficappfordriving.quizmodule.dialog.CustomDialog
import java.io.IOException


class QuizFragment : Fragment(), ItemClickListener {

    companion object {
        fun newInstance(
            position: Int,
            testIndex: Int,
            all: QuizMain.All?,
            questionMark: Float,
        ): Fragment {
            val fragment = QuizFragment()
            val args = Bundle()
            args.putParcelable("all", all)
            args.putInt("testIndex", testIndex)
            args.putFloat("questionMark", questionMark)
            args.putInt("position_arg", position)
            fragment.arguments = args
            return fragment
        }

    }


    private val mediaPlayer = MediaPlayer()


    private lateinit var binding: FragmentQuizBinding
    private var answers: List<QuizMain.QuestionAns> = emptyList()
    private var correctAnswers: List<Int> = emptyList()

    private lateinit var all: QuizMain.All
    private lateinit var digits: List<Int>
    private var testIndex: Int = 0
    private var questionMark: Float = 0f


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentQuizBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            all = it.getParcelable<QuizMain.All>("all") as QuizMain.All
            testIndex = it.getInt("testIndex")
            questionMark = it.getFloat("questionMark")
        }
        digits = correctList()
    }

    private fun correctList(): List<Int> {
        val list = ArrayList<Int>()
        val charArray = all.correctAnswer.toString().toCharArray()
        for (c in charArray) {
            list.add(Character.getNumericValue(c))
        }
        return list
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val questionRecyclerAdapter = QuestionRecyclerAdapter()
        questionRecyclerAdapter.setListener(object : OnPlayClickListener {
            override fun onPlay(view: View?, audioUrl: String?, isPlaying: Boolean) {
                if (!isPlaying) {
                    if (audioUrl != null) {
                        soundPlaying(audioUrl)
                        return
                    } else {
                        Toast.makeText(context, "Can not load sound", Toast.LENGTH_SHORT).show()
                        return
                    }
                }
                stopAudio(mediaPlayer)
            }
        })

        all.question.let { questionRecyclerAdapter.setData(it) }
       binding.questionLayout.apply {
            layoutManager = LinearLayoutManager(getContext())
            adapter = questionRecyclerAdapter
        }


        if (all.category == "ORDER") {
            getActivity()?.let {
                val linearLayout = it.findViewById<LinearLayout>(R.id.fifty_joker_layout)
                linearLayout.visibility = View.GONE
                binding.orderCheck.visibility = View.VISIBLE
                val orderAnswerRecyclerAdapter = OrderAnswerRecyclerAdapter()
                all.answers.let { orderAnswerRecyclerAdapter.setData(it) }
                orderAnswerRecyclerAdapter.setOnPlayListener(object : OnPlayClickListener{
                    override fun onPlay(view: View?, audioUrl: String?, isPlaying: Boolean) {
                        if (!isPlaying) {
                            if (audioUrl != null) {
                                soundPlaying(audioUrl)
                                return
                            } else {
                                Toast.makeText(requireContext(), "Can not load sound", Toast.LENGTH_SHORT).show()
                                return
                            }
                        }
                        stopAudio(mediaPlayer)
                    }

                })
                binding.answerRecycler.apply {
                    layoutManager = LinearLayoutManager(getContext())
                    adapter = orderAnswerRecyclerAdapter
                }
                val dragManageAdapter = DragManageAdapter(orderAnswerRecyclerAdapter, requireContext(), 3, 12)
                val itemTouchHelper = ItemTouchHelper(dragManageAdapter)
                itemTouchHelper.attachToRecyclerView(binding.answerRecycler)
                binding.orderCheck.setOnClickListener {
                    val digits: List<Int> = digits

                    var allCorrect = true
                    val childCount: Int = binding.answerRecycler.getChildCount()
                    for (i in 0 until orderAnswerRecyclerAdapter.answers.size) {
                        val pos: Int = orderAnswerRecyclerAdapter.answers.get(i).pos
                        if (i >= digits.size || pos != digits!![i] - 1) {
                            allCorrect = false
                            break
                        }
                    }
                    if (allCorrect) {
                        QuizMainActivity.instance.allViewModel.addPoint()
                        showDialogCorrect()
                    } else {
                        showDialogWrong()
                    }
                }
            }
        } else {
            val answers = all.answers
            val answerRecyclerAdapter = AnswerRecyclerAdapter(this, answers.size)
            answerRecyclerAdapter.setData(answers)
            answerRecyclerAdapter.setOnPlayListener(object :OnPlayClickListener{
                override fun onPlay(view: View?, audioUrl: String?, isPlaying: Boolean) {
                    if (!isPlaying) {
                        if (audioUrl != null) {
                           soundPlaying(audioUrl)
                            return
                        } else {
                            Toast.makeText(requireContext(), "Can not load sound", Toast.LENGTH_SHORT).show()
                            return
                        }
                    }
                   stopAudio(mediaPlayer)
                }
            })
            binding.answerRecycler.apply {
                layoutManager = LinearLayoutManager(getContext())
                adapter = answerRecyclerAdapter
                setHasFixedSize(true)
            }
        }

    }

    private fun soundPlaying(str: String) {
        if (!mediaPlayer.isPlaying) {
            playAudio(str)
        } else {
            stopAudio(mediaPlayer)
        }
    }

    private fun playAudio(str: String) {
        try {
            mediaPlayer.setDataSource(str)
            mediaPlayer.setOnCompletionListener {
                stopAudio(mediaPlayer)
            }
            mediaPlayer.setOnPreparedListener {
                it.start()
                QuizMainActivity.instance.allViewModel.updateDuration(0)
            }
            mediaPlayer.prepareAsync()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    private fun stopAudio(mediaPlayer: MediaPlayer) {
        if (mediaPlayer.isPlaying) {
            mediaPlayer.stop()
        }
        mediaPlayer.reset()
    }

    override fun onItemClick(i: Int) {
        if (i == all.correctAnswer) {
            val create: MediaPlayer = MediaPlayer.create(context, R.raw.correct_answer)
            create.start()
            updateItemBackground(i, true)
            QuizMainActivity.instance.allViewModel.addPoint()
            QuizMainActivity.instance.allViewModel.addCorrectAns()
            QuizMainActivity.instance.allViewModel.correctStreak()
            QuizMainActivity.instance.viewModelDb.updateProgressItem(questionMark, testIndex)
        } else {
            val create: MediaPlayer = MediaPlayer.create(context, R.raw.wrong_answer)
            create.start()
            QuizMainActivity.instance.allViewModel.addWrongAns()
            QuizMainActivity.instance.allViewModel.wrongStreak()
            updateItemBackground(all.correctAnswer, true)
            updateItemBackground(i, false)
        }
        Handler(Looper.getMainLooper()).postDelayed({
            QuizMainActivity.instance.allViewModel.plusOneIndex()

        }, 500)
    }

    private fun updateItemBackground(i: Int, z: Boolean) {
        val childAt = binding.answerRecycler.getChildAt(i)
        if (childAt != null) {
            val linearLayout = childAt.findViewById<LinearLayout>(R.id.background_of_image)
            if (z) {
                linearLayout?.setBackgroundResource(R.drawable.hnter_quiz_correct_answer)
            } else {
                linearLayout?.setBackgroundResource(R.drawable.hnter_quiz_wrong_answer)
            }
            val textView = childAt.findViewById<TextView>(R.id.answer_boxes_opt)
            textView?.visibility = View.GONE
            val imageView = childAt.findViewById<ImageView>(R.id.check_opt_image)
            imageView?.visibility = View.VISIBLE
            imageView?.isSelected = z
        }
    }


    @SuppressLint("NotifyDataSetChanged")
    fun fiftyJokerApply() {
        val all = this.all
        var size = all.answers.size / 2
        val correctAnswer = all.correctAnswer

        for (i in 0 until binding.answerRecycler.childCount) {
            if (i != correctAnswer && size > 0) {
                binding.answerRecycler.getChildAt(i).visibility = View.GONE
                size--
            }
        }
        (binding.answerRecycler.adapter as AnswerRecyclerAdapter).notifyDataSetChanged()
        QuizMainActivity.instance.allViewModel.useFiftyJoker()
    }

    private fun showDialogCorrect() {
        val customDialog = CustomDialog()
        customDialog.setCorrect(true)
        customDialog.show(requireActivity().supportFragmentManager, customDialog.tag)
    }

    private fun showDialogWrong() {
        val customDialog = CustomDialog()
        customDialog.show(requireActivity().supportFragmentManager, customDialog.tag)
    }


}