package com.maps.radar.trafficappfordriving.ui.radar;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public final class FragmentBridgeViewModel extends ViewModel {
    private final MutableLiveData<Boolean> _forceStop;
    private final MutableLiveData<Boolean> _locationPermisson;
    private final LiveData<Boolean> forceStop;
    private final LiveData<Boolean> locationPermisson;

    public FragmentBridgeViewModel() {
        MutableLiveData<Boolean> mutableLiveData = new MutableLiveData<>();
        this._forceStop = mutableLiveData;
        this.forceStop = mutableLiveData;
        MutableLiveData<Boolean> mutableLiveData2 = new MutableLiveData<>();
        this._locationPermisson = mutableLiveData2;
        this.locationPermisson = mutableLiveData2;
    }

    public final void exitRadarFragment() {
        this._forceStop.postValue(Boolean.TRUE);
    }

    public final LiveData<Boolean> getForceStop() {
        return this.forceStop;
    }

    public final LiveData<Boolean> getLocationPermisson() {
        return this.locationPermisson;
    }

    public final void setLocationPermisson(boolean z10) {
        this._locationPermisson.postValue(Boolean.valueOf(z10));
    }
}