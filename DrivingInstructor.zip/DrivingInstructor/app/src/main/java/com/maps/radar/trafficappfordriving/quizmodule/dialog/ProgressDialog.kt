package com.maps.radar.trafficappfordriving.quizmodule.dialog

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentActivity
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.FragmentProgressDialogBinding
import com.maps.radar.trafficappfordriving.Db.AllViewModel
import com.maps.radar.trafficappfordriving.quizmodule.QuizMainActivity

class ProgressDialog : DialogFragment() {
    private var type = 0

    companion object {
        fun show(activity: FragmentActivity, type: Int) {
            ProgressDialog().apply {
                this.type = type
                show(activity.supportFragmentManager, tag)
            }
        }
    }

    private lateinit var binding: FragmentProgressDialogBinding
//    private lateinit var viewModel: AllViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentProgressDialogBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(-2, -2)
        dialog?.window?.setDimAmount(1.0f)
        dialog?.window?.setBackgroundDrawable(ContextCompat.getDrawable(requireContext()!!, R.drawable.progress_popup))
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.continueBtnProgress.setOnClickListener { dismiss(); QuizMainActivity.instance.allViewModel.updateInit() }

        when (type) {
            0 -> {
                binding.headerImgProgress.setImageResource(R.drawable.hnter_quiz_good_job_illus)
                binding.headerTextProgress.text = getString(R.string.quiz_good_job)
                binding.bodyTextProgress.text = getString(R.string.quiz_you_answered_correctly_5_times)
            }
            1 -> {
                binding.headerImgProgress.setImageResource(R.drawable.hnter_quiz_oops_illus)
                binding.headerTextProgress.text = getString(R.string.quiz_module_ooops)
                binding.bodyTextProgress.text = getString(R.string.quiz_you_can_make_better)
            }
            2 -> {
                binding.headerImgProgress.setImageResource(R.drawable.hnter_quiz_perfect_illus)
                binding.headerTextProgress.text = getString(R.string.quiz_perfect)
                binding.bodyTextProgress.text = getString(R.string.quiz_you_answered_correctly_10_times)
            }
        }
    }
}