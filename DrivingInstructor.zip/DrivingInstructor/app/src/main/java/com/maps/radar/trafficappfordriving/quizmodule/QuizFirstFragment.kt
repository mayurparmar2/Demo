package com.maps.radar.trafficappfordriving.quizmodule

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import com.bumptech.glide.Glide
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.QuizFragmentFirstBinding
import com.maps.radar.trafficappfordriving.Db.AllViewModel
import com.maps.radar.trafficappfordriving.Db.HomeScreenObjects
import com.maps.radar.trafficappfordriving.Db.ImplRepository
import com.maps.radar.trafficappfordriving.Db.QuizProgressItem
import com.maps.radar.trafficappfordriving.model.QuizMain
import com.maps.radar.trafficappfordriving.quizmodule.Adapter.HomeRecyclerAdapter


class QuizFirstFragment : Fragment() {
    private lateinit var binding: QuizFragmentFirstBinding
//
//    private val viewModel by lazy { ViewModelProvider(this).get(BaseViewModel::class.java) }
//    private val viewModelDb by lazy { ViewModelProvider(this).get(QuizProgressViewModel::class.java) }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = QuizFragmentFirstBinding.inflate(inflater, container, false)
        return binding!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        binding.completedTestText.setOnClickListener { v ->
            findNavController(v).navigate(R.id.action_quiz_FirstFragment_to_completedFragment)
        }
        if (activity is QuizMainActivity) {
            val quizMainActivity = activity as QuizMainActivity
            quizMainActivity.viewModelDb.allDoneData.observe(viewLifecycleOwner) { items ->
                binding.completedTestText.setText(getString(R.string.quiz_completed_quiz) + ' ' +items.size);
            }
            quizMainActivity.allViewModel = ViewModelProvider(this).get(AllViewModel::class.java)

            val homeAdapter = HomeRecyclerAdapter(onItemClicked = { model, index ->

                quizMainActivity.viewModelDb.addProgressItem(
                    QuizProgressItem(
                        index,
                        0.0f,
                        model.icon,
                        model.title
                    )
                )
                val bundle = Bundle()
                bundle.putInt("index", index)
                findNavController(view).navigate(
                    R.id.action_FirstFragment_to_quizContainerFragment,
                    bundle
                )
            })
            binding.homeRecycler.layoutManager = GridLayoutManager(context, 2)
            binding.homeRecycler.adapter = homeAdapter


            if (requireActivity() is QuizMainActivity) {
                val quizMainActivity = activity as QuizMainActivity
                val endPointName: String = quizMainActivity.endPointName.toString()
                quizMainActivity.baseViewModel.getShuffle(endPointName)
            }


            quizMainActivity.baseViewModel.shuffleList.observe(viewLifecycleOwner) { quizList ->
                if (quizList.isNotEmpty()) {
                    updateUI(quizList, homeAdapter)
                } else {
                    showLoading()
                }
            }

            quizMainActivity.viewModelDb.allProgressItem.observe(viewLifecycleOwner) { progressItems ->
                updateProgressUI(progressItems, homeAdapter)
            }
        }


    }

    private fun showLoading() {
        binding.testWaitProgress.visibility = View.VISIBLE
        binding.homeRecycler.visibility = View.GONE
    }

    private fun updateUI(quizList: List<QuizMain>, adapter: HomeRecyclerAdapter) {
        binding.apply {
            quizMainHeaderText.text = quizList[0].name_of_app
            Glide.with(requireActivity())
                .load(quizList[0].image_of_app)
                .into(quizMainHeaderImg)

            testWaitProgress.visibility = View.GONE
            homeRecycler.visibility = View.VISIBLE
        }

        val homeScreenObjects = quizList[0].list_of_img.mapIndexed { index, imageUrl ->
            HomeScreenObjects(imageUrl, getString(R.string.hunter_quiz_quiz) + " ${index + 1}")
        }
        adapter.setData(homeScreenObjects)
    }

    private fun updateProgressUI(
        progressItems: List<QuizProgressItem>,
        adapter: HomeRecyclerAdapter,
    ) {
        val homeScreenObjects = progressItems.map {
            HomeScreenObjects(it.icon, it.title)
        }
        adapter.setDoneData(homeScreenObjects)
    }


}
