package com.maps.radar.trafficappfordriving.quizmodule.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.demo.radar.trafficappfordriving2.databinding.QuizHomeGridItemBinding
import com.maps.radar.trafficappfordriving.Db.HomeScreenObjects

class HomeRecyclerAdapter(
    private val onItemClicked: (HomeScreenObjects, Int) -> Unit
) : RecyclerView.Adapter<HomeRecyclerAdapter.ItemListViewHolder>() {

    private val itemList = mutableListOf<HomeScreenObjects>()
    private val doneList = mutableListOf<HomeScreenObjects>()

    class ItemListViewHolder(
        private val binding: QuizHomeGridItemBinding,
        private val adapter: HomeRecyclerAdapter
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(homeScreenObject: HomeScreenObjects) {
            Glide.with(binding.root).load(homeScreenObject.icon).into(binding.imgQuiz)
            binding.quizName.text = homeScreenObject.title
            binding.doneQuizShow.visibility = if (adapter.doneList.contains(homeScreenObject)) View.VISIBLE else View.GONE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemListViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = QuizHomeGridItemBinding.inflate(inflater, parent, false)
        return ItemListViewHolder(binding, this)
    }

    override fun onBindViewHolder(holder: ItemListViewHolder, position: Int) {
        holder.bind(itemList[position])
        holder.itemView.setOnClickListener { onItemClicked(itemList[position], position) }
    }

    override fun getItemCount(): Int = itemList.size

    fun setData(itemList: List<HomeScreenObjects>) {
        this.itemList.clear()
        this.itemList.addAll(itemList)
        notifyDataSetChanged()
    }

    fun setDoneData(doneList: List<HomeScreenObjects>) {
        this.doneList.clear()
        this.doneList.addAll(doneList)
        notifyDataSetChanged()
    }
}