package com.maps.radar.trafficappfordriving.ui.radar.viewmodel

import androidx.lifecycle.LiveData
import com.maps.radar.trafficappfordriving.ui.radar.model.RadarLocal

public class RadarRepository(private val radarDao: RadarDao) {


    fun getNear(x: Double, y: Double, callback: (List<RadarLocal>) -> Unit) {
        radarDao.getRadarDataInRange(x, y).observeForever { callback(it) }
    }



    fun getNearest(x: Double, y: Double, callback: (List<RadarLocal>) -> Unit) {
        radarDao.getRadarDataNearPoint(x, y).observeForever { callback(it) }
    }


//    fun getRadarDataInRange(x: Double, y: Double, callback: z8.d<List<d>>) {
//        radarDao.getRadarDataInRange(x, y, callback)
//    }
//
//    fun getRadarDataNearPoint(x: Double, y: Double, callback: z8.d<List<d>>) {
//        radarDao.getRadarDataNearPoint(x, y, callback)
//    }
}