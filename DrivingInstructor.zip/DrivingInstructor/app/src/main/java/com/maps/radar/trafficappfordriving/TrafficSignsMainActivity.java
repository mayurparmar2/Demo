package com.maps.radar.trafficappfordriving;
import android.content.Intent;
import android.util.Log;
import android.view.View;

import androidx.fragment.app.FragmentManager;

import com.demo.radar.trafficappfordriving2.R;
import com.demo.radar.trafficappfordriving2.databinding.TrafficSignsModuleActivityMainBinding;
import com.maps.radar.trafficappfordriving.model.TrafficSign;
import com.maps.radar.trafficappfordriving.network.Apis;
import com.maps.radar.trafficappfordriving.ui.base.BaseActivity;
import com.maps.radar.trafficappfordriving.utils.GridSpacingItemDecoration;

import java.util.List;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import lib.module.trafficsignsmodule.presentation.TrafficSignDialogFragment;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TrafficSignsMainActivity extends BaseActivity<TrafficSignsModuleActivityMainBinding> {
    private final String TAG = "TrafficSignsMainActivity";
    TrafficSignsModuleActivityMainBinding binding;
    public static final String PROJECT_ID = "traffic_sign_module_project_id";
    public static final String SUPPORTED_LANGUAGES = "traffic_sign_module_supported_languages";
    public static final String TITLE = "traffic_sign_module_title";

    TrafficSignAdapter adapter;
    private String projectId;
    private String title;

    @Override
    public TrafficSignsModuleActivityMainBinding getViewBinding() {
        binding =TrafficSignsModuleActivityMainBinding.inflate(getLayoutInflater());
        return binding;
    }

    @Override
    public void initView(TrafficSignsModuleActivityMainBinding binding) {
        Intent intent2 = getIntent();
        if (intent2 != null) {
            this.projectId = intent2.getStringExtra(PROJECT_ID);
            this.title = intent2.getStringExtra(TITLE);
        } else {
            this.projectId = null;
        }
        binding.imgBack.setOnClickListener(v -> {
            finish();
        });
        if(this.projectId !=null){
            if(this.title.equals(getString(R.string.police_sign))){
                binding.title.setText(getString(R.string.police_sign));
                Apis.Companion.getInstance2().getPoliceSigns().enqueue(new Callback<List<TrafficSign>>() {
                    @Override
                    public void onResponse(Call<List<TrafficSign>> call, Response<List<TrafficSign>> response) {
                        if(response.isSuccessful()){
                            Log.e("TAG", "onResponse: "+response.body());
                            List<TrafficSign> trafficSigns  =  response.body();
                            if(trafficSigns!=null && !trafficSigns.isEmpty()){
                                binding.progressbar.setVisibility(View.INVISIBLE);
                                adapter = new TrafficSignAdapter(new Function1<TrafficSign, Unit>() {
                                    @Override
                                    public Unit invoke(TrafficSign trafficSignModel) {
                                        FragmentManager supportFragmentManager = getSupportFragmentManager();
                                        TrafficSignDialogFragment trafficSignDialogFragment = new TrafficSignDialogFragment();
                                        trafficSignDialogFragment.setItem(trafficSignModel);
                                        if (!trafficSignDialogFragment.isAdded()) {
                                            trafficSignDialogFragment.show(supportFragmentManager, (String) null);
                                        }
                                        return null;
                                    }
                                });
                                adapter.submitList(trafficSigns);
                                binding.recycler.addItemDecoration(new GridSpacingItemDecoration(2, (int) getResources().getDimension(R.dimen.dp_28), false));
                                binding.recycler.setAdapter(adapter);
                            }
                        }
                    }
                    @Override
                    public void onFailure(Call<List<TrafficSign>> call, Throwable t) {
                        Log.e("TAG", "onFailure: "+t.getMessage() );
                    }
                });
            } else if(this.title.equals(getString(R.string.driving_licenses))){
                binding.title.setText(getString(R.string.driving_licenses));
                Apis.Companion.getInstance2().getDrivingLicences().enqueue(new Callback<List<TrafficSign>>() {
                    @Override
                    public void onResponse(Call<List<TrafficSign>> call, Response<List<TrafficSign>> response) {
                        if(response.isSuccessful()){
                            Log.e("TAG", "onResponse: "+response.body());
                            List<TrafficSign> trafficSigns  =  response.body();
                            if(trafficSigns!=null && !trafficSigns.isEmpty()){
                                binding.progressbar.setVisibility(View.INVISIBLE);
                                adapter = new TrafficSignAdapter(new Function1<TrafficSign, Unit>() {
                                    @Override
                                    public Unit invoke(TrafficSign trafficSignModel) {
                                        FragmentManager supportFragmentManager = getSupportFragmentManager();
                                        TrafficSignDialogFragment trafficSignDialogFragment = new TrafficSignDialogFragment();
                                        trafficSignDialogFragment.setItem(trafficSignModel);
                                        if (!trafficSignDialogFragment.isAdded()) {
                                            trafficSignDialogFragment.show(supportFragmentManager, (String) null);
                                        }
                                        return null;
                                    }
                                });
                                adapter.submitList(trafficSigns);
                                binding.recycler.addItemDecoration(new GridSpacingItemDecoration(2, (int) getResources().getDimension(R.dimen.dp_28), false));
                                binding.recycler.setAdapter(adapter);
                            }
                        }
                    }
                    @Override
                    public void onFailure(Call<List<TrafficSign>> call, Throwable t) {
                        Log.e("TAG", "onFailure: "+t.getMessage() );
                    }
                });
            } else if(this.title.equals(getString(R.string.driving_indicators))){
                binding.title.setText(getString(R.string.driving_indicators));
                Apis.Companion.getInstance2().getIndicators().enqueue(new Callback<List<TrafficSign>>() {
                    @Override
                    public void onResponse(Call<List<TrafficSign>> call, Response<List<TrafficSign>> response) {
                        if(response.isSuccessful()){
                            Log.e("TAG", "onResponse: "+response.body());
                            List<TrafficSign> trafficSigns  =  response.body();
                            if(trafficSigns!=null && !trafficSigns.isEmpty()){
                                binding.progressbar.setVisibility(View.INVISIBLE);
                                adapter = new TrafficSignAdapter(new Function1<TrafficSign, Unit>() {
                                    @Override
                                    public Unit invoke(TrafficSign trafficSignModel) {
                                        FragmentManager supportFragmentManager = getSupportFragmentManager();
                                        TrafficSignDialogFragment trafficSignDialogFragment = new TrafficSignDialogFragment();
                                        trafficSignDialogFragment.setItem(trafficSignModel);
                                        if (!trafficSignDialogFragment.isAdded()) {
                                            trafficSignDialogFragment.show(supportFragmentManager, (String) null);
                                        }
                                        return null;
                                    }
                                });
                                adapter.submitList(trafficSigns);
                                binding.recycler.addItemDecoration(new GridSpacingItemDecoration(2, (int) getResources().getDimension(R.dimen.dp_28), false));
                                binding.recycler.setAdapter(adapter);
                            }
                        }
                    }
                    @Override
                    public void onFailure(Call<List<TrafficSign>> call, Throwable t) {
                        Log.e("TAG", "onFailure: "+t.getMessage() );
                    }
                });
            } else if(this.title.equals(getString(R.string.traffic_sign))){
                Apis.Companion.getInstance().getTrafficSign(projectId).enqueue(new Callback<List<TrafficSign>>() {
                    @Override
                    public void onResponse(Call<List<TrafficSign>> call, Response<List<TrafficSign>> response) {
                        if(response.isSuccessful()){
                            Log.e("TAG", "onResponse: "+response.body() );
                            List<TrafficSign> trafficSigns  =  response.body();
                            if(trafficSigns!=null && !trafficSigns.isEmpty()){
                                binding.progressbar.setVisibility(View.INVISIBLE);
                                adapter = new TrafficSignAdapter(new Function1<TrafficSign, Unit>() {
                                    @Override
                                    public Unit invoke(TrafficSign trafficSignModel) {

                                        FragmentManager supportFragmentManager = getSupportFragmentManager();
                                        TrafficSignDialogFragment trafficSignDialogFragment = new TrafficSignDialogFragment();
                                        trafficSignDialogFragment.setItem(trafficSignModel);
                                        if (!trafficSignDialogFragment.isAdded()) {
                                            trafficSignDialogFragment.show(supportFragmentManager, (String) null);
                                        }
                                        return null;
                                    }
                                });
                                adapter.submitList(trafficSigns);
                                binding.recycler.addItemDecoration(new GridSpacingItemDecoration(2, (int) getResources().getDimension(R.dimen.dp_28), false));
                                binding.recycler.setAdapter(adapter);
                            }
                        }
                    }
                    @Override
                    public void onFailure(Call<List<TrafficSign>> call, Throwable t) {
                        Log.e("TAG", "onFailure: "+t.getMessage() );
                    }
                });
            }



        }



    }

}
