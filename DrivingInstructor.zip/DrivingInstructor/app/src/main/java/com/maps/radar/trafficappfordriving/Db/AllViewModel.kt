package com.maps.radar.trafficappfordriving.Db

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData

class AllViewModel(app: Application) : AndroidViewModel(app) {

    private val _selectIndex = MutableLiveData<Int>()
    private val _point = MutableLiveData<Int>()
    private val _correctAns = MutableLiveData<Int>()
    private val _wrongAns = MutableLiveData<Int>()
    private val _skipJoker = MutableLiveData<Int>()
    private val _fiftyJoker = MutableLiveData<Int>()
    private val _mediaPlayerDuration = MutableLiveData<Int>()
    private val _strikeCount = MutableLiveData<Int>()

    init {
        _selectIndex.value = 0
        _point.value = 0
        _correctAns.value = 0
        _wrongAns.value = 0
        _skipJoker.value = 3
        _fiftyJoker.value = 2
        _strikeCount.value = 0
    }

    fun addCorrectAns() {
        _correctAns.value = _correctAns.value?.plus(1)
    }

    fun addPoint() {
        _point.value = _point.value?.plus(100)
    }

    fun addWrongAns() {
        _wrongAns.value = _wrongAns.value?.plus(1)
    }

    fun correctStreak() {
        _strikeCount.value = _strikeCount.value?.plus(1)
    }

    fun getSelectIndex(): MutableLiveData<Int> {
        return _selectIndex
    }

    fun getPoint(): MutableLiveData<Int> {
        return _point
    }

    fun getCorrectAns(): MutableLiveData<Int> {
        return _correctAns
    }

    fun getWrongAns(): MutableLiveData<Int> {
        return _wrongAns
    }

    fun getSkipJoker(): MutableLiveData<Int> {
        return _skipJoker
    }

    fun getFiftyJoker(): MutableLiveData<Int> {
        return _fiftyJoker
    }

    fun getMediaPlayerDuration(): MutableLiveData<Int> {
        return _mediaPlayerDuration
    }

    fun getStrikeCount(): MutableLiveData<Int> {
        return _strikeCount
    }

    fun initViewModel() {
        _selectIndex.value = 0
        _point.value = 0
        _correctAns.value = 0
        _wrongAns.value = 0
        _skipJoker.value = 3
        _fiftyJoker.value = 2
        _strikeCount.value = 0
    }

    fun plusOneIndex() {
        _selectIndex.value = _selectIndex.value?.plus(1)
    }

    fun updateDuration(i10: Int) {
        _mediaPlayerDuration.value = i10
    }

    fun updateInit() {
        _strikeCount.value = 0
    }

    fun updateSelectIndex(i10: Int) {
        _selectIndex.value = i10
    }

    fun useFiftyJoker() {
        _fiftyJoker.value = _fiftyJoker.value?.minus(1)
    }

    fun useSkipJoker() {
        _skipJoker.value = _skipJoker.value?.minus(1)
    }

    fun wrongStreak() {
        _strikeCount.value = _strikeCount.value?.minus(1)
    }

    fun zeroPoint() {
        _point.value = 0
    }
}

//import android.app.Application;
//import androidx.lifecycle.AndroidViewModel;
//import androidx.lifecycle.MutableLiveData;
//
//public final class AllViewModel extends AndroidViewModel {
//    private final MutableLiveData<Integer> correctAns = new MutableLiveData<>(0);
//    private final MutableLiveData<Integer> fiftyJoker = new MutableLiveData<>(2);
//    private final MutableLiveData<Integer> mediaPlayerDuration = new MutableLiveData<>();
//    private final MutableLiveData<Integer> point = new MutableLiveData<>(0);
//    private final MutableLiveData<Integer> selectIndex = new MutableLiveData<>(0);
//    private final MutableLiveData<Integer> skipJoker = new MutableLiveData<>(3);
//    private final MutableLiveData<Integer> strikeCount = new MutableLiveData<>(0);
//    private final MutableLiveData<Integer> wrongAns = new MutableLiveData<>(0);
//
//    public AllViewModel(Application app) {
//        super(app);
//    }
//
//
//    public final void plusOneIndex() {
//        Integer num;
//        MutableLiveData<Integer> mutableLiveData = this._selectIndex;
//        Integer value = mutableLiveData.getValue();
//        if (value != null) {
//            num = Integer.valueOf(value.intValue() + 1);
//        } else {
//            num = null;
//        }
//        mutableLiveData.setValue(num);
//    }
//
//
//
//
//    private void incrementValue(MutableLiveData<Integer> liveData, int increment) {
//        Integer value = liveData.getValue();
//        liveData.setValue((value != null ? value : 0) + increment);
//    }
//
//    private void decrementValue(MutableLiveData<Integer> liveData, int decrement) {
//        Integer value = liveData.getValue();
//        liveData.setValue((value != null ? value : 0) - decrement);
//    }
//
//    public void addCorrectAns() {
//        incrementValue(correctAns, 1);
//    }
//
//    public void addPoint() {
//        incrementValue(point, 100);
//    }
//
//    public void addWrongAns() {
//        incrementValue(wrongAns, 1);
//    }
//
//    public void correctStreak() {
//        incrementValue(strikeCount, 1);
//    }
//
//    public void useFiftyJoker() {
//        decrementValue(fiftyJoker, 1);
//    }
//
//    public void useSkipJoker() {
//        decrementValue(skipJoker, 1);
//    }
//
//    public void wrongStreak() {
//        decrementValue(strikeCount, 1);
//    }
//
//    public void zeroPoint() {
//        point.setValue(0);
//    }
//
//    public void updateDuration(int duration) {
//        mediaPlayerDuration.setValue(duration);
//    }
//
//    public void updateSelectIndex(int index) {
//        selectIndex.setValue(index);
//    }
//
//    public MutableLiveData<Integer> getCorrectAns() {
//        return correctAns;
//    }
//
//    public MutableLiveData<Integer> getFiftyJoker() {
//        return fiftyJoker;
//    }
//
//    public MutableLiveData<Integer> getMediaPlayerDuration() {
//        return mediaPlayerDuration;
//    }
//
//    public MutableLiveData<Integer> getPoint() {
//        return point;
//    }
//
//    public MutableLiveData<Integer> getSelectIndex() {
//        return selectIndex;
//    }
//
//    public MutableLiveData<Integer> getSkipJoker() {
//        return skipJoker;
//    }
//
//    public MutableLiveData<Integer> getStrikeCount() {
//        return strikeCount;
//    }
//
//    public MutableLiveData<Integer> getWrongAns() {
//        return wrongAns;
//    }
//}


