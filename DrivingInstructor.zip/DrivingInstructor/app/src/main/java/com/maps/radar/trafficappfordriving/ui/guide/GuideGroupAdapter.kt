package com.maps.radar.trafficappfordriving.ui.guide

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.ListItemGuideGroupBinding
import com.maps.radar.trafficappfordriving.model.GuideGroup
import com.maps.radar.trafficappfordriving.model.GuideItem
import com.maps.radar.trafficappfordriving.model.f

class GuideGroupAdapter(private val groupId: Int, private val listener: (GuideItem) -> Unit) :
    ListAdapter<GuideItem, GuideGroupAdapter.GuideGroupViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GuideGroupViewHolder {
        val binding = ListItemGuideGroupBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return GuideGroupViewHolder(binding)
    }

    override fun onBindViewHolder(holder: GuideGroupViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item)
    }

    inner class GuideGroupViewHolder(private val binding: ListItemGuideGroupBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: GuideItem) {

            binding.name.text = item.name

            Log.e("TAG", "bind Url: "+f.f105a.d(groupId, item.id).toString())

            Glide.with(itemView.context)
                .load(f.f105a.d(groupId, item.id))
                .into(binding.image)
            binding.root.setOnClickListener { listener(item) }
        }
    }

    private class DiffCallback : DiffUtil.ItemCallback<GuideItem>() {
        override fun areItemsTheSame(oldItem: GuideItem, newItem: GuideItem): Boolean {
            return oldItem === newItem
        }

        override fun areContentsTheSame(oldItem: GuideItem, newItem: GuideItem): Boolean {
            return oldItem.id == newItem.id
        }
    }
}