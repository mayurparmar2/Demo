package com.maps.radar.trafficappfordriving.offlinemap.fragments;

import static androidx.navigation.fragment.NavHostFragment.findNavController;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Rect;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.demo.radar.trafficappfordriving2.R;
import com.demo.radar.trafficappfordriving2.databinding.FragmentOsmdroidBinding;
import com.maps.radar.trafficappfordriving.offlinemap.CategoryPoiAdapter;
import com.maps.radar.trafficappfordriving.offlinemap.CommunicationMediator;
import com.maps.radar.trafficappfordriving.offlinemap.LocationPermissionDialog;
import com.maps.radar.trafficappfordriving.offlinemap.OfflineMapActivity;
import com.maps.radar.trafficappfordriving.offlinemap.model.PlaceholderContent;
import com.maps.radar.trafficappfordriving.ui.hupd.LocationUpdateListener;
import com.maps.radar.trafficappfordriving.ui.hupd.LocationUpdatesService;
import com.maps.radar.trafficappfordriving.ui.radar.CommunicationListener;
import com.maps.radar.trafficappfordriving.utils.RemoteConfigUtils;

import org.osmdroid.api.IMapController;
import org.osmdroid.events.DelayedMapListener;
import org.osmdroid.events.MapListener;
import org.osmdroid.events.ScrollEvent;
import org.osmdroid.events.ZoomEvent;
import org.osmdroid.tileprovider.cachemanager.CacheManager;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.osmdroid.tileprovider.tilesource.MapBoxTileSource;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.tileprovider.tilesource.XYTileSource;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.CustomZoomButtonsController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.FolderOverlay;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.Overlay;
import org.osmdroid.views.overlay.Polygon;
import org.osmdroid.views.overlay.Polyline;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class OsmdroidFragment extends Fragment implements CommunicationListener, LocationUpdateListener, View.OnClickListener {

    private FragmentOsmdroidBinding _binding;
    private MapView mapView;
    private FolderOverlay poiMarkers;
    private Polyline roadOverlay;
    private CommunicationMediator communicationMediator;
    private ServiceConnection mServiceConnection = new i();
    private boolean mBound;
    private LocationUpdatesService mService;
    private Marker currentLocationMarker;
    private boolean isFirst = true;
    private double zoomLevel = 4.5d;
    private GeoPoint currentLocation;
    private IMapController mapController;
    private CacheManager cacheManager;
     String selectedPoiName;
    private GeoPoint startPoint = new GeoPoint(46.55951d, 15.6397d);
    private Polygon selectedBoundingBox;

    private ArrayList<GeoPoint> points;


    @Override
    public void onLocationChanged(Location location) {
        if (location == null || !checkIfFragmentAttached(this) || mapView == null || mapView.getRepository() == null) {
            return;
        }
        if (currentLocationMarker != null) {
            mapView.getOverlays().remove(currentLocationMarker);
        }

        if (isFirst) {
            zoomLevel = 18.5d;
            isFirst = false;
            _binding.progressHorizontal.setVisibility(View.GONE);
        }
        currentLocation = new GeoPoint(location.getLatitude(), location.getLongitude());
        currentLocationMarker = new Marker(mapView);
        currentLocationMarker.setDraggable(true);
        currentLocationMarker.setImage(ResourcesCompat.getDrawable(getResources(), com.demo.radar.trafficappfordriving2.R.drawable.ic_pin, null));
        currentLocationMarker.setTextIcon(getString(R.string.your_loc));
        currentLocationMarker.setPosition(currentLocation);
        currentLocationMarker.setAnchor(0.5f, 1.0f);
        mapView.getOverlays().add(currentLocationMarker);
        mapController.setZoom(zoomLevel);
        mapController.animateTo(currentLocation);
        mapView.invalidate();
    }

    @Override
    public void onClick(View view) {
        if (view == null) return;
        int viewId = view.getId();
        if (viewId == _binding.btnMapDownload.getId()) {
//            downloadMapArea();
            _binding.btnMapDownload.setVisibility(View.GONE);
        } else if (viewId == _binding.btnZoomIn.getId()) {
            if (mapView != null) {
                mapView.getController().zoomIn();
                zoomLevel = mapView.getZoomLevelDouble();
            }
        } else if (viewId == _binding.btnZoomOut.getId()) {
            if (mapView != null) {
                mapView.getController().zoomOut();
                zoomLevel = mapView.getZoomLevelDouble();
            }
        } else if (viewId == _binding.imgMapLocation.getId()) {
            if (currentLocation != null) {
                zoomLevel = 18.5;
                if (mapController != null) {
                    mapController.setZoom(zoomLevel);
                    mapController.setCenter(currentLocation);
                }
            }
        } else if (viewId == _binding.circleLayout.getId()) {
//            showPopup();
        } else if (viewId == _binding.circleLayout2.getId()) {
            _binding.circleLayout2.setVisibility(View.GONE);
            _binding.imgClose.setVisibility(View.VISIBLE);
            _binding.includePoiLayout.getRoot().setVisibility(View.VISIBLE);
            createPoiItems();
        } else if (viewId == _binding.imgClose.getId()) {
            _binding.circleLayout2.setVisibility(View.VISIBLE);
            _binding.imgClose.setVisibility(View.GONE);
            _binding.includePoiLayout.getRoot().setVisibility(View.GONE);
            _binding.includePoiListLayout.getRoot().setVisibility(View.GONE);
            _binding.btnZoomIn.setVisibility(View.VISIBLE);
            _binding.btnZoomOut.setVisibility(View.VISIBLE);
            clearPoiMarkers(true);
        } else if (viewId == _binding.includePoiListLayout.imgOnMap.getId()) {
            _binding.imgClose.setVisibility(View.GONE);
            _binding.imgOnList.setVisibility(View.VISIBLE);
            _binding.includePoiLayout.getRoot().setVisibility(View.GONE);
            _binding.includePoiListLayout.getRoot().setVisibility(View.GONE);
            _binding.btnZoomIn.setVisibility(View.GONE);
            _binding.btnZoomOut.setVisibility(View.GONE);
            if (mapView != null) {
                mapView.invalidate();
            }
        } else if (viewId == _binding.imgOnList.getId()) {
            _binding.imgClose.setVisibility(View.VISIBLE);
            _binding.includePoiListLayout.imgOnMap.setVisibility(View.VISIBLE);
            _binding.imgOnList.setVisibility(View.GONE);
            _binding.includePoiListLayout.getRoot().setVisibility(View.VISIBLE);
        }
    }

    private final void createPoiItems() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext(), RecyclerView.HORIZONTAL, false);
        RecyclerView recyclerView = _binding.includePoiLayout.list;
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(new CategoryPoiAdapter(PlaceholderContent.INSTANCE.getItems(), new CategoryPoiAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(String category, int iconResId) {
                _binding.includePoiLayout.getRoot().setVisibility(View.GONE);
                _binding.imgClose.setVisibility(View.GONE);

                selectedPoiName = category;
                if (mapView == null) {
                    throw new NullPointerException("mapView is null");
                }
                double lat = mapView.getMapCenter().getLatitude();
                double lon = mapView.getMapCenter().getLongitude();

                String lowerCategory = category != null ? category.toLowerCase(Locale.ROOT) : "";


                String url = String.format("%sreverse?lat=%f&lon=%f&osm_tag=%s&limit=30&radius=15", descipt(), lat, lon, lowerCategory);

                Log.e("TAG", "onItemClick descipt: "+url);

                loadPOIs(url, iconResId);
            }
        }));
    }



    final class i implements ServiceConnection {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            mService = ((LocationUpdatesService.LocationBinder) iBinder).getService();
            mBound = true;
            if (mService != null) {
                mService.c(OsmdroidFragment.this);
                mService.h();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mService = null;
            mBound = false;
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the binding
        _binding = FragmentOsmdroidBinding.inflate(inflater, container, false);
        this.mapView = _binding.mapview;

        if (ContextCompat.checkSelfPermission(requireContext(), "android.permission.ACCESS_FINE_LOCATION") == 0) {
            initializeService();
        }

        // Set click listeners
        _binding.circleLayout.setOnClickListener(this);
        _binding.circleLayout2.setOnClickListener(this);
        _binding.includePoiListLayout.imgOnMap.setOnClickListener(this);
        _binding.imgOnList.setOnClickListener(this);
        _binding.btnMapDownload.setOnClickListener(this);
        _binding.btnZoomOut.setOnClickListener(this);
        _binding.btnZoomIn.setOnClickListener(this);
        _binding.imgMapLocation.setOnClickListener(this);
        _binding.imgClose.setOnClickListener(this);

        _binding.includePoiLayout.editText.setOnEditorActionListener((textView, actionId, keyEvent) ->
                onIncludePoiLayout(this, _binding.getRoot(), textView, actionId, keyEvent)
        );

        _binding.edittextMapSearch.setOnEditorActionListener((textView, actionId, keyEvent) ->
                OsmdroidFragment.onCreateView$lambda$2(this, _binding.getRoot(), textView, actionId, keyEvent)
        );

        _binding.locationPermissionAlert.setOnClickListener(v -> {
            openAppSettings();
        });

        if (mapView != null) {
            mapView.setTileSource(new XYTileSource("MapQuest", 4, 19, 256, ".png", new String[]{"https://map.latlonfinder.com/"}));
            mapView.setMultiTouchControls(true);
            mapView.setMinZoomLevel(4.5);
            mapView.setMaxZoomLevel(19.5);
            mapView.getOverlays().add(new Overlay() {
                @Override
                public boolean onTouchEvent(MotionEvent event, MapView mapView) {
//                    return super.onTouchEvent(event, mapView);
                    if (selectedPoiName == null) {
                        handleMapClick();
                        return true;
                    }
                    return false;

                }
            });

            this.mapController = mapView.getController();
            if (this.mapController != null) {
                this.mapController.setZoom(this.zoomLevel);
                this.mapController.setCenter(this.startPoint);
            }

            this.cacheManager = new CacheManager(mapView);
            mapView.getZoomController().setVisibility(CustomZoomButtonsController.Visibility.NEVER);
            mapView.addMapListener(new DelayedMapListener(new MapListener() {
                @Override
                public boolean onScroll(ScrollEvent event) {
                    if (mapView == null) {
                        mapView = null;
                    }
                    zoomLevel = mapView.getZoomLevelDouble();
                    removeSelectedPolygon();
                    return false;
                }

                @Override
                public boolean onZoom(ZoomEvent event) {
                    if (event != null) {
                        OsmdroidFragment.this.zoomLevel = event.getZoomLevel();
                    }
                    OsmdroidFragment.this.removeSelectedPolygon();

                    return false;
                }
            }, 100L));
        }

        return _binding.getRoot();
    }




    String descipt2(){
        return  a1(-7549158879112463679L);
    }

    public final void removeSelectedPolygon() {
        if (checkIfFragmentAttached(this)) {
            requireActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (selectedBoundingBox != null) {
                        // Remove the selected bounding box from the map
                        if (mapView != null) {
                            mapView.getOverlays().remove(selectedBoundingBox);
                            mapView.invalidate();
                        }

                        // Clear the points and reset the selected bounding box
                        if (points != null) {
                            points.clear();
                        }
                        selectedBoundingBox = null;
                        _binding.btnMapDownload.setVisibility(View.GONE);
                    }
                }
            });
        }
    }

    private final void openAppSettings() {
        FragmentActivity activity = getActivity();
        if (activity instanceof AppCompatActivity) {
            AppCompatActivity appCompatActivity = (AppCompatActivity) activity;
            Intent intent = new Intent();
            intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
            intent.setData(Uri.fromParts("package", appCompatActivity.getPackageName(), null));
            appCompatActivity.startActivity(intent);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean onCreateView$lambda$2(OsmdroidFragment osmdroidFragment, View root, TextView textView, int i10, KeyEvent keyEvent) {
        if (i10 != 2 && i10 != 6) {
            return false;
        }
        // Hide the keyboard
        InputMethodManager imm = (InputMethodManager) osmdroidFragment.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(root.getWindowToken(), 0);
        }
        // Perform search if text is present
        if (textView.length() > 0) {
            String searchText = osmdroidFragment._binding.edittextMapSearch.getText().toString();
            osmdroidFragment.searchLocationName(searchText);
        }

        return true;
    }

    public final void searchLocationName(final String locationName) {
        try {
            Geocoder geocoder = new Geocoder(requireContext(), Locale.getDefault());

            if (Build.VERSION.SDK_INT >= 33) {
                geocoder.getFromLocationName(locationName, 1, 0.0d, 0.0d, 0.0d, 0.0d, new Geocoder.GeocodeListener() {
                    @Override
                    public void onGeocode(List<Address> addresses) {
                        if (!addresses.isEmpty()) {
                            Address address = addresses.get(0);
                            moveCameraMap(locationName, new GeoPoint(address.getLatitude(), address.getLongitude()));
                        } else {
                            Toast.makeText(requireContext(), "Location Not Found", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            } else {
                List<Address> addresses = geocoder.getFromLocationName(locationName, 1);
                if (!addresses.isEmpty()) {
                    Address address = addresses.get(0);
                    moveCameraMap(locationName, new GeoPoint(address.getLatitude(), address.getLongitude()));
                } else {
                    Toast.makeText(requireContext(), "Location Not Found", Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception e) {
            // Log the exception message
            Log.e("searchLocationName", "Search failed: " + e.getLocalizedMessage());
        }
    }

    private final void moveCameraMap(String locationName, GeoPoint geoPoint) {
        if (!locationName.isEmpty()) {
            if (requireActivity() instanceof OfflineMapActivity) {

            }
        }
    }



    private void handleMapClick() {
        _binding.btnMapDownload.setVisibility(View.VISIBLE);

        if (selectedBoundingBox == null) {
            if (this.mapView == null) {
                return;
            }
            Polygon polygon = new Polygon(mapView);
//            polygon.getFillPaint().setColor(R.color.quiz_bar_color);
            polygon.getFillPaint().setColor(Color.argb(128, 255, 255, 255));
            polygon.getFillPaint().setStrokeWidth(10f);
            polygon.getFillPaint().setPathEffect(new DashPathEffect(new float[]{40f, 40f}, 0f));
            selectedBoundingBox = polygon;
            mapView.getOverlays().add(polygon);
        }

        if (mapView == null) {
            return;
        }
        int width = mapView.getWidth();
        int height = mapView.getHeight();
        int centerX = width / 2;
        int centerY = height / 2;
        Rect rect = new Rect(0, 0, width, height);
//        double d = 2.0;
        double d11 = 1 - (0.8 * 2);
        double width2 = rect.width() * d11;
        double height2 = rect.height() * d11;
        double a = mapView.getProjection().fromPixels(centerX, (int) (centerY - height2 / 2)).getLatitude();
        double b = mapView.getProjection().fromPixels(centerX, (int) (centerY + height2 / 2)).getLatitude();
        double c = mapView.getProjection().fromPixels((int) (centerX - width2 / 2), centerY).getLongitude();
        double d = mapView.getProjection().fromPixels((int) (centerX + width2 / 2), centerY).getLongitude();

        points = new ArrayList();
        points.add(new GeoPoint(a, c));
        points.add(new GeoPoint(a, d));
        points.add(new GeoPoint(b, d));
        points.add(new GeoPoint(b, c));
        points.add(new GeoPoint(a, c));

        if (selectedBoundingBox != null) {
            selectedBoundingBox.setPoints(points);
        }
        mapView.invalidate();
    }

//    public final void handleMapClick() {
//        _binding.btnMapDownload.setVisibility(View.VISIBLE);
//        // Initialize selectedBoundingBox if not already initialized
//        if (this.selectedBoundingBox == null) {
//            MapView mapView = getMapViewOrThrow();
//            Polygon boundingBox = new Polygon(mapView);
//            boundingBox.onDetach(null);
//            boundingBox.getFillPaint().setColor(ViewCompat.MEASURED_STATE_MASK);
//            boundingBox.getFillPaint().setStrokeWidth(10.0f);
//            boundingBox.getFillPaint().setPathEffect(new DashPathEffect(new float[]{40.0f, 40.0f}, 0.0f));
//            mapView.getOverlays().add(boundingBox);
//            this.selectedBoundingBox = boundingBox;
//        }
//
//        // Calculate bounding box coordinates
//        MapView mapView = getMapViewOrThrow();
//        Rect rect = new Rect(0, 0, mapView.getWidth(), mapView.getHeight());
//        double scale = 1 - (0.8d * 2);
//        double width2 = rect.width() * scale;
//        double height = rect.height() * scale;
//        int centerX = rect.centerX();
//        int centerY = rect.centerY();
//
//        double topLeftLat = mapView.getProjection().fromPixels(centerX, (int) (centerY - height / 2)).getLatitude();
//        double bottomLeftLat = mapView.getProjection().fromPixels(centerX, (int) (centerY + height / 2)).getLatitude();
//        double topLeftLon = mapView.getProjection().fromPixels((int) (centerX - width2 / 2), centerY).getLongitude();
//        double topRightLon = mapView.getProjection().fromPixels((int) (centerX + width2 / 2), centerY).getLongitude();
//
//        // Define bounding box points
//        ArrayList<GeoPoint> points = new ArrayList<>();
//        points.add(new GeoPoint(topLeftLat, topLeftLon));
//        points.add(new GeoPoint(topLeftLat, topRightLon));
//        points.add(new GeoPoint(bottomLeftLat, topRightLon));
//        points.add(new GeoPoint(bottomLeftLat, topLeftLon));
//        points.add(new GeoPoint(topLeftLat, topLeftLon)); // Closing the bounding box
//
//        Log.e("MTAG", "handleMapClick:" +points);
//        Log.e("MTAG", "handleMapClick:" +selectedBoundingBox);
//        try {
//            selectedBoundingBox.setPoints(points);
//        }catch (Exception e){
//
//        }
//        mapView.invalidate();
//    }

    // Helper method to get MapView or throw exception if null
    private MapView getMapViewOrThrow() {
        if (this.mapView == null) {
            throw new NullPointerException("mapView is null");
        }
        return this.mapView;
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (requireActivity() instanceof CommunicationMediator) {
            communicationMediator = (CommunicationMediator) requireActivity();
        } else {
            communicationMediator = null;
        }
        if (communicationMediator != null) {
            this.communicationMediator = (CommunicationMediator) requireActivity();
            communicationMediator.setCommunicationListener(this);
        }
        requireActivity().getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (_binding.imgClose.getVisibility() == View.VISIBLE || _binding.circleLayout2.getVisibility() == View.GONE) {
                    clearPoiMarkers(true);
                    _binding.imgClose.setVisibility(View.GONE);
                    _binding.includePoiLayout.getRoot().setVisibility(View.GONE);
                    _binding.includePoiListLayout.getRoot().setVisibility(View.GONE);
                    _binding.imgOnList.setVisibility(View.GONE);
                    _binding.includePoiListLayout.imgOnMap.setVisibility(View.GONE);
                    _binding.circleLayout2.setVisibility(View.VISIBLE);
                    _binding.btnZoomOut.setVisibility(android.view.View.VISIBLE);
                    _binding.btnZoomIn.setVisibility(android.view.View.VISIBLE);
                    return;
                }
                if (!findNavController(OsmdroidFragment.this).popBackStack()) {
                    requireActivity().finish();
                }
            }
        });

    }

    public final void clearPoiMarkers(boolean shouldClear) {
        if (mapView == null) {
            throw new IllegalStateException("mapView is not initialized");
        }
        mapView.getOverlays().remove(poiMarkers);
        if (poiMarkers != null) {
            List<Overlay> overlays = poiMarkers.getItems();
            if (overlays != null) {
                overlays.clear();
            }
        }
        if (!shouldClear) {
            mapView.getOverlays().add(poiMarkers);
        }
        if (roadOverlay != null) {
            mapView.getOverlays().remove(roadOverlay);
        }
        mapView.invalidate();
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (!checkLocationPermission()) {
            new LocationPermissionDialog().show(getParentFragmentManager(), "location_perm");
        }

    }

    public final boolean checkLocationPermission() {
        Context context = getContext();
        boolean hasPermission = context != null && ContextCompat.checkSelfPermission(context,
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (_binding != null) {
            _binding.locationPermissionAlert.setVisibility(hasPermission ? View.GONE : View.VISIBLE);
        }
        return hasPermission;
    }


    @Override
    public void locationPermission(boolean z10) {
        if (z10) {
            initializeService();
        }
    }

    private final void initializeService() {
        if (!checkIfFragmentAttached(this)) {
            return;
        }
        requireContext().bindService(new Intent(requireContext(), LocationUpdatesService.class), this.mServiceConnection, 1);
    }

    public final boolean checkIfFragmentAttached(Fragment fragment) {
        return fragment.isAdded() && fragment.getContext() != null;
    }


    @Override
    public void onServiceClosed() {
        if (mService != null) {
            mService.j();
        }

    }

    public  boolean onIncludePoiLayout(
            OsmdroidFragment fragment, View root, TextView textView, int actionId, KeyEvent keyEvent) {
        if (actionId != 2 && actionId != 6) {
            return false;
        }

        // Hide UI elements
        fragment._binding.includePoiLayout.getRoot().setVisibility(View.GONE);
        fragment._binding.imgClose.setVisibility(View.GONE);

        // Hide keyboard
        InputMethodManager imm = (InputMethodManager) fragment.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(root.getWindowToken(), 0);
        }

        // Build the POI search URL
        selectedPoiName = fragment._binding.includePoiLayout.editText.getText().toString();
        String baseUrl = descipt() + "api?lat=";
        StringBuilder urlBuilder = new StringBuilder(baseUrl)
                .append(fragment.mapView.getMapCenter().getLatitude())
                .append("&lon=")
                .append(fragment.mapView.getMapCenter().getLongitude())
                .append("&q=")
                .append(selectedPoiName != null ? selectedPoiName.toLowerCase(Locale.ROOT) : "")
                .append("&limit=30");
        // Load POIs
        fragment.loadPOIs(urlBuilder.toString(), null);

        fragment._binding.includePoiLayout.editText.getText().clear();

        return true;
    }

    public final void loadPOIs(String str, Integer num) {
        // Handle coroutine states
//        if (this.f9584a == 0) {
//            OsmdroidFragment fragment = OsmdroidFragment.this;
//            fragment.clearPoiMarkers(false);
//            if (mapView != null) {
//                mapView.getOverlays().add(fragment.poiMarkers);
//            }
//            ArrayList<PoiParserDatas> poiList = PoiProvider.f7326a.a(this.f9586c, "OSMRadarUserAgent");
//            Drawable drawable = (fragment.getContext() != null) ?
//                    ContextCompat.getDrawable(fragment.getContext(), R.drawable.ic_pin_new) : null;
//
//            if (poiList.isEmpty()) {
//                MainCoroutineDispatcher dispatcher = Dispatchers.c();
//                a continuation = new a(fragment, null);
//                this.f9584a = 1;
//                if (t9.i.g(dispatcher, continuation, this) == COMPLETION) {
//                    return COMPLETION;
//                }
//            } else {
//                ArrayList<PoiListItem> items = new ArrayList<>();
//                for (PoiParserDatas data : poiList) {
//                    String description = data.d();
//                    MapView mapView2 = fragment.mapView;
//                    if (mapView2 != null) {
//                        Marker marker = new Marker(mapView2);
//                        marker.F(data.f());
//                        marker.E(data.c() + ' ' + data.e() + ' ' + data.a());
//                        marker.S(data.b());
//                        if (drawable != null) {
//                            marker.P(drawable);
//                        }
//                        items.add(new PoiListItem(description, this.f9587d, 0, marker));
//
//                        FolderOverlay folderOverlay = fragment.poiMarkers;
//                        if (folderOverlay != null) {
//                            boxing.a(folderOverlay.x(marker));
//                        }
//                        marker.R(new Marker.a() {
//                            @Override // mc.Marker.a
//                            public boolean a(Marker marker, MapView mapView) {
//                                return OsmdroidFragment.f.i(fragment, marker, mapView);
//                            }
//                        });
//                    }
//                }
//                MainCoroutineDispatcher dispatcher = Dispatchers.c();
//                b continuation = new b(fragment, items, null);
//                this.f9584a = 2;
//                if (t9.i.g(dispatcher, continuation, this) == COMPLETION) {
//                    return COMPLETION;
//                }
//            }
//        } else if (this.f9584a == 1 || this.f9584a == 2) {
//            o.b(obj);
//        } else {
//            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
//        }
//        return Unit.f13318a;
    }


    public static final String descipt() {
        return a1(-7549159007961482559L);
    }

    public static String a1(long j10) {
        String[] strArr = {"￢ﾗÏ뢨턫쒯Ⅱ㛴텴쒱℺㚫텵쒰℺㚯턷쒳ℵ㚽턲쒲ℿ㚾턩쓲ℸ㚴턶쓳\uffddﾗÏ뢨턫쒯Ⅱ㛴텴쒰ℴ㚸턺쒨Ⅎ㚴턵쓲ℷ㚺턯쒰ℴ㚵턽쒵ℵ㚿턾쒮ⅵ㚸턴쒱ⅴ"};
        return b(j10, strArr);
    }

    public static String b(long j10, String[] strArr) {
        long a10 = e.a(e.c(4294967295L & j10));
        long j11 = (a10 >>> 32) & 65535;
        long a11 = e.a(a10);
        int i10 = (int) (((j10 >>> 32) ^ j11) ^ ((a11 >>> 16) & (-65536)));
        long a12 = a(i10, strArr, a11);
        int i11 = (int) ((a12 >>> 32) & 65535);
        char[] cArr = new char[i11];
        for (int i12 = 0; i12 < i11; i12++) {
            a12 = a(i10 + i12 + 1, strArr, a12);
            cArr[i12] = (char) ((a12 >>> 32) & 65535);
        }
        return new String(cArr);
    }

    public static long a(int i10, String[] strArr, long j10) {
        return ((long) strArr[i10 / 8191].charAt(i10 % 8191) << 32) ^ e.a(j10);
    }

    static public class e {
        public static long a(long j10) {
            short s10 = (short) (j10 & 65535);
            short s11 = (short) ((j10 >>> 16) & 65535);
            short b10 = (short) (b((short) (s10 + s11), 9) + s10);
            short s12 = (short) (s11 ^ s10);
            return ((long) (b(s12, 10) | (b10 << 16)) << 16) | ((short) (((short) (b(s10, 13) ^ s12)) ^ (s12 << 5)));
        }

        public static short b(short s10, int i10) {
            return (short) ((s10 >>> (32 - i10)) | (s10 << i10));
        }

        public static long c(long j10) {
            long j11 = (j10 ^ (j10 >>> 33)) * 7109453100751455733L;
            return ((j11 ^ (j11 >>> 28)) * (-3808689974395783757L)) >>> 32;
        }
    }


}
