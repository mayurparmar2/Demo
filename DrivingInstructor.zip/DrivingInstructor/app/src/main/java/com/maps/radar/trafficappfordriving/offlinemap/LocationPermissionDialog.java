package com.maps.radar.trafficappfordriving.offlinemap;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;

import com.demo.radar.trafficappfordriving2.databinding.OfflineMapsDialogLocationPermissionBinding;

public final class LocationPermissionDialog extends DialogFragment {

    private OfflineMapsDialogLocationPermissionBinding binding;

    private void openAppSettings() {
        FragmentActivity activity = getActivity();
        if (activity instanceof AppCompatActivity) {
            Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", activity.getPackageName(), null));
            startActivity(intent);
        }
    }

    @Override
    public int getTheme() {
        return android.R.style.Theme_Black_NoTitleBar;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = OfflineMapsDialogLocationPermissionBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume();
        Context context = getContext();
        if (context != null &&
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            dismiss();
        }
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        ViewCompat.setOnApplyWindowInsetsListener(view, (v, insets) -> {
            Insets statusBarInsets = insets.getInsets(WindowInsetsCompat.Type.statusBars());
            if (v.getLayoutParams() instanceof FrameLayout.LayoutParams) {
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) v.getLayoutParams();
                layoutParams.topMargin = statusBarInsets.top;
                layoutParams.bottomMargin = statusBarInsets.bottom;
                v.setLayoutParams(layoutParams);
            }
            return WindowInsetsCompat.CONSUMED;
        });

        if (binding != null) {
            binding.btnYes.setOnClickListener(v -> {
                openAppSettings();
                dismiss();
            });

            binding.exit.setOnClickListener(v -> dismiss());
        }
    }
}
