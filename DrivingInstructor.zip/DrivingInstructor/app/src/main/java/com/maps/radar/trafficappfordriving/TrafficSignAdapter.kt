package com.maps.radar.trafficappfordriving

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.demo.radar.trafficappfordriving2.databinding.TrafficSignsModuleItemListBinding
import com.maps.radar.trafficappfordriving.model.TrafficSign

class TrafficSignAdapter(private val clickCallback: (TrafficSign) -> Unit) : ListAdapter<TrafficSign, TrafficSignAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = TrafficSignsModuleItemListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item)
    }

    inner class ViewHolder(private val binding: TrafficSignsModuleItemListBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: TrafficSign) {
            binding.txtSign.text = item.name
            Glide.with(binding.imgSign)
                .load(item.img_url)
                .into(binding.imgSign)
            binding.root.setOnClickListener {
                clickCallback(item)
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<TrafficSign>() {
        override fun areItemsTheSame(oldItem: TrafficSign, newItem: TrafficSign): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: TrafficSign, newItem: TrafficSign): Boolean {
            return oldItem == newItem
        }
    }
}
