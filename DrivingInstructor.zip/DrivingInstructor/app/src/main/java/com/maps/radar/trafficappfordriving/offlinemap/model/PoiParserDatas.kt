package com.maps.radar.trafficappfordriving.offlinemap.model

import org.osmdroid.util.GeoPoint

data class PoiParserDatas(
    @JvmField val type: String,
    @JvmField val name: String,
    @JvmField val street: String,
    @JvmField val district: String,
    @JvmField val city: String,
    @JvmField val state: String,
    @JvmField val country: String,
    @JvmField val postcode: String,
    @JvmField val coordinates: GeoPoint,
    @JvmField val osmKey: String,
) {
    fun getCity(): String = city
    fun getCoordinates(): GeoPoint = coordinates
    fun getDistrict(): String = district
    fun getName(): String = name
    fun getStreet(): String = street
}
