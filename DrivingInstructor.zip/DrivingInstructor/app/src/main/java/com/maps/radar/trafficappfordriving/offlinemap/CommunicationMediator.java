package com.maps.radar.trafficappfordriving.offlinemap;

import com.maps.radar.trafficappfordriving.ui.radar.CommunicationListener;

public interface CommunicationMediator {
    void setCommunicationListener(CommunicationListener communicationListener);
}