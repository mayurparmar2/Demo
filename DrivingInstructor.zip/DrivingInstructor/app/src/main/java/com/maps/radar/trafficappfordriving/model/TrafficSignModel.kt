package com.maps.radar.trafficappfordriving.model

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore
import com.demo.radar.trafficappfordriving2.R

data class TrafficSignModel(
    val id: Int,
    val name: String,
    val description: String,
    val imgUrl: String,
    var bitmap: Bitmap? = null
) {
    fun getShareIntent(context: Context): Intent {
        val intent = Intent()
        bitmap?.let {
            val insertImage = MediaStore.Images.Media.insertImage(context.contentResolver, it, "", null)
            val shareText = "$name\n\n$description"
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.action = Intent.ACTION_SEND
            intent.type = "image/*"
            intent.putExtra(Intent.EXTRA_STREAM, Uri.parse(insertImage))
            intent.putExtra(Intent.EXTRA_TEXT, shareText)
        }
        return Intent.createChooser(intent, context.getString(R.string.traffic_signs_module_share_sign))
    }
}