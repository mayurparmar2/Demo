package com.maps.radar.trafficappfordriving.Db

import androidx.annotation.Keep

@Keep
data class HomeScreenObjects(
    val icon: String,
    val title: String
)
