package com.maps.radar.trafficappfordriving.Db
import androidx.lifecycle.LiveData
class QuizProgressRepo(private val dao: QuizProgressDao) {

    val allProgressItem: LiveData<List<QuizProgressItem>> = dao.getAllProgressItem()
    val allDoneData: LiveData<List<QuizProgressItem>> = dao.getAllDoneData()

   suspend fun addProgressItem(quizProgressItem: QuizProgressItem) {
        dao.addProgressItem(quizProgressItem)
    }

    suspend fun startTest(i10: Int) {
        dao.startTest(i10)
    }

    suspend fun updateProgressItem(newProgress: Float, index: Int) {
        dao.updateProgressItem(newProgress, index)
    }
}