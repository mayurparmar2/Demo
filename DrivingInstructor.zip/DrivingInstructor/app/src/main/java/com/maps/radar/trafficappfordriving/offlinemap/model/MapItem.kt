package com.maps.radar.trafficappfordriving.offlinemap.model

data class MapItem(
    val iconResId: Int,
    val name: String,
    val packageId: String
)
