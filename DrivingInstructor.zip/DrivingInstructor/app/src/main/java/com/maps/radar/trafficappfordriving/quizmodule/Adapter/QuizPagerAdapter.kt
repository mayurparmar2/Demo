package com.maps.radar.trafficappfordriving.quizmodule.Adapter

import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.maps.radar.trafficappfordriving.model.QuizMain
import com.maps.radar.trafficappfordriving.quizmodule.QuizFragment

class QuizPagerAdapter(
    fragment: Fragment?,
    private val quizList: List<QuizMain.All>,
    private val testIndex: Int,
    private val questionMark: Float
) : FragmentStateAdapter(
    fragment!!
) {
    override fun createFragment(position: Int): Fragment {
        return QuizFragment.newInstance(position, testIndex, quizList[position], questionMark)
    }

    override fun getItemCount(): Int {
        return quizList.size
    }
}
