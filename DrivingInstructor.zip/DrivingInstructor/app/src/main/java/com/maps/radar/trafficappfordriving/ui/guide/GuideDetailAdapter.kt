package com.maps.radar.trafficappfordriving.ui.guide

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.ListItemGuideImageBinding
import com.demo.radar.trafficappfordriving2.databinding.ListItemGuideTextBinding
import com.demo.radar.trafficappfordriving2.databinding.ListItemGuideVideoBinding
import com.maps.radar.trafficappfordriving.model.f
import com.maps.radar.trafficappfordriving.ui.guide.model.Guide


class GuideDetailAdapter(
    private val groupId: Int,
    private val id: Int,
//    , private val playerProvider: () -> ExoPlayer
) : ListAdapter<Guide, GuideDetailAdapter.AbstractGuideItemViewHolder>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<Guide>() {
            override fun areItemsTheSame(oldItem: Guide, newItem: Guide): Boolean {
                return oldItem === newItem
            }

            override fun areContentsTheSame(oldItem: Guide, newItem: Guide): Boolean {
                return oldItem.id == newItem.id
            }
        }
    }

    abstract class AbstractGuideItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun getItemViewType(position: Int): Int {
        val item = getItem(position)
        return when (item) {
            is Guide.TextGuide -> 0
            is Guide.ImageGuide -> 1
            is Guide.VideoGuide -> 2
            else -> throw RuntimeException()
        }
    }

    override fun onBindViewHolder(holder: AbstractGuideItemViewHolder, position: Int) {
        val item = getItem(position)
        when (holder) {
            is GuideImageViewHolder -> holder.bind(item as Guide.ImageGuide)
            is GuideTextItemViewHolder -> holder.bind(item as Guide.TextGuide)
            is GuideVideoViewHolder -> holder.bind(item as Guide.VideoGuide)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AbstractGuideItemViewHolder {
        return when (viewType) {
            0 -> GuideTextItemViewHolder(
                LayoutInflater.from(parent.context)
                    .inflate(R.layout.list_item_guide_text, parent, false)
            )

            1 -> GuideImageViewHolder(
                LayoutInflater.from(parent.context)
                    .inflate(R.layout.list_item_guide_image, parent, false)
            )

            2 -> GuideVideoViewHolder(
                LayoutInflater.from(parent.context)
                    .inflate(R.layout.list_item_guide_video, parent, false)
            )

            else -> throw RuntimeException()
        }
    }

    inner class GuideImageViewHolder(itemView: View) : AbstractGuideItemViewHolder(itemView) {
        private val binding = ListItemGuideImageBinding.bind(itemView)

        fun bind(item: Guide.ImageGuide) {
            this.binding.title.setText(item.bodyImage.toString() + "")
            Glide.with(binding.root.context)
                .load(f.f105a.d(groupId, id))
//                .load(R.drawable.img_icon)
                .into(binding.image)
        }
    }

    inner class GuideTextItemViewHolder(itemView: View) : AbstractGuideItemViewHolder(itemView) {
        private val binding = ListItemGuideTextBinding.bind(itemView)
        fun bind(item: Guide.TextGuide) {
            binding.title.text = item.item.title
            item.item.lines?.let {
                if (item.item.title.isNotEmpty()) {
                    binding.title.setText(item.item.title)
                }
                val text = StringBuilder()
                if (item.item.hasBullet) {
                    for (stringId in item.item.lines) {
                        text.append(stringId)
                            .append(System.lineSeparator())
                            .append(System.lineSeparator())
                    }
                } else {
                    for (stringId in item.item.lines) {
                        text.append(stringId)
                            .append(System.lineSeparator())
                    }
                }
                binding.body.text = text.toString()
                if (text.isNotEmpty()) {
                    binding.body.visibility = View.VISIBLE
                } else {
                    binding.body.visibility = View.GONE
                }
            }

        }
    }

    inner class GuideVideoViewHolder(itemView: View) : AbstractGuideItemViewHolder(itemView) {
        private val binding = ListItemGuideVideoBinding.bind(itemView)
        fun bind(item: Guide.VideoGuide) {
            // bind video
        }
    }
}