package com.maps.radar.trafficappfordriving.model

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Parcelable
import android.provider.MediaStore
import android.transition.Transition
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.SimpleTarget
import com.demo.radar.trafficappfordriving2.R
import kotlinx.parcelize.Parcelize


@Parcelize
data class TrafficSign(
    val id: Int,
    val name: String,
    val description: String,
    val img_url: String,
    val word_name: WordName,
    val word_desc: WordDesc
) : Parcelable {
    @Parcelize
    data class WordName(
        val tr: String,
        val de: String,
        val el: String,
        val fr: String,
        val zh: String,
        val ja: String,
        val ko: String,
        val it: String,
        val pa: String,
        val vi: String,
        val fa: String,
        val hi: String,
        val ru: String,
        val es: String,
        val pt: String,
        val `in`: String,
        val ms: String,
        val ar: String,
        val nl: String,
        val iw: String,
        val th: String,
        val pl: String,
        val sw: String,
        val ta: String,
        val ur: String,
        val mr: String,
        val gu: String,
        val ka: String,
        val uz: String,
        val az: String,
        val sr: String,
        val mn: String,
        val km: String,
        val bn: String,
        val ro: String,
        val tl: String,
        val te: String,
        val ha: String,
        val jv: String,
        val kn: String,
        val ps: String,
        val uk: String,
        val yo: String,
        val ml: String,
        val or: String,
        val my: String,
        val sd: String,
        val kk: String,
        val bho: String,
        val mai: String,
        val fil: String,
        val ne: String,
        val dv: String,
        val si: String
    ) : Parcelable

    @Parcelize
    data class WordDesc(
        val tr: String,
        val de: String,
        val el: String,
        val fr: String,
        val zh: String,
        val ja: String,
        val ko: String,
        val it: String,
        val pa: String,
        val vi: String,
        val fa: String,
        val hi: String,
        val ru: String,
        val es: String,
        val pt: String,
        val `in`: String,
        val ms: String,
        val ar: String,
        val nl: String,
        val iw: String,
        val th: String,
        val pl: String,
        val sw: String,
        val ta: String,
        val ur: String,
        val mr: String,
        val gu: String,
        val ka: String,
        val uz: String,
        val az: String,
        val sr: String,
        val mn: String,
        val km: String,
        val bn: String,
        val ro: String,
        val tl: String,
        val te: String,
        val ha: String,
        val jv: String,
        val kn: String,
        val ps: String,
        val uk: String,
        val yo: String,
        val ml: String,
        val or: String,
        val my: String,
        val sd: String,
        val kk: String,
        val bho: String,
        val mai: String,
        val fil: String,
        val ne: String,
        val dv: String,
        val si: String
    ) : Parcelable


    fun getShareIntent(bitmap: Bitmap, context: Context): Intent {
        val intent = Intent()
        bitmap.let {
            val insertImage = MediaStore.Images.Media.insertImage(context.contentResolver, bitmap, "", null)
            val shareText = "$name\n\n$description"
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.action = Intent.ACTION_SEND
            intent.type = "image/*"
            intent.putExtra(Intent.EXTRA_STREAM, Uri.parse(insertImage))
            intent.putExtra(Intent.EXTRA_TEXT, shareText)
        }
        return Intent.createChooser(intent, context.getString(R.string.traffic_signs_module_share_sign))
    }

}
