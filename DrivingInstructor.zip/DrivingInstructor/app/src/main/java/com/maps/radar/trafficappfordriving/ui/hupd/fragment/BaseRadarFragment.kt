package com.maps.radar.trafficappfordriving.ui.hupd.fragment

import android.content.ComponentName
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.IBinder
import android.view.View
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil.setContentView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.demo.radar.trafficappfordriving2.R
import com.maps.radar.trafficappfordriving.ui.hupd.LocationUpdateListener
import com.maps.radar.trafficappfordriving.ui.hupd.LocationUpdatesService
import com.maps.radar.trafficappfordriving.ui.radar.FragmentBridgeViewModel
import com.maps.radar.trafficappfordriving.ui.radar.RadarModel
import com.maps.radar.trafficappfordriving.ui.radar.viewmodel.DataStoreViewModel
import com.maps.radar.trafficappfordriving.ui.radar.viewmodel.RadarViewModel
import java.util.List


abstract class BaseRadarFragment : Fragment(), LocationUpdateListener {

    private lateinit var dataStoreViewModel: DataStoreViewModel
    private var mBound: Boolean = false
    private var mService: LocationUpdatesService? = null
    private var tempLocation: Location? = null
    private var unitLength: String = "KMPH"
    private lateinit var radarViewModel: RadarViewModel
    private lateinit var fragmentBridgeViewModel: FragmentBridgeViewModel
    lateinit var mServiceConnection: ServiceConnection


    override fun onCreate(bundle: Bundle?) {
        super.onCreate(bundle)

        dataStoreViewModel = ViewModelProvider(this).get(DataStoreViewModel::class.java)
        radarViewModel = ViewModelProvider(this).get(RadarViewModel::class.java)
        fragmentBridgeViewModel = ViewModelProvider(this).get(FragmentBridgeViewModel::class.java)
        this.mServiceConnection = ServiceConnection()
    }
    private fun checkGPSEnabled() {
        if (!isLocationEnabled()) {
            setWarningState(true)
//            k6.d.f9052a.e(requireActivity())
            return
        }
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                "android.permission.ACCESS_FINE_LOCATION"
            ) == 0
        ) {
            setWarningState(false)
            initializeService()
        } else {
            setWarningState(true)
            checkLocationPermission()
        }
    }

    private fun checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                "android.permission.ACCESS_FINE_LOCATION"
            ) != 0
        ) {
//            if (com.helper.ads.library.core.utils.j.a(activity) && (activity is AppCompatActivity)) {
//                k6.d.f9052a.d(activity as AppCompatActivity)
//            }
        }
    }

    private fun initializeService() {
        requireContext().bindService(
            Intent(requireContext(), LocationUpdatesService::class.java),
            mServiceConnection,
            1
        )
    }

    private fun isLocationEnabled(): Boolean {
        val locationManager = requireActivity().getSystemService("location") as LocationManager
        return locationManager.isProviderEnabled("gps") || locationManager.isProviderEnabled("network")
    }

    abstract fun calculateSpeedWarning(num: Int)

    final fun getDataStoreViewModel(): DataStoreViewModel {
        return dataStoreViewModel
    }

    final fun getMService(): LocationUpdatesService? {
        return mService
    }

    final fun getUnitLength(): String {
        return unitLength
    }

    final fun setUnitLength(str: String) {
        unitLength = str
    }

    override fun onLocationChanged(location: Location) {
        if (location.speed == 0.0f) {
            return
        }
        tempLocation = location
        radarViewModel.getNearest(location.longitude, location.latitude)
    }

    override fun onResume() {
        super.onResume()
        checkGPSEnabled()
        updateValues()
    }


    inner class ServiceConnection : android.content.ServiceConnection {
        // android.content.ServiceConnection
        override fun onServiceConnected(componentName: ComponentName, iBinder: IBinder) {
            setMService((iBinder as LocationUpdatesService.LocationBinder).service)
            setMBound(true)
            val mService: LocationUpdatesService? = getMService()
            mService?.c(this@BaseRadarFragment)
            getMService()?.h()
        }
        override fun onServiceDisconnected(componentName: ComponentName) {
            setMService(null)
            setMBound(false)
        }
    }


    fun setMBound(z10: Boolean) {
        this.mBound = z10
    }


    fun setMService(locationUpdatesService: LocationUpdatesService?) {
        this.mService = locationUpdatesService
    }

    abstract fun nextRadarWarning(list: List<RadarModel>)

    abstract fun setWarningState(z: Boolean)

    abstract fun updateValues()
}