package com.maps.radar.trafficappfordriving.offlinemap.model

import com.google.gson.annotations.SerializedName

data class PoiParserDatasRes(
    @SerializedName("features")
    val features: ArrayList<PoiParserDatas> = ArrayList(),
    
    @SerializedName("type")
    val type: String? = null
)