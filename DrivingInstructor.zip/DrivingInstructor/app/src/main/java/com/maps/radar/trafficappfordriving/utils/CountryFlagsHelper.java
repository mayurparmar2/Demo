package com.maps.radar.trafficappfordriving.utils;

import androidx.annotation.DrawableRes;

import com.demo.radar.trafficappfordriving2.R;

public final class CountryFlagsHelper {
    @DrawableRes
    public static Integer a(String s) {
        int v = s.hashCode();
        if(v != 2091) {
            switch(v) {
                case 2083: {
                    return s.equals("AD") ? (R.drawable.andorra) : null;
                }
                case 2084: {
                    return s.equals("AE") ? (R.drawable.united_arab_emirates) : null;
                }
                case 2085: {
                    return s.equals("AF") ? (R.drawable.afghanistan) : null;
                }
                case 2086: {
                    return s.equals("AG") ? (R.drawable.antigua_and_barbuda) : null;
                }
                case 2088: {
                    return s.equals("AI") ? (R.drawable.anguilla) : null;
                }
                case 2092: {
                    return s.equals("AM") ? (R.drawable.armenia) : null;
                }
                case 0x830: {
                    return s.equals("AQ") ? (R.drawable.antarctica) : null;
                }
                case 2097: {
                    return s.equals("AR") ? (R.drawable.argentina) : null;
                }
                case 2098: {
                    return s.equals("AS") ? (R.drawable.american_samoa) : null;
                }
                case 2099: {
                    return s.equals("AT") ? (R.drawable.austria) : null;
                }
                case 2100: {
                    return s.equals("AU") ? (R.drawable.australia) : null;
                }
                case 2102: {
                    return s.equals("AW") ? (R.drawable.aruba) : null;
                }
                case 2103: {
                    return s.equals("AX") ? (R.drawable.aland_islands) : null;
                }
                case 2105: {
                    return s.equals("AZ") ? (R.drawable.azerbaijan) : null;
                }
                case 0x83F: {
                    return s.equals("BA") ? (R.drawable.bosnia_and_herzegovina) : null;
                }
                case 0x840: {
                    return s.equals("BB") ? (R.drawable.barbados) : null;
                }
                case 0x842: {
                    return s.equals("BD") ? (R.drawable.bangladesh) : null;
                }
                case 0x843: {
                    return s.equals("BE") ? (R.drawable.belgium) : null;
                }
                case 0x844: {
                    return s.equals("BF") ? (R.drawable.burkina_faso) : null;
                }
                case 0x845: {
                    return s.equals("BG") ? (R.drawable.bulgaria) : null;
                }
                case 0x846: {
                    return s.equals("BH") ? (R.drawable.bahrain) : null;
                }
                case 0x847: {
                    return s.equals("BI") ? (R.drawable.burundi) : null;
                }
                case 2120: {
                    return s.equals("BJ") ? (R.drawable.benin) : null;
                }
                case 0x84A: {
                    return s.equals("BL") ? (R.drawable.saint_barthelemy) : null;
                }
                case 0x84B: {
                    return s.equals("BM") ? (R.drawable.bermuda) : null;
                }
                case 0x84C: {
                    return s.equals("BN") ? (R.drawable.brunei_darussalam) : null;
                }
                case 0x84D: {
                    return s.equals("BO") ? (R.drawable.bolivia) : null;
                }
                case 0x84F: {
                    return s.equals("BQ") ? (R.drawable.sint_eustatius_and_saba) : null;
                }
                case 0x850: {
                    return s.equals("BR") ? (R.drawable.brazil) : null;
                }
                case 0x851: {
                    return s.equals("BS") ? (R.drawable.bahamas) : null;
                }
                case 2130: {
                    return s.equals("BT") ? (R.drawable.bhutan) : null;
                }
                case 0x854: {
                    return s.equals("BV") ? (R.drawable.bouvet_island) : null;
                }
                case 0x855: {
                    return s.equals("BW") ? (R.drawable.botswana) : null;
                }
                case 0x857: {
                    return s.equals("BY") ? (R.drawable.belarus) : null;
                }
                case 0x858: {
                    return s.equals("BZ") ? (R.drawable.belize) : null;
                }
                case 0x85E: {
                    return s.equals("CA") ? (R.drawable.canada) : null;
                }
                case 0x860: {
                    return s.equals("CC") ? (R.drawable.cocos_islands) : null;
                }
                case 0x861: {
                    return s.equals("CD") ? (R.drawable.democratic_republic_congo) : null;
                }
                case 0x863: {
                    return s.equals("CF") ? (R.drawable.central_african_republic) : null;
                }
                case 0x864: {
                    return s.equals("CG") ? (R.drawable.republic_congo) : null;
                }
                case 0x865: {
                    return s.equals("CH") ? (R.drawable.switzerland) : null;
                }
                case 2150: {
                    return s.equals("CI") ? (R.drawable.ivory_coast) : null;
                }
                case 0x868: {
                    return s.equals("CK") ? (R.drawable.cook_islands) : null;
                }
                case 0x869: {
                    return s.equals("CL") ? (R.drawable.chile) : null;
                }
                case 0x86A: {
                    return s.equals("CM") ? (R.drawable.cameroon) : null;
                }
                case 0x86B: {
                    return s.equals("CN") ? (R.drawable.china) : null;
                }
                case 0x86C: {
                    return s.equals("CO") ? (R.drawable.colombia) : null;
                }
                case 0x86F: {
                    return s.equals("CR") ? (R.drawable.costa_rica) : null;
                }
                case 0x872: {
                    return s.equals("CU") ? (R.drawable.cuba) : null;
                }
                case 0x873: {
                    return s.equals("CV") ? (R.drawable.cabo_verde) : null;
                }
                case 0x874: {
                    return s.equals("CW") ? (R.drawable.curacao) : null;
                }
                case 0x875: {
                    return s.equals("CX") ? (R.drawable.christmas_island) : null;
                }
                case 0x876: {
                    return s.equals("CY") ? (R.drawable.cyprus) : null;
                }
                case 0x877: {
                    return s.equals("CZ") ? (R.drawable.czech_republic) : null;
                }
                case 0x881: {
                    return s.equals("DE") ? (R.drawable.germany) : null;
                }
                case 0x886: {
                    return s.equals("DJ") ? (R.drawable.djibouti) : null;
                }
                case 0x887: {
                    return s.equals("DK") ? (R.drawable.denmark) : null;
                }
                case 0x889: {
                    return s.equals("DM") ? (R.drawable.dominica) : null;
                }
                case 0x88B: {
                    return s.equals("DO") ? (R.drawable.dominican_republic) : null;
                }
                case 0x896: {
                    return s.equals("DZ") ? (R.drawable.algeria) : null;
                }
                case 2206: {
                    return s.equals("EC") ? (R.drawable.ecuador) : null;
                }
                case 0x8A0: {
                    return s.equals("EE") ? (R.drawable.estonia) : null;
                }
                case 2210: {
                    return s.equals("EG") ? (R.drawable.egypt) : null;
                }
                case 0x8A3: {
                    return s.equals("EH") ? (R.drawable.western_sahara) : null;
                }
                case 0x8AD: {
                    return s.equals("ER") ? (R.drawable.eritrea) : null;
                }
                case 0x8AE: {
                    return s.equals("ES") ? (R.drawable.spain) : null;
                }
                case 0x8AF: {
                    return s.equals("ET") ? (R.drawable.ethiopia) : null;
                }
                case 0x8C3: {
                    return s.equals("FI") ? (R.drawable.finland) : null;
                }
                case 0x8C4: {
                    return s.equals("FJ") ? (R.drawable.fiji) : null;
                }
                case 0x8C9: {
                    return s.equals("FO") ? (R.drawable.faroe_islands) : null;
                }
                case 0x8CC: {
                    return s.equals("FR") ? (R.drawable.france) : null;
                }
                case 0x8DA: {
                    return s.equals("GA") ? (R.drawable.gabon) : null;
                }
                case 0x8DB: {
                    return s.equals("GB") ? (R.drawable.uk) : null;
                }
                case 0x8DD: {
                    return s.equals("GD") ? (R.drawable.grenada) : null;
                }
                case 2270: {
                    return s.equals("GE") ? (R.drawable.georgia) : null;
                }
                case 0x8E0: {
                    return s.equals("GG") ? (R.drawable.guernsey) : null;
                }
                case 0x8E1: {
                    return s.equals("GH") ? (R.drawable.ghana) : null;
                }
                case 0x8E2: {
                    return s.equals("GI") ? (R.drawable.gibraltar) : null;
                }
                case 0x8E5: {
                    return s.equals("GL") ? (R.drawable.greenland) : null;
                }
                case 0x8E6: {
                    return s.equals("GM") ? (R.drawable.gambia) : null;
                }
                case 0x8E7: {
                    return s.equals("GN") ? (R.drawable.guinea) : null;
                }
                case 0x8E9: {
                    return s.equals("GP") ? (R.drawable.guadeloupe) : null;
                }
                case 0x8EA: {
                    return s.equals("GQ") ? (R.drawable.gqequatorialguinea) : null;
                }
                case 0x8EB: {
                    return s.equals("GR") ? (R.drawable.greece) : null;
                }
                case 0x8EC: {
                    return s.equals("GS") ? (R.drawable.south_korea) : null;
                }
                case 0x8ED: {
                    return s.equals("GT") ? (R.drawable.guatemala) : null;
                }
                case 0x8EE: {
                    return s.equals("GU") ? (R.drawable.guam) : null;
                }
                case 0x8F0: {
                    return s.equals("GW") ? (R.drawable.guinea_bissau) : null;
                }
                case 0x8F2: {
                    return s.equals("GY") ? (R.drawable.guyana) : null;
                }
                case 0x903: {
                    return s.equals("HK") ? (R.drawable.hong_kong) : null;
                }
                case 0x906: {
                    return s.equals("HN") ? (R.drawable.honduras) : null;
                }
                case 0x90A: {
                    return s.equals("HR") ? (R.drawable.croatia) : null;
                }
                case 0x90C: {
                    return s.equals("HT") ? (R.drawable.haiti) : null;
                }
                case 0x90D: {
                    return s.equals("HU") ? (R.drawable.hungary) : null;
                }
                case 0x91B: {
                    return s.equals("ID") ? (R.drawable.indonesia) : null;
                }
                case 0x91C: {
                    return s.equals("IE") ? (R.drawable.ireland) : null;
                }
                case 0x923: {
                    return s.equals("IL") ? (R.drawable.israel) : null;
                }
                case 2340: {
                    return s.equals("IM") ? (R.drawable.isle_of_man) : null;
                }
                case 0x925: {
                    return s.equals("IN") ? (R.drawable.india) : null;
                }
                case 0x928: {
                    return s.equals("IQ") ? (R.drawable.iiraq) : null;
                }
                case 0x929: {
                    return s.equals("IR") ? (R.drawable.iran) : null;
                }
                case 0x92A: {
                    return s.equals("IS") ? (R.drawable.iiceland) : null;
                }
                case 0x92B: {
                    return s.equals("IT") ? (R.drawable.italy) : null;
                }
                case 0x93B: {
                    return s.equals("JE") ? (R.drawable.jersey) : null;
                }
                case 0x943: {
                    return s.equals("JM") ? (R.drawable.jamaica) : null;
                }
                case 0x945: {
                    return s.equals("JO") ? (R.drawable.jordan) : null;
                }
                case 0x946: {
                    return s.equals("JP") ? (R.drawable.japan) : null;
                }
                case 0x95A: {
                    return s.equals("KE") ? (R.drawable.kenya) : null;
                }
                case 0x95C: {
                    return s.equals("KG") ? (R.drawable.kyrgyzstan) : null;
                }
                case 0x95D: {
                    return s.equals("KH") ? (R.drawable.cambodia) : null;
                }
                case 0x95E: {
                    return s.equals("KI") ? (R.drawable.kiribati) : null;
                }
                case 2402: {
                    return s.equals("KM") ? (R.drawable.comoros) : null;
                }
                case 2403: {
                    return s.equals("KN") ? (R.drawable.saint_kitts_and_nevis) : null;
                }
                case 2405: {
                    return s.equals("KP") ? (R.drawable.north_korea) : null;
                }
                case 0x96C: {
                    return s.equals("KW") ? (R.drawable.kuwait) : null;
                }
                case 0x96F: {
                    return s.equals("KZ") ? (R.drawable.kazakhstan) : null;
                }
                case 0x975: {
                    return s.equals("LA") ? (R.drawable.laos) : null;
                }
                case 0x976: {
                    return s.equals("LB") ? (R.drawable.lebanon) : null;
                }
                case 0x977: {
                    return s.equals("LC") ? (R.drawable.saint_lucia) : null;
                }
                case 0x97D: {
                    return s.equals("LI") ? (R.drawable.liechtenstein) : null;
                }
                case 0x97F: {
                    return s.equals("LK") ? (R.drawable.sri_lanka) : null;
                }
                case 0x986: {
                    return s.equals("LR") ? (R.drawable.liberia) : null;
                }
                case 0x987: {
                    return s.equals("LS") ? (R.drawable.llesotho) : null;
                }
                case 2440: {
                    return s.equals("LT") ? (R.drawable.lithuania) : null;
                }
                case 0x989: {
                    return s.equals("LU") ? (R.drawable.luxembourg) : null;
                }
                case 0x98A: {
                    return s.equals("LV") ? (R.drawable.latvia) : null;
                }
                case 0x98D: {
                    return s.equals("LY") ? (R.drawable.libya) : null;
                }
                case 0x994: {
                    return s.equals("MA") ? (R.drawable.morocco) : null;
                }
                case 0x996: {
                    return s.equals("MC") ? (R.drawable.monaco) : null;
                }
                case 0x997: {
                    return s.equals("MD") ? (R.drawable.moldova) : null;
                }
                case 0x998: {
                    return s.equals("ME") ? (R.drawable.montenegro) : null;
                }
                case 0x999: {
                    return s.equals("MF") ? (R.drawable.saint_martin) : null;
                }
                case 0x99A: {
                    return s.equals("MG") ? (R.drawable.madagascar) : null;
                }
                case 0x99E: {
                    return s.equals("MK") ? (R.drawable.north_macedonia) : null;
                }
                case 0x99F: {
                    return s.equals("ML") ? (R.drawable.mali) : null;
                }
                case 0x9A0: {
                    return s.equals("MM") ? (R.drawable.myanmar) : null;
                }
                case 0x9A1: {
                    return s.equals("MN") ? (R.drawable.mnmongolia) : null;
                }
                case 0x9A2: {
                    return s.equals("MO") ? (R.drawable.macau) : null;
                }
                case 0x9A4: {
                    return s.equals("MQ") ? (R.drawable.martinique) : null;
                }
                case 0x9A5: {
                    return s.equals("MR") ? (R.drawable.mauritania) : null;
                }
                case 0x9A7: {
                    return s.equals("MT") ? (R.drawable.malta) : null;
                }
                case 0x9A8: {
                    return s.equals("MU") ? (R.drawable.mauritius) : null;
                }
                case 0x9A9: {
                    return s.equals("MV") ? (R.drawable.maldives) : null;
                }
                case 0x9AA: {
                    return s.equals("MW") ? (R.drawable.malawi) : null;
                }
                case 0x9AB: {
                    return s.equals("MX") ? (R.drawable.mexico) : null;
                }
                case 0x9AC: {
                    return s.equals("MY") ? (R.drawable.malaysia) : null;
                }
                case 0x9AD: {
                    return s.equals("MZ") ? (R.drawable.mozambique) : null;
                }
                case 0x9B3: {
                    return s.equals("NA") ? (R.drawable.namibia) : null;
                }
                case 0x9B5: {
                    return s.equals("NC") ? (R.drawable.new_caledonia) : null;
                }
                case 0x9B7: {
                    return s.equals("NE") ? (R.drawable.niger) : null;
                }
                case 0x9B8: {
                    return s.equals("NF") ? (R.drawable.norfolk_island) : null;
                }
                case 0x9B9: {
                    return s.equals("NG") ? (R.drawable.nigeria) : null;
                }
                case 0x9BB: {
                    return s.equals("NI") ? (R.drawable.nicaragua) : null;
                }
                case 0x9BE: {
                    return s.equals("NL") ? (R.drawable.netherlands) : null;
                }
                case 0x9C1: {
                    return s.equals("NO") ? (R.drawable.norway) : null;
                }
                case 0x9C2: {
                    return s.equals("NP") ? (R.drawable.nepal) : null;
                }
                case 2500: {
                    return s.equals("NR") ? (R.drawable.nauru) : null;
                }
                case 2503: {
                    return s.equals("NU") ? (R.drawable.niue) : null;
                }
                case 2508: {
                    return s.equals("NZ") ? (R.drawable.new_zealand) : null;
                }
                case 0x9DE: {
                    return s.equals("OM") ? (R.drawable.oman) : null;
                }
                case 0x9F1: {
                    return s.equals("PA") ? (R.drawable.panama) : null;
                }
                case 0x9F5: {
                    return s.equals("PE") ? (R.drawable.peru) : null;
                }
                case 0x9F7: {
                    return s.equals("PG") ? (R.drawable.papua_new_guinea) : null;
                }
                case 0x9F8: {
                    return s.equals("PH") ? (R.drawable.philippines) : null;
                }
                case 0x9FB: {
                    return s.equals("PK") ? (R.drawable.pakistan) : null;
                }
                case 0x9FC: {
                    return s.equals("PL") ? (R.drawable.poland) : null;
                }
                case 0x9FD: {
                    return s.equals("PM") ? (R.drawable.saint_pierre_and_miquelon) : null;
                }
                case 0x9FE: {
                    return s.equals("PN") ? (R.drawable.pitcairn) : null;
                }
                case 0xA02: {
                    return s.equals("PR") ? (R.drawable.puerto_rico) : null;
                }
                case 0xA03: {
                    return s.equals("PS") ? (R.drawable.palestine) : null;
                }
                case 0xA04: {
                    return s.equals("PT") ? (R.drawable.portugal) : null;
                }
                case 0xA07: {
                    return s.equals("PW") ? (R.drawable.palau) : null;
                }
                case 0xA09: {
                    return s.equals("PY") ? (R.drawable.paraguay) : null;
                }
                case 0xA10: {
                    return s.equals("QA") ? (R.drawable.qatar) : null;
                }
                case 0xA33: {
                    return s.equals("RE") ? (R.drawable.reunion) : null;
                }
                case 0xA3D: {
                    return s.equals("RO") ? (R.drawable.romania) : null;
                }
                case 0xA41: {
                    return s.equals("RS") ? (R.drawable.serbia) : null;
                }
                case 0xA43: {
                    return s.equals("RU") ? (R.drawable.russia) : null;
                }
                case 0xA45: {
                    return s.equals("RW") ? (R.drawable.rwanda) : null;
                }
                case 0xA4E: {
                    return s.equals("SA") ? (R.drawable.saudi_arabia) : null;
                }
                case 0xA4F: {
                    return s.equals("SB") ? (R.drawable.solomon_islands) : null;
                }
                case 0xA50: {
                    return s.equals("SC") ? (R.drawable.seychelles) : null;
                }
                case 0xA51: {
                    return s.equals("SD") ? (R.drawable.sudan) : null;
                }
                case 0xA52: {
                    return s.equals("SE") ? (R.drawable.sweden) : null;
                }
                case 0xA54: {
                    return s.equals("SG") ? (R.drawable.singapore) : null;
                }
                case 0xA55: {
                    return s.equals("SH") ? (R.drawable.ascension_island) : null;
                }
                case 0xA56: {
                    return s.equals("SI") ? (R.drawable.slovenia) : null;
                }
                case 0xA58: {
                    return s.equals("SK") ? (R.drawable.slovakia) : null;
                }
                case 0xA59: {
                    return s.equals("SL") ? (R.drawable.sierra_leone) : null;
                }
                case 2650: {
                    break;
                }
                case 0xA5B: {
                    return s.equals("SN") ? (R.drawable.senegal) : null;
                }
                case 0xA5C: {
                    return s.equals("SO") ? (R.drawable.somalia) : null;
                }
                case 0xA5F: {
                    return s.equals("SR") ? (R.drawable.suriname) : null;
                }
                case 0xA60: {
                    return s.equals("SS") ? (R.drawable.south_sudan) : null;
                }
                case 0xA61: {
                    return s.equals("ST") ? (R.drawable.sao_tome_and_principe) : null;
                }
                case 0xA63: {
                    return s.equals("SV") ? (R.drawable.el_salvador) : null;
                }
                case 0xA65: {
                    return s.equals("SX") ? (R.drawable.sint_maarten) : null;
                }
                case 0xA66: {
                    return s.equals("SY") ? (R.drawable.syria) : null;
                }
                case 0xA67: {
                    return s.equals("SZ") ? (R.drawable.eswatini) : null;
                }
                case 0xA70: {
                    return s.equals("TD") ? (R.drawable.chad) : null;
                }
                case 0xA73: {
                    return s.equals("TG") ? (R.drawable.togo) : null;
                }
                case 0xA74: {
                    return s.equals("TH") ? (R.drawable.thailand) : null;
                }
                case 0xA76: {
                    return s.equals("TJ") ? (R.drawable.tajikistan) : null;
                }
                case 0xA77: {
                    return s.equals("TK") ? (R.drawable.tokelau) : null;
                }
                case 2680: {
                    return s.equals("TL") ? (R.drawable.timor_leste) : null;
                }
                case 0xA79: {
                    return s.equals("TM") ? (R.drawable.turkmenistan) : null;
                }
                case 0xA7A: {
                    return s.equals("TN") ? (R.drawable.tunisia) : null;
                }
                case 0xA7B: {
                    return s.equals("TO") ? (R.drawable.tonga) : null;
                }
                case 0xA7E: {
                    return s.equals("TR") ? (R.drawable.turkey) : null;
                }
                case 2690: {
                    return s.equals("TV") ? (R.drawable.tuvalu) : null;
                }
                case 0xA83: {
                    return s.equals("TW") ? (R.drawable.taiwan) : null;
                }
                case 0xA86: {
                    return s.equals("TZ") ? (R.drawable.tanzania) : null;
                }
                case 2700: {
                    return s.equals("UA") ? (R.drawable.ukraine) : null;
                }
                case 2706: {
                    return s.equals("UG") ? (R.drawable.uganda) : null;
                }
                case 0xA9E: {
                    return s.equals("US") ? (R.drawable.usa) : null;
                }
                case 0xAA4: {
                    return s.equals("UY") ? (R.drawable.uruguay) : null;
                }
                case 0xAA5: {
                    return s.equals("UZ") ? (R.drawable.uzbekistan) : null;
                }
                case 0xAAF: {
                    return s.equals("VE") ? (R.drawable.venezuela) : null;
                }
                case 0xAB8: {
                    return s.equals("VN") ? (R.drawable.vietnam) : null;
                }
                case 0xABF: {
                    return s.equals("VU") ? (R.drawable.vanuatu) : null;
                }
                case 2780: {
                    return s.equals("WS") ? (R.drawable.samoa) : null;
                }
                case 0xAF3: {
                    return s.equals("XK") ? (R.drawable.xkkosovo) : null;
                }
                case 0xB0C: {
                    return s.equals("YE") ? (R.drawable.yemen) : null;
                }
                case 0xB1B: {
                    return s.equals("YT") ? (R.drawable.mayotte) : null;
                }
                case 0xB27: {
                    return s.equals("ZA") ? (R.drawable.south_africa) : null;
                }
                case 0xB33: {
                    return s.equals("ZM") ? (R.drawable.zambia) : null;
                }
                case 0xB3D: {
                    return s.equals("ZW") ? (R.drawable.zimbabwe) : null;
                }
                default: {
                    return null;
                }
            }
            return s.equals("SM") ? (R.drawable.san_marino) : null;
        }
        return s.equals("AL") ? (R.drawable.albania) : null;
    }
}

