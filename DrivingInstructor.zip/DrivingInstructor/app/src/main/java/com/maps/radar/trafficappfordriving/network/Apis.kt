package com.maps.radar.trafficappfordriving.network

import com.maps.radar.trafficappfordriving.model.QuizMain
import com.maps.radar.trafficappfordriving.model.TrafficSign
import com.maps.radar.trafficappfordriving.model.QuizCountry
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Path

interface Apis {
    companion object {
        fun getInstance(): Apis = RetrofitHelper.retrofit.create(Apis::class.java)
        fun getInstance2(): Apis = RetrofitHelper.retrofit2.create(Apis::class.java)
    }

//    @GET("v1/{endpointName}")
//    fun getShuffle(@Path("endpointName") str: String?): Call<List<QuizMain>>


    @GET("v1/new_quiz_america")
    fun getShuffle(
        @Header("projectId") projectId: String
    ): Call<List<QuizMain>>

    @GET("v1/get_traffic_signs_1")
    fun getTrafficSign(
        @Header("projectId") projectId: String
    ): Call<List<TrafficSign>>


    @GET("driving_instructor/apis.php/indicators")
    fun getIndicators(): Call<List<TrafficSign>>

    @GET("driving_instructor/apis.php/driving_licences")
    fun getDrivingLicences(): Call<List<TrafficSign>>

    @GET("driving_instructor/apis.php/police_signs")
    fun getPoliceSigns(): Call<List<TrafficSign>>


    @GET("driving_instructor/apis.php/countryList")
    fun getCountryList(): Call<List<QuizCountry>>
}