package com.maps.radar.trafficappfordriving.quizmodule.Adapter;

import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.demo.radar.trafficappfordriving2.databinding.QuizCompletedItemBinding;
import com.maps.radar.trafficappfordriving.Db.QuizProgressItem;

import java.util.List;

public final class ProgressRecyclerAdapter extends RecyclerView.Adapter<ProgressRecyclerAdapter.ItemListViewHolder> {
    private List<QuizProgressItem> itemList;
    private final OnItemClickListener onItemClicked;

    public interface OnItemClickListener {
        void onItemClick(int index);
    }

    public ProgressRecyclerAdapter(OnItemClickListener onItemClicked) {
        this.onItemClicked = onItemClicked;
        this.itemList = List.of(); // Empty list by default
    }

    public void setData(List<QuizProgressItem> itemList) {
        this.itemList = itemList;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    @Override
    public ItemListViewHolder onCreateViewHolder(final ViewGroup parent, int viewType) {
        QuizCompletedItemBinding binding = QuizCompletedItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        adjustItemHeight(binding, parent);
        return new ItemListViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(ItemListViewHolder holder, int position) {
        holder.bind(itemList.get(position));
    }

    private void adjustItemHeight(QuizCompletedItemBinding binding, ViewGroup parent) {
        binding.getRoot().post(() -> {
            binding.getRoot().getLayoutParams().height = parent.getHeight() / 3;
            binding.getRoot().requestLayout();
        });
    }

    public class ItemListViewHolder extends RecyclerView.ViewHolder {
        private final QuizCompletedItemBinding binding;

        public ItemListViewHolder(QuizCompletedItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(final QuizProgressItem item) {

            Glide.with(binding.imgQuizImg.getContext())
                    .load(item.getIcon())
                    .into(binding.imgQuizImg);


            binding.quizName.setText(item.getTitle());
            binding.testProgressBar.setMax(100);
            if (Build.VERSION.SDK_INT >= 26) {
                binding.testProgressBar.setMin(0);
            }
            binding.testProgressBar.setProgress((int) item.getProgress());
            binding.testProgressPercantage.setText(String.format("%d%%", (int) item.getProgress()));

            binding.retryQuizBtn.setOnClickListener(v -> onItemClicked.onItemClick(item.getIndex()));
        }
    }
}
