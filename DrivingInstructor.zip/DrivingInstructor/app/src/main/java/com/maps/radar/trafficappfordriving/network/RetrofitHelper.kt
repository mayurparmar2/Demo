package com.maps.radar.trafficappfordriving.network

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitHelper {
    private const val BASE_URL = "https://www.8datasolutions.com/"
    private var retrofitInstance: Retrofit? = null
    private var retrofitInstance2: Retrofit? = null

    fun resetClient() {
        retrofitInstance = null
    }

    val retrofit: Retrofit
        get() {
            if (retrofitInstance == null) {
                retrofitInstance = Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
            }
            return retrofitInstance!!
        }

    val retrofit2: Retrofit
        get() {
            if (retrofitInstance2 == null) {
                retrofitInstance2 = Retrofit.Builder()
                    .baseUrl("https://minglegames.xyz/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
            }
            return retrofitInstance2!!
        }
}

