package com.maps.radar.trafficappfordriving.ui.radar.viewmodel

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Query
import com.maps.radar.trafficappfordriving.ui.radar.model.RadarLocal

@Dao
interface RadarDao {
    @Query("SELECT * FROM radar WHERE speed >= 0 ORDER BY ABS(x - :userx) + ABS(y - :usery) ASC LIMIT 5")
    fun getRadarDataInRange(userx: Double, usery: Double): LiveData<List<RadarLocal>>

    @Query("SELECT * FROM radar WHERE speed >= 0 AND x BETWEEN (:userx - 0.018) AND (:userx + 0.018) AND y BETWEEN (:usery - 0.018) AND (:usery + 0.018)")
    fun getRadarDataNearPoint(userx: Double, usery: Double): LiveData<List<RadarLocal>>
}