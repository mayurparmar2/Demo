package com.maps.radar.trafficappfordriving.ui.radar.viewmodel

import android.app.Application
import androidx.lifecycle.*
import kotlinx.coroutines.launch

class DataStoreViewModel(app: Application) : AndroidViewModel(app) {

    private val appDataStore: AppDataStore = AppDataStore(app)
    fun getValue(key: String): LiveData<String> = liveData {
        appDataStore.get(key)?.let { emit(it) }
    }

    fun isDataLoaded(): LiveData<Boolean> = liveData {
        emit(appDataStore.isDataLoaded())
    }

    fun saveButtonValue(key: String, value: String) {
        viewModelScope.launch {
            appDataStore.save(key, value)
        }
    }

    fun saveButtonValue(key: String, value: Int?) {
        viewModelScope.launch {
            appDataStore.save(key, value)
        }
    }

    fun saveInit() {
        viewModelScope.launch {
            appDataStore.initialize()
        }
    }
}
