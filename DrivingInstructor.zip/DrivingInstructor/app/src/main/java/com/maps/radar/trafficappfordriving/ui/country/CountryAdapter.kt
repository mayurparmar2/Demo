import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.ListItemCountryBinding
import com.maps.radar.trafficappfordriving.model.UIQuizCountry
import java.util.Locale


class CountryAdapter(private val callback: (UIQuizCountry) -> Unit) :
    ListAdapter<UIQuizCountry, CountryAdapter.CountryViewHolder>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<UIQuizCountry>() {
            override fun areItemsTheSame(oldItem: UIQuizCountry, newItem: UIQuizCountry) =
                oldItem === newItem

            override fun areContentsTheSame(oldItem: UIQuizCountry, newItem: UIQuizCountry) =
                oldItem == newItem
        }
        const val UPDATE_SELECTION_KEY = "update_selection_key"
    }

    private val defaultLocale = Locale.getDefault()
    private var lastSelectedIndex: Int? = null
    private var selected: UIQuizCountry? = null

    inner class CountryViewHolder(private val binding: ListItemCountryBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: UIQuizCountry) {
            binding.name.text = Locale(defaultLocale.language, item.countryCode).displayCountry
            item.flagDrawableId?.let { binding.flag.setImageResource(it) }
            updateSelection(item == selected)
            binding.root.setOnClickListener {
                onItemClicked(item)
            }
        }

        fun updateSelection(isSelected: Boolean) {
            val resourceId =
                if (isSelected) R.drawable.btn_radio_selected else R.drawable.btn_radio_unselect
            binding.check.setImageResource(resourceId)
        }

        private fun onItemClicked(item: UIQuizCountry) {
            if (item != selected) {
                selected = item
                callback(item)
                lastSelectedIndex?.let { notifyItemChanged(it, UPDATE_SELECTION_KEY to false) }
                lastSelectedIndex = adapterPosition
                notifyItemChanged(adapterPosition, UPDATE_SELECTION_KEY to true)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryViewHolder {
        val binding = ListItemCountryBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return CountryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CountryViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    override fun onBindViewHolder(holder: CountryViewHolder, position: Int, payloads: List<Any>) {
        super.onBindViewHolder(holder, position, payloads)
        val updateSelection =
            payloads.find { it is Pair<*, *> && it.first == UPDATE_SELECTION_KEY } as? Pair<*, *>?
        if (updateSelection?.second is Boolean) {
            holder.updateSelection(updateSelection.second as Boolean)
        }
    }


    override fun submitList(list: List<UIQuizCountry>?) {
        val currentCountry = selected?.countryCode ?: defaultLocale.country
        val newIndex = list?.indexOfFirst { it.countryCode == currentCountry } ?: -1
        if (newIndex > -1) {
            lastSelectedIndex = newIndex
            selected = list?.get(newIndex)
            callback(selected!!)
        }
        super.submitList(list)
    }
}


//
//class CountryAdapter(private val callback: (UIQuizCountry) -> Unit) :
//    ListAdapter<UIQuizCountry, CountryAdapter.CountryViewHolder>(DiffCallback()) {
//    var defaultLocale: Locale = Locale.getDefault()
//    private var selectedPosition: Int? = null
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryViewHolder {
//        val binding = ListItemCountryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
//        return CountryViewHolder(binding)
//    }
//
//    override fun onBindViewHolder(holder: CountryViewHolder, position: Int) {
//        val item = getItem(position)
//        holder.bind(item, position == selectedPosition)
//    }
//
//    inner class CountryViewHolder(private val binding: ListItemCountryBinding) :
//        RecyclerView.ViewHolder(binding.root) {
//
//        fun bind(item: UIQuizCountry, isSelected: Boolean) {
//            // Display the country name based on the country code
//            binding.name.text = Locale(defaultLocale.getLanguage(), item.countryCode).getDisplayCountry(defaultLocale)
//
////            binding.name.text = Locale("", item.countryCode).displayCountry
//
//            // Set the flag image if available
//            item.flagDrawableId?.let {
//                binding.flag.setImageResource(it)
//            }
//
//            if(item.flagDrawableId == null){
//                Log.e("TAG", "bind 11111111 : "+item.countryCode)
//
//            }
//            // Update the selection state of the item
//            updateSelection(isSelected)
//
//            // Handle item click
//            binding.root.setOnClickListener {
//                if (adapterPosition != RecyclerView.NO_POSITION) {
//                    if (selectedPosition != adapterPosition) {
//                        selectedPosition = adapterPosition
//                        notifyDataSetChanged()  // Refresh all items
//                        callback(item)
//                    }
//                }
//            }
//        }
//
//        private fun updateSelection(isSelected: Boolean) {
//            val resourceId = if (isSelected) R.drawable.btn_radio_selected else R.drawable.btn_radio_unselect
//            Log.d("CountryAdapter", "Updating selection: $isSelected, Resource ID: $resourceId")
//            binding.check.setImageResource(resourceId)
//        }
//    }
//
//    private class DiffCallback : DiffUtil.ItemCallback<UIQuizCountry>() {
//        override fun areItemsTheSame(oldItem: UIQuizCountry, newItem: UIQuizCountry): Boolean {
//            return oldItem.id == newItem.id
//        }
//
//        override fun areContentsTheSame(oldItem: UIQuizCountry, newItem: UIQuizCountry): Boolean {
//            return oldItem == newItem
//        }
//    }
//}
