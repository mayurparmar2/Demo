package com.maps.radar.trafficappfordriving.quizmodule.dialog

import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.media.MediaPlayer
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.View.OnClickListener
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Observer
import androidx.navigation.Navigation.findNavController
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.FinishDialogBoxBinding
import com.demo.radar.trafficappfordriving2.databinding.FragmentQuizContainerBinding
import com.maps.radar.trafficappfordriving.quizmodule.QuizMainActivity
import kotlin.math.ceil

class CustomDialogFinish : DialogFragment() {
    private lateinit var binding: FinishDialogBoxBinding
    private lateinit var tmp: FragmentQuizContainerBinding
    private var subCount = 1

    companion object {
        fun show(activity: FragmentActivity, subCount: Int, binding: FragmentQuizContainerBinding) {
            val dialog = CustomDialogFinish()
            dialog.subCount = subCount
            dialog.tmp = binding
            dialog.show(activity.supportFragmentManager, dialog.tag)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FinishDialogBoxBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.apply {
            setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setBackgroundDrawable(ColorDrawable(0))
            setDimAmount(1.0f)
            setGravity(17)
            context?.let {
                setBackgroundDrawable(ContextCompat.getDrawable(it, R.drawable.hnter_quiz_congrats_popup))
            }
        }
//        dialog?.window?.setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
//        dialog?.window?.setBackgroundDrawable(ColorDrawable(0))
//        dialog?.window?.setDimAmount(1.0f)
//        dialog?.window?.setGravity(Gravity.CENTER)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setCancelable(false)

        val correctAns = QuizMainActivity.instance.allViewModel.getCorrectAns().value ?: 0
        val wrongAns = QuizMainActivity.instance.allViewModel.getWrongAns().value ?: 0


        binding.totalScorePoint.text = "$correctAns%"

        if (correctAns > wrongAns) {
            playCongratsAnimation()
        } else {
            playFailureAnimation()
        }
        QuizMainActivity.instance.baseViewModel.correctProgress.observe(viewLifecycleOwner,Observer{ value ->
            if (value != null && value < 100) {
                QuizMainActivity.instance.baseViewModel.saveCorrectProgress(value + (kotlin.math.ceil(correctAns / 160.0).toInt()))
            }
        })



        QuizMainActivity.instance.allViewModel.getPoint().observe(viewLifecycleOwner,Observer{ point->
            binding.pointEarn.setText(point.toString());
        })

        QuizMainActivity.instance.allViewModel.getCorrectAns().observe(viewLifecycleOwner, Observer { correctAns ->
            binding.countCorrectAns.text = correctAns.toString()
        })

        QuizMainActivity.instance.allViewModel.getWrongAns().observe(viewLifecycleOwner, Observer { wrongAns ->
            binding.countWrongAns.text = wrongAns.toString()
        })

        QuizMainActivity.instance.baseViewModel.totalProgress.observe(viewLifecycleOwner, Observer { totalProgress ->
            if (totalProgress < 100) {
                QuizMainActivity.instance.baseViewModel.saveTotalProgress(totalProgress + ((100 / subCount).toInt()))
            }
        })

        binding.shareBtn.setOnClickListener {
            val correctAns = QuizMainActivity.instance.allViewModel.getCorrectAns().value.toString()
            val wrongAns = QuizMainActivity.instance.allViewModel.getWrongAns().value.toString()
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "text/plain"
            intent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=" + requireContext().packageName + "\n✅ Correct answers: $correctAns\n❌ Wrong answers: $wrongAns")
            val chooser = Intent.createChooser(intent, "Share your quiz results")
            if (intent.resolveActivity(requireContext().packageManager) != null) {
                startActivity(chooser)
            }
        }
        binding.closeBtnDialog.setOnClickListener(object : OnClickListener {
            override fun onClick(v: View?) {
                if (v != null) {
                    findNavController(tmp.root).navigate(R.id.quiz_FirstFragment)
                }
                dismiss()
            }
        })
    }

    private fun playCongratsAnimation() {
        MediaPlayer.create(context, R.raw.congratulations).start()
        binding.lottieAnimationView.visibility = View.VISIBLE
    }

    private fun playFailureAnimation() {
        binding.lottieAnimationView.visibility = View.GONE
        binding.root.setBackgroundResource(R.drawable.hnter_quiz_popup_bg)
    }
}