package com.maps.radar.trafficappfordriving.offlinemap.fragments

import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.location.Address
import android.location.Geocoder
import android.location.Geocoder.GeocodeListener
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.NavHostFragment.findNavController
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.FragmentOsmdroidBinding
import com.maps.radar.trafficappfordriving.offlinemap.model.MapType
import com.maps.radar.trafficappfordriving.ui.hupd.LocationUpdateListener
import com.maps.radar.trafficappfordriving.ui.hupd.LocationUpdatesService
import com.maps.radar.trafficappfordriving.ui.radar.CommunicationListener
import com.maps.radar.trafficappfordriving.utils.PermissionUtil
import org.osmdroid.api.IMapController
import org.osmdroid.bonuspack.routing.OSRMRoadManager
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.util.Locale


abstract class BaseMapFragment : BaseFragment2<FragmentOsmdroidBinding>(FragmentOsmdroidBinding::inflate),
    CommunicationListener,LocationUpdateListener, View.OnClickListener{

    private  var mService: LocationUpdatesService? = null
    private lateinit var mServiceConnection: ServiceConnection
    private var zoomLevel = 4.5
    private var isFirst = true
    private var wayPoint = ArrayList<GeoPoint>()
    private var startPoint = GeoPoint(46.55951, 15.6397)
    private var mapController: IMapController? = null
    private var roadOverlay: Polyline? = null
    private var roadManager: OSRMRoadManager? = null
    private var currentLocation: GeoPoint? = null
    private var currentLocationMarker: Marker? = null


    abstract fun getMapType(): MapType
    abstract fun getPageTitle(): String


  init {
        this.zoomLevel = 4.5
        this.isFirst = true
        this.wayPoint = ArrayList()
        this.startPoint = GeoPoint(46.55951, 15.6397)
        this.mServiceConnection = G()
    }

    inner class G : ServiceConnection {
        override fun onServiceConnected(componentName: ComponentName?, iBinder: IBinder?) {
            mService = (iBinder as LocationUpdatesService.LocationBinder).service
            mService?.c(this@BaseMapFragment)
            mService?.h()
        }
        override fun onServiceDisconnected(componentName: ComponentName?) {
            mService = null
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initializeService()
//        val activity: KeyEventDispatcher.Component? = requireActivity()
//        if (activity is CommunicationMediator) {
//            communicationMediator = activity as CommunicationMediator?
//        } else {
//            communicationMediator = null
//        }
//        if (communicationMediator != null) {
//            communicationMediator.setCommunicationListener(this)
//        }
        setBackPressedCallback()


    }


    private fun openMapStreet() {
        startActivity(
            Intent(
                "android.intent.action.VIEW",
                Uri.parse("https://www.openstreetmap.org/copyright")
            )
        )
    }

    private fun setBackPressedCallback() {
        requireActivity().onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                   handleBackPress()
                    binding
                }
            })
    }


    fun handleBackPress() {
        if (!findNavController(this).popBackStack()) {
            requireActivity().finish()
        }
    }


    override fun setupViews(): FragmentOsmdroidBinding {
        with(binding!!) {
            locationPermissionAlert.visibility = View.GONE
            circleLayout.setOnClickListener(this@BaseMapFragment)
            btnZoomOut.setOnClickListener(this@BaseMapFragment)
            btnZoomIn.setOnClickListener(this@BaseMapFragment)
            imgMapLocation.setOnClickListener(this@BaseMapFragment)
            txtTitle.text = getPageTitle()
            val mapView = binding!!.mapview
            mapView.setTileSource(TileSourceFactory.MAPNIK);
//            mapView.setTileSource(i("MapQuest", 4, 20, 256, ".png", arrayOf<String>(ea.d.a())))
            mapView.setMultiTouchControls(true)
            mapView.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            mapView.setMinZoomLevel(4.5)
            mapView.setMaxZoomLevel(19.5)
            setMapController(mapView.controller)
            mapView.controller.setZoom(mapView.zoomLevel)
            mapView.controller.setCenter(startPoint)
        }
        return binding!!
    }


    fun setMapController(iMapController: IMapController) {
        this.mapController = iMapController
    }

    fun setZoomLevel(zoomLevel: Double) {
        this.zoomLevel = zoomLevel
    }
    fun setWayPoint(arrayList: ArrayList<GeoPoint>) {
        this.wayPoint = arrayList
    }

    fun setRoadOverlay(polyline: Polyline) {
        this.roadOverlay = polyline
    }
    fun setRoadManager(roadManager: OSRMRoadManager) {
        this.roadManager = roadManager
    }
    fun setCurrentLocation(geoPoint: GeoPoint) {
        this.currentLocation = geoPoint
    }

    override fun onResume() {
        super.onResume()
        binding?.mapview?.onResume()
    }
    override fun onPause() {
        super.onPause()
        binding?.mapview?.onPause()
    }
    override fun onServiceClosed() {
        this.mService?.j()
    }

    override fun locationPermission(isGranted: Boolean) {
        if (isGranted) {
            initializeService();
        }
    }

    protected fun checkIfFragmentAttached(fragment: Fragment): Boolean {
        return fragment.isAdded && fragment.context != null
    }


    private fun initializeService() {
        if (!checkIfFragmentAttached(this)) {
            return
        }
        if (ContextCompat.checkSelfPermission(requireContext(),"android.permission.ACCESS_FINE_LOCATION") != 0) {
            val requireActivity = requireActivity()
            PermissionUtil.requestLocationPermissions(requireActivity)
            return
        }
        requireContext().bindService(Intent(requireContext(), LocationUpdatesService::class.java), this.mServiceConnection, 1)
    }

    override fun onLocationChanged(location: Location?) {
        if (location == null || !checkIfFragmentAttached(this)) {
            return
        }
        this.currentLocation = GeoPoint(location.latitude, location.longitude)
        if (binding != null) {
            val progressBar = binding!!.progressHorizontal
            progressBar.visibility = View.GONE
        }
        if (this.isFirst) {
            if (getMapType() == MapType.MY_LOCATION) {
                getAddressFromGeoPoint(location.latitude, location.longitude, 5)
            }
            this.isFirst = false
            this.zoomLevel = 18.5
             createCurrentLocationMarker()

        }
    }
    private fun createCurrentLocationMarker() {
        binding?.let { binding->
            currentLocationMarker?.apply {
                binding.mapview.getOverlays().remove(this)
            }
            this.currentLocationMarker = Marker(binding.mapview)
            currentLocationMarker!!.setIcon(ResourcesCompat.getDrawable(resources, R.drawable.ic_pin, null))
            currentLocationMarker!!.setTextIcon(getString(R.string.your_loc))
            currentLocationMarker!!.setPosition(this.currentLocation)
            currentLocationMarker!!.setAnchor(0.5f, 1.0f);
            getMapController()?.setZoom(this.zoomLevel)
            getMapController()?.animateTo(this.currentLocation)
            binding.mapview.getOverlays().add(this.currentLocationMarker)
            binding.mapview.invalidate()
        }

    }

    fun getMapController(): IMapController? {
        if (mapController != null) {
            return mapController
        }
        return null
    }


    fun getDisplayedAddress(address: Address?) {
//        val str = address?.getAddressLine(0)
//        val valueOf = str.toString()
//        t9.k.d(LifecycleOwnerKt.getLifecycleScope(this), null, null, f(valueOf, null), 3, null)
//        FragmentKt.setFragmentResult(
//            this,
//            IntegrityManager.INTEGRITY_TYPE_ADDRESS,
//            BundleKt.bundleOf(r.a(IntegrityManager.INTEGRITY_TYPE_ADDRESS, valueOf))
//        )
    }


    private fun getAddressFromGeoPoint(latitude: Double, longitude: Double, maxResults: Int) {
        val geocoder = Geocoder(requireContext(), Locale.getDefault())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            geocoder.getFromLocation(latitude, longitude, maxResults, object : GeocodeListener {
                override fun onGeocode(addresses: MutableList<Address>) {
                    getDisplayedAddress(addresses.firstOrNull())
                }
            })
        }
        val fromLocation: MutableList<Address>? = geocoder.getFromLocation(latitude, longitude, maxResults)
        val displayedAddress: Address? = fromLocation?.firstOrNull()
        getDisplayedAddress(displayedAddress)
    }

    override fun onClick(v: View?) {

    }
}


