package com.maps.radar.trafficappfordriving.ui.base;

import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewbinding.ViewBinding;

import com.maps.radar.trafficappfordriving.model.QuizMain;
import com.maps.radar.trafficappfordriving.network.Apis;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public abstract class BaseActivity<T extends ViewBinding> extends AppCompatActivity {
    private T binding;

    public abstract T getViewBinding();

    public abstract void initView(T binding);

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = getViewBinding();
        setContentView(binding.getRoot());
//        getWindow().getDecorView().getRootView().setBackgroundResource(R.color.global_background);
        initView(binding);
    }

}
