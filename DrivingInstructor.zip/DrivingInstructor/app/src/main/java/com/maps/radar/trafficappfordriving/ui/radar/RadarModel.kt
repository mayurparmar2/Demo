package com.maps.radar.trafficappfordriving.ui.radar

public  data class RadarModel(
    val flagImage: Int,
    val roadName: String,
    @JvmField val measurement: String
)