package com.maps.radar.trafficappfordriving.ui.country

import CountryAdapter
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.demo.radar.trafficappfordriving2.databinding.FragmentCountrySelectBinding
import com.maps.radar.trafficappfordriving.model.QuizCountry
import com.maps.radar.trafficappfordriving.model.UIQuizCountry
import com.maps.radar.trafficappfordriving.network.Apis
import com.maps.radar.trafficappfordriving.quizmodule.QuizMainActivity
import com.maps.radar.trafficappfordriving.utils.CountryFlagsHelper
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.Locale


class CountrySelectionFragment : Fragment() {
    var _selected: UIQuizCountry? = null

    private lateinit var binding: FragmentCountrySelectBinding
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentCountrySelectBinding.inflate(inflater, container, false)
        return binding.root
    }


    private fun getAvailableCountryCodes(): List<String> {
//        val availableLocales = Locale.getAvailableLocales()
//        val countryCodes: MutableList<String> = ArrayList(availableLocales.size)
//        for (locale in availableLocales) {
//            val countryName = locale.country
//            if (countryName.isNotBlank()) {
//                countryCodes.add(countryName)
//            }
//        }
        val availableLocales = Locale.getISOCountries()
        val countryCodes2 = availableLocales.map { it }
        return countryCodes2
    }


    private fun onCountrySelected(uIQuizCountry: UIQuizCountry) {
        this._selected = uIQuizCountry
        binding?.let {
            it.choose.isEnabled = true
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding?.let { binding ->

            binding.close.setOnClickListener(View.OnClickListener { view2 ->
                findNavController(view2).popBackStack()
            })
            binding.choose.setOnClickListener(View.OnClickListener { view2 ->
                var str: String? = null
//                _selected?.let {
                if (_selected!!.hasQuiz) {
                    str = _selected!!.endPoint;
                    val intent = Intent(requireActivity(), QuizMainActivity::class.java)
                    intent.putExtra("projectId", "64fb2e37aa125e0001bcaeeb")
                    intent.putExtra("endPointId", str)
                    requireActivity().startActivity(intent)
                }
//                }
            })

            binding.countries.setLayoutManager(LinearLayoutManager(requireContext()))
            val adapter = CountryAdapter(callback = { model ->
                onCountrySelected(model)
            })
            binding.countries.setAdapter(adapter)
            Apis.getInstance2().getCountryList().enqueue(object : Callback<List<QuizCountry>> {
                override fun onResponse(
                    call: Call<List<QuizCountry>>,
                    response: Response<List<QuizCountry>>,
                ) {
                    Log.e("TAG", "onResponse: " + response.body())
                    if (response.isSuccessful) {
                        val countryList = response.body()
                        if (!countryList.isNullOrEmpty()) {

                            val countryMap = mutableMapOf<String, QuizCountry>()
                            for (item in countryList) {
                                countryMap[item.country_code] = item
                            }

                            val countries: MutableList<UIQuizCountry> = ArrayList()
                            var count = 0


                            for (country in getAvailableCountryCodes()) {

                                Log.e("TAG", "onResponse getAvailableCountryCodes: $country")
                                val code: Int? = CountryFlagsHelper.a(country)
                                val countryData: QuizCountry? = countryMap.get(country)
                                val countryItem = if (countryData != null) {
                                    UIQuizCountry(count, country, countryData.end_point, true, code)
                                } else {
                                    UIQuizCountry(count, country, null, false, code)
                                }
                                countries.add(countryItem)
                                count++
                            }
                            adapter.submitList(countries)
                            binding.loading.visibility = View.INVISIBLE

                        }
                    }
                }

                override fun onFailure(call: Call<List<QuizCountry>>, t: Throwable) {
                    Log.e("TAG", "onFailure: " + t.message)
                }

            })
        }
    }
}