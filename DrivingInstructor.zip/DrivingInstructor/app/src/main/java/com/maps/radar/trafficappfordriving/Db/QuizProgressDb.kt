package com.maps.radar.trafficappfordriving.Db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [QuizProgressItem::class], exportSchema = false, version = 1)
abstract class QuizProgressDb : RoomDatabase() {

    abstract fun appDAO(): QuizProgressDao

    companion object {
        private var INSTANCE: QuizProgressDb? = null

        fun getInstance(context: Context): QuizProgressDb {
            if (INSTANCE == null) {
                synchronized(this) {
                    INSTANCE = Room.databaseBuilder(
                        context.applicationContext,
                        QuizProgressDb::class.java,
                        "app_database_piano"
                    ).fallbackToDestructiveMigration().build()
                }
            }
            return INSTANCE!!
        }
    }
}