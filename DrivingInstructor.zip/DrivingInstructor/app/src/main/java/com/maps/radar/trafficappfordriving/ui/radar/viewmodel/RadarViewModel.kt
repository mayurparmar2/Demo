package com.maps.radar.trafficappfordriving.ui.radar.viewmodel

import android.app.Application
import android.content.Context
import android.location.Geocoder
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.demo.radar.trafficappfordriving2.R
import com.maps.radar.trafficappfordriving.ui.radar.RadarModel
import com.maps.radar.trafficappfordriving.ui.radar.model.RadarLocal
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*

class RadarViewModel(app: Application) : AndroidViewModel(app)  {

    private val _radarLocalData = MutableLiveData<List<RadarLocal>>()
    val radarLocalData: LiveData<List<RadarLocal>> = _radarLocalData

    private val _radarModelData = MutableLiveData<List<RadarModel>>()
    val radarModelData: LiveData<List<RadarModel>> = _radarModelData

    private var tempAddress: String = ""

    fun getAddressInfos(
        context: Context,
        location: Location,
        radarList: List<RadarLocal>,
        unit: String,
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val geocoder = Geocoder(context, Locale.getDefault())
                val radarModels = radarList.mapNotNull { radar ->
                    val address = geocoder.getFromLocation(radar.x, radar.toString().toDouble(), 1)
                        ?.firstOrNull()
                    address?.let {
                        val addressString =
                            "${it.subThoroughfare.orEmpty()} ${it.thoroughfare.orEmpty()}".trim()
                        if (addressString.isNotEmpty() && addressString != tempAddress) {
                            tempAddress = addressString
                            RadarModel(
                                R.drawable.baserdr_ic_radar,
                                addressString,
                                calculateDistance(location, radar, unit)
                            )
                        } else {
                            null
                        }
                    }
                }
                _radarModelData.postValue(radarModels)
            } catch (e: Exception) {
                // Handle exception if necessary
            }
        }
    }

    fun getNear(latitude: Double, longitude: Double) {
        viewModelScope.launch(Dispatchers.IO) {
//            radarRepository.getNear(latitude, longitude, callback = {
//                _radarLocalData.postValue(it)
//            })
        }
    }

    fun getNearest(latitude: Double, longitude: Double) {
        viewModelScope.launch(Dispatchers.IO) {
//            radarRepository.getNearest(latitude, longitude, callback = {
//                _radarLocalData.postValue(it)
//            })
        }
    }

    private fun calculateDistance(location: Location, radar: RadarLocal, unit: String): String {
        // Implement distance calculation logic based on location, radar, and unit
        return "distance"
    }
}
