package com.maps.radar.trafficappfordriving.ui.home

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.FragmentActivity
import androidx.navigation.NavBackStackEntry
import androidx.navigation.fragment.NavHostFragment
import com.demo.radar.trafficappfordriving2.databinding.FragmentHomeBinding
import com.maps.radar.trafficappfordriving.TrafficSignsMainActivity
import com.maps.radar.trafficappfordriving.offlinemap.OfflineMapActivity
import com.maps.radar.trafficappfordriving.ui.base.BaseFragment
import com.maps.radar.trafficappfordriving.ui.home.MenuItemAdapter.EnumMenuItem
import com.maps.radar.trafficappfordriving.ui.hupd.HeadUpDisplayActivity
import com.maps.radar.trafficappfordriving.ui.radar.MainRadarActivity


class HomeFragment : BaseFragment<FragmentHomeBinding>(FragmentHomeBinding::inflate) {
    private var backPressedTime: Long = 0L
    private lateinit var adapter: MenuItemAdapter

    enum class b constructor(val value: String) {
        QUESTION("question"),
        RADAR("radar"),
        HUD("hud"),
        HOME("home"),
        OFFLINE_MAP("offline_map"),
        TRAFFIC_SIGN("traffic_sign"),
        CAR_CONTROL("car_control"),
        DRIVING_TIPS("driving_tips"),
        GUIDELINE("guideline"),
        INDICATORS("indicators"),
        POLICE_SIGNS("police_signs"),
        DRIVING_LICENSES("driving_licenses"),
        HOW_TO_DO("how_to_do");
    }




    private val callback = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            if (System.currentTimeMillis() - backPressedTime <= 2000) {
                requireActivity().finishAffinity()
            } else {
                backPressedTime = System.currentTimeMillis()
                Toast.makeText(requireContext(), "Press again to exit.", Toast.LENGTH_LONG).show()
            }
        }
    }
    lateinit var locationPermission: ActivityResultLauncher<String>
    var launchType = -1

    override fun onAttach(context: Context) {
        super.onAttach(context)
        locationPermission =  requireActivity().registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted: Boolean ->
            if (isGranted) {
                if (launchType == 1) {
                    val intent = Intent(activity, MainRadarActivity::class.java)
                    requireActivity().startActivity(intent)
                } else if (launchType == 2){
                    startOffileMap()
                }
            } else {
                Toast.makeText(requireContext(), "Please allow permition ", Toast.LENGTH_LONG).show()
            }
        }
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
//        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, callback);
//        val currentBackStackEntry: NavBackStackEntry? = nav.currentBackStackEntry

        val nav = NavHostFragment.findNavController(this)
        binding!!.settings.setOnClickListener { view ->
            nav.navigate(com.demo.radar.trafficappfordriving2.R.id.settingFragment)
        }

        adapter = MenuItemAdapter(object : MenuItemAdapter.OnItemClickListener {


            override fun onItemClick(item: MenuItemAdapter.MenuItem) {
                when (item.enumMenuItem) {
                    EnumMenuItem.DRIVING_TEST -> {
//                        navigateDrivingQuestions();
                        nav.navigate(com.demo.radar.trafficappfordriving2.R.id.countrySelectionFragment)
                    }

                    EnumMenuItem.DRIVING_GUIDELINE -> {
                        val bundle = Bundle()
                        bundle.putInt("groupId",0)
                        nav.navigate(com.demo.radar.trafficappfordriving2.R.id.guideFragment,bundle)
                    }
                    EnumMenuItem.DRIVING_TIPS_TRICKS-> {
                        val bundle = Bundle()
                        bundle.putInt("groupId",2)
                        nav.navigate(com.demo.radar.trafficappfordriving2.R.id.guideFragment,bundle)
                    }

                    EnumMenuItem.HOW_TO_DO -> {
                        val bundle = Bundle()
                        bundle.putInt("groupId",2)
                        nav.navigate(com.demo.radar.trafficappfordriving2.R.id.guideFragment,bundle)
                    }
                    EnumMenuItem.CAR_CONTROL -> {
                        val bundle = Bundle()
                        bundle.putInt("groupId",1)
                        nav.navigate(com.demo.radar.trafficappfordriving2.R.id.guideFragment,bundle)
                    }

                    EnumMenuItem.RADAR_DETECTOR -> {
                        if (ContextCompat.checkSelfPermission(requireContext(), "android.permission.ACCESS_FINE_LOCATION") == 0) {
                            val intent = Intent(activity, MainRadarActivity::class.java)
                            requireActivity().startActivity(intent)
                        } else {
                            launchType = 1
                            locationPermission.launch("android.permission.ACCESS_FINE_LOCATION")
                        }
                    }
                    EnumMenuItem.OFFLINE_MAPS -> {
                        if (ContextCompat.checkSelfPermission(requireContext(), "android.permission.ACCESS_FINE_LOCATION") == 0) {
                            startOffileMap()
                        } else {
                            launchType = 2
                            locationPermission.launch("android.permission.ACCESS_FINE_LOCATION")
                        }
                    }

                    EnumMenuItem.POLICE_SIGN -> { a(
                            requireActivity(),
                            requireActivity().getString(com.demo.radar.trafficappfordriving2.R.string.police_sign),
                            "66476576f5cf10000149a8c8",
                            ""
                        )

                    }
                    EnumMenuItem.HUD -> {
                        requireActivity().startActivity(Intent(requireActivity(), HeadUpDisplayActivity::class.java))
                    }
                    EnumMenuItem.DRIVING_LICENSES -> {
                        a(
                            requireActivity(),
                            requireActivity().getString(com.demo.radar.trafficappfordriving2.R.string.driving_licenses),
                            "6646f8a4f5cf10000149a8a0",
                            ""
                        )
                    }

                    EnumMenuItem.INDICATORS -> {
                        a(
                            requireActivity(),
                            requireActivity().getString(com.demo.radar.trafficappfordriving2.R.string.driving_indicators),
                            "66462d3ef5cf10000149a22c",
                            "tr;de;el;fr;zh;ja;ko;it;pa;vi;fa;hi;ru;es;pt;in;ms;ar;nl;iw;th;pl;sw;ta;ur;mr;gu;ka;uz;az;sr;mn;km;bn;ro;tl;te;ha;jv;kn;ps;uk;yo;ml;or;my;sd;kk;bho;mai;fil;ne;dv;si"
                        )

                    }


                    EnumMenuItem.TRAFFIC_SIGN -> {
                        a(
                            requireActivity(),
                            getString(com.demo.radar.trafficappfordriving2.R.string.traffic_sign),
                            "664b4256f5cf10000149a8df",
                            ""
                        )
                    }

                    else -> {
                        Log.d("MenuItemAdapter", "Unknown item clicked")
                    }
                }
            }
        })

        binding!!.menuItems.adapter = adapter
        binding!!.navView.setItemIconTintList(null);
        binding!!.navView.setItemBackgroundResource(com.demo.radar.trafficappfordriving2.R.drawable.bg_bottom_line_1);

        binding!!.drawerIcon.setOnClickListener { view ->
            binding!!.drawer.open();
        }

        (binding!!.navView.getHeaderView(0)
            .findViewById<ImageView>(com.demo.radar.trafficappfordriving2.R.id.close)!!).setOnClickListener { view ->
                binding!!.drawer.close();
            }


        binding!!.drawer.addDrawerListener(object : DrawerLayout.DrawerListener {
            override fun onDrawerSlide(drawerView: View, slideOffset: Float) {

            }

            override fun onDrawerOpened(drawerView: View) {

            }

            override fun onDrawerClosed(drawerView: View) {

            }

            override fun onDrawerStateChanged(newState: Int) {

            }

        })


    }

    private fun startOffileMap() {
        val intent = Intent(requireActivity(), OfflineMapActivity::class.java)
        intent.putExtra("map_type", "OFFLINE_MAPS")
        requireActivity().startActivity(intent)
    }

    private fun navigateDrivingQuestions() {
        val activity: FragmentActivity = requireActivity()
    }

    fun a(
        activity: Activity,
        str: String?,
        projectId: String?,
        supportedLangCodes: String?,
    ) {
        val intent = Intent(activity, TrafficSignsMainActivity::class.java)
        intent.putExtra(TrafficSignsMainActivity.PROJECT_ID, projectId)
        if (str != null) {
            intent.putExtra(TrafficSignsMainActivity.TITLE, str)
        }
        intent.putExtra(TrafficSignsMainActivity.SUPPORTED_LANGUAGES, supportedLangCodes)
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.startActivity(intent)
    }


}
