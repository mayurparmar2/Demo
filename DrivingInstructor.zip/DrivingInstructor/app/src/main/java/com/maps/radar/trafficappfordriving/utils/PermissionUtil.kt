package com.maps.radar.trafficappfordriving.utils

import android.app.Activity
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import androidx.core.app.ActivityCompat

object PermissionUtil {

    // Opens location settings
    private fun openLocationSettings(activity: Activity) {
        activity.startActivity(Intent("android.settings.LOCATION_SOURCE_SETTINGS"))
    }

    // Requests location permissions
    fun requestLocationPermissions(activity: Activity) {
        ActivityCompat.requestPermissions(
            activity,
            arrayOf(
                "android.permission.ACCESS_FINE_LOCATION",
                "android.permission.ACCESS_COARSE_LOCATION"
            ),
            101
        )
    }

    // Shows a dialog to enable location settings
    fun showEnableLocationDialog(activity: Activity) {
        AlertDialog.Builder(activity)
            .setTitle("Enable Location")
            .setMessage("Your Location Settings are set to 'Off'.\nPlease enable location to use this app.")
            .setPositiveButton("Location Settings") { _, _ ->
                openLocationSettings(activity)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // Shows a rationale for location permission if needed
    fun showLocationPermissionRationale(activity: Activity) {
        if (ActivityCompat.shouldShowRequestPermissionRationale(activity, "android.permission.ACCESS_FINE_LOCATION")) {
            AlertDialog.Builder(activity)
                .setTitle("Location Permission Needed")
                .setMessage("This app needs the Location permission; please accept to use location functionality.")
                .setPositiveButton("OK") { _, _ ->
                    requestLocationPermissions(activity)
                }
                .create()
                .show()
        } else {
            requestLocationPermissions(activity)
        }
    }
}
