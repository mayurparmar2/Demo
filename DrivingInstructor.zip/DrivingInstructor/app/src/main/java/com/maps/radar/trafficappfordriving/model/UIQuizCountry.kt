package com.maps.radar.trafficappfordriving.model

import androidx.annotation.DrawableRes

data class UIQuizCountry(
    val id: Int,
    val countryCode: String,
    val endPoint: String?,
    val hasQuiz: Boolean,
    @DrawableRes val flagDrawableId: Int?
)
//{
//    fun a(): String = countryCode
//    fun b(): String = endPoint
//    fun c(): Int = flagDrawableId
//    fun d(): Boolean = hasQuiz
//    fun e(): Int = id
//}