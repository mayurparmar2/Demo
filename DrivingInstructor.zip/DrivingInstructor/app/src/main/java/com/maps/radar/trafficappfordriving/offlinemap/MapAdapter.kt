package com.maps.radar.trafficappfordriving.offlinemap

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.demo.radar.trafficappfordriving2.R
import com.maps.radar.trafficappfordriving.offlinemap.model.MapItem

class MapAdapter(
    private val mapItems: List<MapItem>,
    private val onItemClick: (String) -> Unit
) : RecyclerView.Adapter<MapAdapter.MapViewHolder>() {

    inner class MapViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val iconImageView: ImageView = itemView.findViewById(R.id.icon_image_view)
        private val nameTextView: TextView = itemView.findViewById(R.id.nameTextView)

        fun bind(mapItem: MapItem) {
            iconImageView.setImageResource(mapItem.iconResId)
            nameTextView.text = mapItem.name
            itemView.setOnClickListener {
                onItemClick(mapItem.packageId)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MapViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_map, parent, false)
        return MapViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MapViewHolder, position: Int) {
        holder.bind(mapItems[position])
    }

    override fun getItemCount(): Int = mapItems.size
}
