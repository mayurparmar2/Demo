package com.example.quizmodule.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.CompoundButton
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.QuestionLayoutFillBinding
import com.demo.radar.trafficappfordriving2.databinding.QuestionLayoutImageBinding
import com.demo.radar.trafficappfordriving2.databinding.QuestionLayoutSoundBinding
import com.demo.radar.trafficappfordriving2.databinding.QuestionLayoutTextBinding
import com.maps.radar.trafficappfordriving.model.QuizMain
import com.maps.radar.trafficappfordriving.quizmodule.Adapter.OnPlayClickListener
import java.util.Locale

class QuestionRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val listOfQuestions = mutableListOf<QuizMain.QuestionAns>()

    @JvmField
    var listener: OnPlayClickListener? = null

    override fun getItemCount(): Int = listOfQuestions.size

    override fun getItemViewType(position: Int): Int {
        return when (listOfQuestions[position].type) {
            "TEXT" -> TYPE_TEXT
            "IMAGE" -> TYPE_IMAGE
            "AUDIO" -> TYPE_SOUND
            "FILL" -> TYPE_FILL
            else -> throw IllegalArgumentException("Invalid question type")
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            TYPE_TEXT -> TextViewHolder(QuestionLayoutTextBinding.inflate(inflater, parent, false))
            TYPE_IMAGE -> ImageViewHolder(QuestionLayoutImageBinding.inflate(inflater, parent, false))
            TYPE_SOUND -> SoundViewHolder(QuestionLayoutSoundBinding.inflate(inflater, parent, false))
            TYPE_FILL -> FillViewHolder(QuestionLayoutFillBinding.inflate(inflater, parent, false))
            else -> throw IllegalArgumentException("Invalid view type")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val question = listOfQuestions[position]
        when (holder) {
            is TextViewHolder -> holder.bind(question)
            is ImageViewHolder -> holder.bind(question)
            is SoundViewHolder -> holder.bind(question, listener)
            is FillViewHolder -> holder.bind(question)
        }
    }

    fun setData(data: List<QuizMain.QuestionAns>) {
        listOfQuestions.clear()
        listOfQuestions.addAll(data)
        notifyDataSetChanged()
    }

    inner class TextViewHolder(private val binding: QuestionLayoutTextBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(question: QuizMain.QuestionAns) {
            question.content.image_url?.takeIf { it.isNotEmpty() }?.let {
                Glide.with(binding.root.context)
                    .load(it)
                    .placeholder(R.drawable.hunter_quiz_question_mark)
                    .into(binding.questionLayoutImage)
            } ?: binding.questionLayoutImage.setImageResource(R.drawable.hunter_quiz_question_mark)

            val language = Locale.getDefault().language
            val textMap = question.content.text_map
            val text = textMap?.get(language) ?: question.content.text
            binding.questionLayoutText.text = text
        }
    }

    inner class ImageViewHolder(private val binding: QuestionLayoutImageBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(question: QuizMain.QuestionAns) {
            Glide.with(binding.questionLayoutImage.context)
                .load(question.content.image_url)
                .into(binding.questionLayoutImage)
        }
    }

    inner class SoundViewHolder(private val binding: QuestionLayoutSoundBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(question: QuizMain.QuestionAns, listener: OnPlayClickListener?) {
            binding.questionPlayBtnSound.setOnCheckedChangeListener { button, isChecked ->
                listener?.onPlay(button, question.content.audio_url!!, !isChecked)
            }
        }
    }

    inner class FillViewHolder(private val binding: QuestionLayoutFillBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(question: QuizMain.QuestionAns) {
//            binding.question = question
//            binding.executePendingBindings()
        }
    }

//    interface OnPlayClickListener {
//        fun onPlayClicked(button: CompoundButton, audioUrl: String, isPlaying: Boolean)
//    }

    fun setListener(onPlayClickListener: OnPlayClickListener?) {
        this.listener = onPlayClickListener
    }

    companion object {
        private const val TYPE_TEXT = 0
        private const val TYPE_IMAGE = 1
        private const val TYPE_SOUND = 2
        private const val TYPE_FILL = 3
    }
}
