package com.maps.radar.trafficappfordriving.ui.hupd.fragment;

import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleOwnerKt;

import com.demo.radar.trafficappfordriving2.databinding.HupdFragmentHeadUpDisplayBinding;
import com.demo.radar.trafficappfordriving2.databinding.HupdFragmentHeadUpDisplayNormalBinding;
import com.maps.radar.trafficappfordriving.ui.hupd.LocationUpdatesService;
import com.maps.radar.trafficappfordriving.ui.radar.RadarModel;
import com.maps.radar.trafficappfordriving.ui.radar.viewmodel.DataStoreViewModel;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public final class HeadUpDisplayFragment extends BaseRadarFragment implements View.OnClickListener {
    private HupdFragmentHeadUpDisplayBinding bindingMirror;
    private HupdFragmentHeadUpDisplayNormalBinding bindingNormal;
    private boolean isMirrorLayout = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private float currentRotation = 315.0f;
    private final float rotationFactor = 1.5f;
    private final Runnable timeRunnable = new Runnable() {
        @Override
        public void run() {
            updateDateTime();
            handler.postDelayed(this, 1000);
        }
    };

    private void updateDateTime() {
        Calendar calendar = Calendar.getInstance();
        String time = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(calendar.getTime());
        String date = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(calendar.getTime());
        if (isMirrorLayout) {
            bindingMirror.txtTime.setText(time);
            bindingMirror.txtDate.setText(date);
        } else {
            bindingNormal.txtTime.setText(time);
            bindingNormal.txtDate.setText(date);
        }
    }

    private void toggleLayout() {
        if (isMirrorLayout) {
            bindingMirror.getRoot().setVisibility(View.GONE);
            bindingNormal.getRoot().setVisibility(View.VISIBLE);
            currentRotation = 225.0f;
        } else {
            bindingNormal.getRoot().setVisibility(View.GONE);
            bindingMirror.getRoot().setVisibility(View.VISIBLE);
            currentRotation = 315.0f;
        }
        updateSpeedUnit();
        isMirrorLayout = !isMirrorLayout;
    }

    private void updateSpeedUnit() {
        String unit = getUnitLength().equals("KMPH") ? "km/h" : "mil/h";
        if (isMirrorLayout) {
            bindingMirror.txtSpeedUnit.setText(unit);
        } else {
            bindingNormal.txtSpeedUnit.setText(unit);
        }
    }

    @Override
    public void calculateSpeedWarning(int speed) {
        String speedText = speed+"";
        if (isMirrorLayout) {
            bindingMirror.txtSpeedSmall.setText(speedText);
        } else {
            bindingNormal.txtSpeedSmall.setText(speedText);
        }
    }

    @Override
    public void nextRadarWarning(List<RadarModel> radarWarnings) {
        if (radarWarnings != null && !radarWarnings.isEmpty()) {
            String radarText = radarWarnings.get(0).measurement;
            if (isMirrorLayout) {
                bindingMirror.txtNextRadarMeasurement.setText(radarText);
            } else {
                bindingNormal.txtNextRadarMeasurement.setText(radarText);
            }
        }
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == bindingMirror.imgBtnLeft.getId() || view.getId() == bindingNormal.imgBtnLeft.getId()) {
            toggleLayout();
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        super.onLocationChanged(location);
        if (location.hasSpeed()) {
            int speed = (int) (getUnitLength().equals("KMPH") ? location.getSpeed() * 3.6 : location.getSpeed() * 2.23694);
            float rotation = isMirrorLayout ? currentRotation - speed * rotationFactor : currentRotation + speed * rotationFactor;
            if (isMirrorLayout) {
                bindingMirror.txtSpeed.setText(String.valueOf(speed));
                bindingMirror.imgSpeedArrow.setRotation(rotation);
            } else {
                bindingNormal.txtSpeed.setText(String.valueOf(speed));
                bindingNormal.imgSpeedArrow.setRotation(rotation);
            }
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FragmentActivity activity = getActivity();
        if (activity != null) {
            activity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        bindingMirror = HupdFragmentHeadUpDisplayBinding.inflate(inflater, container, false);
        bindingNormal = HupdFragmentHeadUpDisplayNormalBinding.inflate(inflater, container, false);
        View view = bindingNormal.getRoot();
        initLocationListener();
        bindingMirror.imgBtnLeft.setOnClickListener(this);
        bindingNormal.imgBtnLeft.setOnClickListener(this);
        return view;
    }


    public final void initLocationListener() {
//        getRadarViewModel().getRadarLocalData().observe(getViewLifecycleOwner(), new g(new a()));
//        getRadarViewModel().getRadarModelData().observe(getViewLifecycleOwner(), new g(new b()));
//        getFragmentBridgeViewModel().getForceStop().observe(getViewLifecycleOwner(), new g(new c()));
//        getFragmentBridgeViewModel().getLocationPermisson().observe(getViewLifecycleOwner(), new g(new d()));
//        Context requireContext = requireContext();
//        new ConnectivityStatus(requireContext).observe(getViewLifecycleOwner(), new g(new e()));
    }


    @Override
    public void onResume() {
        super.onResume();
        handler.postDelayed(timeRunnable, 0L);
    }

    @Override
    public void onPause() {
        super.onPause();
        handler.removeCallbacks(timeRunnable);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        LocationUpdatesService mService = getMService();
        if (mService != null) {
            mService.onDestroy();
        }
        bindingMirror = null;
        bindingNormal = null;
    }

    @Override
    public void updateValues() {
//        LifecycleOwner viewLifecycleOwner = getViewLifecycleOwner();
//        DataStoreViewModel dataStoreViewModel = getDataStoreViewModel();
//        LifecycleOwnerKt.getLifecycleScope(viewLifecycleOwner).launchWhenStarted(() -> {
//            String unit = dataStoreViewModel.getUnitLength();
//            setUnitLength(unit);
//            updateSpeedUnit();
//        });
    }

    @Override
    public void setWarningState(boolean warningState) {
        // Implement if needed
    }


}
