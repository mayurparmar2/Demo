package com.maps.radar.trafficappfordriving.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class QuizCountry(
    val country_code: String,
    val end_point: String,
    val id: Int
): Parcelable