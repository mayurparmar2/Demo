package com.maps.radar.trafficappfordriving.model

import android.os.Parcelable
import androidx.annotation.Keep
import kotlinx.parcelize.Parcelize
import java.io.Serializable

@Parcelize
data class QuizMain(
    val name_of_app: String,
    val image_of_app: String,
    val list_of_img: List<String>,
    val content: List<All>
) : Parcelable {
    @Parcelize
    data class All(
        val question: List<QuestionAns>,
        val answers: List<QuestionAns>,
        val correctAnswer: Int,
        val category: String
    ) : Parcelable

    @Parcelize
    data class QuestionAns(
        val content: Content,
        val pos: Int,
        val type: String
    ) : Parcelable

//    @Parcelize
//    data class Answer(
//        val content: Content,
//        val pos: Int,
//        val type: String
//    ) : Parcelable

    @Parcelize
    data class Content(
        val text: String,
        val image_url: String?,
        val audio_url: String?,
        val text_map: Map<String, String>?
    ) : Parcelable
}
