package com.maps.radar.trafficappfordriving.ui.hupd;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.demo.radar.trafficappfordriving2.R;
import com.demo.radar.trafficappfordriving2.databinding.HupdActivtyMainBinding;

public final class HeadUpDisplayActivity extends AppCompatActivity {

    private HupdActivtyMainBinding binding;
    private NavController navController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = HupdActivtyMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Fragment navHostFragment = getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_activity_main);
        if (navHostFragment instanceof NavHostFragment) {
            navController = ((NavHostFragment) navHostFragment).getNavController();
        }
    }
}
