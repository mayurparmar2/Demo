package com.maps.radar.trafficappfordriving.offlinemap.model

import com.demo.radar.trafficappfordriving2.R

object PlaceholderContent {
    val items = listOf(
        PlaceholderItem(R.string.str_bank, R.drawable.ic_cats_banks, "bank"),
        PlaceholderItem(R.string.str_charging, R.drawable.ic_cats_charging, "fuel"),
        PlaceholderItem(R.string.str_coffee, R.drawable.ic_cats_coffee, "cafe"),
        PlaceholderItem(R.string.str_gas, R.drawable.ic_cats_gas, "fuel"),
        PlaceholderItem(R.string.str_grocerie, R.drawable.ic_cats_groceries, "shopping_centre"),
        PlaceholderItem(R.string.str_hospital, R.drawable.ic_cats_hospitals, "hospital"),
        PlaceholderItem(R.string.str_hotel, R.drawable.ic_cats_hotels, "hotel"),
        PlaceholderItem(R.string.str_park, R.drawable.ic_cats_parking, "parking"),
        PlaceholderItem(R.string.str_pharmacy, R.drawable.ic_cats_pharmacy, "pharmacy"),
        PlaceholderItem(R.string.str_restaurant, R.drawable.ic_cats_restaurant, "restaurant"),
        PlaceholderItem(R.string.str_transport, R.drawable.ic_cats_transport, "bus_station"),
        PlaceholderItem(R.string.str_wifi, R.drawable.ic_cats_wifi, "cafe")
    )

    data class PlaceholderItem(val titleResource: Int, val imageResource: Int, val amenity: String)
}