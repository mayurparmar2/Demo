package com.maps.radar.trafficappfordriving.quizmodule.dialog

import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.CustomDialogBoxBinding
import com.maps.radar.trafficappfordriving.Db.AllViewModel

class CustomDialog : DialogFragment() {
    private lateinit var binding: CustomDialogBoxBinding
    private lateinit var viewModel: AllViewModel
    private var isCorrect = false
    private var isSkipped = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = CustomDialogBoxBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(-1, -2)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(0))
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (isCorrect) {
            binding.homeButton.visibility = View.GONE
            binding.tryButton.visibility = View.GONE
            binding.nextQuestionButton.visibility = View.VISIBLE
            // Set text and image views
            binding.nextQuestionButton.setOnClickListener { viewModel.plusOneIndex(); dismiss() }
        } else {
            binding.pointEarn.text = getString(R.string.quiz_u_r_total_score)
            binding.totalPoint.text = viewModel.getPoint().value.toString()
            binding.tryButton.setOnClickListener { viewModel.initViewModel(); dismiss() }
            binding.homeButton.setOnClickListener { viewModel.plusOneIndex(); dismiss() }
        }
    }

    fun setCorrect(correct: Boolean) {
        isCorrect = correct
    }

    fun setSkipped(skipped: Boolean) {
        isSkipped = skipped
    }
}