package com.maps.radar.trafficappfordriving.offlinemap

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.ActivityOfflineMapBinding

class OfflineMapActivity : AppCompatActivity() {
    private lateinit var binding: ActivityOfflineMapBinding
    companion object {
        fun start(activity: Activity) {
            val intent = Intent(activity, OfflineMapActivity::class.java).apply {
                putExtra("map_type", "OFFLINE_MAPS")
            }
            activity.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate the view binding
        binding = ActivityOfflineMapBinding.inflate(layoutInflater)
        setContentView(binding.root)



        // Retrieve the map type from the intent
        val mapType = intent.getStringExtra("map_type")

        // Find the NavHostFragment and set up navigation
        val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment_activity_main) as? NavHostFragment

        navHostFragment?.let {
            val navController = it.navController
            val navGraph = navController.navInflater.inflate(R.navigation.offlinemap_navigation)
            // Set the start destination based on the map type
            navGraph.setStartDestination(
                when (mapType) {
                    "OFFLINE_MAPS" -> R.id.osmdroidFragment
                    else -> R.id.navigation_offline_map_list
                }
            )
            navController.graph = navGraph
        }
    }
}


//
//class OfflineMapActivity : AppCompatActivity() {
//
//    private lateinit var binding: ActivityOfflineMapBinding
//    private var keys: ConfigKeys? = null
//
//    companion object {
//        fun start(activity: Activity, configKeys: ConfigKeys) {
//            val intent = Intent(activity, OfflineMapActivity::class.java).apply {
//                putExtra("configKeys", configKeys)
//                putExtra("map_type", "OFFLINE_MAPS")
//            }
//            activity.startActivity(intent)
//        }
//    }
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        keys = if (Build.VERSION.SDK_INT >= 33) {
//            intent.getParcelableExtra("configKeys", ConfigKeys::class.java)
//        } else {
//            intent.getParcelableExtra("configKeys") as? ConfigKeys
//        }
//        val mapType = intent.getStringExtra("map_type")
//
//        lifecycleScope.launch {
////            viewModel.displayAddressState.collect { address ->
////                println("collected address $address")
////            }
//        }
//
//        binding = ActivityOfflineMapBinding.inflate(layoutInflater)
//        setContentView(binding.root)
//
//        val findFragmentById: Fragment? =supportFragmentManager.findFragmentById(R.id.nav_host_fragment_activity_main)
//        val navController = (findFragmentById as NavHostFragment).navController
//        val navGraph = navController.navInflater.inflate(R.navigation.offlinemap_navigation)
//
//        navGraph.startDestination = when (mapType) {
//            "OFFLINE_MAPS" -> R.id.osmdroidFragment
//            else -> R.id.navigation_offline_map_list
//        }
//        navController.graph = navGraph
//    }
//}
