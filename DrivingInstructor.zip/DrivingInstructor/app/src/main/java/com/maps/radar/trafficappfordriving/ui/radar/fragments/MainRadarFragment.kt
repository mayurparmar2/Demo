package com.maps.radar.trafficappfordriving.ui.radar.fragments

import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.RadarFragmentMainRadarBinding
import com.maps.radar.trafficappfordriving.ui.radar.FragmentBridgeViewModel
import com.maps.radar.trafficappfordriving.ui.radar.viewmodel.DataStoreViewModel

class MainRadarFragment : Fragment(), View.OnClickListener {

    private lateinit var fragmentBridgeViewModel:FragmentBridgeViewModel
    private lateinit var dataStoreViewModel: DataStoreViewModel
    private lateinit var _binding: RadarFragmentMainRadarBinding


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = RadarFragmentMainRadarBinding.inflate(inflater, container, false)
        setupClickListeners()
        return _binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        dataStoreViewModel = ViewModelProvider(this).get(DataStoreViewModel::class.java)
        fragmentBridgeViewModel = ViewModelProvider(this).get(FragmentBridgeViewModel::class.java)


        dataStoreViewModel.isDataLoaded().observe(viewLifecycleOwner, androidx.lifecycle.Observer { isLoaded ->
            if (isLoaded) {
                // data loaded
            }
        })
        fragmentBridgeViewModel.getLocationPermisson().observe(viewLifecycleOwner, androidx.lifecycle.Observer  { isGranted ->
            if (isGranted) {
                // location permission granted
            } else {
                // location permission denied
            }
        })
    }


    private fun setupClickListeners() {
        _binding.includeFirstFragment.btnOk.setOnClickListener(this)
        _binding.includeFirstFragment.btnKm.setOnClickListener(this)
        _binding.includeFirstFragment.btnMile.setOnClickListener(this)
        _binding.includeFirstFragment.btnKmFuel.setOnClickListener(this)
        _binding.includeFirstFragment.btnMileFuelUk.setOnClickListener(this)
        _binding.includeFirstFragment.btnMileFuelUsa.setOnClickListener(this)
        _binding.includeFirstFragment.imgMinus.setOnClickListener(this)
        _binding.includeFirstFragment.imgPlus.setOnClickListener(this)
        _binding.btnStart.setOnClickListener(this)
        _binding.includeLocation.btnAllow.setOnClickListener(this)
        _binding.includeLocation.btnSkip.setOnClickListener(this)
        _binding.includeWelcome.btnPopupCancel.setOnClickListener(this)
        _binding.includeWelcome.btnPopupYes.setOnClickListener(this)
        _binding.includeLaterPopup.btnPopupOk.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
//            R.id.imgMinus -> {
//                // minus button clicked
//            }
//            R.id.imgPlus -> {
//                // plus button clicked
//            }
//            R.id.btnKm -> {
//                // km button clicked
//            }
//            R.id.btnMile -> {
//                // mile button clicked
//            }
//            R.id.btnKmFuel -> {
//                // km fuel button clicked
//            }
//            R.id.btnMileFuelUk -> {
//                // mile fuel uk button clicked
//            }
//            R.id.btnMileFuelUsa -> {
//                // mile fuel usa button clicked
//            }
//            R.id.btnOk -> {
//                // ok button clicked
//            }
//            R.id.btnStart -> {
//                // start button clicked
//            }
//            R.id.btnAllow -> {
//                // allow button clicked
//            }
//            R.id.btnSkip -> {
//                // skip button clicked
//            }
//            R.id.btnPopupCancel -> {
//                // cancel button clicked
//            }
//            R.id.btnPopupYes -> {
//                // yes button clicked
//            }
//            R.id.btnPopupOk -> {
//                // ok button clicked
//            }
        }
    }


}