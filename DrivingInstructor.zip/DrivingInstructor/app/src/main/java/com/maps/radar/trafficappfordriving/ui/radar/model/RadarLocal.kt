package com.maps.radar.trafficappfordriving.ui.radar.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Radar")
data class RadarLocal(
    @PrimaryKey val id: Long,
    @ColumnInfo(name = "X", typeAffinity = 4) val x: Double,
    @ColumnInfo(name = "Y") val y: Double,
    @ColumnInfo(name = "TYPE") val type: Integer,
    @ColumnInfo(name = "SPEED") val speed: Integer
)