package com.maps.radar.trafficappfordriving.ui.hupd;

import android.location.Location;

public interface LocationUpdateListener {
    void onLocationChanged(Location location);
}