package com.maps.radar.trafficappfordriving.Db

import android.annotation.SuppressLint
import android.content.Context
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class ImplRepository private constructor(private val context: Context) {

    // Simulating data storage, e.g., using SharedPreferences or a database
    private val sharedPreferences = context.getSharedPreferences("quiz_prefs", Context.MODE_PRIVATE)

    fun getProgress(key: String): Flow<Int> {
        return flow {
            val progress = sharedPreferences.getInt(key, 0)
            emit(progress)
        }
    }

    suspend fun saveProgress(key: String, progress: Int) {
        sharedPreferences.edit().putInt(key, progress).apply()
    }


    fun getProgress2(key: String): Int {
        return sharedPreferences.getInt(key, 0)
    }

    companion object {
        @SuppressLint("StaticFieldLeak")
        @Volatile
        private var instance: ImplRepository? = null
        fun getInstance(context: Context): ImplRepository {
            return instance ?: synchronized(this) {
                instance ?: ImplRepository(context).also { instance = it }
            }
        }
    }
}
