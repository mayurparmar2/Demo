package com.maps.radar.trafficappfordriving.model

import android.os.Parcelable
import com.maps.radar.trafficappfordriving.ui.guide.model.Guide
import kotlinx.parcelize.Parcelize


@Parcelize
data class GuideGroup(
    val groupId: Int,
    val name: String,
    val title: String?,
    val items: List<GuideItem>,
) : Parcelable

@Parcelize
data class GuideItem(
    val id: Int,
    val name: String,
    val title: String?,
    val body: String?,
    val imageUrl: String?,
    val items: List<GuideTextItemRes>,
    val tips: GuideTextItemRes?,
    val videoUrl: String?
) : Parcelable{

    fun getGuides(): List<Guide> {
        val guide: Guide
        val guidesList: MutableList<Guide> = ArrayList()

        if (this.videoUrl != null) {
            guide = Guide.VideoGuide(0, this.videoUrl)
        } else {
            guide = Guide.ImageGuide(0, this.body, this.imageUrl)
        }
        guidesList.add(guide)
        for (item in this.items) {
            guidesList.add(Guide.TextGuide(guidesList.size, item))
        }
        if (this.tips != null) {
            guidesList.add(Guide.TextGuide(guidesList.size, this.tips))
        }
        return guidesList
    }
}

@Parcelize
data class GuideTextItemRes(
    val title: String,
    val lines: List<String>?,
    val hasBullet: Boolean,
) : Parcelable

//@Parcelize
//data class GuideTips(
//    val title: String,
//    val lines: List<String>,
//    val hasBullet: Boolean,
//) : Parcelable