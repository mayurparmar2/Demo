package com.maps.radar.trafficappfordriving.quizmodule

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.demo.radar.trafficappfordriving2.R

class QuizReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        if (context != null && intent != null) {
            createNotificationChannel(context)
            showNotification(context)
        }
    }

    private fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val notificationChannel = NotificationChannel("1009", "QuizNotification", NotificationManager.IMPORTANCE_HIGH)
            NotificationManagerCompat.from(context).createNotificationChannel(notificationChannel)
        }
    }

    private fun showNotification(context: Context) {
        val intent = Intent(context, QuizMainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        val pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(context, "1009")
            .setContentIntent(pendingIntent)
            .setSmallIcon(R.drawable.quiz_ic_notif)
            .setContentText(context.getString(R.string.quiz_notification_body))
            .setContentTitle(context.getString(R.string.quiz_notification_title))
            .setPriority(NotificationCompat.PRIORITY_HIGH)

        if (ContextCompat.checkSelfPermission(context, "android.permission.POST_NOTIFICATIONS") == 0) {
            NotificationManagerCompat.from(context).notify(109, notification.build())
        }
    }
}