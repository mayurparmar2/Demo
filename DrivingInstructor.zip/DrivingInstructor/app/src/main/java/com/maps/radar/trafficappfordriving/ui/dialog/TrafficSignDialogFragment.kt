package lib.module.trafficsignsmodule.presentation

import android.app.Dialog
import android.graphics.Bitmap
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.demo.radar.trafficappfordriving2.databinding.TrafficSignsModuleDialogFragmentBinding
import com.maps.radar.trafficappfordriving.model.TrafficSign

class TrafficSignDialogFragment : DialogFragment() {
    private var binding: TrafficSignsModuleDialogFragmentBinding? = null
    private var item: TrafficSign? = null


    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        binding = TrafficSignsModuleDialogFragmentBinding.inflate(layoutInflater)
        setBinding(binding)

        // Load image using Glide
        Glide.with(this).load(item?.img_url.toString()).into(binding!!.imgSign)

        binding!!.btnClose.setOnClickListener(View.OnClickListener { dismiss() })

        binding!!.btnShare.setOnClickListener(View.OnClickListener {
            Glide.with(binding!!.imgSign.context!!)
                .asBitmap()
                .load(item!!.img_url.toString())
                .into(object : SimpleTarget<Bitmap?>() {
                    override fun onResourceReady(
                        resource: Bitmap,
                        transition: Transition<in Bitmap?>?
                    ) {
                        startActivity(item!!.getShareIntent(resource , binding!!.imgSign.context))
                    }
                })


        })

        val builder = AlertDialog.Builder(requireActivity())
        builder.setView(binding!!.getRoot())
        val dialog = builder.create()
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        return dialog
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val window = dialog!!.window
        window?.setBackgroundDrawable(ColorDrawable(0))
        return super.onCreateView(inflater, container, savedInstanceState)
    }

    fun setBinding(binding: TrafficSignsModuleDialogFragmentBinding?) {
        this.binding = binding
    }

    fun setItem(item: TrafficSign?) {
        this.item = item
    }
}
