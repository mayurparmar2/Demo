package com.maps.radar.trafficappfordriving.model

import android.os.Parcel
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class TurnSignalIndicator(
    val id: Int,
    val name: String,
    val description: String,
    val img_url: String
) : Parcelable
