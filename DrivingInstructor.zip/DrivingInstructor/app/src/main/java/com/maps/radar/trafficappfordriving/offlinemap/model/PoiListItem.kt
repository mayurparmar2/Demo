package com.maps.radar.trafficappfordriving.offlinemap.model

import org.osmdroid.views.overlay.Marker

data class PoiListItem(
    val poiName: String,
    val imageResource: Int?,
    val isAd: Int,
    val marker: Marker
)