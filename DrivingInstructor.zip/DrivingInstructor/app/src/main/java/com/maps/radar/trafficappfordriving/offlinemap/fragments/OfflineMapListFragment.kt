package com.maps.radar.trafficappfordriving.offlinemap.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.demo.radar.trafficappfordriving2.R
import com.demo.radar.trafficappfordriving2.databinding.FragmentOfflineMapListBinding
import com.maps.radar.trafficappfordriving.offlinemap.MapAdapter
import com.maps.radar.trafficappfordriving.offlinemap.model.MapItem

class OfflineMapListFragment: Fragment() {


    private val mapItemList = listOf(
        MapItem(R.drawable.google, "Google Maps", "com.google.android.apps.maps"),
        MapItem(R.drawable.here, "HERE WeGo", "com.here.app.maps"),
        MapItem(R.drawable.waze, "Waze", "com.waze"),
        MapItem(R.drawable.mapsme, "MAPS.ME", "com.mapswithme.maps.pro"),
        MapItem(R.drawable.sygic, "Sygic GPS Navigation", "com.sygic.aura"),
        MapItem(R.drawable.tomtom, "TomTom Navigation", "com.tomtom.gplay.navapp"),
        MapItem(R.drawable.citymapper, "Citymapper", "com.citymapper.app.release"),
        MapItem(R.drawable.navmii, "Navmii GPS World", "com.navfree.android.OSM.ALL"),
        MapItem(R.drawable.mapquest, "MAPQUEST", "com.mapquest.android.ace"),
        MapItem(R.drawable.yandex, "Yandex.Navigation", "ru.yandex.yandexnavi")
    )

    private lateinit var binding: FragmentOfflineMapListBinding
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentOfflineMapListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.recyclerView.adapter = MapAdapter(mapItemList) {

        }

    }

}