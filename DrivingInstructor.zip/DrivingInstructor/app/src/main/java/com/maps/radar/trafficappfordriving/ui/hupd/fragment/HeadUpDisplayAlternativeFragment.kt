package com.maps.radar.trafficappfordriving.ui.hupd.fragment

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.demo.radar.trafficappfordriving2.databinding.HupdFragmentHeadUpDisplayAlternativeBinding
import com.demo.radar.trafficappfordriving2.databinding.HupdFragmentHeadUpDisplayAlternativeNormalBinding
import com.maps.radar.trafficappfordriving.ui.radar.RadarModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.List
import java.util.Locale


class HeadUpDisplayAlternativeFragment : BaseRadarFragment(), View.OnClickListener {

    private lateinit var _binding: HupdFragmentHeadUpDisplayAlternativeBinding
    private lateinit var _bindingNormal: HupdFragmentHeadUpDisplayAlternativeNormalBinding
    private var currentRotation = 0f
    private var isShowingMirrorLayout = false
    private lateinit var view: View
    private lateinit var viewMirror: View
    private lateinit var viewNormal: View
    private val timeUpdate = 1000L
    private val handler = Handler(Looper.getMainLooper())
    private val rotationArtisi = 1.0f
    private val timeRunnable = Runnable {
        val calendar = Calendar.getInstance()
        val simpleDateFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val simpleDateFormat2 = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        val time = simpleDateFormat.format(calendar.time)
        val date = simpleDateFormat2.format(calendar.time)
        if (isShowingMirrorLayout) {
            _binding.txtTime.text = time
            _binding.txtDate.text = date
        } else {
            _bindingNormal.txtTime.text = time
            _bindingNormal.txtDate.text = date
        }
        handler.postDelayed(Runnable {

        }, timeUpdate)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = HupdFragmentHeadUpDisplayAlternativeBinding.inflate(inflater, container, false)
        _bindingNormal = HupdFragmentHeadUpDisplayAlternativeNormalBinding.inflate(inflater, container, false)
        viewMirror = _binding.root
        viewNormal = _bindingNormal.root
        view = viewNormal
        initLocationListener()
        _binding.imgBtnLeft.setOnClickListener(this)
        _binding.imgBtnRight.setOnClickListener(this)
        _bindingNormal.imgBtnLeft.setOnClickListener(this)
        _bindingNormal.imgBtnRight.setOnClickListener(this)
        return view
    }

    fun initLocationListener() {
//        getRadarViewModel().getRadarLocalData().observe(viewLifecycleOwner, g(a()))
//        getRadarViewModel().getRadarModelData().observe(viewLifecycleOwner, g(b()))
//        getFragmentBridgeViewModel().getForceStop().observe(viewLifecycleOwner, g(c()))
//        getFragmentBridgeViewModel().getLocationPermisson().observe(viewLifecycleOwner, g(d()))
//        ConnectivityStatus(requireContext()).observe(viewLifecycleOwner, g(e()))
    }

    override fun onClick(v: View?) {
        if (v?.id == _binding.imgBtnLeft.id || v?.id == _bindingNormal.imgBtnLeft.id) {
            toggleLayout()
        } else if (v?.id == _binding.imgBtnRight.id || v?.id == _bindingNormal.imgBtnRight.id) {
            toggleLayout()
        }
    }

    private fun toggleLayout() {
        if (isShowingMirrorLayout) {
            currentRotation = 0f
            val parent = viewMirror.parent as ViewGroup
            parent.removeView(viewMirror)
            parent.addView(viewNormal)
        } else {
            currentRotation = 90f
            val parent = viewNormal.parent as ViewGroup
            parent.removeView(viewNormal)
            parent.addView(viewMirror)
        }
        isShowingMirrorLayout = !isShowingMirrorLayout
    }

    override fun calculateSpeedWarning(num: Int) {
    }

    override fun onResume() {
        super.onResume()
        handler.postDelayed(timeRunnable, 0)
    }

    override fun nextRadarWarning(list: List<RadarModel>) {
    }

    override fun setWarningState(z: Boolean) {
    }

    override fun updateValues() {
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(timeRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(timeRunnable)
//        _binding = null
//        _bindingNormal = null
    }
}