package com.maps.radar.trafficappfordriving.Db

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class QuizProgressViewModel(app: Application) : AndroidViewModel(app) {
    private val dao: QuizProgressDao = QuizProgressDb.getInstance(app).appDAO()
    private val repo: QuizProgressRepo = QuizProgressRepo(dao)


    val allProgressItem: LiveData<List<QuizProgressItem>> = repo.allProgressItem
    val allDoneData: LiveData<List<QuizProgressItem>> = repo.allDoneData

    fun addProgressItem(progressItem: QuizProgressItem) {
        viewModelScope.launch {
            repo.addProgressItem(progressItem)
        }
    }
    fun startTest(i10: Int) {
        viewModelScope.launch {
            repo.startTest(i10)
        }
    }
    fun updateProgressItem(newProgress: Float, index: Int) {
        viewModelScope.launch {
            repo.updateProgressItem(newProgress, index)
        }
    }

    fun returnCountOfProgress(): Int {
        return dao.getCountOfProgress()
    }
}