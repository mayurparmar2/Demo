package com.maps.radar.trafficappfordriving.quizmodule.Adapter;

import android.view.View;

public interface OnPlayClickListener {
    void onPlay(View view, String audioUrl, boolean isPlaying);
}