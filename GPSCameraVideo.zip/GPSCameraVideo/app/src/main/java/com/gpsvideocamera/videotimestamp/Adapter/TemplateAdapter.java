package com.gpsvideocamera.videotimestamp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import androidx.recyclerview.widget.RecyclerView;
import com.gpsvideocamera.videotimestamp.Interface.OnRecyclerItemClickListener;
import com.gpsvideocamera.videotimestamp.Model.TemplateModel;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import java.util.List;


public class TemplateAdapter extends RecyclerView.Adapter<TemplateAdapter.Holder> {
    boolean isAddress;
    boolean isCompass;
    boolean isCompassFound;
    boolean isDateTime;
    boolean isLatLng;
    boolean isMagneticField;
    boolean isMap;
    boolean isWeather;
    Context mContext;
    List<TemplateModel> mList;
    OnRecyclerItemClickListener mOnRecyclerItemClickListener;
    SP mSP;

    public void refreshAdapter(List<TemplateModel> list) {
    }

    public TemplateAdapter(Context context, List<TemplateModel> list, OnRecyclerItemClickListener onRecyclerItemClickListener) {
        this.mContext = context;
        this.mList = list;
        this.mOnRecyclerItemClickListener = onRecyclerItemClickListener;
        SP sp = new SP(this.mContext);
        this.mSP = sp;
        this.isCompassFound = sp.getBoolean(this.mContext, SP.COMPASS_FOUND, false).booleanValue();
    }

    @Override 
    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_template, viewGroup, false));
    }

    public void onBindViewHolder(Holder holder, int i) {
        holder.chk_template.setText(this.mList.get(i).getTitle());
        if (this.mList.get(i).isSelected()) {
            holder.chk_template.setChecked(true);
        }
    }

    @Override 
    public int getItemCount() {
        return this.mList.size();
    }

    
    public class Holder extends RecyclerView.ViewHolder {
        CheckBox chk_template;
        LinearLayout temp_main_lay;

        public Holder(View view) {
            super(view);
            this.chk_template = (CheckBox) view.findViewById(R.id.chk_template);
            LinearLayout linearLayout = (LinearLayout) view.findViewById(R.id.temp_main_lay);
            this.temp_main_lay = linearLayout;
            linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override 
                public void onClick(View view2) {
                    if (Holder.this.getAdapterPosition() >= 0 && TemplateAdapter.this.mList.size() > 0 && Holder.this.getAdapterPosition() < TemplateAdapter.this.mList.size()) {
                        if (Holder.this.chk_template.isChecked()) {
                            TemplateAdapter.this.mSP.setBoolean(TemplateAdapter.this.mContext, TemplateAdapter.this.mList.get(Holder.this.getAdapterPosition()).getSpKey(), false);
                            Holder.this.chk_template.setChecked(false);
                        } else {
                            Holder.this.chk_template.setChecked(true);
                            TemplateAdapter.this.mSP.setBoolean(TemplateAdapter.this.mContext, TemplateAdapter.this.mList.get(Holder.this.getAdapterPosition()).getSpKey(), true);
                        }
                        TemplateAdapter.this.isMap = TemplateAdapter.this.mSP.getBoolean(TemplateAdapter.this.mContext, TemplateAdapter.this.mList.get(0).getSpKey(), true).booleanValue();
                        TemplateAdapter.this.isAddress = TemplateAdapter.this.mSP.getBoolean(TemplateAdapter.this.mContext, TemplateAdapter.this.mList.get(1).getSpKey(), true).booleanValue();
                        TemplateAdapter.this.isLatLng = TemplateAdapter.this.mSP.getBoolean(TemplateAdapter.this.mContext, TemplateAdapter.this.mList.get(2).getSpKey(), true).booleanValue();
                        TemplateAdapter.this.isDateTime = TemplateAdapter.this.mSP.getBoolean(TemplateAdapter.this.mContext, TemplateAdapter.this.mList.get(3).getSpKey(), true).booleanValue();
                        TemplateAdapter.this.isWeather = TemplateAdapter.this.mSP.getBoolean(TemplateAdapter.this.mContext, TemplateAdapter.this.mList.get(4).getSpKey(), false).booleanValue();
                        if (TemplateAdapter.this.isCompassFound) {
                            TemplateAdapter.this.isMagneticField = TemplateAdapter.this.mSP.getBoolean(TemplateAdapter.this.mContext, TemplateAdapter.this.mList.get(5).getSpKey(), false).booleanValue();
                            TemplateAdapter.this.isCompass = TemplateAdapter.this.mSP.getBoolean(TemplateAdapter.this.mContext, TemplateAdapter.this.mList.get(6).getSpKey(), false).booleanValue();
                            if (!TemplateAdapter.this.isMap && !TemplateAdapter.this.isAddress && !TemplateAdapter.this.isLatLng && !TemplateAdapter.this.isWeather && !TemplateAdapter.this.isDateTime && !TemplateAdapter.this.isMagneticField && !TemplateAdapter.this.isCompass) {
                                TemplateAdapter.this.mSP.setBoolean(TemplateAdapter.this.mContext, TemplateAdapter.this.mList.get(3).getSpKey(), true);
                                TemplateAdapter.this.mList.get(0).setSelected(false);
                                TemplateAdapter.this.mList.get(1).setSelected(false);
                                TemplateAdapter.this.mList.get(2).setSelected(false);
                                TemplateAdapter.this.mList.get(3).setSelected(true);
                                TemplateAdapter.this.mList.get(4).setSelected(false);
                                TemplateAdapter.this.mList.get(5).setSelected(false);
                                TemplateAdapter.this.mList.get(6).setSelected(false);
                                TemplateAdapter.this.notifyDataSetChanged();
                            } else if (TemplateAdapter.this.isMap && !TemplateAdapter.this.isAddress && !TemplateAdapter.this.isLatLng && !TemplateAdapter.this.isWeather && !TemplateAdapter.this.isDateTime && !TemplateAdapter.this.isMagneticField && !TemplateAdapter.this.isCompass) {
                                TemplateAdapter.this.mSP.setBoolean(TemplateAdapter.this.mContext, TemplateAdapter.this.mList.get(3).getSpKey(), true);
                                TemplateAdapter.this.mList.get(0).setSelected(true);
                                TemplateAdapter.this.mList.get(1).setSelected(false);
                                TemplateAdapter.this.mList.get(2).setSelected(false);
                                TemplateAdapter.this.mList.get(3).setSelected(true);
                                TemplateAdapter.this.mList.get(4).setSelected(false);
                                TemplateAdapter.this.mList.get(5).setSelected(false);
                                TemplateAdapter.this.mList.get(6).setSelected(false);
                                TemplateAdapter.this.notifyDataSetChanged();
                            }
                        } else if (!TemplateAdapter.this.isMap && !TemplateAdapter.this.isAddress && !TemplateAdapter.this.isLatLng && !TemplateAdapter.this.isWeather && !TemplateAdapter.this.isDateTime) {
                            TemplateAdapter.this.mSP.setBoolean(TemplateAdapter.this.mContext, TemplateAdapter.this.mList.get(3).getSpKey(), true);
                            TemplateAdapter.this.mList.get(0).setSelected(false);
                            TemplateAdapter.this.mList.get(1).setSelected(false);
                            TemplateAdapter.this.mList.get(2).setSelected(false);
                            TemplateAdapter.this.mList.get(3).setSelected(true);
                            TemplateAdapter.this.mList.get(4).setSelected(false);
                            TemplateAdapter.this.notifyDataSetChanged();
                        } else if (TemplateAdapter.this.isMap && !TemplateAdapter.this.isAddress && !TemplateAdapter.this.isLatLng && !TemplateAdapter.this.isWeather && !TemplateAdapter.this.isDateTime) {
                            TemplateAdapter.this.mSP.setBoolean(TemplateAdapter.this.mContext, TemplateAdapter.this.mList.get(3).getSpKey(), true);
                            TemplateAdapter.this.mList.get(0).setSelected(true);
                            TemplateAdapter.this.mList.get(1).setSelected(false);
                            TemplateAdapter.this.mList.get(2).setSelected(false);
                            TemplateAdapter.this.mList.get(3).setSelected(true);
                            TemplateAdapter.this.mList.get(4).setSelected(false);
                            TemplateAdapter.this.notifyDataSetChanged();
                        }
                        if (TemplateAdapter.this.mOnRecyclerItemClickListener != null) {
                            TemplateAdapter.this.mOnRecyclerItemClickListener.OnClick_(Holder.this.getAdapterPosition(), view2);
                        }
                    }
                }
            });
        }
    }
}
