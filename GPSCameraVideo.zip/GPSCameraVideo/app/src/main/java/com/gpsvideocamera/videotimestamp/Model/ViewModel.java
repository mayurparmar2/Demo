package com.gpsvideocamera.videotimestamp.Model;


public class ViewModel {
    private int id;
    private Boolean isSelected;
    private String name;
    private String value;

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public String getValue() {
        return this.value;
    }

    public void setValue(String str) {
        this.value = str;
    }

    public Boolean getSelected() {
        return this.isSelected;
    }

    public void setSelected(Boolean bool) {
        this.isSelected = bool;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int i) {
        this.id = i;
    }
}
