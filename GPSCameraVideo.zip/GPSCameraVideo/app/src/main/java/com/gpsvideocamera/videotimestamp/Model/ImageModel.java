package com.gpsvideocamera.videotimestamp.Model;

import android.net.Uri;


public class ImageModel {
    public String name;
    public String path;
    public Uri uri;

    public ImageModel(Uri uri, String str, String str2) {
        this.uri = uri;
        this.name = str;
        this.path = str2;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public Uri getUri() {
        return this.uri;
    }

    public void setUri(Uri uri) {
        this.uri = uri;
    }

    public String getPath() {
        return this.path;
    }

    public void setPath(String str) {
        this.path = str;
    }
}
