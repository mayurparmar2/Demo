package com.gpsvideocamera.videotimestamp.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
 






import com.google.android.material.snackbar.Snackbar;
import com.gpsvideocamera.videotimestamp.Adapter.AddFolderAdapter;
import com.gpsvideocamera.videotimestamp.Interface.OnRecyclerItemClickListener;
import com.gpsvideocamera.videotimestamp.Model.FileGetSet;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.Default;
import com.gpsvideocamera.videotimestamp.Utils.HelperClass;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;


public class FolderActivity extends AppCompatActivity implements View.OnClickListener {
    private boolean IS_ADS;
    String ads_status;
    boolean is_pro;
    private AddFolderAdapter mAdapter;
    private RecyclerView mAdd_Folder_Recyclerview;
    HelperClass mHelperClass;
    private ImageView mImgPro;
     
    private String mSelectedVale;
    private SP mSp;
    private RelativeLayout mToolbar_add;
    private RelativeLayout mToolbar_back;
    private TextView mtv_toolbar_title;
    private List<FileGetSet> mFolderList = new ArrayList();
    private long mLastClickTime = 0;

    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        HelperClass helperClass = new HelperClass();
        this.mHelperClass = helperClass;
        helperClass.SetLanguage(this);
        AppCompatDelegate. setDefaultNightMode(androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_NO);
        setContentView(R.layout.activity_folder);
        init();
    }

    private void init() {
        this.mSp = new SP(this);
        this.ads_status = new SP(this).getString(this, SP.ADS_STATUS, "1");
        this.IS_ADS = new SP(this).getBoolean(this, HelperClass.IS_PURCHESH_OR_NOT, false).booleanValue();
        this.mToolbar_back = (RelativeLayout) findViewById(R.id.toolbar_back);
        this.mToolbar_add = (RelativeLayout) findViewById(R.id.toolbar_add);
        this.mtv_toolbar_title = (TextView) findViewById(R.id.tv_toolbar_title);
        this.mImgPro = (ImageView) findViewById(R.id.imgPro);
        this.mtv_toolbar_title.setText(getString(R.string.select_folder));
        this.mToolbar_add.setVisibility(View.VISIBLE);
        this.mAdd_Folder_Recyclerview = (RecyclerView) findViewById(R.id.add_folder_recyclerview);
        boolean booleanValue = new SP(this).getBoolean(this, HelperClass.IS_PURCHESH_OR_NOT, false).booleanValue();
        this.is_pro = booleanValue;
        if (!booleanValue) {
            this.mImgPro.setVisibility(View.VISIBLE);
        }
        this.mSelectedVale = this.mSp.getString(this, SP.FOLDER_NAME, Default.DEFAULT_FOLDER_PATH);
        setAdapter();
        onClicks();
    }


    private void setAdapter() {
        fillData();
        this.mAdd_Folder_Recyclerview.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        AddFolderAdapter addFolderAdapter = new AddFolderAdapter(this, this.mFolderList, new OnRecyclerItemClickListener() { 
            @Override 
            public void OnClick_(int i, View view) {
                FolderActivity folderActivity = FolderActivity.this;
                folderActivity.mSelectedVale = ((FileGetSet) folderActivity.mFolderList.get(i)).getFilePath();
                new Handler().postDelayed(new Runnable() { 
                    @Override 
                    public void run() {
                        FolderActivity.this.mAdapter.refAdapter(FolderActivity.this.mSelectedVale);
                    }
                }, 150);
            }

            @Override 
            public void OnLongClick_(int i, View view) {
                if (!((FileGetSet) FolderActivity.this.mFolderList.get(i)).getFileName().equals(Default.SITE_1) && !((FileGetSet) FolderActivity.this.mFolderList.get(i)).getFileName().equals(Default.SITE_2) && !((FileGetSet) FolderActivity.this.mFolderList.get(i)).getFileName().equals(Default.DEFAULT_FOLDER_NAME)) {
                    FolderActivity.this.openDeleteDialog(i);
                }
            }
        });
        this.mAdapter = addFolderAdapter;
        this.mAdd_Folder_Recyclerview.setAdapter(addFolderAdapter);
    }

    public void openDeleteDialog(final int i) {
        if (!isFinishing()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getString(R.string.delete_dialog_title));
            builder.setMessage(getString(R.string.delete_dialog_message));
            builder.setPositiveButton(getString(R.string.delete), new DialogInterface.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FolderActivity.2
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i2) {
                    File file = new File(((FileGetSet) FolderActivity.this.mFolderList.get(i)).getFilePath());
                    if (file.exists()) {
                        FolderActivity.this.mFolderList.remove(i);
                        if (file.getAbsolutePath().equals(FolderActivity.this.mSelectedVale)) {
                            FolderActivity.this.mSelectedVale = Default.DEFAULT_FOLDER_PATH;
                            FolderActivity.this.mAdapter.refAdapter(FolderActivity.this.mFolderList, FolderActivity.this.mSelectedVale);
                            SP sp = FolderActivity.this.mSp;
                            FolderActivity folderActivity = FolderActivity.this;
                            sp.setString(folderActivity, SP.FOLDER_NAME, folderActivity.mSelectedVale);
                        } else {
                            FolderActivity.this.mAdapter.refAdapter(FolderActivity.this.mFolderList, FolderActivity.this.mSelectedVale);
                        }
                        FolderActivity.this.deleteFile(file);
                    }
                    dialogInterface.dismiss();
                }
            });
            builder.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FolderActivity.3
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i2) {
                    dialogInterface.dismiss();
                }
            });
            builder.create().show();
        }
    }

    public void deleteFile(File file) {
        if (file.isDirectory()) {
            File[] listFiles = file.listFiles();
            for (File file2 : listFiles) {
                file2.delete();
                deleteFile(file2);
            }
        }
        file.delete();
    }

    private void fillData() {
        this.mFolderList.clear();
        FileGetSet fileGetSet = new FileGetSet();
        fileGetSet.setFileName(Default.DEFAULT_FOLDER_NAME);
        fileGetSet.setFilePath(Default.DEFAULT_FOLDER_PATH);
        this.mFolderList.add(fileGetSet);
        int i = 0;
        if (!this.is_pro) {
            File[] listFiles = new File(Default.PARENT_FOLDER_PATH).listFiles();
            if (listFiles != null && listFiles.length > 0) {
                while (i < listFiles.length) {
                    if (listFiles[i].getName().equals(Default.SITE_1) || listFiles[i].getName().equals(Default.SITE_2)) {
                        FileGetSet fileGetSet2 = new FileGetSet();
                        fileGetSet2.setFileName(listFiles[i].getName());
                        fileGetSet2.setFilePath(listFiles[i].getAbsolutePath());
                        this.mFolderList.add(fileGetSet2);
                    }
                    i++;
                }
                return;
            }
            return;
        }
        File[] listFiles2 = new File(Default.PARENT_FOLDER_PATH).listFiles();
        if (listFiles2 != null && listFiles2.length > 0) {
            while (i < listFiles2.length) {
                FileGetSet fileGetSet3 = new FileGetSet();
                fileGetSet3.setFileName(listFiles2[i].getName());
                fileGetSet3.setFilePath(listFiles2[i].getAbsolutePath());
                this.mFolderList.add(fileGetSet3);
                i++;
            }
        }
    }

    private void onClicks() {
        this.mToolbar_back.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FolderActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                FolderActivity.this.onClick(view);
            }
        });
        this.mToolbar_add.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FolderActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                FolderActivity.this.onClick(view);
            }
        });
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        if (SystemClock.elapsedRealtime() - this.mLastClickTime >= 1000) {
            this.mLastClickTime = SystemClock.elapsedRealtime();
            switch (view.getId()) {
                case R.id.toolbar_add :
                    if (this.is_pro) {
                        addFolderDialog();
                        return;
                    } else {
                        createInAppDialog();
                        return;
                    }
                case R.id.toolbar_back :
                    onBackPressed();
                    return;
                default:
                    return;
            }
        }
    }

    private void addFolderDialog() {
        if (!isFinishing()) {
            final View inflate = View.inflate(this, R.layout.dialog_add_folder, null);
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setView(inflate);
            final AlertDialog create = builder.create();
            final EditText editText = (EditText) inflate.findViewById(R.id.edAddFolder);
            editText.addTextChangedListener(new TextWatcher() { // from class: com.gpsvideocamera.videotimestamp.Activity.FolderActivity.4
                @Override // android.text.TextWatcher
                public void afterTextChanged(Editable editable) {
                }

                @Override // android.text.TextWatcher
                public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                }

                @Override // android.text.TextWatcher
                public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                    if (charSequence.toString().length() == 30) {
                        View view = inflate;
                        Snackbar.make(view, "" + FolderActivity.this.getString(R.string.max_length_msg), -Toast.LENGTH_LONG).show();
                    }
                }
            });
            ((TextView) inflate.findViewById(R.id.tv_cancel)).setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FolderActivity.5
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    HelperClass.hideSoftKeyboard(FolderActivity.this, view);
                    AlertDialog alertDialog = create;
                    if (alertDialog != null) {
                        alertDialog.cancel();
                        create.dismiss();
                    }
                }
            });
            ((TextView) inflate.findViewById(R.id.tv_ok)).setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FolderActivity.6
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    String trim = editText.getText().toString().trim();
                    if (Pattern.compile("^([a-zA-Z0-9][^*/><?\"|:]*)$").matcher(trim).matches()) {
                        File file = new File(Default.PARENT_FOLDER_PATH + trim);
                        if (!file.exists()) {
                            file.mkdir();
                            FileGetSet fileGetSet = new FileGetSet();
                            fileGetSet.setFilePath(file.getAbsolutePath());
                            fileGetSet.setFileName(file.getName());
                            FolderActivity.this.mFolderList.add(fileGetSet);
                            FolderActivity.this.mSelectedVale = file.getAbsolutePath();
                            if (FolderActivity.this.mAdapter != null) {
                                FolderActivity.this.mAdapter.refAdapter(FolderActivity.this.mFolderList, FolderActivity.this.mSelectedVale);
                            }
                            AlertDialog alertDialog = create;
                            if (alertDialog != null) {
                                alertDialog.cancel();
                                create.dismiss();
                                return;
                            }
                            return;
                        }
                        Snackbar.make(view, "" + FolderActivity.this.getString(R.string.dummy_folder_empty_msg), -Toast.LENGTH_LONG).show();
                        return;
                    }
                    Snackbar.make(view, "" + FolderActivity.this.getString(R.string.add_folder_empty_msg), -Toast.LENGTH_LONG).show();
                }
            });
            if (create.getWindow() != null) {
                create.getWindow().getAttributes().windowAnimations = R.style.SlidingDialogAnimation;
            }
            if (create != null && !create.isShowing()) {
                create.show();
            }
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (!this.mSelectedVale.equals(this.mSp.getString(this, SP.FOLDER_NAME, Default.DEFAULT_FOLDER_PATH))) {
            checkInApp();
        } else {
            finish();
        }
    }

    private void saveData() {
        String string = this.mSp.getString(this, SP.FOLDER_NAME, Default.DEFAULT_FOLDER_PATH);
        this.mSp.setString(this, SP.FOLDER_NAME, this.mSelectedVale);
        if (!this.mSelectedVale.equals(string)) {
            pathDialog();
        } else {
            finish();
        }
    }

    private void checkInApp() {
        if (this.is_pro) {
            saveData();
            return;
        }
        if (!this.mSelectedVale.equals(Default.DEFAULT_FOLDER_PATH)) {
            String str = this.mSelectedVale;
            if (!str.equals("" + Default.PARENT_FOLDER_PATH + Default.SITE_1)) {
                String str2 = this.mSelectedVale;
                if (!str2.equals("" + Default.PARENT_FOLDER_PATH + Default.SITE_2)) {
                    createInAppDialog();
                    return;
                }
            }
        }
        saveData();
    }

    private void createInAppDialog() {
        if (!isFinishing()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(getString(R.string.add_folder_inapp_msg));
            builder.setPositiveButton(getString(R.string.pro), new DialogInterface.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FolderActivity.9
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (HelperClass.check_internet(FolderActivity.this)) {
                        FolderActivity.this.startActivity(new Intent(FolderActivity.this, InAppPurchaseActivity.class));
                    } else {
                        RelativeLayout relativeLayout = FolderActivity.this.mToolbar_back;
                        Snackbar.make(relativeLayout, "" + FolderActivity.this.getString(R.string.no_internet_msg), -Toast.LENGTH_LONG).show();
                    }
                    dialogInterface.dismiss();
                }
            });
            builder.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FolderActivity.10
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            builder.create().show();
        }
    }

    void pathDialog() {
        if (!isFinishing()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getString(R.string.folder_path));
            builder.setMessage(this.mSelectedVale);
            builder.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FolderActivity.11
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    FolderActivity.this.finish();
                }
            });
            final AlertDialog create = builder.create();
            create.setOnShowListener(new DialogInterface.OnShowListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FolderActivity.12
                @Override // android.content.DialogInterface.OnShowListener
                public void onShow(DialogInterface dialogInterface) {
                    create.getButton(-1).setTextColor(FolderActivity.this.getResources().getColor(R.color._3d3d3d));
                }
            });
            create.show();
        }
    }
}
