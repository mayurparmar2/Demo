package com.gpsvideocamera.videotimestamp.colorselector;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentTransaction;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.core.view.ViewCompat;

import com.demo.example.R;
public class CustomColorPickerDialog extends DialogFragment {
    public static Context context;
    public static OnAmbilWarnaListener listener;
    private static int supportsAlpha;
    int Newcolor;
    int alpha;
    TextView btn_cancle;
    TextView btn_ok;
    int color;
    float[] currentColorHsv = new float[3];
    AlertDialog dialog;
    EditText editTextColorcode;
    FrameLayout frm_lay_alpha;
    RelativeLayout lay_alpha;
    int position;
    SeekBar seekBarCursor;
    ImageView viewAlphaCheckered;
    ImageView viewAlphaCursor;
    View viewAlphaOverlay;
    ViewGroup viewContainer;
    ImageView viewCursor;
    View viewHue;
    View viewNewColor;
    View viewOldColor;
    ColorSelectorSquare viewSatVal;
    ImageView viewTarget;

    
    public interface OnAmbilWarnaListener {
        void onCancel(CustomColorPickerDialog customColorPickerDialog);

        void onOk(CustomColorPickerDialog customColorPickerDialog, int i, int i2);
    }

    public static CustomColorPickerDialog newInstance(Context context2, int i, int i2, int i3, OnAmbilWarnaListener onAmbilWarnaListener) {
        listener = onAmbilWarnaListener;
        context = context2;
        Bundle bundle = new Bundle();
        bundle.putInt("supportsAlpha", i3);
        bundle.putInt("color", i2);
        bundle.putInt("position", i);
        CustomColorPickerDialog customColorPickerDialog = new CustomColorPickerDialog();
        customColorPickerDialog.setArguments(bundle);
        return customColorPickerDialog;
    }

    public static String addAlpha(String str, double d) {
        String hexString = Long.toHexString(Math.round(d * 255.0d) / 100);
        if (hexString.length() == 1) {
            hexString = "0" + hexString;
        }
        return str.replace("#", "" + hexString.toUpperCase());
    }

    @Override 
    public Dialog onCreateDialog(Bundle bundle) {
        int i = getArguments().getInt("color");
        this.color = i;
        this.Newcolor = i;
        supportsAlpha = getArguments().getInt("supportsAlpha");
        this.position = getArguments().getInt("position");
        final View inflate = LayoutInflater.from(context).inflate(R.layout.custom_color_picker_dialog, (ViewGroup) null);
        this.viewHue = inflate.findViewById(R.id.ambilwarna_viewHue);
        this.viewSatVal = (ColorSelectorSquare) inflate.findViewById(R.id.ambilwarna_viewSatBri);
        this.viewCursor = (ImageView) inflate.findViewById(R.id.ambilwarna_cursor);
        this.viewOldColor = inflate.findViewById(R.id.ambilwarna_oldColor);
        this.viewNewColor = inflate.findViewById(R.id.ambilwarna_newColor);
        this.viewTarget = (ImageView) inflate.findViewById(R.id.ambilwarna_target);
        this.viewContainer = (ViewGroup) inflate.findViewById(R.id.ambilwarna_viewContainer);
        this.viewAlphaOverlay = inflate.findViewById(R.id.ambilwarna_overlay);
        this.viewAlphaCursor = (ImageView) inflate.findViewById(R.id.ambilwarna_alphaCursor);
        this.viewAlphaCheckered = (ImageView) inflate.findViewById(R.id.ambilwarna_alphaCheckered);
        this.lay_alpha = (RelativeLayout) inflate.findViewById(R.id.lay_alpha);
        this.btn_ok = (TextView) inflate.findViewById(R.id.btn_ok);
        this.btn_cancle = (TextView) inflate.findViewById(R.id.btn_cancel);
        FrameLayout frameLayout = (FrameLayout) inflate.findViewById(R.id.frm_lay_alpha);
        this.frm_lay_alpha = frameLayout;
        if (this.position == 0) {
            frameLayout.setVisibility(View.VISIBLE);
        } else {
            frameLayout.setVisibility(View.GONE);
        }
        this.seekBarCursor = (SeekBar) inflate.findViewById(R.id.seekbar_cursor);
        this.editTextColorcode = (EditText) inflate.findViewById(R.id.edittext_colorcode);
        this.seekBarCursor.setProgress(supportsAlpha);
        this.viewAlphaOverlay.setVisibility(View.VISIBLE);
        this.viewAlphaCursor.setVisibility(android.view.View.GONE);
        this.viewAlphaCheckered.setVisibility(View.VISIBLE);
        Color.colorToHSV(this.Newcolor, this.currentColorHsv);
        this.viewSatVal.setHue(getHue());
        String addAlpha = addAlpha(String.format("#%06X", Integer.valueOf(16777215 & this.Newcolor)), (double) (100 - this.seekBarCursor.getProgress()));
        this.editTextColorcode.setText(addAlpha);
        this.Newcolor = Color.parseColor("#" + addAlpha);
        customDrawable(getActivity(), this.viewNewColor, this.Newcolor, true);
        customDrawable(getActivity(), this.viewOldColor, this.color, false);
        this.seekBarCursor.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int i2, boolean z) {
                CustomColorPickerDialog customColorPickerDialog = CustomColorPickerDialog.this;
                customColorPickerDialog.Newcolor = customColorPickerDialog.getColor();
                String addAlpha2 = CustomColorPickerDialog.addAlpha(String.format("#%06X", Integer.valueOf(CustomColorPickerDialog.this.Newcolor & ViewCompat.MEASURED_SIZE_MASK)), (double) (100 - i2));
                CustomColorPickerDialog.this.editTextColorcode.setText(addAlpha2);
                CustomColorPickerDialog customColorPickerDialog2 = CustomColorPickerDialog.this;
                customColorPickerDialog2.Newcolor = Color.parseColor("#" + addAlpha2);
                CustomColorPickerDialog customColorPickerDialog3 = CustomColorPickerDialog.this;
                customColorPickerDialog3.customDrawable(customColorPickerDialog3.getActivity(), CustomColorPickerDialog.this.viewNewColor, CustomColorPickerDialog.this.Newcolor, true);
            }
        });
        this.viewHue.setOnTouchListener(new View.OnTouchListener() {
            @Override 
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() != 2 && motionEvent.getAction() != 0 && motionEvent.getAction() != 1) {
                    return false;
                }
                float y = motionEvent.getY();
                float f = 0.0f;
                if (y < 0.0f) {
                    y = 0.0f;
                }
                if (y > ((float) CustomColorPickerDialog.this.viewHue.getMeasuredHeight())) {
                    y = ((float) CustomColorPickerDialog.this.viewHue.getMeasuredHeight()) - 0.001f;
                }
                float measuredHeight = 360.0f - ((360.0f / ((float) CustomColorPickerDialog.this.viewHue.getMeasuredHeight())) * y);
                if (measuredHeight != 360.0f) {
                    f = measuredHeight;
                }
                CustomColorPickerDialog.this.setHue(f);
                CustomColorPickerDialog.this.viewSatVal.setHue(CustomColorPickerDialog.this.getHue());
                CustomColorPickerDialog.this.moveCursor();
                CustomColorPickerDialog customColorPickerDialog = CustomColorPickerDialog.this;
                customColorPickerDialog.Newcolor = customColorPickerDialog.getColor();
                String addAlpha2 = CustomColorPickerDialog.addAlpha(String.format("#%06X", Integer.valueOf(16777215 & CustomColorPickerDialog.this.Newcolor)), (double) (100 - CustomColorPickerDialog.this.seekBarCursor.getProgress()));
                CustomColorPickerDialog.this.editTextColorcode.setText(addAlpha2);
                CustomColorPickerDialog customColorPickerDialog2 = CustomColorPickerDialog.this;
                customColorPickerDialog2.Newcolor = Color.parseColor("#" + addAlpha2);
                CustomColorPickerDialog customColorPickerDialog3 = CustomColorPickerDialog.this;
                customColorPickerDialog3.customDrawable(customColorPickerDialog3.getActivity(), CustomColorPickerDialog.this.viewNewColor, CustomColorPickerDialog.this.Newcolor, true);
                CustomColorPickerDialog.this.updateAlphaView();
                return true;
            }
        });
        this.viewAlphaCheckered.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() != 2 && motionEvent.getAction() != 0 && motionEvent.getAction() != 1) {
                    return false;
                }
                float y = motionEvent.getY();
                if (y < 0.0f) {
                    y = 0.0f;
                }
                if (y > ((float) CustomColorPickerDialog.this.viewAlphaCheckered.getMeasuredHeight())) {
                    y = ((float) CustomColorPickerDialog.this.viewAlphaCheckered.getMeasuredHeight()) - 0.001f;
                }
                CustomColorPickerDialog.this.setAlpha(Math.round(255.0f - ((255.0f / ((float) CustomColorPickerDialog.this.viewAlphaCheckered.getMeasuredHeight())) * y)));
                CustomColorPickerDialog.this.moveAlphaCursorWidth();
                CustomColorPickerDialog.this.Newcolor = CustomColorPickerDialog.this.getColor() & ViewCompat.MEASURED_SIZE_MASK;
                CustomColorPickerDialog.this.viewSatVal.setHue(CustomColorPickerDialog.this.getHue());
                String addAlpha2 = CustomColorPickerDialog.addAlpha(String.format("#%06X", Integer.valueOf(CustomColorPickerDialog.this.Newcolor & ViewCompat.MEASURED_SIZE_MASK)), (double) (100 - CustomColorPickerDialog.this.seekBarCursor.getProgress()));
                CustomColorPickerDialog.this.editTextColorcode.setText(addAlpha2);
                CustomColorPickerDialog customColorPickerDialog = CustomColorPickerDialog.this;
                customColorPickerDialog.Newcolor = Color.parseColor("#" + addAlpha2);
                CustomColorPickerDialog customColorPickerDialog2 = CustomColorPickerDialog.this;
                customColorPickerDialog2.customDrawable(customColorPickerDialog2.getActivity(), CustomColorPickerDialog.this.viewNewColor, CustomColorPickerDialog.this.Newcolor, true);
                CustomColorPickerDialog.this.updateAlphaView();
                return true;
            }
        });
        this.viewSatVal.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() != 2 && motionEvent.getAction() != 0 && motionEvent.getAction() != 1) {
                    return false;
                }
                float x = motionEvent.getX();
                float y = motionEvent.getY();
                if (x < 0.0f) {
                    x = 0.0f;
                }
                if (x > ((float) CustomColorPickerDialog.this.viewSatVal.getMeasuredWidth())) {
                    x = (float) CustomColorPickerDialog.this.viewSatVal.getMeasuredWidth();
                }
                if (y < 0.0f) {
                    y = 0.0f;
                }
                if (y > ((float) CustomColorPickerDialog.this.viewSatVal.getMeasuredHeight())) {
                    y = (float) CustomColorPickerDialog.this.viewSatVal.getMeasuredHeight();
                }
                CustomColorPickerDialog customColorPickerDialog = CustomColorPickerDialog.this;
                customColorPickerDialog.setSat((1.0f / ((float) customColorPickerDialog.viewSatVal.getMeasuredWidth())) * x);
                CustomColorPickerDialog customColorPickerDialog2 = CustomColorPickerDialog.this;
                customColorPickerDialog2.setVal(1.0f - ((1.0f / ((float) customColorPickerDialog2.viewSatVal.getMeasuredHeight())) * y));
                CustomColorPickerDialog.this.viewSatVal.setHue(CustomColorPickerDialog.this.getHue());
                CustomColorPickerDialog.this.moveTarget();
                CustomColorPickerDialog customColorPickerDialog3 = CustomColorPickerDialog.this;
                customColorPickerDialog3.Newcolor = customColorPickerDialog3.getColor();
                String addAlpha2 = CustomColorPickerDialog.addAlpha(String.format("#%06X", Integer.valueOf(16777215 & CustomColorPickerDialog.this.Newcolor)), (double) (100 - CustomColorPickerDialog.this.seekBarCursor.getProgress()));
                CustomColorPickerDialog.this.editTextColorcode.setText(addAlpha2);
                CustomColorPickerDialog customColorPickerDialog4 = CustomColorPickerDialog.this;
                customColorPickerDialog4.Newcolor = Color.parseColor("#" + addAlpha2);
                CustomColorPickerDialog customColorPickerDialog5 = CustomColorPickerDialog.this;
                customColorPickerDialog5.customDrawable(customColorPickerDialog5.getActivity(), CustomColorPickerDialog.this.viewNewColor, CustomColorPickerDialog.this.Newcolor, true);
                CustomColorPickerDialog.this.updateAlphaView();
                return true;
            }
        });
        this.editTextColorcode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String obj = CustomColorPickerDialog.this.editTextColorcode.getText().toString();
                switch (obj.length()) {
                    case 0:
                        obj = obj + "FFFFFFFF";
                        break;
                    case 1:
                        obj = obj + "FFFFFFF";
                        break;
                    case 2:
                        obj = obj + "FFFFFF";
                        break;
                    case 3:
                        obj = obj + "FFFFF";
                        break;
                    case 4:
                        obj = obj + "FFFF";
                        break;
                    case 5:
                        obj = obj + "FFF";
                        break;
                    case 6:
                        obj = obj + "FF";
                        break;
                    case 7:
                        obj = obj + "F";
                        break;
                }
                String substring = obj.substring(2, obj.length());
                CustomColorPickerDialog.this.Newcolor = Color.parseColor("#" + substring);
                CustomColorPickerDialog customColorPickerDialog = CustomColorPickerDialog.this;
                customColorPickerDialog.customDrawable(customColorPickerDialog.getActivity(), CustomColorPickerDialog.this.viewNewColor, CustomColorPickerDialog.this.Newcolor, true);
                Color.colorToHSV(CustomColorPickerDialog.this.Newcolor, CustomColorPickerDialog.this.currentColorHsv);
                CustomColorPickerDialog customColorPickerDialog2 = CustomColorPickerDialog.this;
                customColorPickerDialog2.setHue(customColorPickerDialog2.currentColorHsv[0]);
                CustomColorPickerDialog.this.viewSatVal.setHue(CustomColorPickerDialog.this.getHue());
                CustomColorPickerDialog.this.moveCursor();
                CustomColorPickerDialog.this.moveAlphaCursorWidth();
                CustomColorPickerDialog.this.moveTarget();
                CustomColorPickerDialog.this.updateAlphaView();
                CustomColorPickerDialog.this.updateAlphaView();
            }
        });
        this.editTextColorcode.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean z) {
                if (z) {
                    CustomColorPickerDialog.this.dialog.getWindow().setSoftInputMode(32);
                }
            }
        });
        inflate.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                CustomColorPickerDialog.this.moveCursor();
                CustomColorPickerDialog.this.moveAlphaCursorWidth();
                CustomColorPickerDialog.this.moveTarget();
                CustomColorPickerDialog.this.updateAlphaView();
                inflate.getViewTreeObserver().removeGlobalOnLayoutListener(this);
            }
        });
        this.btn_cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (CustomColorPickerDialog.listener != null) {
                    CustomColorPickerDialog.listener.onCancel(CustomColorPickerDialog.this);
                }
            }
        });
        this.btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (CustomColorPickerDialog.listener != null) {
                    OnAmbilWarnaListener onAmbilWarnaListener = CustomColorPickerDialog.listener;
                    CustomColorPickerDialog customColorPickerDialog = CustomColorPickerDialog.this;
                    onAmbilWarnaListener.onOk(customColorPickerDialog, customColorPickerDialog.Newcolor, CustomColorPickerDialog.this.seekBarCursor.getProgress());
                }
            }
        });
        AlertDialog create = new AlertDialog.Builder(context).create();
        this.dialog = create;
        create.setView(inflate, 0, 0, 0, 0);
        return this.dialog;
    }

    
    public void customDrawable(Activity activity, View view, int i, boolean z) {
        ShapeDrawable shapeDrawable = new ShapeDrawable();
        float[] fArr = new float[8];
        if (z) {
            fArr[2] = activity.getResources().getDimension(R.dimen.corners);
            fArr[3] = activity.getResources().getDimension(R.dimen.corners);
            fArr[4] = activity.getResources().getDimension(R.dimen.corners);
            fArr[5] = activity.getResources().getDimension(R.dimen.corners);
        } else {
            fArr[0] = activity.getResources().getDimension(R.dimen.corners);
            fArr[1] = activity.getResources().getDimension(R.dimen.corners);
            fArr[6] = activity.getResources().getDimension(R.dimen.corners);
            fArr[7] = activity.getResources().getDimension(R.dimen.corners);
        }
        shapeDrawable.setShape(new RoundRectShape(fArr, null, fArr));
        shapeDrawable.getPaint().setColor(i);
        view.setBackgroundDrawable(shapeDrawable);
    }

    @Override
    public int show(FragmentTransaction fragmentTransaction, String str) {
        return super.show(fragmentTransaction, str);
    }

    protected void moveCursor() {
        float measuredHeight = ((float) this.viewHue.getMeasuredHeight()) - ((getHue() * ((float) this.viewHue.getMeasuredHeight())) / 360.0f);
        if (measuredHeight == ((float) this.viewHue.getMeasuredHeight())) {
            measuredHeight = 0.0f;
        }
        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.viewCursor.getLayoutParams();
        layoutParams.leftMargin = (int) ((((double) this.viewHue.getLeft()) - Math.floor((double) (this.viewCursor.getMeasuredWidth() / 2))) - ((double) this.viewContainer.getPaddingLeft()));
        layoutParams.topMargin = (int) ((((double) (((float) this.viewHue.getTop()) + measuredHeight)) - Math.floor((double) (this.viewCursor.getMeasuredHeight() / 2))) - ((double) this.viewContainer.getPaddingTop()));
        this.viewCursor.setLayoutParams(layoutParams);
    }

    protected void moveTarget() {
        float sat = getSat() * ((float) this.viewSatVal.getMeasuredWidth());
        float val = (1.0f - getVal()) * ((float) this.viewSatVal.getMeasuredHeight());
        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.viewTarget.getLayoutParams();
        layoutParams.leftMargin = (int) ((((double) (((float) this.viewSatVal.getLeft()) + sat)) - Math.floor((double) (this.viewTarget.getMeasuredWidth() / 2))) - ((double) this.viewContainer.getPaddingLeft()));
        layoutParams.topMargin = (int) ((((double) (((float) this.viewSatVal.getTop()) + val)) - Math.floor((double) (this.viewTarget.getMeasuredHeight() / 2))) - ((double) this.viewContainer.getPaddingTop()));
        this.viewTarget.setLayoutParams(layoutParams);
    }

    protected void moveAlphaCursorWidth() {
        float measuredWidth = (float) this.lay_alpha.getMeasuredWidth();
        float alpha = measuredWidth - ((getAlpha() * measuredWidth) / 255.0f);
        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.viewAlphaCursor.getLayoutParams();
        layoutParams.leftMargin = (int) ((((double) (((float) this.lay_alpha.getLeft()) + alpha)) - Math.floor((double) (this.viewAlphaCursor.getMeasuredWidth() / 2))) - ((double) this.viewContainer.getPaddingLeft()));
        layoutParams.topMargin = (int) ((((double) (((float) this.lay_alpha.getTop()) + alpha)) - Math.floor((double) (this.viewAlphaCursor.getMeasuredHeight() / 2))) - ((double) this.viewContainer.getPaddingTop()));
        this.viewAlphaCursor.setLayoutParams(layoutParams);
    }

    
    public int getColor() {
        return Color.HSVToColor(this.currentColorHsv) & ViewCompat.MEASURED_SIZE_MASK;
    }

    
    public float getHue() {
        return this.currentColorHsv[0];
    }

    private float getAlpha() {
        return (float) this.alpha;
    }

    private float getSat() {
        return this.currentColorHsv[1];
    }

    private float getVal() {
        return this.currentColorHsv[2];
    }

    
    public void setHue(float f) {
        this.currentColorHsv[0] = f;
    }

    
    public void setSat(float f) {
        this.currentColorHsv[1] = f;
    }

    
    public void setAlpha(int i) {
        this.alpha = i;
    }

    
    public void setVal(float f) {
        this.currentColorHsv[2] = f;
    }

    @Override
    public AlertDialog getDialog() {
        return this.dialog;
    }

    
    public void updateAlphaView() {
        this.viewAlphaOverlay.setBackgroundDrawable(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{Color.HSVToColor(this.currentColorHsv), 0}));
    }
}
