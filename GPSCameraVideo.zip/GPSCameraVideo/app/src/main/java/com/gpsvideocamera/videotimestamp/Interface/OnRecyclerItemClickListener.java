package com.gpsvideocamera.videotimestamp.Interface;

import android.view.View;


public interface OnRecyclerItemClickListener {
    void OnClick_(int i, View view);

    void OnLongClick_(int i, View view);
}
