package com.gpsvideocamera.videotimestamp.Dragview;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewTreeObserver;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import androidx.core.content.ContextCompat;
import androidx.core.view.MotionEventCompat;
import com.demo.example.R;


public class DragLinearLayout extends LinearLayout {
    private static final int DEFAULT_SCROLL_SENSITIVE_AREA_HEIGHT_DP = 48;
    private static final int INVALID_POINTER_ID = -1;
    private static final String LOG_TAG = "DragLinearLayout";
    private static final int MAX_DRAG_SCROLL_SPEED = 16;
    private static final long MAX_SWITCH_DURATION = 300;
    private static final long MIN_SWITCH_DURATION = 150;
    private static final float NOMINAL_DISTANCE = 20.0f;
    private static final long NOMINAL_SWITCH_DURATION = 150;
    private int activePointerId;
    private ScrollView containerScrollView;
    private int downY;
    private final Drawable dragBottomShadowDrawable;
    private final int dragShadowHeight;
    private final Drawable dragTopShadowDrawable;
    private Runnable dragUpdater;
    private final SparseArray<DraggableChild> draggableChildren;
    private final DragItem draggedItem;
    private final float nominalDistanceScaled;
    private int scrollSensitiveAreaHeight;
    private final int slop;
    private OnViewSwapListener swapListener;

    
    public interface OnViewSwapListener {
        void onSwap(View view, int i, View view2, int i2);
    }

    
    
    public class DraggableChild {
        private ValueAnimator swapAnimation;

        private DraggableChild() {
        }

        public void endExistingAnimation() {
            ValueAnimator valueAnimator = this.swapAnimation;
            if (valueAnimator != null) {
                valueAnimator.end();
            }
        }

        public void cancelExistingAnimation() {
            ValueAnimator valueAnimator = this.swapAnimation;
            if (valueAnimator != null) {
                valueAnimator.cancel();
            }
        }
    }

    
    
    public class DragItem {
        private boolean detecting;
        private boolean dragging;
        private int height;
        private int position;
        private ValueAnimator settleAnimation;
        private int startTop;
        private int startVisibility;
        private int targetTopOffset;
        private int totalDragOffset;
        private View view;
        private BitmapDrawable viewDrawable;

        public DragItem() {
            stopDetecting();
        }

        public void startDetectingOnPossibleDrag(View view, int i) {
            this.view = view;
            this.startVisibility = view.getVisibility();
            this.viewDrawable = DragLinearLayout.this.getDragDrawable(view);
            this.position = i;
            this.startTop = view.getTop();
            this.height = view.getHeight();
            this.totalDragOffset = 0;
            this.targetTopOffset = 0;
            this.settleAnimation = null;
            this.detecting = true;
        }

        public void onDragStart() {
            this.view.setVisibility(View.INVISIBLE);
            this.dragging = true;
        }

        public void setTotalOffset(int i) {
            this.totalDragOffset = i;
            updateTargetTop();
        }

        public void updateTargetTop() {
            this.targetTopOffset = (this.startTop - this.view.getTop()) + this.totalDragOffset;
        }

        public void onDragStop() {
            this.dragging = false;
        }

        public boolean settling() {
            return this.settleAnimation != null;
        }

        public void stopDetecting() {
            this.detecting = false;
            View view = this.view;
            if (view != null) {
                view.setVisibility(this.startVisibility);
            }
            this.view = null;
            this.startVisibility = -1;
            this.viewDrawable = null;
            this.position = -1;
            this.startTop = -1;
            this.height = -1;
            this.totalDragOffset = 0;
            this.targetTopOffset = 0;
            ValueAnimator valueAnimator = this.settleAnimation;
            if (valueAnimator != null) {
                valueAnimator.end();
            }
            this.settleAnimation = null;
        }
    }

    public DragLinearLayout(Context context) {
        this(context, null);
    }

    
    @SuppressLint("ResourceType")
    public DragLinearLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.downY = -1;
        this.activePointerId = -1;
        setOrientation(LinearLayout.VERTICAL);
        this.draggableChildren = new SparseArray<>();
        this.draggedItem = new DragItem();
        this.slop = ViewConfiguration.get(context).getScaledTouchSlop();
        Resources resources = getResources();
        this.dragTopShadowDrawable = ContextCompat.getDrawable(context, R.drawable.ab_solid_shadow_holo_flipped);
        this.dragBottomShadowDrawable = ContextCompat.getDrawable(context, R.drawable.ab_solid_shadow_holo);
        this.dragShadowHeight = resources.getDimensionPixelSize(R.dimen._16dp);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(attributeSet, R.styleable.DragLinearLayout, 0, 0);
        try {
            this.scrollSensitiveAreaHeight = obtainStyledAttributes.getDimensionPixelSize(1, (int) ((resources.getDisplayMetrics().density * 48.0f) + 0.5f));
            obtainStyledAttributes.recycle();
            this.nominalDistanceScaled = (float) ((int) ((resources.getDisplayMetrics().density * NOMINAL_DISTANCE) + 0.5f));
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    @Override 
    public void setOrientation(int i) {
        if (i != 0) {
            super.setOrientation(i);
            return;
        }
        throw new IllegalArgumentException("DragLinearLayout must be VERTICAL.");
    }

    public void addDragView(View view, View view2) {
        addView(view);
        setViewDraggable(view, view2);
    }

    public void addDragView(View view, View view2, int i) {
        addView(view, i);
        for (int size = this.draggableChildren.size() - 1; size >= 0; size--) {
            int keyAt = this.draggableChildren.keyAt(size);
            if (keyAt >= i) {
                SparseArray<DraggableChild> sparseArray = this.draggableChildren;
                sparseArray.put(keyAt + 1, sparseArray.get(keyAt));
            }
        }
        setViewDraggable(view, view2);
    }

    public void setViewDraggable(View view, View view2) {
        if (this == view.getParent()) {
            view2.setOnTouchListener(new DragHandleOnTouchListener(view));
            this.draggableChildren.put(indexOfChild(view), new DraggableChild());
        }
    }

    public void removeDragView(View view) {
        if (this == view.getParent()) {
            int indexOfChild = indexOfChild(view);
            removeView(view);
            int size = this.draggableChildren.size();
            for (int i = 0; i < size; i++) {
                int keyAt = this.draggableChildren.keyAt(i);
                if (keyAt >= indexOfChild) {
                    DraggableChild draggableChild = this.draggableChildren.get(keyAt + 1);
                    if (draggableChild == null) {
                        this.draggableChildren.delete(keyAt);
                    } else {
                        this.draggableChildren.put(keyAt, draggableChild);
                    }
                }
            }
        }
    }

    public void setContainerScrollView(ScrollView scrollView) {
        this.containerScrollView = scrollView;
    }

    public void setScrollSensitiveHeight(int i) {
        this.scrollSensitiveAreaHeight = i;
    }

    public int getScrollSensitiveHeight() {
        return this.scrollSensitiveAreaHeight;
    }

    public void setOnViewSwapListener(OnViewSwapListener onViewSwapListener) {
        this.swapListener = onViewSwapListener;
    }

    
    public long getTranslateAnimationDuration(float f) {
        return Math.min((long) MAX_SWITCH_DURATION, Math.max(150L, (long) ((Math.abs(f) * 150.0f) / this.nominalDistanceScaled)));
    }

    
    public void startDetectingDrag(View view) {
        if (!this.draggedItem.detecting) {
            int indexOfChild = indexOfChild(view);
            this.draggableChildren.get(indexOfChild).endExistingAnimation();
            this.draggedItem.startDetectingOnPossibleDrag(view, indexOfChild);
        }
    }

    private void startDrag() {
        this.draggedItem.onDragStart();
        requestDisallowInterceptTouchEvent(true);
    }

    
    public void onDragStop() {
        DragItem dragItem = this.draggedItem;
        dragItem.settleAnimation = ValueAnimator.ofFloat((float) dragItem.totalDragOffset, (float) (this.draggedItem.totalDragOffset - this.draggedItem.targetTopOffset)).setDuration(getTranslateAnimationDuration((float) this.draggedItem.targetTopOffset));
        this.draggedItem.settleAnimation.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { 
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                if (DragLinearLayout.this.draggedItem.detecting) {
                    DragLinearLayout.this.draggedItem.setTotalOffset(((Float) valueAnimator.getAnimatedValue()).intValue());
                    int animatedFraction = (int) ((1.0f - valueAnimator.getAnimatedFraction()) * 255.0f);
                    if (DragLinearLayout.this.dragTopShadowDrawable != null) {
                        DragLinearLayout.this.dragTopShadowDrawable.setAlpha(animatedFraction);
                    }
                    DragLinearLayout.this.dragBottomShadowDrawable.setAlpha(animatedFraction);
                    DragLinearLayout.this.invalidate();
                }
            }
        });
        this.draggedItem.settleAnimation.addListener(new AnimatorListenerAdapter() { // from class: com.gpsvideocamera.videotimestamp.Dragview.DragLinearLayout.2
            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public void onAnimationStart(Animator animator) {
                DragLinearLayout.this.draggedItem.onDragStop();
            }

            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public void onAnimationEnd(Animator animator) {
                if (DragLinearLayout.this.draggedItem.detecting) {
                    DragLinearLayout.this.draggedItem.settleAnimation = null;
                    DragLinearLayout.this.draggedItem.stopDetecting();
                    if (DragLinearLayout.this.dragTopShadowDrawable != null) {
                        DragLinearLayout.this.dragTopShadowDrawable.setAlpha(255);
                    }
                    DragLinearLayout.this.dragBottomShadowDrawable.setAlpha(255);
                }
            }
        });
        this.draggedItem.settleAnimation.start();
    }

    
    public void onDrag(int i) {
        this.draggedItem.setTotalOffset(i);
        invalidate();
        int i2 = this.draggedItem.startTop + this.draggedItem.totalDragOffset;
        handleContainerScroll(i2);
        int nextDraggablePosition = nextDraggablePosition(this.draggedItem.position);
        int previousDraggablePosition = previousDraggablePosition(this.draggedItem.position);
        View childAt = getChildAt(nextDraggablePosition);
        View childAt2 = getChildAt(previousDraggablePosition);
        boolean z = false;
        boolean z2 = childAt != null && this.draggedItem.height + i2 > childAt.getTop() + (childAt.getHeight() / 2);
        if (childAt2 != null && i2 < childAt2.getTop() + (childAt2.getHeight() / 2)) {
            z = true;
        }
        if (z2 || z) {
            final View view = z2 ? childAt : childAt2;
            final int i3 = this.draggedItem.position;
            if (!z2) {
                nextDraggablePosition = previousDraggablePosition;
            }
            this.draggableChildren.get(nextDraggablePosition).cancelExistingAnimation();
            final float y = view.getY();
            OnViewSwapListener onViewSwapListener = this.swapListener;
            if (onViewSwapListener != null) {
                onViewSwapListener.onSwap(this.draggedItem.view, this.draggedItem.position, view, nextDraggablePosition);
            }
            if (z2) {
                removeViewAt(i3);
                removeViewAt(nextDraggablePosition - 1);
                addView(childAt, i3);
                addView(this.draggedItem.view, nextDraggablePosition);
            } else {
                removeViewAt(nextDraggablePosition);
                removeViewAt(i3 - 1);
                addView(this.draggedItem.view, nextDraggablePosition);
                addView(childAt2, i3);
            }
            this.draggedItem.position = nextDraggablePosition;
            final ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
            viewTreeObserver.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() { // from class: com.gpsvideocamera.videotimestamp.Dragview.DragLinearLayout.3
                @Override // android.view.ViewTreeObserver.OnPreDrawListener
                public boolean onPreDraw() {
                    viewTreeObserver.removeOnPreDrawListener(this);
                    View view2 = view;
                    final ObjectAnimator duration = ObjectAnimator.ofFloat(view2, "y", y, (float) view2.getTop()).setDuration(DragLinearLayout.this.getTranslateAnimationDuration(((float) view.getTop()) - y));
                    duration.addListener(new AnimatorListenerAdapter() { // from class: com.gpsvideocamera.videotimestamp.Dragview.DragLinearLayout.3.1
                        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
                        public void onAnimationStart(Animator animator) {
                            ((DraggableChild) DragLinearLayout.this.draggableChildren.get(i3)).swapAnimation = duration;
                        }

                        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
                        public void onAnimationEnd(Animator animator) {
                            ((DraggableChild) DragLinearLayout.this.draggableChildren.get(i3)).swapAnimation = null;
                        }
                    });
                    duration.start();
                    return true;
                }
            });
            final ViewTreeObserver viewTreeObserver2 = this.draggedItem.view.getViewTreeObserver();
            viewTreeObserver2.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() { // from class: com.gpsvideocamera.videotimestamp.Dragview.DragLinearLayout.4
                @Override // android.view.ViewTreeObserver.OnPreDrawListener
                public boolean onPreDraw() {
                    viewTreeObserver2.removeOnPreDrawListener(this);
                    DragLinearLayout.this.draggedItem.updateTargetTop();
                    if (!DragLinearLayout.this.draggedItem.settling()) {
                        return true;
                    }
                    Log.d(DragLinearLayout.LOG_TAG, "Updating settle animation");
                    DragLinearLayout.this.draggedItem.settleAnimation.removeAllListeners();
                    DragLinearLayout.this.draggedItem.settleAnimation.cancel();
                    DragLinearLayout.this.onDragStop();
                    return true;
                }
            });
        }
    }

    private int previousDraggablePosition(int i) {
        int indexOfKey = this.draggableChildren.indexOfKey(i);
        if (indexOfKey < 1 || indexOfKey > this.draggableChildren.size()) {
            return -1;
        }
        return this.draggableChildren.keyAt(indexOfKey - 1);
    }

    private int nextDraggablePosition(int i) {
        int indexOfKey = this.draggableChildren.indexOfKey(i);
        if (indexOfKey < -1 || indexOfKey > this.draggableChildren.size() - 2) {
            return -1;
        }
        return this.draggableChildren.keyAt(indexOfKey + 1);
    }

    private void handleContainerScroll(int i) {
        final int i2;
        ScrollView scrollView = this.containerScrollView;
        if (scrollView != null) {
            final int scrollY = scrollView.getScrollY();
            int top = (getTop() - scrollY) + i;
            int height = this.containerScrollView.getHeight();
            int i3 = this.scrollSensitiveAreaHeight;
            if (top < i3) {
                i2 = (int) (smootherStep((float) i3, 0.0f, (float) top) * -16.0f);
            } else {
                i2 = top > height - i3 ? (int) (smootherStep((float) (height - i3), (float) height, (float) top) * 16.0f) : 0;
            }
            this.containerScrollView.removeCallbacks(this.dragUpdater);
            this.containerScrollView.smoothScrollBy(0, i2);
            Runnable r1 = new Runnable() { // from class: com.gpsvideocamera.videotimestamp.Dragview.DragLinearLayout.5
                @Override // java.lang.Runnable
                public void run() {
                    if (DragLinearLayout.this.draggedItem.dragging && scrollY != DragLinearLayout.this.containerScrollView.getScrollY()) {
                        DragLinearLayout dragLinearLayout = DragLinearLayout.this;
                        dragLinearLayout.onDrag(dragLinearLayout.draggedItem.totalDragOffset + i2);
                    }
                }
            };
            this.dragUpdater = r1;
            this.containerScrollView.post(r1);
        }
    }

    private static float smootherStep(float f, float f2, float f3) {
        float max = Math.max(0.0f, Math.min((f3 - f) / (f2 - f), 1.0f));
        return max * max * max * ((max * ((6.0f * max) - 15.0f)) + 10.0f);
    }

    @Override // android.view.View, android.view.ViewGroup
    protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);
        if (!this.draggedItem.detecting) {
            return;
        }
        if (this.draggedItem.dragging || this.draggedItem.settling()) {
            canvas.save();
            canvas.translate(0.0f, (float) this.draggedItem.totalDragOffset);
            this.draggedItem.viewDrawable.draw(canvas);
            int i = this.draggedItem.viewDrawable.getBounds().left;
            int i2 = this.draggedItem.viewDrawable.getBounds().right;
            int i3 = this.draggedItem.viewDrawable.getBounds().top;
            int i4 = this.draggedItem.viewDrawable.getBounds().bottom;
            this.dragBottomShadowDrawable.setBounds(i, i4, i2, this.dragShadowHeight + i4);
            this.dragBottomShadowDrawable.draw(canvas);
            Drawable drawable = this.dragTopShadowDrawable;
            if (drawable != null) {
                drawable.setBounds(i, i3 - this.dragShadowHeight, i2, i3);
                this.dragTopShadowDrawable.draw(canvas);
            }
            canvas.restore();
        }
    }

    
    @Override // android.view.ViewGroup
    
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int i;
        int actionMasked = MotionEventCompat.getActionMasked(motionEvent);
        if (actionMasked != 0) {
            if (actionMasked != 1) {
                if (actionMasked != 2) {
                    if (actionMasked != 3) {
                        if (actionMasked == 6) {
                        }
                    }
                } else if (!this.draggedItem.detecting || -1 == (i = this.activePointerId) || Math.abs(MotionEventCompat.getY(motionEvent, motionEvent.findPointerIndex(i)) - ((float) this.downY)) <= ((float) this.slop)) {
                    return false;
                } else {
                    startDrag();
                    return true;
                }
            }
            onTouchEnd();
            if (this.draggedItem.detecting) {
                this.draggedItem.stopDetecting();
            }
        } else if (this.draggedItem.detecting) {
            return false;
        } else {
            this.downY = (int) MotionEventCompat.getY(motionEvent, 0);
            this.activePointerId = MotionEventCompat.getPointerId(motionEvent, 0);
        }
        return false;
    }

    
    @Override // android.view.View
    
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int i;
        int actionMasked = MotionEventCompat.getActionMasked(motionEvent);
        if (actionMasked != 0) {
            if (actionMasked != 1) {
                if (actionMasked != 2) {
                    if (actionMasked != 3) {
                        if (actionMasked == 6) {
                        }
                    }
                } else if (this.draggedItem.dragging && -1 != (i = this.activePointerId)) {
                    onDrag(((int) MotionEventCompat.getY(motionEvent, motionEvent.findPointerIndex(i))) - this.downY);
                    return true;
                }
                return false;
            }
            onTouchEnd();
            if (this.draggedItem.dragging) {
                onDragStop();
            } else if (this.draggedItem.detecting) {
                this.draggedItem.stopDetecting();
            }
            return true;
        } else if (!this.draggedItem.detecting || this.draggedItem.settling()) {
            return false;
        } else {
            startDrag();
            return true;
        }
    }

    private void onTouchEnd() {
        this.downY = -1;
        this.activePointerId = -1;
    }

    
    
    public class DragHandleOnTouchListener implements View.OnTouchListener {
        private final View view;

        public DragHandleOnTouchListener(View view) {
            this.view = view;
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (MotionEventCompat.getActionMasked(motionEvent) != 0) {
                return false;
            }
            DragLinearLayout.this.startDetectingDrag(this.view);
            return false;
        }
    }

    
    public BitmapDrawable getDragDrawable(View view) {
        int top = view.getTop();
        int left = view.getLeft();
        BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), getBitmapFromView(view));
        bitmapDrawable.setBounds(new Rect(left, top, view.getWidth() + left, view.getHeight() + top));
        return bitmapDrawable;
    }

    private static Bitmap getBitmapFromView(View view) {
        Bitmap createBitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        view.draw(new Canvas(createBitmap));
        return createBitmap;
    }
}
