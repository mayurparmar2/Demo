package com.gpsvideocamera.videotimestamp.Fragment;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.gpsvideocamera.videotimestamp.Adapter.DateTimeAdapter;
import com.gpsvideocamera.videotimestamp.Interface.OnRecyclerItemClickListener;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.SP;


public class DateTimeFragment extends Fragment {
    OnDateSelectedListener callBack;
    private DateTimeAdapter mAdapter;
    String[] mDateArray;
    private RecyclerView mRecyclerview;
    private SP mSP;

    
    
    public interface OnDateSelectedListener {
        void onDateSelected();
    }

    public void setOnDate_SelectedListener(OnDateSelectedListener onDateSelectedListener) {
        this.callBack = onDateSelectedListener;
    }

    @Override 
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_template, viewGroup, false);
    }

    @Override 
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        init(view);
    }

    private void init(View view) {
        this.mSP = new SP(getContext());
        this.mRecyclerview = (RecyclerView) view.findViewById(R.id.fragment_recyclerview);
        this.mDateArray = getResources().getStringArray(R.array.datetime_format_arry);
        setAdapter();
    }

    private void setAdapter() {
        this.mRecyclerview.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        this.mRecyclerview.setHasFixedSize(true);
        DateTimeAdapter dateTimeAdapter = new DateTimeAdapter(getContext(), this.mDateArray, new OnRecyclerItemClickListener() { 
            @Override 
            public void OnLongClick_(int i, View view) {
            }

            @Override 
            public void OnClick_(int i, View view) {
                final String str = DateTimeFragment.this.mDateArray[i];
                DateTimeFragment.this.mSP.setString(DateTimeFragment.this.getContext(), "date_format_temp", str);
                new Handler().postDelayed(new Runnable() { 
                    @Override 
                    public void run() {
                        if (DateTimeFragment.this.mAdapter != null) {
                            DateTimeFragment.this.mAdapter.refAdapter(str);
                            if (DateTimeFragment.this.callBack != null) {
                                DateTimeFragment.this.callBack.onDateSelected();
                            }
                        }
                    }
                }, 50);
            }
        });
        this.mAdapter = dateTimeAdapter;
        this.mRecyclerview.setAdapter(dateTimeAdapter);
    }
}
