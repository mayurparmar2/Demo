package com.gpsvideocamera.videotimestamp.Fragment;

import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;

import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;
import com.gpsvideocamera.videotimestamp.Activity.CameraActivity;
import com.gpsvideocamera.videotimestamp.Compass.Compass;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.Default;
import com.gpsvideocamera.videotimestamp.Utils.HelperClass;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import java.util.Timer;
import java.util.TimerTask;


public class MainFragment extends Fragment implements View.OnClickListener, Template_Fragment.OnTemplateDataListener, DateTimeFragment.OnDateSelectedListener, ColorFragment.OnColorSelectedListener, GPS_Coordinates_Fragment.OnLatLngListener, TempratureFragment.OntTempratureListener, MapTypeFragment.OnMapTypeSelectedListener {
    private static final int TAB_COLOR = 3;
    private static final int TAB_DATE_TIME = 2;
    private static final int TAB_GPS_COORDINATES = 5;
    private static final int TAB_MAP_TYPE = 4;
    private static final int TAB_STAMP_POS = 1;
    private static final int TAB_TAMPLATE = 0;
    private static final int TAB_TEMPRATURE_UNIT = 6;
    int address_color;
    int background_color;
    private Compass compass;
    int compass_color;
    AlertDialog confirm_dialog;
    private float currentAzimuth;
    int date_time_color;
    ImageView imgCompass;
    ImageView imgMap;
    ImageView imgWeather;
    boolean isAddress;
    boolean isCompass;
    boolean isCompassFound;
    boolean isDateTime;
    boolean isLatLng;
    boolean isMagneticField;
    boolean isMap;
    boolean isWeather;
    int lat_lng_color;
    LinearLayout li_address;
    LinearLayout li_compass;
    LinearLayout li_magnetic_field;
    RelativeLayout li_main_stamp_lay;
    LinearLayout li_rightView;
    LinearLayout li_stamp;
    LinearLayout li_weather;
    Pager_Adapter mAdapter;
    String mDateFormat;
    HelperClass mHelperClass;
    int mIconValue;
    int mLatLngType;
    String mMap_Type;
    int mPos_mapType;
    private SP mSP;
    String mStamp_Pos;
    private TabLayout mTabLayout;
    String[] mTabTitleArray;
    private TimerTask mTimerTask_Date;
    private Timer mTimer_Date;
    private RelativeLayout mToolbar_back;
    private ViewPager mViewPager;
    TypedArray mWeatherIcon;
    int magnetic_field_color;
    float mfTemprature_value;
    String msTemprature_type;
    private TextView mtv_toolbar_title;
    TextView tv_address;
    TextView tv_address_line_1;
    TextView tv_compass;
    TextView tv_magnetic_field;
    TextView tv_weather;
    int weather_color;
    boolean isBack = false;
    private boolean compassFound = false;
    float bearing = 0.0f;
    private Handler mTimerHandler = new Handler();

    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override 
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_main, viewGroup, false);
    }

    @Override 
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        init(view);
        setupCompass();
        onCliks();
    }

    private void onCliks() {
        this.mToolbar_back.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view) {
                MainFragment.this.onClick(view);
            }
        });
    }

    @Override 
    public void onStart() {
        super.onStart();
    }

    @Override 
    public void onPause() {
        super.onPause();
        this.compass.stop();
        stopDateTimer();
    }

    @Override 
    public void onResume() {
        super.onResume();
        this.compass.start();
    }

    @Override 
    public void onStop() {
        super.onStop();
        this.compass.stop();
        stopDateTimer();
    }

    private void stopDateTimer() {
        Timer timer = this.mTimer_Date;
        if (timer != null) {
            timer.cancel();
            this.mTimer_Date.purge();
        }
    }

    private void setupCompass() {
        this.compass = new Compass(getContext());
        Compass.CompassListener r0 = new Compass.CompassListener() {
            @Override 
            public void onNewAzimuth(float f) {
                MainFragment.this.adjustArrow(f);
            }

            @Override 
            public void onMagField(float f) {
                MainFragment.this.MagField(f);
            }
        };
        this.compass.setListener(r0);
        Compass compass = this.compass;
        if (compass != null) {
            compass.setListener(r0);
            if (this.compass.getStatus()) {
                this.compassFound = true;
            }
        }
    }

    public void MagField(float f) {
        TextView textView = this.tv_magnetic_field;
        textView.setText(f + " μT");
    }

    public void adjustArrow(float f) {
        if (this.compass.getSensorData()) {
            float f2 = (this.bearing - f) * -1.0f;
            RotateAnimation rotateAnimation = new RotateAnimation(-this.currentAzimuth, -f2, 1, 0.5f, 1, 0.5f);
            this.currentAzimuth = f2;
            rotateAnimation.setDuration(500);
            rotateAnimation.setRepeatCount(0);
            rotateAnimation.setFillAfter(true);
            this.imgCompass.startAnimation(rotateAnimation);
            showDirection(f2);
        }
    }

    private void showDirection(float f) {
        String str = (f >= 338.0f || f < 23.0f) ? "N" : (f < 23.0f || f >= 68.0f) ? (f < 68.0f || f >= 113.0f) ? (f < 113.0f || f >= 158.0f) ? (f < 158.0f || f >= 203.0f) ? (f < 203.0f || f >= 248.0f) ? (f < 248.0f || f >= 293.0f) ? (f < 293.0f || f >= 338.0f) ? "" : "NW" : "W" : "SW" : "S" : "SE" : "E" : "NE";
        TextView textView = this.tv_compass;
        textView.setText(Math.round(f) + "° " + str);
    }

    private void init(View view) {
        this.mSP = new SP(getActivity());
        this.mWeatherIcon = getResources().obtainTypedArray(R.array.wI);
        this.mHelperClass = new HelperClass();
        this.mToolbar_back = (RelativeLayout) view.findViewById(R.id.toolbar_back);
        TextView textView = (TextView) view.findViewById(R.id.tv_toolbar_title);
        this.mtv_toolbar_title = textView;
        textView.setText(getString(R.string.stamp_template));
        this.mTabLayout = (TabLayout) view.findViewById(R.id.tabLay);
        this.mViewPager = (ViewPager) view.findViewById(R.id.pager);
        this.tv_address_line_1 = (TextView) view.findViewById(R.id.tv_address_line_1);
        this.tv_address = (TextView) view.findViewById(R.id.tv_address);
        this.tv_weather = (TextView) view.findViewById(R.id.tv_weather);
        this.tv_compass = (TextView) view.findViewById(R.id.tv_compass);
        this.tv_magnetic_field = (TextView) view.findViewById(R.id.tv_magnetic_field);
        this.imgMap = (ImageView) view.findViewById(R.id.imgMap);
        this.li_stamp = (LinearLayout) view.findViewById(R.id.li_stamp);
        this.li_compass = (LinearLayout) view.findViewById(R.id.li_compass);
        this.imgCompass = (ImageView) view.findViewById(R.id.imgCompass);
        this.imgWeather = (ImageView) view.findViewById(R.id.imgWeather);
        this.li_rightView = (LinearLayout) view.findViewById(R.id.li_rightView);
        this.li_magnetic_field = (LinearLayout) view.findViewById(R.id.li_magnetic_field);
        this.li_weather = (LinearLayout) view.findViewById(R.id.li_weather);
        this.li_main_stamp_lay = (RelativeLayout) view.findViewById(R.id.li_main_stamp_lay);
        this.li_address = (LinearLayout) view.findViewById(R.id.li_address);
        this.li_main_stamp_lay.setVisibility(View.VISIBLE);
        this.li_main_stamp_lay.setBackgroundColor(getResources().getColor(R.color.trans_white));
        this.background_color = this.mSP.getInteger(getActivity(), SP.BACKGROUND_COLOR, Color.parseColor("#9c000000")).intValue();
        this.address_color = this.mSP.getInteger(getActivity(), SP.ADDRESS_COLOR, -1).intValue();
        this.date_time_color = this.mSP.getInteger(getActivity(), SP.DATE_TIME_COLOR, -1).intValue();
        this.lat_lng_color = this.mSP.getInteger(getActivity(), SP.LAT_LNG_COLOR, -1).intValue();
        this.weather_color = this.mSP.getInteger(getActivity(), SP.WEATHER_COLOR, -1).intValue();
        this.magnetic_field_color = this.mSP.getInteger(getActivity(), SP.MAGNETIC_FIELD_COLOR, -1).intValue();
        this.compass_color = this.mSP.getInteger(getActivity(), SP.COMPASS_COLOR, -1).intValue();
        this.isMap = this.mSP.getBoolean(getActivity(), SP.IS_MAP, Default.IS_MAP).booleanValue();
        this.isAddress = this.mSP.getBoolean(getActivity(), SP.IS_ADDRESS, Default.IS_ADDRESS).booleanValue();
        this.isLatLng = this.mSP.getBoolean(getActivity(), SP.IS_LAT_LNG_TEMPLATE, Default.IS_LAT_LNG_TEMPLATE).booleanValue();
        this.isWeather = this.mSP.getBoolean(getActivity(), SP.IS_WEATHER, Default.IS_WEATHER).booleanValue();
        this.isDateTime = this.mSP.getBoolean(getActivity(), SP.IS_DATE_TIME, Default.IS_DATE_TIME).booleanValue();
        this.isMagneticField = this.mSP.getBoolean(getActivity(), SP.IS_MAGNETIC_FIELD, Default.IS_MAGNETIC_FIELD).booleanValue();
        this.isCompass = this.mSP.getBoolean(getActivity(), SP.IS_COMPASS, Default.IS_COMPASS).booleanValue();
        this.isCompassFound = this.mSP.getBoolean(getActivity(), SP.COMPASS_FOUND, false).booleanValue();
        this.mDateFormat = this.mSP.getString(getActivity(), SP.DATE_FORMAT, Default.DEFAULT_DATE_FORMAT);
        this.mLatLngType = this.mSP.getInteger(getActivity(), SP.LAT_LNG_TYPE, 1).intValue();
        this.msTemprature_type = this.mSP.getString(getActivity(), SP.TEMPRATURE_TYPE, "Celsius");
        this.mfTemprature_value = this.mSP.getFloat(getActivity(), SP.TEMPRETURE_VALUE).floatValue();
        int intValue = this.mSP.getInteger(getActivity(), SP.WEATHER_ICON, 0).intValue();
        this.mIconValue = intValue;
        this.imgWeather.setImageResource(this.mWeatherIcon.getResourceId(intValue, 0));
        this.mMap_Type = this.mSP.getString(getActivity(), SP.MAP_TYPE_TEMPLATE, Default.NORMAL_1);
        this.mPos_mapType = this.mSP.getInteger(getActivity(), SP.MAP_POS, 0).intValue();
        this.mStamp_Pos = this.mSP.getString(getActivity(), SP.STAMP_POS, "Bottom");
        savePreviousData();
        setTempratureData();
        setTemplate();
        setMapType();
        setColors();
        setUpViewPager();
        startDateTimer();
    }

    private void setTempratureData() {
        if (getTemprature_Type_Temp().equals("Celsius")) {
            this.tv_weather.setText(HelperClass.getCelcius(this.mfTemprature_value));
        } else {
            this.tv_weather.setText(HelperClass.getFahrenheit(this.mfTemprature_value));
        }
    }

    private void startDateTimer() {
        this.mTimer_Date = new Timer();
        TimerTask r2 = new TimerTask() {
            @Override 
            public void run() {
                MainFragment.this.mTimerHandler.post(new Runnable() { 
                    @Override 
                    public void run() {
                        MainFragment.this.setText();
                    }
                });
            }
        };
        this.mTimerTask_Date = r2;
        this.mTimer_Date.schedule(r2, 1, 1000);
    }

    public void setText() {
        String str;
        String str2 = "";
        String trim = this.mSP.getString(getActivity(), SP.LOC_LINE_1_ADDRESS, str2).trim();
        String trim2 = this.mSP.getString(getActivity(), SP.LOC_LINE_2_CITY, str2).trim();
        String trim3 = this.mSP.getString(getActivity(), SP.LOC_LINE_3_STATE, str2).trim();
        String trim4 = this.mSP.getString(getActivity(), SP.LOC_LINE_4_COUNTRY, str2).trim();
        if (trim2 == null || trim2.isEmpty()) {
            str = str2;
        } else {
            str = str2 + str2 + trim2 + ", ";
        }
        if (trim3 != null && !trim3.isEmpty()) {
            str = str + str2 + trim3 + ", ";
        }
        if (trim4 != null && !trim4.isEmpty()) {
            str = str + trim4;
        }
        if (str != null && str.endsWith(", ")) {
            str = str.substring(0, str.length() - 2);
        }
        if (trim != null && !trim.isEmpty()) {
            str2 = getColoredSpanned(trim, getAddress_ColorTemp());
        }
        String coloredSpanned = getColoredSpanned(this.mHelperClass.getLatLong(getContext(), getLatLngTemp_Type()), getLatLng_ColorTemp());
        if (coloredSpanned != null && coloredSpanned.length() > 55 && isMapTemp() && !isWeatherTemp() && !isMagneticFieldTemp() && !isCompassTemp()) {
            if (this.mSP.getInteger(getActivity(), "lat_lng_type_temp_1", 1).intValue() == 6) {
                String[] split = coloredSpanned.split(" Lat");
                coloredSpanned = split[0] + "<br/>Lat " + split[1];
            } else {
                String[] split2 = coloredSpanned.split(" Long");
                coloredSpanned = split2[0] + "<br/>Long " + split2[1];
            }
        }
        if (isAddressTemp()) {
            if (isLatLngTemp()) {
                str2 = str2 + "<br/>" + coloredSpanned;
            }
        } else if (isLatLngTemp() && !isAddressTemp()) {
            str2 = coloredSpanned;
        }
        if (isDateTimeTemp()) {
            String coloredSpanned2 = getColoredSpanned(HelperClass.setDateTimeFormat(getDateTemp()), getDate_ColorTemp());
            if (isAddressTemp() || isLatLngTemp()) {
                str2 = str2 + "<br/>" + coloredSpanned2;
            } else {
                str2 = coloredSpanned2;
            }
        }
        if (str2.contains("null")) {
            str2 = str2.replace("null", "Loading");
        }
        this.tv_address_line_1.setText(Html.fromHtml(str2));
        if (str == null || str.isEmpty() || !isAddressTemp()) {
            this.tv_address.setVisibility(View.GONE);
            return;
        }
        this.tv_address.setVisibility(View.VISIBLE);
        if (str.equalsIgnoreCase("null")) {
            str = "Loading";
        }
        this.tv_address.setText(Html.fromHtml(getColoredSpanned(str, getAddress_ColorTemp())));
    }

    private void setMapType() {
        String map_Type_Temp = getMap_Type_Temp();
        map_Type_Temp.hashCode();
        char c = 65535;
        switch (map_Type_Temp.hashCode()) {
            case -1579103941:
                if (map_Type_Temp.equals(Default.SETELLITE_2)) {
                    c = 0;
                    break;
                }
                break;
            case -1423437003:
                if (map_Type_Temp.equals(Default.TERRAIN_3)) {
                    c = 1;
                    break;
                }
                break;
            case -1202757124:
                if (map_Type_Temp.equals(Default.HYBRID_4)) {
                    c = 2;
                    break;
                }
                break;
            case 1366708796:
                if (map_Type_Temp.equals(Default.NORMAL_1)) {
                    c = 3;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                this.imgMap.setImageResource(R.drawable.setellite);
                return;
            case 1:
                this.imgMap.setImageResource(R.drawable.tarrain);
                return;
            case 2:
                this.imgMap.setImageResource(R.drawable.hybrid);
                return;
            case 3:
                this.imgMap.setImageResource(R.drawable.normal);
                return;
            default:
                return;
        }
    }

    private void setUpViewPager() {
        this.mTabTitleArray = getResources().getStringArray(R.array.tab_array);
        for (int i = 0; i < this.mTabTitleArray.length; i++) {
            TabLayout tabLayout = this.mTabLayout;
            tabLayout.addTab(tabLayout.newTab().setText(this.mTabTitleArray[i]));
        }
        Pager_Adapter pager_Adapter = new Pager_Adapter(getChildFragmentManager(), this.mTabLayout.getTabCount());
        this.mAdapter = pager_Adapter;
        this.mViewPager.setAdapter(pager_Adapter);
        this.mViewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(this.mTabLayout));
        this.mTabLayout.setupWithViewPager(this.mViewPager);
        this.mTabLayout.addOnTabSelectedListener((TabLayout.OnTabSelectedListener) new TabLayout.OnTabSelectedListener() { 
            @Override 
            public void onTabReselected(TabLayout.Tab tab) {
            }

            @Override 
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override 
            public void onTabSelected(TabLayout.Tab tab) {
                MainFragment.this.mViewPager.setCurrentItem(tab.getPosition());
            }
        });
    }

    @Override 
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        if (getActivity() != null) {
            ((CameraActivity) getActivity()).hideUi();
            ((CameraActivity) getActivity()).setOnBackPressedListener(new CameraActivity.OnBackPressedListener() { 
                @Override 
                public void onBackPressed() {
                    MainFragment.this.doBack();
                }
            });
        }
    }

    public void doBack() {
        if (isAllUnCheck()) {
            showSnackbar();
        } else if (isChanges()) {
            saveData();
        } else {
            getActivity().getSupportFragmentManager().popBackStackImmediate();
        }
    }

    private void showSnackbar() {
        Snackbar.make(this.mToolbar_back, getString(R.string.no_select_template), -Toast.LENGTH_LONG).show();
    }

    private boolean isAllUnCheck() {
        return !isAddressTemp() && !isMapTemp() && !isLatLngTemp() && !isDateTimeTemp() && !isWeatherTemp() && !isCompassTemp() && !isMagneticFieldTemp();
    }

    @Override 
    public void onDetach() {
        AlertDialog alertDialog = this.confirm_dialog;
        if (alertDialog != null && alertDialog.isShowing()) {
            this.confirm_dialog.dismiss();
        }
        if (getActivity() != null) {
            ((CameraActivity) getActivity()).showUI();
            ((CameraActivity) getActivity()).setUpStampLayout();
            ((CameraActivity) getActivity()).setRatio();
            ((CameraActivity) getActivity()).setOnBackPressedListener(null);
        }
        super.onDetach();
    }

    @Override 
    public void onClick(View view) {
        if (view.getId() == R.id.toolbar_back) {
            doBack();
        }
    }

    @Override 
    public void onTemplateSelected(int i) {
        setTemplate();
    }

    private void setTemplate() {
        boolean isMapTemp = isMapTemp();
        boolean isAddressTemp = isAddressTemp();
        boolean isLatLngTemp = isLatLngTemp();
        boolean isMagneticFieldTemp = isMagneticFieldTemp();
        boolean isCompassTemp = isCompassTemp();
        boolean isWeatherTemp = isWeatherTemp();
        boolean isDateTimeTemp = isDateTimeTemp();
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        if (isMapTemp) {
            this.imgMap.setVisibility(View.VISIBLE);
            layoutParams.setMargins((int) getResources().getDimension(R.dimen._8dp), 0, 0, 0);
        } else {
            this.imgMap.setVisibility(View.GONE);
            layoutParams.setMargins(0, 0, 0, 0);
        }
        this.li_stamp.setLayoutParams(layoutParams);
        if (isWeatherTemp) {
            this.li_weather.setVisibility(View.VISIBLE);
        } else {
            this.li_weather.setVisibility(View.GONE);
        }
        if (this.isCompassFound) {
            if (isMagneticFieldTemp) {
                this.li_magnetic_field.setVisibility(View.VISIBLE);
            } else {
                this.li_magnetic_field.setVisibility(View.GONE);
            }
            if (isCompassTemp) {
                this.li_compass.setVisibility(View.VISIBLE);
            } else {
                this.li_compass.setVisibility(View.GONE);
            }
        } else {
            this.li_magnetic_field.setVisibility(View.GONE);
            this.li_compass.setVisibility(View.GONE);
        }
        if (isWeatherTemp || isMagneticFieldTemp || isCompassTemp) {
            this.li_rightView.setVisibility(View.VISIBLE);
        } else {
            this.li_rightView.setVisibility(View.GONE);
        }
        if (isAddressTemp) {
            this.tv_address_line_1.setMaxLines(10);
        } else if (isMapTemp || ((isWeatherTemp || isMagneticFieldTemp || isCompassTemp || isLatLngTemp || !isDateTimeTemp) && ((isWeatherTemp || isMagneticFieldTemp || isCompassTemp || isDateTimeTemp || !isLatLngTemp) && (((!isWeatherTemp && !isCompassTemp && !isMagneticFieldTemp) || !isDateTimeTemp || isLatLngTemp) && ((!isWeatherTemp && !isCompassTemp && !isMagneticFieldTemp) || isDateTimeTemp || !isLatLngTemp))))) {
            this.tv_address_line_1.setMaxLines(10);
        } else {
            this.tv_address_line_1.setMaxLines(1);
        }
        if (isMapTemp) {
            if (isAddressTemp && isLatLngTemp) {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 0.0f, getResources().getDisplayMetrics()), 1.0f);
            } else if (isAddressTemp && (isWeatherTemp || isMagneticFieldTemp || isCompassTemp)) {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 2.0f, getResources().getDisplayMetrics()), 1.0f);
            } else if (isWeatherTemp || isMagneticFieldTemp || isCompassTemp) {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_SP, 5.0f, getResources().getDisplayMetrics()), 1.0f);
            } else {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 2.0f, getResources().getDisplayMetrics()), 1.2f);
            }
            this.li_stamp.getLayoutParams().height = (int) getActivity().getResources().getDimension(R.dimen.stamp_icon_size_110);
        } else if (!isLatLngTemp && !isAddressTemp && !isMagneticFieldTemp && !isWeatherTemp && !isCompassTemp) {
            this.li_stamp.getLayoutParams().height = (int) getActivity().getResources().getDimension(R.dimen.stamp_70dp);
        } else if (!isAddressTemp) {
            this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 2.0f, getResources().getDisplayMetrics()), 1.2f);
            if ((isDateTimeTemp || isLatLngTemp) && (this.tv_address_line_1.getMaxLines() != 1 || ((isCompassTemp || isMagneticFieldTemp || isWeatherTemp) && ((!isWeatherTemp || isCompassTemp || isMagneticFieldTemp) && ((!isCompassTemp || isWeatherTemp || isMagneticFieldTemp) && (!isMagneticFieldTemp || isWeatherTemp || isCompassTemp)))))) {
                this.li_stamp.getLayoutParams().height = (int) getActivity().getResources().getDimension(R.dimen.stamp_90dp);
            } else {
                this.li_stamp.getLayoutParams().height = (int) getActivity().getResources().getDimension(R.dimen.stamp_70dp);
            }
        } else if (!isAddressTemp || isLatLngTemp) {
            this.li_stamp.getLayoutParams().height = (int) getActivity().getResources().getDimension(R.dimen.stamp_icon_size_110);
        } else {
            this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 2.0f, getResources().getDisplayMetrics()), 1.2f);
            this.li_stamp.getLayoutParams().height = (int) getActivity().getResources().getDimension(R.dimen.stamp_icon_size_110);
        }
        if (isAddressTemp || isLatLngTemp || isDateTimeTemp) {
            this.li_address.setVisibility(View.VISIBLE);
            this.li_rightView.setOrientation(LinearLayout.VERTICAL);
            this.li_rightView.setGravity(19);
            this.li_rightView.getLayoutParams().width = -2;
            this.li_rightView.getLayoutParams().width = -2;
        } else {
            this.li_address.setVisibility(View.GONE);
            this.li_rightView.setOrientation(android.widget.LinearLayout.HORIZONTAL);
            this.li_rightView.setGravity(17);
            this.li_rightView.getLayoutParams().width = -1;
            this.li_rightView.getLayoutParams().width = -1;
        }
        if (isLatLngTemp || isAddressTemp || isMagneticFieldTemp || isWeatherTemp || isCompassTemp || isDateTimeTemp || isMapTemp) {
            this.li_main_stamp_lay.setVisibility(View.VISIBLE);
            setText();
            return;
        }
        this.li_main_stamp_lay.setVisibility(View.GONE);
    }

    private boolean isCompassTemp() {
        return this.mSP.getBoolean(getActivity(), "Compass", Default.IS_COMPASS).booleanValue();
    }

    private boolean isMagneticFieldTemp() {
        return this.mSP.getBoolean(getActivity(), "Magnetic Field", Default.IS_MAGNETIC_FIELD).booleanValue();
    }

    private boolean isWeatherTemp() {
        return this.mSP.getBoolean(getActivity(), "Weather", Default.IS_WEATHER).booleanValue();
    }

    private boolean isDateTimeTemp() {
        return this.mSP.getBoolean(getActivity(), "date_and_time", Default.IS_DATE_TIME).booleanValue();
    }

    private boolean isLatLngTemp() {
        return this.mSP.getBoolean(getActivity(), "Lat/Long", Default.IS_LAT_LNG_TEMPLATE).booleanValue();
    }

    private boolean isAddressTemp() {
        return this.mSP.getBoolean(getActivity(), "Address", Default.IS_ADDRESS).booleanValue();
    }

    private boolean isMapTemp() {
        return this.mSP.getBoolean(getActivity(), "Map", Default.IS_MAP).booleanValue();
    }

    @Override 
    public void onDateSelected() {
        setText();
    }

    private String getDateTemp() {
        return this.mSP.getString(getActivity(), "date_format_temp", Default.DEFAULT_DATE_FORMAT);
    }

    private int getPos_MapType_Temp() {
        return this.mSP.getInteger(getActivity(), "map_type_temp_pos", 0).intValue();
    }

    @Override 
    public void onColorSelected() {
        setColors();
    }

    private void setColors() {
        ((GradientDrawable) this.li_stamp.getBackground().getCurrent()).setColor(getBackground_ColorTemp());
        this.tv_weather.setTextColor(getWeather_ColorTemp());
        this.tv_magnetic_field.setTextColor(getMagnetic_ColorTemp());
        this.tv_compass.setTextColor(getCompass_ColorTemp());
        setText();
    }

    private int getBackground_ColorTemp() {
        return this.mSP.getInteger(getActivity(), "Background Color", Color.parseColor("#9c000000")).intValue();
    }

    private int getCompass_ColorTemp() {
        return this.mSP.getInteger(getActivity(), "Compass Color", -1).intValue();
    }

    private int getMagnetic_ColorTemp() {
        return this.mSP.getInteger(getActivity(), "Magnetic Field Color", -1).intValue();
    }

    private int getWeather_ColorTemp() {
        return this.mSP.getInteger(getActivity(), "Weather Color", -1).intValue();
    }

    private int getLatLng_ColorTemp() {
        return this.mSP.getInteger(getActivity(), "Lat/Long Color", -1).intValue();
    }

    private int getDate_ColorTemp() {
        return this.mSP.getInteger(getActivity(), "Date & Time Color", -1).intValue();
    }

    private int getAddress_ColorTemp() {
        return this.mSP.getInteger(getActivity(), "Address Color", -1).intValue();
    }

    @Override 
    public void onLatLngType() {
        setText();
    }

    private String getColoredSpanned(String str, int i) {
        return "<font color=" + i + ">" + str + "</font>";
    }

    @Override 
    public void onTempratureType() {
        setTempratureData();
    }

    @Override 
    public void onMapTypeSelected() {
        setMapType();
    }

    
    public class Pager_Adapter extends FragmentStatePagerAdapter {
        int totalTabs;

        
        public Pager_Adapter(FragmentManager fragmentManager, int i) {
            super(fragmentManager);
            this.totalTabs = i;
        }

        @Override 
        public Fragment getItem(int i) {
            switch (i) {
                case 0:
                    return new Template_Fragment();
                case 1:
                    return new PositionFragment();
                case 2:
                    return new DateTimeFragment();
                case 3:
                    return new ColorFragment();
                case 4:
                    return new MapTypeFragment();
                case 5:
                    return new GPS_Coordinates_Fragment();
                case 6:
                    return new TempratureFragment();
                default:
                    return null;
            }
        }

        @Override 
        public CharSequence getPageTitle(int i) {
            return MainFragment.this.mTabTitleArray[i];
        }

        @Override 
        public int getCount() {
            return this.totalTabs;
        }
    }

    @Override 
    public void onAttachFragment(Fragment fragment) {
        super.onAttachFragment(fragment);
        if (fragment instanceof Template_Fragment) {
            ((Template_Fragment) fragment).setOnTemplate_DataListener(new Template_Fragment.OnTemplateDataListener() { 
                @Override 
                public final void onTemplateSelected(int i) {
                    MainFragment.this.onTemplateSelected(i);
                }
            });
        } else if (fragment instanceof DateTimeFragment) {
            ((DateTimeFragment) fragment).setOnDate_SelectedListener(new DateTimeFragment.OnDateSelectedListener() { 
                @Override 
                public final void onDateSelected() {
                    MainFragment.this.onDateSelected();
                }
            });
        } else if (fragment instanceof MapTypeFragment) {
            ((MapTypeFragment) fragment).setOnMap_SelectedListener(this);
        } else if (fragment instanceof ColorFragment) {
            ((ColorFragment) fragment).setOnColorSelectedListener(new ColorFragment.OnColorSelectedListener() { 
                @Override 
                public final void onColorSelected() {
                    MainFragment.this.onColorSelected();
                }
            });
        } else if (fragment instanceof GPS_Coordinates_Fragment) {
            ((GPS_Coordinates_Fragment) fragment).setOnLatLngListener(this);
        } else if (fragment instanceof TempratureFragment) {
            ((TempratureFragment) fragment).setOnTempratureListener(this);
        }
    }

    boolean isChanges() {
        return (this.isMap == isMapTemp() && this.isAddress == isAddressTemp() && this.isLatLng == isLatLngTemp() && this.isWeather == isWeatherTemp() && this.isDateTime == isDateTimeTemp() && this.isMagneticField == isMagneticFieldTemp() && this.isCompass == isCompassTemp() && this.mDateFormat.equals(getDateTemp()) && this.background_color == getBackground_ColorTemp() && this.address_color == getAddress_ColorTemp() && this.date_time_color == getDate_ColorTemp() && this.lat_lng_color == getLatLng_ColorTemp() && this.weather_color == getWeather_ColorTemp() && this.magnetic_field_color == getMagnetic_ColorTemp() && this.compass_color == getCompass_ColorTemp() && this.mLatLngType == getLatLngTemp_Type() && this.msTemprature_type.equals(getTemprature_Type_Temp()) && this.mMap_Type.equals(getMap_Type_Temp()) && this.mStamp_Pos.equals(getStampPosTypeTemp())) ? false : true;
    }

    private String getTemprature_Type_Temp() {
        return this.mSP.getString(getActivity(), "temprature_type_temp", "Celsius");
    }

    private void savePreviousData() {
        SP sp;
        if (getActivity() != null && (sp = this.mSP) != null) {
            sp.setBoolean(getActivity(), "Map", Boolean.valueOf(this.isMap));
            this.mSP.setBoolean(getActivity(), "Address", Boolean.valueOf(this.isAddress));
            this.mSP.setBoolean(getActivity(), "Lat/Long", Boolean.valueOf(this.isLatLng));
            this.mSP.setBoolean(getActivity(), "Weather", Boolean.valueOf(this.isWeather));
            this.mSP.setBoolean(getActivity(), "date_and_time", Boolean.valueOf(this.isDateTime));
            this.mSP.setBoolean(getActivity(), "Magnetic Field", Boolean.valueOf(this.isMagneticField));
            this.mSP.setBoolean(getActivity(), "Compass", Boolean.valueOf(this.isCompass));
            this.mSP.setString(getActivity(), "date_format_temp", this.mDateFormat);
            this.mSP.setInteger(getActivity(), "Background Color", Integer.valueOf(this.background_color));
            this.mSP.setInteger(getActivity(), "Address Color", Integer.valueOf(this.address_color));
            this.mSP.setInteger(getActivity(), "Date & Time Color", Integer.valueOf(this.date_time_color));
            this.mSP.setInteger(getActivity(), "Lat/Long Color", Integer.valueOf(this.lat_lng_color));
            this.mSP.setInteger(getActivity(), "Weather Color", Integer.valueOf(this.weather_color));
            this.mSP.setInteger(getActivity(), "Magnetic Field Color", Integer.valueOf(this.magnetic_field_color));
            this.mSP.setInteger(getActivity(), "Compass Color", Integer.valueOf(this.compass_color));
            this.mSP.setInteger(getActivity(), "lat_lng_type_temp_1", Integer.valueOf(this.mLatLngType));
            this.mSP.setString(getActivity(), "temprature_type_temp", this.msTemprature_type);
            this.mSP.setString(getActivity(), "map_type_temp", this.mMap_Type);
            this.mSP.setInteger(getActivity(), "map_type_temp_pos", Integer.valueOf(this.mPos_mapType));
            this.mSP.setString(getActivity(), "pos_type_temp", this.mStamp_Pos);
        }
    }

    private void saveData() {
        if (getActivity() != null) {
            this.mSP.setBoolean(getActivity(), SP.IS_MAP, Boolean.valueOf(isMapTemp()));
            this.mSP.setBoolean(getActivity(), SP.IS_ADDRESS, Boolean.valueOf(isAddressTemp()));
            this.mSP.setBoolean(getActivity(), SP.IS_LAT_LNG_TEMPLATE, Boolean.valueOf(isLatLngTemp()));
            this.mSP.setBoolean(getActivity(), SP.IS_WEATHER, Boolean.valueOf(isWeatherTemp()));
            this.mSP.setBoolean(getActivity(), SP.IS_DATE_TIME, Boolean.valueOf(isDateTimeTemp()));
            this.mSP.setBoolean(getActivity(), SP.IS_MAGNETIC_FIELD, Boolean.valueOf(isMagneticFieldTemp()));
            this.mSP.setBoolean(getActivity(), SP.IS_COMPASS, Boolean.valueOf(isCompassTemp()));
            this.mSP.setString(getActivity(), SP.DATE_FORMAT, getDateTemp());
            this.mSP.setInteger(getActivity(), SP.BACKGROUND_COLOR, Integer.valueOf(getBackground_ColorTemp()));
            this.mSP.setInteger(getActivity(), SP.ADDRESS_COLOR, Integer.valueOf(getAddress_ColorTemp()));
            this.mSP.setInteger(getActivity(), SP.DATE_TIME_COLOR, Integer.valueOf(getDate_ColorTemp()));
            this.mSP.setInteger(getActivity(), SP.LAT_LNG_COLOR, Integer.valueOf(getLatLng_ColorTemp()));
            this.mSP.setInteger(getActivity(), SP.WEATHER_COLOR, Integer.valueOf(getWeather_ColorTemp()));
            this.mSP.setInteger(getActivity(), SP.MAGNETIC_FIELD_COLOR, Integer.valueOf(getMagnetic_ColorTemp()));
            this.mSP.setInteger(getActivity(), SP.COMPASS_COLOR, Integer.valueOf(getCompass_ColorTemp()));
            this.mSP.setInteger(getActivity(), SP.LAT_LNG_TYPE, Integer.valueOf(getLatLngTemp_Type()));
            this.mSP.setString(getActivity(), SP.TEMPRATURE_TYPE, getTemprature_Type_Temp());
            this.mSP.setString(getActivity(), SP.MAP_TYPE_TEMPLATE, getMap_Type_Temp());
            this.mSP.setInteger(getActivity(), SP.MAP_POS, Integer.valueOf(getPos_MapType_Temp()));
            this.mSP.setString(getActivity(), SP.STAMP_POS, getStampPosTypeTemp());
            popupBakcstake();
        }
    }

    private void popupBakcstake() {
        new Handler().postDelayed(new Runnable() { 
            @Override 
            public void run() {
                if (MainFragment.this.getActivity() != null && MainFragment.this.getActivity().getSupportFragmentManager() != null) {
                    MainFragment.this.getActivity().getSupportFragmentManager().popBackStack();
                }
            }
        }, 50);
    }

    private String getMap_Type_Temp() {
        return this.mSP.getString(getActivity(), "map_type_temp", Default.NORMAL_1);
    }

    private int getLatLngTemp_Type() {
        return this.mSP.getInteger(getActivity(), "lat_lng_type_temp_1", 1).intValue();
    }

    private String getStampPosTypeTemp() {
        return this.mSP.getString(getActivity(), "pos_type_temp", "Bottom");
    }

    @Override 
    public void onDestroy() {
        super.onDestroy();
        if (isWeatherTemp()) {
            try {
                ((CameraActivity) requireActivity()).callWeatherApi();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
