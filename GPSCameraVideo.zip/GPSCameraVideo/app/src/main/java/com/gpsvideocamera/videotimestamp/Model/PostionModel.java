package com.gpsvideocamera.videotimestamp.Model;


public class PostionModel {
    String Postion;
    int Selected;

    public PostionModel(String str, int i) {
        this.Postion = str;
        this.Selected = i;
    }

    public String getPostion() {
        return this.Postion;
    }

    public void setPostion(String str) {
        this.Postion = str;
    }

    public int getSelected() {
        return this.Selected;
    }

    public void setSelected(int i) {
        this.Selected = i;
    }
}
