package com.gpsvideocamera.videotimestamp.Activity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.HelperClass;


public class Privacy_Policy extends AppCompatActivity implements View.OnClickListener {
    WebView browser;
    private HelperClass mHelperClass;
    private ProgressBar mProgressBar;
    private RelativeLayout mToolbar_back;
    private TextView mtv_toolbar_title;

    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        HelperClass helperClass = new HelperClass();
        this.mHelperClass = helperClass;
        helperClass.SetLanguage(this);
        setContentView(R.layout.activity_privacy__policy);
        init();
    }

    private void init() {
        this.mToolbar_back = (RelativeLayout) findViewById(R.id.toolbar_back);
        TextView textView = (TextView) findViewById(R.id.tv_toolbar_title);
        this.mtv_toolbar_title = textView;
        textView.setText(getString(R.string.privacy_policy));
        this.browser = (WebView) findViewById(R.id.browser);
        this.mProgressBar = (ProgressBar) findViewById(R.id.progress_bar);
        loadUrl();
        onClicks();
    }

    private void loadUrl() {
        this.browser.setWebChromeClient(new WebChromeClient() { 
            @Override 
            public void onProgressChanged(WebView webView, int i) {
                Privacy_Policy.this.mProgressBar.setProgress(i);
                if (i == 100) {
                    Privacy_Policy.this.mProgressBar.setVisibility(View.GONE);
                } else {
                    Privacy_Policy.this.mProgressBar.setVisibility(View.VISIBLE);
                }
                Privacy_Policy.this.setTitle("Loading...");
                Privacy_Policy.this.setProgress(i * 100);
                if (i == 100) {
                    Privacy_Policy.this.setTitle(R.string.app_name);
                }
            }
        });
        this.browser.setWebViewClient(new WebViewClient() { 
            @Override 
            public void onLoadResource(WebView webView, String str) {
            }

            @Override 
            public void onPageFinished(WebView webView, String str) {
            }

            @Override 
            public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                webView.loadUrl(str);
                return false;
            }

            @Override // android.webkit.WebViewClient
            public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
                super.onPageStarted(webView, str, bitmap);
            }
        });
        this.browser.loadUrl(getString(R.string.about_privacy_policy));
    }

    private void onClicks() {
        this.mToolbar_back.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.Privacy_Policy$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                Privacy_Policy.this.onClick(view);
            }
        });
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        if (view.getId() == R.id.toolbar_back) {
            finish();
        }
    }
}
