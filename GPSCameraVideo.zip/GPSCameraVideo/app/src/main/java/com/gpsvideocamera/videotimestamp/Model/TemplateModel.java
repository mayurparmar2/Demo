package com.gpsvideocamera.videotimestamp.Model;


public class TemplateModel {
    boolean isSelected;
    String spKey;
    String title;

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public boolean isSelected() {
        return this.isSelected;
    }

    public void setSelected(boolean z) {
        this.isSelected = z;
    }

    public String getSpKey() {
        return this.spKey;
    }

    public void setSpKey(String str) {
        this.spKey = str;
    }
}
