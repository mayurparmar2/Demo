package com.gpsvideocamera.videotimestamp.LocalNotification;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import com.gpsvideocamera.videotimestamp.Activity.SplashActivity;


public class AutoStart extends BroadcastReceiver {
    AlarmReceiver alarmReceiver = new AlarmReceiver();

    @Override 
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.intent.action.BOOT_COMPLETED")) {
            Intent intent2 = new Intent(context, SplashActivity.class);
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent2);
            } else {
                context.startService(intent2);
            }
            this.alarmReceiver.setAlarm(context, AlarmTimingUtils.getLastOpenTime(context), 51);
        }
    }
}
