package com.gpsvideocamera.videotimestamp.Fragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.gpsvideocamera.videotimestamp.colorselector.CustomColorPickerDialog;
import com.google.android.material.snackbar.Snackbar;
import com.gpsvideocamera.videotimestamp.Activity.InAppPurchaseActivity;
import com.gpsvideocamera.videotimestamp.Adapter.ColorAdapter;
import com.gpsvideocamera.videotimestamp.Interface.OnRecyclerItemClickListener;
import com.gpsvideocamera.videotimestamp.Model.ColorModel;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.HelperClass;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import java.util.ArrayList;
import java.util.List;


public class ColorFragment extends Fragment {
    OnColorSelectedListener callback;
    boolean isCompassFound;
    boolean is_pro;
    private ColorAdapter mAdapter;
    private RecyclerView mRecyclerview;
    SP mSP;
    List<ColorModel> mList = new ArrayList();
    private long mLastClickTime = 0;

    
    
    public interface OnColorSelectedListener {
        void onColorSelected();
    }

    public void setOnColorSelectedListener(OnColorSelectedListener onColorSelectedListener) {
        this.callback = onColorSelectedListener;
    }

    @Override 
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_template, viewGroup, false);
    }

    @Override 
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        init(view);
    }

    private void init(View view) {
        this.mSP = new SP(getActivity());
        this.is_pro = new SP(getContext()).getBoolean(getContext(), HelperClass.IS_PURCHESH_OR_NOT, false).booleanValue();
        this.mRecyclerview = (RecyclerView) view.findViewById(R.id.fragment_recyclerview);
        fillList();
    }

    private void fillList() {
        this.isCompassFound = this.mSP.getBoolean(getActivity(), SP.COMPASS_FOUND, false).booleanValue();
        List<ColorModel> list = this.mList;
        if (list != null) {
            if (list.size() > 0) {
                this.mList.clear();
            }
            ColorModel colorModel = new ColorModel();
            colorModel.setTitle(getString(R.string.background_color));
            colorModel.setSpKey("Background Color");
            colorModel.setColor(this.mSP.getInteger(getActivity(), colorModel.getSpKey(), Color.parseColor("#9c000000")).intValue());
            this.mList.add(colorModel);
            ColorModel colorModel2 = new ColorModel();
            colorModel2.setTitle(getString(R.string.address_color));
            colorModel2.setSpKey("Address Color");
            colorModel2.setColor(this.mSP.getInteger(getActivity(), colorModel2.getSpKey(), -1).intValue());
            this.mList.add(colorModel2);
            ColorModel colorModel3 = new ColorModel();
            colorModel3.setTitle(getString(R.string.date_time_color));
            colorModel3.setSpKey("Date & Time Color");
            colorModel3.setColor(this.mSP.getInteger(getActivity(), colorModel3.getSpKey(), -1).intValue());
            this.mList.add(colorModel3);
            ColorModel colorModel4 = new ColorModel();
            colorModel4.setTitle(getString(R.string.lat_lng_color));
            colorModel4.setSpKey("Lat/Long Color");
            colorModel4.setColor(this.mSP.getInteger(getActivity(), colorModel4.getSpKey(), -1).intValue());
            this.mList.add(colorModel4);
            ColorModel colorModel5 = new ColorModel();
            colorModel5.setTitle(getString(R.string.weather_color));
            colorModel5.setSpKey("Weather Color");
            colorModel5.setColor(this.mSP.getInteger(getActivity(), colorModel5.getSpKey(), -1).intValue());
            this.mList.add(colorModel5);
            if (this.isCompassFound) {
                ColorModel colorModel6 = new ColorModel();
                colorModel6.setTitle(getString(R.string.magnetic_color));
                colorModel6.setSpKey("Magnetic Field Color");
                colorModel6.setColor(this.mSP.getInteger(getActivity(), colorModel6.getSpKey(), -1).intValue());
                this.mList.add(colorModel6);
                ColorModel colorModel7 = new ColorModel();
                colorModel7.setTitle(getString(R.string.compass_color));
                colorModel7.setSpKey("Compass Color");
                colorModel7.setColor(this.mSP.getInteger(getActivity(), colorModel7.getSpKey(), -1).intValue());
                this.mList.add(colorModel7);
            }
        }
        setAdapter();
    }

    private void setAdapter() {
        this.mRecyclerview.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        ColorAdapter colorAdapter = new ColorAdapter(getActivity(), this.mList, new OnRecyclerItemClickListener() { 
            @Override 
            public void OnLongClick_(int i, View view) {
            }

            @Override 
            public void OnClick_(final int i, final View view) {
                if (SystemClock.elapsedRealtime() - ColorFragment.this.mLastClickTime >= 1000) {
                    ColorFragment.this.mLastClickTime = SystemClock.elapsedRealtime();
                    if (!ColorFragment.this.is_pro) {
                        ColorFragment.this.createInAppDialog(view);
                    } else if (ColorFragment.this.getContext() != null) {
                        CustomColorPickerDialog.newInstance(ColorFragment.this.getContext(), i, ColorFragment.this.mSP.getInteger(ColorFragment.this.getContext(), ColorFragment.this.mList.get(i).getSpKey(), -1).intValue(), 0, new CustomColorPickerDialog.OnAmbilWarnaListener() { 
                            @Override 
                            public void onCancel(CustomColorPickerDialog customColorPickerDialog) {
                                customColorPickerDialog.dismiss();
                            }

                            @Override 
                            public void onOk(CustomColorPickerDialog customColorPickerDialog, int i2, int i3) {
                                ColorFragment.this.mSP.setInteger(ColorFragment.this.getContext(), ColorFragment.this.mList.get(i).getSpKey(), Integer.valueOf(i2));
                                ((GradientDrawable) view.findViewById(R.id.tv_color_background).getBackground().getCurrent()).setColor(i2);
                                if (ColorFragment.this.callback != null) {
                                    ColorFragment.this.callback.onColorSelected();
                                }
                                customColorPickerDialog.dismiss();
                            }
                        }).show(ColorFragment.this.getActivity().getFragmentManager(), "dialog");
                    }
                }
            }
        });
        this.mAdapter = colorAdapter;
        this.mRecyclerview.setAdapter(colorAdapter);
    }

    public void createInAppDialog(final View view) {
        if (getContext() != null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setMessage(getContext().getString(R.string.color_inapp_msg));
            builder.setPositiveButton(getContext().getString(R.string.pro), new DialogInterface.OnClickListener() { 
                @Override 
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (HelperClass.check_internet(ColorFragment.this.getContext())) {
                        ColorFragment.this.getContext().startActivity(new Intent(ColorFragment.this.getContext(), InAppPurchaseActivity.class));
                    } else {
                        View view2 = view;
                        Snackbar.make(view2, "" + ColorFragment.this.getContext().getString(R.string.no_internet_msg), -Toast.LENGTH_LONG).show();
                    }
                    dialogInterface.dismiss();
                }
            });
            builder.setNegativeButton(getContext().getString(R.string.cancel), new DialogInterface.OnClickListener() { 
                @Override 
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            final AlertDialog create = builder.create();
            create.setOnShowListener(new DialogInterface.OnShowListener() { 
                @Override 
                public void onShow(DialogInterface dialogInterface) {
                    create.getButton(-1).setTextColor(ColorFragment.this.getResources().getColor(R.color._0b2528));
                    create.getButton(-1).setBackgroundResource(R.drawable.black_ripple_custom);
                    create.getButton(-2).setTextColor(ColorFragment.this.getResources().getColor(R.color._0b2528));
                    create.getButton(-2).setBackgroundResource(R.drawable.black_ripple_custom);
                }
            });
            create.show();
        }
    }

    @Override 
    public void onDetach() {
        super.onDetach();
        this.callback = null;
    }
}
