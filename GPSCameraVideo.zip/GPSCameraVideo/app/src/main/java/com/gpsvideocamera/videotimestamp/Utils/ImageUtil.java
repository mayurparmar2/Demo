package com.gpsvideocamera.videotimestamp.Utils;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Log;
import com.gpsvideocamera.videotimestamp.Model.ImageModel;
import java.util.ArrayList;


public class ImageUtil {
    public static ArrayList<ImageModel> getAllImages11(Context context) {
        ArrayList<ImageModel> arrayList = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 29) {
            MediaStore.Images.Media.getContentUri("external");
        } else {
            Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        }
        try {
            Cursor query = context.getContentResolver().query(MediaStore.Files.getContentUri("external"), null, Build.VERSION.SDK_INT >= 29 ? "relative_path LIKE ?" : "_data LIKE ?", new String[]{"%DCIM/GPS video camera%"}, "date_added DESC");
            Log.e("TAG", "getAllImages: " + query.getCount());
            int columnIndexOrThrow = query.getColumnIndexOrThrow("_id");
            int columnIndexOrThrow2 = query.getColumnIndexOrThrow("_display_name");
            while (query.moveToNext()) {
                arrayList.add(new ImageModel(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, query.getLong(columnIndexOrThrow)), query.getString(columnIndexOrThrow2), query.getString(query.getColumnIndexOrThrow("_data"))));
            }
            query.close();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
        return arrayList;
    }
}
