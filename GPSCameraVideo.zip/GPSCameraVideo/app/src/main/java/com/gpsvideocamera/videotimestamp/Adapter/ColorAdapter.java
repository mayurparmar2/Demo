package com.gpsvideocamera.videotimestamp.Adapter;

import android.app.Activity;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.gpsvideocamera.videotimestamp.Interface.OnRecyclerItemClickListener;
import com.gpsvideocamera.videotimestamp.Model.ColorModel;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.HelperClass;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import java.util.List;


public class ColorAdapter extends RecyclerView.Adapter<ColorAdapter.Holder> {
    boolean is_pro;
    Activity mContext;
    List<ColorModel> mList;
    OnRecyclerItemClickListener mOnRecyclerItemClickListener;
    SP mSP;

    public ColorAdapter(Activity activity, List<ColorModel> list, OnRecyclerItemClickListener onRecyclerItemClickListener) {
        this.mContext = activity;
        this.mList = list;
        this.mOnRecyclerItemClickListener = onRecyclerItemClickListener;
        this.mSP = new SP(this.mContext);
        this.is_pro = new SP(this.mContext).getBoolean(this.mContext, HelperClass.IS_PURCHESH_OR_NOT, false).booleanValue();
    }

    @Override 
    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_color, viewGroup, false));
    }

    public void onBindViewHolder(Holder holder, int i) {
        holder.tv_color_title.setText(this.mList.get(i).getTitle());
        ((GradientDrawable) holder.tv_color_background.getBackground().getCurrent()).setColor(this.mList.get(i).getColor());
    }

    @Override 
    public int getItemCount() {
        return this.mList.size();
    }

    
    public class Holder extends RecyclerView.ViewHolder {
        RelativeLayout Rel_background;
        TextView tv_color_background;
        TextView tv_color_title;

        public Holder(final View view) {
            super(view);
            this.tv_color_title = (TextView) view.findViewById(R.id.tv_color_title);
            this.tv_color_background = (TextView) view.findViewById(R.id.tv_color_background);
            this.Rel_background = (RelativeLayout) view.findViewById(R.id.Rel_background);
            this.Rel_background.setOnClickListener(new View.OnClickListener() {
                @Override 
                public void onClick(View view2) {
                    if (Holder.this.getAdapterPosition() >= 0 && view != null && ColorAdapter.this.mOnRecyclerItemClickListener != null) {
                        ColorAdapter.this.mOnRecyclerItemClickListener.OnClick_(Holder.this.getAdapterPosition(), view);
                    }
                }
            });
        }
    }
}
