package com.gpsvideocamera.videotimestamp.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
 






import com.google.android.material.snackbar.Snackbar;
import com.gpsvideocamera.videotimestamp.Dragview.DragLinearLayout;
import com.gpsvideocamera.videotimestamp.Model.ViewModel;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.Default;
import com.gpsvideocamera.videotimestamp.Utils.HelperClass;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;


public class FileName_Activity extends AppCompatActivity implements View.OnClickListener, CompoundButton.OnCheckedChangeListener, View.OnFocusChangeListener {
    private boolean IS_ADS;
    String ads_status;
    int appCount;
    CheckBox chk_24_hr;
    CheckBox chk_Week;
    CheckBox chk_cus_1;
    CheckBox chk_cus_2;
    CheckBox chk_cus_3;
    CheckBox chk_decimal;
    CheckBox chk_dms;
    CheckBox chk_dt;
    CheckBox chk_hr_min;
    CheckBox chk_line_1;
    CheckBox chk_line_2;
    CheckBox chk_line_3;
    CheckBox chk_line_4;
    CheckBox chk_main_address;
    CheckBox chk_main_date_time;
    CheckBox chk_main_latlng;
    CheckBox chk_s_n;
    DragLinearLayout dragLinearLayout;
    ImageView img_drag_cus_1;
    boolean is_pro;
    LinearLayout li_child_address;
    LinearLayout li_child_cus_1;
    LinearLayout li_child_cus_2;
    LinearLayout li_child_cus_3;
    LinearLayout li_child_dt;
    LinearLayout li_child_lat_lng;
    LinearLayout li_child_sequence;
    EditText mEd_cus_1;
    EditText mEd_cus_2;
    EditText mEd_cus_3;
    EditText mEd_sequence;
    private HelperClass mHelperClass;

    RelativeLayout mRel_add_address;
    RelativeLayout mRel_custom_1;
    RelativeLayout mRel_custom_2;
    RelativeLayout mRel_custom_3;
    RelativeLayout mRel_datetime;
    RelativeLayout mRel_lat_lng;
    RelativeLayout mRel_sequence_num;
    SP mSP;
    private RelativeLayout mToolbar_back;
    TextView mTv_click_address;
    TextView mTv_click_cus_1;
    TextView mTv_click_cus_2;
    TextView mTv_click_cus_3;
    TextView mTv_click_dt;
    TextView mTv_click_latlng;
    TextView mTv_click_sn;
    TextView mTv_filename;
    private RelativeLayout main_real;
    private TextView mtv_toolbar_title;
    RelativeLayout rel_inapp_address;
    RelativeLayout rel_inapp_cus_1;
    RelativeLayout rel_inapp_cus_2;
    RelativeLayout rel_inapp_cus_3;
    RelativeLayout rel_inapp_lat_lng;
    ArrayList<Integer> child_layList = new ArrayList<>();
    ArrayList<Integer> drop_down_List = new ArrayList<>();
    ArrayList<ViewModel> list_item = new ArrayList<>();
    String time = "";
    String timedate24 = "";

    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        HelperClass helperClass = new HelperClass();
        this.mHelperClass = helperClass;
        helperClass.SetLanguage(this);
        setContentView(R.layout.activity_file_name_);
        init();
    }

    private ArrayList<ViewModel> callTextViewData(int i) {
        String str;
        String str2;
        String str3;
        String str4;
        String str5;
        String str6;
        ArrayList<ViewModel> arrayList = new ArrayList<>();
        ViewModel viewModel = new ViewModel();
        String str7 = "";
        if (this.chk_main_date_time.isChecked()) {
            str = getDateValue(i);
            viewModel.setSelected(true);
            if (this.chk_Week.isChecked()) {
                str = getDateValue(i);
                viewModel.setSelected(true);
            }
            if (this.chk_24_hr.isChecked()) {
                str = getDateValue(i);
                viewModel.setSelected(true);
            }
        } else {
            viewModel.setSelected(true);
            str = str7;
        }
        viewModel.setId(R.id.rel_main_datetime);
        viewModel.setName("rel_main_datetime");
        viewModel.setValue(str);
        arrayList.add(get_date_time_index().intValue(), viewModel);
        ViewModel viewModel2 = new ViewModel();
        if (this.chk_s_n.isChecked()) {
            str2 = getSequence_EdittextValue();
            viewModel2.setSelected(true);
        } else {
            viewModel2.setSelected(false);
            str2 = str7;
        }
        viewModel2.setId(R.id.rel_sequence_num);
        viewModel2.setName("rel_sequence_num");
        viewModel2.setValue(str2);
        arrayList.add(get_sequence_index().intValue(), viewModel2);
        ViewModel viewModel3 = new ViewModel();
        if (this.chk_cus_1.isChecked()) {
            str3 = getCustom_1_EditTextValue();
            viewModel3.setSelected(true);
        } else {
            viewModel3.setSelected(false);
            str3 = str7;
        }
        viewModel3.setId(R.id.rel_custom_1);
        viewModel3.setName("rel_custom_1");
        viewModel3.setValue(str3);
        arrayList.add(get_custom1_index().intValue(), viewModel3);
        ViewModel viewModel4 = new ViewModel();
        if (this.chk_cus_2.isChecked()) {
            str4 = getCustom_2_EditTextValue();
            viewModel4.setSelected(true);
        } else {
            viewModel4.setSelected(false);
            str4 = str7;
        }
        viewModel4.setId(R.id.rel_custom_2);
        viewModel4.setName("rel_custom_2");
        viewModel4.setValue(str4);
        arrayList.add(get_custom2_index().intValue(), viewModel4);
        ViewModel viewModel5 = new ViewModel();
        if (this.chk_cus_3.isChecked()) {
            str5 = getCustom_3_EditTextValue();
            viewModel5.setSelected(true);
        } else {
            viewModel5.setSelected(false);
            str5 = str7;
        }
        viewModel5.setId(R.id.rel_custom_3);
        viewModel5.setName("rel_custom_3");
        viewModel5.setValue(str5);
        arrayList.add(get_custom3_index().intValue(), viewModel5);
        ViewModel viewModel6 = new ViewModel();
        if (this.chk_main_address.isChecked()) {
            if (this.chk_line_1.isChecked()) {
                viewModel6.setSelected(true);
            }
            if (this.chk_line_2.isChecked()) {
                viewModel6.setSelected(true);
            }
            if (this.chk_line_3.isChecked()) {
                viewModel6.setSelected(true);
            }
            if (this.chk_line_4.isChecked()) {
                viewModel6.setSelected(true);
            }
            str6 = getAddress();
        } else {
            viewModel6.setSelected(false);
            str6 = str7;
        }
        viewModel6.setId(R.id.rel_add_address);
        viewModel6.setName("rel_add_address");
        viewModel6.setValue(str6);
        arrayList.add(get_address_index().intValue(), viewModel6);
        ViewModel viewModel7 = new ViewModel();
        if (this.chk_main_latlng.isChecked()) {
            if (this.chk_decimal.isChecked()) {
                str7 = getLatLong();
                viewModel7.setSelected(true);
            }
            if (this.chk_dms.isChecked()) {
                str7 = str7 + "_" + getLatLong();
                viewModel7.setSelected(true);
            }
        } else {
            viewModel7.setSelected(false);
        }
        viewModel7.setId(R.id.rel_lat_lng);
        viewModel7.setName("rel_lat_lng");
        viewModel7.setValue(str7);
        arrayList.add(get_lat_long_index().intValue(), viewModel7);
        return arrayList;
    }

    private String getLatLong() {
        String str = "";
        if (this.chk_decimal.isChecked()) {
            str = str + "_" + this.mSP.getString(this, SP.LATITUDE, str) + "_" + this.mSP.getString(this, SP.LONGITUDE, str);
        }
        if (!this.chk_dms.isChecked()) {
            return str;
        }
        return str + "_" + this.mHelperClass.dms_latlng(this);
    }

    private String getAddress() {
        String str;
        String line_1_address = getLine_1_address();
        if (!this.chk_line_1.isChecked() || !isNotEmpty(line_1_address)) {
            str = "";
        } else {
            str = "_" + line_1_address;
        }
        String line_2_address = getLine_2_address();
        if (this.chk_line_2.isChecked() && isNotEmpty(line_2_address)) {
            str = str + "_" + line_2_address;
        }
        String line_3_address = getLine_3_address();
        if (this.chk_line_3.isChecked() && isNotEmpty(line_3_address)) {
            str = str + "_" + line_3_address;
        }
        String line_4_address = getLine_4_address();
        if (this.chk_line_4.isChecked() && isNotEmpty(line_4_address)) {
            str = str + "_" + line_4_address;
        }
        if (isNotEmpty(str)) {
            return str;
        }
        return "";
    }

    private String getLine_4_address() {
        return this.mSP.getString(this, SP.LOC_LINE_4_COUNTRY, "");
    }

    private String getLine_3_address() {
        return this.mSP.getString(this, SP.LOC_LINE_3_STATE, "");
    }

    private String getLine_2_address() {
        return this.mSP.getString(this, SP.LOC_LINE_2_CITY, "");
    }

    private String getLine_1_address() {
        return this.mSP.getString(this, SP.LOC_LINE_1_ADDRESS, "");
    }

    public String getCustom_3_EditTextValue() {
        return this.mEd_cus_3.getText().toString();
    }

    public String getCustom_2_EditTextValue() {
        return this.mEd_cus_2.getText().toString();
    }

    public String getCustom_1_EditTextValue() {
        return this.mEd_cus_1.getText().toString().trim();
    }

    public String getSequence_EdittextValue() {
        return this.mEd_sequence.getText().toString().trim();
    }

    private String getDateValue(int i) {
        String str;
        if (this.chk_24_hr.isChecked()) {
            str = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()).trim();
            if (i == 0) {
                this.timedate24 = str;
            }
        } else {
            str = new SimpleDateFormat("yyyyMMdd_hmmssa").format(new Date()).trim();
            if (i == 0) {
                this.time = str;
            }
        }
        if (!this.chk_Week.isChecked()) {
            return str;
        }
        return str + "_" + getWeek();
    }

    private String getWeek() {
        return new SimpleDateFormat("EEEE").format(new Date());
    }

    private void addExistingNote(int i, View view) {
        setNoteIndex(view, i);
    }

    public void setNoteIndex(View view, int i) {
        view.setTag(Integer.valueOf(i));
    }

    public int getNoteIndex(View view) {
        Object tag = view.getTag();
        if (tag == null) {
            return -1;
        }
        return ((Integer) tag).intValue();
    }



    private void init() {
        SP sp = new SP(this);
        this.mSP = sp;
        int intValue = sp.getInteger(this, SP.APP_COUNT, 0).intValue();
        this.appCount = intValue;
        if (intValue <= 3) {
            int i = intValue + 1;
            this.appCount = i;
            this.mSP.setInteger(this, SP.APP_COUNT, Integer.valueOf(i));
        }
        this.ads_status = new SP(this).getString(this, SP.ADS_STATUS, "1");
        this.IS_ADS = new SP(this).getBoolean(this, HelperClass.IS_PURCHESH_OR_NOT, false).booleanValue();
        this.mToolbar_back = (RelativeLayout) findViewById(R.id.toolbar_back);
        this.main_real = (RelativeLayout) findViewById(R.id.main_real);
        TextView textView = (TextView) findViewById(R.id.tv_toolbar_title);
        this.mtv_toolbar_title = textView;
        textView.setText(getString(R.string.file_name));
        this.dragLinearLayout = (DragLinearLayout) findViewById(R.id.container);
        this.mRel_datetime = (RelativeLayout) findViewById(R.id.rel_main_datetime);
        this.mRel_sequence_num = (RelativeLayout) findViewById(R.id.rel_sequence_num);
        this.mRel_custom_1 = (RelativeLayout) findViewById(R.id.rel_custom_1);
        this.mRel_custom_2 = (RelativeLayout) findViewById(R.id.rel_custom_2);
        this.mRel_custom_3 = (RelativeLayout) findViewById(R.id.rel_custom_3);
        this.mRel_add_address = (RelativeLayout) findViewById(R.id.rel_add_address);
        this.mRel_lat_lng = (RelativeLayout) findViewById(R.id.rel_lat_lng);
        this.child_layList.add(Integer.valueOf((int) R.id.li_child_dt));
        this.child_layList.add(Integer.valueOf((int) R.id.li_child_sequence));
        this.child_layList.add(Integer.valueOf((int) R.id.li_child_cus_1));
        this.child_layList.add(Integer.valueOf((int) R.id.li_child_cus_2));
        this.child_layList.add(Integer.valueOf((int) R.id.li_child_cus_3));
        this.child_layList.add(Integer.valueOf((int) R.id.li_child_address));
        this.child_layList.add(Integer.valueOf((int) R.id.li_child_lat_lng));
        this.drop_down_List.add(Integer.valueOf((int) R.id.tv_click_dt));
        this.drop_down_List.add(Integer.valueOf((int) R.id.tv_click_sn));
        this.drop_down_List.add(Integer.valueOf((int) R.id.tv_click_cus_1));
        this.drop_down_List.add(Integer.valueOf((int) R.id.tv_click_cus_2));
        this.drop_down_List.add(Integer.valueOf((int) R.id.tv_click_cus_3));
        this.drop_down_List.add(Integer.valueOf((int) R.id.tv_click_address));
        this.drop_down_List.add(Integer.valueOf((int) R.id.tv_click_latlng));
        this.li_child_dt = (LinearLayout) findViewById(R.id.li_child_dt);
        this.li_child_sequence = (LinearLayout) findViewById(R.id.li_child_sequence);
        this.li_child_cus_1 = (LinearLayout) findViewById(R.id.li_child_cus_1);
        this.li_child_cus_2 = (LinearLayout) findViewById(R.id.li_child_cus_2);
        this.li_child_cus_3 = (LinearLayout) findViewById(R.id.li_child_cus_3);
        this.li_child_address = (LinearLayout) findViewById(R.id.li_child_address);
        this.li_child_lat_lng = (LinearLayout) findViewById(R.id.li_child_lat_lng);
        this.mTv_click_dt = (TextView) findViewById(R.id.tv_click_dt);
        this.mTv_click_sn = (TextView) findViewById(R.id.tv_click_sn);
        this.mTv_click_cus_1 = (TextView) findViewById(R.id.tv_click_cus_1);
        this.mTv_click_cus_2 = (TextView) findViewById(R.id.tv_click_cus_2);
        this.mTv_click_cus_3 = (TextView) findViewById(R.id.tv_click_cus_3);
        this.mTv_click_address = (TextView) findViewById(R.id.tv_click_address);
        this.mTv_click_latlng = (TextView) findViewById(R.id.tv_click_latlng);
        this.chk_main_date_time = (CheckBox) findViewById(R.id.chk_main_date_time);
        this.chk_dt = (CheckBox) findViewById(R.id.chk_dt);
        this.chk_Week = (CheckBox) findViewById(R.id.chk_Week);
        this.chk_hr_min = (CheckBox) findViewById(R.id.chk_hr_min);
        this.chk_24_hr = (CheckBox) findViewById(R.id.chk_24_hr);
        this.chk_s_n = (CheckBox) findViewById(R.id.chk_s_n);
        this.chk_cus_1 = (CheckBox) findViewById(R.id.chk_cus_1);
        this.chk_cus_2 = (CheckBox) findViewById(R.id.chk_cus_2);
        this.chk_cus_3 = (CheckBox) findViewById(R.id.chk_cus_3);
        this.chk_main_address = (CheckBox) findViewById(R.id.chk_main_address);
        this.chk_main_latlng = (CheckBox) findViewById(R.id.chk_main_latlng);
        this.chk_main_latlng = (CheckBox) findViewById(R.id.chk_main_latlng);
        this.chk_decimal = (CheckBox) findViewById(R.id.chk_decimal);
        this.chk_dms = (CheckBox) findViewById(R.id.chk_dms);
        this.chk_line_1 = (CheckBox) findViewById(R.id.chk_line_1);
        this.chk_line_2 = (CheckBox) findViewById(R.id.chk_line_2);
        this.chk_line_3 = (CheckBox) findViewById(R.id.chk_line_3);
        this.chk_line_4 = (CheckBox) findViewById(R.id.chk_line_4);
        this.img_drag_cus_1 = (ImageView) findViewById(R.id.img_drag_cus_1);
        TextView textView2 = (TextView) findViewById(R.id.tv_filename);
        this.mTv_filename = textView2;
        textView2.setMovementMethod(new ScrollingMovementMethod());
        this.mEd_sequence = (EditText) findViewById(R.id.ed_sequence);
        this.mEd_cus_1 = (EditText) findViewById(R.id.ed_cus_1);
        this.mEd_cus_2 = (EditText) findViewById(R.id.ed_cus_2);
        this.mEd_cus_3 = (EditText) findViewById(R.id.ed_cus_3);
        this.rel_inapp_cus_1 = (RelativeLayout) findViewById(R.id.rel_inapp_cus_1);
        this.rel_inapp_cus_2 = (RelativeLayout) findViewById(R.id.rel_inapp_cus_2);
        this.rel_inapp_cus_3 = (RelativeLayout) findViewById(R.id.rel_inapp_cus_3);
        this.rel_inapp_address = (RelativeLayout) findViewById(R.id.rel_inapp_address);
        this.rel_inapp_lat_lng = (RelativeLayout) findViewById(R.id.rel_inapp_lat_lng);
        this.is_pro = new SP(this).getBoolean(this, HelperClass.IS_PURCHESH_OR_NOT, false).booleanValue();
        ArrayList<ViewModel> arrayList = this.mSP.getArrayList(this);
        this.list_item = arrayList;
        if (arrayList != null) {
            newViews();
        }
        setRecyclerView();
        setData();
        if (this.list_item == null) {
            this.list_item = new ArrayList<>();
            this.list_item = callTextViewData(0);
        }
        setUpEditText();
        if (this.appCount == 1) {
            showToolTip();
            saveData(1);
        }
        onClicks();
    }

    private void showToolTip() {
        if (!isFinishing()) {
            new Handler().postDelayed(new Runnable() { 
                @Override // java.lang.Runnable
                public void run() {
                    View inflate = View.inflate(FileName_Activity.this, R.layout.tooltip_lay, null);
                    final PopupWindow popupWindow = new PopupWindow(inflate, -2, -2, true);
                    popupWindow.setOutsideTouchable(false);
                    ((RelativeLayout) inflate.findViewById(R.id.tooltip_close)).setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity.1.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            PopupWindow popupWindow2 = popupWindow;
                            if (popupWindow2 != null) {
                                popupWindow2.dismiss();
                            }
                        }
                    });
                    popupWindow.showAtLocation(FileName_Activity.this.mRel_custom_3, GravityCompat.END, 0, (int) FileName_Activity.this.getResources().getDimension(R.dimen._8dp));
                    SP sp = FileName_Activity.this.mSP;
                    FileName_Activity fileName_Activity = FileName_Activity.this;
                    sp.setString(fileName_Activity, SP.FULL_FILE_NAME, fileName_Activity.mTv_filename.getText().toString().trim());
                }
            }, 1000);
        }
    }

    private void newViews() {
        if (this.list_item.size() > 0) {
            try {
                View findViewById = findViewById(this.list_item.get(0).getId());
                ((ViewGroup) findViewById.getParent()).removeView(findViewById);
                View findViewById2 = findViewById(this.list_item.get(1).getId());
                ((ViewGroup) findViewById2.getParent()).removeView(findViewById2);
                View findViewById3 = findViewById(this.list_item.get(2).getId());
                ((ViewGroup) findViewById3.getParent()).removeView(findViewById3);
                View findViewById4 = findViewById(this.list_item.get(3).getId());
                ((ViewGroup) findViewById4.getParent()).removeView(findViewById4);
                View findViewById5 = findViewById(this.list_item.get(4).getId());
                ((ViewGroup) findViewById5.getParent()).removeView(findViewById5);
                View findViewById6 = findViewById(this.list_item.get(5).getId());
                ((ViewGroup) findViewById6.getParent()).removeView(findViewById6);
                View findViewById7 = findViewById(this.list_item.get(6).getId());
                ((ViewGroup) findViewById7.getParent()).removeView(findViewById7);
                this.dragLinearLayout.addView(findViewById, 0);
                this.dragLinearLayout.addView(findViewById2, 1);
                this.dragLinearLayout.addView(findViewById3, 2);
                this.dragLinearLayout.addView(findViewById4, 3);
                this.dragLinearLayout.addView(findViewById5, 4);
                this.dragLinearLayout.addView(findViewById6, 5);
                this.dragLinearLayout.addView(findViewById7, 6);
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
        }
    }

    private void setUpEditText() {
        this.mEd_sequence.addTextChangedListener(new TextWatcher() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity.2
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                if (charSequence.toString().length() <= 0 || !FileName_Activity.this.mEd_sequence.isFocused()) {
                    FileName_Activity.this.chk_s_n.setChecked(false);
                    FileName_Activity fileName_Activity = FileName_Activity.this;
                    fileName_Activity.updateListData(fileName_Activity.get_sequence_index(), false, "");
                } else {
                    FileName_Activity.this.chk_s_n.setChecked(true);
                    FileName_Activity fileName_Activity2 = FileName_Activity.this;
                    fileName_Activity2.updateListData(fileName_Activity2.get_sequence_index(), true, FileName_Activity.this.getSequence_EdittextValue());
                }
                FileName_Activity.this.setUpTextview();
            }
        });
        if (this.is_pro) {
            this.mEd_cus_1.setEnabled(true);
            this.mEd_cus_2.setEnabled(true);
            this.mEd_cus_3.setEnabled(true);
            this.chk_line_1.setEnabled(true);
            this.chk_line_2.setEnabled(true);
            this.chk_line_3.setEnabled(true);
            this.chk_line_4.setEnabled(true);
            this.chk_dms.setEnabled(true);
            this.chk_decimal.setEnabled(true);
            this.rel_inapp_cus_1.setVisibility(View.GONE);
            this.rel_inapp_cus_2.setVisibility(View.GONE);
            this.rel_inapp_cus_3.setVisibility(View.GONE);
            this.rel_inapp_lat_lng.setVisibility(View.GONE);
            this.rel_inapp_address.setVisibility(View.GONE);
            this.mEd_cus_1.addTextChangedListener(new TextWatcher() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity.3
                @Override // android.text.TextWatcher
                public void afterTextChanged(Editable editable) {
                }

                @Override // android.text.TextWatcher
                public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                }

                @Override // android.text.TextWatcher
                public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                    if (charSequence.toString().trim().length() <= 0 || !FileName_Activity.this.mEd_cus_1.isFocused()) {
                        FileName_Activity.this.chk_cus_1.setChecked(false);
                        FileName_Activity fileName_Activity = FileName_Activity.this;
                        fileName_Activity.updateListData(fileName_Activity.get_custom1_index(), false, "");
                    } else {
                        FileName_Activity.this.chk_cus_1.setChecked(true);
                        FileName_Activity fileName_Activity2 = FileName_Activity.this;
                        fileName_Activity2.updateListData(fileName_Activity2.get_custom1_index(), true, FileName_Activity.this.getCustom_1_EditTextValue());
                    }
                    FileName_Activity.this.setUpTextview();
                }
            });
            this.mEd_cus_2.addTextChangedListener(new TextWatcher() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity.4
                @Override // android.text.TextWatcher
                public void afterTextChanged(Editable editable) {
                }

                @Override // android.text.TextWatcher
                public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                }

                @Override // android.text.TextWatcher
                public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                    if (charSequence.toString().trim().length() > 0) {
                        FileName_Activity.this.chk_cus_2.setChecked(true);
                        FileName_Activity fileName_Activity = FileName_Activity.this;
                        fileName_Activity.updateListData(fileName_Activity.get_custom2_index(), true, FileName_Activity.this.getCustom_2_EditTextValue());
                    } else {
                        FileName_Activity.this.chk_cus_2.setChecked(false);
                        FileName_Activity fileName_Activity2 = FileName_Activity.this;
                        fileName_Activity2.updateListData(fileName_Activity2.get_custom2_index(), false, "");
                    }
                    FileName_Activity.this.setUpTextview();
                }
            });
            this.mEd_cus_3.addTextChangedListener(new TextWatcher() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity.5
                @Override // android.text.TextWatcher
                public void afterTextChanged(Editable editable) {
                }

                @Override // android.text.TextWatcher
                public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                }

                @Override // android.text.TextWatcher
                public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                    if (charSequence.toString().trim().length() > 0) {
                        FileName_Activity.this.chk_cus_3.setChecked(true);
                        FileName_Activity fileName_Activity = FileName_Activity.this;
                        fileName_Activity.updateListData(fileName_Activity.get_custom3_index(), true, FileName_Activity.this.getCustom_3_EditTextValue());
                    } else {
                        FileName_Activity.this.chk_cus_3.setChecked(false);
                        FileName_Activity fileName_Activity2 = FileName_Activity.this;
                        fileName_Activity2.updateListData(fileName_Activity2.get_custom3_index(), false, "");
                    }
                    FileName_Activity.this.setUpTextview();
                }
            });
            if (this.chk_main_address.isChecked()) {
                if (this.chk_line_1.isChecked() && !isNotEmpty(getLine_1_address())) {
                    this.chk_line_1.setChecked(false);
                }
                if (this.chk_line_2.isChecked() && !isNotEmpty(getLine_2_address())) {
                    this.chk_line_2.setChecked(false);
                }
                if (this.chk_line_3.isChecked() && !isNotEmpty(getLine_3_address())) {
                    this.chk_line_3.setChecked(false);
                }
                if (this.chk_line_4.isChecked() && !isNotEmpty(getLine_4_address())) {
                    this.chk_line_4.setChecked(false);
                }
                if (this.chk_line_1.isChecked() || this.chk_line_2.isChecked() || this.chk_line_3.isChecked() || this.chk_line_4.isChecked()) {
                    updateListData(get_address_index(), true, getAddress());
                } else {
                    this.chk_main_address.setChecked(false);
                    updateListData(get_address_index(), false, "");
                }
            }
            if (this.chk_main_latlng.isChecked()) {
                Integer num = get_lat_long_index();
                updateListData(num, true, "" + getLatLong());
            }
        } else {
            this.rel_inapp_cus_1.setVisibility(View.VISIBLE);
            this.rel_inapp_cus_2.setVisibility(View.VISIBLE);
            this.rel_inapp_cus_3.setVisibility(View.VISIBLE);
            this.rel_inapp_lat_lng.setVisibility(View.VISIBLE);
            this.rel_inapp_address.setVisibility(View.VISIBLE);
            this.mEd_cus_1.setEnabled(false);
            this.mEd_cus_2.setEnabled(false);
            this.mEd_cus_3.setEnabled(false);
            this.chk_line_1.setEnabled(false);
            this.chk_line_2.setEnabled(false);
            this.chk_line_3.setEnabled(false);
            this.chk_line_4.setEnabled(false);
            this.chk_dms.setEnabled(false);
            this.chk_decimal.setEnabled(false);
        }
        if (this.chk_main_date_time.isChecked()) {
            updateListData(get_date_time_index(), true, getDateValue(0));
        }
        if (this.chk_s_n.isChecked()) {
            Integer num2 = get_sequence_index();
            updateListData(num2, true, "" + getSequenceText());
        }
        setUpTextview();
    }

    private void setData() {
        this.chk_main_date_time.setChecked(is_main_dt());
        this.chk_dt.setChecked(is_dt());
        this.chk_hr_min.setChecked(is_hr_min());
        this.chk_24_hr.setChecked(is_24HR());
        this.chk_Week.setChecked(is_week());
        this.chk_s_n.setChecked(is_sequence());
        this.chk_cus_1.setChecked(is_cus_1());
        this.chk_cus_2.setChecked(is_cus_2());
        this.chk_cus_3.setChecked(is_cus_3());
        this.chk_main_address.setChecked(is_main_address());
        this.chk_line_1.setChecked(is_line_1());
        this.chk_line_2.setChecked(is_line_2());
        this.chk_line_3.setChecked(is_line_3());
        this.chk_line_4.setChecked(is_line_4());
        this.chk_main_latlng.setChecked(is_main_lat_lng());
        this.chk_decimal.setChecked(is_decimal());
        this.chk_dms.setChecked(is_dms());
        EditText editText = this.mEd_sequence;
        editText.setText("" + getSequenceText());
        this.mEd_cus_1.setText(getCusText_1());
        this.mEd_cus_2.setText(getCusText_2());
        this.mEd_cus_3.setText(getCusText_3());
    }

    private String getCusText_1() {
        return this.mSP.getString(this, SP.CUS_VALUE_1, Default.CUSTUM_NAME_1_VALUE);
    }

    private String getCusText_2() {
        return this.mSP.getString(this, SP.CUS_VALUE_2, getString(R.string.cus_2));
    }

    private String getCusText_3() {
        return this.mSP.getString(this, SP.CUS_VALUE_3, getString(R.string.cus_3));
    }

    private int getSequenceText() {
        return this.mSP.getInteger(this, SP.SEQUENCE_VALUE, 1).intValue();
    }

    private boolean is_dms() {
        return this.mSP.getBoolean(this, SP.IS_DMS_FILE, false).booleanValue();
    }

    private boolean is_decimal() {
        return this.mSP.getBoolean(this, SP.IS_DECIMAL_FILE, false).booleanValue();
    }

    private boolean is_main_lat_lng() {
        return this.mSP.getBoolean(this, SP.IS_LAT_LNG, Default.IS_LAT_LONG_FILE_NAME).booleanValue();
    }

    private boolean is_line_4() {
        return this.mSP.getBoolean(this, SP.IS_LINE_4, false).booleanValue();
    }

    private boolean is_line_3() {
        return this.mSP.getBoolean(this, SP.IS_LINE_3, false).booleanValue();
    }

    private boolean is_line_2() {
        return this.mSP.getBoolean(this, SP.IS_LINE_2, false).booleanValue();
    }

    private boolean is_line_1() {
        return this.mSP.getBoolean(this, SP.IS_LINE_1, false).booleanValue();
    }

    private boolean is_main_address() {
        return this.mSP.getBoolean(this, SP.IS_MAIN_ADDRESS, Default.IS_MAIN_ADDRESS_FILE_NAME).booleanValue();
    }

    private boolean is_cus_3() {
        return this.mSP.getBoolean(this, SP.IS_CUS_3, Default.IS_CUS_3).booleanValue();
    }

    private boolean is_cus_2() {
        return this.mSP.getBoolean(this, SP.IS_CUS_2, Default.IS_CUS_2).booleanValue();
    }

    private boolean is_cus_1() {
        return this.mSP.getBoolean(this, SP.IS_CUS_1, Default.IS_CUS_1).booleanValue();
    }

    private boolean is_sequence() {
        return this.mSP.getBoolean(this, SP.IS_SEQUENCE, Default.IS_SEQUENCE_FILE).booleanValue();
    }

    private boolean is_week() {
        return this.mSP.getBoolean(this, SP.IS_WEEK, false).booleanValue();
    }

    private boolean is_24HR() {
        return this.mSP.getBoolean(this, SP.IS_24HR, false).booleanValue();
    }

    private boolean is_hr_min() {
        return this.mSP.getBoolean(this, SP.IS_HR_MIN_SEC, true).booleanValue();
    }

    private boolean is_dt() {
        return this.mSP.getBoolean(this, SP.IS_DT, true).booleanValue();
    }

    private boolean is_main_dt() {
        return this.mSP.getBoolean(this, SP.IS_FILE_DATE_TIME, Default.IS_MAIN_DT_FILE).booleanValue();
    }

    public void setUpTextview() {
        ArrayList<ViewModel> arrayList = this.list_item;
        if (arrayList != null && arrayList.size() > 0) {
            String str = "";
            for (int i = 0; i < this.list_item.size(); i++) {
                if (this.list_item.get(i).getSelected().booleanValue()) {
                    str = str + "_" + this.list_item.get(i).getValue();
                }
            }
            if (isNotEmpty(str)) {
                if (str.substring(0, 1).equals("_")) {
                    str = str.replaceFirst("_", "");
                }
                String replace = str.replace("__", "_");
                this.mTv_filename.setText(replace + ".jpg");
            }
        }
    }

    private String getoldefilepath() {
        ArrayList<ViewModel> arrayList = this.mSP.getArrayList(this);
        if (arrayList == null) {
            new ArrayList();
            arrayList = callTextViewData(1);
        }
        if (arrayList == null || arrayList.size() <= 0) {
            return "";
        }
        String str = "";
        for (int i = 0; i < arrayList.size(); i++) {
            ViewModel viewModel = arrayList.get(i);
            if (arrayList.get(i).getSelected().booleanValue()) {
                String name = viewModel.getName();
                name.hashCode();
                char c = 65535;
                switch (name.hashCode()) {
                    case -1781247461:
                        if (name.equals("rel_main_datetime")) {
                            c = 0;
                            break;
                        }
                        break;
                    case -1532787792:
                        if (name.equals("rel_add_address")) {
                            c = 1;
                            break;
                        }
                        break;
                    case -982105377:
                        if (name.equals("rel_lat_lng")) {
                            c = 2;
                            break;
                        }
                        break;
                    case -488653842:
                        if (name.equals("rel_sequence_num")) {
                            c = 3;
                            break;
                        }
                        break;
                    case 1675137993:
                        if (name.equals("rel_custom_1")) {
                            c = 4;
                            break;
                        }
                        break;
                    case 1675137994:
                        if (name.equals("rel_custom_2")) {
                            c = 5;
                            break;
                        }
                        break;
                    case 1675137995:
                        if (name.equals("rel_custom_3")) {
                            c = 6;
                            break;
                        }
                        break;
                }
                switch (c) {
                    case 0:
                        if (is_24HR()) {
                            str = this.timedate24;
                        } else {
                            str = this.time;
                        }
                        if (!is_week()) {
                            break;
                        } else {
                            str = str + "_" + getWeek();
                            continue;
                        }
                    case 1:
                        str = str + "_" + viewModel.getValue();
                        continue;
                    case 2:
                        str = str + "_" + viewModel.getValue();
                        continue;
                    case 3:
                        str = str + "_" + viewModel.getValue();
                        continue;
                    case 4:
                        str = str + "_" + viewModel.getValue();
                        continue;
                    case 5:
                        str = str + "_" + viewModel.getValue();
                        continue;
                    case 6:
                        str = str + "_" + viewModel.getValue();
                        continue;
                }
            }
        }
        if (!isNotEmpty(str)) {
            return str;
        }
        if (str.substring(0, 1).equals("_")) {
            str = str.replaceFirst("_", "");
        }
        return str.replace("__", "_") + ".jpg";
    }

    private void setRecyclerView() {
        for (int i = 0; i < this.dragLinearLayout.getChildCount(); i++) {
            View childAt = this.dragLinearLayout.getChildAt(i);
            this.dragLinearLayout.setViewDraggable(childAt, childAt);
            addExistingNote(i, childAt);
        }
        this.dragLinearLayout.setOnViewSwapListener(new DragLinearLayout.OnViewSwapListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity.6
            @Override // com.gpsvideocamera.videotimestamp.Dragview.DragLinearLayout.OnViewSwapListener
            public void onSwap(View view, int i2, View view2, int i3) {
                int noteIndex = FileName_Activity.this.getNoteIndex(view);
                int noteIndex2 = FileName_Activity.this.getNoteIndex(view2);
                FileName_Activity.this.setNoteIndex(view, noteIndex2);
                FileName_Activity.this.setNoteIndex(view2, noteIndex);
                Collections.swap(FileName_Activity.this.list_item, noteIndex2, noteIndex);
                FileName_Activity.this.setUpTextview();
            }
        });
    }

    private void onClicks() {
        this.mToolbar_back.setOnClickListener(this);
        this.mTv_click_dt.setOnClickListener(this);
        this.mTv_click_sn.setOnClickListener(this);
        this.mTv_click_cus_1.setOnClickListener(this);
        this.mTv_click_cus_2.setOnClickListener(this);
        this.mTv_click_cus_3.setOnClickListener(this);
        this.mTv_click_address.setOnClickListener(this);
        this.mTv_click_latlng.setOnClickListener(this);
        this.chk_main_date_time.setOnCheckedChangeListener(this);
        this.chk_dt.setOnCheckedChangeListener(this);
        this.chk_Week.setOnCheckedChangeListener(this);
        this.chk_hr_min.setOnCheckedChangeListener(this);
        this.chk_24_hr.setOnCheckedChangeListener(this);
        this.chk_s_n.setOnCheckedChangeListener(this);
        if (this.is_pro) {
            this.chk_cus_1.setOnCheckedChangeListener(this);
            this.chk_cus_2.setOnCheckedChangeListener(this);
            this.chk_cus_3.setOnCheckedChangeListener(this);
            this.chk_main_address.setOnCheckedChangeListener(this);
            this.chk_main_latlng.setOnCheckedChangeListener(this);
            this.chk_main_latlng.setOnCheckedChangeListener(this);
            this.chk_decimal.setOnCheckedChangeListener(this);
            this.chk_dms.setOnCheckedChangeListener(this);
            this.chk_line_1.setOnCheckedChangeListener(this);
            this.chk_line_2.setOnCheckedChangeListener(this);
            this.chk_line_3.setOnCheckedChangeListener(this);
            this.chk_line_4.setOnCheckedChangeListener(this);
        } else {
            this.rel_inapp_cus_1.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    FileName_Activity.this.onClick(view);
                }
            });
            this.rel_inapp_cus_2.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    FileName_Activity.this.onClick(view);
                }
            });
            this.rel_inapp_cus_3.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    FileName_Activity.this.onClick(view);
                }
            });
            this.rel_inapp_address.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    FileName_Activity.this.onClick(view);
                }
            });
            this.rel_inapp_lat_lng.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    FileName_Activity.this.onClick(view);
                }
            });
        }
        this.mEd_sequence.setOnFocusChangeListener(this);
        this.mEd_cus_1.setOnFocusChangeListener(this);
        this.mEd_cus_2.setOnFocusChangeListener(this);
        this.mEd_cus_3.setOnFocusChangeListener(this);
        this.chk_line_1.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                FileName_Activity.this.onClick(view);
            }
        });
        this.chk_line_2.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                FileName_Activity.this.onClick(view);
            }
        });
        this.chk_line_3.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                FileName_Activity.this.onClick(view);
            }
        });
        this.chk_line_4.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                FileName_Activity.this.onClick(view);
            }
        });
        this.chk_main_date_time.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                FileName_Activity.this.onClick(view);
            }
        });
        this.chk_main_address.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                FileName_Activity.this.onClick(view);
            }
        });
        this.chk_main_latlng.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                FileName_Activity.this.onClick(view);
            }
        });
        this.chk_s_n.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                FileName_Activity.this.onClick(view);
            }
        });
        this.chk_cus_1.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                FileName_Activity.this.onClick(view);
            }
        });
        this.chk_cus_2.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                FileName_Activity.this.onClick(view);
            }
        });
        this.chk_cus_3.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                FileName_Activity.this.onClick(view);
            }
        });
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        int id = view.getId();
        if (id != R.id.toolbar_back) {
            switch (id) {
                case R.id.chk_cus_1 :
                    if (!isNotEmpty(this.mEd_cus_1.getText().toString())) {
                        RelativeLayout relativeLayout = this.mRel_datetime;
                        Snackbar.make(relativeLayout, "" + getString(R.string.cus_1_empty_msg), -Toast.LENGTH_LONG).show();
                    }
                    if (!this.is_pro) {
                        this.chk_cus_1.setChecked(true);
                    }
                    if (this.chk_cus_1.isChecked()) {
                        visibleUi(R.id.li_child_cus_1, true);
                        return;
                    }
                    return;
                case R.id.chk_cus_2 :
                    if (!isNotEmpty(this.mEd_cus_2.getText().toString())) {
                        RelativeLayout relativeLayout2 = this.mRel_datetime;
                        Snackbar.make(relativeLayout2, "" + getString(R.string.cus_2_empty_msg), -Toast.LENGTH_LONG).show();
                    }
                    if (this.chk_cus_2.isChecked()) {
                        if (!this.is_pro) {
                            this.chk_cus_2.setChecked(false);
                        }
                        visibleUi(R.id.li_child_cus_2, true);
                        return;
                    }
                    return;
                case R.id.chk_cus_3 :
                    if (!isNotEmpty(this.mEd_cus_3.getText().toString())) {
                        RelativeLayout relativeLayout3 = this.mRel_datetime;
                        Snackbar.make(relativeLayout3, "" + getString(R.string.cus_3_empty_msg), -Toast.LENGTH_LONG).show();
                    }
                    if (this.chk_cus_3.isChecked()) {
                        if (!this.is_pro) {
                            this.chk_cus_3.setChecked(false);
                        }
                        visibleUi(R.id.li_child_cus_3, true);
                        return;
                    }
                    return;
                default:
                    switch (id) {
                        case R.id.chk_line_1 :
                            if (!isNotEmpty(getLine_1_address())) {
                                RelativeLayout relativeLayout4 = this.mRel_datetime;
                                Snackbar.make(relativeLayout4, "" + getString(R.string.line1_address_empty_msg), -Toast.LENGTH_LONG).show();
                                return;
                            }
                            return;
                        case R.id.chk_line_2 :
                            if (!isNotEmpty(getLine_2_address())) {
                                RelativeLayout relativeLayout5 = this.mRel_datetime;
                                Snackbar.make(relativeLayout5, "" + getString(R.string.line2_address_empty_msg), -Toast.LENGTH_LONG).show();
                                return;
                            }
                            return;
                        case R.id.chk_line_3 :
                            if (!isNotEmpty(getLine_3_address())) {
                                RelativeLayout relativeLayout6 = this.mRel_datetime;
                                Snackbar.make(relativeLayout6, "" + getString(R.string.line3_address_empty_msg), -Toast.LENGTH_LONG).show();
                                return;
                            }
                            return;
                        case R.id.chk_line_4 :
                            if (!isNotEmpty(getLine_4_address())) {
                                RelativeLayout relativeLayout7 = this.mRel_datetime;
                                Snackbar.make(relativeLayout7, "" + getString(R.string.line4_address_empty_msg), -Toast.LENGTH_LONG).show();
                                return;
                            }
                            return;
                        case R.id.chk_main_address :
                            if (this.chk_main_address.isChecked()) {
                                if (!this.is_pro) {
                                    this.chk_main_address.setChecked(false);
                                }
                                visibleUi(R.id.li_child_address, true);
                                return;
                            } else if (!isNotEmpty(getLine_1_address()) && !isNotEmpty(getLine_2_address()) && !isNotEmpty(getLine_3_address()) && !isNotEmpty(getLine_4_address())) {
                                RelativeLayout relativeLayout8 = this.mRel_datetime;
                                Snackbar.make(relativeLayout8, "" + getString(R.string.all_address_empty_msg), -Toast.LENGTH_LONG).show();
                                return;
                            } else {
                                return;
                            }
                        case R.id.chk_main_date_time :
                            if (this.chk_main_date_time.isChecked()) {
                                visibleUi(R.id.li_child_dt, true);
                                return;
                            }
                            return;
                        case R.id.chk_main_latlng :
                            if (this.chk_main_latlng.isChecked()) {
                                if (!this.is_pro) {
                                    this.chk_main_latlng.setChecked(false);
                                }
                                visibleUi(R.id.li_child_lat_lng, true);
                                return;
                            }
                            return;
                        case R.id.chk_s_n :
                            if (this.chk_s_n.isChecked()) {
                                visibleUi(R.id.li_child_sequence, true);
                                return;
                            }
                            return;
                        default:
                            switch (id) {
                                case R.id.rel_inapp_address :
                                case R.id.rel_inapp_cus_1 :
                                case R.id.rel_inapp_cus_2 :
                                case R.id.rel_inapp_cus_3 :
                                case R.id.rel_inapp_lat_lng :
                                    if (HelperClass.check_internet(this)) {
                                        startActivity(new Intent(this, InAppPurchaseActivity.class));
                                        return;
                                    }
                                    RelativeLayout relativeLayout9 = this.main_real;
                                    Snackbar.make(relativeLayout9, "" + getString(R.string.no_internet_msg), -Toast.LENGTH_LONG).show();
                                    return;
                                default:
                                    switch (id) {
                                        case R.id.tv_click_address :
                                            visibleUi(R.id.li_child_address, false);
                                            HelperClass.hideSoftKeyboard(this, this.mRel_datetime);
                                            return;
                                        case R.id.tv_click_cus_1 :
                                            visibleUi(R.id.li_child_cus_1, false);
                                            return;
                                        case R.id.tv_click_cus_2 :
                                            visibleUi(R.id.li_child_cus_2, false);
                                            return;
                                        case R.id.tv_click_cus_3 :
                                            visibleUi(R.id.li_child_cus_3, false);
                                            return;
                                        case R.id.tv_click_dt :
                                            visibleUi(R.id.li_child_dt, false);
                                            HelperClass.hideSoftKeyboard(this, this.mRel_datetime);
                                            return;
                                        case R.id.tv_click_latlng :
                                            visibleUi(R.id.li_child_lat_lng, false);
                                            HelperClass.hideSoftKeyboard(this, this.mRel_datetime);
                                            return;
                                        case R.id.tv_click_sn :
                                            visibleUi(R.id.li_child_sequence, false);
                                            return;
                                        default:
                                            return;
                                    }
                            }
                    }
            }
        } else {
            onBackPressed();
        }
    }

    private void visibleUi(int i, boolean z) {
        int size = this.child_layList.size();
        for (int i2 = 0; i2 < size; i2++) {
            View findViewById = findViewById(this.child_layList.get(i2).intValue());
            TextView textView = (TextView) findViewById(this.drop_down_List.get(i2).intValue());
            if (!(findViewById == null || textView == null)) {
                if (this.child_layList.get(i2).intValue() != i) {
                    findViewById.setVisibility(View.GONE);
                    textView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_dropdown, 0);
                } else if (z) {
                    findViewById.setVisibility(View.VISIBLE);
                    textView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_drop_up, 0);
                } else if (findViewById.getVisibility() == android.view.View.VISIBLE) {
                    findViewById.setVisibility(View.GONE);
                    textView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_dropdown, 0);
                } else {
                    findViewById.setVisibility(View.VISIBLE);
                    textView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_drop_up, 0);
                }
            }
        }
    }

    private void confirmDialog() {
        if (!isFinishing()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(getString(R.string.discard_message));
            builder.setPositiveButton(getString(R.string.save), new DialogInterface.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity.7
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            builder.setNegativeButton(getString(R.string.discard), new DialogInterface.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.FileName_Activity.8
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            builder.create().show();
        }
    }

    private void saveData(int i) {
        try {
            if (!isFinishing()) {
                this.mSP.saveArrayList(this, this.list_item);
                this.mSP.setString(this, SP.FULL_FILE_NAME, this.mTv_filename.getText().toString().trim());
                this.mSP.setBoolean(this, SP.IS_FILE_DATE_TIME, Boolean.valueOf(this.chk_main_date_time.isChecked()));
                this.mSP.setBoolean(this, SP.IS_DT, Boolean.valueOf(this.chk_dt.isChecked()));
                this.mSP.setBoolean(this, SP.IS_HR_MIN_SEC, Boolean.valueOf(this.chk_hr_min.isChecked()));
                this.mSP.setBoolean(this, SP.IS_WEEK, Boolean.valueOf(this.chk_Week.isChecked()));
                this.mSP.setBoolean(this, SP.IS_24HR, Boolean.valueOf(this.chk_24_hr.isChecked()));
                this.mSP.setBoolean(this, SP.IS_SEQUENCE, Boolean.valueOf(this.chk_s_n.isChecked()));
                this.mSP.setBoolean(this, SP.IS_CUS_1, Boolean.valueOf(this.chk_cus_1.isChecked()));
                this.mSP.setBoolean(this, SP.IS_CUS_2, Boolean.valueOf(this.chk_cus_2.isChecked()));
                this.mSP.setBoolean(this, SP.IS_CUS_3, Boolean.valueOf(this.chk_cus_3.isChecked()));
                this.mSP.setBoolean(this, SP.IS_MAIN_ADDRESS, Boolean.valueOf(this.chk_main_address.isChecked()));
                this.mSP.setBoolean(this, SP.IS_LINE_1, Boolean.valueOf(this.chk_line_1.isChecked()));
                this.mSP.setBoolean(this, SP.IS_LINE_2, Boolean.valueOf(this.chk_line_2.isChecked()));
                this.mSP.setBoolean(this, SP.IS_LINE_3, Boolean.valueOf(this.chk_line_3.isChecked()));
                this.mSP.setBoolean(this, SP.IS_LINE_4, Boolean.valueOf(this.chk_line_4.isChecked()));
                this.mSP.setBoolean(this, SP.IS_LAT_LNG, Boolean.valueOf(this.chk_main_latlng.isChecked()));
                this.mSP.setBoolean(this, SP.IS_DECIMAL_FILE, Boolean.valueOf(this.chk_decimal.isChecked()));
                this.mSP.setBoolean(this, SP.IS_DMS_FILE, Boolean.valueOf(this.chk_dms.isChecked()));
                if (isNotEmpty(getSequence_EdittextValue())) {
                    this.mSP.setInteger(this, SP.SEQUENCE_VALUE, Integer.valueOf(Integer.parseInt(getSequence_EdittextValue())));
                }
                this.mSP.setString(this, SP.CUS_VALUE_1, getCustom_1_EditTextValue());
                this.mSP.setString(this, SP.CUS_VALUE_2, getCustom_2_EditTextValue());
                this.mSP.setString(this, SP.CUS_VALUE_3, getCustom_3_EditTextValue());
                this.mSP.setInteger(this, SP.DATE_TIME_INDEX, get_date_time_index());
                this.mSP.setInteger(this, SP.SEQUENCE_INDEX, get_sequence_index());
                this.mSP.setInteger(this, SP.CUS_1_INDEX, get_custom1_index());
                this.mSP.setInteger(this, SP.CUS_2_INDEX, get_custom2_index());
                this.mSP.setInteger(this, SP.CUS_3_INDEX, get_custom3_index());
                this.mSP.setInteger(this, SP.ADDRESS_INDEX, get_address_index());
                this.mSP.setInteger(this, SP.LAT_LNG_INDEX, get_lat_long_index());
                if (i != 0) {
                    return;
                }
                finish();
            }
        } catch (Exception unused) {
            finish();
        }
    }

    private boolean isNotSelected() {
        return !this.chk_main_date_time.isChecked() && !this.chk_s_n.isChecked() && !this.chk_cus_1.isChecked() && !this.chk_cus_2.isChecked() && !this.chk_cus_3.isChecked() && !this.chk_main_address.isChecked() && !this.chk_main_latlng.isChecked();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (!isNotSelected()) {
            saveData(0);
            return;
        }
        RelativeLayout relativeLayout = this.mRel_datetime;
        Snackbar.make(relativeLayout, "" + getString(R.string.file_name_empty_msg), -Toast.LENGTH_LONG).show();
    }




    private boolean isChanges() {
        return !getoldefilepath().equals(this.mTv_filename.getText().toString().trim());
    }

    private Integer get_date_time_index() {
        return Integer.valueOf(((Integer) this.mRel_datetime.getTag()).intValue());
    }

    public Integer get_sequence_index() {
        return Integer.valueOf(((Integer) this.mRel_sequence_num.getTag()).intValue());
    }

    public Integer get_custom1_index() {
        return Integer.valueOf(((Integer) this.mRel_custom_1.getTag()).intValue());
    }

    public Integer get_custom2_index() {
        return Integer.valueOf(((Integer) this.mRel_custom_2.getTag()).intValue());
    }

    public Integer get_custom3_index() {
        return Integer.valueOf(((Integer) this.mRel_custom_3.getTag()).intValue());
    }

    private Integer get_address_index() {
        return Integer.valueOf(((Integer) this.mRel_add_address.getTag()).intValue());
    }

    private Integer get_lat_long_index() {
        return Integer.valueOf(((Integer) this.mRel_lat_lng.getTag()).intValue());
    }

    
    
    
    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    
    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        switch (compoundButton.getId()) {
            case R.id.chk_24_hr :
            case R.id.chk_Week :
                if (!z) {
                    this.chk_main_date_time.setChecked(true);
                    updateListData(get_date_time_index(), true, getDateValue(0));
                } else {
                    this.chk_main_date_time.setChecked(true);
                    updateListData(get_date_time_index(), true, getDateValue(0));
                }
                HelperClass.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_cus_1 :
                if (z) {
                    if (!this.mEd_cus_1.getText().toString().trim().isEmpty()) {
                        updateListData(get_custom1_index(), true, getCustom_1_EditTextValue());
                        break;
                    } else {
                        this.chk_cus_1.setChecked(false);
                        updateListData(get_custom1_index(), false, "");
                        break;
                    }
                } else {
                    updateListData(get_custom1_index(), false, "");
                    break;
                }
            case R.id.chk_cus_2 :
                if (z) {
                    if (!this.mEd_cus_2.getText().toString().trim().isEmpty()) {
                        updateListData(get_custom2_index(), true, getCustom_2_EditTextValue());
                        break;
                    } else {
                        this.chk_cus_2.setChecked(false);
                        updateListData(get_custom2_index(), false, "");
                        break;
                    }
                } else {
                    updateListData(get_custom2_index(), false, "");
                    break;
                }
            case R.id.chk_cus_3 :
                if (z) {
                    if (!this.mEd_cus_3.getText().toString().trim().isEmpty()) {
                        updateListData(get_custom3_index(), true, getCustom_3_EditTextValue());
                        break;
                    } else {
                        this.chk_cus_3.setChecked(false);
                        updateListData(get_custom3_index(), false, "");
                        break;
                    }
                } else {
                    updateListData(get_custom3_index(), false, "");
                    break;
                }
            case R.id.chk_decimal :
            case R.id.chk_dms :
                if (z) {
                    this.chk_main_latlng.setChecked(true);
                    updateListData(get_lat_long_index(), true, getLatLong());
                } else if (this.chk_decimal.isChecked() || this.chk_dms.isChecked()) {
                    this.chk_main_latlng.setChecked(true);
                    updateListData(get_lat_long_index(), true, getLatLong());
                } else {
                    this.chk_main_latlng.setChecked(false);
                    updateListData(get_lat_long_index(), false, "");
                }
                if (!z) {
                }
                HelperClass.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_line_1 :
                if (z) {
                    if (isNotEmpty(getLine_1_address())) {
                        this.chk_main_address.setChecked(true);
                        updateListData(get_address_index(), true, getAddress());
                    } else {
                        this.chk_line_1.setChecked(false);
                    }
                } else if (!this.chk_line_1.isChecked() && !this.chk_line_2.isChecked() && !this.chk_line_3.isChecked() && !this.chk_line_4.isChecked()) {
                    this.chk_main_address.setChecked(false);
                    updateListData(get_address_index(), false, "");
                } else if (isNotEmpty(getAddress())) {
                    this.chk_main_address.setChecked(true);
                    updateListData(get_address_index(), true, getAddress());
                }
                HelperClass.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_line_2 :
                if (z) {
                    if (isNotEmpty(getLine_2_address())) {
                        this.chk_main_address.setChecked(true);
                        updateListData(get_address_index(), true, getAddress());
                    } else {
                        this.chk_line_2.setChecked(false);
                    }
                } else if (!this.chk_line_1.isChecked() && !this.chk_line_2.isChecked() && !this.chk_line_3.isChecked() && !this.chk_line_4.isChecked()) {
                    this.chk_main_address.setChecked(false);
                    updateListData(get_address_index(), false, "");
                } else if (isNotEmpty(getAddress())) {
                    this.chk_main_address.setChecked(true);
                    updateListData(get_address_index(), true, getAddress());
                }
                HelperClass.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_line_3 :
                if (z) {
                    if (isNotEmpty(getLine_3_address())) {
                        this.chk_main_address.setChecked(true);
                        updateListData(get_address_index(), true, getAddress());
                    } else {
                        this.chk_line_3.setChecked(false);
                    }
                } else if (!this.chk_line_1.isChecked() && !this.chk_line_2.isChecked() && !this.chk_line_3.isChecked() && !this.chk_line_4.isChecked()) {
                    this.chk_main_address.setChecked(false);
                    updateListData(get_address_index(), false, "");
                } else if (isNotEmpty(getAddress())) {
                    this.chk_main_address.setChecked(true);
                    updateListData(get_address_index(), true, getAddress());
                }
                HelperClass.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_line_4 :
                if (z) {
                    if (isNotEmpty(getLine_4_address())) {
                        this.chk_main_address.setChecked(true);
                        updateListData(get_address_index(), true, getAddress());
                    } else {
                        this.chk_line_4.setChecked(false);
                    }
                } else if (!this.chk_line_1.isChecked() && !this.chk_line_2.isChecked() && !this.chk_line_3.isChecked() && !this.chk_line_4.isChecked()) {
                    this.chk_main_address.setChecked(false);
                    updateListData(get_address_index(), false, "");
                } else if (isNotEmpty(getAddress())) {
                    this.chk_main_address.setChecked(true);
                    updateListData(get_address_index(), true, getAddress());
                }
                HelperClass.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_main_address :
                if (!z) {
                    this.chk_main_address.setChecked(false);
                    this.chk_line_1.setChecked(false);
                    this.chk_line_2.setChecked(false);
                    this.chk_line_3.setChecked(false);
                    this.chk_line_4.setChecked(false);
                    updateListData(get_address_index(), false, "");
                } else if (this.chk_line_1.isChecked() || this.chk_line_2.isChecked() || this.chk_line_3.isChecked() || this.chk_line_4.isChecked()) {
                    if (isNotEmpty(getAddress())) {
                        this.chk_main_address.setChecked(true);
                        updateListData(get_address_index(), true, getAddress());
                    } else {
                        this.chk_main_address.setChecked(false);
                        updateListData(get_address_index(), false, "");
                    }
                } else if (isNotEmpty(getLine_1_address())) {
                    this.chk_main_address.setChecked(true);
                    this.chk_line_1.setChecked(true);
                    updateListData(get_address_index(), true, getAddress());
                } else if (isNotEmpty(getLine_2_address())) {
                    this.chk_main_address.setChecked(true);
                    this.chk_line_2.setChecked(true);
                    updateListData(get_address_index(), true, getAddress());
                } else if (isNotEmpty(getLine_3_address())) {
                    this.chk_main_address.setChecked(true);
                    this.chk_line_3.setChecked(true);
                    updateListData(get_address_index(), true, getAddress());
                } else if (isNotEmpty(getLine_4_address())) {
                    this.chk_main_address.setChecked(true);
                    this.chk_line_4.setChecked(true);
                    updateListData(get_address_index(), true, getAddress());
                } else {
                    this.chk_main_address.setChecked(false);
                    this.chk_line_1.setChecked(false);
                    updateListData(get_address_index(), false, "");
                }
                HelperClass.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_main_date_time :
                if (z) {
                    updateListData(get_date_time_index(), true, getDateValue(0));
                }
                HelperClass.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_main_latlng :
                if (!z) {
                    this.chk_decimal.setChecked(false);
                    this.chk_dms.setChecked(false);
                    updateListData(get_lat_long_index(), false, "");
                } else if (this.chk_decimal.isChecked() || this.chk_dms.isChecked()) {
                    updateListData(get_lat_long_index(), true, getLatLong());
                } else {
                    this.chk_main_latlng.setChecked(true);
                    this.chk_decimal.setChecked(true);
                    updateListData(get_lat_long_index(), true, getLatLong());
                }
                HelperClass.hideSoftKeyboard(this, this.mRel_datetime);
                break;
            case R.id.chk_s_n :
                if (z) {
                    if (!this.mEd_sequence.getText().toString().trim().isEmpty()) {
                        updateListData(get_sequence_index(), true, getSequence_EdittextValue());
                        break;
                    } else {
                        this.chk_s_n.setChecked(false);
                        updateListData(get_sequence_index(), false, "");
                        RelativeLayout relativeLayout = this.mRel_datetime;
                        Snackbar.make(relativeLayout, "" + getString(R.string.s_n_empty_msg), -Toast.LENGTH_LONG).show();
                        break;
                    }
                } else {
                    updateListData(get_sequence_index(), false, "");
                    break;
                }
        }
        setUpTextview();
    }

    boolean isNotEmpty(String str) {
        if (str == null) {
            return false;
        }
        return !str.trim().isEmpty();
    }

    public void updateListData(Integer num, boolean z, String str) {
        ArrayList<ViewModel> arrayList = this.list_item;
        if (arrayList != null && arrayList.size() > 0) {
            this.list_item.get(num.intValue()).setSelected(Boolean.valueOf(z));
            this.list_item.get(num.intValue()).setValue(str);
        }
    }

    @Override // android.view.View.OnFocusChangeListener
    public void onFocusChange(View view, boolean z) {
        switch (view.getId()) {
            case R.id.ed_cus_1 :
                if (!z) {
                    HelperClass.hideSoftKeyboard(this, this.mRel_datetime);
                    return;
                } else if (!this.chk_cus_1.isChecked()) {
                    this.chk_cus_1.setChecked(true);
                    return;
                } else {
                    return;
                }
            case R.id.ed_cus_2 :
                if (!z) {
                    HelperClass.hideSoftKeyboard(this, this.mRel_datetime);
                    return;
                } else if (!this.chk_cus_2.isChecked()) {
                    this.chk_cus_2.setChecked(true);
                    return;
                } else {
                    return;
                }
            case R.id.ed_cus_3 :
                if (!z) {
                    HelperClass.hideSoftKeyboard(this, this.mRel_datetime);
                    return;
                } else if (!this.chk_cus_3.isChecked()) {
                    this.chk_cus_3.setChecked(true);
                    return;
                } else {
                    return;
                }
            case R.id.ed_errormsg :
            default:
                return;
            case R.id.ed_sequence :
                if (!z) {
                    HelperClass.hideSoftKeyboard(this, this.mRel_datetime);
                    return;
                } else if (!this.chk_s_n.isChecked()) {
                    this.chk_s_n.setChecked(true);
                    return;
                } else {
                    return;
                }
        }
    }
}
