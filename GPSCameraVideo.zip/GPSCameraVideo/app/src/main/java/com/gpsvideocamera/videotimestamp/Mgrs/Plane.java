package com.gpsvideocamera.videotimestamp.Mgrs;




public final class Plane {
    private final Vec4 n;

    public Plane(Vec4 vec4) {
        if (vec4 == null) {
            throw new IllegalArgumentException("Vector Is Null");
        } else if (vec4.getLengthSquared3() != 0.0d) {
            this.n = vec4;
        } else {
            throw new IllegalArgumentException("Vector Is Zero");
        }
    }

    public Plane(double d, double d2, double d3, double d4) {
        if (d == 0.0d && d2 == 0.0d && d3 == 0.0d) {
            throw new IllegalArgumentException("Vector Is Zero");
        }
        this.n = new Vec4(d, d2, d3, d4);
    }

    public static Plane fromPoints(Vec4 vec4, Vec4 vec42, Vec4 vec43) {
        if (vec4 == null || vec42 == null || vec43 == null) {
            throw new IllegalArgumentException("Vec4 Is Null");
        }
        Vec4 cross3 = vec42.subtract3(vec4).cross3(vec43.subtract3(vec4));
        return new Plane(cross3.x, cross3.y, cross3.z, -cross3.dot3(vec4));
    }

    public final Vec4 getNormal() {
        return this.n;
    }

    public final double getDistance() {
        return this.n.w;
    }

    public final Vec4 getVector() {
        return this.n;
    }

    public final Plane normalize() {
        double length3 = this.n.getLength3();
        if (length3 == 0.0d) {
            return this;
        }
        return new Plane(new Vec4(this.n.x / length3, this.n.y / length3, this.n.z / length3, this.n.w / length3));
    }

    public final double dot(Vec4 vec4) {
        if (vec4 != null) {
            return (this.n.x * vec4.x) + (this.n.y * vec4.y) + (this.n.z * vec4.z) + (this.n.w * vec4.w);
        }
        throw new IllegalArgumentException("Point Is Null");
    }

    public Vec4 intersect(Line line) {
        if (line != null) {
            double intersectDistance = intersectDistance(line);
            if (Double.isNaN(intersectDistance)) {
                return null;
            }
            if (Double.isInfinite(intersectDistance)) {
                return line.getOrigin();
            }
            return line.getPointAt(intersectDistance);
        }
        throw new IllegalArgumentException("Line Is Null");
    }

    public double intersectDistance(Line line) {
        if (line != null) {
            double dot3 = this.n.dot3(line.getDirection());
            if (dot3 == 0.0d) {
                return this.n.dot4(line.getOrigin()) == 0.0d ? Double.POSITIVE_INFINITY : Double.NaN;
            }
            return (-this.n.dot4(line.getOrigin())) / dot3;
        }
        throw new IllegalArgumentException("Line Is Null");
    }

    public Vec4 intersect(Vec4 vec4, Vec4 vec42) {
        if (vec4 == null || vec42 == null) {
            throw new IllegalArgumentException("Point Is Null");
        } else if (!vec4.equals(vec42)) {
            Line fromSegment = Line.fromSegment(vec4, vec42);
            double intersectDistance = intersectDistance(fromSegment);
            if (Double.isInfinite(intersectDistance)) {
                return Vec4.INFINITY;
            }
            if (Double.isNaN(intersectDistance) || intersectDistance < 0.0d || intersectDistance > 1.0d) {
                return null;
            }
            return fromSegment.getPointAt(intersectDistance);
        } else if (distanceTo(vec4) == 0.0d) {
            return vec4;
        } else {
            return null;
        }
    }

    public Vec4[] clip(Vec4 vec4, Vec4 vec42) {
        if (vec4 == null || vec42 == null) {
            throw new IllegalArgumentException("Point Is Null");
        } else if (vec4.equals(vec42)) {
            return null;
        } else {
            Line fromSegment = Line.fromSegment(vec4, vec42);
            double dot3 = this.n.dot3(fromSegment.getDirection());
            int i = (dot3 > 0.0d ? 1 : (dot3 == 0.0d ? 0 : -1));
            if (i != 0) {
                double d = (-this.n.dot4(fromSegment.getOrigin())) / dot3;
                if (d < 0.0d || d > 1.0d) {
                    return null;
                }
                Vec4 pointAt = fromSegment.getPointAt(d);
                return i > 0 ? new Vec4[]{pointAt, vec42} : new Vec4[]{vec4, pointAt};
            } else if (this.n.dot4(fromSegment.getOrigin()) != 0.0d) {
                return null;
            } else {
                return new Vec4[]{vec4, vec42};
            }
        }
    }

    public double distanceTo(Vec4 vec4) {
        return this.n.dot4(vec4);
    }

    public int onSameSide(Vec4 vec4, Vec4 vec42) {
        if (vec4 == null || vec42 == null) {
            throw new IllegalArgumentException("Point Is Null");
        }
        double distanceTo = distanceTo(vec4);
        double distanceTo2 = distanceTo(vec42);
        if (distanceTo >= 0.0d || distanceTo2 >= 0.0d) {
            return (distanceTo <= 0.0d || distanceTo2 <= 0.0d ? 0 : 1);
        }
        return -1;
    }

    public int onSameSide(Vec4[] vec4Arr) {
        if (vec4Arr != null) {
            double distanceTo = distanceTo(vec4Arr[0]);
            int i = distanceTo < 0.0d ? -1 : distanceTo > 0.0d ? 1 : 0;
            if (i == 0) {
                return 0;
            }
            for (int i2 = 1; i2 < vec4Arr.length; i2++) {
                if (vec4Arr[i2] != null) {
                    double distanceTo2 = distanceTo(vec4Arr[i2]);
                    if ((i != -1 || distanceTo2 >= 0.0d && (i != 1 || distanceTo2 <= 0.0d))) {
                        return 0;
                    }
                } else {
                    throw new IllegalArgumentException("Point Is Null");
                }
            }
            return i;
        }
        throw new IllegalArgumentException("Points Array Is Null");
    }

    public static Vec4 intersect(Plane plane, Plane plane2, Plane plane3) {
        if (plane == null || plane2 == null || plane3 == null) {
            throw new IllegalArgumentException("Plane Is Null");
        }
        Vec4 normal = plane.getNormal();
        Vec4 normal2 = plane2.getNormal();
        Vec4 normal3 = plane3.getNormal();
        return new Vec4(-plane.getDistance(), -plane2.getDistance(), -plane3.getDistance()).transformBy3(new Matrix(normal.x, normal.y, normal.z, 0.0d, normal2.x, normal2.y, normal2.z, 0.0d, normal3.x, normal3.y, normal3.z, 0.0d, 0.0d, 0.0d, 0.0d, 1.0d, true).getInverse());
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Plane)) {
            return false;
        }
        Vec4 vec4 = this.n;
        Vec4 vec42 = ((Plane) obj).n;
        if (vec4 == null) {
            if (vec42 == null) {
                return true;
            }
        } else if (vec4.equals(vec42)) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        Vec4 vec4 = this.n;
        if (vec4 != null) {
            return vec4.hashCode();
        }
        return 0;
    }

    public final String toString() {
        return this.n.toString();
    }
}
