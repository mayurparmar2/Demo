package com.gpsvideocamera.videotimestamp.Mgrs;


public class MGRSCoordConverter {
    private static final String BESSEL_1841 = "BR";
    private static final String BESSEL_1841_NAMIBIA = "BN";
    private static final String CLARKE_1866 = "CC";
    private static final String CLARKE_1880 = "CD";
    public static final double DEG_TO_RAD = 0.017453292519943295d;
    private static final int LETTER_A = 0;
    private static final int LETTER_B = 1;
    private static final int LETTER_C = 2;
    private static final int LETTER_D = 3;
    private static final int LETTER_E = 4;
    private static final int LETTER_F = 5;
    private static final int LETTER_G = 6;
    private static final int LETTER_H = 7;
    private static final int LETTER_I = 8;
    private static final int LETTER_J = 9;
    private static final int LETTER_K = 10;
    private static final int LETTER_L = 11;
    private static final int LETTER_M = 12;
    private static final int LETTER_N = 13;
    private static final int LETTER_O = 14;
    private static final int LETTER_P = 15;
    private static final int LETTER_Q = 16;
    private static final int LETTER_R = 17;
    private static final int LETTER_S = 18;
    private static final int LETTER_T = 19;
    private static final int LETTER_U = 20;
    private static final int LETTER_V = 21;
    private static final int LETTER_W = 22;
    private static final int LETTER_X = 23;
    private static final int LETTER_Y = 24;
    private static final int LETTER_Z = 25;
    private static final int MAX_PRECISION = 5;
    private static final double MAX_UTM_LAT = 1.4660765716752369d;
    private static final int MGRS_A_ERROR = 16;
    private static final int MGRS_EASTING_ERROR = 64;
    private static final int MGRS_HEMISPHERE_ERROR = 512;
    private static final int MGRS_INV_F_ERROR = 32;
    private static final int MGRS_LAT_ERROR = 1;
    private static final int MGRS_LAT_WARNING = 1024;
    private static final int MGRS_LETTERS = 3;
    private static final int MGRS_LON_ERROR = 2;
    private static final int MGRS_NORTHING_ERROR = 128;
    private static final int MGRS_NOZONE_WARNING = 2048;
    public static final int MGRS_NO_ERROR = 0;
    private static final int MGRS_PRECISION_ERROR = 8;
    public static final int MGRS_STRING_ERROR = 4;
    private static final int MGRS_UPS_ERROR = 8192;
    private static final int MGRS_UTM_ERROR = 4096;
    private static final int MGRS_ZONE_ERROR = 256;
    private static final double MIN_EAST_NORTH = 0.0d;
    private static final double MIN_UTM_LAT = -1.3962634015954636d;
    private static final double ONEHT = 100000.0d;
    private static final double PI = 3.141592653589793d;
    private static final double PI_OVER_2 = 1.5707963267948966d;
    private static final double RAD_TO_DEG = 57.29577951308232d;
    private static final String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private double false_northing;
    private long lastLetter;
    private double latitude;
    private double longitude;
    private long ltr2_high_value;
    private long ltr2_low_value;
    private double min_northing;
    private double north;
    private double northing_offset;
    private double south;
    private static final long[][] upsConstants = {new long[]{0, 9, 25, 25, 800000, 800000}, new long[]{1, 0, 17, 25, 2000000, 800000}, new long[]{24, 9, 25, 15, 800000, 1300000}, new long[]{25, 0, 9, 15, 2000000, 1300000}};
    private static final double TWOMIL = 2000000.0d;
    private static final double MAX_EAST_NORTH = 4000000.0d;
    private static final double[][] latitudeBandConstants = {new double[]{2.0d, 1100000.0d, -72.0d, -80.5d, 0.0d}, new double[]{3.0d, TWOMIL, -64.0d, -72.0d, TWOMIL}, new double[]{4.0d, 2800000.0d, -56.0d, -64.0d, TWOMIL}, new double[]{5.0d, 3700000.0d, -48.0d, -56.0d, TWOMIL}, new double[]{6.0d, 4600000.0d, -40.0d, -48.0d, MAX_EAST_NORTH}, new double[]{7.0d, 5500000.0d, -32.0d, -40.0d, MAX_EAST_NORTH}, new double[]{9.0d, 6400000.0d, -24.0d, -32.0d, 6000000.0d}, new double[]{10.0d, 7300000.0d, -16.0d, -24.0d, 6000000.0d}, new double[]{11.0d, 8200000.0d, -8.0d, -16.0d, 8000000.0d}, new double[]{12.0d, 9100000.0d, 0.0d, -8.0d, 8000000.0d}, new double[]{13.0d, 0.0d, 8.0d, 0.0d, 0.0d}, new double[]{15.0d, 800000.0d, 16.0d, 8.0d, 0.0d}, new double[]{16.0d, 1700000.0d, 24.0d, 16.0d, 0.0d}, new double[]{17.0d, 2600000.0d, 32.0d, 24.0d, TWOMIL}, new double[]{18.0d, 3500000.0d, 40.0d, 32.0d, TWOMIL}, new double[]{19.0d, 4400000.0d, 48.0d, 40.0d, MAX_EAST_NORTH}, new double[]{20.0d, 5300000.0d, 56.0d, 48.0d, MAX_EAST_NORTH}, new double[]{21.0d, 6200000.0d, 64.0d, 56.0d, 6000000.0d}, new double[]{22.0d, 7000000.0d, 72.0d, 64.0d, 6000000.0d}, new double[]{23.0d, 7900000.0d, 84.5d, 72.0d, 6000000.0d}};
    private double MGRS_a = 6378137.0d;
    private double MGRS_f = 0.0033528106647474805d;
    private String MGRS_Ellipsoid_Code = "WE";
    private String MGRSString = "";
    private long last_error = 0;

    
    
    public class MGRSComponents {
        private final double easting;
        private final int latitudeBand;
        private final double northing;
        private final int precision;
        private final int squareLetter1;
        private final int squareLetter2;
        private final int zone;

        public MGRSComponents(int i, int i2, int i3, int i4, double d, double d2, int i5) {
            this.zone = i;
            this.latitudeBand = i2;
            this.squareLetter1 = i3;
            this.squareLetter2 = i4;
            this.easting = d;
            this.northing = d2;
            this.precision = i5;
        }

        public String toString() {
            return "MGRS: " + this.zone + " " + MGRSCoordConverter.alphabet.charAt(this.latitudeBand) + " " + MGRSCoordConverter.alphabet.charAt(this.squareLetter1) + MGRSCoordConverter.alphabet.charAt(this.squareLetter2) + " " + this.easting + " " + this.northing + " (" + this.precision + ")";
        }
    }

    public long setMGRSParameters(double d, double d2, String str) {
        if (d <= 0.0d) {
            return 16;
        }
        if (d2 == 0.0d) {
            return 32;
        }
        double d3 = 1.0d / d2;
        if (d3 < 250.0d || d3 > 350.0d) {
            return 32;
        }
        this.MGRS_a = d;
        this.MGRS_f = d2;
        this.MGRS_Ellipsoid_Code = str;
        return 0;
    }

    public double getMGRS_f() {
        return this.MGRS_f;
    }

    public double getMGRS_a() {
        return this.MGRS_a;
    }

    private long getLastLetter() {
        return this.lastLetter;
    }

    public String getMGRS_Ellipsoid_Code() {
        return this.MGRS_Ellipsoid_Code;
    }

    public long convertMGRSToGeodetic(String str) {
        this.latitude = 0.0d;
        this.longitude = 0.0d;
        long checkZone = checkZone(str);
        if (checkZone == 0) {
            UTMCoord convertMGRSToUTM = convertMGRSToUTM(str);
            if (convertMGRSToUTM == null) {
                return 4096;
            }
            this.latitude = convertMGRSToUTM.getLatitude().radians;
            this.longitude = convertMGRSToUTM.getLongitude().radians;
            return checkZone;
        } else if (checkZone != 2048) {
            return checkZone;
        } else {
            UPSCoord convertMGRSToUPS = convertMGRSToUPS(str);
            if (convertMGRSToUPS == null) {
                return 8192;
            }
            this.latitude = convertMGRSToUPS.getLatitude().radians;
            this.longitude = convertMGRSToUPS.getLongitude().radians;
            return checkZone;
        }
    }

    public double getLatitude() {
        return this.latitude;
    }

    public double getLongitude() {
        return this.longitude;
    }

    
    
    
    
    
    private MGRSComponents breakMGRSString(String str) {
        int i;
        long j;
        int i2;
        int i3;
        int i4;
        int i5;
        long j2;
        long j3;
        MGRSCoordConverter mGRSCoordConverter;
        int[] iArr = new int[3];
        int i6 = 0;
        while (i6 < str.length() && str.charAt(i6) == ' ') {
            i6++;
        }
        int i7 = i6;
        while (i7 < str.length() && Character.isDigit(str.charAt(i7))) {
            i7++;
        }
        int i8 = i7 - i6;
        if (i8 > 2) {
            j = 0;
        } else if (i8 > 0) {
            int parseInt = Integer.parseInt(str.substring(i6, i7));
            if (parseInt < 1 || parseInt > 60) {
                i = parseInt;
                j = 4;
            } else {
                i = parseInt;
                j = 0;
            }
            i2 = i7;
            while (i2 < str.length() && Character.isLetter(str.charAt(i2))) {
                i2++;
            }
            if (i2 - i7 == 3) {
                iArr[0] = alphabet.indexOf(Character.toUpperCase(str.charAt(i7)));
                if (iArr[0] == 8 || iArr[0] == 14) {
                    j |= 4;
                }
                iArr[1] = alphabet.indexOf(Character.toUpperCase(str.charAt(i7 + 1)));
                if (iArr[1] == 8 || iArr[1] == 14) {
                    j |= 4;
                }
                iArr[2] = alphabet.indexOf(Character.toUpperCase(str.charAt(i7 + 2)));
                if (iArr[2] != 8) {
                }
            }
            j |= 4;
            i3 = i2;
            while (i3 < str.length() && Character.isDigit(str.charAt(i3))) {
                i3++;
            }
            i4 = i3 - i2;
            if (i4 <= 10 || i4 % 2 != 0) {
                j |= 4;
                j3 = 0;
                j2 = 0;
                i5 = 0;
                mGRSCoordConverter = this;
            } else {
                int i9 = i4 / 2;
                if (i9 > 0) {
                    int i10 = i2 + i9;
                    long parseInt2 = (long) Integer.parseInt(str.substring(i2, i10));
                    long parseInt3 = (long) Integer.parseInt(str.substring(i10, i10 + i9));
                    double pow = Math.pow(10.0d, (double) (5 - i9));
                    j2 = (long) (((double) parseInt2) * pow);
                    j3 = (long) (((double) parseInt3) * pow);
                } else {
                    j3 = 0;
                    j2 = 0;
                }
                mGRSCoordConverter = this;
                i5 = i9;
            }
            mGRSCoordConverter.last_error = j;
            if (j != 0) {
                return new MGRSComponents(i, iArr[0], iArr[1], iArr[2], (double) j2, (double) j3, i5);
            }
            return null;
        } else {
            j = 4;
        }
        i = 0;
        i2 = i7;
        while (i2 < str.length()) {
            i2++;
        }
        if (i2 - i7 == 3) {
        }
        j |= 4;
        i3 = i2;
        while (i3 < str.length()) {
            i3++;
        }
        i4 = i3 - i2;
        if (i4 <= 10) {
        }
        j |= 4;
        j3 = 0;
        j2 = 0;
        i5 = 0;
        mGRSCoordConverter = this;
        mGRSCoordConverter.last_error = j;
        if (j != 0) {
        }
        return null;
    }

    private long checkZone(String str) {
        int i = 0;
        while (i < str.length() && str.charAt(i) == ' ') {
            i++;
        }
        int i2 = i;
        while (i2 < str.length() && Character.isDigit(str.charAt(i2))) {
            i2++;
        }
        int i3 = i2 - i;
        if (i3 > 2) {
            return 4;
        }
        if (i3 <= 0) {
            return 2048;
        }
        return 0;
    }

    private long getLatitudeBandMinNorthing(int i) {
        if (i >= 2 && i <= 7) {
            double[][] dArr = latitudeBandConstants;
            int i2 = i - 2;
            this.min_northing = dArr[i2][1];
            this.northing_offset = dArr[i2][4];
        } else if (i >= 9 && i <= 13) {
            double[][] dArr2 = latitudeBandConstants;
            int i3 = i - 3;
            this.min_northing = dArr2[i3][1];
            this.northing_offset = dArr2[i3][4];
        } else if (i < 15 || i > 23) {
            return 4;
        } else {
            double[][] dArr3 = latitudeBandConstants;
            int i4 = i - 4;
            this.min_northing = dArr3[i4][1];
            this.northing_offset = dArr3[i4][4];
        }
        return 0;
    }

    private long getLatitudeRange(int i) {
        if (i >= 2 && i <= 7) {
            double[][] dArr = latitudeBandConstants;
            int i2 = i - 2;
            this.north = dArr[i2][2] * 0.017453292519943295d;
            this.south = dArr[i2][3] * 0.017453292519943295d;
        } else if (i >= 9 && i <= 13) {
            double[][] dArr2 = latitudeBandConstants;
            int i3 = i - 3;
            this.north = dArr2[i3][2] * 0.017453292519943295d;
            this.south = dArr2[i3][3] * 0.017453292519943295d;
        } else if (i < 15 || i > 23) {
            return 4;
        } else {
            double[][] dArr3 = latitudeBandConstants;
            int i4 = i - 4;
            this.north = dArr3[i4][2] * 0.017453292519943295d;
            this.south = dArr3[i4][3] * 0.017453292519943295d;
        }
        return 0;
    }

    
    
    
    private UTMCoord convertMGRSToUTM(String str) {
        UTMCoord uTMCoord;
        double d = 0;
        double pow = 0;
        long latitudeRange = 0;
        MGRSComponents breakMGRSString = breakMGRSString(str);
        long j = 4;
        if (!(breakMGRSString == null || (breakMGRSString.latitudeBand == 23 && (breakMGRSString.zone == 32 || breakMGRSString.zone == 34 || breakMGRSString.zone == 36)))) {
            String str2 = breakMGRSString.latitudeBand < 13 ? AVKey.SOUTH : AVKey.NORTH;
            getGridValues((long) breakMGRSString.zone);
            if (((long) breakMGRSString.squareLetter1) >= this.ltr2_low_value && ((long) breakMGRSString.squareLetter1) <= this.ltr2_high_value && breakMGRSString.squareLetter2 <= 21) {
                j = 0;
            }
            if (j == 0) {
                double d2 = ((double) breakMGRSString.squareLetter2) * ONEHT;
                long j2 = this.ltr2_low_value;
                double d3 = ((double) ((((long) breakMGRSString.squareLetter1) - j2) + 1)) * ONEHT;
                if (j2 == 9 && breakMGRSString.squareLetter1 > 14) {
                    d3 -= ONEHT;
                }
                if (breakMGRSString.squareLetter2 > 14) {
                    d2 -= ONEHT;
                }
                if (breakMGRSString.squareLetter2 > 8) {
                    d2 -= ONEHT;
                }
                if (d2 >= TWOMIL) {
                    d2 -= TWOMIL;
                }
                long latitudeBandMinNorthing = getLatitudeBandMinNorthing(breakMGRSString.latitudeBand);
                if (latitudeBandMinNorthing == 0) {
                    double d4 = d2 - this.false_northing;
                    if (d4 < 0.0d) {
                        d4 += TWOMIL;
                    }
                    double d5 = d4 + this.northing_offset;
                    if (d5 < this.min_northing) {
                        d5 += TWOMIL;
                    }
                    try {
                        uTMCoord = UTMCoord.fromUTM(breakMGRSString.zone, str2, d3 + breakMGRSString.easting, d5 + breakMGRSString.northing);
                        try {
                            d = uTMCoord.getLatitude().radians;
                            pow = Math.pow(10.0d, (double) breakMGRSString.precision);
                            latitudeRange = getLatitudeRange(breakMGRSString.latitudeBand);
                        } catch (Exception unused) {
                            j = 4096;
                            this.last_error = j;
                            if (j != 0) {
                            }
                            return uTMCoord;
                        }
                    } catch (Exception unused2) {
                        uTMCoord = null;
                    }
                    if (latitudeRange == 0) {
                        double d6 = 0.017453292519943295d / pow;
                        if (this.south - d6 <= d) {
                        }
                        j = latitudeRange | 1024;
                        this.last_error = j;
                        if (j != 0 || j == 1024) {
                            return uTMCoord;
                        }
                        return null;
                    }
                    j = latitudeRange;
                    this.last_error = j;
                    if (j != 0) {
                    }
                    return uTMCoord;
                }
                j = latitudeBandMinNorthing;
            }
        }
        uTMCoord = null;
        this.last_error = j;
        if (j != 0) {
        }
        return uTMCoord;
    }

    public long convertGeodeticToMGRS(double d, double d2, int i) {
        long convertUPSToMGRS;
        this.MGRSString = "";
        long j = (d < -1.5707963267948966d || d > 1.5707963267948966d) ? 1 : 0;
        if (d2 < -3.141592653589793d || d2 > 6.283185307179586d) {
            j = 2;
        }
        if (i < 0 || i > 5) {
            j = 8;
        }
        if (j != 0) {
            return j;
        }
        if (d < MIN_UTM_LAT || d > MAX_UTM_LAT) {
            try {
                UPSCoord fromLatLon = UPSCoord.fromLatLon(Angle.fromRadians(d), Angle.fromRadians(d2));
                convertUPSToMGRS = convertUPSToMGRS(fromLatLon.getHemisphere(), Double.valueOf(fromLatLon.getEasting()), Double.valueOf(fromLatLon.getNorthing()), (long) i);
            } catch (Exception unused) {
                return 8192;
            }
        } else {
            try {
                UTMCoord fromLatLon2 = UTMCoord.fromLatLon(Angle.fromRadians(d), Angle.fromRadians(d2));
                convertUPSToMGRS = convertUTMToMGRS((long) fromLatLon2.getZone(), d, fromLatLon2.getEasting(), fromLatLon2.getNorthing(), (long) i);
            } catch (Exception unused2) {
                return 4096;
            }
        }
        return j | convertUPSToMGRS;
    }

    public String getMGRSString() {
        return this.MGRSString;
    }

    private long convertUPSToMGRS(String str, Double d, Double d2, long j) {
        double d3;
        int i;
        double d4;
        long j2;
        long[] jArr = new long[3];
        long j3 = (AVKey.NORTH.equals(str) || AVKey.SOUTH.equals(str)) ? 0 : 512;
        if (d.doubleValue() < 0.0d || d.doubleValue() > MAX_EAST_NORTH) {
            j3 |= 64;
        }
        if (d2.doubleValue() < 0.0d || d2.doubleValue() > MAX_EAST_NORTH) {
            j3 |= 128;
        }
        if (j < 0 || j > 5) {
            j3 |= 8;
        }
        if (j3 == 0) {
            double pow = Math.pow(10.0d, (double) (5 - j));
            Double valueOf = Double.valueOf(roundMGRS(d.doubleValue() / pow) * pow);
            Double valueOf2 = Double.valueOf(roundMGRS(d2.doubleValue() / pow) * pow);
            if (AVKey.NORTH.equals(str)) {
                if (valueOf.doubleValue() >= TWOMIL) {
                    jArr[0] = 25;
                } else {
                    jArr[0] = 24;
                }
                int i2 = ((int) jArr[0]) - 22;
                long[][] jArr2 = upsConstants;
                i = (int) jArr2[i2][1];
                d3 = (double) jArr2[i2][4];
                d4 = (double) jArr2[i2][5];
            } else {
                if (valueOf.doubleValue() >= TWOMIL) {
                    jArr[0] = 1;
                } else {
                    jArr[0] = 0;
                }
                long[][] jArr3 = upsConstants;
                i = (int) jArr3[(int) jArr[0]][1];
                d3 = (double) jArr3[(int) jArr[0]][4];
                d4 = (double) jArr3[(int) jArr[0]][5];
            }
            jArr[2] = (long) ((int) ((valueOf2.doubleValue() - d4) / ONEHT));
            if (jArr[2] > 7) {
                j2 = 1;
                jArr[2] = jArr[2] + 1;
            } else {
                j2 = 1;
            }
            if (jArr[2] > 13) {
                jArr[2] = jArr[2] + j2;
            }
            jArr[1] = (long) (i + ((int) ((valueOf.doubleValue() - d3) / ONEHT)));
            if (valueOf.doubleValue() < TWOMIL) {
                if (jArr[1] > 11) {
                    jArr[1] = jArr[1] + 3;
                }
                if (jArr[1] > 20) {
                    jArr[1] = jArr[1] + 2;
                }
            } else {
                if (jArr[1] > 2) {
                    jArr[1] = jArr[1] + 2;
                }
                if (jArr[1] > 7) {
                    jArr[1] = jArr[1] + 1;
                }
                if (jArr[1] > 11) {
                    jArr[1] = jArr[1] + 3;
                }
            }
            makeMGRSString(0, jArr, valueOf.doubleValue(), valueOf2.doubleValue(), j);
        }
        return j3;
    }

    private long convertUTMToMGRS(long j, double d, double d2, double d3, long j2) {
        long[] jArr = new long[3];
        double pow = Math.pow(10.0d, (double) (5 - j2));
        double roundMGRS = roundMGRS(d2 / pow) * pow;
        double roundMGRS2 = roundMGRS(d3 / pow) * pow;
        getGridValues(j);
        long latitudeLetter = getLatitudeLetter(d);
        jArr[0] = getLastLetter();
        if (latitudeLetter == 0) {
            double d4 = roundMGRS2 == 1.0E7d ? roundMGRS2 - 1.0d : roundMGRS2;
            while (d4 >= TWOMIL) {
                d4 -= TWOMIL;
            }
            double d5 = d4 + this.false_northing;
            if (d5 >= TWOMIL) {
                d5 -= TWOMIL;
            }
            jArr[2] = (long) (d5 / ONEHT);
            if (jArr[2] > 7) {
                jArr[2] = jArr[2] + 1;
            }
            if (jArr[2] > 13) {
                jArr[2] = jArr[2] + 1;
            }
            double d6 = (jArr[0] == 21 && j == 31 && roundMGRS == 500000.0d) ? roundMGRS - 1.0d : roundMGRS;
            long j3 = this.ltr2_low_value;
            jArr[1] = (((long) (d6 / ONEHT)) - 1) + j3;
            if (j3 == 9 && jArr[1] > 13) {
                jArr[1] = jArr[1] + 1;
            }
            makeMGRSString(j, jArr, roundMGRS, roundMGRS2, j2);
        }
        return latitudeLetter;
    }

    private void getGridValues(long j) {
        long j2 = j % 6;
        if (j2 == 0) {
            j2 = 6;
        }
        long j3 = (this.MGRS_Ellipsoid_Code.compareTo(CLARKE_1866) == 0 || this.MGRS_Ellipsoid_Code.compareTo(CLARKE_1880) == 0 || this.MGRS_Ellipsoid_Code.compareTo(BESSEL_1841) == 0 || this.MGRS_Ellipsoid_Code.compareTo(BESSEL_1841_NAMIBIA) == 0) ? 0 : 1;
        if (j2 == 1 || j2 == 4) {
            this.ltr2_low_value = 0;
            this.ltr2_high_value = 7;
        } else if (j2 == 2 || j2 == 5) {
            this.ltr2_low_value = 9;
            this.ltr2_high_value = 17;
        } else if (j2 == 3 || j2 == 6) {
            this.ltr2_low_value = 18;
            this.ltr2_high_value = 25;
        }
        if (j3 == 1) {
            if (j2 % 2 == 0) {
                this.false_northing = 500000.0d;
            } else {
                this.false_northing = 0.0d;
            }
        } else if (j2 % 2 == 0) {
            this.false_northing = 1500000.0d;
        } else {
            this.false_northing = 1000000.0d;
        }
    }

    private long getLatitudeLetter(double d) {
        double d2 = RAD_TO_DEG * d;
        if (d2 >= 72.0d && d2 < 84.5d) {
            this.lastLetter = 23;
        } else if (d2 <= -80.5d || d2 >= 72.0d) {
            return 1;
        } else {
            this.lastLetter = (long) latitudeBandConstants[(int) (((d + 1.3962634015954636d) / 0.13962634015954636d) + 1.0E-12d)][0];
        }
        return 0;
    }

    private double roundMGRS(double d) {
        double floor = Math.floor(d);
        double d2 = d - floor;
        long j = (long) floor;
        int i = (d2 > 0.5d ? 1 : (d2 == 0.5d ? 0 : -1));
        if (i > 0 || (i == 0 && j % 2 == 1)) {
            j++;
        }
        return (double) j;
    }

    private long makeMGRSString(long j, long[] jArr, double d, double d2, long j2) {
        String str;
        if (j != 0) {
            this.MGRSString = String.format("%02d", Long.valueOf(j));
        } else {
            this.MGRSString = "  ";
        }
        for (int i = 0; i < 3; i++) {
            if (jArr[i] < 0 || jArr[i] > 26) {
                return 256;
            }
            this.MGRSString += alphabet.charAt((int) jArr[i]);
        }
        double pow = Math.pow(10.0d, (double) (5 - j2));
        double d3 = d % ONEHT;
        if (d3 >= 99999.5d) {
            d3 = 99999.0d;
        }
        String num = Integer.valueOf((int) ((long) (d3 / pow))).toString();
        if (((long) num.length()) > j2) {
            num = num.substring(0, ((int) j2) - 1);
        } else {
            int length = num.length();
            for (int i2 = 0; ((long) i2) < j2 - ((long) length); i2++) {
                num = "0" + num;
            }
        }
        this.MGRSString += " " + num;
        double d4 = d2 % ONEHT;
        String num2 = Integer.valueOf((int) ((long) ((d4 >= 99999.5d ? 99999.0d : d4) / pow))).toString();
        if (((long) num2.length()) > j2) {
            str = num2.substring(0, ((int) j2) - 1);
        } else {
            int length2 = num2.length();
            for (int i3 = 0; ((long) i3) < j2 - ((long) length2); i3++) {
                num2 = "0" + num2;
            }
            str = num2;
        }
        this.MGRSString += " " + str;
        return 0;
    }

    public long getError() {
        return this.last_error;
    }

    private UPSCoord convertMGRSToUPS(String str) {
        double d;
        long j;
        long j2;
        long j3;
        double d2;
        String str2;
        long j4;
        long j5;
        MGRSComponents breakMGRSString = breakMGRSString(str);
        long j6 = breakMGRSString == null ? this.last_error : 0;
        if (breakMGRSString != null && breakMGRSString.zone > 0) {
            j6 |= 4;
        }
        if (j6 != 0) {
            return null;
        }
        double d3 = breakMGRSString.easting;
        double d4 = breakMGRSString.northing;
        if (breakMGRSString.latitudeBand >= 24) {
            int i = breakMGRSString.latitudeBand - 22;
            long[][] jArr = upsConstants;
            j3 = jArr[i][1];
            j2 = jArr[i][2];
            j = jArr[i][3];
            d2 = (double) jArr[i][5];
            str2 = AVKey.NORTH;
            d = (double) jArr[i][4];
        } else {
            long[][] jArr2 = upsConstants;
            j3 = jArr2[breakMGRSString.latitudeBand][12];
            j2 = jArr2[breakMGRSString.latitudeBand][2];
            j = jArr2[breakMGRSString.latitudeBand][3];
            d = (double) jArr2[breakMGRSString.latitudeBand][4];
            d2 = (double) jArr2[breakMGRSString.latitudeBand][5];
            str2 = AVKey.SOUTH;
        }
        if (((long) breakMGRSString.squareLetter1) < j3 || ((long) breakMGRSString.squareLetter1) > j2 || breakMGRSString.squareLetter1 == 3 || breakMGRSString.squareLetter1 == 4 || breakMGRSString.squareLetter1 == 12 || breakMGRSString.squareLetter1 == 13 || breakMGRSString.squareLetter1 == 21 || breakMGRSString.squareLetter1 == 22 || ((long) breakMGRSString.squareLetter2) > j) {
            j5 = 0;
            j4 = 4;
        } else {
            j4 = j6;
            j5 = 0;
        }
        if (j4 != j5) {
            return null;
        }
        double d5 = (((double) breakMGRSString.squareLetter2) * ONEHT) + d2;
        if (breakMGRSString.squareLetter2 > 8) {
            d5 -= ONEHT;
        }
        if (breakMGRSString.squareLetter2 > 14) {
            d5 -= ONEHT;
        }
        double d6 = (((double) (((long) breakMGRSString.squareLetter1) - j3)) * ONEHT) + d;
        if (j3 != 0) {
            if (breakMGRSString.squareLetter1 > 11) {
                d6 -= 300000.0d;
            }
            if (breakMGRSString.squareLetter1 > 20) {
                d6 -= 200000.0d;
            }
        } else {
            if (breakMGRSString.squareLetter1 > 2) {
                d6 -= 200000.0d;
            }
            if (breakMGRSString.squareLetter1 > 8) {
                d6 -= ONEHT;
            }
            if (breakMGRSString.squareLetter1 > 11) {
                d6 -= 300000.0d;
            }
        }
        return UPSCoord.fromUPS(str2, d6 + d3, d5 + d4);
    }
}
