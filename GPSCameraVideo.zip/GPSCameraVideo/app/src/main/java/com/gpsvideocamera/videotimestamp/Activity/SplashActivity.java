package com.gpsvideocamera.videotimestamp.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.android.billingclient.BuildConfig;
import com.gpsvideocamera.videotimestamp.LocalNotification.AlarmReceiver;
import com.gpsvideocamera.videotimestamp.LocalNotification.AlarmTimingUtils;
import com.gpsvideocamera.videotimestamp.LocalNotification.AppCheckService;
import com.gpsvideocamera.videotimestamp.LocalNotification.FBAnalyticsEventUtils;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.HelperClass;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import java.util.Calendar;


public class SplashActivity extends AppCompatActivity {
    public static final int SPLASH_TIME_OUT = 3000;
    public static final int SPLASH_TIME_OUT_AD = 7000;
    private boolean IS_PRO;
    boolean inBG;
    private HelperClass mHelperClass;
    SP mSP;
    TextView tv_title;
    TextView txtVersion;
    Handler handler = new Handler();
    Runnable runnable = new Runnable() { 
        @Override 
        public final void run() {
            SplashActivity.this.m166x385578d8();
        }
    };

    @Override 
    public void onBackPressed() {
    }

    @Override 
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        HelperClass helperClass = new HelperClass();
        this.mHelperClass = helperClass;
        helperClass.SetLanguage(this);
        setContentView(R.layout.activity_splash);
        SP sp = new SP(this);
        this.mSP = sp;
        this.IS_PRO = sp.getBoolean(this, HelperClass.IS_PURCHESH_OR_NOT, false).booleanValue();
        this.txtVersion = (TextView) findViewById(R.id.txtVersion);
        TextView textView = (TextView) findViewById(R.id.tv_title);
        this.tv_title = textView;
        textView.setText(getResources().getString(R.string._splash_title));
        TextView textView2 = this.txtVersion;
        textView2.setText(getString(R.string.version) + " " + BuildConfig.VERSION_NAME);
        if (!this.IS_PRO) {
            startService(new Intent(this, AppCheckService.class));
            int intValue = this.mSP.getInteger(this, HelperClass.TOTAL_TIME_APP_OPEN, 0).intValue() + 1;
            AlarmReceiver alarmReceiver = new AlarmReceiver();
            AlarmTimingUtils.setLastOpenTime(this, System.currentTimeMillis());
            Calendar instance = Calendar.getInstance();
            instance.setTimeInMillis(AlarmTimingUtils.getLastOpenTime(this));
            instance.set(11, 21);
            instance.set(12, 0);
            instance.set(13, 0);
            instance.set(14, 0);
            instance.add(5, 15);
            alarmReceiver.setAlarm(this, instance.getTimeInMillis(), 51);
            if (intValue == 1) {
                this.mSP.setInteger(this, HelperClass.TOTAL_TIME_APP_OPEN, Integer.valueOf(intValue));
                Calendar instance2 = Calendar.getInstance();
                instance2.set(11, 21);
                instance2.set(12, 0);
                instance2.set(13, 0);
                instance2.set(14, 0);
                instance2.add(5, 1);
                alarmReceiver.setAlarm(this, instance2.getTimeInMillis(), 57);
                return;
            }
            this.mSP.setInteger(this, HelperClass.TOTAL_TIME_APP_OPEN, Integer.valueOf(intValue));
        }
    }

    @Override 
    protected void onResume() {
        super.onResume();
        this.inBG = false;
        boolean booleanValue = new SP(this).getBoolean(this, HelperClass.IS_PURCHESH_OR_NOT, false).booleanValue();
        this.IS_PRO = booleanValue;
        if (booleanValue || !HelperClass.check_internet(this)) {
            this.handler.postDelayed(this.runnable, 3000);
            return;
        }
        this.handler.postDelayed(this.runnable, 7000);
    }

    
    public void continueExecution() {
        Intent intent;
        if (getIntent().hasExtra("noti_code")) {
            int intExtra = getIntent().getIntExtra("noti_code", 0);
            if (intExtra == 1) {
                intent = new Intent(this, CameraActivity.class);
            
            } else if (intExtra == 7) {
                intent = new Intent(this, CameraActivity.class);
            
            } else if (intExtra != 15) {
                intent = new Intent(this, CameraActivity.class);
            } else {
                intent = new Intent(this, InAppPurchaseActivity.class);
            
            }
        } else {
            intent = new Intent(this, CameraActivity.class);
        }
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);
        finish();
    }

    @Override 
    protected void onPause() {
        Handler handler = this.handler;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
        super.onPause();
    }

    
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onStop() {
        this.inBG = true;
        super.onStop();
    }
    public void m166x385578d8() {
        continueExecution();
        finish();
    }
}
