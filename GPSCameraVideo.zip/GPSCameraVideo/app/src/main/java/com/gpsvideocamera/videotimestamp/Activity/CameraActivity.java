package com.gpsvideocamera.videotimestamp.Activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.media.ExifInterface;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.renderscript.RenderScript;
import android.text.Html;
import android.text.Spanned;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.OrientationEventListener;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.SkuDetails;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.demo.example.BuildConfig;
import com.demo.example.R;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.googlecode.mp4parser.BasicContainer;
import com.googlecode.mp4parser.FileDataSourceImpl;
import com.googlecode.mp4parser.authoring.Movie;
import com.googlecode.mp4parser.authoring.Track;
import com.googlecode.mp4parser.authoring.builder.DefaultMp4Builder;
import com.googlecode.mp4parser.authoring.container.mp4.MovieCreator;
import com.googlecode.mp4parser.authoring.tracks.AppendTrack;
import com.gpsvideocamera.videotimestamp.Adapter.FunactionalAdapter;
import com.gpsvideocamera.videotimestamp.Adapter.RatioAdapter;
import com.gpsvideocamera.videotimestamp.Compass.Compass;
import com.gpsvideocamera.videotimestamp.Fragment.MainFragment;
import com.gpsvideocamera.videotimestamp.Fragment.SettingFragment;
import com.gpsvideocamera.videotimestamp.Model.ImageGetSet;
import com.gpsvideocamera.videotimestamp.Model.PostionModel;
import com.gpsvideocamera.videotimestamp.Model.TransferApp;
import com.gpsvideocamera.videotimestamp.Model.UpdateApp;
import com.gpsvideocamera.videotimestamp.Model.ViewModel;
import com.gpsvideocamera.videotimestamp.Utils.Default;
import com.gpsvideocamera.videotimestamp.Utils.HelperClass;
import com.gpsvideocamera.videotimestamp.Utils.MyApplication;
import com.gpsvideocamera.videotimestamp.Utils.MyObject;
import com.gpsvideocamera.videotimestamp.Utils.PurchaseHelper;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import com.gpsvideocamera.videotimestamp.Utils.SP_Keys;
import com.gpsvideocamera.videotimestamp.Utils.SearchHelper;
import com.gpsvideocamera.videotimestamp.Utils.SingleClickListener;
import com.gpsvideocamera.videotimestamp.Utils.SingleMediaScanner;
import com.gpsvideocamera.videotimestamp.Utils.onRecyclerClickListener;
import com.otaliastudios.cameraview.BitmapCallback;
import com.otaliastudios.cameraview.CameraException;
import com.otaliastudios.cameraview.CameraListener;
import com.otaliastudios.cameraview.CameraOptions;
import com.otaliastudios.cameraview.CameraUtils;
import com.otaliastudios.cameraview.CameraView;
import com.otaliastudios.cameraview.PictureResult;
import com.otaliastudios.cameraview.VideoResult;
import com.otaliastudios.cameraview.controls.Flash;
import com.otaliastudios.cameraview.controls.Grid;
import com.otaliastudios.cameraview.controls.Preview;
import com.otaliastudios.cameraview.frame.Frame;
import com.otaliastudios.cameraview.frame.FrameProcessor;
import com.otaliastudios.cameraview.size.AspectRatio;
import com.otaliastudios.cameraview.size.Size;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.lang.ref.WeakReference;
import java.nio.channels.FileChannel;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;


public class CameraActivity extends AppCompatActivity implements OnMapReadyCallback, View.OnClickListener {
    private static final boolean DECODE_BITMAP = false;
    private static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = 5000;
    private static final long MAX_WAIT_TIME = 2000;
    private static final String TAG = "MainActivity";
    private static final String TAG_DATETIME_DIGITIZED = "DateTimeDigitized";
    private static final String TAG_DATETIME_ORIGINAL = "DateTimeOriginal";
    private static final long UPDATE_INTERVAL_IN_MILLISECONDS = 10000;
    private static final boolean USE_FRAME_PROCESSOR = true;
    public static int current_orientation = 0;
    public static boolean functionflag = false;
    public static boolean isFromGal = false;
    public static LinearLayout lin_function;
    static SP mSP;
    public static int ui_rotation;
    private int C_Loc_HP;
    private int C_Loc_VP;
    private int DW;
    private int H_progress_loc;
    private boolean IS_ADS;
    private int V_progress_loc;
    private int address_color;
    String address_line_1;
    AlertDialog alertSimpleDialog;
    private int background_color;
    RelativeLayout banner_native_layout;
    LinearLayout bottomscreenpannel;
    LinearLayout btn_map;
    private CountDownTimer c_timer;
    private CameraView camera;
    String city;
    private Compass compass;
    private int compass_color;
    String country;
    private float currentAzimuth;
    DecimalFormat dFormat;
    private int date_time_color;
    private int display_height;
    private int display_width;
    LinearLayout folder_linear;
    FunactionalAdapter funactionalAdapter;
    FusedLocationProviderClient fusedLocationClient;
    ImageView galleryButton;
    Spanned getAddress_line_1;
    Spanned getaddress;
    ImageView imgCompass;
    ImageView imgMap;
    ImageView imgWeather;
    ImageView img_pasue;
    ImageView img_time;
    boolean isAddress;
    boolean isCompass;
    boolean isCompassFound;
    boolean isDateTime;
    boolean isLatLng;
    boolean isMagneticField;
    boolean isMap;
    boolean isPurchaseQueryPending;
    boolean isRecording;
    boolean isWeather;
    private int lat_lng_color;
    LinearLayout li_address;
    LinearLayout li_compass;
    LinearLayout li_magnetic_field;
    RelativeLayout li_main_stamp_lay;
    LinearLayout li_rightView;
    LinearLayout li_stamp;
    LinearLayout li_weather;
    LinearLayout lin_flashoff;
    LinearLayout lin_flason;
    LinearLayout lin_tackphoto;
    LinearLayout linear_setting;
    LinearLayout linear_templet;
    LinearLayout lny_time;
    private int loc_background_color;
    private int loc_pos;
    private int loc_size;
    private int location_color;
    private Location mCurrentLocation;
    private String mDateFormat;
    private ArrayList<Flash> mFlashvalues;
    private GoogleMap mGMap;
    HelperClass mHelperClass;
    private int mIconValue;
    private int mLatLngType;
    LinearLayout mLinear_Flilename;
    Location mLocation;
    private LocationCallback mLocationCallback;
    private LocationRequest mLocationRequest;
    private LocationSettingsRequest mLocationSettingsRequest;
    private SupportMapFragment mMapView;
    public RatioAdapter mRatioAdapter;
    RelativeLayout mRel_header;
    RelativeLayout mRel_preview;
    private Boolean mRequestingLocationUpdates;
    private Sensor mSensorAccelerometer;
    private SensorManager mSensorManager;
    private SettingsClient mSettingsClient;
    private TimerTask mTimerTask_Date;
    private Timer mTimer_Date;
    RequestQueue mVolleyQueue;
    TypedArray mWeatherIcon;
    private MagneticSensor magneticSensor;
    private int magnetic_field_color;
    Bitmap mapBitmap;
    private float mfTemprature_value;
    RelativeLayout moRelHeader;
    private String msTemprature_type;
    private WeakReference<MyObject> myObjectWeakReference;
    OnBackPressedListener onBackPressedListener;
    private OrientationEventListener orientationEventListener;
    int padding_12;
    int padding_4;
    int padding_6;
    int padding_8;
    RelativeLayout pasue_button;
    List<Purchase> purchaseHistory;
    PurchaseHelper purchaseInAppHelper;
    LinearLayout ratio_linear;
    RecyclerView rv_gride;
    RecyclerView rv_ration;
    float scale;
    SettingFragment settingFragment;
    Bitmap stampBitmap;
    String state;
    RelativeLayout switchCameraButton;
    ImageView takePhotoButton;
    ImageView takeVideoButton;
    LinearLayout tmpl_layout;
    private ArrayList<TransferApp> transferAppList;
    TextView tv_address;
    TextView tv_address_line_1;
    TextView tv_compass;
    TextView tv_flash;
    TextView tv_gride;
    TextView tv_magnetic_field;
    TextView tv_ration;
    TextView tv_timer;
    TextView tv_weather;
    private ArrayList<UpdateApp> updateAppList;
    private boolean view_rotate_animation;
    private int weather_color;
    int width;
    final int REQUEST_CHECK_SETTINGS = 1;
    private final SensorEventListener accelerometerListener = new SensorEventListener() {
        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {
        }

        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
        }
    };
    public boolean is_test = false;
    public int gpsflag = 0;
    int isPermission = 0;
    int stamp_withflag = 0;
    int REQUEST_CODE = 16;
    String cameraType = "video";
    int pasu_flage = 0;
    int play_pasuefalge = 0;
    long timeInMilliseconds = 0;
    long timeSwapBuff = 0;
    long updatedTime = 0;
    ArrayList<String> video_List = new ArrayList<>();
    String[] timer = {"Off", "3x3", "4X4", "PHI"};
    ArrayList<PostionModel> timer_list = new ArrayList<>();
    float bearing = 0.0f;
    String str_compass = "";
    String str_magnaticField = "";
    double oldlate = 0.0d;
    double oldlong = 0.0d;
    float azimuth = 0.0f;
    String mLocationType = Default.AUTOMATIC;
    String ration = "";
    String device_name = "";
    int isStoragePermission = 0;
    boolean doubleBackToExitPressedOnce = false;
    private long startTime = 0;
    private Handler customHandler = new Handler();
    private boolean app_is_paused = false;
    private boolean camera_in_background = false;
    private List<Size> ratio_list = new ArrayList();
    private boolean compassFound = false;
    private Marker marker = null;
    private int isInternetDialog = 0;
    private boolean isTablet = false;
    private int AppCount = 0;
    private Handler mTimerHandler = new Handler();
    private long mLastClickTime = 0;
    private Runnable updateTimerThread = new Runnable() { 
        @Override 
        public void run() {
            timeInMilliseconds = SystemClock.uptimeMillis() - startTime;
            CameraActivity cameraActivity = CameraActivity.this;
            cameraActivity.updatedTime = cameraActivity.timeSwapBuff + timeInMilliseconds;
            int i = (int) (updatedTime / 1000);
            int i2 = i / 60;
            TextView textView = tv_timer;
            textView.setText(String.format("%02d", Integer.valueOf(i2 / 60)) + ":" + String.format("%02d", Integer.valueOf(i2)) + ":" + String.format("%02d", Integer.valueOf(i % 60)));
            customHandler.postDelayed(this, 0);
        }
    };


    public interface OnBackPressedListener {
        void onBackPressed();
    }

    public static double round(double d, int i) {
        if (i >= 0) {
            double pow = (double) ((long) Math.pow(10.0d, (double) i));
            return ((double) Math.round(d * pow)) / pow;
        }
        throw new IllegalArgumentException();
    }

    public void setRatio() {
        List<Size> supportedPictureSize = this.camera.getSupportedPictureSize();
        if (supportedPictureSize != null && supportedPictureSize.size() > 0) {
            int intValue = mSP.getInteger(this, SP.getRatioPos_Key(this.camera.getCameraId()), this.mHelperClass.setposratio(this, supportedPictureSize)).intValue();
            AspectRatio flip = AspectRatio.of(supportedPictureSize.get(intValue)).flip();
            Size size = supportedPictureSize.get(intValue);
            this.ration = HelperClass.getAspectRatioMPString(getResources(), size.getWidth(), size.getHeight(), USE_FRAME_PROCESSOR, 1) + " ";
            this.camera.setRatioValue(supportedPictureSize.get(intValue));
            this.camera.getLayoutParams().height = getRatioH(flip.getX(), flip.getY());
            this.camera.getLayoutParams().width = getRatioW(flip.getX(), flip.getY());
            ((RelativeLayout.LayoutParams) this.camera.getLayoutParams()).addRule(13);
            this.camera.requestLayout();
            this.camera.invalidate();
            new Handler().postDelayed(new Runnable() { 
                @Override 
                public void run() {
                    setPreviewRotation(CameraActivity.ui_rotation);
                }
            }, 100);
        }
    }

    private int getRatioH(int i, int i2) {
        return (i * this.display_width) / i2;
    }

    public int getRatioW(int i, int i2) {
        return (i2 * this.display_height) / i;
    }

    public void setOnBackPressedListener(OnBackPressedListener onBackPressedListener) {
        this.onBackPressedListener = onBackPressedListener;
    }

    void DelayToclick() {
        this.takePhotoButton.setEnabled(false);
        this.takeVideoButton.setEnabled(false);
        this.galleryButton.setEnabled(false);
        this.pasue_button.setEnabled(false);
        this.switchCameraButton.setEnabled(false);
        new Handler().postDelayed(new Runnable() { 
            @Override 
            public void run() {
                takePhotoButton.setEnabled(CameraActivity.USE_FRAME_PROCESSOR);
                takeVideoButton.setEnabled(CameraActivity.USE_FRAME_PROCESSOR);
                galleryButton.setEnabled(CameraActivity.USE_FRAME_PROCESSOR);
                pasue_button.setEnabled(CameraActivity.USE_FRAME_PROCESSOR);
                switchCameraButton.setEnabled(CameraActivity.USE_FRAME_PROCESSOR);
            }
        }, 500);
    }

    @Override 
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            OnBackPressedListener onBackPressedListener = this.onBackPressedListener;
            if (onBackPressedListener != null) {
                onBackPressedListener.onBackPressed();
            }
            updateGalleryIcon();
        } else if (this.doubleBackToExitPressedOnce) {
            System.gc();
            super.onBackPressed();
        } else {
            this.doubleBackToExitPressedOnce = USE_FRAME_PROCESSOR;
            Snackbar.make(findViewById(R.id.rl_home_main), "Press once again to exit", -Toast.LENGTH_LONG).show();
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { 
                @Override 
                public void run() {
                    doubleBackToExitPressedOnce = false;
                }
            }, MAX_WAIT_TIME);
        }
    }


    @Override
    
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        HelperClass helperClass = new HelperClass();
        this.mHelperClass = helperClass;
        helperClass.SetLanguage(this);
        if (Build.VERSION.SDK_INT >= 23) {
            getWindow().addFlags(Integer.MIN_VALUE);
            getWindow().setStatusBarColor(getColor(R.color.black));
        }
        this.mHelperClass = new HelperClass();
        setContentView(R.layout.activity_camera);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.display_width = displayMetrics.widthPixels;
        this.display_height = displayMetrics.heightPixels;
        init();
        this.magneticSensor.clearDialog();
        this.mVolleyQueue = Volley.newRequestQueue(this);
        this.tv_address_line_1 = (TextView) findViewById(R.id.tv_address_line_1);
        this.tv_address = (TextView) findViewById(R.id.tv_address);
        this.tv_weather = (TextView) findViewById(R.id.tv_weather);
        this.tv_compass = (TextView) findViewById(R.id.tv_compass);
        this.tv_magnetic_field = (TextView) findViewById(R.id.tv_magnetic_field);
        this.imgMap = (ImageView) findViewById(R.id.imgMap);
        this.li_stamp = (LinearLayout) findViewById(R.id.li_stamp);
        this.li_compass = (LinearLayout) findViewById(R.id.li_compass);
        this.imgCompass = (ImageView) findViewById(R.id.imgCompass);
        this.imgWeather = (ImageView) findViewById(R.id.imgWeather);
        this.li_rightView = (LinearLayout) findViewById(R.id.li_rightView);
        this.li_magnetic_field = (LinearLayout) findViewById(R.id.li_magnetic_field);
        this.li_weather = (LinearLayout) findViewById(R.id.li_weather);
        this.li_address = (LinearLayout) findViewById(R.id.li_address);
        this.li_main_stamp_lay = (RelativeLayout) findViewById(R.id.li_main_stamp_lay);
        this.tmpl_layout = (LinearLayout) findViewById(R.id.Temp_stamp_layout);
        updateGrid();
        setUpFlash();
        setupCompass();
        setUpOrientation();
        createSaveFolder();
        this.device_name = Build.MANUFACTURER;
        this.dFormat = new DecimalFormat("#.######");

        initLocation();

        callWeatherApi();
        initmap();
        new Handler().postDelayed(new Runnable() { 
            @Override 
            public void run() {
                IS_ADS = CameraActivity.mSP.getBoolean(CameraActivity.this, HelperClass.IS_PURCHESH_OR_NOT, false).booleanValue();
            }
        }, 300);
    }
    private void init() {
        this.padding_4 = getResources().getDimensionPixelOffset(R.dimen._4dp);
        this.padding_12 = getResources().getDimensionPixelOffset(R.dimen._12dp);
        this.padding_6 = getResources().getDimensionPixelOffset(R.dimen._6dp);
        this.padding_8 = getResources().getDimensionPixelOffset(R.dimen._8dp);
        this.camera = (CameraView) findViewById(R.id.camera);
        this.mRel_preview = (RelativeLayout) findViewById(R.id.rel_preview);
        this.mRel_header = (RelativeLayout) findViewById(R.id.rel_header);
        this.camera.setLifecycleOwner(this);
        this.camera.addCameraListener(new Listener());
        this.camera.addFrameProcessor(new FrameProcessor() {
            private long lastTime = System.currentTimeMillis();

            @Override
            public void process(Frame frame) {
                this.lastTime = frame.getTime();
            }
        });
        mSP = new SP(this);
        this.magneticSensor = new MagneticSensor(this);
        this.switchCameraButton = (RelativeLayout) findViewById(R.id.switch_camera);
        this.pasue_button = (RelativeLayout) findViewById(R.id.pasue_camera);
        this.img_pasue = (ImageView) findViewById(R.id.img_pasue);
        this.galleryButton = (ImageView) findViewById(R.id.img_gallery);
        this.lin_tackphoto = (LinearLayout) findViewById(R.id.lin_tackphoto);
        this.moRelHeader = (RelativeLayout) findViewById(R.id.rel_header);
        this.mLinear_Flilename = (LinearLayout) findViewById(R.id.linear_filename);
        this.folder_linear = (LinearLayout) findViewById(R.id.folder_linear);
        this.bottomscreenpannel = (LinearLayout) findViewById(R.id.bottomscreenpannel);
        this.btn_map = (LinearLayout) findViewById(R.id.lny_map);
        this.linear_setting = (LinearLayout) findViewById(R.id.linear_setting);
        this.linear_templet = (LinearLayout) findViewById(R.id.linear_templet);
        lin_function = (LinearLayout) findViewById(R.id.lin_function);
        this.lin_flashoff = (LinearLayout) findViewById(R.id.lin_flash_off);
        this.lin_flason = (LinearLayout) findViewById(R.id.lin_flash_on);
        this.tv_flash = (TextView) findViewById(R.id.tv_flash);
        this.tv_gride = (TextView) findViewById(R.id.tv_grid);
        this.tv_ration = (TextView) findViewById(R.id.tv_ration);
        this.rv_gride = (RecyclerView) findViewById(R.id.rv_grid);
        this.rv_ration = (RecyclerView) findViewById(R.id.rv_ration);
        this.btn_map.setOnClickListener(new SingleClickListener() { 
            @Override 
            public void performClick(View view) {
                setUpFlash();
                startActivity(new Intent(CameraActivity.this, Location_Activity.class));
            }
        });
        this.linear_setting.setOnClickListener(new SingleClickListener() { 
            @Override 
            public void performClick(View view) {
                if (SystemClock.elapsedRealtime() - mLastClickTime >= 1000) {
                    mLastClickTime = SystemClock.elapsedRealtime();
                    setUpFlash();
                    settingFragment = new SettingFragment();
                    CameraActivity cameraActivity = CameraActivity.this;
                    cameraActivity.callFragment(cameraActivity.settingFragment, "SettingFragment");
                }
            }
        });
        this.linear_templet.setOnClickListener(new SingleClickListener() { 
            @Override 
            public void performClick(View view) {
                setUpFlash();
                callFragment(new MainFragment(), "MainFragment");
                closePopup();
            }
        });
        lin_function.setOnTouchListener(new View.OnTouchListener() { 
            @Override 
            public boolean onTouch(View view, MotionEvent motionEvent) {
                CameraActivity.functionflag = false;
                CameraActivity.lin_function.setVisibility(View.GONE);
                return CameraActivity.USE_FRAME_PROCESSOR;
            }
        });
        this.folder_linear.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public void onClick(View view) {
                setUpFlash();
                startActivity(new Intent(CameraActivity.this, FolderActivity.class));
            }
        });
        this.ratio_linear = (LinearLayout) findViewById(R.id.ratio_linear);
        this.takePhotoButton = (ImageView) findViewById(R.id.take_photo);
        this.takeVideoButton = (ImageView) findViewById(R.id.take_video);
        this.tv_timer = (TextView) findViewById(R.id.tv_timer);
        this.lny_time = (LinearLayout) findViewById(R.id.lin_timer);
        this.img_time = (ImageView) findViewById(R.id.img_timer);
        this.takePhotoButton.setOnClickListener(this);
        this.takeVideoButton.setOnClickListener(this);
        this.mLinear_Flilename.setOnClickListener(this);
        this.galleryButton.setOnClickListener(this);
        this.switchCameraButton.setOnClickListener(this);
        this.pasue_button.setOnClickListener(this);
        this.ratio_linear.setOnClickListener(new SingleClickListener() { 
            @Override 
            public void performClick(View view) {
                setUpFlash();
                fuctionality();
            }
        });
        if (this.cameraType.equals("camera")) {
            setModePhoto();
            this.mRel_header.setVisibility(View.VISIBLE);
        } else {
            setModeVideo();
        }
        refrece_data();
        refrece_grid();
        refreshflash();
        this.lin_flashoff.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public void onClick(View view) {
                SP sp = CameraActivity.mSP;
                CameraActivity cameraActivity = CameraActivity.this;
                sp.setInteger(cameraActivity, SP_Keys.getFlashPos(cameraActivity.camera.getCameraId()), 0);
                Setflashback(0);
                updateCycleFlashIcon();
                CameraActivity.functionflag = false;
                CameraActivity.lin_function.setVisibility(View.GONE);
            }
        });
        this.lin_flason.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public void onClick(View view) {
                SP sp = CameraActivity.mSP;
                CameraActivity cameraActivity = CameraActivity.this;
                sp.setInteger(cameraActivity, SP_Keys.getFlashPos(cameraActivity.camera.getCameraId()), 3);
                Setflashback(3);
                updateCycleFlashIcon();
                CameraActivity.functionflag = false;
                CameraActivity.lin_function.setVisibility(View.GONE);
            }
        });
        openShareRateDialog();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.DW = displayMetrics.heightPixels;
        this.scale = displayMetrics.scaledDensity;
    }

    private void setupCompass() {
        this.compass = new Compass(this);
        Compass.CompassListener r0 = new Compass.CompassListener() { 
            @Override 
            public void onNewAzimuth(float f) {
                adjustArrow(f);
            }

            @Override 
            public void onMagField(float f) {
                MagField(f);
            }
        };
        this.compass.setListener(r0);
        Compass compass = this.compass;
        if (compass != null) {
            compass.setListener(r0);
            if (this.compass.getStatus()) {
                this.compassFound = USE_FRAME_PROCESSOR;
                mSP.setBoolean(this, SP.COMPASS_FOUND, Boolean.valueOf((boolean) USE_FRAME_PROCESSOR));
                return;
            }
            mSP.setBoolean(this, SP.COMPASS_FOUND, false);
        }
    }

    @Override
    
    public void onLowMemory() {
        super.onLowMemory();
        SupportMapFragment supportMapFragment = this.mMapView;
        if (supportMapFragment != null) {
            supportMapFragment.onLowMemory();
        }
    }

    @Override 
    public void onMapReady(GoogleMap googleMap) {
        this.mGMap = googleMap;
        setMapType();
        if (this.mLocationType.equals(Default.MANUAL)) {
            loadMap();
        }
    }

    public void MagField(float f) {
        this.str_magnaticField = f + " μT";
        if (CameraView.Stop_video == 0) {
            mSP.setString(this, SP.MAGNETIC_FIELD_VALUE, this.str_magnaticField);
            this.tv_magnetic_field.setText(this.str_magnaticField);
        }
    }

    private void setMapType() {
        if (this.mGMap != null) {
            String string = mSP.getString(this, SP.MAP_TYPE_TEMPLATE, Default.NORMAL_1);
            string.hashCode();
            char c = 65535;
            switch (string.hashCode()) {
                case -1579103941:
                    if (string.equals(Default.SETELLITE_2)) {
                        c = 0;
                        break;
                    }
                    break;
                case -1423437003:
                    if (string.equals(Default.TERRAIN_3)) {
                        c = 1;
                        break;
                    }
                    break;
                case -1202757124:
                    if (string.equals(Default.HYBRID_4)) {
                        c = 2;
                        break;
                    }
                    break;
                case 1366708796:
                    if (string.equals(Default.NORMAL_1)) {
                        c = 3;
                        break;
                    }
                    break;
            }
            switch (c) {
                case 0:
                    this.mGMap.setMapType(2);
                    return;
                case 1:
                    this.mGMap.setMapType(3);
                    return;
                case 2:
                    this.mGMap.setMapType(4);
                    return;
                case 3:
                    this.mGMap.setMapType(1);
                    return;
                default:
                    return;
            }
        }
    }

    public void adjustArrow(float f) {
        if (this.compass.getSensorData()) {
            this.azimuth = f;
            float f2 = (this.bearing - f) * -1.0f;
            if (CameraView.Stop_video == 0) {
                RotateAnimation rotateAnimation = new RotateAnimation(-this.currentAzimuth, -f2, 1, 0.5f, 1, 0.5f);
                this.currentAzimuth = f2;
                rotateAnimation.setDuration(500);
                rotateAnimation.setRepeatCount(0);
                rotateAnimation.setFillAfter(USE_FRAME_PROCESSOR);
                this.imgCompass.startAnimation(rotateAnimation);
            }
            showDirection(f2);
        }
    }

    private void startDateTimer() {
        this.mTimer_Date = new Timer();
        TimerTask r2 = new TimerTask() { 
            @Override 
            public void run() {
                mTimerHandler.post(new Runnable() {
                    @Override 
                    public void run() {
                        setDate();
                    }
                });
            }
        };
        this.mTimerTask_Date = r2;
        this.mTimer_Date.schedule(r2, 1, 1000);
    }

    private void openShareRateDialog() {
        this.AppCount = mSP.getInteger(this, HelperClass.KEY_COUNT, 0).intValue() + 1;
        mSP.setInteger(this, HelperClass.KEY_COUNT, Integer.valueOf(this.AppCount));
        if (this.AppCount % 5 == 0 && !mSP.getBoolean(this, HelperClass.SHARE).booleanValue()) {
            HelperClass.showShareDialog(this);
        }
        if (this.AppCount % 9 == 0 && !mSP.getBoolean(this, HelperClass.RATE).booleanValue()) {
            HelperClass.showSayThanksDialog(this);
        }
    }

    public void setDate() {
        String str;
        String str2 = this.city;
        String str3 = "";
        if (str2 == null || str2.isEmpty()) {
            str = str3;
        } else {
            str = str3 + str3 + this.city + ", ";
        }
        String str4 = this.state;
        if (str4 != null && !str4.isEmpty()) {
            str = str + str3 + this.state + ", ";
        }
        String str5 = this.country;
        if (str5 != null && !str5.isEmpty()) {
            str = str + this.country;
        }
        if (str != null && str.endsWith(", ")) {
            str = str.substring(0, str.length() - 2);
        }
        String str6 = this.address_line_1;
        if (str6 != null && !str6.isEmpty()) {
            if (this.address_line_1.equalsIgnoreCase("null")) {
                this.address_line_1 = "Loading";
            }
            str3 = getColoredSpanned(this.address_line_1, this.address_color);
        }
        String coloredSpanned = getColoredSpanned(this.mHelperClass.getLatLong(this, this.mLatLngType), this.lat_lng_color);
        if (coloredSpanned != null && coloredSpanned.length() > 55 && this.isMap && !this.isMagneticField && this.isDateTime && !this.isWeather && !this.isCompass) {
            if (mSP.getInteger(this, "lat_lng_type_temp_1", 1).intValue() == 6) {
                String[] split = coloredSpanned.split(" Lat");
                coloredSpanned = split[0] + "<br/>Lat " + split[1];
            } else {
                String[] split2 = coloredSpanned.split(" Long");
                coloredSpanned = split2[0] + "<br/>Long " + split2[1];
            }
        }
        boolean z = this.isAddress;
        if (z) {
            if (this.isLatLng) {
                str3 = str3 + "<br/>" + coloredSpanned;
            }
        } else if (this.isLatLng && !z) {
            str3 = coloredSpanned;
        }
        if (this.isDateTime) {
            String coloredSpanned2 = getColoredSpanned(HelperClass.setDateTimeFormat(this.mDateFormat), this.date_time_color);
            if (this.isAddress || this.isLatLng) {
                str3 = str3 + "<br/>" + coloredSpanned2;
            } else {
                str3 = coloredSpanned2;
            }
        }
        if (str3.contains("null")) {
            str3 = str3.replace("null", "Loading");
        }
        this.tv_address_line_1.setText(Html.fromHtml(str3));
        this.getAddress_line_1 = Html.fromHtml(str3);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(this.li_stamp.getLayoutParams().width, this.li_stamp.getLayoutParams().height);
        if (CameraView.Stop_video == 0) {
            if (!this.isMap || this.mapBitmap == null) {
                layoutParams.setMargins(0, 0, 0, 0);
                this.imgMap.setVisibility(View.GONE);
            } else {
                this.imgMap.setVisibility(View.VISIBLE);
                this.imgMap.setImageBitmap(this.mapBitmap);
                layoutParams.setMargins(getResources().getDimensionPixelOffset(R.dimen._8dp), 0, 0, 0);
            }
            this.li_stamp.setLayoutParams(layoutParams);
            mapSnapshot();
        }
        if (str == null || str.isEmpty() || !this.isAddress) {
            this.tv_address.setVisibility(View.GONE);
        } else {
            this.tv_address.setVisibility(View.VISIBLE);
            String coloredSpanned3 = getColoredSpanned(str, this.address_color);
            this.tv_address.setText(Html.fromHtml(coloredSpanned3));
            this.getaddress = Html.fromHtml(coloredSpanned3);
        }
        if (this.msTemprature_type.equals("Celsius")) {
            this.tv_weather.setText(HelperClass.getCelcius(this.mfTemprature_value));
        } else {
            this.tv_weather.setText(HelperClass.getFahrenheit(this.mfTemprature_value));
        }
        if (CameraView.Stop_video == 1) {
            this.tv_compass.setText(this.str_compass);
            this.tv_magnetic_field.setText(this.str_magnaticField);
        }
    }

    public String getColoredSpanned(String str, int i) {
        return "<font color=" + i + ">" + str + "</font>";
    }

    public void setUpStampLayout() {
        boolean z;
        boolean z2;
        boolean z3;
        setMapType();
        startDateTimer();
        this.mWeatherIcon = getResources().obtainTypedArray(R.array.wI);
        this.li_main_stamp_lay.setVisibility(View.VISIBLE);
        this.background_color = mSP.getInteger(this, SP.BACKGROUND_COLOR, Color.parseColor("#9c000000")).intValue();
        this.isMap = mSP.getBoolean(this, SP.IS_MAP, Default.IS_MAP).booleanValue();
        this.isAddress = mSP.getBoolean(this, SP.IS_ADDRESS, Default.IS_ADDRESS).booleanValue();
        this.isLatLng = mSP.getBoolean(this, SP.IS_LAT_LNG_TEMPLATE, Default.IS_LAT_LNG_TEMPLATE).booleanValue();
        this.isWeather = mSP.getBoolean(this, SP.IS_WEATHER, Default.IS_WEATHER).booleanValue();
        this.isDateTime = mSP.getBoolean(this, SP.IS_DATE_TIME, Default.IS_DATE_TIME).booleanValue();
        this.isMagneticField = mSP.getBoolean(this, SP.IS_MAGNETIC_FIELD, Default.IS_MAGNETIC_FIELD).booleanValue();
        this.isCompass = mSP.getBoolean(this, SP.IS_COMPASS, Default.IS_COMPASS).booleanValue();
        this.isCompassFound = mSP.getBoolean(this, SP.COMPASS_FOUND, false).booleanValue();
        this.address_color = mSP.getInteger(this, SP.ADDRESS_COLOR, -1).intValue();
        this.date_time_color = mSP.getInteger(this, SP.DATE_TIME_COLOR, -1).intValue();
        this.lat_lng_color = mSP.getInteger(this, SP.LAT_LNG_COLOR, -1).intValue();
        this.weather_color = mSP.getInteger(this, SP.WEATHER_COLOR, -1).intValue();
        this.magnetic_field_color = mSP.getInteger(this, SP.MAGNETIC_FIELD_COLOR, -1).intValue();
        this.compass_color = mSP.getInteger(this, SP.COMPASS_COLOR, -1).intValue();
        this.mDateFormat = mSP.getString(this, SP.DATE_FORMAT, Default.DEFAULT_DATE_FORMAT);
        this.mLatLngType = mSP.getInteger(this, SP.LAT_LNG_TYPE, 1).intValue();
        this.msTemprature_type = mSP.getString(this, SP.TEMPRATURE_TYPE, "Celsius");
        this.mfTemprature_value = mSP.getFloat(this, SP.TEMPRETURE_VALUE).floatValue();
        this.mIconValue = mSP.getInteger(this, SP.WEATHER_ICON, 0).intValue();
        if (this.isMap) {
            this.imgMap.setVisibility(View.VISIBLE);
        } else {
            this.imgMap.setVisibility(View.GONE);
        }
        if (this.isWeather) {
            this.li_weather.setVisibility(View.VISIBLE);
        } else {
            this.li_weather.setVisibility(View.GONE);
        }
        if (this.isCompassFound) {
            if (this.isMagneticField) {
                this.li_magnetic_field.setVisibility(View.VISIBLE);
            } else {
                this.li_magnetic_field.setVisibility(View.GONE);
            }
            if (this.isCompass) {
                this.li_compass.setVisibility(View.VISIBLE);
            } else {
                this.li_compass.setVisibility(View.GONE);
            }
        } else {
            this.li_magnetic_field.setVisibility(View.GONE);
            this.li_compass.setVisibility(View.GONE);
        }
        if (this.isWeather || this.isMagneticField || this.isCompass) {
            this.li_rightView.setVisibility(View.VISIBLE);
        } else {
            this.li_rightView.setVisibility(View.GONE);
        }
        if (this.isAddress) {
            this.tv_address_line_1.setMaxLines(10);
        } else if (this.isMap || (((z3 = this.isWeather) || this.isMagneticField || this.isCompass || this.isLatLng || !this.isDateTime) && ((z3 || this.isMagneticField || this.isCompass || this.isDateTime || !this.isLatLng) && (((!z3 && !this.isCompass && !this.isMagneticField) || !this.isDateTime || this.isLatLng) && ((!z3 && !this.isCompass && !this.isMagneticField) || this.isDateTime || !this.isLatLng))))) {
            this.tv_address_line_1.setMaxLines(10);
        } else {
            this.tv_address_line_1.setMaxLines(1);
        }
        if (this.isMap) {
            boolean z4 = this.isAddress;
            if (z4 && this.isLatLng) {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 0.0f, getResources().getDisplayMetrics()), 1.0f);
            } else if (z4 && (this.isWeather || this.isMagneticField || this.isCompass)) {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 2.0f, getResources().getDisplayMetrics()), 1.0f);
            } else if (this.isWeather || this.isMagneticField || this.isCompass) {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 5.0f, getResources().getDisplayMetrics()), 1.0f);
            } else {
                this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 2.0f, getResources().getDisplayMetrics()), 1.2f);
            }
            this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
        } else {
            boolean z5 = this.isLatLng;
            if (z5 || this.isAddress || this.isMagneticField || this.isWeather || this.isCompass) {
                boolean z6 = this.isAddress;
                if (!z6) {
                    this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 2.0f, getResources().getDisplayMetrics()), 1.2f);
                    if ((this.isDateTime || this.isLatLng) && (this.tv_address_line_1.getMaxLines() != 1 || (((z = this.isCompass) || this.isMagneticField || this.isWeather) && ((!(z2 = this.isWeather) || z || this.isMagneticField) && ((!z || z2 || this.isMagneticField) && (!this.isMagneticField || z2 || z)))))) {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_90dp);
                    } else {
                        this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_70dp);
                    }
                } else if (!z6 || z5) {
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                } else {
                    this.tv_address_line_1.setLineSpacing(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 2.0f, getResources().getDisplayMetrics()), 1.2f);
                    this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_icon_size_110);
                }
            } else {
                this.li_stamp.getLayoutParams().height = (int) getResources().getDimension(R.dimen.stamp_70dp);
            }
        }
        if (this.isAddress || this.isLatLng || this.isDateTime) {
            this.li_address.setVisibility(View.VISIBLE);
            this.li_rightView.setOrientation(LinearLayout.VERTICAL);
            this.li_rightView.setGravity(19);
            this.li_rightView.getLayoutParams().width = -2;
            this.li_rightView.getLayoutParams().width = -2;
        } else {
            this.li_address.setVisibility(View.GONE);
            this.li_rightView.setOrientation(LinearLayout.HORIZONTAL);
            this.li_rightView.setGravity(17);
            this.li_rightView.getLayoutParams().width = -1;
            this.li_rightView.getLayoutParams().width = -1;
        }
        this.V_progress_loc = mSP.getInteger(this, SP.LOVP, 0).intValue();
        this.H_progress_loc = mSP.getInteger(this, SP.LOHP, 0).intValue();
        this.C_Loc_HP = mSP.getInteger(this, SP.C_LOHP, 100).intValue();
        this.C_Loc_VP = mSP.getInteger(this, SP.C_LOVP, 100).intValue();
        ((GradientDrawable) this.li_stamp.getBackground().getCurrent()).setColor(this.background_color);
        this.tv_weather.setTextColor(this.weather_color);
        this.tv_magnetic_field.setTextColor(this.magnetic_field_color);
        this.tv_compass.setTextColor(this.compass_color);
        this.imgWeather.setImageResource(this.mWeatherIcon.getResourceId(this.mIconValue, 0));
    }

    private void initmap() {
        SupportMapFragment supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapView);
        this.mMapView = supportMapFragment;
        if (supportMapFragment != null) {
            supportMapFragment.getMapAsync(this);
        }
        this.address_line_1 = mSP.getString(this, SP.LOC_LINE_1_ADDRESS, "").trim();
        this.city = mSP.getString(this, SP.LOC_LINE_2_CITY, "").trim();
        this.state = mSP.getString(this, SP.LOC_LINE_3_STATE, "").trim();
        this.country = mSP.getString(this, SP.LOC_LINE_4_COUNTRY, "").trim();
    }

    public void initLocation() {
        Log.e(TAG, "initLocation");
        mSP.setBoolean(this, SP.IS_CALL_WEATHER_API, Boolean.valueOf((boolean) USE_FRAME_PROCESSOR));

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        
        mLocationRequest = LocationRequest.create();
        mLocationRequest.setInterval(10000);
        mLocationRequest.setFastestInterval(5000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        
        mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);
                if (locationResult == null) {
                    return;
                }
                Log.e(TAG, "onLocationResult 1111111111: "+locationResult.getLocations());
                for (android.location.Location location : locationResult.getLocations()) {
                    if (location != null) {
                        mLocation = location;
                        doWorkWithNewLocation(location);
                    }
                }
            }
        };

        this.fusedLocationClient = LocationServices.getFusedLocationProviderClient((Activity) this);
        this.mLocationRequest = new LocationRequest().create();
        this.mLocationRequest.setInterval(10000);
        this.mLocationRequest.setFastestInterval(5000);
        this.mLocationRequest.setMaxWaitTime(MAX_WAIT_TIME);
        this.mLocationRequest.setPriority(100);
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        builder.addLocationRequest(this.mLocationRequest);
        this.mLocationSettingsRequest = builder.build();

        this.mLocationCallback = new LocationCallback() { 
            @Override 
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);
                Log.e(TAG, "onLocationResult 1111111111: "+locationResult.getLocations());
                for (Location location : locationResult.getLocations()) {
                    if (location != null) {
                        mLocation = location;
                        doWorkWithNewLocation(location);
                    }
                }
            }
        };
    }

    public void doWorkWithNewLocation(Location location) {
        Log.e(":::location:::", "doWorkWithNewLocation: " + location.getLatitude() + " :::longitude:: " + location.getLongitude());
        String string = mSP.getString(this, SP.LOCATION_TYPE, Default.AUTOMATIC);
        if (string != null && !string.isEmpty() && string.equals(Default.AUTOMATIC)) {
            double latitude = location.getLatitude();
            double longitude = location.getLongitude();
            try {
                List<Address> fromLocation = new Geocoder(this, Locale.getDefault()).getFromLocation(latitude, longitude, 1);
                if (fromLocation != null && !fromLocation.isEmpty() && fromLocation.size() > 0) {
                    String addressLine = fromLocation.get(0).getAddressLine(0);
                    String locality = fromLocation.get(0).getLocality();
                    String adminArea = fromLocation.get(0).getAdminArea();
                    String countryName = fromLocation.get(0).getCountryName();
                    if (latitude != 0.0d) {
                        String format = this.dFormat.format(latitude);
                        if (format.contains(",")) {
                            format = format.replace(",", ".");
                        }
                        mSP.setString(this, SP.LATITUDE, format);
                    }
                    if (longitude != 0.0d) {
                        String format2 = this.dFormat.format(longitude);
                        if (format2.contains(",")) {
                            format2 = format2.replace(",", ".");
                        }
                        mSP.setString(this, SP.LONGITUDE, format2);
                    }
                    if (addressLine != null) {
                        this.address_line_1 = addressLine;
                        mSP.setString(this, SP.LOC_LINE_1_ADDRESS, addressLine);
                    }
                    if (locality != null) {
                        this.city = locality;
                        mSP.setString(this, SP.LOC_LINE_2_CITY, locality);
                    }
                    if (adminArea != null) {
                        this.state = adminArea;
                        mSP.setString(this, SP.LOC_LINE_3_STATE, adminArea);
                    }
                    if (countryName != null) {
                        this.country = countryName;
                        mSP.setString(this, SP.LOC_LINE_4_COUNTRY, countryName);
                    }
                    loadMap();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void loadMap() {
        double d;
        double d2;
        String string = mSP.getString(this, SP.LATITUDE, "");
        String string2 = mSP.getString(this, SP.LONGITUDE, "");
        if (string == null || string2 == null || string.isEmpty() || string2.isEmpty()) {
            d2 = 0.0d;
            d = 0.0d;
        } else {
            if (string.contains(",")) {
                string = string.replace(",", ".");
            }
            if (string2.contains(",")) {
                string2 = string2.replace(",", ".");
            }
            d = Double.valueOf(string).doubleValue();
            d2 = Double.valueOf(string2).doubleValue();
        }
        if (this.mGMap != null && d != 0.0d && d2 != 0.0d) {
            LatLng latLng = new LatLng(d, d2);
            this.mGMap.clear();
            this.marker = null;
            this.marker = this.mGMap.addMarker(new MarkerOptions().position(latLng).title(""));
            this.mGMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
            this.mGMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15.0f));
        }
    }

    private void mapSnapshot() {
        try {
            System.gc();
            if (this.mGMap != null && HelperClass.check_internet(this)) {
                this.mGMap.snapshot(new GoogleMap.SnapshotReadyCallback() { 
                    @Override 
                    public void onSnapshotReady(Bitmap bitmap) {
                        if (bitmap != null) {
                            mapBitmap = bitmap;
                        }
                    }
                });
            }
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
        }
    }

    private void showDirection(float f) {
        String str = (f >= 338.0f || f < 23.0f) ? "N" : (f < 23.0f || f >= 68.0f) ? (f < 68.0f || f >= 113.0f) ? (f < 113.0f || f >= 158.0f) ? (f < 158.0f || f >= 203.0f) ? (f < 203.0f || f >= 248.0f) ? (f < 248.0f || f >= 293.0f) ? (f < 293.0f || f >= 338.0f) ? "" : "NW" : "W" : "SW" : "S" : "SE" : "E" : "NE";
        this.str_compass = Math.round(f) + "° " + str;
        if (CameraView.Stop_video == 0) {
            mSP.setString(this, SP.COMPASS_VALUE, this.str_compass);
            this.tv_compass.setText(this.str_compass);
        }
    }

    public void hideUi() {
        if (this.mRel_header.getVisibility() == View.VISIBLE) {
            this.mRel_header.setVisibility(View.INVISIBLE);
        }
        if (this.bottomscreenpannel.getVisibility() == View.VISIBLE) {
            this.bottomscreenpannel.setVisibility(View.INVISIBLE);
        }
    }

    public void showUI() {
        if (this.mRel_header.getVisibility() == View.INVISIBLE) {
            this.mRel_header.setVisibility(View.VISIBLE);
        }
        if (this.bottomscreenpannel.getVisibility() == View.INVISIBLE) {
            this.bottomscreenpannel.setVisibility(View.VISIBLE);
        }
    }

    private void refreshflash() {
        Setflashback(mSP.getInteger(this, SP_Keys.getFlashPos(this.camera.getCameraId())).intValue());
    }

    public void callWeatherApi() {
        if (mSP.getBoolean(this, SP.IS_CALL_WEATHER_API, Boolean.valueOf((boolean) USE_FRAME_PROCESSOR)).booleanValue() && HelperClass.check_internet(this)) {
            mSP.setBoolean(this, SP.IS_CALL_WEATHER_API, false);
            String string = mSP.getString(this, SP.LATITUDE, "");
            String string2 = mSP.getString(this, SP.LONGITUDE, "");
            Double valueOf = Double.valueOf((double) 0.0d);
            Double valueOf2 = Double.valueOf((double) 0.0d);
            if (string != null && string2 != null && !string.isEmpty() && !string2.isEmpty()) {
                if (string.contains(",")) {
                    string = string.replace(",", ".");
                }
                if (string2.contains(",")) {
                    string2 = string2.replace(",", ".");
                }
                valueOf = Double.valueOf(string);
                valueOf2 = Double.valueOf(string2);
            }
            final Double valueOf3 = Double.valueOf(round(valueOf.doubleValue(), 2));
            final Double valueOf4 = Double.valueOf(round(valueOf2.doubleValue(), 2));
            if (valueOf3.doubleValue() != this.oldlate || valueOf4.doubleValue() != this.oldlong) {
                Log.e("weather_api : ", NotificationCompat.CATEGORY_CALL);
                String string3 = getString(R.string.weather_api);
                StringRequest stringRequest = new StringRequest(0, "https://api.openweathermap.org/data/2.5/weather?lat=" + valueOf + "&lon=" + valueOf2 + "&appid=" + string3 + "&units=metric", new Response.Listener<String>() { 
                    public void onResponse(String str) {
                        try {
                            JSONObject jSONObject = new JSONObject(str);
                            float parseFloat = Float.parseFloat(jSONObject.getJSONObject("main").getString("temp"));
                            mfTemprature_value = parseFloat;
                            CameraActivity.mSP.setFloat(CameraActivity.this, SP.TEMPRETURE_VALUE, Float.valueOf(parseFloat));
                            oldlate = valueOf3.doubleValue();
                            oldlong = valueOf4.doubleValue();
                            JSONArray jSONArray = jSONObject.getJSONArray("weather");
                            Log.e("jAryIcon001", "" + jSONArray);
                            if (jSONArray.length() != 0) {
                                JSONObject jSONObject2 = jSONArray.getJSONObject(0);
                                SP sp = CameraActivity.mSP;
                                CameraActivity cameraActivity = CameraActivity.this;
                                sp.setInteger(cameraActivity, SP.WEATHER_ICON, Integer.valueOf(cameraActivity.getIconCode(jSONObject2.getString("icon"))));
                                imgWeather.setImageResource(mWeatherIcon.getResourceId(getIconCode(jSONObject2.getString("icon")), 0));
                            }
                        } catch (JSONException e) {
                            Log.e("JSONException", "" + e.getMessage());
                        } catch (Exception e2) {
                            Log.e("Exception", "" + e2.getMessage());
                        }
                    }
                }, new Response.ErrorListener() { 
                    @Override 
                    public void onErrorResponse(VolleyError volleyError) {
                        Log.e("VolleyError", "" + volleyError.getMessage());
                    }
                });
                stringRequest.setShouldCache(false);
                stringRequest.setRetryPolicy(new DefaultRetryPolicy(30000, 0, 1.0f));
                this.mVolleyQueue.add(stringRequest);
            }
        }
    }


    public int getIconCode(String str) {
        str.equalsIgnoreCase("01d");
        String r0 = String.valueOf(str.equalsIgnoreCase("02d"));
        if (str.equalsIgnoreCase("03d")) {
            r0 = String.valueOf(2);
        }
        int i = Integer.parseInt(r0);
        if (str.equalsIgnoreCase("04d")) {
            i = 3;
        }
        int i2 = i;
        if (str.equalsIgnoreCase("09d")) {
            i2 = 4;
        }
        int i3 = i2;
        if (str.equalsIgnoreCase("10d")) {
            i3 = 5;
        }
        int i4 = i3;
        if (str.equalsIgnoreCase("11d")) {
            i4 = 6;
        }
        int i5 = i4;
        if (str.equalsIgnoreCase("13d")) {
            i5 = 7;
        }
        int i6 = i5;
        if (str.equalsIgnoreCase("50d")) {
            i6 = 8;
        }
        int i7 = i6;
        if (str.equalsIgnoreCase("01n")) {
            i7 = 9;
        }
        int i8 = i7;
        if (str.equalsIgnoreCase("02n")) {
            i8 = 10;
        }
        int i9 = i8;
        if (str.equalsIgnoreCase("03n")) {
            i9 = 11;
        }
        int i10 = i9;
        if (str.equalsIgnoreCase("04n")) {
            i10 = 12;
        }
        int i11 = i10;
        if (str.equalsIgnoreCase("09n")) {
            i11 = 13;
        }
        int i12 = i11;
        if (str.equalsIgnoreCase("10n")) {
            i12 = 14;
        }
        int i13 = i12;
        if (str.equalsIgnoreCase("11n")) {
            i13 = 15;
        }
        int i14 = i13;
        if (str.equalsIgnoreCase("13n")) {
            i14 = 16;
        }
        int i15 = i14;
        if (str.equalsIgnoreCase("50n")) {
            i15 = 17;
        }
        Log.e(":::icon:::", "getIconCode: " + (i15 == 1 ? 1 : 0));
        return i15;
    }

    public void Setflashback(int i) {
        this.lin_flason.setBackground(getResources().getDrawable(R.drawable.unselected_circle_back));
        this.lin_flashoff.setBackground(getResources().getDrawable(R.drawable.unselected_circle_back));
        if (i == 0) {
            this.lin_flashoff.setBackground(getResources().getDrawable(R.drawable.select_circle_back));
            this.tv_flash.setText(getResources().getString(R.string.off));
            return;
        }
        this.lin_flason.setBackground(getResources().getDrawable(R.drawable.select_circle_back));
        this.tv_flash.setText(getResources().getString(R.string.always_on));
    }

    private void refrece_grid() {
        int intValue = mSP.getInteger(this, SP_Keys.GRID_POS, 0).intValue();
        this.timer_list.clear();
        for (int i = 0; i < this.timer.length; i++) {
            if (i == intValue) {
                this.timer_list.add(new PostionModel(this.timer[i], 1));
                this.tv_gride.setText(this.timer[i]);
            } else {
                this.timer_list.add(new PostionModel(this.timer[i], 0));
            }
        }
        setgrideadpter();
    }

    private void setAdapter() {
        this.rv_ration.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        this.ratio_list.clear();
        this.ratio_list = this.camera.getSupportedPictureSize();
        RatioAdapter ratioAdapter = new RatioAdapter(this, this.camera, this.ratio_list, new onRecyclerClickListener() { 
            @Override 
            public void setOnItemClickListener(int i, View view) {
                if (i >= 0 && i < ratio_list.size()) {
                    Size size = (Size) ratio_list.get(i);
                    SP sp = CameraActivity.mSP;
                    CameraActivity cameraActivity = CameraActivity.this;
                    sp.setString(cameraActivity, SP.getRatio_Key(cameraActivity.camera.getCameraId()), size.getWidth() + " " + size.getHeight());
                    SP sp2 = CameraActivity.mSP;
                    CameraActivity cameraActivity2 = CameraActivity.this;
                    sp2.setInteger(cameraActivity2, SP.getRatioPos_Key(cameraActivity2.camera.getCameraId()), Integer.valueOf(i));
                    setRatio();
                    CameraActivity.functionflag = false;
                    CameraActivity.lin_function.setVisibility(View.GONE);
                }
            }
        });
        this.mRatioAdapter = ratioAdapter;
        this.rv_ration.setAdapter(ratioAdapter);
    }

    private void setgrideadpter() {
        this.rv_gride.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        FunactionalAdapter funactionalAdapter = new FunactionalAdapter(this, this.timer_list);
        this.funactionalAdapter = funactionalAdapter;
        this.rv_gride.setAdapter(funactionalAdapter);
        this.funactionalAdapter.setOnselected(new FunactionalAdapter.Onselected() { 
            @Override 
            public void Onsetlect(PostionModel postionModel, int i) {
                CameraActivity.mSP.setInteger(CameraActivity.this, SP_Keys.GRID_POS, Integer.valueOf(i));
                if (i == 0) {
                    camera.setGrid(Grid.OFF);
                } else if (i == 1) {
                    camera.setGrid(Grid.DRAW_3X3);
                } else if (i == 2) {
                    camera.setGrid(Grid.DRAW_4X4);
                } else if (i == 3) {
                    camera.setGrid(Grid.DRAW_PHI);
                }
                CameraActivity.functionflag = false;
                CameraActivity.lin_function.setVisibility(View.GONE);
            }
        });
    }

    public void refrece_data() {
        List<Size> supportedPictureSize = this.camera.getSupportedPictureSize();
        this.ratio_list = supportedPictureSize;
        if (supportedPictureSize != null) {
            setAdapter();
        }
    }

    public void createSaveFolder() {
        if (!isFinishing()) {
            File file = new File(Default.PARENT_FOLDER_PATH);
            if (!file.exists()) {
                file.mkdir();
            }
            if (file.exists()) {
                File file2 = new File(file.getAbsolutePath() + "/" + Default.SITE_1);
                if (!file2.exists()) {
                    file2.mkdir();
                }
                File file3 = new File(file.getAbsolutePath() + "/" + Default.SITE_2);
                if (!file3.exists()) {
                    file3.mkdir();
                }
            }
        }
    }

    public void updateGrid() {
        int intValue = mSP.getInteger(this, SP_Keys.GRID_POS, 0).intValue();
        if (intValue == 0) {
            this.camera.setGrid(Grid.OFF);
        } else if (intValue == 1) {
            this.camera.setGrid(Grid.DRAW_3X3);
        } else if (intValue == 2) {
            this.camera.setGrid(Grid.DRAW_4X4);
        } else if (intValue == 3) {
            this.camera.setGrid(Grid.DRAW_PHI);
        }
    }

    public void callFragment(Fragment fragment, String str) {
        FragmentTransaction beginTransaction = getSupportFragmentManager().beginTransaction();
        beginTransaction.replace(R.id.camera_layout, fragment, str);
        beginTransaction.addToBackStack(str);
        beginTransaction.commitAllowingStateLoss();
    }

    public void closePopup() {
        if (lin_function.getVisibility() == View.VISIBLE) {
            lin_function.setVisibility(View.GONE);
        }
    }

    public void fuctionality() {
        List<Size> list;
        refrece_data();
        refrece_grid();
        refreshflash();
        int intValue = mSP.getInteger(this, SP.getRatioPos_Key(this.camera.getCameraId()), this.mHelperClass.setposratio(this, this.ratio_list)).intValue();
        if (!(this.rv_ration == null || (list = this.ratio_list) == null)) {
            if (list.size() > intValue) {
                this.rv_ration.scrollToPosition(intValue);
            } else if (this.ratio_list.size() != 0) {
                mSP.setInteger(this, SP.getRatioPos_Key(this.camera.getCameraId()), 0);
                this.rv_ration.scrollToPosition(0);
            }
        }
        String str = this.ration;
        Log.e("ration : ", str);
        this.tv_ration.setText(str);
        functionflag = USE_FRAME_PROCESSOR;
        lin_function.setVisibility(View.VISIBLE);
    }

    private void setUpOrientation() {
        SensorManager sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        this.mSensorManager = sensorManager;
        if (sensorManager.getDefaultSensor(1) != null) {
            this.mSensorAccelerometer = this.mSensorManager.getDefaultSensor(1);
        }
        this.magneticSensor.initSensor(this.mSensorManager);
        this.orientationEventListener = new OrientationEventListener(this) { 
            @Override 
            public void onOrientationChanged(int i) {
                int i2;
                if (i != -1) {
                    int abs = Math.abs(i - CameraActivity.current_orientation);
                    if (abs > 180) {
                        abs = 360 - abs;
                    }
                    if (abs > 60 && (i2 = (((i + 45) / 90) * 90) % 360) != CameraActivity.current_orientation) {
                        CameraActivity.current_orientation = i2;
                        view_rotate_animation = CameraActivity.USE_FRAME_PROCESSOR;
                        layoutUI(false);
                        view_rotate_animation = false;
                    }
                }
            }
        };
    }

    public void layoutUI(boolean z) {
        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        int i = 0;
        if (rotation != 0) {
            if (rotation == 1) {
                i = 90;
            } else if (rotation == 2) {
                i = 180;
            } else if (rotation == 3) {
                i = 270;
            }
        }
        ui_rotation = (360 - ((current_orientation + i) % 360)) % 360;
        if (!z) {
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.switchCameraButton.getLayoutParams();
            layoutParams.addRule(11, -1);
            layoutParams.addRule(15, -1);
            this.switchCameraButton.setLayoutParams(layoutParams);
            setViewRotation(this.switchCameraButton, (float) ui_rotation);
            RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) this.galleryButton.getLayoutParams();
            layoutParams2.addRule(11, -1);
            layoutParams2.addRule(15, -1);
            this.galleryButton.setLayoutParams(layoutParams2);
            setViewRotation(this.galleryButton, (float) ui_rotation);
            View findViewById = findViewById(R.id.lay_ratio);
            findViewById.setLayoutParams((LinearLayout.LayoutParams) findViewById.getLayoutParams());
            setViewRotation(findViewById, (float) ui_rotation);
            View findViewById2 = findViewById(R.id.linear_filename);
            findViewById2.setLayoutParams((LinearLayout.LayoutParams) findViewById2.getLayoutParams());
            setViewRotation(findViewById2, (float) ui_rotation);
            View findViewById3 = findViewById(R.id.lny_map);
            findViewById3.setLayoutParams((LinearLayout.LayoutParams) findViewById3.getLayoutParams());
            setViewRotation(findViewById3, (float) ui_rotation);
            ImageView imageView = (ImageView) findViewById(R.id.img_folder);
            imageView.setLayoutParams((LinearLayout.LayoutParams) imageView.getLayoutParams());
            setViewRotation(imageView, (float) ui_rotation);
            ImageView imageView2 = (ImageView) findViewById(R.id.img_templet);
            imageView2.setLayoutParams((LinearLayout.LayoutParams) imageView2.getLayoutParams());
            setViewRotation(imageView2, (float) ui_rotation);
            View findViewById4 = findViewById(R.id.img_setting);
            findViewById4.setLayoutParams((LinearLayout.LayoutParams) findViewById4.getLayoutParams());
            setViewRotation(findViewById4, (float) ui_rotation);
            setPreviewRotation(ui_rotation);
        }
    }

    public void setPreviewRotation(int i) {
        ViewGroup.LayoutParams layoutParams = this.mRel_preview.getLayoutParams();
        if (i == 0 || i == 180) {
            layoutParams.height = this.camera.getHeight();
            layoutParams.width = this.camera.getWidth();
            this.mRel_preview.setRotation((float) i);
            setWatermarkParams();
        } else if (i == 90 || i == 270) {
            layoutParams.height = this.camera.getWidth();
            layoutParams.width = this.camera.getHeight();
            this.mRel_preview.setRotation((float) i);
            setWatermarkParams();
        }
    }

    private void setWatermarkParams() {
        if (mSP.getString(this, "pos_type_temp", "Bottom").equals("Bottom")) {
            this.mHelperClass.setWatermarkLayoutParams(this, 1, this.tmpl_layout, this.li_main_stamp_lay);
        } else {
            this.mHelperClass.setWatermarkLayoutParams(this, 0, this.tmpl_layout, this.li_main_stamp_lay);
        }
    }

    private void setViewRotation(View view, float f) {
        if (!this.view_rotate_animation) {
            view.setRotation(f);
        }
        float rotation = f - view.getRotation();
        if (rotation > 181.0f) {
            rotation -= 360.0f;
        } else if (rotation < -181.0f) {
            rotation += 360.0f;
        }
        view.animate().rotationBy(rotation).setDuration(100).setInterpolator(new AccelerateDecelerateInterpolator()).start();
    }

    private void tackephoto() {
        if (!this.isRecording) {
            this.isRecording = USE_FRAME_PROCESSOR;
            startVideoTimer();
            this.takeVideoButton.setImageResource(R.drawable.ic_video);
            this.mRel_header.setVisibility(View.GONE);
            this.img_pasue.setImageResource(R.drawable.ic_pause);
            this.pasu_flage = 0;
            this.play_pasuefalge = 0;
            this.video_List.clear();
            this.galleryButton.setVisibility(View.INVISIBLE);
            this.lin_tackphoto.setVisibility(View.VISIBLE);
            this.switchCameraButton.setVisibility(View.INVISIBLE);
            this.pasue_button.setVisibility(View.VISIBLE);
            captureVideoSnapshot();
            CameraView.Stop_video = 1;
            return;
        }
        this.isRecording = false;
        CameraView.Stop_video = 0;
        this.camera.stopVideo();
        stopVideoTimer();
        this.takeVideoButton.setImageResource(R.drawable.ic_capture);
        this.mRel_header.setVisibility(View.VISIBLE);
        this.galleryButton.setVisibility(View.VISIBLE);
        this.lin_tackphoto.setVisibility(View.GONE);
        this.pasue_button.setVisibility(View.GONE);
        this.switchCameraButton.setVisibility(View.VISIBLE);
        CameraView.outputRation = null;
        if (this.pasu_flage == 1) {
            appendTwoVideos();
        }
    }

    private void Playpasuesvideo() {
        this.play_pasuefalge = 1;
        if (this.pasu_flage == 0) {
            this.img_pasue.setImageResource(R.drawable.ic_capture);
            this.takeVideoButton.setImageResource(R.drawable.ic_capture__stop);
            this.pasu_flage = 1;
            this.camera.stopVideo();
            AlphaAnimation alphaAnimation = new AlphaAnimation(0.2f, 1.0f);
            alphaAnimation.setStartOffset(5000);
            alphaAnimation.setDuration(0);
            alphaAnimation.setFillAfter(USE_FRAME_PROCESSOR);
            this.img_time.startAnimation(alphaAnimation);
            this.img_time.setImageResource(R.drawable.ic_pause);
            this.timeSwapBuff += this.timeInMilliseconds;
            this.customHandler.removeCallbacks(this.updateTimerThread);
            return;
        }
        this.img_pasue.setImageResource(R.drawable.ic_pause);
        this.takeVideoButton.setImageResource(R.drawable.ic_video);
        this.pasu_flage = 0;
        startVideoTimer();
        captureVideoSnapshot();
    }

    private void startVideoTimer() {
        this.lny_time.setVisibility(View.VISIBLE);
        this.startTime = SystemClock.uptimeMillis();
        this.img_time.setImageResource(R.drawable.ic_play);
        AlphaAnimation alphaAnimation = new AlphaAnimation(0.1f, 1.0f);
        alphaAnimation.setDuration(700);
        alphaAnimation.setRepeatCount(50000);
        alphaAnimation.setFillAfter(USE_FRAME_PROCESSOR);
        this.img_time.startAnimation(alphaAnimation);
        this.customHandler.postDelayed(this.updateTimerThread, 0);
    }

    public void setUpFlash() {
        ArrayList<Flash> arrayList;
        int intValue;
        String name;
        if (!isFinishing() && (arrayList = this.mFlashvalues) != null && arrayList.size() > 1 && (intValue = mSP.getInteger(this, SP_Keys.getFlashPos(this.camera.getCameraId()), 0).intValue()) >= 0 && intValue < this.mFlashvalues.size() && (name = this.mFlashvalues.get(intValue).name()) != null && name.equals("TORCH")) {
            mSP.setInteger(this, SP_Keys.getFlashPos(this.camera.getCameraId()), 0);
            updateCycleFlashIcon();
        }
    }

    private void captureVideoSnapshot() {
        if (!this.camera.isTakingVideo() && this.camera.getPreview() == Preview.GL_SURFACE) {
            this.camera.takeVideoSnapshot(new File(getFilesDir(), "video.mp4"));
        }
    }

    private void stopVideoTimer() {
        this.timeSwapBuff = 0;
        this.customHandler.removeCallbacks(this.updateTimerThread);
        this.lny_time.setVisibility(View.GONE);
    }

    private void setModePhoto() {
        this.takePhotoButton.setImageResource(R.drawable.ic_camera);
    }

    private void setModeVideo() {
        this.takeVideoButton.setImageResource(R.drawable.ic_capture);
    }

    public void appendTwoVideos() {
        String string = mSP.getString(this, SP.FOLDER_NAME, Default.DEFAULT_FOLDER_PATH);
        try {
            int size = this.video_List.size();
            Movie[] movieArr = new Movie[size];
            for (int i = 0; i < this.video_List.size(); i++) {
                movieArr[i] = MovieCreator.build(new FileDataSourceImpl(this.video_List.get(i)));
            }
            LinkedList linkedList = new LinkedList();
            LinkedList linkedList2 = new LinkedList();
            for (int i2 = 0; i2 < size; i2++) {
                for (Track track : movieArr[i2].getTracks()) {
                    if (track.getHandler().equals("soun")) {
                        linkedList2.add(track);
                    }
                    if (track.getHandler().equals("vide")) {
                        linkedList.add(track);
                    }
                }
            }
            Movie movie = new Movie();
            if (linkedList2.size() > 0) {
                movie.addTrack(new AppendTrack((Track[]) linkedList2.toArray(new Track[linkedList2.size()])));
            }
            if (linkedList.size() > 0) {
                movie.addTrack(new AppendTrack((Track[]) linkedList.toArray(new Track[linkedList.size()])));
            }
            BasicContainer basicContainer = (BasicContainer) new DefaultMp4Builder().build(movie);
            File file = new File(string);
            if (!file.exists()) {
                file.mkdirs();
            }
            File file2 = new File(file, createMediaFilename(0));
            FileChannel channel = new RandomAccessFile(file2, "rw").getChannel();
            basicContainer.writeContainer(channel);
            channel.close();
            if (mSP.getBoolean(this, SP_Keys.IS_SD_CARD, false).booleanValue()) {
                saveVideosd(file2);
            } else {
                updateGalleryIcon();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        new Handler().postDelayed(new Runnable() { 
            @Override 
            public void run() {
                for (int i3 = 0; i3 < video_List.size(); i3++) {
                    File file3 = new File(video_List.get(i3));
                    file3.exists();
                    file3.delete();
                    CameraView.outputRation = null;
                }
            }
        }, 600);
    }

    private void saveVideosd(File file) throws FileNotFoundException {
        String str;
        File file2 = new File(file.getPath());
        FileInputStream fileInputStream = new FileInputStream(file2);
        String string = mSP.getString(this, SP.FOLDER_SD_NAME, "");
        Uri parse = Uri.parse(string);
        String createMediaFilename = createMediaFilename(0);
        String str2 = new File(parse.getPath()).getAbsolutePath() + createMediaFilename;
        Log.e("file_path", str2);
        File file3 = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), createMediaFilename);
        try {
            if (file3.exists()) {
                file3.delete();
            }
            FileOutputStream fileOutputStream = new FileOutputStream(file3);
            byte[] bArr = new byte[1024];
            while (true) {
                int read = fileInputStream.read(bArr);
                if (read <= 0) {
                    break;
                }
                fileOutputStream.write(bArr, 0, read);
            }
            fileInputStream.close();
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        Log.e("treeUri", "" + string);
        if (string != null) {
            ContentResolver contentResolver = getContentResolver();
            Uri parse2 = Uri.parse(string);
            if (Build.VERSION.SDK_INT >= 19) {
                contentResolver.takePersistableUriPermission(parse2, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }
            String[] split = str2.split("/");
            if (split == null || split.length <= 0 || split.length - 1 <= 3) {
                str = "";
            } else {
                str = "";
                for (int i = 3; i < split.length - 1; i++) {
                    str = str + split[i] + "/";
                }
            }
            if (str.endsWith("/")) {
                str = str.substring(0, str.length() - 1);
            }
            try {
                Uri parse3 = Uri.parse(String.valueOf(Build.VERSION.SDK_INT >= 21 ? DocumentsContract.buildDocumentUriUsingTree(parse, DocumentsContract.getTreeDocumentId(parse) + str) : null));
                Cursor query = contentResolver.query(parse3, new String[]{"_display_name", "mime_type"}, null, null, null);
                if (query != null) {
                    while (query.moveToNext()) {
                        String[] split2 = str2.split("/");
                        String str3 = split2[split2.length - 1];
                        String str4 = str + "/" + createMediaFilename;
                        if (Build.VERSION.SDK_INT >= 21) {
                            DocumentsContract.buildDocumentUriUsingTree(parse, DocumentsContract.getTreeDocumentId(parse) + str4);
                        }
                        Uri createDocument = Build.VERSION.SDK_INT >= 21 ? DocumentsContract.createDocument(contentResolver, parse3, "video/*", "" + createMediaFilename) : null;
                        FileInputStream fileInputStream2 = new FileInputStream(file3);
                        byte[] bArr2 = new byte[(int) file3.length()];
                        fileInputStream2.read(bArr2);
                        fileInputStream2.close();
                        try {
                            OutputStream openOutputStream = getContentResolver().openOutputStream(createDocument);
                            if (openOutputStream != null) {
                                openOutputStream.write(bArr2);
                                openOutputStream.close();
                                file3.delete();
                                System.gc();
                            } else {
                                file3.delete();
                                System.gc();
                            }
                        } catch (IOException e3) {
                            e3.printStackTrace();
                        }
                    }
                    query.close();
                }
            } catch (Exception e4) {
                e4.printStackTrace();
            }
        }
        if (file2.exists()) {
            file2.delete();
        }
        updateGalleryIcon();
    }

    public void saveVideo(Uri uri) throws IOException {
        FileInputStream createInputStream = null;
        String str;
        try {
            createInputStream = getContentResolver().openAssetFileDescriptor(uri, "r").createInputStream();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (mSP.getBoolean(this, SP_Keys.IS_SD_CARD, false).booleanValue()) {
            String string = mSP.getString(this, SP.FOLDER_SD_NAME, "");
            Uri parse = Uri.parse(string);
            String createMediaFilename = createMediaFilename(0);
            String str2 = new File(parse.getPath()).getAbsolutePath() + createMediaFilename;
            Log.e("file_path", str2);
            File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), createMediaFilename);
            try {
                if (file.exists()) {
                    file.delete();
                }
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                byte[] bArr = new byte[1024];
                while (true) {
                    int read = createInputStream.read(bArr);
                    if (read <= 0) {

                        break;
                    }
                    fileOutputStream.write(bArr, 0, read);
                }
                createInputStream.close();
                fileOutputStream.close();
            } catch (FileNotFoundException e2) {
                e2.printStackTrace();
            } catch (IOException e3) {
                e3.printStackTrace();
            }
            Log.e("treeUri", "" + string);
            if (string != null) {
                ContentResolver contentResolver = getContentResolver();
                Uri parse2 = Uri.parse(string);
                if (Build.VERSION.SDK_INT >= 19) {
                    contentResolver.takePersistableUriPermission(parse2, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                }
                String[] split = str2.split("/");
                if (split == null || split.length <= 0 || split.length - 1 <= 3) {
                    str = "";
                } else {
                    str = "";
                    for (int i = 3; i < split.length - 1; i++) {
                        str = str + split[i] + "/";
                    }
                }
                if (str.endsWith("/")) {
                    str = str.substring(0, str.length() - 1);
                }
                int i2 = 21;
                try {
                    Uri parse3 = Uri.parse(String.valueOf(Build.VERSION.SDK_INT >= 21 ? DocumentsContract.buildDocumentUriUsingTree(parse, DocumentsContract.getTreeDocumentId(parse) + str) : null));
                    Cursor query = contentResolver.query(parse3, new String[]{"_display_name", "mime_type"}, null, null, null);
                    if (query != null) {
                        while (query.moveToNext()) {
                            String[] split2 = str2.split("/");
                            String str3 = split2[split2.length - 1];
                            String str4 = str + "/" + createMediaFilename;
                            if (Build.VERSION.SDK_INT >= i2) {
                                DocumentsContract.buildDocumentUriUsingTree(parse, DocumentsContract.getTreeDocumentId(parse) + str4);
                            }
                            Uri createDocument = Build.VERSION.SDK_INT >= i2 ? DocumentsContract.createDocument(contentResolver, parse3, "video/*", "" + createMediaFilename) : null;
                            FileInputStream fileInputStream = new FileInputStream(file);
                            byte[] bArr2 = new byte[(int) file.length()];
                            fileInputStream.read(bArr2);
                            fileInputStream.close();
                            try {
                                OutputStream openOutputStream = getContentResolver().openOutputStream(createDocument);
                                if (openOutputStream != null) {
                                    openOutputStream.write(bArr2);
                                    openOutputStream.close();
                                    file.delete();
                                    System.gc();
                                } else {
                                    file.delete();
                                    System.gc();
                                }
                            } catch (IOException e4) {
                                e4.printStackTrace();
                            }
                            parse3 = parse3;
                            i2 = 21;
                        }
                        query.close();
                    }
                } catch (Exception e5) {
                    e5.printStackTrace();
                }
            }
            updateGalleryIcon();
            CameraView.outputRation = null;
        }
        File file2 = new File(getStoragePath());
        if (!file2.exists()) {
            file2.mkdirs();
        }
        File file3 = new File(file2, createMediaFilename(0));
        if (file3.exists()) {
            file3.delete();
        }
        FileOutputStream fileOutputStream2 = new FileOutputStream(file3);
        byte[] bArr3 = new byte[1024];
        while (true) {
            int read2 = createInputStream.read(bArr3);
            if (read2 <= 0) {
                break;
            }
            fileOutputStream2.write(bArr3, 0, read2);
        }
        createInputStream.close();
        fileOutputStream2.close();
        try {
            if (Build.VERSION.SDK_INT >= 24) {
                setExifFromUri(uri, file3);
            }
        } catch (IOException e6) {
            e6.printStackTrace();
        }
        MediaScannerConnection.scanFile(this, new String[]{file3.toString()}, null, new MediaScannerConnection.OnScanCompletedListener() { 
            @Override 
            public void onScanCompleted(String str5, Uri uri2) {
                Log.e("ExternalStorage", "-> uri=" + uri2);
            }
        });
        updateGalleryIcon();
        CameraView.outputRation = null;
        CameraView.outputRation = null;
    }

    @Override 
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.img_gallery:
                DelayToclick();
                setUpFlash();
                if (!this.isRecording) {
                    String recentPath = getRecentPath();
                    if (recentPath != null) {
                        new SingleMediaScanner(this, recentPath);
                        return;
                    } else {
                        showSnackBar(this.li_stamp, getString(R.string.no_image_available));
                        return;
                    }
                } else {
                    this.galleryButton.setImageResource(R.drawable.ic_stamp);
                    return;
                }
            case R.id.linear_filename:
                setUpFlash();
                startActivity(new Intent(this, FileName_Activity.class));
                return;
            case R.id.pasue_camera:
                DelayToclick();
                Playpasuesvideo();
                return;
            case R.id.switch_camera:
                DelayToclick();
                setUpFlash();
                if (!this.isRecording && !this.camera.isTakingPicture() && !this.camera.isTakingVideo()) {
                    this.camera.toggleFacing();
                    return;
                }
                return;
            case R.id.take_photo:
                if (this.camera != null) {
                    AlphaAnimation alphaAnimation = new AlphaAnimation(0.1f, 1.0f);
                    alphaAnimation.setDuration(1000);
                    alphaAnimation.setRepeatCount(5000);
                    alphaAnimation.setFillAfter(USE_FRAME_PROCESSOR);
                    this.takePhotoButton.startAnimation(alphaAnimation);
                    this.takePhotoButton.setEnabled(false);
                    this.takeVideoButton.setEnabled(false);
                    this.pasue_button.setEnabled(false);
                    if (!this.camera.isTakingPicture()) {
                        this.camera.takePicture();
                        return;
                    }
                    return;
                }
                return;
            case R.id.take_video:
                DelayToclick();
                tackephoto();
                return;
            default:
                return;
        }
    }

    private void showSnackBar(LinearLayout linearLayout, String str) {
        Snackbar textColor = Snackbar.make(linearLayout, str, -2).setActionTextColor(-1).setTextColor(-1);
        textColor.setDuration(3000);
        textColor.show();
        textColor.getView().setBackgroundColor(ContextCompat.getColor(this, R.color.black));
    }

    @Override
    
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        CameraView cameraView;
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (this.isStoragePermission == 0 && i == this.REQUEST_CODE) {
            boolean z = USE_FRAME_PROCESSOR;
            for (int i2 : iArr) {
                z = (!z || i2 != 0) ? false : USE_FRAME_PROCESSOR;
            }
            if (z && (cameraView = this.camera) != null && !cameraView.isOpened()) {
                try {
                    this.camera.open();
                } catch (Exception e) {
                    e.printStackTrace();
                    runOnUiThread(new Runnable() { 
                        @Override 
                        public void run() {
                            showSimpleDialog();
                        }
                    });
                }
            }
            if (z) {
                updateGalleryIcon();
                createSaveFolder();
                initLocation();
            } else if (!ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.CAMERA")) {
                showSimpleDialog();
            } else if (!ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.RECORD_AUDIO")) {
                showSimpleDialog();
            } else if (!ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.READ_EXTERNAL_STORAGE")) {
                showSimpleDialog();
            } else if (!ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.WRITE_EXTERNAL_STORAGE")) {
                showSimpleDialog();
            }
        }
    }

    public void showSimpleDialog() {
        try {
            int i = this.isStoragePermission;
            if (i == 0) {
                int i2 = i + 1;
                this.isStoragePermission = i2;
                this.camera.pemission(i2);
                AlertDialog alertDialog = this.alertSimpleDialog;
                if (alertDialog == null) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.MyAlertDialogStyle);
                    builder.setTitle(getResources().getString(R.string.permission_denied_title));
                    builder.setMessage(getResources().getString(R.string.permissionstr));
                    builder.setCancelable(false);
                    builder.setPositiveButton(getResources().getString(R.string.action_settings), new DialogInterface.OnClickListener() { 
                        @Override 
                        public void onClick(DialogInterface dialogInterface, int i3) {
                            Intent intent = new Intent();
                            intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                            intent.setData(Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                            startActivity(intent);
                            dialogInterface.dismiss();
                        }
                    });
                    AlertDialog create = builder.create();
                    this.alertSimpleDialog = create;
                    create.show();
                    this.alertSimpleDialog.setOnDismissListener(new DialogInterface.OnDismissListener() { 
                        @Override 
                        public void onDismiss(DialogInterface dialogInterface) {
                            isStoragePermission = 0;
                            camera.pemission(isStoragePermission);
                        }
                    });
                } else if (!alertDialog.isShowing()) {
                    this.alertSimpleDialog.show();
                }
            }
        } catch (Exception unused) {
        }
    }

    public void CaptureImage(final PictureResult pictureResult) {
        Size size = pictureResult.getSize();
        if (size.getWidth() <= 3500 || size.getHeight() <= 3500) {
            CameraUtils.decodeBitmap(pictureResult.getData(), new BitmapCallback() { 
                @Override 
                public void onBitmapReady(Bitmap bitmap) {
                    ImageStampAsync imageStampAsync = new ImageStampAsync();
                    MyObject myObject = new MyObject();
                    myObject.setBitmap(bitmap);
                    myObject.setData(pictureResult.getData());
                    imageStampAsync.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, myObject);
                }
            });
            return;
        }
        int width = size.getWidth();
        int height = size.getHeight();
        if (width > 3500) {
            width = size.getWidth() + NotificationManagerCompat.IMPORTANCE_UNSPECIFIED;
            height = size.getHeight() + NotificationManagerCompat.IMPORTANCE_UNSPECIFIED;
        }
        if (width > 4500) {
            width = size.getWidth() + NotificationManagerCompat.IMPORTANCE_UNSPECIFIED;
            height = size.getHeight() + NotificationManagerCompat.IMPORTANCE_UNSPECIFIED;
        }
        if (width > 5500) {
            width = size.getWidth() + NotificationManagerCompat.IMPORTANCE_UNSPECIFIED;
            height = size.getHeight() + NotificationManagerCompat.IMPORTANCE_UNSPECIFIED;
        }
        CameraUtils.decodeBitmap(pictureResult.getData(), width, height, new BitmapCallback() { 
            @Override 
            public void onBitmapReady(Bitmap bitmap) {
                ImageStampAsync imageStampAsync = new ImageStampAsync();
                MyObject myObject = new MyObject();
                myObject.setBitmap(bitmap);
                myObject.setData(pictureResult.getData());
                imageStampAsync.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, myObject);
            }
        });
    }


    public void updateCycleFlashIcon() {
        String str;
        char c = 0;
        int intValue = mSP.getInteger(this, SP_Keys.getFlashPos(this.camera.getCameraId()), 0).intValue();
        if (intValue < this.mFlashvalues.size()) {
            str = this.mFlashvalues.get(intValue).name();
        } else {
            str = "OFF";
        }
        if (str != null) {
            str.hashCode();
            switch (str.hashCode()) {
                case 2527:
                    break;
                case 78159:
                    if (str.equals("OFF")) {
                        c = 1;
                        break;
                    }
                    c = 65535;
                    break;
                case 2020783:
                    if (str.equals("AUTO")) {
                        c = 2;
                        break;
                    }
                    c = 65535;
                    break;
                case 80010204:
                    if (str.equals("TORCH")) {
                        c = 3;
                        break;
                    }
                    c = 65535;
                    break;
                default:
                    c = 65535;
                    break;
            }
            switch (c) {
                case 0:
                    this.camera.setFlash(Flash.ON);
                    return;
                case 1:
                    this.camera.setFlash(Flash.OFF);
                    return;
                case 2:
                    this.camera.setFlash(Flash.AUTO);
                    return;
                case 3:
                    this.camera.setFlash(Flash.TORCH);
                    return;
                default:
                    return;
            }
        }
    }

    public void stopDateTimer() {
        Timer timer = this.mTimer_Date;
        if (timer != null) {
            timer.cancel();
            this.mTimer_Date.purge();
        }
    }

    @Override
    
    public void onDestroy() {
        if (Build.VERSION.SDK_INT >= 23) {
            RenderScript.releaseAllContexts();
        }
        CameraView cameraView = this.camera;
        if (cameraView != null) {
            cameraView.destroy();
        }
        Compass compass = this.compass;
        if (compass != null) {
            compass.stop();
        }
        cancelTimer();
        super.onDestroy();
    }

    private void cancelTimer() {
        setUpFlash();
        HelperClass.dismissProgressDialog();
    }

    @Override
    
    public void onStart() {
        super.onStart();
        if (this.mMapView != null) {
            this.mMapView.onStart();
        }
    }

    @Override
    
    public void onStop() {
        super.onStop();
        if (this.compass != null) {
            this.compass.stop();
        }
        if (this.mMapView != null) {
            this.mMapView.onStop();
        }
        stopLocationUpdates();
    }


    @SuppressLint("WrongConstant")
    @Override
    
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 42 && i2 == -1 && intent != null) {
            Uri data = intent.getData();
            try {
                getContentResolver().takePersistableUriPermission(data, intent.getFlags() & 3);
                mSP.setBoolean(this, SP_Keys.IS_SD_CARD, Boolean.valueOf((boolean) USE_FRAME_PROCESSOR));
                mSP.setString(this, SP.FOLDER_SD_NAME, data.toString());
                this.settingFragment.refrese();
            } catch (SecurityException e) {
                e.printStackTrace();
            }
        }
    }

    protected void createLocationRequest() {
        try {

                Log.e(TAG, "createLocationRequest 121212: ------------>");
                SettingsClient settingsClient = LocationServices.getSettingsClient((Activity) this);
                this.mSettingsClient = settingsClient;
                settingsClient.checkLocationSettings(this.mLocationSettingsRequest).addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() { 
                    @SuppressLint("MissingPermission")
                    public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                        if (fusedLocationClient != null) {
                            fusedLocationClient.requestLocationUpdates(mLocationRequest, mLocationCallback, Looper.myLooper());
                        }
                    }
                }).addOnFailureListener(this, new OnFailureListener() { 
                    @Override 
                    public void onFailure(Exception exc) {
                        int statusCode = ((ApiException) exc).getStatusCode();
                        if (statusCode == 6) {
                            try {
                                ((ResolvableApiException) exc).startResolutionForResult(CameraActivity.this, 1);
                            } catch (IntentSender.SendIntentException unused) {
                            }
                        } else if (statusCode == 8502) {
                            Toast.makeText(CameraActivity.this, "Location settings are inadequate, and cannot be fixed here. Fix in Settings.", Toast.LENGTH_LONG).show();
                        }
                    }
                });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override 
    protected void onResume() {
        super.onResume();
        SensorManager sensorManager = this.mSensorManager;
        if (sensorManager != null) {
            sensorManager.registerListener(this.accelerometerListener, this.mSensorAccelerometer, 3);
        }
        MagneticSensor magneticSensor = this.magneticSensor;
        if (magneticSensor != null) {
            magneticSensor.registerMagneticListener(this.mSensorManager);
        }
        OrientationEventListener orientationEventListener = this.orientationEventListener;
        if (orientationEventListener != null) {
            orientationEventListener.enable();
        }
        this.app_is_paused = false;

        if (!MyApplication.hasPermissions(this, MyApplication.ALL_PERMISSIONS_LIST)) {
            ActivityCompat.requestPermissions(CameraActivity.this, MyApplication.ALL_PERMISSIONS_LIST, MyApplication.PERMISSION_TOKEN);
        } else {
            getLocation();
        }
        if (this.mMapView != null) {
            this.mMapView.onResume();
        }
        PrintStream printStream = System.out;
        printStream.println("Imagemap       " + this.imgMap.getWidth());
        PrintStream printStream2 = System.out;
        printStream2.println("Imagemap       " + this.imgMap.getHeight());
    }


   void getLocation(){
       this.mLocationType = mSP.getString(this, SP.LOCATION_TYPE, Default.AUTOMATIC);
       updateGalleryIcon();
       if (HelperClass.check_internet(this)) {
           createLocationRequest();
           if ( this.compass != null) {
               this.compass.start();
           }
           if (this.mLocationType.equals(Default.MANUAL)) {
               if (mSP.getBoolean(this, SP.IS_LOCATION_CHANGED, false).booleanValue()) {
                   mSP.setBoolean(this, SP.IS_LOCATION_CHANGED, false);
                   mSP.setBoolean(this, SP.IS_CALL_WEATHER_API, Boolean.valueOf((boolean) USE_FRAME_PROCESSOR));
                   initmap();
               }
               loadMap();
               callWeatherApi();
           }
       }
       if (this.isPermission == 0 && !HelperClass.check_internet(this)) {
           internetAlertDialog();
       }
    }






    private void internetAlertDialog() {
        if (!isFinishing()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(getString(R.string.no_internet_location));
            builder.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() { 
                @Override 
                public void onClick(DialogInterface dialogInterface, int i) {
                    try {
                        createLocationRequest();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    dialogInterface.dismiss();
                }
            });
            builder.create().show();
        }
    }

    @Override 
    protected void onPause() {
        CameraView cameraView = this.camera;
        if (cameraView != null) {
            cameraView.close();
        }
        super.onPause();
        Compass compass = this.compass;
        if (compass != null) {
            compass.stop();
        }
        this.mSensorManager.unregisterListener(this.accelerometerListener);
        this.magneticSensor.unregisterMagneticListener(this.mSensorManager);
        this.orientationEventListener.disable();
        this.app_is_paused = USE_FRAME_PROCESSOR;
        stopLocationUpdates();
    }

    private void stopLocationUpdates() {
        if (this.mGMap != null) {
            if (ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0) {
                this.mGMap.setMyLocationEnabled(false);
            } else {
                return;
            }
        }
        if (this.fusedLocationClient != null) {
            this.fusedLocationClient.removeLocationUpdates(this.mLocationCallback);
        }
    }

    public Bitmap drawStamp(Bitmap bitmap) {
        if (bitmap == null) {
            return null;
        }
        int width = (bitmap.getWidth() * 4) / this.display_width;
        Paint paint = new Paint(1);
        Bitmap createBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), bitmap.getConfig());
        Canvas canvas = new Canvas(createBitmap);
        canvas.drawBitmap(bitmap, 0.0f, 0.0f, (Paint) null);
        System.gc();
        bitmap.recycle();
        return setbitmap1(canvas, paint, createBitmap);
    }


    private Bitmap setbitmap1(Canvas canvas0, Paint paint0, Bitmap bitmap0) {
        LinearLayout linearLayout12;
        TextView textView7;
        LinearLayout linearLayout11;
        int v15;
        int v14;
        int v13;
        int v10;
        CameraActivity cameraActivity0 = this;
        try {
            View view0 = ((LayoutInflater) cameraActivity0.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.stamp_layout_capture, null);  
            TextView textView0 = (TextView) view0.findViewById(R.id.tv_address_line_1);  
            TextView textView1 = (TextView) view0.findViewById(R.id.tv_address);  
            TextView textView2 = (TextView) view0.findViewById(R.id.tv_weather);  
            TextView textView3 = (TextView) view0.findViewById(R.id.tv_compass);  
            TextView textView4 = (TextView) view0.findViewById(R.id.tv_magnetic_field);  
            ImageView imageView0 = (ImageView) view0.findViewById(R.id.imgMap);  
            RelativeLayout relativeLayout0 = (RelativeLayout) view0.findViewById(R.id.li_main_stamp_lay);  
            LinearLayout linearLayout0 = (LinearLayout) view0.findViewById(R.id.li_stamp);  
            LinearLayout linearLayout1 = (LinearLayout) view0.findViewById(R.id.li_compass);  
            ImageView imageView1 = (ImageView) view0.findViewById(R.id.imgCompass);  
            ImageView imageView2 = (ImageView) view0.findViewById(R.id.imgWeather);  
            ImageView imageView3 = (ImageView) view0.findViewById(R.id.imgMagneticField);  
            LinearLayout linearLayout2 = (LinearLayout) view0.findViewById(R.id.li_rightView);  
            TextView textView5 = textView1;
            LinearLayout linearLayout3 = (LinearLayout) view0.findViewById(R.id.li_address);  
            LinearLayout linearLayout4 = (LinearLayout) view0.findViewById(R.id.li_magnetic_field);  
            LinearLayout linearLayout5 = linearLayout0;
            LinearLayout linearLayout6 = (LinearLayout) view0.findViewById(R.id.li_weather);  
            View view1 = view0;
            TextView textView6 = textView0;
            int v = (int) (((float) bitmap0.getWidth()) * (cameraActivity0.scale * 8.0f) / ((float) cameraActivity0.DW));
            LinearLayout linearLayout7 = linearLayout2;
            int v1 = (int) (((float) bitmap0.getWidth()) * (cameraActivity0.scale * 10.0f) / ((float) cameraActivity0.DW));
            LinearLayout linearLayout8 = linearLayout1;
            int v2 = (int) (((float) bitmap0.getWidth()) * (cameraActivity0.scale * 12.0f) / ((float) cameraActivity0.DW));
            int v3 = (int) (((float) bitmap0.getWidth()) * (cameraActivity0.scale * 18.0f) / ((float) cameraActivity0.DW));
            LinearLayout linearLayout9 = linearLayout4;
            int v4 = (int) (((float) bitmap0.getWidth()) * (cameraActivity0.scale * 16.0f) / ((float) cameraActivity0.DW));
            ImageView imageView4 = imageView2;
            int v5 = (int) (((float) bitmap0.getWidth()) * (cameraActivity0.scale * 4.0f) / ((float) cameraActivity0.DW));
            int v6 = (int) (((float) bitmap0.getWidth()) * (cameraActivity0.scale * 36.0f) / ((float) cameraActivity0.DW));
            LinearLayout linearLayout10 = linearLayout6;
            int v7 = (int) (((float) bitmap0.getWidth()) * (cameraActivity0.scale * 200.0f) / ((float) cameraActivity0.DW));
            int v8 = (int) (((float) bitmap0.getWidth()) * (cameraActivity0.scale * 130.0f) / ((float) cameraActivity0.DW));
            int v9 = (int) (((float) bitmap0.getWidth()) * (cameraActivity0.scale * 155.0f) / ((float) cameraActivity0.DW));
            if (bitmap0.getWidth() > bitmap0.getHeight()) {
                v10 = v;
                int v11 = (int) (((float) bitmap0.getWidth()) * (cameraActivity0.scale * 170.0f) / ((float) cameraActivity0.DW));
                int v12 = (int) (((float) bitmap0.getWidth()) * (cameraActivity0.scale * 80.0f) / ((float) cameraActivity0.DW));
                v13 = (int) (((float) bitmap0.getWidth()) * (cameraActivity0.scale * 105.0f) / ((float) cameraActivity0.DW));
                v14 = v11;
                v15 = v12;
            } else {
                v10 = v;
                v13 = v9;
                v14 = v7;
                v15 = v8;
            }

            float f = (float) v1;
            textView2.setTextSize(f);
            textView3.setTextSize(f);
            textView4.setTextSize(f);
            LinearLayout.LayoutParams linearLayout$LayoutParams0 = new LinearLayout.LayoutParams(v14, v14);
            int v16 = v13;
            linearLayout$LayoutParams0.setMargins(0, 0, v4, 0);
            imageView0.setLayoutParams(linearLayout$LayoutParams0);
            imageView3.getLayoutParams().width = v6;
            imageView3.getLayoutParams().height = v6;
            imageView1.getLayoutParams().width = v6;
            imageView1.getLayoutParams().height = v6;
            relativeLayout0.setPadding(v3, v3, v3, v3);
            int v17 = v10;
            textView4.setPadding(v17, 0, 0, 0);
            textView3.setPadding(v17, 0, 0, 0);
            textView2.setPadding(v17, 0, 0, 0);
            if (cameraActivity0.isWeather) {
                linearLayout10.setVisibility(View.VISIBLE);
                imageView4.setImageResource(cameraActivity0.mWeatherIcon.getResourceId(cameraActivity0.mIconValue, 0));
                imageView4.getLayoutParams().width = v6;
                imageView4.getLayoutParams().height = v6;
            } else {
                linearLayout10.setVisibility(android.view.View.GONE);
            }

            if (cameraActivity0.isMagneticField) {
                linearLayout9.setVisibility(android.view.View.VISIBLE);
            } else {
                linearLayout9.setVisibility(android.view.View.GONE);
            }

            if (cameraActivity0.isCompass) {
                linearLayout8.setVisibility(android.view.View.VISIBLE);
            } else {
                linearLayout8.setVisibility(android.view.View.GONE);
            }

            if (!cameraActivity0.isWeather && !cameraActivity0.isMagneticField && !cameraActivity0.isCompass) {
                linearLayout11 = linearLayout7;
                linearLayout11.setVisibility(android.view.View.GONE);
            } else {
                linearLayout11 = linearLayout7;
                linearLayout11.setVisibility(android.view.View.VISIBLE);
            }

            if (cameraActivity0.isAddress) {
                textView7 = textView6;
                textView7.setMaxLines(10);
            } else if (!cameraActivity0.isMap && (!cameraActivity0.isWeather && !cameraActivity0.isMagneticField && !cameraActivity0.isCompass && !cameraActivity0.isLatLng && (cameraActivity0.isDateTime) || !cameraActivity0.isWeather && !cameraActivity0.isMagneticField && !cameraActivity0.isCompass && !cameraActivity0.isDateTime && (cameraActivity0.isLatLng) || ((cameraActivity0.isWeather) || (cameraActivity0.isCompass) || (cameraActivity0.isMagneticField)) && (cameraActivity0.isDateTime) && !cameraActivity0.isLatLng || ((cameraActivity0.isWeather) || (cameraActivity0.isCompass) || (cameraActivity0.isMagneticField)) && !cameraActivity0.isDateTime && (cameraActivity0.isLatLng))) {
                textView7 = textView6;
                textView7.setMaxLines(1);
            } else {
                textView7 = textView6;
                textView7.setMaxLines(10);
            }

            if ((cameraActivity0.isMap) && cameraActivity0.mapBitmap != null) {
                cameraActivity0.width = canvas0.getWidth() - (v3 * 3 + v14);
                linearLayout5.getLayoutParams().height = v14;
                linearLayout12 = linearLayout5;
                linearLayout12.setPadding(v2, v17, v2, v17);
                imageView0.setVisibility(android.view.View.VISIBLE);
                imageView0.setImageBitmap(cameraActivity0.mapBitmap);
            } else {
                linearLayout12 = linearLayout5;
                int v18 = v2;
                if (!cameraActivity0.isLatLng && !cameraActivity0.isAddress && !cameraActivity0.isMagneticField && !cameraActivity0.isCompass && !cameraActivity0.isWeather) {
                    cameraActivity0.width = canvas0.getWidth() - v3 * 2;
                    imageView0.setVisibility(android.view.View.GONE);
                    linearLayout12.getLayoutParams().height = v15;
                    linearLayout12.setPadding(v18, v18, v18, v18);
                } else {
                    imageView0.setVisibility(android.view.View.GONE);
                    cameraActivity0.width = canvas0.getWidth() - v3 * 2;
                    boolean z = cameraActivity0.isAddress;
                    if (z) {
                        if (!z || (cameraActivity0.isLatLng)) {
                        }

                        linearLayout12.getLayoutParams().height = v14;
                        linearLayout12.setPadding(v18, v17, v18, v17);
                    } else if (!cameraActivity0.isDateTime && !cameraActivity0.isLatLng || textView7.getMaxLines() == 1 && (!cameraActivity0.isCompass && !cameraActivity0.isMagneticField && !cameraActivity0.isWeather || ((cameraActivity0.isWeather) && !cameraActivity0.isCompass && !cameraActivity0.isMagneticField || (cameraActivity0.isCompass) && !cameraActivity0.isWeather && !cameraActivity0.isMagneticField || (cameraActivity0.isMagneticField) && !cameraActivity0.isWeather && !cameraActivity0.isCompass))) {
                        linearLayout12.getLayoutParams().height = v15;
                        linearLayout12.setPadding(v18, v3, v18, v3);
                    } else {
                        linearLayout12.getLayoutParams().height = v16;
                        linearLayout12.setPadding(v18, v17, v18, v17);
                    }
                }
            }

            int v19 = textView7.getMaxLines() == 1 && ((cameraActivity0.isWeather) || (cameraActivity0.isMagneticField) || (cameraActivity0.isCompass)) ? v5 : v5;
            textView7.setPadding(0, 0, v19, 0);
            if (!cameraActivity0.isAddress && !cameraActivity0.isLatLng && !cameraActivity0.isDateTime) {
                linearLayout3.setVisibility(android.view.View.GONE);
                linearLayout11.setOrientation(android.widget.LinearLayout.HORIZONTAL);
                linearLayout11.setGravity(17);
                linearLayout11.getLayoutParams().width = -1;
                linearLayout11.getLayoutParams().width = -1;
            } else {
                linearLayout3.setVisibility(android.view.View.VISIBLE);
                linearLayout11.setOrientation(android.widget.LinearLayout.VERTICAL);
                linearLayout11.setGravity(19);
                linearLayout11.getLayoutParams().width = -2;
                linearLayout11.getLayoutParams().width = -2;
            }

            if (!cameraActivity0.isLatLng && !cameraActivity0.isAddress && !cameraActivity0.isMagneticField && !cameraActivity0.isWeather && !cameraActivity0.isCompass && !cameraActivity0.isDateTime && !cameraActivity0.isMap) {
                relativeLayout0.setVisibility(android.view.View.GONE);
            } else {
                relativeLayout0.setVisibility(android.view.View.VISIBLE);
            }

            GradientDrawable gradientDrawable0 = (GradientDrawable) linearLayout12.getBackground().getCurrent();
            gradientDrawable0.setCornerRadius(((float) v19));
            gradientDrawable0.setColor(cameraActivity0.background_color);
            textView2.setTextColor(cameraActivity0.weather_color);
            textView4.setTextColor(cameraActivity0.magnetic_field_color);
            textView4.setText(cameraActivity0.str_magnaticField);
            textView3.setTextColor(cameraActivity0.compass_color);
            textView3.setText(cameraActivity0.str_compass);
            linearLayout12.setLayoutParams(new LinearLayout.LayoutParams(cameraActivity0.width, linearLayout12.getLayoutParams().height));
            textView7.setText(cameraActivity0.getAddress_line_1);
            if (cameraActivity0.isAddress) {
                textView5.setVisibility(android.view.View.VISIBLE);
                textView5.setText(cameraActivity0.getaddress);
            } else {
                textView5.setVisibility(android.view.View.GONE);
            }

            if (cameraActivity0.msTemprature_type.equals("Celsius")) {
                textView2.setText(HelperClass.getCelcius(cameraActivity0.mfTemprature_value));
            } else {
                textView2.setText(HelperClass.getFahrenheit(cameraActivity0.mfTemprature_value));
            }

            cameraActivity0.stampBitmap = cameraActivity0.loadBitmapFromView(view1);
            String s = CameraActivity.mSP.getString(cameraActivity0, "stamp_pos", "Bottom");
            float f1 = 0.0f;
            if (bitmap0 != null && cameraActivity0.stampBitmap != null) {
                if (s.equals("Bottom")) {
                    f1 = ((float) canvas0.getHeight()) - ((float) cameraActivity0.stampBitmap.getHeight());
                }

                float f2 = (float) (canvas0.getWidth() / 2 - cameraActivity0.stampBitmap.getWidth() / 2);
                canvas0.drawBitmap(cameraActivity0.stampBitmap, f2, f1, paint0);
                cameraActivity0.stampBitmap.recycle();
                cameraActivity0.stampBitmap = null;
                System.gc();
                return bitmap0;
            }
        } catch (OutOfMemoryError | Exception exception0) {
            exception0.printStackTrace();
            return null;
        }

        return bitmap0;
    }

    public Bitmap loadBitmapFromView(View view) {
        try {
            view.measure(0, 0);
            Bitmap createBitmap = Bitmap.createBitmap(view.getMeasuredWidth(), view.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(createBitmap);
            view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
            view.draw(canvas);
            System.gc();
            return createBitmap;
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
            return null;
        }
    }

    private String getRecentPath() {
        File file = new File(getStoragePath());
        if (!file.exists()) {
            return null;
        }
        File[] listFiles = file.listFiles();
        if (listFiles == null || listFiles.length <= 0) {
            return commnpath();
        }
        ArrayList arrayList = new ArrayList();
        for (File file2 : listFiles) {
            Date date = new Date(file2.lastModified());
            ImageGetSet imageGetSet = new ImageGetSet();
            if (file2.isFile()) {
                imageGetSet.setDateTime(date);
                imageGetSet.setImg_path(file2.getAbsolutePath());
                arrayList.add(imageGetSet);
            }
        }
        Collections.sort(arrayList, Collections.reverseOrder());
        if (arrayList.size() <= 0) {
            return null;
        }
        String img_path = ((ImageGetSet) arrayList.get(0)).getImg_path();
        return (img_path.contains(".jpg") || img_path.contains(".mp4")) ? img_path : commnpath();
    }

    public String commnpath() {
        File[] listFiles;
        File file = new File(Default.CAMERA_FOLDER);
        if (!file.exists() || (listFiles = file.listFiles()) == null || listFiles.length <= 0) {
            return null;
        }
        Arrays.sort(listFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
        return listFiles[0].getAbsolutePath();
    }

    public void updateGalleryIcon() {
        Glide.with((FragmentActivity) this).load(getRecentPath()).centerCrop().into(this.galleryButton);
    }

    public String getStoragePath() {
        String string = mSP.getString(this, SP.FOLDER_SD_NAME, Default.DEFAULT_FOLDER_NAME);
        if (!mSP.getBoolean(this, SP_Keys.IS_SD_CARD, false).booleanValue()) {
            return mSP.getString(this, SP.FOLDER_NAME, Default.DEFAULT_FOLDER_PATH);
        }
        ContentResolver contentResolver = getContentResolver();
        Uri parse = Uri.parse(string);
        if (Build.VERSION.SDK_INT >= 19) {
            contentResolver.takePersistableUriPermission(parse, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }
        String[] split = new File(parse.getPath()).getAbsolutePath().split("/");
        String str = "";
        for (String str2 : split) {
            if (str2.equals("tree")) {
                str = str + "storage/";
            } else {
                str = str + str2.replace(":", "/") + "/";
            }
        }
        File file = new File(str);
        if (!file.exists()) {
            file.mkdirs();
        }
        Log.e("new_save_location", str);
        return str;
    }

    private void openGallery(Uri uri) throws IOException {
        ParcelFileDescriptor openFileDescriptor = null;
        if (uri != null) {
            try {
                openFileDescriptor = getContentResolver().openFileDescriptor(uri, "r");
            } catch (IOException unused) {
            }
            if (openFileDescriptor == null) {
                uri = null;
            } else {
                openFileDescriptor.close();
            }
        }
        if (uri == null) {
            uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        }
        if (!this.is_test) {
            boolean z = USE_FRAME_PROCESSOR;
            isFromGal = USE_FRAME_PROCESSOR;
            mSP.setInteger(this, SP_Keys.GAL_OPEN_COUNT, Integer.valueOf(mSP.getInteger(this, SP_Keys.GAL_OPEN_COUNT).intValue() + 1));
            try {
                startActivity(new Intent("com.android.camera.action.REVIEW", uri));
            } catch (ActivityNotFoundException e) {
                e.printStackTrace();
                z = false;
            }
            if (!z) {
                Intent intent = new Intent("android.intent.action.VIEW", uri);
                if (intent.resolveActivity(getPackageManager()) != null) {
                    try {
                        startActivity(intent);
                    } catch (SecurityException e2) {
                        e2.printStackTrace();
                    }
                }
            }
        }
    }

    public File getExifTempFile(byte[] bArr) {
        File file = null;
        if (Build.VERSION.SDK_INT < 24) {
            try {
                file = File.createTempFile("opencamera_exif", "");
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                fileOutputStream.write(bArr);
                fileOutputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return file;
    }

    public String createMediaFilename(int i) {
        String str;
        String str2;
        String str3;
        mSP.getBoolean(this, SP.IS_FILE_DATE_TIME, Default.IS_MAIN_DT_FILE).booleanValue();
        boolean booleanValue = mSP.getBoolean(this, SP.IS_SEQUENCE, Default.IS_SEQUENCE_FILE).booleanValue();
        mSP.getBoolean(this, SP.IS_CUS_1, Default.IS_CUS_1).booleanValue();
        mSP.getBoolean(this, SP.IS_CUS_2, Default.IS_CUS_2).booleanValue();
        mSP.getBoolean(this, SP.IS_CUS_3, Default.IS_CUS_3).booleanValue();
        boolean booleanValue2 = mSP.getBoolean(this, SP.IS_LAT_LNG, Default.IS_LAT_LONG_FILE_NAME).booleanValue();
        boolean booleanValue3 = mSP.getBoolean(this, SP.IS_MAIN_ADDRESS, Default.IS_MAIN_ADDRESS_FILE_NAME).booleanValue();
        new ArrayList();
        String str4 = "";
        if (mSP.getArrayList(this) == null) {
            str4 = getTimeStamp();
        } else {
            ArrayList<ViewModel> arrayList = mSP.getArrayList(this);
            int intValue = mSP.getInteger(this, SP.DATE_TIME_INDEX, 0).intValue();
            int intValue2 = mSP.getInteger(this, SP.SEQUENCE_INDEX, 1).intValue();
            int intValue3 = mSP.getInteger(this, SP.ADDRESS_INDEX, 5).intValue();
            int intValue4 = mSP.getInteger(this, SP.LAT_LNG_INDEX, 6).intValue();
            arrayList.get(intValue).setValue(getTimeStamp());
            if (booleanValue) {
                int intValue5 = mSP.getInteger(this, SP.SEQUENCE_VALUE, 1).intValue();
                arrayList.get(intValue2).setValue(str4 + intValue5);
                mSP.setInteger(this, SP.SEQUENCE_VALUE, Integer.valueOf(intValue5 + 1));
            }
            if (booleanValue3) {
                boolean booleanValue4 = mSP.getBoolean(this, SP.IS_LINE_1, false).booleanValue();
                boolean booleanValue5 = mSP.getBoolean(this, SP.IS_LINE_2, false).booleanValue();
                boolean booleanValue6 = mSP.getBoolean(this, SP.IS_LINE_3, false).booleanValue();
                boolean booleanValue7 = mSP.getBoolean(this, SP.IS_LINE_4, false).booleanValue();
                String string = mSP.getString(this, SP.LOC_LINE_1_ADDRESS, str4);
                String string2 = mSP.getString(this, SP.LOC_LINE_2_CITY, str4);
                String string3 = mSP.getString(this, SP.LOC_LINE_3_STATE, str4);
                String string4 = mSP.getString(this, SP.LOC_LINE_4_COUNTRY, str4);
                if (!booleanValue4 || !isNotEmpty(string)) {
                    str3 = str4;
                } else {
                    str3 = str4 + "_" + string;
                }
                if (booleanValue5 && isNotEmpty(string2)) {
                    str3 = str3 + "_" + string2;
                }
                if (booleanValue6 && isNotEmpty(string3)) {
                    str3 = str3 + "_" + string3;
                }
                if (booleanValue7 && isNotEmpty(string4)) {
                    str3 = str3 + "_" + string4;
                }
                arrayList.get(intValue3).setValue(str3);
            }
            if (booleanValue2) {
                boolean booleanValue8 = mSP.getBoolean(this, SP.IS_DECIMAL_FILE, false).booleanValue();
                boolean booleanValue9 = mSP.getBoolean(this, SP.IS_DMS_FILE, false).booleanValue();
                String string5 = mSP.getString(this, SP.LATITUDE, str4);
                String string6 = mSP.getString(this, SP.LONGITUDE, str4);
                if (isNotEmpty(string5) && isNotEmpty(string6)) {
                    if (booleanValue8) {
                        str2 = str4 + "_" + string5 + "_" + string6;
                    } else {
                        str2 = str4;
                    }
                    if (booleanValue9) {
                        str2 = str2 + "_" + this.mHelperClass.dms_latlng(this);
                    }
                    arrayList.get(intValue4).setValue(str2);
                }
            }
            if (arrayList != null && arrayList.size() > 0) {
                if (!arrayList.get(0).getSelected().booleanValue() || !isNotEmpty(arrayList.get(0).getValue())) {
                    str = str4;
                } else {
                    str = str4 + arrayList.get(0).getValue();
                }
                if (arrayList.get(1).getSelected().booleanValue() && isNotEmpty(arrayList.get(1).getValue())) {
                    str = str + "_" + arrayList.get(1).getValue();
                }
                if (arrayList.get(2).getSelected().booleanValue() && isNotEmpty(arrayList.get(2).getValue())) {
                    str = str + "_" + arrayList.get(2).getValue();
                }
                if (arrayList.get(3).getSelected().booleanValue() && isNotEmpty(arrayList.get(3).getValue())) {
                    str = str + "_" + arrayList.get(3).getValue();
                }
                if (arrayList.get(4).getSelected().booleanValue() && isNotEmpty(arrayList.get(4).getValue())) {
                    str = str + "_" + arrayList.get(4).getValue();
                }
                if (arrayList.get(5).getSelected().booleanValue() && isNotEmpty(arrayList.get(5).getValue())) {
                    str = str + "_" + arrayList.get(5).getValue();
                }
                if (arrayList.get(6).getSelected().booleanValue() && isNotEmpty(arrayList.get(6).getValue())) {
                    str = str + "_" + arrayList.get(6).getValue();
                }
                if (isNotEmpty(str)) {
                    if (str.substring(0, 1).equals("_")) {
                        str = str.replaceFirst("_", str4);
                    }
                    str4 = str.replace("__", "_");
                } else {
                    str4 = str;
                }
            }
        }
        if (i == 0) {
            return str4 + ".mp4";
        } else if (i != 1) {
            return "IMG";
        } else {
            return str4 + ".jpg";
        }
    }

    boolean isNotEmpty(String str) {
        if (str == null) {
            return false;
        }
        return str.trim().isEmpty() ^ USE_FRAME_PROCESSOR;
    }

    private String getTimeStamp() {
        String str;
        boolean booleanValue = mSP.getBoolean(this, SP.IS_WEEK, false).booleanValue();
        if (mSP.getBoolean(this, SP.IS_24HR, false).booleanValue()) {
            str = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()).trim();
        } else {
            str = new SimpleDateFormat("yyyyMMdd_hmmssa").format(new Date()).trim();
        }
        if (!booleanValue) {
            return str;
        }
        return str + "_" + getWeek();
    }

    private String getWeek() {
        return new SimpleDateFormat("EEEE").format(new Date());
    }

    public void setExifFromData(byte[] bArr, File file) throws IOException {
        Throwable th;
        ByteArrayInputStream byteArrayInputStream = null;
        try {
            ByteArrayInputStream byteArrayInputStream2 = new ByteArrayInputStream(bArr);
            try {
                setExif(new ExifInterface(byteArrayInputStream2), new ExifInterface(file.getAbsolutePath()));
                byteArrayInputStream2.close();
            } catch (Throwable th2) {
                th = th2;
                byteArrayInputStream = byteArrayInputStream2;
                if (byteArrayInputStream != null) {
                    byteArrayInputStream.close();
                }
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
        }
    }

    public void setExifFromFile(File file, File file2) throws IOException {
        try {
            setExif(new ExifInterface(file.getAbsolutePath()), new ExifInterface(file2.getAbsolutePath()));
        } catch (NoClassDefFoundError e) {
            e.printStackTrace();
        }
    }

    private void setExifFromUri(Uri uri, File file) throws IOException {
        try {
            setExif(new ExifInterface(getContentResolver().openInputStream(uri)), new ExifInterface(file.getAbsolutePath()));
        } catch (NoClassDefFoundError e) {
            e.printStackTrace();
        }
    }

    private void setExif(ExifInterface exifInterface0, ExifInterface exifInterface1) throws IOException {
        double f1;
        double f;
        CameraActivity cameraActivity0;
        String s103;
        String s102;
        String s101;
        String s100;
        String s99;
        String s98;
        String s97;
        String s96;
        String s95;
        String s94;
        String s93;
        String s92;
        String s91;
        String s90;
        String s89;
        String s88;
        String s87;
        String s86;
        String s85;
        String s84;
        String s83;
        String s82;
        String s81;
        String s80;
        String s79;
        String s78;
        String s77;
        String s76;
        String s75;
        String s74;
        String s73;
        String s72;
        String s71;
        String s70;
        String s69;
        String s68;
        String s67;
        String s66;
        String s65;
        String s64;
        String s23;
        String s22;
        String s21;
        String s18;
        ExifInterface exifInterface2 = exifInterface0;
        ExifInterface exifInterface3 = exifInterface1;
        String s = exifInterface2.getAttribute("FNumber");
        String s1 = exifInterface2.getAttribute("DateTime");
        String s2 = exifInterface2.getAttribute("ExposureTime");
        String s3 = exifInterface2.getAttribute("Flash");
        String s4 = exifInterface2.getAttribute("FocalLength");
        String s5 = exifInterface2.getAttribute("GPSAltitude");
        String s6 = exifInterface2.getAttribute("GPSAltitudeRef");
        String s7 = exifInterface2.getAttribute("GPSDateStamp");
        String s8 = exifInterface2.getAttribute("GPSLatitude");
        String s9 = exifInterface2.getAttribute("GPSLatitudeRef");
        String s10 = exifInterface2.getAttribute("GPSLongitude");
        String s11 = exifInterface2.getAttribute("GPSLongitudeRef");
        String s12 = exifInterface2.getAttribute("GPSProcessingMethod");
        String s13 = exifInterface2.getAttribute("GPSTimeStamp");
        String s14 = exifInterface2.getAttribute("ISOSpeedRatings");
        String s15 = exifInterface2.getAttribute("Make");
        String s16 = exifInterface2.getAttribute("Model");
        String s17 = exifInterface2.getAttribute("WhiteBalance");
        if (Build.VERSION.SDK_INT >= 23) {
            s18 = exifInterface2.getAttribute("DateTimeDigitized");
            String s19 = exifInterface2.getAttribute("SubSecTime");
            String s20 = exifInterface2.getAttribute("SubSecTimeDigitized");
            s21 = exifInterface2.getAttribute("SubSecTimeOriginal");
            s22 = s19;
            s23 = s20;
        } else {
            s18 = null;
            s23 = null;
            s22 = null;
            s21 = null;
        }

        String s24 = s18;
        if (Build.VERSION.SDK_INT >= 24) {
            String s25 = exifInterface2.getAttribute("ApertureValue");
            String s26 = exifInterface2.getAttribute("BrightnessValue");
            String s27 = exifInterface2.getAttribute("CFAPattern");
            String s28 = exifInterface2.getAttribute("ColorSpace");
            String s29 = exifInterface2.getAttribute("ComponentsConfiguration");
            String s30 = exifInterface2.getAttribute("CompressedBitsPerPixel");
            String s31 = exifInterface2.getAttribute("Compression");
            String s32 = exifInterface2.getAttribute("Contrast");
            String s33 = exifInterface2.getAttribute("DateTimeOriginal");
            String s34 = exifInterface2.getAttribute("DeviceSettingDescription");
            String s35 = exifInterface2.getAttribute("DigitalZoomRatio");
            String s36 = exifInterface2.getAttribute("ExposureBiasValue");
            String s37 = exifInterface2.getAttribute("ExposureIndex");
            String s38 = exifInterface2.getAttribute("ExposureMode");
            String s39 = exifInterface2.getAttribute("ExposureProgram");
            String s40 = exifInterface2.getAttribute("FlashEnergy");
            String s41 = exifInterface2.getAttribute("FocalLengthIn35mmFilm");
            String s42 = exifInterface2.getAttribute("FocalPlaneResolutionUnit");
            String s43 = exifInterface2.getAttribute("FocalPlaneXResolution");
            String s44 = exifInterface2.getAttribute("FocalPlaneYResolution");
            String s45 = exifInterface2.getAttribute("GainControl");
            String s46 = exifInterface2.getAttribute("GPSAreaInformation");
            String s47 = exifInterface2.getAttribute("GPSDifferential");
            String s48 = exifInterface2.getAttribute("GPSDOP");
            String s49 = exifInterface2.getAttribute("GPSMeasureMode");
            String s50 = exifInterface2.getAttribute("ImageDescription");
            String s51 = exifInterface2.getAttribute("LightSource");
            String s52 = exifInterface2.getAttribute("MakerNote");
            String s53 = exifInterface2.getAttribute("MaxApertureValue");
            String s54 = exifInterface2.getAttribute("MeteringMode");
            String s55 = exifInterface2.getAttribute("OECF");
            String s56 = exifInterface2.getAttribute("PhotometricInterpretation");
            String s57 = exifInterface2.getAttribute("Saturation");
            String s58 = exifInterface2.getAttribute("SceneCaptureType");
            String s59 = exifInterface2.getAttribute("SceneType");
            String s60 = exifInterface2.getAttribute("SensingMethod");
            String s61 = exifInterface2.getAttribute("Sharpness");
            String s62 = exifInterface2.getAttribute("ShutterSpeedValue");
            String s63 = exifInterface2.getAttribute("Software");
            s64 = exifInterface2.getAttribute("UserComment");
            s65 = s27;
            s66 = s25;
            s67 = s26;
            s68 = s28;
            s69 = s29;
            s70 = s30;
            s71 = s31;
            s72 = s32;
            s73 = s33;
            s74 = s34;
            s75 = s35;
            s76 = s36;
            s77 = s37;
            s78 = s38;
            s79 = s39;
            s80 = s40;
            s81 = s41;
            s82 = s42;
            s83 = s43;
            s84 = s44;
            s85 = s45;
            s86 = s46;
            s87 = s47;
            s88 = s48;
            s89 = s49;
            s90 = s50;
            s91 = s51;
            s92 = s52;
            s93 = s53;
            s94 = s54;
            s95 = s55;
            s96 = s56;
            s97 = s57;
            s98 = s58;
            s99 = s59;
            s100 = s60;
            s101 = s61;
            s102 = s62;
            s103 = s63;
        } else {
            s66 = null;
            s67 = null;
            s65 = null;
            s68 = null;
            s69 = null;
            s70 = null;
            s71 = null;
            s72 = null;
            s73 = null;
            s74 = null;
            s75 = null;
            s76 = null;
            s77 = null;
            s78 = null;
            s79 = null;
            s80 = null;
            s81 = null;
            s82 = null;
            s83 = null;
            s84 = null;
            s85 = null;
            s86 = null;
            s87 = null;
            s88 = null;
            s89 = null;
            s90 = null;
            s91 = null;
            s92 = null;
            s93 = null;
            s94 = null;
            s95 = null;
            s96 = null;
            s97 = null;
            s98 = null;
            s99 = null;
            s100 = null;
            s101 = null;
            s102 = null;
            s103 = null;
            s64 = null;
        }

        if (s != null) {
            exifInterface3.setAttribute("FNumber", s);
        }

        if (s1 != null) {
            exifInterface3.setAttribute("DateTime", s1);
        }

        if (s2 != null) {
            exifInterface3.setAttribute("ExposureTime", s2);
        }

        if (s3 != null) {
            exifInterface3.setAttribute("Flash", s3);
        }

        if (s4 != null) {
            exifInterface3.setAttribute("FocalLength", s4);
        }

        if (s5 != null) {
            exifInterface3.setAttribute("GPSAltitude", s5);
        }

        if (s6 != null) {
            exifInterface3.setAttribute("GPSAltitudeRef", s6);
        }

        if (s7 != null) {
            exifInterface3.setAttribute("GPSDateStamp", s7);
        }

        if (s8 == null) {
            Log.e(":::location:::", "exif_gps_latitude null: ");
            cameraActivity0 = this;
            Location location0 = cameraActivity0.mCurrentLocation;
            if (location0 == null) {
                f = 0.0;
            } else {
                f = location0.getLatitude();
                Log.e(":::location:::", "mCurrentLocation not null: " + f);
                String s104 = cameraActivity0.dec2DMS(f);
                Log.e(":::location:::", "exif_longi: " + s104);
                exifInterface2.setAttribute("GPSLatitude", s104);
            }
        } else {
            Log.e(":::location:::", "exif_gps_latitude: ");
            exifInterface3.setAttribute("GPSLatitude", s8);
            cameraActivity0 = this;
            f = 0.0;
        }

        if (s9 != null) {
            exifInterface3.setAttribute("GPSLatitudeRef", s9);
        } else if (f > 0.0) {
            exifInterface2.setAttribute("GPSLatitudeRef", "N");
        } else {
            exifInterface2.setAttribute("GPSLatitudeRef", "S");
        }

        if (s10 == null) {
            Location location1 = cameraActivity0.mCurrentLocation;
            if (location1 == null) {
                f1 = 0.0;
            } else {
                f1 = location1.getLongitude();
                String s105 = cameraActivity0.dec2DMS(f1);
                Log.e(":::location:::", "exif_longi: " + s105);
                exifInterface2.setAttribute("GPSLongitude", s105);
            }
        } else {
            exifInterface3.setAttribute("GPSLongitude", s10);
            f1 = 0.0;
        }

        if (s11 != null) {
            exifInterface3.setAttribute("GPSLongitudeRef", s11);
        } else if (f1 > 0.0) {
            exifInterface2.setAttribute("GPSLongitudeRef", "E");
        } else {
            exifInterface2.setAttribute("GPSLongitudeRef", "W");
        }

        if (s12 != null) {
            exifInterface3.setAttribute("GPSProcessingMethod", s12);
        }

        if (s13 != null) {
            exifInterface3.setAttribute("GPSTimeStamp", s13);
        }

        if (s14 != null) {
            exifInterface3.setAttribute("ISOSpeedRatings", s14);
        }

        if (s15 != null) {
            exifInterface3.setAttribute("Make", s15);
        }

        if (s16 != null) {
            exifInterface3.setAttribute("Model", s16);
        }

        if (s17 != null) {
            exifInterface3.setAttribute("WhiteBalance", s17);
        }

        if (Build.VERSION.SDK_INT >= 23) {
            if (s24 != null) {
                exifInterface3.setAttribute("DateTimeDigitized", s24);
            }

            if (s22 != null) {
                exifInterface3.setAttribute("SubSecTime", s22);
            }

            if (s23 != null) {
                exifInterface3.setAttribute("SubSecTimeDigitized", s23);
            }

            String s106 = s21;
            if (s106 != null) {
                exifInterface3.setAttribute("SubSecTimeOriginal", s106);
            }
        }

        if (Build.VERSION.SDK_INT >= 24) {
            if (s66 != null) {
                exifInterface3.setAttribute("ApertureValue", s66);
            }

            if (s67 != null) {
                exifInterface3.setAttribute("BrightnessValue", s67);
            }

            String s107 = s65;
            if (s107 != null) {
                exifInterface3.setAttribute("CFAPattern", s107);
            }

            String s108 = s68;
            if (s108 != null) {
                exifInterface3.setAttribute("ColorSpace", s108);
            }

            String s109 = s69;
            if (s109 != null) {
                exifInterface3.setAttribute("ComponentsConfiguration", s109);
            }

            String s110 = s70;
            if (s110 != null) {
                exifInterface3.setAttribute("CompressedBitsPerPixel", s110);
            }

            String s111 = s71;
            if (s111 != null) {
                exifInterface3.setAttribute("Compression", s111);
            }

            String s112 = s72;
            if (s112 != null) {
                exifInterface3.setAttribute("Contrast", s112);
            }

            String s113 = s73;
            if (s113 != null) {
                exifInterface3.setAttribute("DateTimeOriginal", s113);
            }

            String s114 = s74;
            if (s114 != null) {
                exifInterface3.setAttribute("DeviceSettingDescription", s114);
            }

            String s115 = s75;
            if (s115 != null) {
                exifInterface3.setAttribute("DigitalZoomRatio", s115);
            }

            String s116 = s76;
            if (s116 != null) {
                exifInterface3.setAttribute("ExposureBiasValue", s116);
            }

            String s117 = s77;
            if (s117 != null) {
                exifInterface3.setAttribute("ExposureIndex", s117);
            }

            String s118 = s78;
            if (s118 != null) {
                exifInterface3.setAttribute("ExposureMode", s118);
            }

            String s119 = s79;
            if (s119 != null) {
                exifInterface3.setAttribute("ExposureProgram", s119);
            }

            String s120 = s80;
            if (s120 != null) {
                exifInterface3.setAttribute("FlashEnergy", s120);
            }

            String s121 = s81;
            if (s121 != null) {
                exifInterface3.setAttribute("FocalLengthIn35mmFilm", s121);
            }

            String s122 = s82;
            if (s122 != null) {
                exifInterface3.setAttribute("FocalPlaneResolutionUnit", s122);
            }

            String s123 = s83;
            if (s123 != null) {
                exifInterface3.setAttribute("FocalPlaneXResolution", s123);
            }

            String s124 = s84;
            if (s124 != null) {
                exifInterface3.setAttribute("FocalPlaneYResolution", s124);
            }

            String s125 = s85;
            if (s125 != null) {
                exifInterface3.setAttribute("GainControl", s125);
            }

            String s126 = s86;
            if (s126 != null) {
                exifInterface3.setAttribute("GPSAreaInformation", s126);
            }

            String s127 = s87;
            if (s127 != null) {
                exifInterface3.setAttribute("GPSDifferential", s127);
            }

            String s128 = s88;
            if (s128 != null) {
                exifInterface3.setAttribute("GPSDOP", s128);
            }

            String s129 = s89;
            if (s129 != null) {
                exifInterface3.setAttribute("GPSMeasureMode", s129);
            }

            String s130 = s90;
            if (s130 != null) {
                exifInterface3.setAttribute("ImageDescription", s130);
            }

            String s131 = s91;
            if (s131 != null) {
                exifInterface3.setAttribute("LightSource", s131);
            }

            String s132 = s92;
            if (s132 != null) {
                exifInterface3.setAttribute("MakerNote", s132);
            }

            String s133 = s93;
            if (s133 != null) {
                exifInterface3.setAttribute("MaxApertureValue", s133);
            }

            String s134 = s94;
            if (s134 != null) {
                exifInterface3.setAttribute("MeteringMode", s134);
            }

            String s135 = s95;
            if (s135 != null) {
                exifInterface3.setAttribute("OECF", s135);
            }

            String s136 = s96;
            if (s136 != null) {
                exifInterface3.setAttribute("PhotometricInterpretation", s136);
            }

            String s137 = s97;
            if (s137 != null) {
                exifInterface3.setAttribute("Saturation", s137);
            }

            String s138 = s98;
            if (s138 != null) {
                exifInterface3.setAttribute("SceneCaptureType", s138);
            }

            String s139 = s99;
            if (s139 != null) {
                exifInterface3.setAttribute("SceneType", s139);
            }

            String s140 = s100;
            if (s140 != null) {
                exifInterface3.setAttribute("SensingMethod", s140);
            }

            String s141 = s101;
            if (s141 != null) {
                exifInterface3.setAttribute("Sharpness", s141);
            }

            String s142 = s102;
            if (s142 != null) {
                exifInterface3.setAttribute("ShutterSpeedValue", s142);
            }

            String s143 = s103;
            if (s143 != null) {
                exifInterface3.setAttribute("Software", s143);
            }

            String s144 = s64;
            if (s144 != null) {
                exifInterface3.setAttribute("UserComment", s144);
            }
        }

        cameraActivity0.setDateTimeExif(exifInterface3);
        exifInterface1.saveAttributes();
    }

    String dec2DMS(double d) {
        String str = "";
        String str2 = d < 0.0d ? "-" : str;
        double abs = Math.abs(d);
        int i = (int) abs;
        boolean z = USE_FRAME_PROCESSOR;
        boolean z2 = i == 0 ? USE_FRAME_PROCESSOR : false;
        String valueOf = String.valueOf(i);
        double d2 = (abs - ((double) i)) * 60.0d;
        int i2 = (int) d2;
        boolean z3 = (!z2 || i2 != 0) ? false : USE_FRAME_PROCESSOR;
        String valueOf2 = String.valueOf(i2);
        int i3 = (int) ((d2 - ((double) i2)) * 60.0d);
        if (!z3 || i3 != 0) {
            z = false;
        }
        String valueOf3 = String.valueOf(i3);
        if (!z) {
            str = str2;
        }
        return str + valueOf + "°" + valueOf2 + "'" + valueOf3 + "\"";
    }

    private void setDateTimeExif(ExifInterface exifInterface) {
        String attribute = exifInterface.getAttribute(ExifInterface.TAG_DATETIME);
        if (attribute != null) {
            exifInterface.setAttribute("DateTimeOriginal", attribute);
            exifInterface.setAttribute("DateTimeDigitized", attribute);
        }
    }

    private void dissmissDialog() {
        HelperClass.dismissProgressDialog();
    }


    public class Listener extends CameraListener {

        @Override 
        public void onCameraOpened(CameraOptions cameraOptions) {
            camera_in_background = CameraActivity.USE_FRAME_PROCESSOR;
            compass.start();
            setUpStampLayout();
            CameraView.Stop_video = 0;
            CameraView.outputRation = null;
            setRatio();
            gpsflag = 1;


           Collection<Flash> flashes =  cameraOptions.getSupportedFlash();
            mFlashvalues = new ArrayList<>();
           if(flashes!=null && !flashes.isEmpty()){
               mFlashvalues.addAll(flashes);
           }
            if (mFlashvalues.size() > 1) {
                Collections.sort(mFlashvalues);
                updateCycleFlashIcon();
            }
        }

        @Override 
        public void onCameraError(CameraException cameraException) {
            super.onCameraError(cameraException);
            stopDateTimer();
        }

        @Override 
        public void onCameraClosed() {
            super.onCameraClosed();
            stopDateTimer();
            gpsflag = 0;
        }

        @Override 
        public void onAutoFocusStart(PointF pointF) {
            super.onAutoFocusStart(pointF);
        }

        @Override 
        public void onAutoFocusEnd(boolean z, PointF pointF) {
            super.onAutoFocusEnd(z, pointF);
        }

        @Override 
        public void onOrientationChanged(int i) {
            super.onOrientationChanged(i);
        }

        @Override 
        public void onPictureTaken(PictureResult pictureResult) {
            super.onPictureTaken(pictureResult);
            CaptureImage(pictureResult);
        }

        @Override 
        public void onVideoTaken(VideoResult videoResult) {
            super.onVideoTaken(videoResult);
            CameraActivity cameraActivity = CameraActivity.this;
            File files = new File(getFilesDir(), "video.mp4");
            Uri uriForFile = FileProvider.getUriForFile(CameraActivity.this, getPackageName() + ".provider", files);


            if (play_pasuefalge == 1) {
                try {
                    FileInputStream createInputStream = getContentResolver().openAssetFileDescriptor(uriForFile, "r").createInputStream();
                    File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString());
                    if (!file.exists()) {
                        file.mkdirs();
                    }
                    File file2 = new File(file, "save_" + System.currentTimeMillis() + ".mp4");
                    if (file2.exists()) {
                        file2.delete();
                    }
                    FileOutputStream fileOutputStream = new FileOutputStream(file2);
                    byte[] bArr = new byte[1024];
                    while (true) {
                        int read = createInputStream.read(bArr);
                        if (read <= 0) {
                            break;
                        }
                        fileOutputStream.write(bArr, 0, read);
                    }
                    createInputStream.close();
                    fileOutputStream.close();
                    video_List.add(file2.getPath());
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
            }
            if (play_pasuefalge != 1) {
                try {
                    saveVideo(uriForFile);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            } else if (CameraView.Stop_video == 0) {
                appendTwoVideos();
            }
        }

        @Override 
        public void onVideoRecordingStart() {
            super.onVideoRecordingStart();
        }

        @Override 
        public void onVideoRecordingEnd() {
            super.onVideoRecordingEnd();
        }

        @Override 
        public void onExposureCorrectionChanged(float f, float[] fArr, PointF[] pointFArr) {
            super.onExposureCorrectionChanged(f, fArr, pointFArr);
        }

        @Override 
        public void onZoomChanged(float f, float[] fArr, PointF[] pointFArr) {
            super.onZoomChanged(f, fArr, pointFArr);
        }
    }


    public class ImageStampAsync extends AsyncTask<MyObject, Void, Void> {

        public Void doInBackground(MyObject... myObjectArr) {
            String str;
            myObjectWeakReference = new WeakReference(myObjectArr[0]);
            Bitmap drawStamp = drawStamp(((MyObject) myObjectWeakReference.get()).getBitmap());
            System.gc();
            if (drawStamp != null) {
                if (CameraActivity.mSP.getBoolean(CameraActivity.this, SP_Keys.IS_SD_CARD, false).booleanValue()) {
                    String createMediaFilename = createMediaFilename(1);
                    String string = CameraActivity.mSP.getString(CameraActivity.this, SP.FOLDER_SD_NAME, "");
                    Uri parse = Uri.parse(string);
                    String str2 = new File(parse.getPath()).getAbsolutePath() + createMediaFilename;
                    File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), createMediaFilename);
                    try {
                        FileOutputStream fileOutputStream = new FileOutputStream(file, false);
                        drawStamp.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
                        fileOutputStream.flush();
                        fileOutputStream.close();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e2) {
                        e2.printStackTrace();
                    }
                    Log.e("treeUri", "" + string);
                    if (string != null) {
                        ContentResolver contentResolver = getContentResolver();
                        Uri parse2 = Uri.parse(string);
                        if (Build.VERSION.SDK_INT >= 19) {
                            contentResolver.takePersistableUriPermission(parse2, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        }
                        String[] split = str2.split("/");
                        if (split == null || split.length <= 0 || split.length - 1 <= 3) {
                            str = "";
                        } else {
                            str = "";
                            for (int i = 3; i < split.length - 1; i++) {
                                str = str + split[i] + "/";
                            }
                        }
                        if (str.endsWith("/")) {
                            str = str.substring(0, str.length() - 1);
                        }
                        int i2 = 21;
                        try {
                            Uri parse3 = Uri.parse(String.valueOf(Build.VERSION.SDK_INT >= 21 ? DocumentsContract.buildDocumentUriUsingTree(parse, DocumentsContract.getTreeDocumentId(parse) + str) : null));
                            Uri uri = parse3;
                            Cursor query = contentResolver.query(parse3, new String[]{"_display_name", "mime_type"}, null, null, null);
                            if (query != null) {
                                while (query.moveToNext()) {
                                    String[] split2 = str2.split("/");
                                    String str3 = split2[split2.length - 1];
                                    String str4 = str + "/" + createMediaFilename;
                                    if (Build.VERSION.SDK_INT >= i2) {
                                        DocumentsContract.buildDocumentUriUsingTree(parse, DocumentsContract.getTreeDocumentId(parse) + str4);
                                    }
                                    Uri createDocument = Build.VERSION.SDK_INT >= i2 ? DocumentsContract.createDocument(contentResolver, uri, "image/*", "" + createMediaFilename) : null;
                                    FileInputStream fileInputStream = new FileInputStream(file);
                                    byte[] bArr = new byte[(int) file.length()];
                                    fileInputStream.read(bArr);
                                    fileInputStream.close();
                                    try {
                                        OutputStream openOutputStream = getContentResolver().openOutputStream(createDocument);
                                        if (openOutputStream != null) {
                                            openOutputStream.write(bArr);
                                            openOutputStream.close();
                                            file.delete();
                                            System.gc();
                                        } else {
                                            file.delete();
                                            System.gc();
                                        }
                                    } catch (IOException e3) {
                                        e3.printStackTrace();
                                    }
                                    uri = uri;
                                    i2 = 21;
                                }
                                query.close();
                            }
                        } catch (Exception e4) {
                            e4.printStackTrace();
                        }
                    }
                } else {
                    File file2 = new File(getStoragePath());
                    if (!file2.exists()) {
                        file2.mkdirs();
                    }
                    File file3 = new File(file2, createMediaFilename(1));
                    try {
                        FileOutputStream fileOutputStream2 = new FileOutputStream(file3, false);
                        drawStamp.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream2);
                        fileOutputStream2.flush();
                        fileOutputStream2.close();
                    } catch (FileNotFoundException e5) {
                        e5.printStackTrace();
                    } catch (IOException e6) {
                        e6.printStackTrace();
                    }
                    byte[] data = ((MyObject) myObjectWeakReference.get()).getData();
                    if (Build.VERSION.SDK_INT >= 24) {
                        try {
                            setExifFromData(data, file3);
                        } catch (IOException e7) {
                            e7.printStackTrace();
                        }
                    } else {
                        File exifTempFile = getExifTempFile(data);
                        if (exifTempFile != null) {
                            try {
                                setExifFromFile(exifTempFile, file3);
                            } catch (IOException e8) {
                                e8.printStackTrace();
                            }
                        }
                    }
                    File exifTempFile2 = getExifTempFile(data);
                    if (exifTempFile2 != null) {
                        try {
                            setExifFromFile(exifTempFile2, file3);
                        } catch (IOException e9) {
                            e9.printStackTrace();
                        }
                    }
                    MediaScannerConnection.scanFile(getApplicationContext(), new String[]{file3.toString()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                        @Override 
                        public void onScanCompleted(String str5, Uri uri2) {
                            Log.i("ExternalStorage", "Scanned " + str5 + ":");
                            StringBuilder sb = new StringBuilder();
                            sb.append("-> uri=");
                            sb.append(uri2);
                            Log.i("ExternalStorage", sb.toString());
                        }
                    });
                    drawStamp.recycle();
                    return null;
                }
            }
            return null;
        }

        public void onPostExecute(Void r3) {
            super.onPostExecute(r3);
            AlphaAnimation alphaAnimation = new AlphaAnimation(0.2f, 1.0f);
            alphaAnimation.setDuration(0);
            alphaAnimation.setFillAfter(CameraActivity.USE_FRAME_PROCESSOR);
            takePhotoButton.startAnimation(alphaAnimation);
            takePhotoButton.setEnabled(CameraActivity.USE_FRAME_PROCESSOR);
            takeVideoButton.setEnabled(CameraActivity.USE_FRAME_PROCESSOR);
            pasue_button.setEnabled(CameraActivity.USE_FRAME_PROCESSOR);
            updateGalleryIcon();
        }
    }




}
