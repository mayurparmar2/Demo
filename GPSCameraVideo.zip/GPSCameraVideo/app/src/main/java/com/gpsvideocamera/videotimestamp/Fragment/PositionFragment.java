package com.gpsvideocamera.videotimestamp.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.SP;


public class PositionFragment extends Fragment implements View.OnClickListener {
    ImageView mImg_bottom;
    ImageView mImg_top;
    LinearLayout mLi_bottom;
    LinearLayout mLi_top;
    String mPos_type;
    SP mSP;
    TextView mTv_bottom;
    TextView mTv_top;

    @Override 
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_pos, viewGroup, false);
    }

    @Override 
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.mSP = new SP(getActivity());
        this.mLi_bottom = (LinearLayout) view.findViewById(R.id.li_bottom);
        this.mImg_bottom = (ImageView) view.findViewById(R.id.img_bottom);
        this.mTv_bottom = (TextView) view.findViewById(R.id.tv_bottom);
        this.mLi_top = (LinearLayout) view.findViewById(R.id.li_top);
        this.mImg_top = (ImageView) view.findViewById(R.id.img_top);
        this.mTv_top = (TextView) view.findViewById(R.id.tv_top);
        String string = this.mSP.getString(getActivity(), "pos_type_temp", "Bottom");
        this.mPos_type = string;
        if (string.equals("Bottom")) {
            this.mImg_top.setImageResource(R.drawable.ic_radio_btn_white);
            this.mImg_bottom.setImageResource(R.drawable.ic_radiobtn);
        } else {
            this.mImg_top.setImageResource(R.drawable.ic_radiobtn);
            this.mImg_bottom.setImageResource(R.drawable.ic_radio_btn_white);
        }
        this.mLi_bottom.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view2) {
                PositionFragment.this.onClick(view2);
            }
        });
        this.mLi_top.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view2) {
                PositionFragment.this.onClick(view2);
            }
        });
    }

    @Override 
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.li_bottom) {
            this.mSP.setString(getActivity(), "pos_type_temp", "Bottom");
            this.mImg_top.setImageResource(R.drawable.ic_radio_btn_white);
            this.mImg_bottom.setImageResource(R.drawable.ic_radiobtn);
        } else if (id == R.id.li_top) {
            this.mSP.setString(getActivity(), "pos_type_temp", "Top");
            this.mImg_top.setImageResource(R.drawable.ic_radiobtn);
            this.mImg_bottom.setImageResource(R.drawable.ic_radio_btn_white);
        }
    }
}
