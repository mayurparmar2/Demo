package com.gpsvideocamera.videotimestamp.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.gpsvideocamera.videotimestamp.Adapter.TemplateAdapter;
import com.gpsvideocamera.videotimestamp.Interface.OnRecyclerItemClickListener;
import com.gpsvideocamera.videotimestamp.Model.TemplateModel;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.Default;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import java.util.ArrayList;
import java.util.List;


public class Template_Fragment extends Fragment {
    OnTemplateDataListener callback;
    boolean isCompassFound;
    private TemplateAdapter mAdapter;
    List<TemplateModel> mList = new ArrayList();
    private RecyclerView mRecyclerview;
    SP mSP;
    String[] mTempNameArray;

    
    interface OnTemplateDataListener {
        void onTemplateSelected(int i);
    }

    public void setOnTemplate_DataListener(OnTemplateDataListener onTemplateDataListener) {
        this.callback = onTemplateDataListener;
    }

    @Override 
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_template, viewGroup, false);
    }

    @Override 
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        init(view);
    }

    private void init(View view) {
        SP sp = new SP(getActivity());
        this.mSP = sp;
        this.isCompassFound = sp.getBoolean(getActivity(), SP.COMPASS_FOUND, false).booleanValue();
        this.mRecyclerview = (RecyclerView) view.findViewById(R.id.fragment_recyclerview);
        fillList();
    }

    private void fillList() {
        List<TemplateModel> list = this.mList;
        if (list != null) {
            if (list.size() > 0) {
                this.mList.clear();
            }
            TemplateModel templateModel = new TemplateModel();
            templateModel.setTitle(getString(R.string.map));
            templateModel.setSpKey("Map");
            templateModel.setSelected(this.mSP.getBoolean(getActivity(), templateModel.getSpKey(), Default.IS_MAP).booleanValue());
            this.mList.add(0, templateModel);
            TemplateModel templateModel2 = new TemplateModel();
            templateModel2.setTitle(getString(R.string.address));
            templateModel2.setSpKey("Address");
            templateModel2.setSelected(this.mSP.getBoolean(getActivity(), templateModel2.getSpKey(), Default.IS_ADDRESS).booleanValue());
            this.mList.add(1, templateModel2);
            TemplateModel templateModel3 = new TemplateModel();
            templateModel3.setTitle(getString(R.string.lat_lng));
            templateModel3.setSpKey("Lat/Long");
            templateModel3.setSelected(this.mSP.getBoolean(getActivity(), templateModel3.getSpKey(), Default.IS_LAT_LNG_TEMPLATE).booleanValue());
            this.mList.add(2, templateModel3);
            TemplateModel templateModel4 = new TemplateModel();
            templateModel4.setTitle(getString(R.string.date_and_time));
            templateModel4.setSpKey("date_and_time");
            templateModel4.setSelected(this.mSP.getBoolean(getActivity(), templateModel4.getSpKey(), Default.IS_WEATHER).booleanValue());
            this.mList.add(3, templateModel4);
            TemplateModel templateModel5 = new TemplateModel();
            templateModel5.setTitle(getString(R.string.weather));
            templateModel5.setSpKey("Weather");
            templateModel5.setSelected(this.mSP.getBoolean(getActivity(), templateModel5.getSpKey(), Default.IS_WEATHER).booleanValue());
            this.mList.add(4, templateModel5);
            if (this.isCompassFound) {
                TemplateModel templateModel6 = new TemplateModel();
                templateModel6.setTitle(getString(R.string.magnetic_field));
                templateModel6.setSpKey("Magnetic Field");
                templateModel6.setSelected(this.mSP.getBoolean(getActivity(), templateModel6.getSpKey(), Default.IS_MAGNETIC_FIELD).booleanValue());
                this.mList.add(5, templateModel6);
                TemplateModel templateModel7 = new TemplateModel();
                templateModel7.setTitle(getString(R.string.compass));
                templateModel7.setSpKey("Compass");
                templateModel7.setSelected(this.mSP.getBoolean(getActivity(), templateModel7.getSpKey(), Default.IS_COMPASS).booleanValue());
                this.mList.add(6, templateModel7);
            }
        }
        setAdapter();
    }

    private void setAdapter() {
        this.mRecyclerview.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        TemplateAdapter templateAdapter = new TemplateAdapter(getContext(), this.mList, new OnRecyclerItemClickListener() { 
            @Override 
            public void OnLongClick_(int i, View view) {
            }

            @Override 
            public void OnClick_(int i, View view) {
                Template_Fragment.this.callback.onTemplateSelected(i);
            }
        });
        this.mAdapter = templateAdapter;
        this.mRecyclerview.setAdapter(templateAdapter);
    }

    @Override 
    public void onDetach() {
        super.onDetach();
        this.callback = null;
    }
}
