package com.gpsvideocamera.videotimestamp.Model;


public class TransferApp {
    private String enable;
    private String link;
    private String transfer_text;
    private String transfer_title;

    public TransferApp(String str, String str2, String str3, String str4) {
        this.enable = str;
        this.transfer_title = str2;
        this.transfer_text = str3;
        this.link = str4;
    }

    public String getEnable() {
        return this.enable;
    }

    public void setEnable(String str) {
        this.enable = str;
    }

    public String getTransfer_title() {
        return this.transfer_title;
    }

    public void setTransfer_title(String str) {
        this.transfer_title = str;
    }

    public String getTransfer_text() {
        return this.transfer_text;
    }

    public void setTransfer_text(String str) {
        this.transfer_text = str;
    }

    public String getLink() {
        return this.link;
    }

    public void setLink(String str) {
        this.link = str;
    }
}
