package com.gpsvideocamera.videotimestamp.Adapter;

import android.content.Context;
import android.content.res.TypedArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.card.MaterialCardView;
import com.gpsvideocamera.videotimestamp.Interface.OnRecyclerItemClickListener;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.SP;


public class LanguageAdapter extends RecyclerView.Adapter<LanguageAdapter.Holder> {
    TypedArray Img_flag;
    private final int count;
    Context mContext;
    String[] mLanArray;
    String[] mLanArray_real;
    SP mSP;
    OnRecyclerItemClickListener onRecyclerItemClickListener;
    int seleced_pos;

    public LanguageAdapter(Context context, String[] strArr, String[] strArr2, TypedArray typedArray, OnRecyclerItemClickListener onRecyclerItemClickListener) {
        this.seleced_pos = 0;
        this.mContext = context;
        this.mLanArray = strArr;
        this.mLanArray_real = strArr2;
        this.Img_flag = typedArray;
        this.onRecyclerItemClickListener = onRecyclerItemClickListener;
        SP sp = new SP(context);
        this.mSP = sp;
        int intValue = sp.getInteger(context, SP.LANGUAGE_COUNT, 0).intValue();
        this.count = intValue;
        if (intValue == 0) {
            this.seleced_pos = this.mSP.getInteger(context, SP.LANGUAGE_POS, -1).intValue();
            return;
        }
        int intValue2 = this.mSP.getInteger(context, SP.LANGUAGE_POS, 0).intValue();
        this.seleced_pos = intValue2;
        if (intValue2 == -1) {
            this.seleced_pos = 0;
        }
    }

    @Override 
    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_language_home, viewGroup, false));
    }

    public void refAdapter(int i) {
        this.seleced_pos = i;
        notifyDataSetChanged();
    }

    public void onBindViewHolder(Holder holder, int i) {
        TextView textView = holder.mtvTitle;
        textView.setText("" + this.mLanArray_real[i]);
        TextView textView2 = holder.tv_engle;
        textView2.setText("" + this.mLanArray[i]);
        holder.img_flag.setImageResource(this.Img_flag.getResourceId(i, 0));
        if (this.seleced_pos == i) {
            holder.img_chek.setVisibility(View.VISIBLE);
            holder.cardView.setStrokeColor(this.mContext.getResources().getColor(R.color._10aedb));
            return;
        }
        holder.img_chek.setVisibility(View.GONE);
        holder.cardView.setStrokeColor(this.mContext.getResources().getColor(R.color.card_border_00000029));
    }

    @Override 
    public int getItemCount() {
        return this.mLanArray.length;
    }

    
    public class Holder extends RecyclerView.ViewHolder {
        private MaterialCardView cardView;
        private ImageView img_chek;
        private ImageView img_flag;
        private TextView mtvTitle;
        private TextView tv_engle;

        public Holder(View view) {
            super(view);
            this.mtvTitle = (TextView) view.findViewById(R.id.tv_title);
            this.tv_engle = (TextView) view.findViewById(R.id.tv_english);
            this.img_chek = (ImageView) view.findViewById(R.id.img_check);
            this.img_flag = (ImageView) view.findViewById(R.id.img_flage);
            MaterialCardView materialCardView = (MaterialCardView) view.findViewById(R.id.cardView);
            this.cardView = materialCardView;
            materialCardView.setOnClickListener(new View.OnClickListener() {
                @Override 
                public void onClick(View view2) {
                    if (LanguageAdapter.this.onRecyclerItemClickListener != null) {
                        LanguageAdapter.this.onRecyclerItemClickListener.OnClick_(Holder.this.getAdapterPosition(), view2);
                    }
                }
            });
        }
    }
}
