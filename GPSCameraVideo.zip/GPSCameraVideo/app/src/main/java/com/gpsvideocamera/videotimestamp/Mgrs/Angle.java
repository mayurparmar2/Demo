package com.gpsvideocamera.videotimestamp.Mgrs;


import java.util.regex.Pattern;


public class Angle implements Comparable<Angle> {
    public static final String ANGLE_FORMAT_DD = "gov.nasa.worldwind.Geom.AngleDD";
    public static final String ANGLE_FORMAT_DMS = "gov.nasa.worldwind.Geom.AngleDMS";
    private static final double DEGREES_TO_RADIANS = 0.017453292519943295d;
    private static final double PIOver2 = 1.5707963267948966d;
    private static final double RADIANS_TO_DEGREES = 57.29577951308232d;
    public final double degrees;
    public final double radians;
    public static final Angle MINUTE = fromDegrees(0.016666666666666666d);
    public static final Angle NEG180 = fromDegrees(-180.0d);
    public static final Angle NEG360 = fromDegrees(-360.0d);
    public static final Angle NEG90 = fromDegrees(-90.0d);
    public static final Angle POS180 = fromDegrees(180.0d);
    public static final Angle POS360 = fromDegrees(360.0d);
    public static final Angle POS90 = fromDegrees(90.0d);
    public static final Angle SECOND = fromDegrees(2.777777777777778E-4d);
    public static final Angle ZERO = fromDegrees(0.0d);

    public static boolean isValidLatitude(double d) {
        return d >= -90.0d && d <= 90.0d;
    }

    public static boolean isValidLongitude(double d) {
        return d >= -180.0d && d <= 180.0d;
    }

    private static double normalizedDegreesLatitude(double d) {
        double d2 = 180.0d;
        double d3 = d % 180.0d;
        if (d3 <= 90.0d) {
            if (d3 >= -90.0d) {
                return d3;
            }
            d2 = -180.0d;
        }
        return d2 - d3;
    }

    private static double normalizedDegreesLongitude(double d) {
        double d2 = d % 360.0d;
        return d2 > 180.0d ? d2 - 360.0d : d2 < -180.0d ? d2 + 360.0d : d2;
    }

    public long getSizeInBytes() {
        return 8;
    }

    public static Angle fromDegrees(double d) {
        return new Angle(d, 0.017453292519943295d * d);
    }

    public static Angle fromRadians(double d) {
        return new Angle(RADIANS_TO_DEGREES * d, d);
    }

    public static Angle fromDegreesLatitude(double d) {
        if (d < -90.0d) {
            d = -90.0d;
        } else if (d > 90.0d) {
            d = 90.0d;
        }
        double d2 = 0.017453292519943295d * d;
        if (d2 < -1.5707963267948966d) {
            d2 = -1.5707963267948966d;
        } else if (d2 > 1.5707963267948966d) {
            d2 = 1.5707963267948966d;
        }
        return new Angle(d, d2);
    }

    public static Angle fromRadiansLatitude(double d) {
        if (d < -1.5707963267948966d) {
            d = -1.5707963267948966d;
        } else if (d > 1.5707963267948966d) {
            d = 1.5707963267948966d;
        }
        double d2 = RADIANS_TO_DEGREES * d;
        if (d2 < -90.0d) {
            d2 = -90.0d;
        } else if (d2 > 90.0d) {
            d2 = 90.0d;
        }
        return new Angle(d2, d);
    }

    public static Angle fromDegreesLongitude(double d) {
        if (d < -180.0d) {
            d = -180.0d;
        } else if (d > 180.0d) {
            d = 180.0d;
        }
        double d2 = 0.017453292519943295d * d;
        if (d2 < -3.141592653589793d) {
            d2 = -3.141592653589793d;
        } else if (d2 > 3.141592653589793d) {
            d2 = 3.141592653589793d;
        }
        return new Angle(d, d2);
    }

    public static Angle fromRadiansLongitude(double d) {
        if (d < -3.141592653589793d) {
            d = -3.141592653589793d;
        } else if (d > 3.141592653589793d) {
            d = 3.141592653589793d;
        }
        double d2 = RADIANS_TO_DEGREES * d;
        if (d2 < -180.0d) {
            d2 = -180.0d;
        } else if (d2 > 180.0d) {
            d2 = 180.0d;
        }
        return new Angle(d2, d);
    }

    public static Angle fromXY(double d, double d2) {
        double atan2 = Math.atan2(d2, d);
        return new Angle(RADIANS_TO_DEGREES * atan2, atan2);
    }

    public static Angle fromDMS(int i, int i2, int i3) {
        if (i2 < 0 || i2 >= 60) {
            throw new IllegalArgumentException("Argument Out Of Range");
        } else if (i3 < 0 || i3 >= 60) {
            throw new IllegalArgumentException("Argument Out Of Range");
        } else {
            double signum = (double) Math.signum((float) i);
            double abs = (double) Math.abs(i);
            double d = (double) i2;
            Double.isNaN(d);
            Double.isNaN(abs);
            double d2 = abs + (d / 60.0d);
            double d3 = (double) i3;
            Double.isNaN(d3);
            Double.isNaN(signum);
            return fromDegrees(signum * (d2 + (d3 / 3600.0d)));
        }
    }

    public static Angle fromDMdS(int i, double d) {
        if (d < 0.0d || d >= 60.0d) {
            throw new IllegalArgumentException("Argument Out Of Range");
        }
        double signum = (double) Math.signum((float) i);
        double abs = (double) Math.abs(i);
        Double.isNaN(abs);
        Double.isNaN(signum);
        return fromDegrees(signum * (abs + (d / 60.0d)));
    }

    public static Angle fromDMS(String str) {
        int i;
        if (str != null) {
            Pattern compile = Pattern.compile("([-|\\+]?\\d{1,3}[d|D|°|\\s](\\s*\\d{1,2}['|’|\\s])?(\\s*\\d{1,2}[\"|”|\\s])?\\s*([N|n|S|s|E|e|W|w])?\\s?)");
            if (compile.matcher(str + " ").matches()) {
                String trim = str.replaceAll("[D|d|°|'|’|\"|”]", " ").replaceAll("\\s+", " ").trim();
                char charAt = trim.toUpperCase().charAt(trim.length() - 1);
                int i2 = -1;
                int i3 = 0;
                if (!Character.isDigit(charAt)) {
                    i = (charAt == 'S' || charAt == 'W') ? -1 : 1;
                    trim = trim.substring(0, trim.length() - 1).trim();
                } else {
                    i = 1;
                }
                char charAt2 = trim.charAt(0);
                if (!Character.isDigit(charAt2)) {
                    if (charAt2 != '-') {
                        i2 = 1;
                    }
                    i *= i2;
                    trim = trim.substring(1, trim.length());
                }
                String[] split = trim.split(" ");
                int parseInt = Integer.parseInt(split[0]);
                int parseInt2 = split.length > 1 ? Integer.parseInt(split[1]) : 0;
                if (split.length > 2) {
                    i3 = Integer.parseInt(split[2]);
                }
                return fromDMS(parseInt, parseInt2, i3).multiply((double) i);
            }
            throw new IllegalArgumentException("Argument Out Of Range");
        }
        throw new IllegalArgumentException("String Is Null");
    }

    public Angle(Angle angle) {
        this.degrees = angle.degrees;
        this.radians = angle.radians;
    }

    private Angle(double d, double d2) {
        this.degrees = d;
        this.radians = d2;
    }

    public final double getDegrees() {
        return this.degrees;
    }

    public final double getRadians() {
        return this.radians;
    }

    public final Angle add(Angle angle) {
        if (angle != null) {
            return fromDegrees(this.degrees + angle.degrees);
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public final Angle subtract(Angle angle) {
        if (angle != null) {
            return fromDegrees(this.degrees - angle.degrees);
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public final Angle multiply(double d) {
        return fromDegrees(this.degrees * d);
    }

    public final double divide(Angle angle) {
        if (angle == null) {
            throw new IllegalArgumentException("Angle Is Null");
        } else if (angle.getDegrees() != 0.0d) {
            return this.degrees / angle.degrees;
        } else {
            throw new IllegalArgumentException("Divide By Zero");
        }
    }

    public final Angle addDegrees(double d) {
        return fromDegrees(this.degrees + d);
    }

    public final Angle subtractDegrees(double d) {
        return fromDegrees(this.degrees - d);
    }

    public final Angle divide(double d) {
        return fromDegrees(this.degrees / d);
    }

    public final Angle addRadians(double d) {
        return fromRadians(this.radians + d);
    }

    public final Angle subtractRadians(double d) {
        return fromRadians(this.radians - d);
    }

    public Angle angularDistanceTo(Angle angle) {
        if (angle != null) {
            double d = angle.subtract(this).degrees;
            if (d < -180.0d) {
                d += 360.0d;
            } else if (d > 180.0d) {
                d -= 360.0d;
            }
            return fromDegrees(Math.abs(d));
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public final double sin() {
        return Math.sin(this.radians);
    }

    public final double sinHalfAngle() {
        return Math.sin(this.radians * 0.5d);
    }

    public static Angle asin(double d) {
        return fromRadians(Math.asin(d));
    }

    public final double cos() {
        return Math.cos(this.radians);
    }

    public final double cosHalfAngle() {
        return Math.cos(this.radians * 0.5d);
    }

    public static Angle acos(double d) {
        return fromRadians(Math.acos(d));
    }

    public final double tanHalfAngle() {
        return Math.tan(this.radians * 0.5d);
    }

    public static Angle atan(double d) {
        return fromRadians(Math.atan(d));
    }

    public static Angle midAngle(Angle angle, Angle angle2) {
        if (angle != null && angle2 != null) {
            return fromDegrees((angle.degrees + angle2.degrees) * 0.5d);
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public static Angle average(Angle angle, Angle angle2) {
        if (angle != null && angle2 != null) {
            return fromDegrees((angle.degrees + angle2.degrees) * 0.5d);
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public static Angle average(Angle angle, Angle angle2, Angle angle3) {
        if (angle != null && angle2 != null && angle3 != null) {
            return fromDegrees(((angle.degrees + angle2.degrees) + angle3.degrees) / 3.0d);
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public static Angle mix(double d, Angle angle, Angle angle2) {
        if (angle == null || angle2 == null) {
            throw new IllegalArgumentException("Angle Is Null");
        } else if (d < 0.0d) {
            return angle;
        } else {
            if (d > 1.0d) {
                return angle2;
            }
            Angle rotationX = Quaternion.slerp(d, Quaternion.fromAxisAngle(angle, Vec4.UNIT_X), Quaternion.fromAxisAngle(angle2, Vec4.UNIT_X)).getRotationX();
            if (Double.isNaN(rotationX.degrees)) {
                return null;
            }
            return rotationX;
        }
    }

    public final int compareTo(Angle angle) {
        if (angle != null) {
            double d = this.degrees;
            double d2 = angle.degrees;
            if (d < d2) {
                return -1;
            }
            return d > d2 ? 1 : 0;
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public static Angle normalizedLatitude(Angle angle) {
        if (angle != null) {
            return fromDegrees(normalizedDegreesLatitude(angle.degrees));
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public static Angle normalizedLongitude(Angle angle) {
        if (angle != null) {
            return fromDegrees(normalizedDegreesLongitude(angle.degrees));
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public Angle normalizedLatitude() {
        return normalizedLatitude(this);
    }

    public Angle normalizedLongitude() {
        return normalizedLongitude(this);
    }

    public static boolean crossesLongitudeBoundary(Angle angle, Angle angle2) {
        if (angle != null && angle2 != null) {
            return Math.signum(angle.degrees) != Math.signum(angle2.degrees) && Math.abs(angle.degrees - angle2.degrees) > 180.0d;
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public static Angle max(Angle angle, Angle angle2) {
        return angle.degrees >= angle2.degrees ? angle : angle2;
    }

    public static Angle min(Angle angle, Angle angle2) {
        return angle.degrees <= angle2.degrees ? angle : angle2;
    }

    @Override 
    public final String toString() {
        return Double.toString(this.degrees) + 176;
    }

    public final String toDecimalDegreesString(int i) {
        if (i < 0 || i > 15) {
            throw new IllegalArgumentException("Argument Out Of Range");
        }
        return String.format("%." + i + "f°", Double.valueOf(this.degrees));
    }

    public final String toDMSString() {
        double d = this.degrees;
        int signum = (int) Math.signum(d);
        double d2 = (double) signum;
        Double.isNaN(d2);
        double d3 = d * d2;
        int floor = (int) Math.floor(d3);
        double d4 = (double) floor;
        Double.isNaN(d4);
        double d5 = (d3 - d4) * 60.0d;
        int floor2 = (int) Math.floor(d5);
        double d6 = (double) floor2;
        Double.isNaN(d6);
        int round = (int) Math.round((d5 - d6) * 60.0d);
        int i = 0;
        if (round == 60) {
            floor2++;
            round = 0;
        }
        if (floor2 == 60) {
            floor++;
        } else {
            i = floor2;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(signum == -1 ? "-" : "");
        sb.append(floor);
        sb.append(176);
        sb.append(' ');
        sb.append(i);
        sb.append(8217);
        sb.append(' ');
        sb.append(round);
        sb.append(8221);
        return sb.toString();
    }

    public final String toFormattedDMSString() {
        double d = this.degrees;
        int signum = (int) Math.signum(d);
        double d2 = (double) signum;
        Double.isNaN(d2);
        double d3 = d * d2;
        int floor = (int) Math.floor(d3);
        double d4 = (double) floor;
        Double.isNaN(d4);
        double d5 = (d3 - d4) * 60.0d;
        int floor2 = (int) Math.floor(d5);
        double d6 = (double) floor2;
        Double.isNaN(d6);
        double rint = Math.rint(((d5 - d6) * 60.0d) * 100.0d) / 100.0d;
        if (rint == 60.0d) {
            floor2++;
            rint = 0.0d;
        }
        if (floor2 == 60) {
            floor++;
            floor2 = 0;
        }
        return String.format("%4d° %2d’ %5.2f”", Integer.valueOf(signum * floor), Integer.valueOf(floor2), Double.valueOf(rint));
    }

    public final double[] toDMS() {
        double d = this.degrees;
        int signum = (int) Math.signum(d);
        double d2 = (double) signum;
        Double.isNaN(d2);
        double d3 = d * d2;
        int floor = (int) Math.floor(d3);
        double d4 = (double) floor;
        Double.isNaN(d4);
        double d5 = (d3 - d4) * 60.0d;
        int floor2 = (int) Math.floor(d5);
        double d6 = (double) floor2;
        Double.isNaN(d6);
        double rint = Math.rint(((d5 - d6) * 60.0d) * 100.0d) / 100.0d;
        if (rint == 60.0d) {
            floor2++;
            rint = 0.0d;
        }
        if (floor2 == 60) {
            floor++;
            floor2 = 0;
        }
        return new double[]{(double) (signum * floor), (double) floor2, rint};
    }

    @Override // java.lang.Object
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return obj != null && getClass() == obj.getClass() && ((Angle) obj).degrees == this.degrees;
    }

    @Override // java.lang.Object
    public int hashCode() {
        double d = this.degrees;
        long doubleToLongBits = d != 0.0d ? Double.doubleToLongBits(d) : 0;
        return (int) (doubleToLongBits ^ (doubleToLongBits >>> 32));
    }
}
