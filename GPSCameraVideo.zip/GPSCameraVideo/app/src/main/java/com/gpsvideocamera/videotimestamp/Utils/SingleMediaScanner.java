package com.gpsvideocamera.videotimestamp.Utils;

import android.content.Context;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import java.net.URLConnection;


public class SingleMediaScanner implements MediaScannerConnection.MediaScannerConnectionClient {
    private Context context;
    private String mFilePath;
    private MediaScannerConnection mMs;

    public SingleMediaScanner(Context context, String str) {
        this.context = context;
        this.mFilePath = str;
        MediaScannerConnection mediaScannerConnection = new MediaScannerConnection(context, this);
        this.mMs = mediaScannerConnection;
        mediaScannerConnection.connect();
    }

    @Override 
    public void onMediaScannerConnected() {
        this.mMs.scanFile(this.mFilePath, null);
    }

    @Override 
    public void onScanCompleted(String str, Uri uri) {
        Intent intent = new Intent("android.intent.action.VIEW");
        if (!Build.BRAND.equalsIgnoreCase("xiaomi")) {
            intent.setData(uri);
        } else if (!isImageFile(str)) {
            intent.setDataAndType(Uri.parse(str), "video/*");
        } else {
            intent.setData(uri);
        }
        this.context.startActivity(intent);
        this.mMs.disconnect();
    }

    public static boolean isImageFile(String str) {
        String guessContentTypeFromName = URLConnection.guessContentTypeFromName(str);
        return guessContentTypeFromName != null && guessContentTypeFromName.startsWith("image");
    }
}
