package com.gpsvideocamera.videotimestamp.Mgrs;


import java.util.ArrayList;
import java.util.List;


public class Position extends LatLon {
    public static final Position ZERO = new Position(Angle.ZERO, Angle.ZERO, 0.0d);
    public final double elevation;

    
    public static class PositionList {
        public List<? extends Position> list;

        public PositionList(List<? extends Position> list) {
            this.list = list;
        }
    }

    public static Position fromRadians(double d, double d2, double d3) {
        return new Position(Angle.fromRadians(d), Angle.fromRadians(d2), d3);
    }

    public static Position fromDegrees(double d, double d2, double d3) {
        return new Position(Angle.fromDegrees(d), Angle.fromDegrees(d2), d3);
    }

    public static Position fromDegrees(double d, double d2) {
        return new Position(Angle.fromDegrees(d), Angle.fromDegrees(d2), 0.0d);
    }

    public Position(Angle angle, Angle angle2, double d) {
        super(angle, angle2);
        this.elevation = d;
    }

    public Position(LatLon latLon, double d) {
        super(latLon);
        this.elevation = d;
    }

    public double getElevation() {
        return this.elevation;
    }

    public double getAltitude() {
        return this.elevation;
    }

    @Override 
    public Position add(Position position) {
        return new Position(Angle.normalizedLatitude(this.latitude.add(position.latitude)), Angle.normalizedLongitude(this.longitude.add(position.longitude)), this.elevation + position.elevation);
    }

    @Override 
    public Position subtract(Position position) {
        return new Position(Angle.normalizedLatitude(this.latitude.subtract(position.latitude)), Angle.normalizedLongitude(this.longitude.subtract(position.longitude)), this.elevation - position.elevation);
    }

    public static Position interpolate(double d, Position position, Position position2) {
        if (position == null || position2 == null) {
            throw new IllegalArgumentException("Position Is Null");
        } else if (d < 0.0d) {
            return position;
        } else {
            if (d > 1.0d) {
                return position2;
            }
            return new Position(LatLon.interpolate(d, position, position2), WWMath.mix(d, position.getElevation(), position2.getElevation()));
        }
    }

    public static Position interpolateGreatCircle(double d, Position position, Position position2) {
        if (position != null && position2 != null) {
            return new Position(LatLon.interpolateGreatCircle(d, position, position2), WWMath.mix(d, position.getElevation(), position2.getElevation()));
        }
        throw new IllegalArgumentException("Position Is Null");
    }

    public static Position interpolateRhumb(double d, Position position, Position position2) {
        if (position != null && position2 != null) {
            return new Position(LatLon.interpolateRhumb(d, position, position2), WWMath.mix(d, position.getElevation(), position2.getElevation()));
        }
        throw new IllegalArgumentException("Position Is Null");
    }

    public static boolean positionsCrossDateLine(Iterable<? extends Position> iterable) {
        if (iterable != null) {
            Position position = null;
            for (Position position2 : iterable) {
                if (!(position == null || Math.signum(position.getLongitude().degrees) == Math.signum(position2.getLongitude().degrees))) {
                    double abs = Math.abs(position.getLongitude().degrees - position2.getLongitude().degrees);
                    if (abs > 180.0d && abs < 360.0d) {
                        return true;
                    }
                }
                position = position2;
            }
            return false;
        }
        throw new IllegalArgumentException("Positions List Is Null");
    }

    public static List<Position> computeShiftedPositions(Position position, Position position2, Iterable<? extends Position> iterable) {
        if (position == null || position2 == null) {
            throw new IllegalArgumentException("Position Is Null");
        } else if (iterable != null) {
            ArrayList arrayList = new ArrayList();
            double elevation = position2.getElevation() - position.getElevation();
            for (Position position3 : iterable) {
                arrayList.add(new Position(LatLon.greatCircleEndPosition(position2, LatLon.greatCircleAzimuth(position, position3), LatLon.greatCircleDistance(position, position3)), position3.getElevation() + elevation));
            }
            return arrayList;
        } else {
            throw new IllegalArgumentException("Positions List Is Null");
        }
    }

    @Override 
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return obj != null && getClass() == obj.getClass() && super.equals(obj) && Double.compare(((Position) obj).elevation, this.elevation) == 0;
    }

    @Override 
    public int hashCode() {
        int hashCode = super.hashCode();
        double d = this.elevation;
        long doubleToLongBits = d != 0.0d ? Double.doubleToLongBits(d) : 0;
        return (hashCode * 31) + ((int) (doubleToLongBits ^ (doubleToLongBits >>> 32)));
    }

    @Override 
    public String toString() {
        return "(" + this.latitude.toString() + ", " + this.longitude.toString() + ", " + this.elevation + ")";
    }
}
