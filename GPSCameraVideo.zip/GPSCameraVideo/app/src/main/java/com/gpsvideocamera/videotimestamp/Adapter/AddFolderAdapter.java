package com.gpsvideocamera.videotimestamp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.gpsvideocamera.videotimestamp.Interface.OnRecyclerItemClickListener;
import com.gpsvideocamera.videotimestamp.Model.FileGetSet;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.Default;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import java.util.ArrayList;
import java.util.List;


public class AddFolderAdapter extends RecyclerView.Adapter<AddFolderAdapter.Holder> {
    Context mContext;
    List<FileGetSet> mList;
    OnRecyclerItemClickListener mOnRecyclerItemClickListener;
    SP mSP;
    private String mSelectedVale;
    int selected_pos;

    public AddFolderAdapter(Context context, List<FileGetSet> list, OnRecyclerItemClickListener onRecyclerItemClickListener) {
        this.mContext = context;
        this.mList = list;
        this.mOnRecyclerItemClickListener = onRecyclerItemClickListener;
        SP sp = new SP(this.mContext);
        this.mSP = sp;
        this.mSelectedVale = sp.getString(this.mContext, SP.FOLDER_NAME, Default.DEFAULT_FOLDER_PATH);
    }

    @Override 
    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_add_folder, viewGroup, false));
    }

    public void refAdapter(List<FileGetSet> list, String str) {
        this.mList = new ArrayList(list);
        this.mSelectedVale = str;
        notifyDataSetChanged();
    }

    public void refAdapter(String str) {
        this.mList = new ArrayList(this.mList);
        this.mSelectedVale = str;
        notifyDataSetChanged();
    }

    public void onBindViewHolder(Holder holder, int i) {
        holder.tv_folderName.setText(this.mList.get(i).getFileName());
        if (this.mSelectedVale.equals(this.mList.get(i).getFilePath())) {
            holder.img_selection.setImageResource(R.drawable.ic_radiobtn);
        } else {
            holder.img_selection.setImageResource(R.drawable.ic_uncheck);
        }
    }

    @Override 
    public int getItemCount() {
        return this.mList.size();
    }

    
    public class Holder extends RecyclerView.ViewHolder {
        LinearLayout folder_main_lay;
        ImageView img_selection;
        TextView tv_folderName;

        public Holder(View view) {
            super(view);
            this.tv_folderName = (TextView) view.findViewById(R.id.tv_folderName);
            this.folder_main_lay = (LinearLayout) view.findViewById(R.id.folder_main_lay);
            this.img_selection = (ImageView) view.findViewById(R.id.img_selection);
            this.folder_main_lay.setOnClickListener(new View.OnClickListener() {
                @Override 
                public void onClick(View view2) {
                    if (Holder.this.getAdapterPosition() >= 0 && AddFolderAdapter.this.mOnRecyclerItemClickListener != null) {
                        AddFolderAdapter.this.mOnRecyclerItemClickListener.OnClick_(Holder.this.getAdapterPosition(), view2);
                    }
                }
            });
            this.folder_main_lay.setOnLongClickListener(new View.OnLongClickListener() {
                @Override 
                public boolean onLongClick(View view2) {
                    if (Holder.this.getAdapterPosition() < 0 || AddFolderAdapter.this.mOnRecyclerItemClickListener == null) {
                        return true;
                    }
                    AddFolderAdapter.this.mOnRecyclerItemClickListener.OnLongClick_(Holder.this.getAdapterPosition(), view2);
                    return true;
                }
            });
        }
    }
}
