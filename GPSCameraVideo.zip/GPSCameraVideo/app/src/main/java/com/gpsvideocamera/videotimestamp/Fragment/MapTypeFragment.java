package com.gpsvideocamera.videotimestamp.Fragment;

import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.gpsvideocamera.videotimestamp.Adapter.MapAdapter;
import com.gpsvideocamera.videotimestamp.Interface.OnRecyclerItemClickListener;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.Default;
import com.gpsvideocamera.videotimestamp.Utils.SP;


public class MapTypeFragment extends Fragment {
    OnMapTypeSelectedListener callBack;
    private MapAdapter mAdapter;
    TypedArray mIconArray;
    String[] mMapArray;
    private RecyclerView mRecyclerview;
    private SP mSP;

    
    interface OnMapTypeSelectedListener {
        void onMapTypeSelected();
    }

    public void setOnMap_SelectedListener(OnMapTypeSelectedListener onMapTypeSelectedListener) {
        this.callBack = onMapTypeSelectedListener;
    }

    @Override 
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_template, viewGroup, false);
    }

    @Override 
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        init(view);
    }

    private void init(View view) {
        this.mSP = new SP(getContext());
        this.mRecyclerview = (RecyclerView) view.findViewById(R.id.fragment_recyclerview);
        this.mMapArray = getResources().getStringArray(R.array.map_title_array);
        this.mIconArray = getResources().obtainTypedArray(R.array.map_icon_array);
        setAdapter();
    }

    private void setAdapter() {
        this.mRecyclerview.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        MapAdapter mapAdapter = new MapAdapter(getContext(), this.mMapArray, this.mIconArray, new OnRecyclerItemClickListener() { 
            @Override 
            public void OnLongClick_(int i, View view) {
            }

            @Override 
            public void OnClick_(final int i, View view) {
                MapTypeFragment.this.mSP.setInteger(MapTypeFragment.this.getContext(), "map_type_temp_pos", Integer.valueOf(i));
                if (i == 0) {
                    MapTypeFragment.this.mSP.setString(MapTypeFragment.this.getContext(), "map_type_temp", Default.NORMAL_1);
                } else if (i == 1) {
                    MapTypeFragment.this.mSP.setString(MapTypeFragment.this.getContext(), "map_type_temp", Default.SETELLITE_2);
                } else if (i == 2) {
                    MapTypeFragment.this.mSP.setString(MapTypeFragment.this.getContext(), "map_type_temp", Default.TERRAIN_3);
                } else if (i == 3) {
                    MapTypeFragment.this.mSP.setString(MapTypeFragment.this.getContext(), "map_type_temp", Default.HYBRID_4);
                }
                new Handler().postDelayed(new Runnable() { 
                    @Override 
                    public void run() {
                        MapTypeFragment.this.mAdapter.refAdapter(i);
                        if (MapTypeFragment.this.callBack != null) {
                            MapTypeFragment.this.callBack.onMapTypeSelected();
                        }
                    }
                }, 50);
            }
        });
        this.mAdapter = mapAdapter;
        this.mRecyclerview.setAdapter(mapAdapter);
    }
}
