package com.gpsvideocamera.videotimestamp.Activity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.SkuDetails;
import com.google.android.material.button.MaterialButton;
import com.gpsvideocamera.videotimestamp.LocalNotification.AlarmReceiver;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.HelperClass;
import com.gpsvideocamera.videotimestamp.Utils.PurchaseHelper;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import com.gpsvideocamera.videotimestamp.Utils.SearchHelper;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;


public class InAppPurchaseActivity extends AppCompatActivity implements View.OnClickListener {
    LinearLayout CV_color;
    LinearLayout CV_file;
    LinearLayout CV_floder;
    LinearLayout Cv_ads;
    LinearLayout btn_back;
    private MaterialButton btn_purchase;
    ImageView img_ads;
    ImageView img_color;
    ImageView img_file;
    ImageView img_folder;
    boolean isPurchaseQueryPending;
    private HelperClass mHelperClass;
    SP mSP;
    List<Purchase> purchaseHistory;
    PurchaseHelper purchaseInAppHelper;
    Timer timer;
    TextView tv_desic;
    TextView tv_price;
    TextView tv_title;
    final long DELAY_MS = 500;
    final long PERIOD_MS = 3000;
    int selcte = 1;
    private long mLastClickTime = 0;

    
    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        HelperClass helperClass = new HelperClass();
        this.mHelperClass = helperClass;
        helperClass.SetLanguage(this);
        setContentView(R.layout.activity_in_app_purchase);
        init();
        Clickhandler();
    }

    private void Clickhandler() {
        this.btn_back.setOnClickListener(this);
        this.Cv_ads.setOnClickListener(this);
        this.CV_file.setOnClickListener(this);
        this.CV_floder.setOnClickListener(this);
        this.CV_color.setOnClickListener(this);
    }

    private void init() {
        this.btn_back = (LinearLayout) findViewById(R.id.btn_back);
        this.btn_purchase = (MaterialButton) findViewById(R.id.btn_purchase);
        this.tv_price = (TextView) findViewById(R.id.tv_price);
        this.tv_title = (TextView) findViewById(R.id.tv_title);
        this.tv_desic = (TextView) findViewById(R.id.tv_desc);
        this.Cv_ads = (LinearLayout) findViewById(R.id.CV_ads);
        this.CV_color = (LinearLayout) findViewById(R.id.CV_color);
        this.CV_file = (LinearLayout) findViewById(R.id.CV_file);
        this.CV_floder = (LinearLayout) findViewById(R.id.CV_floder);
        this.img_ads = (ImageView) findViewById(R.id.img_ads);
        this.img_folder = (ImageView) findViewById(R.id.img_folder);
        this.img_file = (ImageView) findViewById(R.id.img_file);
        this.img_color = (ImageView) findViewById(R.id.img_color);
        this.mSP = new SP(this);
        checkInApp();
        setpurchase(1);
    }

    @Override 
    protected void onResume() {
        super.onResume();
        final Handler handler = new Handler();
        final Runnable r1 = new Runnable() {
            @Override // java.lang.Runnable
            public void run() {
                if (InAppPurchaseActivity.this.selcte == 5) {
                    InAppPurchaseActivity.this.selcte = 1;
                }
                InAppPurchaseActivity inAppPurchaseActivity = InAppPurchaseActivity.this;
                int i = inAppPurchaseActivity.selcte;
                inAppPurchaseActivity.selcte = i + 1;
                inAppPurchaseActivity.setpurchase(i);
            }
        };
        Timer timer = new Timer();
        this.timer = timer;
        timer.schedule(new TimerTask() { // from class: com.gpsvideocamera.videotimestamp.Activity.InAppPurchaseActivity.2
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                handler.post(r1);
            }
        }, 500, 3000);
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onPause() {
        super.onPause();
        this.timer.cancel();
    }

    private void checkInApp() {
        if (HelperClass.check_internet(this)) {
            this.purchaseInAppHelper = new PurchaseHelper(this, getInAppHelperListener());
            loadData();
        }
    }

    public PurchaseHelper.PurchaseHelperListener getInAppHelperListener() {
        return new PurchaseHelper.PurchaseHelperListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.InAppPurchaseActivity.3
            @Override // com.gpsvideocamera.videotimestamp.Utils.PurchaseHelper.PurchaseHelperListener
            public void onServiceConnected(int i) {
                if (InAppPurchaseActivity.this.isPurchaseQueryPending) {
                    InAppPurchaseActivity.this.purchaseInAppHelper.getPurchasedItems(BillingClient.SkuType.INAPP);
                    InAppPurchaseActivity.this.isPurchaseQueryPending = false;
                }
            }

            @Override // com.gpsvideocamera.videotimestamp.Utils.PurchaseHelper.PurchaseHelperListener
            public void onSkuQueryResponse(List<SkuDetails> list) {
                if (!(list == null || list.isEmpty())) {
                    for (final SkuDetails skuDetails : list) {
                        if (skuDetails.getSku().equals(getApplicationContext()+".fullpurchase")) {
                            InAppPurchaseActivity.this.tv_price.setText(skuDetails.getPrice());
                            InAppPurchaseActivity.this.btn_purchase.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.InAppPurchaseActivity.3.1
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    if (SystemClock.elapsedRealtime() - InAppPurchaseActivity.this.mLastClickTime >= 1000) {
                                        InAppPurchaseActivity.this.mLastClickTime = SystemClock.elapsedRealtime();
                                        if (InAppPurchaseActivity.this.purchaseInAppHelper != null) {
                                            InAppPurchaseActivity.this.purchaseInAppHelper.launchBillingFLow(skuDetails);
                                        }
                                    
                                        if (!InAppPurchaseActivity.this.mSP.getBoolean(InAppPurchaseActivity.this, HelperClass.PURCHASE_3_TIME_SHOWN, false).booleanValue()) {
                                            int intValue = InAppPurchaseActivity.this.mSP.getInteger(InAppPurchaseActivity.this, HelperClass.PURCHASE_3_TIME_CLICK, 0).intValue() + 1;
                                            if (intValue == 3) {
                                                AlarmReceiver alarmReceiver = new AlarmReceiver();
                                                Calendar instance = Calendar.getInstance();
                                                instance.set(11, 21);
                                                instance.set(12, 0);
                                                instance.set(13, 0);
                                                instance.set(14, 0);
                                                alarmReceiver.setAlarm(InAppPurchaseActivity.this, instance.getTimeInMillis(), 65);
                                                InAppPurchaseActivity.this.mSP.setBoolean(InAppPurchaseActivity.this, HelperClass.PURCHASE_3_TIME_SHOWN, true);
                                                return;
                                            }
                                            InAppPurchaseActivity.this.mSP.setInteger(InAppPurchaseActivity.this, HelperClass.PURCHASE_3_TIME_CLICK, Integer.valueOf(intValue));
                                        }
                                    }
                                }
                            });
                        }
                    }
                }
            }

            @Override // com.gpsvideocamera.videotimestamp.Utils.PurchaseHelper.PurchaseHelperListener
            public void onPurchasehistoryResponse(List<Purchase> list) {
                InAppPurchaseActivity.this.purchaseHistory = list;
                HelperClass.purchaseHistory = list;
                if (InAppPurchaseActivity.this.purchaseHistory != null) {
                    ArrayList<String> arrayList = new ArrayList();
                    arrayList.add(getApplicationContext()+".fullpurchase");
                    ArrayList<String> arrayList2 = new ArrayList(arrayList);
                    List<String> purchasedProductIdListing = SearchHelper.getPurchasedProductIdListing(InAppPurchaseActivity.this.purchaseHistory);
                    arrayList2.retainAll(purchasedProductIdListing);
                    for (String str : arrayList2) {
                        if (str.equals(getApplicationContext()+".fullpurchase")) {
                            new SP(InAppPurchaseActivity.this).setBoolean(InAppPurchaseActivity.this, HelperClass.IS_PURCHESH_OR_NOT, true);
                        }
                    }
                    arrayList.removeAll(purchasedProductIdListing);
                    for (String str2 : arrayList) {
                        if (str2.equals(getApplicationContext()+".fullpurchase")) {
                            new SP(InAppPurchaseActivity.this).setBoolean(InAppPurchaseActivity.this, HelperClass.IS_PURCHESH_OR_NOT, false);
                        }
                    }
                    if (arrayList.size() > 0) {
                        InAppPurchaseActivity.this.purchaseInAppHelper.getSkuDetails(arrayList, BillingClient.SkuType.INAPP);
                    }
                }
            }

            @Override // com.gpsvideocamera.videotimestamp.Utils.PurchaseHelper.PurchaseHelperListener
            public void onPurchasesUpdated(BillingResult billingResult, List<Purchase> list) {
                if (billingResult.getResponseCode() == 0 && list != null) {
                    for (Purchase purchase : list) {
                        if (purchase.getSkus().get(0).equals(getApplicationContext()+".fullpurchase")) {
                            new SP(InAppPurchaseActivity.this).setBoolean(InAppPurchaseActivity.this, HelperClass.IS_PURCHESH_OR_NOT, true);
                            InAppPurchaseActivity.this.createRestartDialog();
                        }
                    }
                }
            }
        };
    }

    private void loadData() {
        PurchaseHelper purchaseHelper = this.purchaseInAppHelper;
        if (purchaseHelper == null || !purchaseHelper.isServiceConnected()) {
            this.isPurchaseQueryPending = true;
        } else {
            this.purchaseInAppHelper.getPurchasedItems(BillingClient.SkuType.INAPP);
        }
    }

    public void createRestartDialog() {
        try {
            if (!isFinishing()) {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(getResources().getString(R.string.congratulations));
                builder.setMessage(getResources().getString(R.string.restart_msg));
                builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.InAppPurchaseActivity.4
                    @SuppressLint("WrongConstant")
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(InAppPurchaseActivity.this, CameraActivity.class);
                        intent.setFlags(268468224);
                        InAppPurchaseActivity.this.startActivity(intent);
                    }
                });
                builder.setCancelable(false);
                builder.create().show();
            }
        } catch (Exception unused) {
        }
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        PurchaseHelper purchaseHelper = this.purchaseInAppHelper;
        if (purchaseHelper != null) {
            purchaseHelper.endConnection();
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        int id = view.getId();
        if (id != R.id.btn_back) {
            switch (id) {
                case R.id.CV_ads :
                    this.selcte = 4;
                    setpurchase(4);
                    return;
                case R.id.CV_color :
                    this.selcte = 2;
                    setpurchase(2);
                    return;
                case R.id.CV_file :
                    this.selcte = 3;
                    setpurchase(3);
                    return;
                case R.id.CV_floder :
                    this.selcte = 1;
                    setpurchase(1);
                    return;
                default:
                    return;
            }
        } else {
            finish();
        }
    }

    public void setpurchase(int i) {
        this.CV_floder.setBackgroundResource(R.drawable.unselect_pro_folder);
        this.CV_file.setBackgroundResource(R.drawable.unselect_pro_file);
        this.Cv_ads.setBackgroundResource(R.drawable.unselect_pro_ads);
        this.CV_color.setBackgroundResource(R.drawable.unselect_pro_color);
        this.img_color.setVisibility(View.GONE);
        this.img_ads.setVisibility(View.GONE);
        this.img_file.setVisibility(View.GONE);
        this.img_folder.setVisibility(View.GONE);
        if (i == 1) {
            this.tv_title.setText(getResources().getString(R.string.add_folder));
            this.tv_title.setTextColor(getResources().getColor(R.color._ffb020));
            this.tv_desic.setText(getResources().getString(R.string.inApp_text_1));
            this.CV_floder.setBackgroundResource(R.drawable.selecte_pro_folder);
            this.img_folder.setVisibility(View.VISIBLE);
        } else if (i == 2) {
            this.tv_title.setText(getResources().getString(R.string.change_color));
            this.tv_title.setTextColor(getResources().getColor(R.color._1cb0f6));
            this.tv_desic.setText(getResources().getString(R.string.in_app_text_2));
            this.CV_color.setBackgroundResource(R.drawable.selecte_pro_color);
            this.img_color.setVisibility(View.VISIBLE);
        } else if (i == 3) {
            this.tv_title.setText(getResources().getString(R.string.change_filename));
            this.tv_title.setTextColor(getResources().getColor(R.color._7ac70c));
            this.tv_desic.setText(getResources().getString(R.string.inApp_text_4));
            this.CV_file.setBackgroundResource(R.drawable.selecte_pro_file);
            this.img_file.setVisibility(View.VISIBLE);
        } else if (i == 4) {
            this.tv_title.setText(getResources().getString(R.string.remove_ads));
            this.tv_title.setTextColor(getResources().getColor(R.color._e53b3b));
            this.tv_desic.setText(getResources().getString(R.string.inApp_text_3));
            this.Cv_ads.setBackgroundResource(R.drawable.select_pro_ads);
            this.img_ads.setVisibility(View.VISIBLE);
        }
    }
}
