package com.gpsvideocamera.videotimestamp.LocalNotification;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.PowerManager;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import com.gpsvideocamera.videotimestamp.Activity.SplashActivity;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.HelperClass;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import java.util.Calendar;


public class AlarmReceiver extends BroadcastReceiver {
    public static final int ALARM_REQUEST_CODE_100PHOTOS = 55;
    public static final int ALARM_REQUEST_CODE_10TIMES_OPEN = 52;
    public static final int ALARM_REQUEST_CODE_15DAYS = 51;
    public static final int ALARM_REQUEST_CODE_2ND_DAY = 57;
    public static final int ALARM_REQUEST_CODE_3_TIME_NO_BUY = 65;
    public static final int ALARM_REQUEST_CODE_3_TIME_NO_BUY_STAN = 66;
    public static final int ALARM_REQUEST_CODE_45PHOTOS = 53;
    public static final int ALARM_REQUEST_CODE_500PHOTOS = 56;
    public static final int ALARM_REQUEST_CODE_50PHOTOS_PRO = 54;
    public static final int ALARM_REQUEST_CODE_CAMSET_OPEN_TIME = 59;
    public static final int ALARM_REQUEST_CODE_FILE_OPEN_TIME = 61;
    public static final int ALARM_REQUEST_CODE_FOLD_OPEN_TIME = 60;
    public static final int ALARM_REQUEST_CODE_FONT_OPEN_TIME = 63;
    public static final int ALARM_REQUEST_CODE_MAP_OPEN_TIME = 58;
    public static final int ALARM_REQUEST_CODE_STAMPPOS_OPEN_TIME = 64;
    public static final int ALARM_REQUEST_CODE_TEMP_OPEN_TIME = 62;
    public static final int NID_100PHOTOS = 5;
    public static final int NID_10TIMES_OPEN = 2;
    public static final int NID_15DAYS = 1;
    public static final int NID_2ND_DAY = 7;
    public static final int NID_3_TIME_NO_BUY = 15;
    public static final int NID_3_TIME_NO_BUY_STAN = 16;
    public static final int NID_45PHOTOS = 3;
    public static final int NID_500PHOTOS = 6;
    public static final int NID_50PHOTOS_PRO = 4;
    public static final int NID_CAMSET_OPEN_TIME = 9;
    public static final int NID_FILE_OPEN_TIME = 11;
    public static final int NID_FOLD_OPEN_TIME = 10;
    public static final int NID_FONT_OPEN_TIME = 13;
    public static final int NID_MAP_OPEN_TIME = 8;
    public static final int NID_STAMPPOS_OPEN_TIME = 14;
    public static final int NID_TEMP_OPEN_TIME = 12;
    public static final String SCREEN_FOLDER = "screen_folder";
    public static final String SCREEN_IN_APP = "screen_in_app";
    public static final String SCREEN_LOCATION = "screen_location";
    public static final String SCREEN_SPLASH = "screen_splash";
    NotificationManagerCompat notificationManager;

    @SuppressLint("MissingPermission")
    @Override
    public void onReceive(Context context, Intent intent) {
        PowerManager.WakeLock newWakeLock = ((PowerManager) context.getSystemService(Context.POWER_SERVICE)).newWakeLock(1, ":AlarmService");
        newWakeLock.acquire(600000);
        context.getPackageManager().setComponentEnabledSetting(new ComponentName(context, SplashActivity.class), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
        this.notificationManager = NotificationManagerCompat.from(context);
        boolean booleanValue = new SP(context).getBoolean(context, "app_running", false).booleanValue();
        int intExtra = intent.getIntExtra("alarmId", 0);
        SP sp = new SP(context);
        if (!AlarmTimingUtils.isWithin15Days(context) && intExtra == 51) {
            if (!booleanValue) {
                cancelAlarm(context, intExtra);
                this.notificationManager.notify(1, BuildNotificationUtils.buildNotification(context, 51));

            }
            setNextNotification(context, intent);
        }
        if (intExtra == 52) {
            if (!booleanValue) {
                this.notificationManager.notify(2, BuildNotificationUtils.buildNotification(context, 52));

            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 53) {
            if (!booleanValue) {
                this.notificationManager.notify(3, BuildNotificationUtils.buildNotification(context, 53));

            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 54) {
            if (booleanValue || sp.getBoolean(context, HelperClass.IS_PURCHESH_OR_NOT).booleanValue()) {
                setNextNotification(context, intent);
            } else {
                this.notificationManager.notify(4, BuildNotificationUtils.buildNotification(context, 54));
            
            }
        }
        if (intExtra == 55) {
            if (!booleanValue) {
                this.notificationManager.notify(5, BuildNotificationUtils.buildNotification(context, 55));
            
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 56) {
            if (!booleanValue) {
                this.notificationManager.notify(6, BuildNotificationUtils.buildNotification(context, 56));
            
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 57) {
            if (!booleanValue) {
                this.notificationManager.notify(7, BuildNotificationUtils.buildNotification(context, 57));

            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 58) {
            if (!booleanValue) {
                this.notificationManager.notify(8, BuildNotificationUtils.buildNotification(context, 58));
            
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 59) {
            if (!booleanValue) {
                this.notificationManager.notify(9, BuildNotificationUtils.buildNotification(context, 59));
            
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 60) {
            if (!booleanValue) {
                this.notificationManager.notify(10, BuildNotificationUtils.buildNotification(context, 60));
            
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 61) {
            if (!booleanValue) {
                this.notificationManager.notify(11, BuildNotificationUtils.buildNotification(context, 61));
            
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 62) {
            if (!booleanValue) {
                this.notificationManager.notify(12, BuildNotificationUtils.buildNotification(context, 62));
            
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 63) {
            if (!booleanValue) {
                this.notificationManager.notify(13, BuildNotificationUtils.buildNotification(context, 63));
            
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 64) {
            if (!booleanValue) {
                this.notificationManager.notify(14, BuildNotificationUtils.buildNotification(context, 64));
            
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 65) {
            if (!booleanValue) {
                this.notificationManager.notify(15, BuildNotificationUtils.buildNotification(context, 65));
            
            } else {
                setNextNotification(context, intent);
            }
        }
        if (intExtra == 66) {
            if (!booleanValue) {
                this.notificationManager.notify(16, BuildNotificationUtils.buildNotification(context, 66));
            
            } else {
                setNextNotification(context, intent);
            }
        }
        newWakeLock.release();
    }

    private void setNextNotification(Context context, Intent intent) {
        int intExtra = intent.getIntExtra("alarmId", 0);
        Calendar instance = Calendar.getInstance();
        if (intExtra == 51) {
            instance.set(11, 21);
            instance.set(12, 0);
            instance.set(13, 0);
            instance.set(14, 0);
            instance.add(5, 15);
        } else {
            instance.set(11, 21);
            instance.set(12, 0);
            instance.set(13, 0);
            instance.set(14, 0);
            instance.add(5, 1);
        }
        setAlarm(context, instance.getTimeInMillis(), intExtra);
    }

    public void setAlarm(Context context, long j, int i) {
        Calendar instance = Calendar.getInstance();
        instance.setTimeInMillis(j);
        instance.set(11, 21);
        instance.set(12, 0);
        instance.set(13, 0);
        instance.set(14, 0);
        SP sp = new SP(context);
        if (i == 51) {
            sp.setLong(context, SP.ALARM_TIME_15_DAYS, j);
        } else if (i == 52) {
            sp.setLong(context, SP.ALARM_TIME_10_TIMES_OPEN, instance.getTimeInMillis());
        } else if (i == 53) {
            sp.setLong(context, SP.ALARM_TIME_45_PHOTOS, instance.getTimeInMillis());
        } else if (i == 54) {
            sp.setLong(context, SP.ALARM_TIME_50_PHOTOS_PRO, instance.getTimeInMillis());
        } else if (i == 55) {
            sp.setLong(context, SP.ALARM_TIME_100_PHOTOS, instance.getTimeInMillis());
        } else if (i == 56) {
            sp.setLong(context, SP.ALARM_TIME_500_PHOTOS, instance.getTimeInMillis());
        } else if (i == 57) {
            sp.setLong(context, SP.ALARM_TIME_2ND_DAY, j);
        } else if (i == 58) {
            sp.setLong(context, SP.ALARM_TIME_MAP_OPEN_TIME, instance.getTimeInMillis());
        } else if (i == 59) {
            sp.setLong(context, SP.ALARM_TIME_CAMSET_OPEN_TIME, instance.getTimeInMillis());
        } else if (i == 60) {
            sp.setLong(context, SP.ALARM_TIME_FOLD_OPEN_TIME, instance.getTimeInMillis());
        } else if (i == 61) {
            sp.setLong(context, SP.ALARM_TIME_FILE_OPEN_TIME, instance.getTimeInMillis());
        } else if (i == 62) {
            sp.setLong(context, SP.ALARM_TIME_TEMP_OPEN_TIME, instance.getTimeInMillis());
        } else if (i == 63) {
            sp.setLong(context, SP.ALARM_TIME_FONT_OPEN_TIME, instance.getTimeInMillis());
        } else if (i == 64) {
            sp.setLong(context, SP.ALARM_TIME_STAMPPOS_OPEN_TIME, instance.getTimeInMillis());
        } else if (i == 65) {
            sp.setLong(context, SP.ALARM_TIME_3_TIME_NO_BUY, instance.getTimeInMillis());
        } else if (i == 66) {
            sp.setLong(context, SP.ALARM_TIME_3_TIME_NO_BUY_STAN, instance.getTimeInMillis());
        }
        try {
            setExactIdleAlarm(context, i);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setExactIdleAlarm(Context context, int i) {
        AlarmManager.AlarmClockInfo alarmClockInfo;
        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("alarmId", i);
        PendingIntent broadcast = PendingIntent.getBroadcast(context, i, intent, PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        switch (i) {
            case 51:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_15_DAYS, System.currentTimeMillis()), broadcast);
                break;
            case 52:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_10_TIMES_OPEN, System.currentTimeMillis()), broadcast);
                break;
            case 53:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_45_PHOTOS, System.currentTimeMillis()), broadcast);
                break;
            case 54:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_50_PHOTOS_PRO, System.currentTimeMillis()), broadcast);
                break;
            case 55:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_100_PHOTOS, System.currentTimeMillis()), broadcast);
                break;
            case 56:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_500_PHOTOS, System.currentTimeMillis()), broadcast);
                break;
            case 57:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_2ND_DAY, System.currentTimeMillis()), broadcast);
                break;
            case 58:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_MAP_OPEN_TIME, System.currentTimeMillis()), broadcast);
                break;
            case 59:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_CAMSET_OPEN_TIME, System.currentTimeMillis()), broadcast);
                break;
            case 60:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_FOLD_OPEN_TIME, System.currentTimeMillis()), broadcast);
                break;
            case 61:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_FILE_OPEN_TIME, System.currentTimeMillis()), broadcast);
                break;
            case 62:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_TEMP_OPEN_TIME, System.currentTimeMillis()), broadcast);
                break;
            case 63:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_FONT_OPEN_TIME, System.currentTimeMillis()), broadcast);
                break;
            case 64:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_STAMPPOS_OPEN_TIME, System.currentTimeMillis()), broadcast);
                break;
            case 65:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_3_TIME_NO_BUY, System.currentTimeMillis()), broadcast);
                break;
            case 66:
                alarmClockInfo = new AlarmManager.AlarmClockInfo(new SP(context).getLong(context, SP.ALARM_TIME_3_TIME_NO_BUY_STAN, System.currentTimeMillis()), broadcast);
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + i);
        }
        alarmManager.setAlarmClock(alarmClockInfo, broadcast);
    }

    public void cancelAlarm(Context context, int i) {
        ((AlarmManager) context.getSystemService(Context.ALARM_SERVICE)).cancel(PendingIntent.getBroadcast(context, i, new Intent(context, AlarmReceiver.class), PendingIntent.FLAG_IMMUTABLE));
    }
}
