package com.gpsvideocamera.videotimestamp.Utils;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import com.android.billingclient.BuildConfig;
import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.AcknowledgePurchaseResponseListener;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.SkuDetails;
import com.android.billingclient.api.SkuDetailsParams;
import com.android.billingclient.api.SkuDetailsResponseListener;
import java.util.List;


public class PurchaseHelper {
    private int billingSetupResponseCode;
    private Context context;
    private BillingClient mBillingClient;
    private boolean mIsServiceConnected;
    private PurchaseHelperListener purchaseHelperListener;

    
    public interface PurchaseHelperListener {
        void onPurchasehistoryResponse(List<Purchase> list);

        void onPurchasesUpdated(BillingResult billingResult, List<Purchase> list);

        void onServiceConnected(int i);

        void onSkuQueryResponse(List<SkuDetails> list);
    }

    public PurchaseHelper(Context context, PurchaseHelperListener purchaseHelperListener) {
        this.context = context;
        this.mBillingClient = BillingClient.newBuilder(context).enablePendingPurchases().setListener(getPurchaseUpdatedListener()).build();
        this.purchaseHelperListener = purchaseHelperListener;
        startConnection(getServiceConnectionRequest());
    }

    private void startConnection(final Runnable runnable) {
        this.mBillingClient.startConnection(new BillingClientStateListener() {
            @Override 
            public void onBillingSetupFinished(BillingResult billingResult) {
                if (billingResult.getResponseCode() == 0) {
                    PurchaseHelper.this.mIsServiceConnected = true;
                    PurchaseHelper.this.billingSetupResponseCode = billingResult.getResponseCode();
                    Runnable runnable2 = runnable;
                    if (runnable2 != null) {
                        runnable2.run();
                    }
                }
            }

            @Override 
            public void onBillingServiceDisconnected() {
                PurchaseHelper.this.mIsServiceConnected = false;
            }
        });
    }

    public boolean isServiceConnected() {
        return this.mIsServiceConnected;
    }

    public void endConnection() {
        BillingClient billingClient = this.mBillingClient;
        if (billingClient != null && billingClient.isReady()) {
            this.mBillingClient.endConnection();
            this.mBillingClient = null;
        }
    }

    private Runnable getServiceConnectionRequest() {
        return new Runnable() { 
            @Override 
            public void run() {
                if (PurchaseHelper.this.purchaseHelperListener != null) {
                    PurchaseHelper.this.purchaseHelperListener.onServiceConnected(PurchaseHelper.this.billingSetupResponseCode);
                }
            }
        };
    }

    public void getPurchasedItems(final String str) {
        executeServiceRequest(new Runnable() { 
            @Override 
            public void run() {
                Purchase.PurchasesResult queryPurchases = PurchaseHelper.this.mBillingClient.queryPurchases(str);
                if (PurchaseHelper.this.purchaseHelperListener != null) {
                    PurchaseHelper.this.purchaseHelperListener.onPurchasehistoryResponse(queryPurchases.getPurchasesList());
                }
            }
        });
    }

    public void getSkuDetails(final List<String> list, final String str) {
        executeServiceRequest(new Runnable() { 
            @Override 
            public void run() {
                PurchaseHelper.this.mBillingClient.querySkuDetailsAsync(SkuDetailsParams.newBuilder().setType(str).setSkusList(list).build(), new SkuDetailsResponseListener() {
                    @Override 
                    public void onSkuDetailsResponse(BillingResult billingResult, List<SkuDetails> list2) {
                        if (billingResult.getResponseCode() == 0 && list2 != null && PurchaseHelper.this.purchaseHelperListener != null) {
                            PurchaseHelper.this.purchaseHelperListener.onSkuQueryResponse(list2);
                        }
                    }
                });
            }
        });
    }

    public void launchBillingFLow(final SkuDetails skuDetails) {
        executeServiceRequest(new Runnable() { 
            @Override 
            public void run() {
                PurchaseHelper.this.mBillingClient.launchBillingFlow((Activity) PurchaseHelper.this.context, BillingFlowParams.newBuilder().setSkuDetails(skuDetails).build());
            }
        });
    }

    public void gotoManageSubscription() {
        String packageName = this.context.getPackageName();
        this.context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/account/subscriptions?package=" + packageName)));
    }

    private PurchasesUpdatedListener getPurchaseUpdatedListener() {
        return new PurchasesUpdatedListener() { // from class: com.gpsvideocamera.videotimestamp.Utils.PurchaseHelper.6
            @Override // com.android.billingclient.api.PurchasesUpdatedListener
            public void onPurchasesUpdated(BillingResult billingResult, List<Purchase> list) {
                if (billingResult.getResponseCode() != 0 || list == null || list.size() <= 0 || PurchaseHelper.this.purchaseHelperListener == null) {
                    billingResult.getResponseCode();
                    return;
                }
                PurchaseHelper.this.purchaseHelperListener.onPurchasesUpdated(billingResult, list);
                for (Purchase purchase : list) {
                    if (purchase.getSkus().get(0).equals(context.getPackageName()+".fullpurchase")) {
                        PurchaseHelper.this.handlePurchase(purchase);
                    }
                }
            }
        };
    }

    void handlePurchase(Purchase purchase) {
        if (purchase.getPurchaseState() != 1) {
            purchase.getPurchaseState();
        } else if (!purchase.isAcknowledged()) {
            this.mBillingClient.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build(), new AcknowledgePurchaseResponseListener() { // from class: com.gpsvideocamera.videotimestamp.Utils.PurchaseHelper.7
                @Override // com.android.billingclient.api.AcknowledgePurchaseResponseListener
                public void onAcknowledgePurchaseResponse(BillingResult billingResult) {
                }
            });
        }
    }

    private void executeServiceRequest(Runnable runnable) {
        if (this.mIsServiceConnected) {
            runnable.run();
        } else {
            startConnection(runnable);
        }
    }
}
