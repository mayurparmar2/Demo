package com.gpsvideocamera.videotimestamp.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.SP;


public class TempratureFragment extends Fragment implements View.OnClickListener {
    OntTempratureListener callBack;
    ImageView mImg_celsius;
    ImageView mImg_fahrenheit;
    LinearLayout mLi_celsius;
    LinearLayout mLi_fahrenheit;
    SP mSP;
    String mTemp_type;
    TextView mTv_celsius;
    TextView mTv_fahrenheit;

    
    
    public interface OntTempratureListener {
        void onTempratureType();
    }

    public void setOnTempratureListener(OntTempratureListener ontTempratureListener) {
        this.callBack = ontTempratureListener;
    }

    @Override 
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_temprature, viewGroup, false);
    }

    @Override 
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.mSP = new SP(getActivity());
        this.mLi_fahrenheit = (LinearLayout) view.findViewById(R.id.li_fahrenheit);
        this.mLi_celsius = (LinearLayout) view.findViewById(R.id.li_celsius);
        this.mImg_celsius = (ImageView) view.findViewById(R.id.img_celsius);
        this.mImg_fahrenheit = (ImageView) view.findViewById(R.id.img_fahrenheit);
        this.mTv_fahrenheit = (TextView) view.findViewById(R.id.tv_fahrenheit);
        this.mTv_celsius = (TextView) view.findViewById(R.id.tv_celsius);
        String tempratureType = getTempratureType();
        this.mTemp_type = tempratureType;
        if (tempratureType.equals("Fahrenheit")) {
            this.mImg_celsius.setImageResource(R.drawable.ic_radio_btn_white);
            this.mImg_fahrenheit.setImageResource(R.drawable.ic_radiobtn);
        } else {
            this.mImg_celsius.setImageResource(R.drawable.ic_radiobtn);
            this.mImg_fahrenheit.setImageResource(R.drawable.ic_radio_btn_white);
        }
        this.mLi_fahrenheit.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view2) {
                TempratureFragment.this.onClick(view2);
            }
        });
        this.mLi_celsius.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public final void onClick(View view2) {
                TempratureFragment.this.onClick(view2);
            }
        });
    }

    private String getTempratureType() {
        return this.mSP.getString(getActivity(), "temprature_type_temp", "Celsius");
    }

    @Override 
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.li_celsius) {
            this.mSP.setString(getActivity(), "temprature_type_temp", "Celsius");
            this.mImg_celsius.setImageResource(R.drawable.ic_radiobtn);
            this.mImg_fahrenheit.setImageResource(R.drawable.ic_radio_btn_white);
        } else if (id == R.id.li_fahrenheit) {
            this.mSP.setString(getActivity(), "temprature_type_temp", "Fahrenheit");
            this.mImg_celsius.setImageResource(R.drawable.ic_radio_btn_white);
            this.mImg_fahrenheit.setImageResource(R.drawable.ic_radiobtn);
        }
        OntTempratureListener ontTempratureListener = this.callBack;
        if (ontTempratureListener != null) {
            ontTempratureListener.onTempratureType();
        }
    }
}
