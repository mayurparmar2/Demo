package com.gpsvideocamera.videotimestamp.LocalNotification;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.gpsvideocamera.videotimestamp.Activity.SplashActivity;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.SP;

import java.util.Random;


public class BuildNotificationUtils {
    public static final String CHANNEL_ID = "notification_channel_id";
    public static final String CHANNEL_NAME = "notification_channel";
    private static String[] notiTitles = {"Live In Present!", "Don't Trust Words!!", "What do you say to god of photography?", "The pictures are there!!"};
    private static String[] notiMessages = {"Capture your activities Today!", "But Trust Gps Map Camera Lite captured Photos!", "One more. Do not Stop to take photo", "And you just take them with Gps Map Camera Lite"};

    public static Notification buildNotification(Context context, int i) {
        String str;
        int i2;
        Intent intent;
        String str2;
        int nextInt = new Random().nextInt(4);
        new SP(context);
        Build.MANUFACTURER.equalsIgnoreCase("xiaomi");
        switch (i) {
            case 51:
                str = notiTitles[nextInt];
                str2 = notiMessages[nextInt];
                intent = new Intent(context, SplashActivity.class);
                intent.putExtra("noti_code", 1);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i2 = 101;
                break;
            case 52:
                str = context.getString(R.string.not1title);
                str2 = context.getString(R.string.not1msg);
                intent = new Intent(context, SplashActivity.class);
                intent.putExtra("noti_code", 2);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i2 = 102;
                break;
            case 53:
                str = context.getString(R.string.not1title);
                str2 = context.getString(R.string.not1msg);
                intent = new Intent(context, SplashActivity.class);
                intent.putExtra("noti_code", 3);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i2 = 103;
                break;
            case 54:
                str = context.getString(R.string.not2title);
                str2 = context.getString(R.string.not2msg);
                intent = new Intent(context, SplashActivity.class);
                intent.putExtra("noti_code", 4);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i2 = 104;
                break;
            case 55:
                str = context.getString(R.string.not3title);
                str2 = context.getString(R.string.not3msg1);
                intent = new Intent(context, SplashActivity.class);
                intent.putExtra("noti_code", 5);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i2 = 105;
                break;
            case 56:
                str = context.getString(R.string.not3title);
                str2 = context.getString(R.string.not3msg2);
                intent = new Intent(context, SplashActivity.class);
                intent.putExtra("noti_code", 6);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i2 = 106;
                break;
            case 57:
                str = context.getString(R.string.not4title);
                str2 = context.getString(R.string.not4msg);
                intent = new Intent(context, SplashActivity.class);
                intent.putExtra("noti_code", 7);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i2 = 107;
                break;
            case 58:
                str = context.getString(R.string.not11title);
                str2 = context.getString(R.string.not11msg);
                intent = new Intent(context, SplashActivity.class);
                intent.putExtra("noti_code", 8);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i2 = 108;
                break;
            case 59:
                str = context.getString(R.string.not12title);
                str2 = context.getString(R.string.not12msg);
                intent = new Intent(context, SplashActivity.class);
                intent.putExtra("noti_code", 9);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i2 = 109;
                break;
            case 60:
                str = context.getString(R.string.not13title);
                str2 = context.getString(R.string.not13msg);
                intent = new Intent(context, SplashActivity.class);
                intent.putExtra("noti_code", 10);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i2 = 110;
                break;
            case 61:
                str = context.getString(R.string.not14title);
                str2 = context.getString(R.string.not14msg);
                intent = new Intent(context, SplashActivity.class);
                intent.putExtra("noti_code", 11);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i2 = 111;
                break;
            case 62:
                str = context.getString(R.string.not15title);
                str2 = context.getString(R.string.not15msg);
                intent = new Intent(context, SplashActivity.class);
                intent.putExtra("noti_code", 12);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i2 = 112;
                break;
            case 63:
                str = context.getString(R.string.not16title);
                str2 = context.getString(R.string.not16msg);
                intent = new Intent(context, SplashActivity.class);
                intent.putExtra("noti_code", 13);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i2 = 113;
                break;
            case 64:
                str = context.getString(R.string.not17title);
                str2 = context.getString(R.string.not17msg);
                intent = new Intent(context, SplashActivity.class);
                intent.putExtra("noti_code", 14);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i2 = 114;
                break;
            case 65:
                str = context.getString(R.string.not10title);
                str2 = context.getString(R.string.not10msg);
                intent = new Intent(context, SplashActivity.class);
                intent.putExtra("noti_code", 15);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i2 = 115;
                break;
            case 66:
                str = context.getString(R.string.not10title);
                str2 = context.getString(R.string.not10msg);
                intent = new Intent(context, SplashActivity.class);
                intent.putExtra("noti_code", 16);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i2 = 116;
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + i);
        }
        PendingIntent activity = PendingIntent.getActivity(context, i2, intent, PendingIntent.FLAG_IMMUTABLE);
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT < 26) {
            return new Notification.Builder(context).setShowWhen(true).setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH).setColor(context.getResources().getColor(R.color.colorPrimary)).setStyle(new Notification.BigTextStyle().bigText(str2)).setSmallIcon(R.mipmap.ic_launcher).setContentText(str2).setContentTitle(str).setContentIntent(activity).build();
        }
        NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH);
        notificationChannel.enableVibration(false);
        notificationManager.createNotificationChannel(notificationChannel);
        return new NotificationCompat.Builder(context, CHANNEL_ID).setShowWhen(true).setAutoCancel(true).setPriority(1).setColor(context.getColor(R.color.colorPrimary)).setStyle(new NotificationCompat.BigTextStyle().bigText(str2)).setSmallIcon(R.mipmap.ic_launcher).setContentText(str2).setContentTitle(str).setContentIntent(activity).build();
    }
}
