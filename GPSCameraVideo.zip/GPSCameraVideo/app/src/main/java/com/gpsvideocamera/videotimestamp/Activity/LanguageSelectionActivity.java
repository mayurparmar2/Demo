package com.gpsvideocamera.videotimestamp.Activity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.button.MaterialButton;
import com.gpsvideocamera.videotimestamp.Adapter.LanguageAdapter;
import com.gpsvideocamera.videotimestamp.Interface.OnRecyclerItemClickListener;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.Default;
import com.gpsvideocamera.videotimestamp.Utils.SP;


public class LanguageSelectionActivity extends AppCompatActivity implements View.OnClickListener {
    TypedArray Img_flag;
    private MaterialButton btnSave;
    int count;
    Intent intent;
    private LanguageAdapter mAdapter;
    private String[] mLanArray;
    private String[] mLanArray_real;
    private RecyclerView mRecyclerView;
    SP mSP;
    String mSelectedLanguage;
    AppBarLayout mToolbar;
    int selected_pos;
    RelativeLayout toolbar_back;
    RelativeLayout toolbar_select;
    TextView tv_home_subTitle;
    LinearLayout tv_home_title;
    TextView tv_toolbar_title;

    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_language_selection);
        init();
    }

    private void init() {
        SP sp = new SP(this);
        this.mSP = sp;
        this.count = sp.getInteger(this, SP.LANGUAGE_COUNT, 0).intValue();
        this.mLanArray = getResources().getStringArray(R.array.lan_array);
        this.mLanArray_real = getResources().getStringArray(R.array.lan_array_real);
        this.Img_flag = getResources().obtainTypedArray(R.array.lan_flag);
        this.mToolbar = (AppBarLayout) findViewById(R.id.toolbar);
        this.toolbar_back = (RelativeLayout) findViewById(R.id.toolbar_back);
        this.toolbar_select = (RelativeLayout) findViewById(R.id.toolbar_done);
        TextView textView = (TextView) findViewById(R.id.tv_toolbar_title);
        this.tv_toolbar_title = textView;
        textView.setText(getString(R.string.select_language));
        this.mRecyclerView = (RecyclerView) findViewById(R.id.select_lan_recyclerview);
        this.btnSave = (MaterialButton) findViewById(R.id.btnSave);
        this.tv_home_subTitle = (TextView) findViewById(R.id.tv_home_subTitle);
        this.tv_home_title = (LinearLayout) findViewById(R.id.tv_home_title);
        if (this.count == 0) {
            this.mToolbar.setVisibility(View.GONE);
            this.btnSave.setVisibility(View.VISIBLE);
        } else {
            this.tv_home_subTitle.setVisibility(View.GONE);
            this.tv_home_title.setVisibility(View.GONE);
            this.btnSave.setVisibility(View.GONE);
            this.mToolbar.setVisibility(View.VISIBLE);
        }
        this.mSelectedLanguage = this.mSP.getString(this, SP.SELECTED_LANGUAGE, Default.LANGUAGE);
        this.selected_pos = this.mSP.getInteger(this, SP.LANGUAGE_POS, -1).intValue();
        onClicks();
        setAdapter();
    }


    private void onClicks() {
        this.btnSave.setOnClickListener(new View.OnClickListener() { 
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                LanguageSelectionActivity.this.onClick(view);
            }
        });
        this.toolbar_back.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.LanguageSelectionActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                LanguageSelectionActivity.this.onClick(view);
            }
        });
        this.toolbar_select.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.LanguageSelectionActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                LanguageSelectionActivity.this.onClick(view);
            }
        });
    }

    private void setAdapter() {
        this.mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        LanguageAdapter languageAdapter = new LanguageAdapter(this, this.mLanArray, this.mLanArray_real, this.Img_flag, new OnRecyclerItemClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.LanguageSelectionActivity.1
            @Override // com.gpsvideocamera.videotimestamp.Interface.OnRecyclerItemClickListener
            public void OnLongClick_(int i, View view) {
            }

            @Override // com.gpsvideocamera.videotimestamp.Interface.OnRecyclerItemClickListener
            public void OnClick_(int i, View view) {
                LanguageSelectionActivity.this.selected_pos = i;
                if (LanguageSelectionActivity.this.selected_pos >= 0) {
                    LanguageSelectionActivity languageSelectionActivity = LanguageSelectionActivity.this;
                    languageSelectionActivity.mSelectedLanguage = languageSelectionActivity.mLanArray[i];
                    LanguageSelectionActivity.this.btnSave.setBackgroundColor(LanguageSelectionActivity.this.getResources().getColor(R.color._10aedb));
                    new Handler().postDelayed(new Runnable() { // from class: com.gpsvideocamera.videotimestamp.Activity.LanguageSelectionActivity.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            if (LanguageSelectionActivity.this.mAdapter != null) {
                                LanguageSelectionActivity.this.mAdapter.refAdapter(LanguageSelectionActivity.this.selected_pos);
                            }
                        }
                    }, 120);
                }
            }
        });
        this.mAdapter = languageAdapter;
        this.mRecyclerView.setAdapter(languageAdapter);
    }

    @SuppressLint("WrongConstant")
    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnSave :
                this.mSP.setInteger(this, SP.LANGUAGE_COUNT, 1);
                this.intent = new Intent(this, CameraActivity.class);
                saveData();
                return;
            case R.id.toolbar_back :
                onBackPressed();
                return;
            case R.id.toolbar_done :
                Intent intent = new Intent(this, CameraActivity.class);
                this.intent = intent;
                intent.setFlags(67239936);
                saveData();
                finish();
                return;
            default:
                return;
        }
    }

    public void saveData() {
        this.mSP.setString(this, SP.SELECTED_LANGUAGE, this.mSelectedLanguage);
        this.mSP.setInteger(this, SP.LANGUAGE_POS, Integer.valueOf(this.selected_pos));
        this.intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(this.intent);
        finish();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.count == 0) {
            return;
        }
        if (isChanges()) {
            confirmDialog();
        } else {
            super.onBackPressed();
        }
    }

    private boolean isChanges() {
        return this.selected_pos != this.mSP.getInteger(this, SP.LANGUAGE_POS, -1).intValue();
    }

    private void confirmDialog() {
        if (!isFinishing()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(getString(R.string.discard_message));
            builder.setPositiveButton(getString(R.string.save), new DialogInterface.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.LanguageSelectionActivity.2
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i) {
                    LanguageSelectionActivity.this.intent = new Intent(LanguageSelectionActivity.this, CameraActivity.class);
                    LanguageSelectionActivity.this.saveData();
                    dialogInterface.dismiss();
                    LanguageSelectionActivity.this.finish();
                }
            });
            builder.setNegativeButton(getString(R.string.discard), new DialogInterface.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.LanguageSelectionActivity.3
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    LanguageSelectionActivity.this.finish();
                }
            });
            builder.create().show();
        }
    }
}
