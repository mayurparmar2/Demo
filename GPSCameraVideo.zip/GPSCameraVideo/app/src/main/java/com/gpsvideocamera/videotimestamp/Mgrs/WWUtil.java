package com.gpsvideocamera.videotimestamp.Mgrs;


public class WWUtil {
    public static boolean isEmpty(Object obj) {
        return obj == null || ((obj instanceof String) && ((String) obj).length() == 0);
    }
}
