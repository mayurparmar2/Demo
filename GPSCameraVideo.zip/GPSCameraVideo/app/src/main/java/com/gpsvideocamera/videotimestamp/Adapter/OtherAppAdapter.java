package com.gpsvideocamera.videotimestamp.Adapter;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.gpsvideocamera.videotimestamp.Model.MoreAppsData;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.HelperClass;
import java.util.ArrayList;


public class OtherAppAdapter extends RecyclerView.Adapter<OtherAppAdapter.SingleListItemHolder> {
    private static final String TAG = "AdapterOtherApps";
    private HelperClass mCommonFunction = new HelperClass();
    private Context mContext;
    private ArrayList<MoreAppsData> mOtherAppGetSet;

    public OtherAppAdapter(Context context, ArrayList<MoreAppsData> arrayList) {
        this.mContext = context;
        this.mOtherAppGetSet = arrayList;
    }

    @Override 
    public SingleListItemHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new SingleListItemHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_more_app, viewGroup, false));
    }

    public void onBindViewHolder(SingleListItemHolder singleListItemHolder, int i) {
        TextView textView = singleListItemHolder.mItemName;
        textView.setText("" + this.mOtherAppGetSet.get(i).getApp_name());
        TextView textView2 = singleListItemHolder.mItemDesc;
        textView2.setText("" + this.mOtherAppGetSet.get(i).getApp_desc());
        Glide.with(this.mContext).load(this.mOtherAppGetSet.get(i).getApp_icon_url()).into(singleListItemHolder.mImageIcon);
    }

    @Override 
    public int getItemCount() {
        return this.mOtherAppGetSet.size();
    }

    
    
    public class SingleListItemHolder extends RecyclerView.ViewHolder {
        private LinearLayout btnInstall;
        private ImageView mImageIcon;
        private TextView mItemDesc;
        private TextView mItemName;

        SingleListItemHolder(View view) {
            super(view);
            this.mItemName = (TextView) view.findViewById(R.id.text_view_app_name);
            this.mItemDesc = (TextView) view.findViewById(R.id.text_view_app_desc);
            this.mImageIcon = (ImageView) view.findViewById(R.id.image_icon);
            this.btnInstall = (LinearLayout) view.findViewById(R.id.btnInstall);
            setIsRecyclable(false);
            this.itemView.setOnClickListener(new View.OnClickListener() {
                @Override 
                public void onClick(View view2) {
                    if (SingleListItemHolder.this.getAdapterPosition() >= 0) {
                        OtherAppAdapter.this.checkAppIsInstallOrNot(((MoreAppsData) OtherAppAdapter.this.mOtherAppGetSet.get(SingleListItemHolder.this.getAdapterPosition())).getApp_package_name(), ((MoreAppsData) OtherAppAdapter.this.mOtherAppGetSet.get(SingleListItemHolder.this.getAdapterPosition())).getApp_short_url(), view2);
                    }
                }
            });
            this.btnInstall.setOnClickListener(new View.OnClickListener() {
                @Override 
                public void onClick(View view2) {
                    if (SingleListItemHolder.this.getAdapterPosition() >= 0) {
                        OtherAppAdapter.this.checkAppIsInstallOrNot(((MoreAppsData) OtherAppAdapter.this.mOtherAppGetSet.get(SingleListItemHolder.this.getAdapterPosition())).getApp_package_name(), ((MoreAppsData) OtherAppAdapter.this.mOtherAppGetSet.get(SingleListItemHolder.this.getAdapterPosition())).getApp_short_url(), view2);
                    }
                }
            });
        }
    }

    
    public void checkAppIsInstallOrNot(String str, String str2, View view) {
        if (appInstalledOrNot(str)) {
            this.mContext.startActivity(this.mContext.getPackageManager().getLaunchIntentForPackage(str));
        } else if (HelperClass.check_internet(this.mContext)) {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse(str2));
            if (!MyStartActivity(this.mContext, intent)) {
                intent.setData(Uri.parse("market://details?id=" + str));
                if (!MyStartActivity(this.mContext, intent)) {
                    HelperClass.showSnackBar(view, "Application Not Available");
                }
            }
        } else {
            HelperClass.showSnackBar(view, this.mContext.getResources().getString(R.string.no_internet_msg));
        }
    }

    private boolean MyStartActivity(Context context, Intent intent) {
        try {
            context.startActivity(intent);
            return true;
        } catch (ActivityNotFoundException unused) {
            return false;
        }
    }

    private boolean appInstalledOrNot(String str) {
        try {
            this.mContext.getPackageManager().getPackageInfo(str, 1);
            return true;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }
}
