package com.gpsvideocamera.videotimestamp.Utils;

import android.view.View;


public interface onRecyclerClickListener {
    void setOnItemClickListener(int i, View view);
}
