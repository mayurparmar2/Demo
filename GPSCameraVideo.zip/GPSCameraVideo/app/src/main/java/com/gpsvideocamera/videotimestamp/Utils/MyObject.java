package com.gpsvideocamera.videotimestamp.Utils;

import android.graphics.Bitmap;


public class MyObject {
    Bitmap bitmap;
    byte[] data;

    public Bitmap getBitmap() {
        return this.bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }

    public byte[] getData() {
        return this.data;
    }

    public void setData(byte[] bArr) {
        this.data = bArr;
    }
}
