package com.gpsvideocamera.videotimestamp.Model;


public class UpdateHistory {
    private String version;
    private String versionDesc;

    public UpdateHistory(String str, String str2) {
        this.version = str;
        this.versionDesc = str2;
    }

    public String getVersion() {
        return this.version;
    }

    public void setVersion(String str) {
        this.version = str;
    }

    public String getVersionDesc() {
        return this.versionDesc;
    }

    public void setVersionDesc(String str) {
        this.versionDesc = str;
    }
}
