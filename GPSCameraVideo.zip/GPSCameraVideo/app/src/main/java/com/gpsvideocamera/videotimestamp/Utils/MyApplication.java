package com.gpsvideocamera.videotimestamp.Utils;

import android.Manifest;
import android.app.Application;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Process;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;

import java.util.ArrayList;
import java.util.List;


public class MyApplication extends Application {

    @Override 
    public void onCreate() {
        super.onCreate();
        AppCompatDelegate. setDefaultNightMode(androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_NO);
        checkAppReplacingState();
    }

    private void checkAppReplacingState() {
        if (getResources() == null) {
            Process.killProcess(Process.myPid());
        }
    }

    public static boolean hasPermissions(Context context, String... permissions) {
        for (String permission : permissions) {
            if (ActivityCompat.checkSelfPermission(context, permission)
                    != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }


    public static final int PERMISSION_TOKEN = 1212;
    public static final String[] ALL_PERMISSIONS_LIST = getRequiredPermissions().toArray(new String[0]);

    public static List<String> getRequiredPermissions() {
        List<String> permissions = new ArrayList<>();
        permissions.add(Manifest.permission.CAMERA);
        if (Build.VERSION.SDK_INT >= 33) {
            permissions.add("android.permission.READ_MEDIA_VIDEO");
            permissions.add("android.permission.READ_MEDIA_IMAGES");
            permissions.add("android.permission.POST_NOTIFICATIONS");
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            permissions.add("android.permission.WRITE_EXTERNAL_STORAGE");
            permissions.add("android.permission.READ_EXTERNAL_STORAGE");
        }
        return permissions;
    }

}
