package com.gpsvideocamera.videotimestamp.Utils;


import com.android.billingclient.api.Purchase;

import java.util.ArrayList;
import java.util.List;


public class SearchHelper {
    public static List<String> getPurchasedProductIdListing(List<Purchase> list) {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < list.size(); i++) {
            arrayList.add(list.get(i).getSkus().get(0));
        }
        return arrayList;
    }
}
