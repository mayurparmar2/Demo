package com.gpsvideocamera.videotimestamp.Mgrs;




public class Quaternion {
    private static final int NUM_ELEMENTS = 4;
    private int hashCode;
    public final double w;
    public final double x;
    public final double y;
    public final double z;
    private static final Double NegativeZero = Double.valueOf(-0.0d);
    private static final Double PositiveZero = Double.valueOf((double) 0.0d);
    public static final Quaternion IDENTITY = new Quaternion(0.0d, 0.0d, 0.0d, 1.0d);

    public Quaternion(double d, double d2, double d3, double d4) {
        this.x = d;
        this.y = d2;
        this.z = d3;
        this.w = d4;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        Quaternion quaternion = (Quaternion) obj;
        if (this.x == quaternion.x && this.y == quaternion.y && this.z == quaternion.z && this.w == quaternion.w) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        if (this.hashCode == 0) {
            long doubleToLongBits = Double.doubleToLongBits(this.x);
            long doubleToLongBits2 = Double.doubleToLongBits(this.y);
            long doubleToLongBits3 = Double.doubleToLongBits(this.z);
            long doubleToLongBits4 = Double.doubleToLongBits(this.w);
            this.hashCode = (((((((int) (doubleToLongBits ^ (doubleToLongBits >>> 32))) * 31) + ((int) (doubleToLongBits2 ^ (doubleToLongBits2 >>> 32)))) * 31) + ((int) (doubleToLongBits3 ^ (doubleToLongBits3 >>> 32)))) * 31) + ((int) ((doubleToLongBits4 >>> 32) ^ doubleToLongBits4));
        }
        return this.hashCode;
    }

    public static Quaternion fromArray(double[] dArr, int i) {
        if (dArr == null) {
            throw new IllegalArgumentException("Array Is Null");
        } else if (dArr.length - i >= 4) {
            return new Quaternion(dArr[i + 0], dArr[i + 1], dArr[i + 2], dArr[i + 3]);
        } else {
            throw new IllegalArgumentException("Array Invalid Length");
        }
    }

    public final double[] toArray(double[] dArr, int i) {
        if (dArr == null) {
            throw new IllegalArgumentException("Array Is Null");
        } else if (dArr.length - i >= 4) {
            dArr[i + 0] = this.x;
            dArr[i + 1] = this.y;
            dArr[i + 2] = this.z;
            dArr[i + 3] = this.w;
            return dArr;
        } else {
            throw new IllegalArgumentException("Array Invalid Length");
        }
    }

    public final String toString() {
        return "(" + this.x + ", " + this.y + ", " + this.z + ", " + this.w + ")";
    }

    public final double getX() {
        return this.x;
    }

    public final double getY() {
        return this.y;
    }

    public final double getZ() {
        return this.z;
    }

    public final double getW() {
        return this.w;
    }

    public final double x() {
        return this.x;
    }

    public final double y() {
        return this.y;
    }

    public final double z() {
        return this.z;
    }

    public final double w() {
        return this.w;
    }

    public static Quaternion fromAxisAngle(Angle angle, Vec4 vec4) {
        if (angle == null) {
            throw new IllegalArgumentException("Angle Is Null");
        } else if (vec4 != null) {
            return fromAxisAngle(angle, vec4.x, vec4.y, vec4.z, true);
        } else {
            throw new IllegalArgumentException("Vec4 Is Null");
        }
    }

    public static Quaternion fromAxisAngle(Angle angle, double d, double d2, double d3) {
        if (angle != null) {
            return fromAxisAngle(angle, d, d2, d3, true);
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    private static Quaternion fromAxisAngle(Angle angle, double d, double d2, double d3, boolean z) {
        if (angle != null) {
            if (z) {
                double sqrt = Math.sqrt((d * d) + (d2 * d2) + (d3 * d3));
                if (!isZero(sqrt) && sqrt != 1.0d) {
                    double d4 = d / sqrt;
                    double d5 = d2 / sqrt;
                    double sinHalfAngle = angle.sinHalfAngle();
                    return new Quaternion(d4 * sinHalfAngle, d5 * sinHalfAngle, (d3 / sqrt) * sinHalfAngle, angle.cosHalfAngle());
                }
            }
            double sinHalfAngle2 = angle.sinHalfAngle();
            return new Quaternion(d * sinHalfAngle2, d2 * sinHalfAngle2, d3 * sinHalfAngle2, angle.cosHalfAngle());
        }
        throw new IllegalArgumentException("Angle Is Null");
    }

    public static Quaternion fromMatrix(Matrix matrix) {
        double d;
        double d2;
        double d3;
        double d4;
        double d5;
        double d6;
        double d7;
        if (matrix != null) {
            double d8 = matrix.m11 + 1.0d + matrix.m22 + matrix.m33;
            if (d8 > 1.0E-8d) {
                double sqrt = Math.sqrt(d8) * 2.0d;
                d5 = (matrix.m32 - matrix.m23) / sqrt;
                d4 = (matrix.m13 - matrix.m31) / sqrt;
                d2 = (matrix.m21 - matrix.m12) / sqrt;
                d7 = sqrt / 4.0d;
            } else {
                if (matrix.m11 > matrix.m22 && matrix.m11 > matrix.m33) {
                    d6 = Math.sqrt(((matrix.m11 + 1.0d) - matrix.m22) - matrix.m33) * 2.0d;
                    d5 = d6 / 4.0d;
                    d4 = (matrix.m21 + matrix.m12) / d6;
                    d2 = (matrix.m13 + matrix.m31) / d6;
                    d3 = matrix.m32;
                    d = matrix.m23;
                } else if (matrix.m22 > matrix.m33) {
                    d6 = Math.sqrt(((matrix.m22 + 1.0d) - matrix.m11) - matrix.m33) * 2.0d;
                    d5 = (matrix.m21 + matrix.m12) / d6;
                    d4 = d6 / 4.0d;
                    d2 = (matrix.m32 + matrix.m23) / d6;
                    d3 = matrix.m13;
                    d = matrix.m31;
                } else {
                    d6 = Math.sqrt(((matrix.m33 + 1.0d) - matrix.m11) - matrix.m22) * 2.0d;
                    d5 = (matrix.m13 + matrix.m31) / d6;
                    d4 = (matrix.m32 + matrix.m23) / d6;
                    d2 = d6 / 4.0d;
                    d3 = matrix.m21;
                    d = matrix.m12;
                }
                d7 = (d3 - d) / d6;
            }
            return new Quaternion(d5, d4, d2, d7);
        }
        throw new IllegalArgumentException("Matrix Is Null");
    }

    public static Quaternion fromRotationXYZ(Angle angle, Angle angle2, Angle angle3) {
        if (angle == null || angle2 == null || angle3 == null) {
            throw new IllegalArgumentException("Angle Is Null");
        }
        double cosHalfAngle = angle.cosHalfAngle();
        double cosHalfAngle2 = angle2.cosHalfAngle();
        double cosHalfAngle3 = angle3.cosHalfAngle();
        double sinHalfAngle = angle.sinHalfAngle();
        double sinHalfAngle2 = angle2.sinHalfAngle();
        double sinHalfAngle3 = angle3.sinHalfAngle();
        double d = cosHalfAngle * cosHalfAngle2;
        double d2 = sinHalfAngle * sinHalfAngle2;
        double d3 = sinHalfAngle * cosHalfAngle2;
        double d4 = cosHalfAngle * sinHalfAngle2;
        return new Quaternion((d3 * cosHalfAngle3) - (d4 * sinHalfAngle3), (d4 * cosHalfAngle3) + (d3 * sinHalfAngle3), (d * sinHalfAngle3) - (d2 * cosHalfAngle3), (d * cosHalfAngle3) + (d2 * sinHalfAngle3));
    }

    public static Quaternion fromLatLon(Angle angle, Angle angle2) {
        if (angle == null || angle2 == null) {
            throw new IllegalArgumentException("Angle Is Null");
        }
        double cosHalfAngle = angle.cosHalfAngle();
        double cosHalfAngle2 = angle2.cosHalfAngle();
        double sinHalfAngle = angle.sinHalfAngle();
        double sinHalfAngle2 = angle2.sinHalfAngle();
        return new Quaternion(cosHalfAngle * sinHalfAngle2, sinHalfAngle * cosHalfAngle2, 0.0d - (sinHalfAngle * sinHalfAngle2), cosHalfAngle * cosHalfAngle2);
    }

    public final Quaternion add(Quaternion quaternion) {
        if (quaternion != null) {
            return new Quaternion(this.x + quaternion.x, this.y + quaternion.y, this.z + quaternion.z, this.w + quaternion.w);
        }
        throw new IllegalArgumentException("Quaternion Is Null");
    }

    public final Quaternion subtract(Quaternion quaternion) {
        if (quaternion != null) {
            return new Quaternion(this.x - quaternion.x, this.y - quaternion.y, this.z - quaternion.z, this.w - quaternion.w);
        }
        throw new IllegalArgumentException("Quaternion Is Null");
    }

    public final Quaternion multiplyComponents(double d) {
        return new Quaternion(this.x * d, this.y * d, this.z * d, this.w * d);
    }

    public final Quaternion multiply(Quaternion quaternion) {
        if (quaternion != null) {
            double d = this.w;
            double d2 = quaternion.x;
            double d3 = this.x;
            double d4 = quaternion.w;
            double d5 = (d * d2) + (d3 * d4);
            double d6 = this.y;
            double d7 = quaternion.z;
            double d8 = this.z;
            double d9 = quaternion.y;
            return new Quaternion((d5 + (d6 * d7)) - (d8 * d9), (((d * d9) + (d6 * d4)) + (d8 * d2)) - (d3 * d7), (((d * d7) + (d8 * d4)) + (d3 * d9)) - (d6 * d2), (((d * d4) - (d2 * d3)) - (d6 * d9)) - (d8 * d7));
        }
        throw new IllegalArgumentException("Quaternion Is Null");
    }

    public final Quaternion divideComponents(double d) {
        if (!isZero(d)) {
            return new Quaternion(this.x / d, this.y / d, this.z / d, this.w / d);
        }
        throw new IllegalArgumentException("Argument Out Of Range");
    }

    public final Quaternion divideComponents(Quaternion quaternion) {
        if (quaternion != null) {
            return new Quaternion(this.x / quaternion.x, this.y / quaternion.y, this.z / quaternion.z, this.w / quaternion.w);
        }
        throw new IllegalArgumentException("Quaternion Is Null");
    }

    public final Quaternion getConjugate() {
        return new Quaternion(0.0d - this.x, 0.0d - this.y, 0.0d - this.z, this.w);
    }

    public final Quaternion getNegative() {
        return new Quaternion(0.0d - this.x, 0.0d - this.y, 0.0d - this.z, 0.0d - this.w);
    }

    public final double getLength() {
        return Math.sqrt(getLengthSquared());
    }

    public final double getLengthSquared() {
        double d = this.x;
        double d2 = this.y;
        double d3 = (d * d) + (d2 * d2);
        double d4 = this.z;
        double d5 = d3 + (d4 * d4);
        double d6 = this.w;
        return d5 + (d6 * d6);
    }

    public final Quaternion normalize() {
        double length = getLength();
        if (isZero(length)) {
            return this;
        }
        return new Quaternion(this.x / length, this.y / length, this.z / length, this.w / length);
    }

    public final double dot(Quaternion quaternion) {
        if (quaternion != null) {
            return (this.x * quaternion.x) + (this.y * quaternion.y) + (this.z * quaternion.z) + (this.w * quaternion.w);
        }
        throw new IllegalArgumentException("Quaternion Is Null");
    }

    public final Quaternion getInverse() {
        double length = getLength();
        if (isZero(length)) {
            return this;
        }
        return new Quaternion((0.0d - this.x) / length, (0.0d - this.y) / length, (0.0d - this.z) / length, this.w / length);
    }

    public static Quaternion mix(double d, Quaternion quaternion, Quaternion quaternion2) {
        if (quaternion == null || quaternion2 == null) {
            throw new IllegalArgumentException("Quaternion Is Null");
        } else if (d < 0.0d) {
            return quaternion;
        } else {
            if (d > 1.0d) {
                return quaternion2;
            }
            double d2 = 1.0d - d;
            return new Quaternion((quaternion.x * d2) + (quaternion2.x * d), (quaternion.y * d2) + (quaternion2.y * d), (quaternion.z * d2) + (quaternion2.z * d), (quaternion.w * d2) + (quaternion2.w * d));
        }
    }

    public static Quaternion slerp(double d, Quaternion quaternion, Quaternion quaternion2) {
        double d2;
        double d3;
        double d4;
        double d5;
        double d6;
        double d7;
        if (quaternion == null || quaternion2 == null) {
            throw new IllegalArgumentException("Quaternion Is Null");
        } else if (d < 0.0d) {
            return quaternion;
        } else {
            if (d > 1.0d) {
                return quaternion2;
            }
            double dot = quaternion.dot(quaternion2);
            if (dot < 0.0d) {
                dot = 0.0d - dot;
                d4 = 0.0d - quaternion2.x;
                d3 = 0.0d - quaternion2.y;
                d2 = 0.0d - quaternion2.z;
                d5 = 0.0d - quaternion2.w;
            } else {
                d4 = quaternion2.x;
                d3 = quaternion2.y;
                d2 = quaternion2.z;
                d5 = quaternion2.w;
            }
            if (1.0d - dot > 1.0E-4d) {
                double acos = Math.acos(dot);
                double sin = Math.sin(acos);
                d7 = Math.sin((1.0d - d) * acos) / sin;
                d6 = Math.sin(acos * d) / sin;
            } else {
                d7 = 1.0d - d;
                d6 = d;
            }
            return new Quaternion((quaternion.x * d7) + (d4 * d6), (quaternion.y * d7) + (d3 * d6), (quaternion.z * d7) + (d2 * d6), (quaternion.w * d7) + (d5 * d6));
        }
    }

    public final Angle getAngle() {
        double d = this.w;
        double length = getLength();
        if (!isZero(length) && length != 1.0d) {
            d /= length;
        }
        double acos = Math.acos(d) * 2.0d;
        if (Double.isNaN(acos)) {
            return null;
        }
        return Angle.fromRadians(acos);
    }

    public final Vec4 getAxis() {
        double d = this.x;
        double d2 = this.y;
        double d3 = this.z;
        double length = getLength();
        if (!isZero(length) && length != 1.0d) {
            d /= length;
            d2 /= length;
            d3 /= length;
        }
        double sqrt = Math.sqrt((d * d) + (d2 * d2) + (d3 * d3));
        if (!isZero(sqrt) && sqrt != 1.0d) {
            d /= sqrt;
            d2 /= sqrt;
            d3 /= sqrt;
        }
        return new Vec4(d, d2, d3);
    }

    public final Angle getRotationX() {
        double d = this.x;
        double d2 = this.z;
        double atan2 = Math.atan2(((d * 2.0d) * this.w) - ((this.y * 2.0d) * d2), (1.0d - ((d * d) * 2.0d)) - ((d2 * d2) * 2.0d));
        if (Double.isNaN(atan2)) {
            return null;
        }
        return Angle.fromRadians(atan2);
    }

    public final Angle getRotationY() {
        double d = this.y;
        double d2 = this.z;
        double atan2 = Math.atan2(((d * 2.0d) * this.w) - ((this.x * 2.0d) * d2), (1.0d - ((d * 2.0d) * d)) - ((2.0d * d2) * d2));
        if (Double.isNaN(atan2)) {
            return null;
        }
        return Angle.fromRadians(atan2);
    }

    public final Angle getRotationZ() {
        double asin = Math.asin((this.x * 2.0d * this.y) + (this.z * 2.0d * this.w));
        if (Double.isNaN(asin)) {
            return null;
        }
        return Angle.fromRadians(asin);
    }

    public final LatLon getLatLon() {
        double asin = Math.asin(((this.y * 2.0d) * this.w) - ((this.x * 2.0d) * this.z));
        double d = this.y;
        double d2 = this.z;
        double d3 = this.x;
        double d4 = this.w;
        double atan2 = Math.atan2((d * 2.0d * d2) + (2.0d * d3 * d4), (((d4 * d4) - (d3 * d3)) - (d * d)) + (d2 * d2));
        if (Double.isNaN(asin) || Double.isNaN(atan2)) {
            return null;
        }
        return LatLon.fromRadians(asin, atan2);
    }

    private static boolean isZero(double d) {
        return PositiveZero.compareTo(Double.valueOf(d)) == 0 || NegativeZero.compareTo(Double.valueOf(d)) == 0;
    }
}
