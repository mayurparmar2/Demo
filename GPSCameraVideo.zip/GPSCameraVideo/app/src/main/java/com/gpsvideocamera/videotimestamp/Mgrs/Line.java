package com.gpsvideocamera.videotimestamp.Mgrs;




public final class Line {
    private final Vec4 direction;
    private final Vec4 origin;

    public static Line fromSegment(Vec4 vec4, Vec4 vec42) {
        return new Line(vec4, new Vec4(vec42.x - vec4.x, vec42.y - vec4.y, vec42.z - vec4.z, 0.0d));
    }

    public Line(Vec4 vec4, Vec4 vec42) {
        String str = vec4 == null ? "Origin Is Null" : vec42 == null ? "Direction Is Null" : vec42.getLength3() <= 0.0d ? "Direction Is Zero Vector" : null;
        if (str == null) {
            this.origin = vec4;
            this.direction = vec42;
            return;
        }
        throw new IllegalArgumentException(str);
    }

    public final Vec4 getDirection() {
        return this.direction;
    }

    public final Vec4 getOrigin() {
        return this.origin;
    }

    public final Vec4 getPointAt(double d) {
        return Vec4.fromLine3(this.origin, d, this.direction);
    }

    public final double selfDot() {
        return this.origin.dot3(this.direction);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Line line = (Line) obj;
        if (!this.direction.equals(line.direction) || !line.origin.equals(this.origin)) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return (this.origin.hashCode() * 29) + this.direction.hashCode();
    }

    public String toString() {
        return "Origin: " + this.origin + ", Direction: " + this.direction;
    }

    public final Vec4 nearestPointTo(Vec4 vec4) {
        Vec4 vec42 = this.origin;
        Vec4 vec43 = this.direction;
        double dot3 = vec4.subtract3(vec42).dot3(this.direction);
        Vec4 vec44 = this.direction;
        return vec42.add3(vec43.multiply3(dot3 / vec44.dot3(vec44)));
    }

    public final double distanceTo(Vec4 vec4) {
        return vec4.distanceTo3(nearestPointTo(vec4));
    }

    public static Vec4 nearestPointOnSegment(Vec4 vec4, Vec4 vec42, Vec4 vec43) {
        Vec4 subtract3 = vec42.subtract3(vec4);
        double dot3 = vec43.subtract3(vec4).dot3(subtract3);
        double dot32 = subtract3.dot3(subtract3);
        if (dot3 <= 0.0d) {
            return vec4;
        }
        if (dot32 <= dot3) {
            return vec42;
        }
        return vec4.add3(subtract3.multiply3(dot3 / dot32));
    }

    public static double distanceToSegment(Vec4 vec4, Vec4 vec42, Vec4 vec43) {
        return vec43.distanceTo3(nearestPointOnSegment(vec4, vec42, vec43));
    }

    public static Vec4[] clipToFrustum(Vec4 vec4, Vec4 vec42, Frustum frustum) {
        return clipToFrustum(vec4, vec42, frustum, 1);
    }

    private static Vec4[] clipToFrustum(Vec4 vec4, Vec4 vec42, Frustum frustum, int i) {
        if (vec4 == null || vec42 == null) {
            throw new IllegalArgumentException("Point Is Null");
        } else if (frustum == null) {
            throw new IllegalArgumentException("Frustum Is Null");
        } else if (frustum.contains(vec4) && frustum.contains(vec42)) {
            return new Vec4[]{vec4, vec42};
        } else {
            Vec4[] vec4Arr = {vec4, vec42};
            Plane[] allPlanes = frustum.getAllPlanes();
            for (Plane plane : allPlanes) {
                if (plane.onSameSide(vec4Arr[0], vec4Arr[1]) < 0) {
                    return null;
                }
                Vec4[] clip = plane.clip(vec4Arr[0], vec4Arr[1]);
                if (clip != null) {
                    vec4Arr = clip;
                }
            }
            return (frustum.contains(vec4) || frustum.contains(vec42) || i <= 0) ? vec4Arr : clipToFrustum(vec4Arr[0], vec4Arr[1], frustum, i - 1);
        }
    }

    public boolean isPointBehindLineOrigin(Vec4 vec4) {
        return vec4.subtract3(getOrigin()).dot3(getDirection()) < 0.0d;
    }

    public Vec4 nearestIntersectionPoint(Intersection[] intersectionArr) {
        Vec4 vec4 = null;
        double d = Double.MAX_VALUE;
        for (Intersection intersection : intersectionArr) {
            if (!isPointBehindLineOrigin(intersection.getIntersectionPoint())) {
                double distanceTo3 = intersection.getIntersectionPoint().distanceTo3(getOrigin());
                if (distanceTo3 < d) {
                    vec4 = intersection.getIntersectionPoint();
                    d = distanceTo3;
                }
            }
        }
        return vec4;
    }
}
