package com.gpsvideocamera.videotimestamp.LocalNotification;

import android.content.Context;
import android.os.Bundle;



public class FBAnalyticsEventUtils {
    public static void registerEvent(Context context, String str, String str2, String str3) {
        Bundle bundle = new Bundle();
        bundle.putString(str2, str3);
    }
}
