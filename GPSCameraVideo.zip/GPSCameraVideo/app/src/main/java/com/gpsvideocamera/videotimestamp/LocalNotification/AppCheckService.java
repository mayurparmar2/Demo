package com.gpsvideocamera.videotimestamp.LocalNotification;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import com.gpsvideocamera.videotimestamp.Utils.SP;


public class AppCheckService extends Service {
    SP sp;

    @Override 
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override 
    public void onCreate() {
        super.onCreate();
        this.sp = new SP(this);
    }

    @Override 
    public int onStartCommand(Intent intent, int i, int i2) {
        this.sp.setBoolean(this, "app_running", true);
        return Service.START_NOT_STICKY;
    }

    @Override 
    public void onDestroy() {
        super.onDestroy();
        Log.d("ClearFromRecentService", "Service Destroyed");
    }

    @Override 
    public void onTaskRemoved(Intent intent) {
        this.sp.setBoolean(this, "app_running", false);
        stopSelf();
    }
}
