package com.gpsvideocamera.videotimestamp.Activity;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.demo.example.R;
import kotlin.Metadata;
public final class MainActivity extends AppCompatActivity {
    
    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
    }
}
