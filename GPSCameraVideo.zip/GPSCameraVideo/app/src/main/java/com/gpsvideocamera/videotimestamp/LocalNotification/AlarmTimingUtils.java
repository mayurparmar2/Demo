package com.gpsvideocamera.videotimestamp.LocalNotification;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import java.util.Calendar;


public class AlarmTimingUtils {
    public static void setLastOpenTime(Context context, long j) {
        new SP(context).setLong(context, SP.OPEN_TIME, j);
    }

    public static long getLastOpenTime(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), PackageManager.GET_CONFIGURATIONS);
            if (new SP(context).getLong(context, SP.OPEN_TIME, packageInfo.firstInstallTime) == packageInfo.firstInstallTime) {
                return packageInfo.firstInstallTime;
            }
            return new SP(context).getLong(context, SP.OPEN_TIME, packageInfo.firstInstallTime);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return 0;
        }
    }

    public static boolean isWithin15Days(Context context) {
        Calendar instance = Calendar.getInstance();
        instance.setTimeInMillis(getLastOpenTime(context));
        Calendar instance2 = Calendar.getInstance();
        instance2.setTimeInMillis(System.currentTimeMillis());
        return Integer.parseInt(Long.toString(Math.abs(instance2.getTimeInMillis() - instance.getTimeInMillis()) / 86400000)) <= 14;
    }
}
