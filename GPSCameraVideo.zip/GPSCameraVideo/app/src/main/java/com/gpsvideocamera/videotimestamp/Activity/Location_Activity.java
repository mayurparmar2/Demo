package com.gpsvideocamera.videotimestamp.Activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.IntentSender;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;


import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.snackbar.Snackbar;

import com.gpsvideocamera.videotimestamp.Location.LocationSupplier;
import com.demo.example.R;
import com.gpsvideocamera.videotimestamp.Utils.Default;
import com.gpsvideocamera.videotimestamp.Utils.HelperClass;
import com.gpsvideocamera.videotimestamp.Utils.SP;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


public class Location_Activity extends AppCompatActivity implements View.OnClickListener, OnMapReadyCallback, GoogleMap.OnCameraIdleListener {
    private static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = 5000;
    private static final int REQUEST_CHECK_SETTINGS = 100;
    private static final long UPDATE_INTERVAL_IN_MILLISECONDS = 1000;
    FusedLocationProviderClient fusedLocationClient;
    private LocationSupplier locationSupplier;
    String mAddress_line_1;
    private BottomSheetBehavior mBottomSheetCardView;
    String mCity;
    String mCountry;
    private Location mCurrentLocation;
    EditText mEd_city;
    EditText mEd_country;
    EditText mEd_latitude;
    EditText mEd_loc_line_1;
    EditText mEd_longitude;
    EditText mEd_state;
    private HelperClass mHelperClass;
    private ImageView mImg_menu;
    double mLatitude;
    private LocationCallback mLocationCallback;
    private LocationRequest mLocationRequest;
    private LocationSettingsRequest mLocationSettingsRequest;
    String mLocationType;
    private RelativeLayout mLocation_toolbar;
    double mLongitude;
    GoogleMap mMap;
    SupportMapFragment mMapFragment;
    RelativeLayout mMap_view;
    String mPostalCode;
    RelativeLayout mRel_mask;
    SP mSP;
    ScrollView mScrollView;
    private SettingsClient mSettingsClient;
    String mState;
    private RelativeLayout mToolbar_back;
    private LinearLayout mToolbar_menu;
    ImageView moImg_location;
    ImageView moImg_mapType;
    ImageView moImg_map_fs;
    RelativeLayout mrelLocation_layout;
    private TextView mtv_toolbar_title;
    private int camMove = 0;
    private boolean app_is_paused = false;
    Marker marker = null;

    @Override 
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        HelperClass helperClass = new HelperClass();
        this.mHelperClass = helperClass;
        helperClass.SetLanguage(this);
        AppCompatDelegate. setDefaultNightMode(androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_NO);
        setContentView(R.layout.activity_location);
        init();
        initMapFragment();
    }


    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onResume() {
        super.onResume();
        this.app_is_paused = false;
        startLocationUpdates();
    }

    private void onClicks() {
        this.mToolbar_menu.setOnClickListener(this);
        this.mToolbar_back.setOnClickListener(this);
        this.moImg_location.setOnClickListener(this);
        this.moImg_mapType.setOnClickListener(this);
        this.moImg_map_fs.setOnClickListener(this);
    }

    public int getStatusBarHeight() {
        int identifier = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (identifier > 0) {
            return getResources().getDimensionPixelSize(identifier);
        }
        return 0;
    }

    private void init() {
        this.mSP = new SP(this);
        this.mToolbar_menu = (LinearLayout) findViewById(R.id.toolbar_menu);
        this.mToolbar_back = (RelativeLayout) findViewById(R.id.toolbar_back);
        this.mtv_toolbar_title = (TextView) findViewById(R.id.tv_toolbar_title);
        this.mImg_menu = (ImageView) findViewById(R.id.img_menu);
        this.mEd_latitude = (EditText) findViewById(R.id.mEd_latitude);
        this.mEd_longitude = (EditText) findViewById(R.id.mEd_longitude);
        this.mEd_loc_line_1 = (EditText) findViewById(R.id.mEd_loc_line_1);
        this.mEd_city = (EditText) findViewById(R.id.mEd_city);
        this.mEd_state = (EditText) findViewById(R.id.mEd_state);
        this.mEd_country = (EditText) findViewById(R.id.mEd_country);
        this.mScrollView = (ScrollView) findViewById(R.id.nes_location_detail);
        this.mRel_mask = (RelativeLayout) findViewById(R.id.rel_mask);
        this.moImg_map_fs = (ImageView) findViewById(R.id.img_map_fs);
        this.moImg_mapType = (ImageView) findViewById(R.id.img_mapType);
        this.moImg_location = (ImageView) findViewById(R.id.img_location);
        this.mMap_view = (RelativeLayout) findViewById(R.id.map_view);
        this.mrelLocation_layout = (RelativeLayout) findViewById(R.id.location_layout);
        this.mLocation_toolbar = (RelativeLayout) findViewById(R.id.location_toolbar);
        this.mLocationType = getLocation_Type();
        onClicks();
        updateManualLocationUI();
        if (!HelperClass.check_internet(this)) {
            RelativeLayout relativeLayout = this.mMap_view;
            Snackbar.make(relativeLayout, "" + getString(R.string.no_internet_msg), -Toast.LENGTH_LONG).show();
        }
    }

    public void disableUI() {
        if (this.mLocationType.equals(Default.AUTOMATIC)) {
            this.mtv_toolbar_title.setText(getString(R.string.automatic));
            this.mEd_latitude.setCursorVisible(false);
            this.mEd_longitude.setCursorVisible(false);
            this.mEd_city.setCursorVisible(false);
            this.mEd_country.setCursorVisible(false);
            this.mEd_state.setCursorVisible(false);
            this.mEd_loc_line_1.setCursorVisible(false);
            this.mScrollView.setAlpha(0.5f);
            this.mMap_view.setAlpha(0.5f);
            this.mRel_mask.setVisibility(View.VISIBLE);
            updateLiveLocaionUI();
            return;
        }
        this.mtv_toolbar_title.setText(getString(R.string.manual));
        latitude_CursorPos();
        longitude_CursorPos();
        line_1_cursorPos();
        cityCursorPos();
        state_CursorPos();
        country_CursorPos();
        this.mEd_latitude.setCursorVisible(true);
        this.mEd_longitude.setCursorVisible(true);
        this.mEd_city.setCursorVisible(true);
        this.mEd_country.setCursorVisible(true);
        this.mEd_state.setCursorVisible(true);
        this.mEd_loc_line_1.setCursorVisible(true);
        this.mMap_view.setAlpha(1.0f);
        this.mScrollView.setAlpha(1.0f);
        this.mRel_mask.setVisibility(View.GONE);
        updateManualLocationUI();
    }

    private void country_CursorPos() {
        EditText editText = this.mEd_country;
        editText.setSelection(editText.getText().toString().trim().length());
    }

    private void state_CursorPos() {
        EditText editText = this.mEd_state;
        editText.setSelection(editText.getText().toString().trim().length());
    }

    private void longitude_CursorPos() {
        EditText editText = this.mEd_longitude;
        editText.setSelection(editText.getText().toString().trim().length());
    }

    private void cityCursorPos() {
        EditText editText = this.mEd_city;
        editText.setSelection(editText.getText().toString().trim().length());
    }

    private void line_1_cursorPos() {
        EditText editText = this.mEd_loc_line_1;
        editText.setSelection(editText.getText().toString().trim().length());
    }

    private void latitude_CursorPos() {
        EditText editText = this.mEd_latitude;
        editText.setSelection(editText.getText().toString().trim().length());
    }

    private void updateManualLocationUI() {
        if (this.mLocationType.equals(Default.MANUAL) || isEmpty()) {
            String string = this.mSP.getString(this, SP.LATITUDE, "");
            if (string != null && !string.isEmpty()) {
                if (string.contains(",")) {
                    string = string.replace(",", ".");
                }
                this.mLatitude = Double.valueOf(string).doubleValue();
            }
            String string2 = this.mSP.getString(this, SP.LONGITUDE, "");
            if (string2 != null && !string2.isEmpty()) {
                if (string2.contains(",")) {
                    string2 = string2.replace(",", ".");
                }
                this.mLongitude = Double.valueOf(string2).doubleValue();
            }
            this.mAddress_line_1 = this.mSP.getString(this, SP.LOC_LINE_1_ADDRESS, "");
            this.mCity = this.mSP.getString(this, SP.LOC_LINE_2_CITY, "");
            this.mState = this.mSP.getString(this, SP.LOC_LINE_3_STATE, "");
            this.mCountry = this.mSP.getString(this, SP.LOC_LINE_4_COUNTRY, "");
            setEditTextData(this.mLatitude, this.mLongitude);
            animateMarker(this.mLatitude, this.mLongitude);
        }
    }

    private void setEditTextData(double d, double d2) {
        DecimalFormat decimalFormat = new DecimalFormat("#.######");
        String str = this.mAddress_line_1;
        if (str != null && !str.isEmpty()) {
            this.mEd_loc_line_1.setText(this.mAddress_line_1);
            line_1_cursorPos();
        }
        if (d != 0.0d) {
            EditText editText = this.mEd_latitude;
            editText.setText("" + decimalFormat.format(d));
            latitude_CursorPos();
        }
        if (d2 != 0.0d) {
            EditText editText2 = this.mEd_longitude;
            editText2.setText("" + decimalFormat.format(d2));
            longitude_CursorPos();
        }
        String str2 = this.mCity;
        if (str2 != null && !str2.isEmpty()) {
            this.mEd_city.setText(this.mCity);
            cityCursorPos();
        }
        String str3 = this.mCountry;
        if (str3 != null && !str3.isEmpty()) {
            this.mEd_country.setText(this.mCountry);
            country_CursorPos();
        }
        String str4 = this.mState;
        if (str4 != null && !str4.isEmpty()) {
            this.mEd_state.setText(this.mState);
            state_CursorPos();
        }
    }

    private void animateMarker(double d, double d2) {
        if (d2 != 0.0d && d != 0.0d) {
            LatLng latLng = new LatLng(d, d2);
            if (this.mMap != null) {
                Marker marker = this.marker;
                if (marker == null) {
                    this.marker = this.mMap.addMarker(new MarkerOptions().position(latLng).title(this.mCity));
                } else {
                    marker.setPosition(latLng);
                }
                this.mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                this.mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15.0f));
            }
        }
    }

    private void initMapFragment() {
        MapsInitializer.initialize(this);
        initLocation();
        SupportMapFragment supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        this.mMapFragment = supportMapFragment;
        if (supportMapFragment != null) {
            supportMapFragment.getMapAsync(this);
        }
    }

    private void initLocation() {
        this.locationSupplier = new LocationSupplier(this);
        this.fusedLocationClient = LocationServices.getFusedLocationProviderClient((Activity) this);
        this.mLocationCallback = new LocationCallback() { // from class: com.gpsvideocamera.videotimestamp.Activity.Location_Activity.2
            @Override // com.google.android.gms.location.LocationCallback
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);
                if (locationResult != null) {
                    for (Location location : locationResult.getLocations()) {
                        if (location != null) {
                            Location_Activity.this.mCurrentLocation = location;
                            Location_Activity.this.updateLiveLocaionUI();
                            Location_Activity.this.locationSupplier.setLocation(location);
                        }
                    }
                }
            }
        };
    }

    public void updateLiveLocaionUI() {
        if (this.mCurrentLocation != null && this.mLocationType.equals(Default.AUTOMATIC)) {
            this.mLatitude = this.mCurrentLocation.getLatitude();
            double longitude = this.mCurrentLocation.getLongitude();
            this.mLongitude = longitude;
            getAddress(this.mLatitude, longitude);
            setEditTextData(this.mLatitude, this.mLongitude);
            animateMarker(this.mLatitude, this.mLongitude);
        }
    }

    private void getAddress(double d, double d2) {
        List<Address> fromLocation;
        new ArrayList();
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            if (Geocoder.isPresent() && (fromLocation = geocoder.getFromLocation(d, d2, 1)) != null && fromLocation.size() > 0) {
                this.mAddress_line_1 = fromLocation.get(0).getAddressLine(0);
                this.mCity = fromLocation.get(0).getLocality();
                this.mState = fromLocation.get(0).getAdminArea();
                this.mCountry = fromLocation.get(0).getCountryName();
                this.mPostalCode = fromLocation.get(0).getPostalCode();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void startLocationUpdates() {
        LocationRequest locationRequest = new LocationRequest();
        this.mLocationRequest = locationRequest;
        locationRequest.setInterval(UPDATE_INTERVAL_IN_MILLISECONDS);
        this.mLocationRequest.setFastestInterval(5000);
        this.mLocationRequest.setPriority(100);
        this.mSettingsClient = LocationServices.getSettingsClient((Activity) this);
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        builder.addLocationRequest(this.mLocationRequest);
        this.mLocationSettingsRequest = builder.build();
        this.fusedLocationClient = LocationServices.getFusedLocationProviderClient((Activity) this);
        this.mSettingsClient.checkLocationSettings(this.mLocationSettingsRequest).addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() { // from class: com.gpsvideocamera.videotimestamp.Activity.Location_Activity.4
            @SuppressLint("MissingPermission")
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                if (Location_Activity.this.fusedLocationClient != null && Location_Activity.this.mLocationCallback != null) {
                    Location_Activity.this.fusedLocationClient.requestLocationUpdates(Location_Activity.this.mLocationRequest, Location_Activity.this.mLocationCallback, Looper.myLooper());
                }
            }
        }).addOnFailureListener(this, new OnFailureListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.Location_Activity.3
            @Override // com.google.android.gms.tasks.OnFailureListener
            public void onFailure(Exception exc) {
                int statusCode = ((ApiException) exc).getStatusCode();
                if (statusCode == 6) {
                    try {
                        ((ResolvableApiException) exc).startResolutionForResult(Location_Activity.this, 100);
                    } catch (IntentSender.SendIntentException unused) {
                    }
                } else if (statusCode == 8502) {
                    Toast.makeText(Location_Activity.this, "Location settings are inadequate, and cannot be fixed here. Fix in Settings.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void locationType_Popup(View view) {
        View inflate = View.inflate(this, R.layout.popup_location, null);
        final PopupWindow popupWindow = new PopupWindow(inflate, -2, -2, true);
        popupWindow.setOutsideTouchable(true);
        LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.li_automatic);
        LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.li_manual);
        final ImageView imageView = (ImageView) inflate.findViewById(R.id.img_automatic);
        final ImageView imageView2 = (ImageView) inflate.findViewById(R.id.img_manual);
        if (this.mLocationType.equals(Default.AUTOMATIC)) {
            imageView.setVisibility(View.VISIBLE);
        } else {
            imageView2.setVisibility(View.VISIBLE);
        }
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.Location_Activity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                Location_Activity.this.mLocationType = Default.AUTOMATIC;
                imageView.setVisibility(View.VISIBLE);
                imageView2.setVisibility(View.INVISIBLE);
                Location_Activity.this.disableUI();
                PopupWindow popupWindow2 = popupWindow;
                if (popupWindow2 != null) {
                    popupWindow2.dismiss();
                }
            }
        });
        linearLayout2.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.Location_Activity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                Location_Activity.this.mLocationType = Default.MANUAL;
                imageView.setVisibility(View.INVISIBLE);
                imageView2.setVisibility(View.VISIBLE);
                Location_Activity.this.disableUI();
                PopupWindow popupWindow2 = popupWindow;
                if (popupWindow2 != null) {
                    popupWindow2.dismiss();
                }
            }
        });
        popupWindow.showAtLocation(view, 51, (int) getResources().getDimension(R.dimen._66dp), (int) getResources().getDimension(R.dimen._66dp));
    }

    private String getLocation_Type() {
        return this.mSP.getString(this, SP.LOCATION_TYPE, Default.AUTOMATIC);
    }

    private void mapType_Popup(View view) {
        View inflate = View.inflate(this, R.layout.popup_map_type, null);
        final PopupWindow popupWindow = new PopupWindow(inflate, -2, -2, true);
        popupWindow.setOutsideTouchable(true);
        final ImageView imageView = (ImageView) inflate.findViewById(R.id.img_normal_done);
        final ImageView imageView2 = (ImageView) inflate.findViewById(R.id.img_setelite_done);
        final ImageView imageView3 = (ImageView) inflate.findViewById(R.id.img_terrain_done);
        final ImageView imageView4 = (ImageView) inflate.findViewById(R.id.img_hybird_done);
        LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.li_normal);
        LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.li_setellite);
        showDone(imageView, imageView2, imageView3, imageView4);
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.Location_Activity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                Location_Activity.this.mMap.setMapType(1);
                Location_Activity.this.mSP.setString(Location_Activity.this, SP.MAP_TYPE, Default.NORMAL_1);
                Location_Activity.this.showDone(imageView, imageView2, imageView3, imageView4);
                popupWindow.dismiss();
            }
        });
        linearLayout2.setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.Location_Activity.8
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                Location_Activity.this.mMap.setMapType(2);
                Location_Activity.this.mSP.setString(Location_Activity.this, SP.MAP_TYPE, Default.SETELLITE_2);
                Location_Activity.this.showDone(imageView, imageView2, imageView3, imageView4);
                popupWindow.dismiss();
            }
        });
        ((LinearLayout) inflate.findViewById(R.id.li_terrain)).setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.Location_Activity.9
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                Location_Activity.this.mMap.setMapType(3);
                Location_Activity.this.mSP.setString(Location_Activity.this, SP.MAP_TYPE, Default.TERRAIN_3);
                Location_Activity.this.showDone(imageView, imageView2, imageView3, imageView4);
                popupWindow.dismiss();
            }
        });
        ((LinearLayout) inflate.findViewById(R.id.li_hybird)).setOnClickListener(new View.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.Location_Activity.10
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                Location_Activity.this.mMap.setMapType(4);
                Location_Activity.this.mSP.setString(Location_Activity.this, SP.MAP_TYPE, Default.HYBRID_4);
                Location_Activity.this.showDone(imageView, imageView2, imageView3, imageView4);
                popupWindow.dismiss();
            }
        });
        if (this.moImg_map_fs.getTag().equals("Full_Screen")) {
            popupWindow.showAtLocation(this.mrelLocation_layout, 5, 0, 190);
        } else {
            popupWindow.showAtLocation(view, 5, 0, -135);
        }
    }

    private void setMapType() {
        String string = this.mSP.getString(this, SP.MAP_TYPE, Default.NORMAL_1);
        string.hashCode();
        char c = 65535;
        switch (string.hashCode()) {
            case -1579103941:
                if (string.equals(Default.SETELLITE_2)) {
                    c = 0;
                    break;
                }
                break;
            case -1423437003:
                if (string.equals(Default.TERRAIN_3)) {
                    c = 1;
                    break;
                }
                break;
            case -1202757124:
                if (string.equals(Default.HYBRID_4)) {
                    c = 2;
                    break;
                }
                break;
            case 1366708796:
                if (string.equals(Default.NORMAL_1)) {
                    c = 3;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                this.mMap.setMapType(2);
                return;
            case 1:
                this.mMap.setMapType(3);
                return;
            case 2:
                this.mMap.setMapType(4);
                return;
            case 3:
                this.mMap.setMapType(1);
                return;
            default:
                return;
        }
    }

    public void showDone(ImageView imageView, ImageView imageView2, ImageView imageView3, ImageView imageView4) {
        String string = this.mSP.getString(this, SP.MAP_TYPE, Default.NORMAL_1);
        string.hashCode();
        char c = 65535;
        switch (string.hashCode()) {
            case -1579103941:
                if (string.equals(Default.SETELLITE_2)) {
                    c = 0;
                    break;
                }
                break;
            case -1423437003:
                if (string.equals(Default.TERRAIN_3)) {
                    c = 1;
                    break;
                }
                break;
            case -1202757124:
                if (string.equals(Default.HYBRID_4)) {
                    c = 2;
                    break;
                }
                break;
            case 1366708796:
                if (string.equals(Default.NORMAL_1)) {
                    c = 3;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                imageView.setVisibility(View.INVISIBLE);
                imageView2.setVisibility(View.VISIBLE);
                imageView3.setVisibility(View.INVISIBLE);
                imageView4.setVisibility(View.INVISIBLE);
                return;
            case 1:
                imageView.setVisibility(View.INVISIBLE);
                imageView2.setVisibility(View.INVISIBLE);
                imageView3.setVisibility(View.VISIBLE);
                imageView4.setVisibility(View.INVISIBLE);
                return;
            case 2:
                imageView.setVisibility(View.INVISIBLE);
                imageView2.setVisibility(View.INVISIBLE);
                imageView3.setVisibility(View.INVISIBLE);
                imageView4.setVisibility(View.VISIBLE);
                return;
            case 3:
                imageView.setVisibility(View.VISIBLE);
                imageView2.setVisibility(View.INVISIBLE);
                imageView3.setVisibility(View.INVISIBLE);
                imageView4.setVisibility(View.INVISIBLE);
                return;
            default:
                return;
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        HelperClass.hideSoftKeyboard(this, view);
        switch (view.getId()) {
            case R.id.img_location :
                refreshLocation();
                return;
            case R.id.img_mapType :
                mapType_Popup(view);
                return;
            case R.id.img_map_fs :
                if (this.moImg_map_fs.getTag().equals("minimize")) {
                    this.mMap_view.setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
                    this.moImg_map_fs.setImageResource(R.drawable.ic_map_zoom_out);
                    this.moImg_map_fs.setTag("Full_Screen");
                    return;
                } else if (this.moImg_map_fs.getTag().equals("Full_Screen")) {
                    this.mMap_view.setLayoutParams(new RelativeLayout.LayoutParams(-1, (int) getResources().getDimension(R.dimen.map_size)));
                    this.moImg_map_fs.setImageResource(R.drawable.ic_map_zoom);
                    this.moImg_map_fs.setTag("minimize");
                    return;
                } else {
                    return;
                }
            case R.id.toolbar_back :
                onBackPressed();
                return;
            case R.id.toolbar_menu :
                locationType_Popup(this.mImg_menu);
                return;
            default:
                return;
        }
    }

    private void refreshLocation() {
        Location location = this.mCurrentLocation;
        if (location != null) {
            this.mLatitude = location.getLatitude();
            double longitude = this.mCurrentLocation.getLongitude();
            this.mLongitude = longitude;
            getAddress(this.mLatitude, longitude);
            setEditTextData(this.mLatitude, this.mLongitude);
            animateMarker(this.mLatitude, this.mLongitude);
        }
    }

    public void stopLocationUpdates() {
        if (this.mMap != null) {
            if (ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0) {
                this.mMap.setMyLocationEnabled(false);
            } else {
                return;
            }
        }
        FusedLocationProviderClient fusedLocationProviderClient = this.fusedLocationClient;
        if (fusedLocationProviderClient != null) {
            fusedLocationProviderClient.removeLocationUpdates(this.mLocationCallback);
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onPause() {
        super.onPause();
        this.app_is_paused = true;
        stopLocationUpdates();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        stopLocationUpdates();
    }

    private void saveData() {
        if (!isEmpty_1()) {
            String trim = this.mEd_latitude.getText().toString().trim();
            String trim2 = this.mEd_longitude.getText().toString().trim();
            if (trim.contains(",")) {
                trim = trim.replace(",", ".");
            }
            if (trim2.contains(",")) {
                trim2 = trim2.replace(",", ".");
            }
            this.mSP.setString(this, SP.LATITUDE, trim);
            this.mSP.setString(this, SP.LONGITUDE, trim2);
            this.mSP.setString(this, SP.LOC_LINE_1_ADDRESS, this.mEd_loc_line_1.getText().toString().trim());
            this.mSP.setString(this, SP.LOC_LINE_2_CITY, this.mEd_city.getText().toString().trim());
            this.mSP.setString(this, SP.LOC_LINE_3_STATE, this.mEd_state.getText().toString().trim());
            this.mSP.setString(this, SP.LOC_LINE_4_COUNTRY, this.mEd_country.getText().toString().trim());
            this.mSP.setString(this, SP.LOCATION_TYPE, this.mLocationType);
            if (this.mLocationType.equals(Default.AUTOMATIC)) {
                msgDialog();
                return;
            }
            this.mSP.setBoolean(this, SP.IS_LOCATION_CHANGED, true);
            finish();
            return;
        }
        Snackbar.make(this.mMap_view, getString(R.string.empty_location_msg), -Toast.LENGTH_LONG).show();
    }

    private boolean anyChange() {
        return !this.mEd_latitude.getText().toString().trim().equals(getLatitude()) || !this.mEd_longitude.getText().toString().trim().equals(getLongitude()) || !this.mEd_loc_line_1.getText().toString().trim().equals(getAddress_Line1()) || !this.mEd_city.getText().toString().trim().equals(getCity()) || !this.mEd_state.getText().toString().trim().equals(getState()) || !this.mEd_country.getText().toString().trim().equals(getCountry()) || !this.mLocationType.equals(getLocation_Type());
    }

    private void msgDialog() {
        if (!isFinishing()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(getString(R.string.save_location_msg));
            builder.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.Location_Activity.11
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    Location_Activity.this.finish();
                }
            });
            builder.create().show();
        }
    }

    private String getCountry() {
        return this.mSP.getString(this, SP.LOC_LINE_4_COUNTRY, "");
    }

    private String getState() {
        return this.mSP.getString(this, SP.LOC_LINE_3_STATE, "");
    }

    private String getCity() {
        return this.mSP.getString(this, SP.LOC_LINE_2_CITY, "");
    }

    private String getAddress_Line1() {
        return this.mSP.getString(this, SP.LOC_LINE_1_ADDRESS, "");
    }

    private String getLongitude() {
        return this.mSP.getString(this, SP.LONGITUDE, "");
    }

    private String getLatitude() {
        return this.mSP.getString(this, SP.LATITUDE, "");
    }

    @Override // com.google.android.gms.maps.OnMapReadyCallback
    public void onMapReady(GoogleMap googleMap) {
        this.mMap = googleMap;
        this.mCurrentLocation = this.locationSupplier.getLocation();
        this.mMap.setOnCameraIdleListener(new GoogleMap.OnCameraIdleListener() { // from class: com.gpsvideocamera.videotimestamp.Activity.Location_Activity$$ExternalSyntheticLambda0
            @Override // com.google.android.gms.maps.GoogleMap.OnCameraIdleListener
            public final void onCameraIdle() {
                Location_Activity.this.onCameraIdle();
            }
        });
        disableUI();
        setMapType();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (anyChange()) {
            saveData();
        } else {
            super.onBackPressed();
        }
    }

    private boolean isEmpty() {
        return this.mEd_loc_line_1.getText().toString().trim().isEmpty() && this.mEd_latitude.getText().toString().trim().isEmpty() && this.mEd_longitude.getText().toString().trim().isEmpty() && this.mEd_state.getText().toString().trim().isEmpty() && this.mEd_city.getText().toString().trim().isEmpty() && this.mEd_country.getText().toString().trim().isEmpty();
    }

    private boolean isEmpty_1() {
        String trim = this.mEd_latitude.getText().toString().trim();
        String trim2 = this.mEd_longitude.getText().toString().trim();
        if (trim.isEmpty() || trim2.isEmpty() || trim.equals("-") || trim2.equals("-") || trim.equals(".")) {
            return true;
        }
        if (!trim2.equals(".")) {
            try {
                if (trim.contains(",")) {
                    trim = trim.replace(",", ".");
                }
                if (trim2.contains(",")) {
                    trim2 = trim2.replace(",", ".");
                }
                double doubleValue = Double.valueOf(trim).doubleValue();
                double doubleValue2 = Double.valueOf(trim2).doubleValue();
                if (doubleValue < -90.0d || doubleValue > 90.0d || doubleValue == 0.0d || doubleValue2 < -180.0d || doubleValue2 > 180.0d || doubleValue2 == 0.0d) {
                    return true;
                }
            } catch (NumberFormatException unused) {
                return true;
            }
        }
        return false;
    }

    @Override // com.google.android.gms.maps.GoogleMap.OnCameraIdleListener
    public void onCameraIdle() {
        LatLng latLng;
        int i = this.camMove + 1;
        this.camMove = i;
        if (i >= 2 && (latLng = this.mMap.getCameraPosition().target) != null) {
            getAddress(latLng.latitude, latLng.longitude);
            setEditTextData(latLng.latitude, latLng.longitude);
        }
    }
}
