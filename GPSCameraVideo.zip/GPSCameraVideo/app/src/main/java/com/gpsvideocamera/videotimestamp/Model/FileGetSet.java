package com.gpsvideocamera.videotimestamp.Model;


public class FileGetSet {
    String fileName;
    String filePath;

    public String getFilePath() {
        return this.filePath;
    }

    public void setFilePath(String str) {
        this.filePath = str;
    }

    public String getFileName() {
        return this.fileName;
    }

    public void setFileName(String str) {
        this.fileName = str;
    }
}
