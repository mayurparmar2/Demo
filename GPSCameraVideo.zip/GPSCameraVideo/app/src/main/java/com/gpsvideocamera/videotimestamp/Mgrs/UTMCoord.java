package com.gpsvideocamera.videotimestamp.Mgrs;

import android.media.ExifInterface;



public class UTMCoord {
    private Angle centralMeridian;
    private final double easting;
    private final String hemisphere;
    private final Angle latitude;
    private final Angle longitude;
    private final double northing;
    private final int zone;

    public static UTMCoord fromLatLon(Angle angle, Angle angle2) {
        if (angle == null || angle2 == null) {
            throw new IllegalArgumentException("Latitude Or Longitude Is Null");
        }
        UTMCoordConverter uTMCoordConverter = new UTMCoordConverter();
        if (uTMCoordConverter.convertGeodeticToUTM(angle.radians, angle2.radians) == 0) {
            return new UTMCoord(angle, angle2, uTMCoordConverter.getZone(), uTMCoordConverter.getHemisphere(), uTMCoordConverter.getEasting(), uTMCoordConverter.getNorthing(), Angle.fromRadians(uTMCoordConverter.getCentralMeridian()));
        }
        throw new IllegalArgumentException("UTM Conversion Error");
    }

    public static UTMCoord fromLatLon(Angle angle, Angle angle2, String str) {
        Angle angle3;
        Angle angle4;
        UTMCoordConverter uTMCoordConverter;
        if (angle == null || angle2 == null) {
            throw new IllegalArgumentException("Latitude Or Longitude Is Null");
        }
        if (WWUtil.isEmpty(str) || !str.equals("NAD27")) {
            uTMCoordConverter = new UTMCoordConverter(6378137.0d, 0.0033528106647474805d);
            angle4 = angle;
            angle3 = angle2;
        } else {
            uTMCoordConverter = new UTMCoordConverter(6378206.4d, 0.0033900753040885176d);
            LatLon convertWGS84ToNAD27 = UTMCoordConverter.convertWGS84ToNAD27(angle, angle2);
            Angle latitude = convertWGS84ToNAD27.getLatitude();
            angle3 = convertWGS84ToNAD27.getLongitude();
            angle4 = latitude;
        }
        if (uTMCoordConverter.convertGeodeticToUTM(angle4.radians, angle3.radians) == 0) {
            return new UTMCoord(angle4, angle3, uTMCoordConverter.getZone(), uTMCoordConverter.getHemisphere(), uTMCoordConverter.getEasting(), uTMCoordConverter.getNorthing(), Angle.fromRadians(uTMCoordConverter.getCentralMeridian()));
        }
        throw new IllegalArgumentException("UTM Conversion Error");
    }

    public static UTMCoord fromUTM(int i, String str, double d, double d2) {
        UTMCoordConverter uTMCoordConverter = new UTMCoordConverter();
        if (uTMCoordConverter.convertUTMToGeodetic((long) i, str, d, d2) == 0) {
            return new UTMCoord(Angle.fromRadians(uTMCoordConverter.getLatitude()), Angle.fromRadians(uTMCoordConverter.getLongitude()), i, str, d, d2, Angle.fromRadians(uTMCoordConverter.getCentralMeridian()));
        }
        throw new IllegalArgumentException("UTM Conversion Error");
    }

    public static LatLon locationFromUTMCoord(int i, String str, double d, double d2) {
        UTMCoord fromUTM = fromUTM(i, str, d, d2);
        return new LatLon(fromUTM.getLatitude(), fromUTM.getLongitude());
    }

    public UTMCoord(Angle angle, Angle angle2, int i, String str, double d, double d2) {
        this(angle, angle2, i, str, d, d2, Angle.fromDegreesLongitude(0.0d));
    }

    public UTMCoord(Angle angle, Angle angle2, int i, String str, double d, double d2, Angle angle3) {
        if (angle == null || angle2 == null) {
            throw new IllegalArgumentException("Latitude Or Longitude Is Null");
        }
        this.latitude = angle;
        this.longitude = angle2;
        this.hemisphere = str;
        this.zone = i;
        this.easting = d;
        this.northing = d2;
        this.centralMeridian = angle3;
    }

    public Angle getCentralMeridian() {
        return this.centralMeridian;
    }

    public Angle getLatitude() {
        return this.latitude;
    }

    public Angle getLongitude() {
        return this.longitude;
    }

    public int getZone() {
        return this.zone;
    }

    public String getHemisphere() {
        return this.hemisphere;
    }

    public double getEasting() {
        return this.easting;
    }

    public double getNorthing() {
        return this.northing;
    }

    public String toString() {
        return this.zone + getLetter() + " " + ((int) this.easting) + "E" + " " + ((int) this.northing) + "N";
    }

    private String getLetter() {
        double d = getLatitude().degrees;
        return String.valueOf(d < -72.0d ? 'C' : d < -64.0d ? 'D' : d < -56.0d ? 'E' : d < -48.0d ? 'F' : d < -40.0d ? 'G' : d < -32.0d ? 'H' : d < -24.0d ? 'J' : d < -16.0d ? 'K' : d < -8.0d ? 'L' : d < 0.0d ? 'M' : d < 8.0d ? 'N' : d < 16.0d ? 'P' : d < 24.0d ? 'Q' : d < 32.0d ? 'R' : d < 40.0d ? 'S' : d < 48.0d ? 'T' : d < 56.0d ? 'U' : d < 64.0d ? 'V' : d < 72.0d ? 'W' : 'X');
    }
}
