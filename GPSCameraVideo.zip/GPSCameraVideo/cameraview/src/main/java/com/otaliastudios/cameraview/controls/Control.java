package com.otaliastudios.cameraview.controls;

/**
 * Base interface for controls like {@link Audio},
 * {@link Facing}, {@link Flash} and so on.
 */
public interface Control {
}
